Workflow for dead wood data
Audrey Barker Plotkin

Most of the compilation of dead wood data was done manually by Audrey Barker Plotkin, because the data sets varied substantially. The calculations are detailed in the metadata, and field methods for each study are detailed in their respective data archive posting (Harvard Forest and EDI KNB number).

For coarse woody debris and standing dead wood, we converted volume to density using wood density values (by tree species group and decay class) obtained at the EMS site (Liu, W. H., Bryant, D. M., Hutyra, L. R., Saleska, S. R., Pyle, E. H., Curran, D. J., Wofsy, S. C. 2006. Woody Debris Contribution to the Carbon Budget of Selectively Logged and Maturing Mid-latitude Forests. Oecologia 148: 108-117; values in table �wood_density_Liu2006.csv�). For fine woody debris, the calculation approache and density conversions are from Harmon and Sexton 1996 (Harmon, M.E. and J. Sexton. 1996. Guidelines for measurements of woody detritus in forest ecosystems. U.S. LTER Publication No. 20)

Coarse woody debris (downed wood 7.5 cm or 10 cm in diameter or greater)
Hf-c-cwd-vol_28mar16.csv (data)
Hf-c-cwd-metadata.csv (metadata and notes on calculations)

Fine woody debris (downed wood 0.65 cm diameter to 7.5 or 10 cm diameter)
Hf-c-fwd_all_updated25mar16.csv
Hf-c-fwd-metadata.csv

Standing dead wood (standing dead trees, snags, and stumps)
Hf-c-snags_vol_updated24mar16.csv
Hf-c-snag-metadata.csv
