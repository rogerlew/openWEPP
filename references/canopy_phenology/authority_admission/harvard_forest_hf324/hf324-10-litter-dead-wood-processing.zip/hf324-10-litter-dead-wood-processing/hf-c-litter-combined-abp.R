# hf-c-litter
# script to read, format, and combine all litterfall data from HF data archive files
# written by L. Nicoll
# Sept/Oct 2014

# Updates by A. Barker Plotkin, January 2015
# new version named hf-c-litter-combined-abp
# Major changes: 
# 1) include each basket separately when possible (all except HF008). 
# 2) report mass in gC/m2 (C= dry mass *0.5); 
# 3) report 3 columns: a) foliar; b) non-foliar; c) total

# Data updates to HF008, HF069, HF101, HF151, HF161, HF257 added March 2016, ABP.
# Data updates to HF161 & HF151 (HK) added November 2017, ABP

#DEFINE UNITS
#GRAMS PER BASKET/YEAR
#AREA OF BASKET IN M2

setwd('C:/Documents and Settings/aabarker/My Documents/Dropbox/HF C Synthesis/Data/litterfall/litterfall data and code')
library(plyr)
library(ggplot2)
library(stringr)
library(lubridate)

# HF008 Chronic N
# this is foliar biomass. Therefore FoliargCm2 will have the numbers. NonFoliargCm2 & TotalgCm2 will be NA.
# 3/31/16 ABP - use updated hf008-09 not yet archived, which has litter data from 2003-2013.

lit008a<-read.csv("hf008-03-litterfall-until-2002.csv")
lit008b<-read.csv("file:///C:/Users/aabarker/Dropbox/HF C Synthesis/Data/litterfall/litterfall data and code/hf008through2013.csv")
lit008<-rbind(lit008a,lit008b)

lit008$project<-"chronicN"
lit008$archive<-"hf008"
lit008$contact<-"frey"
lit008$tract<-"PH"
lit008$lat<-42.54
lit008$long<- -72.18
lit008$size<-900
lit008$treatment<-lit008$plot
lit008$notes<-paste (lit008$nbasket, 'baskets averaged')
lit008$obs.exp<-ifelse((lit008$plot=="PC")&(lit008$plot=="HC"),"obs","exp")
str(lit008)

#Confirmed with Mel Knorr that basket area is 0.2345m2.
lit008$bask.area<-0.2345 #m2. Audrey changed to match basket size in hurricane pulldown.

lit008$type<-substr(lit008$plot,1,1)
lit008$type<-revalue(lit008$type, c("P"="conifer","H"="hardwood"))
lit008$site<-ifelse(lit008$type=="conifer","red pine plantation","mixed hardwood")
lit008$obs.exp<-substr(lit008$plot,2,2)
lit008$obs.exp<-revalue(lit008$obs.exp, c("C"="obs","H"="exp","N"="exp","L"="exp"))
#Chronic N treatments ongoing for hardwood plots, but pine plots discontinued 2005 for high N and 2009 for the low N and control
lit008$treat.year<-ifelse (lit008$treatment %in% c('HL','HNS','HH'), '1988-ongoing', ifelse (lit008$obs.exp=="obs","NA", ifelse (lit008$treatment=='PH', '1988-2005', '1988-2009')))


#CALC gCm2
lit008$FoliargCm2<-(lit008$avg.m2/2)
lit008$NonFoliargCm2<-NA
lit008$TotalgCm2<-NA
lit008<-lit008[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 'TotalgCm2', 'notes')]
#################################################

#HF069 EMS
lit069a<-read.csv("file:///C:/Users/aabarker/Dropbox/HF C Synthesis/Data/litterfall/litterfall data and code/hf069-07-litter-2011.csv")
summary(lit069a)
lit069a<-subset(lit069a, !is.na(lit069a$wt.g) )

#number of baskets variable, adjusted with notes from methods
lit069a$nbasket<-ifelse(lit069a$doy>298 & lit069a$year==2001 & lit069a$plot=="X1", 2, 
  ifelse(lit069a$year %in% c(2002,2003,2004,2005) & lit069a$plot=="X1", 2, 
  ifelse(lit069a$year==2003 & lit069a$plot=="H1", 2,
  ifelse(lit069a$year %in% c(2004,2005) & lit069a$plot=="B2", 2,
  ifelse(lit069a$year==2006 & lit069a$doy>366 & lit069a$plot %in% c("A5","C2"), 2,
  ifelse(lit069a$year==2006 & lit069a$doy>366 & lit069a$plot=="X1", 1, 3))))))

lit069a$bask.area<-0.1295 ##updated 1/29/15 ABP (was 0.13m2)

#calculate gC/m2. The input data file reports summed litter from all the baskets per plot (usually 3 baskets; adjustments below for dates/plot with a basket missing)
lit069a$gCm2<-((lit069a$wt.g/2)/(lit069a$bask.area*lit069a$nbasket))

#group spp into categories
lit069a$category<-ifelse(lit069a$spp %in% c('decomp.matter', 'non.leaf','twig.bark','twigs.bark'), 'woody.other', 
                         ifelse(lit069a$spp %in% c ('acorn', 'acorns', 'fruit.flower', 'fruit.flower.bud', 'fruits&flowers', 'fruits.flowers.buds', 'pine.cones', 'unknown +cones'), 'reproductive', 'foliar'))
summary(lit069a)

#sumarize by type 
lit069b<-ddply(lit069a, 
              c("year","plot","site","bask.area","category" ),
              summarise,
               nbasket=mean(nbasket),
             gCm2.sum=sum(gCm2, na.rm=T))

                       
summary(lit069b)
        
#long to wide
library(reshape2)
names(lit069b)
lit069<-dcast(lit069b, year+plot+nbasket+site ~ category)
 
lit069$project<-"ems"
lit069$archive<-"hf069"
lit069$contact<-"munger"
lit069$tract<-"PH"
lit069$type<-"hardwood"
lit069$bask.area<-0.1295
lit069$size<-ifelse(lit069$plot %in% c("A4", "A5", "B5") & lit069$site=="ems" & lit069$year>2000,706.8583,ifelse(lit069$site=="harv" & lit069$year>2000,706.8583,314.1593))
lit069$lat<-42.54
lit069$long<--72.17
lit069$obs.exp<-ifelse(lit069$site=="harv","exp","obs")
lit069$treatment<-ifelse(lit069$site=="harv","harvest",NA)
lit069$treat.year<-ifelse(lit069$treatment=="harvest",2001,NA)
lit069$FoliargCm2<-lit069$foliar
lit069$NonFoliargCm2<-ifelse(is.na(lit069$reproductive), lit069$woody.other,lit069$reproductive + lit069$woody.other)
lit069$TotalgCm2<-ifelse(is.na(lit069$reproductive), lit069$woody.other+lit069$FoliargCm2,lit069$reproductive + lit069$woody.other+lit069$FoliargCm2)

lit069$notes<-ifelse(lit069$year==1999 & lit069$plot %in% c("B1","C2","E1"), "doy.229 1999 one basket contained birds' nests that had been built in the traps",ifelse(lit069$year==2006 &  lit069$plot %in% c("A5","C2"), "2 baskets 4/23/07",ifelse(lit069$year==2006 &  lit069$plot=="X1","1 basket 4/23/07",NA)))
lit069<-lit069[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 'TotalgCm2', 'notes')]

str(lit069)
#################################################################################

#HF101 Simulated Hurricane Experiment
#litterfall year is November + subsequent early June + subsequent early September
lit101<-read.csv("file:///C:/Users/aabarker/Dropbox/HF C Synthesis/Data/litterfall/litterfall data and code/hf101-02-annual-mean-thru2015.csv")
summary(lit101)
lit101<- rename(lit101,c('mean'='litter.mean'))

#from kg/ha to g/m2
lit101$gCm2<-lit101$litter.mean*.1

lit101$project<-"sim-hurricane"
lit101$archive<-"hf101"
lit101$contact<-"barker-plotkin"
lit101$tract<-"TS"
lit101$site<-"TS"
lit101$type<-"hardwood"
lit101$size<-ifelse(lit101$plot=="C",6000,8000)
lit101$lat<-42.49
lit101$long<--72.2
lit101$obs.exp<-ifelse(lit101$plot=="C","obs","exp")
lit101$treatment<-ifelse(lit101$plot=="C",NA, "pulldown")
lit101$treat.year<-ifelse(lit101$plot=="C",NA, 1990)
lit101$bask.area<-0.2345
lit101$FoliargCm2<-NA
lit101$NonFoliargCm2<-NA

#calculate gC/m2
lit101$TotalgCm2<-(lit101$gCm2/2)

lit101<-lit101[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 'TotalgCm2', 'notes')]
                           
#################################################################


#HF151 Little Prospect Hill & Hemlock Tower Litterfall Data
#LPH litterfall data from 2004 and 2005 are suspect. 25-30% of the total weights are 0s, which makes me think something major is missing.
#It isn't just a species or basket problem, but sprinkled throughout. I'm inclined to exclude these years.
#NAs in other years seem to indicate a basket that wasn't collected? Do exclude 300-330 in 2003, as it has some data & some NAs that look suspicious.
#Also note that the total number of baskets varies between 27 and 36, and they aren't always the same from year-to-year. Yet, at a site level, prob. okay. 
#HEM data do not have these issues and look okay.

#category of litter added manually in excel                           
lit151hk<-read.csv("file:///C:/Users/aabarker/Dropbox/HF C Synthesis/Data/litterfall/litterfall data and code/hf151-01-hem-litterfallThruOct2016.csv")
names(lit151hk)
lit151hk$site<-"HK"
summary(lit151hk)

#assign correct litter year to multiple collections. Litterfall year is thus August through the subsequent July.
lit151hk$meas.year<-lit151hk$year
lit151hk$year<-ifelse(lit151hk$month %in% c("APR","MAY","JULY"),lit151hk$meas.year-1,lit151hk$meas.year)


lit151lph<-read.csv("hf151-02-lph-litterfall.csv" )
summary(lit151lph)
names(lit151lph)
lit151lph$site<-"LPH"
lit151lph<-subset(lit151lph, lit151lph$YEAR %in% c(2003, 2006, 2007, 2008, 2009, 2010))
lit151lph<-subset(lit151lph, !is.na(lit151lph$TOT_WT))
lit151lph<- rename(lit151lph,c('YEAR'='year','DIST' = 'dist', 'TRANS'= 'trans','SPECIES'='species','TOT_WT'='tot.wt',"BASK_AREA"="bask.area"))

lit151a<-rbind(lit151hk[c(1,3:8,10)],lit151lph[c(1:4,6,8:10)])

lit151a<- rename(lit151a,c('tot.wt'='wt.g'))

lit151a$plot<-as.factor(paste(lit151a$trans,"-",lit151a$dist))


#summarize by plot & category

lit151b<-ddply(lit151a, 
c("year","plot","site","bask.area","category" ),
      summarise,
      wt.g.sum=sum(wt.g, na.rm=T))
#cm2 to m2
lit151b$bask.area<-lit151b$bask.area*0.0001
lit151b$wt.gCm2<-((lit151b$wt.g.sum/2)/(lit151b$bask.area))                        
summary(lit151b)
lit151b<-lit151b[,-6]
                           
#long to wide
library(reshape2)
names(lit151b)

lit151<-dcast(lit151b, year+plot+site+bask.area ~ category)

lit151$project<-ifelse(lit151$site=="HK","hk","lph")
lit151$archive<-"hf151"
lit151$contact<-"nicoll"
lit151$tract<-"PH"
lit151$lat<-42.54
lit151$long<--72.1825
lit151$obs.exp<-"obs"
lit151$treat.year<-NA
lit151$type<-ifelse(lit151$site=="HK","conifer","hardwood")
lit151$nbasket<-1
lit151$treatment<-NA
lit151$notes<-NA
lit151$size<-pi*6^2
#get the categories right
lit151$FoliargCm2<-lit151$foliar
lit151$NonFoliargCm2<-ifelse(is.na(lit151$reproductive), lit151$woody.other,lit151$reproductive + lit151$woody.other)
lit151$TotalgCm2<-ifelse(is.na(lit151$reproductive), lit151$woody.other+lit151$FoliargCm2,lit151$reproductive + lit151$woody.other+lit151$FoliargCm2)
# Get rid of 1 basket (2003, basket 330-300) with suspicious NAs in the input data.Row 28 here.
lit151<-subset(lit151[-28,])
lit151<-lit151[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 'TotalgCm2', 'notes')]
summary(lit151)

########################################################################


#HF161 Hemlock Removal Experiment

lit161b<-read.csv("file:///C:/Users/aabarker/Dropbox/HF C Synthesis/Data/litterfall/litterfall data and code/hf161-01-litterfallThruApr2016.csv")
#this version ends with April 2016 (need Jun 2016 for full 2015; litterfall year 2014 is thus complete), and does not include baskets 1 & 5 in plot 7 from 2010 on.
lit161b$date<-as.Date(lit161b$date,format="%m/%d/%Y")
subset(sales, format.Date(date, "%m")=="05" & format.Date(date, "%y")=="07")
lit161b$month<-as.numeric(format(lit161b$date, "%m"))
lit161b$year0<-as.numeric(format(lit161b$date, "%Y"))
lit161b$year<-ifelse(lit161b$month<7,lit161b$year0-1, lit161b$year0)

names(lit161b)
#remove rows (date by basket) with NA, as this means the basket shouldn't be counted b/c it was tipped or missing
lit161a<-subset(lit161b, !is.na (lit161b$total))

#create summary variables
lit161a$foliar<-lit161a$hemlock + lit161a$whpine + lit161a$oaks + lit161a$birches + lit161a$maples + lit161a$othdecid + lit161a$misc
names(lit161a)

#maybe easiest to turn g to gC/m2 at this point
lit161a$bask.area<-0.111
lit161a$FoliargCm2<-(lit161a$foliar/2)/lit161a$bask.area
lit161a$NonFoliargCm2<-(lit161a$twbacone/2)/lit161a$bask.area
lit161a$TotalgCm2<-(lit161a$total/2)/lit161a$bask.area

#summarize by sample date & plot. Get the mean mass based on the number of baskets at each sample date/plot.
lit161aa<-ddply(lit161a,
               c("plot", "date", "year"),
               summarise,
               nbasket=length(unique(basket)),
               FoliargCm2=mean(FoliargCm2, na.rm=T),
               NonFoliargCm2=mean(NonFoliargCm2, na.rm=T),
               TotalgCm2=mean(TotalgCm2, na.rm=T))
               
#summarize by plot and year
lit161<-ddply(lit161aa, 
           c("year","plot"),
           summarise,
              FoliargCm2=sum(FoliargCm2, na.rm=T),
              NonFoliargCm2=sum(NonFoliargCm2, na.rm=T),
              TotalgCm2=sum(TotalgCm2, na.rm=T),
              nbasket=mean(nbasket, na.rm=T))

lit161$bask.area<-0.111
lit161$project<-"hf-here"
lit161$archive<-"hf161"
lit161$contact<-"barker-plotkin"
lit161$tract<-"SIMES"
lit161$site<-"simes"
lit161$lat<-42.475
lit161$long<--72.215
lit161<- rename(lit161,c('Plot'='plot'))
lit161$plot<-as.factor(lit161$plot)
lit161$obs.exp<-as.factor(ifelse(lit161$plot %in% c(3,6,7,8),"obs","exp"))
lit161$type<-as.factor(ifelse(lit161$plot %in% c(7,8),"hardwood",ifelse(lit161$year==2014 & lit161$plot %in% c(1,2,4,5),"hardwood","conifer")))
lit161$treatment<-revalue(as.factor(lit161$plot),c("1"="girdled","2"="logged","3"="hemlock control","4"="logged","5"="girdled","6"="hemlock control","7"="hardwood control","8"="hardwood control"))
lit161$treat.year<-ifelse(lit161$plot %in% c(3,6,7,8),NA,2005)
lit161$size<-ifelse(lit161$plot==7 & lit161$year>2009, 6000, ifelse(lit161$plot %in% c(1,3),90*85,ifelse(lit161$plot==2,85^2,90^2)))
lit161$notes<-NA
lit161$plot<-as.factor(lit161$plot)

names(lit161)
lit161<-lit161[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 'TotalgCm2', 'notes')]


#HF180
#litterfall is foliage only, collected in October & November 2007, 2008. Plots are selected to be dominated by one tree species (80%+ basal area)
lit180<-read.csv("Brzostek-litter-long-total.csv")
summary(lit180)

lit180$tract<-ifelse(lit180$site=='Pisgah', "PISGAH", 'PH')

lit180<-ddply(lit180, 
              c("year","plot", "tract", "Species"),
              summarise,
              Foliargm2=mean(Foliargm2, na.rm=T))

#from biomass to C
lit180$FoliargCm2<-lit180$Foliargm2*0.5
names(lit180)

lit180$project<-"prot-enz"
lit180$archive<-"hf180"
lit180$contact<-"brzostek"
lit180<- rename(lit180,c('Species'='site'))
lit180$site<-revalue(lit180$site, c("ASCA"="ACSA"))
lit180$type<-ifelse (lit180$site=="TSCA", "conifer", "hardwood")
lit180$size<-3.14159*(8^2)
lit180$lat<-ifelse(lit180$tract=='PISGAH', 42.87, ifelse(lit180$site=='FRAM', 42.539171, 42.545013))
lit180$long<-ifelse(lit180$tract=='PISGAH', -72.45, ifelse(lit180$site=='FRAM',-72.193363, -72.177819))
lit180$obs.exp<-'obs'
lit180$treatment<-NA
lit180$treat.year<-NA
lit180$bask.area<-0.125
lit180$nbasket<-2
lit180$NonFoliargCm2<-NA
lit180$TotalgCm2<-NA
lit180$notes<-ifelse(lit180$site=="FRAM", "earthworms present in plot", NA)
names(lit180)
lit180<-lit180[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 'TotalgCm2', 'notes')]
mean(lit180$FoliargCm2)
################################################################################

#Impact of Hemlock Woolly Adelgid study. Note that sites CT & HT are not located on HF land so should be excluded.
litPR<-read.csv("Poli-litterfall.csv") #HF257-11
summary(litPR)

litPR<-subset(litPR,litPR$tract != "offHF")
litPR$FoliarTotg<-litPR$BELE + litPR$TSCA + litPR$ACRU + litPR$ACSA + litPR$QURU + litPR$QUAL + litPR$PIST + litPR$Others
litPR<-subset(litPR, !is.na(litPR$FoliarTotg))

#summarize by sample date & plot. Get the mean mass based on the number of baskets at each sample date/plot.
litPRa<-ddply(litPR,
                c("site", "Plot", "Collection.date", 'collectionyear'),
                summarise,
                nbasket=length(unique(basket)),
                Foliarg=mean(FoliarTotg, na.rm=T))
names(litPRa)

#summarize by plot and year
litPRb<-ddply(litPRa, 
              c("collectionyear","site", "Plot"),
              summarise,
              Foliarg=sum(Foliarg, na.rm=T),
              nbasket=mean(nbasket, na.rm=T))

#from biomass to C
litPRb$bask.area<-3.14159*((0.39/2)^2)
litPRb$FoliargCm2<-(litPRb$Foliarg/litPRb$bask.area)*0.5
names(litPRb)

litPRb$project<-"hem-chrono"
litPRb$archive<-'hf257'
litPRb$contact<-"raymer"
litPRb$type<-ifelse (litPRb$site=="Gdl", "hardwood", "conifer")
litPRb$size<-30*30
litPRb$lat<-ifelse(litPRb$site=='OG', 42.54, 42.47)
litPRb$long<-ifelse(litPRb$site=='OG', -72.18, -72.22)
litPRb$obs.exp<-ifelse(litPRb$site=='2G', 'exp','obs')
litPRb$treatment<-ifelse(litPRb$site=='2G', 'girdled',NA)
litPRb$treat.year<-ifelse(litPRb$site=='2G', 2005,NA)
litPRb$tract<-ifelse(litPRb$site=='OG', 'PH', 'SIMES')
litPRb$NonFoliargCm2<-NA
litPRb$TotalgCm2<-NA
litPRb<- rename(litPRb,c('collectionyear'='year', 'Plot'='plot'))
litPRb$notes<-ifelse(litPRb$year==2011, 'not full year, exclude?', 'Oct 2010-Aug 2011')
litPRb$plot<-as.factor(litPRb$plot)

litPRb<-litPRb[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 'TotalgCm2', 'notes')]

ddply(litPRb, "year", summarise, min=min(FoliargCm2))
######################################################################

# HF018 - Barre Woods Soil Warming experiment
lit018<-read.csv("C:/Users/aabarker/Desktop/hf018-09.csv")
names(lit018)
summary(lit018)
lit018<-subset(lit018, lit018$basket.type == 'LB')
lit018a<-ddply(lit018, 
              c("year","treat", 'basket.number'),
              summarise,
              g.basket=sum(mass.g.basket, na.rm=T))

# what the heck is a plot named 'PLOT' and there are only 2, and the species is 'OTHER'. Strike them!
lit018a<-subset(lit018a, lit018a$basket.number != 'PLOT')

lit018a$mass.m2<-lit018a$g.basket/0.2145
lit018a<-ddply(lit018a,
               c('year', 'treat'),
               summarise,
               FoliargCm2 = mean(mass.m2/2),
               nbasket = length(mass.m2))

lit018a$project<-"barre-woods"
lit018a$archive<-"hf018"
lit018a$contact<-"melillo"
lit018a$tract<-"SC"
lit018a$lat<- 42.48
lit018a$long<- -72.18
lit018a$size<-900
lit018a$treatment<-ifelse(lit018a$treat == 'C', NA, 'heated')
lit018a$plot<-ifelse(lit018a$treat == 'C', 'control', 'heated')
lit018a$notes<-paste (lit018$nbasket, 'baskets averaged')
lit018a$obs.exp<-ifelse(lit018a$plot=="control","obs","exp")
lit018a$bask.area<-0.2145
lit018a$type<-'hardwood'
lit018a$site<-'Barre Woods'
lit018a$treat.year<-ifelse (lit018a$treatment == 'heated', '2003-ongoing', NA)
lit018a$NonFoliargCm2<-NA
lit018a$TotalgCm2<-NA

lit018<-lit018a[c('year', 'archive', 'contact', 'project', 'type', 'size', 'lat', 
                 'long', 'obs.exp', 'treatment', 'treat.year', 'tract', 'site', 
                 'plot', 'nbasket', 'bask.area', 'FoliargCm2', 'NonFoliargCm2', 
                 'TotalgCm2', 'notes')]
#############################################################################

#combine all project files.
all_litter<-rbind(lit008,lit069,lit101,lit151,lit161, lit180, litPRb, lit018)
write.table(all_litter, "C:/Users/aabarker/Dropbox/HF C Synthesis/Data/litterfall/hf-c-litter-nov2017.csv", sep = ",", row.names = FALSE)
## These are the data used in the analyses. Table S5 also includes litterfall data from 'EMS transect' study which isn't in the data archive. ##
#### PROCESSING THE COMBINED DATA for figure 5, see NPPcombined.R -  ####