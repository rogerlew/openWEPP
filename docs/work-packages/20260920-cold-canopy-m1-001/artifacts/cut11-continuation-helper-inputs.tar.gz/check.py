"""Bounded non-physical check runner; exact argv, source pins, raw output retained."""
import datetime, hashlib, importlib.util, json, os, pathlib, signal, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('custody', '/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts/separate-accuracy-source-custody.py')
CUSTODY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CUSTODY)
name, target, *command = sys.argv[1:]
assert command and all(x not in command for x in ['--list', '--nocapture']), 'no physical invocation in check runner'
assert command[0] in ['cargo', 'rustfmt']
assert command[0] == 'rustfmt' or command[1] == 'clippy' or (command[1] == 'test' and '--no-run' in command)
env = dict(os.environ, **json.loads((ROOT / 'build-env.json').read_text()))
env['CARGO_TARGET_DIR'] = str(ROOT / target)
source = ROOT / 'source'
checks = ROOT / 'checks'
checks.mkdir(exist_ok=True)
deadline = datetime.datetime.fromisoformat('2026-10-03T08:15:38.858268+00:00')
remaining = (deadline - datetime.datetime.now(datetime.timezone.utc)).total_seconds()
limit = min(170, int(remaining) - 6)
if limit <= 0:
    raise SystemExit('Readiness deadline leaves no check window')
before = CUSTODY.entries(source)
start = time.monotonic()
record = {'command': command, 'cwd': str(source), 'target': env['CARGO_TARGET_DIR'], 'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_before': CUSTODY.identity(before), 'physical_invocations': 0, 'timeout_seconds': limit}
with (checks / (name + '.stdout')).open('wb') as stdout, (checks / (name + '.stderr')).open('wb') as stderr:
    child = subprocess.Popen(command, cwd=source, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        record['exit'] = child.wait(timeout=limit)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        child.wait(timeout=5)
        record['exit'] = 'TIMEOUT_GROUP_KILLED'
record['elapsed_seconds'] = time.monotonic() - start
record['source_after'] = CUSTODY.identity(CUSTODY.entries(source))
record['source_unchanged'] = record['source_before'] == record['source_after']
for suffix in ['stdout', 'stderr']:
    record[suffix + '_sha256'] = hashlib.sha256((checks / (name + '.' + suffix)).read_bytes()).hexdigest()
(checks / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
