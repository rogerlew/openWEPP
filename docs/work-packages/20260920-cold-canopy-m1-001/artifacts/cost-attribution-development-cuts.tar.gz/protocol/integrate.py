from pathlib import Path
import tarfile,shutil
base=Path('/home/roger/openwepp-experiments/cold-canopy-m1-projection-cache-20260930/frozen14/treatment/crates/openwepp-land-surface-energy/src')
root=Path('/home/roger/openwepp-experiments/cold-canopy-m1-cost-attribution-20260930')
dest=root/'source/crates/openwepp-land-surface-energy/src'
files=['m1_trust_region_controller.rs','m1_trust_region_stage1.rs','m1_coupled_tests.rs','solver_covered_evaluation/m1_coupled.rs']
with tarfile.open(root/'partial-instrumentation-preserved.tar.gz','x:gz') as tar:
 for name in files: tar.add(dest/name,arcname=name)
for name in files: shutil.copyfile(base/name,dest/name)
shutil.copyfile(root/'protocol/recorder.rs',dest/'m1_cost_attribution.rs')
p=dest/'m1_trust_region_controller.rs'; s=p.read_text();s+='\n#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]\n#[path = "m1_cost_attribution.rs"]\npub(crate) mod cost_attribution;\n';p.write_text(s)
guard='\n    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]\n    let _cost_scope = crate::m1_trust_region_controller::cost_attribution::'
def entry(path,name,call):
 s=path.read_text(); start=s.index('fn '+name+'('); body=s.index('{',start)
 s=s[:body+1]+guard+call+';\n'+s[body+1:];path.write_text(s)
p=dest/'solver_covered_evaluation/m1_coupled.rs'
entry(p,'core','core()')
entry(p,'evaluate_core_with_jacobian','enter(if selected_probe.is_some() { crate::m1_trust_region_controller::cost_attribution::Scope::SelectedJacobian } else { crate::m1_trust_region_controller::cost_attribution::Scope::NaturalJacobian })')
p=dest/'m1_trust_region_stage1.rs'
for name,scope in [('jacobi_factor','Svd'),('svd_lambda_ball','Damping'),('refine_face_before_crossing','Refinement'),('box_feasible_kkt_values_with_accounting','ActiveKkt'),('activate_first_crossing','ActiveKkt'),('solve_subproblem_with_certificate','Stage1')]:
 entry(p,name,'enter(crate::m1_trust_region_controller::cost_attribution::Scope::'+scope+')')
s=p.read_text();needle='for sweep in (completed_sweeps + 1)..=64u8 {';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]\n        crate::m1_trust_region_controller::cost_attribution::sweep();');p.write_text(s)
# Generic function needs a signature search rather than the simple helper.
p=dest/'m1_trust_region_controller.rs';s=p.read_text();start=s.index('fn transition_after_model<');body=s.index('{',start);s=s[:body+1]+guard+'enter(crate::m1_trust_region_controller::cost_attribution::Scope::Acceptance);\n'+s[body+1:];p.write_text(s)
p=dest/'m1_coupled_tests.rs';s=p.read_text();start=s.index('fn m1_trust_region_projection_cache_benchmark_protocol()');end=s.index('\n#[cfg(',start);part=s[start:end]
part=part.replace('    let mut lines =', '    use crate::m1_trust_region_controller::cost_attribution;\n    let enabled = std::env::var("M1_COST_ATTRIBUTION").ok().as_deref() == Some("1");\n    let mut lines =',1)
part=part.replace('    marker(&format!("\\nPC_READY', '    cost_attribution::begin(enabled);\n    marker(&format!("\\nPC_READY',1)
part=part.replace('    marker("PC_INIT_END");', '    cost_attribution::phase(1);\n    marker("PC_INIT_END");',1)
part=part.replace('"projection_count_mode": "disabled_optional_capture"}', '"projection_count_mode": "disabled_optional_capture", "cost_attribution": cost_attribution::take()}')
s=s[:start]+part+s[end:];p.write_text(s)
print('Integrated complete fixed hierarchy; partial source preserved; no model execution')
