//! Private frozen-weight arithmetic shared by detached Stage 1 controls.

use std::cmp::Ordering;

#[cfg(test)]
use std::cell::{Cell, RefCell};

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
use crate::m1_trust_region_controller_interface::M1TrustRegionCurrentHydraulics;

use super::{
    M1TrustRegionBallEndpoint, M1TrustRegionBallObservation, M1TrustRegionCorrectionPosition,
    M1TrustRegionJacobiInput, M1TrustRegionJacobiObservation, M1TrustRegionJacobiPair,
    M1TrustRegionLambdaEvaluation, M1TrustRegionRefinementGuardStage,
    M1TrustRegionRefinementReason, M1TrustRegionRefusalKind,
};
use super::{M1TrustRegionMeritInput, M1TrustRegionMeritObservation};

const TWO_POW_53: f64 = 9_007_199_254_740_992.0;

#[cfg(test)]
thread_local! {
    static REFINEMENT_FROZEN_WEIGHTED_MERIT_ENTRIES: Cell<u32> = const { Cell::new(0) };
}

#[cfg(test)]
mod projection_cache_controls {
    use super::{
        JacobiFactor, LambdaProjection, LambdaTrace, RefinementWorkLedger,
        lambda_projection_search_entries_for_test, lambda_step,
        reset_lambda_projection_search_entries_for_test, set_lambda_projection_capture_for_test,
        svd_lambda_ball,
    };

    fn factor() -> JacobiFactor {
        JacobiFactor {
            a: vec![vec![1.0, 0.0], vec![0.0, 1.0]],
            b: vec![vec![1.0, 0.0], vec![0.0, 1.0]],
            v: vec![vec![1.0, 0.0], vec![0.0, 1.0]],
            sigma: vec![1.0, 2.0],
            order: vec![0, 1],
            visits: Vec::new(),
            rotations: 0,
            sweeps: 0,
        }
    }

    // Literal accepted-cut09 arithmetic for finite analytic controls.  It is
    // intentionally test-only and has no candidate cache branch.
    fn accepted_cut09_lambda_step(
        factor: &JacobiFactor,
        y: &[f64],
        lambda: f64,
        mut refinement_work: Option<&mut RefinementWorkLedger>,
    ) -> Result<Vec<f64>, &'static str> {
        macro_rules! scalar {
            () => {
                if let Some(work) = refinement_work.as_deref_mut() {
                    work.scalar();
                }
            };
        }
        macro_rules! guard {
            () => {
                if let Some(work) = refinement_work.as_deref_mut() {
                    work.guard();
                }
            };
        }
        guard!();
        if y.len() != factor.b.len() || !lambda.is_finite() || lambda < 0.0 {
            return Err("invalid lambda input");
        }
        let cols = factor.sigma.len();
        let mut coefficients = vec![0.0; cols];
        for sorted in 0..cols {
            let j = factor.order[sorted];
            let sigma = factor.sigma[j];
            let mut uty = 0.0;
            for (row, &y_value) in y.iter().enumerate() {
                let mut av = 0.0;
                for free in 0..cols {
                    scalar!();
                    let term = factor.a[row][free] * factor.v[free][j];
                    guard!();
                    if !term.is_finite() {
                        return Err("nonfinite A_free V product");
                    }
                    scalar!();
                    av += term;
                    guard!();
                    if !av.is_finite() {
                        return Err("nonfinite A_free V sum");
                    }
                }
                scalar!();
                let u = av / sigma;
                guard!();
                if !u.is_finite() || !y_value.is_finite() {
                    return Err("nonfinite U");
                }
                scalar!();
                let term = u * y_value;
                guard!();
                if !term.is_finite() {
                    return Err("nonfinite Uty product");
                }
                scalar!();
                uty += term;
                guard!();
                if !uty.is_finite() {
                    return Err("nonfinite Uty sum");
                }
            }
            scalar!();
            let sigma_square = sigma * sigma;
            scalar!();
            let denom = sigma_square + lambda;
            scalar!();
            let gain = sigma / denom;
            scalar!();
            // The frozen grouped expression contains both the multiplication and
            // the unary negation; charge both without changing its rounding.
            scalar!();
            let coefficient = -(gain * uty);
            guard!();
            if !denom.is_finite() || !gain.is_finite() || !coefficient.is_finite() {
                return Err("nonfinite lambda coefficient");
            }
            coefficients[j] = coefficient;
        }
        let mut step = vec![0.0; cols];
        for (out, output) in step.iter_mut().enumerate() {
            let mut sum = 0.0;
            for sorted in 0..cols {
                let j = factor.order[sorted];
                scalar!();
                let term = factor.v[out][j] * coefficients[j];
                guard!();
                if !term.is_finite() {
                    return Err("nonfinite V product");
                }
                scalar!();
                sum += term;
                guard!();
                if !sum.is_finite() {
                    return Err("nonfinite V sum");
                }
            }
            *output = sum;
        }
        Ok(step)
    }

    #[test]
    fn lambda_projection_cache_matches_original_body_bitwise_and_enters_once() {
        let factor = factor();
        let y = [1.25, -3.5];
        let original_zero = accepted_cut09_lambda_step(&factor, &y, 0.0, None)
            .expect("accepted original zero-lambda body");
        let mut projection = vec![0.0; factor.sigma.len()];
        set_lambda_projection_capture_for_test(true);
        reset_lambda_projection_search_entries_for_test();
        let cached_zero = lambda_step(
            &factor,
            &y,
            0.0,
            None,
            LambdaProjection::Record(&mut projection),
        )
        .expect("analytic zero-lambda cache recording");
        assert_eq!(
            cached_zero
                .iter()
                .map(|value| value.to_bits())
                .collect::<Vec<_>>(),
            original_zero
                .iter()
                .map(|value| value.to_bits())
                .collect::<Vec<_>>(),
        );
        for lambda in [0.125, 1.0, 8.0] {
            let original = accepted_cut09_lambda_step(&factor, &y, lambda, None)
                .expect("accepted original positive-lambda body");
            let cached = lambda_step(
                &factor,
                &y,
                lambda,
                None,
                LambdaProjection::Reuse(&projection),
            )
            .expect("analytic positive-lambda cached body");
            assert_eq!(
                cached
                    .iter()
                    .map(|value| value.to_bits())
                    .collect::<Vec<_>>(),
                original
                    .iter()
                    .map(|value| value.to_bits())
                    .collect::<Vec<_>>(),
            );
        }
        assert_eq!(lambda_projection_search_entries_for_test(), 1);

        reset_lambda_projection_search_entries_for_test();
        let mut trace = LambdaTrace::default();
        svd_lambda_ball(&factor, &y, 0.1, None, &mut trace)
            .expect("analytic radius search completes");
        assert_eq!(trace.bisection_evaluations.len(), 48);
        assert_eq!(lambda_projection_search_entries_for_test(), 1);
        set_lambda_projection_capture_for_test(false);
    }

    #[test]
    fn first_lambda_coefficient_refusal_precedes_later_projection_refusal() {
        let factor = JacobiFactor {
            a: vec![vec![1.0, f64::MAX]],
            b: vec![vec![1.0, f64::MAX]],
            v: vec![vec![1.0, 0.0], vec![0.0, 2.0]],
            sigma: vec![f64::MAX, 1.0],
            order: vec![0, 1],
            visits: Vec::new(),
            rotations: 0,
            sweeps: 0,
        };
        let y = [1.0];
        let original = accepted_cut09_lambda_step(&factor, &y, 0.0, None);
        let mut projection = vec![0.0; factor.sigma.len()];
        let cached = lambda_step(
            &factor,
            &y,
            0.0,
            None,
            LambdaProjection::Record(&mut projection),
        );
        assert_eq!(original, Err("nonfinite lambda coefficient"));
        assert_eq!(cached, original);
        assert_eq!(projection[0].to_bits(), (1.0 / f64::MAX).to_bits());
        assert_eq!(projection[1].to_bits(), 0.0_f64.to_bits());
    }

    fn diagonal_factor(a: f64) -> JacobiFactor {
        JacobiFactor {
            a: vec![vec![a]],
            b: vec![vec![a]],
            v: vec![vec![1.0]],
            sigma: vec![a],
            order: vec![0],
            visits: Vec::new(),
            rotations: 0,
            sweeps: 0,
        }
    }

    #[test]
    fn lambda_ball_changed_rhs_and_factor_have_independent_diagonal_values() {
        set_lambda_projection_capture_for_test(true);
        reset_lambda_projection_search_entries_for_test();
        // In one dimension p(lambda)=-a*y/(a*a+lambda). The four
        // expectations below are exact binary64 numbers derived independently.
        for (index, (a, y, radius, expected_step, expected_lambda)) in [
            (2.0, 4.0, 3.0, -2.0_f64, 0.0_f64),
            (2.0, 4.0, 1.0, -1.0_f64, 4.0_f64),
            (4.0, 4.0, 3.0, -1.0_f64, 0.0_f64),
            (2.0, 2.0, 3.0, -1.0_f64, 0.0_f64),
        ]
        .into_iter()
        .enumerate()
        {
            let factor = diagonal_factor(a);
            let mut trace = LambdaTrace::default();
            svd_lambda_ball(&factor, &[y], radius, None, &mut trace)
                .expect("fresh independent diagonal search");
            assert_eq!(trace.step[0].to_bits(), expected_step.to_bits());
            assert_eq!(trace.lambda.to_bits(), expected_lambda.to_bits());
            assert_eq!(
                trace.bisection_evaluations.len(),
                if expected_lambda > 0.0 { 48 } else { 0 }
            );
            let original = accepted_cut09_lambda_step(&factor, &[y], trace.lambda, None)
                .expect("immutable original at selected multiplier");
            assert_eq!(trace.step[0].to_bits(), original[0].to_bits());
            assert_eq!(
                lambda_projection_search_entries_for_test(),
                u32::try_from(index + 1).expect("four searches")
            );
        }
        set_lambda_projection_capture_for_test(false);
    }

    #[test]
    fn cache_signed_zero_and_projection_refusals_match_immutable_original() {
        let factor = diagonal_factor(1.0);
        for rhs in [0.0_f64, -0.0_f64] {
            let mut projection = vec![0.0];
            let recorded = lambda_step(
                &factor,
                &[rhs],
                -0.0,
                None,
                LambdaProjection::Record(&mut projection),
            )
            .expect("signed zero recording");
            assert_eq!(recorded[0].to_bits(), 0.0_f64.to_bits());
            for lambda in [-0.0, 0.5] {
                let candidate = lambda_step(
                    &factor,
                    &[rhs],
                    lambda,
                    None,
                    LambdaProjection::Reuse(&projection),
                )
                .expect("signed zero reuse");
                let original = accepted_cut09_lambda_step(&factor, &[rhs], lambda, None)
                    .expect("immutable signed zero");
                assert_eq!(candidate[0].to_bits(), original[0].to_bits());
                assert_eq!(candidate[0].to_bits(), 0.0_f64.to_bits());
            }
        }
        for rhs in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let mut projection = vec![0.0];
            let original = accepted_cut09_lambda_step(&factor, &[rhs], 0.0, None);
            let candidate = lambda_step(
                &factor,
                &[rhs],
                0.0,
                None,
                LambdaProjection::Record(&mut projection),
            );
            assert_eq!(original, Err("nonfinite U"));
            assert_eq!(candidate, original);
        }
        let mut overflow = diagonal_factor(1.0);
        overflow.a[0][0] = f64::MAX;
        overflow.v[0][0] = 2.0;
        let mut projection = vec![0.0];
        let original = accepted_cut09_lambda_step(&overflow, &[1.0], 0.0, None);
        let candidate = lambda_step(
            &overflow,
            &[1.0],
            0.0,
            None,
            LambdaProjection::Record(&mut projection),
        );
        assert_eq!(original, Err("nonfinite A_free V product"));
        assert_eq!(candidate, original);
    }

    #[test]
    fn refinement_rhs_reconstruction_matches_accepted_body_and_ledger() {
        let factor = factor();
        for rhs in [[1.25, -3.5], [-2.0, 0.75]] {
            let mut candidate_work = RefinementWorkLedger::default();
            let mut original_work = RefinementWorkLedger::default();
            let candidate = lambda_step(
                &factor,
                &rhs,
                0.0,
                Some(&mut candidate_work),
                LambdaProjection::Reconstruct,
            )
            .expect("refinement reconstruction");
            let original = accepted_cut09_lambda_step(&factor, &rhs, 0.0, Some(&mut original_work))
                .expect("accepted refinement reconstruction");
            assert_eq!(
                candidate.iter().map(|x| x.to_bits()).collect::<Vec<_>>(),
                original.iter().map(|x| x.to_bits()).collect::<Vec<_>>()
            );
            assert_eq!(
                candidate_work.scalar_operations,
                original_work.scalar_operations
            );
            assert_eq!(candidate_work.guard_events, original_work.guard_events);
        }
    }
}

// BVLS-04 controls intentionally enter through the retained positive-lambda
// face.  They are expected-red until the reviewed two-correction body exists;
// the independent certificate is read only after the solver input is decoded.
#[cfg(test)]
mod bvls04_expected_red_controls {
    use super::{
        RefinementRetainedFaceObservation, m1_trust_region_refinement_retained_face_for_test,
    };
    use serde_json::Value;

    const SHIFTED_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/shifted-face-observed-capture.json"
    ));
    const SHIFTED_CERTIFICATE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/shifted-refinement-correctness-result.json"
    ));

    fn shifted_face() -> (Value, Value) {
        let capture: Value =
            serde_json::from_str(SHIFTED_CAPTURE).expect("retained shifted capture");
        let certificate: Value =
            serde_json::from_str(SHIFTED_CERTIFICATE).expect("independent shifted certificate");
        (capture["face_capture"].clone(), certificate)
    }

    fn bits(values: &Value) -> Vec<u64> {
        values
            .as_array()
            .expect("independent binary64 array")
            .iter()
            .map(|value| {
                u64::from_str_radix(value.as_str().expect("binary64 bits"), 16)
                    .expect("valid binary64 bits")
            })
            .collect()
    }

    fn bit(value: &Value) -> u64 {
        value.as_str().map_or_else(
            || value.as_f64().expect("binary64 value").to_bits(),
            |bits| u64::from_str_radix(bits, 16).expect("valid binary64 bits"),
        )
    }

    fn certificate_class_label(observed: &str) -> &'static str {
        match observed {
            "fixed" => "Fixed",
            "release_lower" => "ReleaseLower",
            "retain_lower" => "RetainLower",
            "release_upper" => "ReleaseUpper",
            "retain_upper" => "RetainUpper",
            "free_pass" => "FreePass",
            "free_refuse" => "FreeRefuse",
            _ => "Unknown",
        }
    }

    fn retained_positive_result(capture: &Value) -> RefinementRetainedFaceObservation {
        m1_trust_region_refinement_retained_face_for_test(capture, None)
            .expect("expected-red: retained positive face must complete BVLS-04")
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_retained_positive_face_certificate() {
        let (capture, certificate) = shifted_face();
        let operation = &capture["operations"][1];
        let observed = retained_positive_result(&capture);
        assert_eq!(observed.p0_bits, bits(&operation["p_candidate"]));
        assert_eq!(
            observed.p1_bits,
            bits(&certificate["points"]["ordinary_correction_1"]["p_bits"])
        );
        assert_eq!(
            observed.p2_bits,
            bits(&certificate["points"]["compensated_correction_2"]["p_bits"])
        );
        assert_eq!(
            observed.delta0_free_bits,
            bits(&certificate["candidate_intermediates"]["correction1_delta_bits"])
        );
        assert_eq!(
            observed.delta1_free_bits,
            bits(&certificate["candidate_intermediates"]["correction2_delta_bits"])
        );
        assert_eq!(
            observed.h0_free_bits,
            Some(bits(
                &certificate["candidate_intermediates"]["correction1_h_free_bits"]
            ))
        );
        assert_eq!(
            observed.h1_free_bits,
            Some(bits(
                &certificate["candidate_intermediates"]["correction2_h_free_bits"]
            ))
        );
        assert_eq!(
            observed.residual1_bits,
            bits(&certificate["candidate_intermediates"]["correction2_residual_bits"])
        );
        assert_eq!(
            observed.r0_bits,
            bits(&certificate["points"]["original"]["residual_bits"])
        );
        assert_eq!(
            observed.final_residual_bits,
            Some(bits(
                &certificate["points"]["compensated_correction_2"]["residual_bits"]
            ))
        );
        assert_eq!(
            observed.final_gradient_bits,
            Some(bits(
                &certificate["points"]["compensated_correction_2"]["gradient_bits"]
            ))
        );
        assert_eq!(
            observed.final_lambda_p_bits,
            Some(bits(
                &certificate["points"]["compensated_correction_2"]["lambda_p_bits"]
            ))
        );
        assert_eq!(
            observed
                .classes
                .iter()
                .map(|class| certificate_class_label(class).to_owned())
                .collect::<Vec<_>>(),
            certificate["points"]["compensated_correction_2"]["classes"]
                .as_array()
                .expect("certificate classes")
                .iter()
                .map(|value| value.as_str().expect("class").to_owned())
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_shift_orientation_order_and_free_active_join()
    {
        let (capture, certificate) = shifted_face();
        let operation = &capture["operations"][1];
        let observed = retained_positive_result(&capture);
        assert!(
            operation["lambda_times_p"]
                .as_array()
                .expect("retained lambda shift")
                .iter()
                .any(|value| value.as_str().expect("captured bit") != "0000000000000000")
        );
        assert_eq!(
            observed.h_bits,
            bits(&certificate["points"]["compensated_correction_2"]["h_bits"])
        );
        assert_eq!(
            observed.cbar_bits,
            bits(&certificate["points"]["compensated_correction_2"]["cbar_bits"])
        );
        assert_eq!(
            observed.tau_bits,
            bits(&certificate["points"]["compensated_correction_2"]["tau_bits"])
        );
        assert_eq!(
            observed.lower_mask_p2,
            operation["lower_before"]
                .as_array()
                .expect("retained active mask")
                .iter()
                .map(|v| v.as_bool().expect("mask"))
                .collect::<Vec<_>>()
        );
        assert_eq!(observed.factorizations_added, 0);
        assert_eq!(observed.factor_application_count, 2);
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_unequal_radii_closeness_failures_work_and_isolation()
     {
        let (capture, certificate) = shifted_face();
        let observed = retained_positive_result(&capture);
        let final_point = &certificate["points"]["compensated_correction_2"];
        assert_eq!(observed.corrections, 2);
        assert_eq!(
            observed.p2_full_norm2_bits,
            Some(bit(&final_point["full_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.p2_reduced_norm2_bits,
            Some(bit(&final_point["reduced_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.original_radius_bits,
            bit(&final_point["original_radius"])
        );
        assert_eq!(
            observed.remaining_radius_bits,
            Some(bit(&final_point["remaining_face_radius"]))
        );
        assert_eq!(
            observed.radius_gap_bits,
            Some(bit(&final_point["radius_gap_ordered"]))
        );
        assert_eq!(
            observed.radius_tolerance_bits,
            Some(bit(&final_point["radius_tolerance"]))
        );
        assert_eq!(
            observed.first_residual_operations
                + observed.second_dot2_operations
                + observed.factor_application_operations
                + observed.coordinate_update_operations,
            27_446
        );
        assert!(observed.refinement_scalar_operations <= 69_345);
        assert!(observed.full_work.refinement_guard_events <= 208_439);
        assert_eq!(observed.second_dot2_operations, 22_263);
        assert_eq!(observed.factor_application_count, 2);
    }
}

// These controls name the small shared observation seams the BVLS-04 body must
// provide.  They deliberately have no test-side numerical implementation:
// until the body owns these operations, this module is expected to compile red.
#[cfg(test)]
mod bvls04_future_body_expected_red_controls {
    use super::{
        M1TrustRegionBvls04AnalyticInput, M1TrustRegionBvls04Poison,
        M1TrustRegionBvls04PoisonObservation, M1TrustRegionBvls04Reservation,
        M1TrustRegionBvls04ReservationOwner, M1TrustRegionBvls04ShiftedInverseInput,
        RefinementRetainedFaceObservation, m1_trust_region_bvls03_signed_zero_for_test,
        m1_trust_region_bvls04_analytic_for_test, m1_trust_region_bvls04_poison_for_test,
        m1_trust_region_bvls04_shifted_inverse_for_test,
        m1_trust_region_bvls04_work_boundary_for_test,
        m1_trust_region_refinement_retained_face_for_test,
    };
    use crate::{
        M1TrustRegionCorrectionPosition, M1TrustRegionRefinementGuardStage,
        M1TrustRegionRefinementReason,
    };
    use serde_json::Value;

    const SHIFTED_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/shifted-face-observed-capture.json"
    ));
    const SHIFTED_CERTIFICATE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/shifted-refinement-correctness-result.json"
    ));
    const BVLS03_ZERO_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/finite-precision-observed-capture.json"
    ));

    fn shifted_face() -> (Value, Value) {
        let capture: Value =
            serde_json::from_str(SHIFTED_CAPTURE).expect("retained shifted capture");
        let certificate: Value =
            serde_json::from_str(SHIFTED_CERTIFICATE).expect("independent shifted certificate");
        (capture["face_capture"].clone(), certificate)
    }

    fn bvls03_zero_face() -> Value {
        serde_json::from_str(BVLS03_ZERO_CAPTURE).expect("accepted BVLS-03 zero-lambda capture")
    }

    fn retained_positive_result(capture: &Value) -> RefinementRetainedFaceObservation {
        m1_trust_region_refinement_retained_face_for_test(capture, None)
            .expect("expected-red: retained positive face must complete BVLS-04")
    }

    fn bit(value: &Value) -> u64 {
        value.as_str().map_or_else(
            || value.as_f64().expect("binary64 value").to_bits(),
            |bits| u64::from_str_radix(bits, 16).expect("valid binary64 bits"),
        )
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_analytic_shift_is_shared_operation() {
        let observed = m1_trust_region_bvls04_analytic_for_test(M1TrustRegionBvls04AnalyticInput {
            v: vec![vec![1.0, 0.0], vec![0.0, 1.0]],
            sigma: vec![1.0, 1.0],
            factor_order: vec![0, 1],
            free_ids: vec![0, 1],
            unshifted_gradient: vec![-1.0, 0.0],
            lambda: 1.0,
            q: vec![1.0, 0.0],
        })
        .expect("expected-red shared shifted-gradient/inverse operation");
        assert_eq!(observed.shifted_gradient_bits, [0, 0]);
        assert_eq!(
            observed.delta_free_slot_bits,
            [0x8000_0000_0000_0000, 0x8000_0000_0000_0000]
        );
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_nonsymmetric_factor_order_and_coordinate_join()
     {
        let observed = m1_trust_region_bvls04_analytic_for_test(M1TrustRegionBvls04AnalyticInput {
            v: vec![vec![0.6, -0.8], vec![0.8, 0.6]],
            sigma: vec![2.0, 3.0],
            factor_order: vec![1, 0],
            free_ids: vec![1, 0],
            unshifted_gradient: vec![10.0, -20.0],
            lambda: 5.0,
            q: vec![0.0, 0.0],
        })
        .expect("expected-red retained nonsymmetric shifted inverse");
        assert_eq!(
            observed.t_bits,
            [0xc024_0000_0000_0000, 0xc034_0000_0000_0000]
        );
        assert_eq!(
            observed.z_bits,
            [0xbff1_c71c_71c7_1c72, 0xbff6_db6d_b6db_6db7]
        );
        assert_eq!(
            observed.delta_free_slot_bits,
            [0xbfde_79e7_9e79_e7a2, 0x3ffb_efbe_fbef_befc]
        );
        assert_eq!(
            observed.delta_coordinate_bits,
            [0x3ffb_efbe_fbef_befc, 0xbfde_79e7_9e79_e7a2]
        );
        assert_eq!(observed.factor_order, vec![1, 0]);
        assert_eq!(observed.free_ids, vec![1, 0]);
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_m4_factor_order_changes_binary64_accumulation()
     {
        let observed = m1_trust_region_bvls04_shifted_inverse_for_test(
            M1TrustRegionBvls04ShiftedInverseInput {
                v: vec![
                    vec![0.5, 0.5, 0.5, 0.5],
                    vec![-0.5, 0.5, 0.5, -0.5],
                    vec![0.5, -0.5, 0.5, -0.5],
                    vec![-0.5, -0.5, 0.5, 0.5],
                ],
                sigma: vec![1.0, 2.0, 3.0, 4.0],
                lambda: 0.5,
                complete_shifted_defect: vec![1.0, 2.0, 4.0, 8.0],
                free_ids: vec![3, 1, 0, 2],
                factor_order: vec![2, 0, 3, 1],
            },
        )
        .expect("expected-red canonical retained shifted inverse");
        assert_eq!(
            observed.t_bits,
            [
                0xc004_0000_0000_0000,
                0xc012_0000_0000_0000,
                0x401e_0000_0000_0000,
                0x3ff8_0000_0000_0000
            ]
        );
        assert_eq!(
            observed.denominator_bits,
            [
                0x3ff8_0000_0000_0000,
                0x4012_0000_0000_0000,
                0x4023_0000_0000_0000,
                0x4030_8000_0000_0000
            ]
        );
        assert_eq!(
            observed.z_bits,
            [
                0xbffa_aaaa_aaaa_aaab,
                0xbff0_0000_0000_0000,
                0x3fe9_435e_50d7_9436,
                0x3fb7_45d1_745d_1746
            ]
        );
        assert_eq!(
            observed.delta_free_slot_bits,
            [
                0x3fec_949e_6af9_0f1c,
                0xbfe5_d7fc_bbd0_a352,
                0xbf90_54ec_cf69_bf70,
                0xbffc_605b_752e_231d
            ]
        );
        assert_eq!(
            observed.delta_coordinate_bits,
            [
                0xbf90_54ec_cf69_bf70,
                0xbfe5_d7fc_bbd0_a352,
                0xbffc_605b_752e_231d,
                0x3fec_949e_6af9_0f1c
            ]
        );
        assert_ne!(
            observed.delta_free_slot_bits,
            [
                0x3fec_949e_6af9_0f1d,
                0xbfe5_d7fc_bbd0_a352,
                0xbf90_54ec_cf69_bf74,
                0xbffc_605b_752e_231e
            ]
        );
        assert_eq!(observed.factor_order, vec![2, 0, 3, 1]);
        assert_eq!(observed.free_ids, vec![3, 1, 0, 2]);
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_retained_operands_norms_and_bvls02_join() {
        let (capture, certificate) = shifted_face();
        let observed = retained_positive_result(&capture);
        let p0 = &certificate["points"]["original"];
        let p1 = &certificate["points"]["ordinary_correction_1"];
        let p2 = &certificate["points"]["compensated_correction_2"];
        assert_eq!(observed.factorizations_added, 0);
        assert_eq!(observed.factor_applications, 2);
        assert_eq!(observed.corrections, 2);
        assert_eq!(observed.lower_mask_p0, observed.lower_mask_p1);
        assert_eq!(observed.lower_mask_p1, observed.lower_mask_p2);
        assert_eq!(observed.lower_mask_p2, observed.lower_mask_exit);
        assert_eq!(observed.upper_mask_p0, observed.upper_mask_p1);
        assert_eq!(observed.upper_mask_p1, observed.upper_mask_p2);
        assert_eq!(observed.upper_mask_p2, observed.upper_mask_exit);
        assert_eq!(observed.active_coordinate, 11);
        assert_eq!(observed.p0_bits[11], observed.p1_bits[11]);
        assert_eq!(observed.p1_bits[11], observed.p2_bits[11]);
        assert_eq!(
            observed.p0_full_norm2_bits,
            Some(bit(&p0["full_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.p0_full_norm_bits,
            Some(bit(&p0["full_norm_ordered"]))
        );
        assert_eq!(
            observed.p0_reduced_norm2_bits,
            Some(bit(&p0["reduced_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.p0_reduced_norm_bits,
            Some(bit(&p0["reduced_norm_ordered"]))
        );
        assert_eq!(
            observed.p1_full_norm2_bits,
            Some(bit(&p1["full_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.p1_full_norm_bits,
            Some(bit(&p1["full_norm_ordered"]))
        );
        assert_eq!(
            observed.p1_reduced_norm2_bits,
            Some(bit(&p1["reduced_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.p1_reduced_norm_bits,
            Some(bit(&p1["reduced_norm_ordered"]))
        );
        assert_eq!(
            observed.p2_full_norm2_bits,
            Some(bit(&p2["full_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.p2_full_norm_bits,
            Some(bit(&p2["full_norm_ordered"]))
        );
        assert_eq!(
            observed.p2_reduced_norm2_bits,
            Some(bit(&p2["reduced_norm2_ordered_bits"]))
        );
        assert_eq!(
            observed.p2_reduced_norm_bits,
            Some(bit(&p2["reduced_norm_ordered"]))
        );
        assert_eq!(observed.original_radius_bits, bit(&p2["original_radius"]));
        assert_eq!(
            observed.remaining_radius_bits,
            Some(bit(&p2["remaining_face_radius"]))
        );
        assert_eq!(
            observed.radius_gap_bits,
            Some(bit(&p2["radius_gap_ordered"]))
        );
        assert_eq!(
            observed.radius_tolerance_bits,
            Some(bit(&p2["radius_tolerance"]))
        );
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_negative_zero_uses_unchanged_bvls03_seam() {
        let capture = bvls03_zero_face();
        let positive_zero = m1_trust_region_bvls03_signed_zero_for_test(&capture, 0.0)
            .expect("expected-red unchanged BVLS-03 positive-zero seam");
        let negative_zero = m1_trust_region_bvls03_signed_zero_for_test(&capture, -0.0)
            .expect("expected-red unchanged BVLS-03 negative-zero seam");
        assert_eq!(negative_zero.lambda_bits, (-0.0_f64).to_bits());
        assert_eq!(negative_zero.result_bits, positive_zero.result_bits);
        assert_eq!(negative_zero.bvls03_entries, positive_zero.bvls03_entries);
        assert!(negative_zero.bvls03_entries > 0);
        assert_eq!(negative_zero.bvls04_entries, 0);
        assert_eq!(
            negative_zero.factor_application_count,
            positive_zero.factor_application_count
        );
        assert_eq!(
            negative_zero.first_residual_operations,
            positive_zero.first_residual_operations
        );
        assert_eq!(
            negative_zero.second_dot2_operations,
            positive_zero.second_dot2_operations
        );
        assert_eq!(negative_zero.full_work, positive_zero.full_work);
    }

    fn assert_bvls04_poison_matrix_refusal(
        refusal: &M1TrustRegionBvls04PoisonObservation,
        poison: M1TrustRegionBvls04Poison,
        reason: M1TrustRegionRefinementReason,
        stage: M1TrustRegionRefinementGuardStage,
        position: M1TrustRegionCorrectionPosition,
        certificate: &Value,
    ) {
        assert_eq!(refusal.metadata.reason, reason);
        assert_eq!(refusal.metadata.guard_stage, stage);
        assert_eq!(refusal.metadata.correction_position, Some(position));
        assert_eq!(refusal.bvls02_fallback_calls, 0);
        assert_eq!(
            refusal.live_state_bits_before,
            refusal.live_state_bits_after
        );
        #[cfg(feature = "m1-trust-region-physical-stage")]
        assert_eq!(refusal.owner_snapshot_before, refusal.owner_snapshot_after);
        assert!(refusal.mutated_operand_bits.is_some());
        assert_eq!(refusal.reached_stage, stage);
        match poison {
            M1TrustRegionBvls04Poison::DenominatorOverflow(index)
            | M1TrustRegionBvls04Poison::DivisionNonfinite(index) => {
                assert_eq!(refusal.mutation_site, Some(index));
            }
            M1TrustRegionBvls04Poison::CoordinateUpdateNonfinite(coordinate) => {
                assert_eq!(refusal.mutation_site, Some(coordinate));
                assert_eq!(
                    refusal.metadata.coordinate.map(usize::from),
                    Some(coordinate)
                );
            }
            M1TrustRegionBvls04Poison::DefensiveInverseOutputInvariant(index) => {
                assert_eq!(refusal.mutation_site, Some(index));
                assert_eq!(refusal.mutated_operand_bits, Some(f64::INFINITY.to_bits()));
                assert_eq!(
                    refusal.output_check_event,
                    Some((index, f64::NEG_INFINITY.to_bits()))
                );
            }
            M1TrustRegionBvls04Poison::P1ReducedRadiusExcess => {
                assert_eq!(
                    refusal.metadata.reduced_face_radius.to_bits(),
                    0.5_f64.to_bits()
                );
                assert_eq!(
                    refusal.metadata.original_trust_radius.to_bits(),
                    1.0_f64.to_bits()
                );
                assert_eq!(refusal.mutated_operand_bits, Some(0.5_f64.to_bits()));
                assert_eq!(
                    refusal.p1_reduced_norm_bits,
                    Some(bit(
                        &certificate["points"]["ordinary_correction_1"]["reduced_norm_ordered"]
                    ))
                );
            }
            M1TrustRegionBvls04Poison::P2ReducedRadiusExcess => {
                assert_eq!(
                    refusal.metadata.reduced_face_radius.to_bits(),
                    0.5_f64.to_bits()
                );
                assert_eq!(
                    refusal.metadata.original_trust_radius.to_bits(),
                    1.0_f64.to_bits()
                );
                assert_eq!(refusal.mutated_operand_bits, Some(0.5_f64.to_bits()));
                assert_eq!(
                    refusal.p2_reduced_norm_bits,
                    Some(bit(
                        &certificate["points"]["compensated_correction_2"]["reduced_norm_ordered"]
                    ))
                );
            }
            _ => {}
        }
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_reachable_operand_guard_matrix() {
        let (_, certificate) = shifted_face();
        for (poison, reason, stage, position) in [
            (
                M1TrustRegionBvls04Poison::p1_lower_box(13),
                M1TrustRegionRefinementReason::ScratchBox,
                M1TrustRegionRefinementGuardStage::ScratchBoxLower,
                M1TrustRegionCorrectionPosition::First,
            ),
            (
                M1TrustRegionBvls04Poison::p1_upper_box(13),
                M1TrustRegionRefinementReason::ScratchBox,
                M1TrustRegionRefinementGuardStage::ScratchBoxUpper,
                M1TrustRegionCorrectionPosition::First,
            ),
            (
                M1TrustRegionBvls04Poison::p1_full_norm_nonfinite(13),
                M1TrustRegionRefinementReason::NonfiniteOperand,
                M1TrustRegionRefinementGuardStage::ScratchFullRadius,
                M1TrustRegionCorrectionPosition::First,
            ),
            (
                M1TrustRegionBvls04Poison::p1_reduced_radius_excess(),
                M1TrustRegionRefinementReason::ScratchRadius,
                M1TrustRegionRefinementGuardStage::ScratchReducedRadius,
                M1TrustRegionCorrectionPosition::First,
            ),
            (
                M1TrustRegionBvls04Poison::p2_full_norm_nonfinite(13),
                M1TrustRegionRefinementReason::NonfiniteOperand,
                M1TrustRegionRefinementGuardStage::FinalFullRadius,
                M1TrustRegionCorrectionPosition::Second,
            ),
            (
                M1TrustRegionBvls04Poison::p2_reduced_radius_excess(),
                M1TrustRegionRefinementReason::FinalRadius,
                M1TrustRegionRefinementGuardStage::FinalReducedRadius,
                M1TrustRegionCorrectionPosition::Second,
            ),
            (
                M1TrustRegionBvls04Poison::p2_closeness_gap(13),
                M1TrustRegionRefinementReason::FinalRadius,
                M1TrustRegionRefinementGuardStage::FinalRadiusCloseness,
                M1TrustRegionCorrectionPosition::Second,
            ),
            (
                M1TrustRegionBvls04Poison::denominator_overflow(13),
                M1TrustRegionRefinementReason::FactorOutput,
                M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                M1TrustRegionCorrectionPosition::First,
            ),
            (
                M1TrustRegionBvls04Poison::division_nonfinite(13),
                M1TrustRegionRefinementReason::FactorOutput,
                M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                M1TrustRegionCorrectionPosition::First,
            ),
            (
                M1TrustRegionBvls04Poison::defensive_inverse_output_invariant(13),
                M1TrustRegionRefinementReason::FactorOutput,
                M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                M1TrustRegionCorrectionPosition::First,
            ),
            (
                M1TrustRegionBvls04Poison::coordinate_update_nonfinite(13),
                M1TrustRegionRefinementReason::CoordinateUpdate,
                M1TrustRegionRefinementGuardStage::CoordinateUpdate,
                M1TrustRegionCorrectionPosition::First,
            ),
        ] {
            let refusal = m1_trust_region_bvls04_poison_for_test(poison)
                .expect_err("expected-red mutation must reach the named shared operation");
            assert_bvls04_poison_matrix_refusal(
                &refusal,
                poison,
                reason,
                stage,
                position,
                &certificate,
            );
        }
    }

    #[test]
    fn m1_trust_region_refinement_bvls04_expected_red_independent_scalar_guard_and_exact_bound() {
        for (reservation, owner) in [
            (
                M1TrustRegionBvls04Reservation {
                    scalar_capacity: 70_275,
                    guard_capacity: 211_236,
                    free_count: 21,
                },
                M1TrustRegionBvls04ReservationOwner::Scalar,
            ),
            (
                M1TrustRegionBvls04Reservation {
                    scalar_capacity: 70_276,
                    guard_capacity: 211_235,
                    free_count: 21,
                },
                M1TrustRegionBvls04ReservationOwner::Guard,
            ),
        ] {
            let refusal = m1_trust_region_bvls04_work_boundary_for_test(reservation)
                .expect_err("expected-red owning cap refusal");
            assert_eq!(refusal.attempted_delta, 1);
            assert_eq!(refusal.denied_delta, 1);
            assert_eq!(refusal.required_scalar, 70_276);
            assert_eq!(refusal.required_guards, 211_236);
            assert_eq!(refusal.denial_owner, owner);
            assert_eq!(refusal.total_scalar_delta, refusal.eligibility_scalar_delta);
            assert_eq!(refusal.total_guard_delta, refusal.eligibility_guard_delta);
            assert_eq!(refusal.factor_delta, 0);
            assert_eq!(refusal.dot2_delta, 0);
            assert_eq!(refusal.inverse_delta, 0);
            assert_eq!(refusal.update_delta, 0);
            #[cfg(feature = "m1-trust-region-physical-stage")]
            {
                assert_eq!(refusal.phase_delta, 0);
                assert_eq!(refusal.evaluator_delta, 0);
                assert_eq!(refusal.hydraulic_delta, 0);
                assert_eq!(refusal.materialization_delta, 0);
            }
            assert_eq!(refusal.owner_snapshot_before, refusal.owner_snapshot_after);
            #[cfg(feature = "m1-trust-region-physical-stage")]
            {
                assert_eq!(refusal.budget_before, refusal.budget_after);
                assert_eq!(refusal.scratch_global_before, refusal.scratch_global_after);
            }
            assert!(refusal.reservation_is_conservative);
        }
        let admitted =
            m1_trust_region_bvls04_work_boundary_for_test(M1TrustRegionBvls04Reservation {
                scalar_capacity: 70_276,
                guard_capacity: 211_236,
                free_count: 21,
            })
            .expect("expected-red exact bound must enter BVLS-04 category");
        assert_eq!(admitted.attempted_delta, 1);
        assert_eq!(admitted.denied_delta, 0);
        assert_eq!(admitted.required_scalar, 70_276);
        assert_eq!(admitted.required_guards, 211_236);
        assert_eq!(admitted.category_entry_delta, 1);
        assert_eq!(admitted.factor_delta, 0);
        assert_eq!(admitted.dot2_delta, 0);
    }
}

#[cfg(test)]
pub(crate) fn refinement_frozen_weighted_merit_entries_for_test() -> u32 {
    REFINEMENT_FROZEN_WEIGHTED_MERIT_ENTRIES.with(Cell::get)
}

// This is a deliberately opt-in, test-only flight recorder for one retained
// physical refusal.  It copies operands already produced by Stage 1; every
// write is best-effort so observation can never replace the typed result.
#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotCapture {
    pub(crate) base: [f64; 21],
    pub(crate) raw_residual: [f64; 21],
    pub(crate) raw_jacobian: [[f64; 21]; 21],
    pub(crate) normalizers: [f64; 21],
    pub(crate) scales: [f64; 21],
    pub(crate) lower: [f64; 21],
    pub(crate) upper: [f64; 21],
    pub(crate) weighted_residual: Vec<f64>,
    pub(crate) weighted_matrix: Vec<Vec<f64>>,
    pub(crate) initial_radius: f64,
    pub(crate) completed_subproblems: Vec<M1FacePivotSubproblemSummary>,
    pub(crate) operations: Vec<M1FacePivotCaptureOperation>,
    pub(crate) accepted_installs: Vec<M1FacePivotAcceptedInstall>,
    pub(crate) post_update_admissions: Vec<M1FacePivotPostUpdateAdmission>,
    pub(crate) lifecycle: Vec<&'static str>,
    pub(crate) bvls05_lifecycle: Vec<M1FacePivotBvls05Capture>,
    /// Copied at first rank refusal; the runtime did not sort this spectrum.
    pub(crate) rank_refusal_factor: Option<M1FacePivotFactorCapture>,
    pub(crate) refusal: Option<M1FacePivotCaptureRefusal>,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotBvls05Capture {
    pub(crate) provenance: Option<super::M1TrustRegionBvls05TestProvenance>,
    pub(crate) held: [bool; 21],
    pub(crate) reused: bool,
    pub(crate) free_ids: Vec<usize>,
    pub(crate) work: super::M1TrustRegionWorkObservation,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotSubproblemSummary {
    pub(crate) entered_factorizations: u8,
    pub(crate) completed_pivots: u8,
    pub(crate) completed_sweeps: u8,
    pub(crate) refused: bool,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotPostUpdateAdmission {
    pub(crate) previous_coordinates: [f64; 21],
    pub(crate) previous_raw: [f64; 21],
    pub(crate) previous_normalizers: [f64; 21],
    pub(crate) previous_wet_temperature_k: [Option<f64>; 2],
    pub(crate) previous_hydraulics: M1TrustRegionCurrentHydraulics,
    pub(crate) previous_beta: [f64; 4],
    pub(crate) previous_ci_pa: [f64; 4],
    pub(crate) current_coordinates: [f64; 21],
    pub(crate) current_raw: [f64; 21],
    pub(crate) current_normalizers: [f64; 21],
    pub(crate) current_wet_temperature_k: [Option<f64>; 2],
    pub(crate) current_hydraulics: M1TrustRegionCurrentHydraulics,
    pub(crate) current_beta: [f64; 4],
    pub(crate) current_ci_pa: [f64; 4],
    pub(crate) current_max: f64,
    pub(crate) governed_temperature: Option<f64>,
    pub(crate) governed_humidity: Option<f64>,
    pub(crate) governed_hydraulic: Option<f64>,
    pub(crate) governed_beta: Option<f64>,
    pub(crate) governed_ci: Option<[f64; 4]>,
    pub(crate) governed_pass: Option<bool>,
    pub(crate) governed_thresholds: [f64; 4],
    pub(crate) admitted: bool,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotAcceptedInstall {
    pub(crate) base_before: [f64; 21],
    pub(crate) raw_before: [f64; 21],
    pub(crate) normalizers_before: [f64; 21],
    pub(crate) base_after: [f64; 21],
    pub(crate) raw_after: [f64; 21],
    pub(crate) normalizers_after: [f64; 21],
    pub(crate) scaled_step: [f64; 21],
    pub(crate) rho: f64,
    pub(crate) predicted_reduction: f64,
    pub(crate) actual_reduction: f64,
    pub(crate) dynamic_max_before: f64,
    pub(crate) dynamic_max_after: f64,
    pub(crate) radius_before: f64,
    pub(crate) radius_after: f64,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotCaptureOperation {
    pub(crate) action: &'static str,
    pub(crate) p_before: [f64; 21],
    pub(crate) p_candidate: [f64; 21],
    pub(crate) conceptual_p_after: [f64; 21],
    pub(crate) scratch_p_at_refusal: Option<[f64; 21]>,
    pub(crate) applied: bool,
    pub(crate) lower_before: [bool; 21],
    pub(crate) upper_before: [bool; 21],
    pub(crate) free_before: [bool; 21],
    pub(crate) lower_after: [bool; 21],
    pub(crate) upper_after: [bool; 21],
    pub(crate) free_after: [bool; 21],
    pub(crate) free_ids: Vec<usize>,
    pub(crate) radius: f64,
    pub(crate) lambda: Option<f64>,
    pub(crate) weighted_residual: Option<[f64; 21]>,
    pub(crate) weighted_matrix: Option<Vec<Vec<f64>>>,
    pub(crate) crossing_theta: Option<f64>,
    pub(crate) selected_coordinate: Option<usize>,
    pub(crate) selected_lower: Option<bool>,
    pub(crate) residual: Option<[f64; 21]>,
    pub(crate) g: Option<[f64; 21]>,
    pub(crate) lambda_times_p: Option<[f64; 21]>,
    pub(crate) h: Option<[f64; 21]>,
    pub(crate) optimality: Option<super::M1TrustRegionOptimalityObservation>,
    pub(crate) entered_factorizations: u8,
    pub(crate) completed_pivots: u8,
    pub(crate) completed_sweeps: u8,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotCaptureRefusal {
    pub(crate) stage: &'static str,
    pub(crate) kind: M1TrustRegionRefusalKind,
    pub(crate) optimality_reason: Option<&'static str>,
    pub(crate) optimality_coordinate: Option<usize>,
    pub(crate) radius: Option<f64>,
    pub(crate) lambda: Option<f64>,
    pub(crate) free_ids: Vec<usize>,
    pub(crate) p: [f64; 21],
    pub(crate) lower: [bool; 21],
    pub(crate) upper: [bool; 21],
    pub(crate) free: [bool; 21],
    pub(crate) scaled_lower: Option<[f64; 21]>,
    pub(crate) scaled_upper: Option<[f64; 21]>,
    pub(crate) entered_factorizations: u8,
    pub(crate) completed_pivots: u8,
    pub(crate) completed_sweeps: u8,
    pub(crate) optimality: Option<super::M1TrustRegionOptimalityObservation>,
    pub(crate) lambda_trace: Option<M1FacePivotLambdaTraceCapture>,
    pub(crate) factor: Option<M1FacePivotFactorCapture>,
}

// This is a copied, reached-state snapshot.  It never calls the lambda or
// factor routines, so a flight record cannot add numerical work to the solve.
#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotLambdaTraceCapture {
    pub(crate) initial_bracket: [f64; 2],
    pub(crate) bracket: [f64; 2],
    pub(crate) bracket_evaluations: Vec<(f64, f64)>,
    pub(crate) bisection_evaluations: Vec<(f64, f64)>,
    pub(crate) lambda: f64,
    pub(crate) natural_step: Vec<f64>,
    pub(crate) pre_hook_step: Vec<f64>,
    pub(crate) post_hook_step: Vec<f64>,
    pub(crate) norm: f64,
    pub(crate) gap: f64,
    pub(crate) tolerance: f64,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1FacePivotFactorCapture {
    pub(crate) same_invocation_identity: Option<usize>,
    pub(crate) same_invocation_identity_available: bool,
    pub(crate) a: Vec<Vec<f64>>,
    pub(crate) b: Vec<Vec<f64>>,
    pub(crate) v: Vec<Vec<f64>>,
    pub(crate) sigma: Vec<f64>,
    pub(crate) rank_max: Option<f64>,
    pub(crate) rank_threshold: Option<f64>,
    pub(crate) order: Vec<usize>,
    pub(crate) order_computed: bool,
    pub(crate) visits: Vec<super::M1TrustRegionJacobiPair>,
    pub(crate) rotations: usize,
    pub(crate) sweeps: u8,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
thread_local! {
    static FACE_PIVOT_CAPTURE: RefCell<Option<M1FacePivotCapture>> = const { RefCell::new(None) };
    static FACE_PIVOT_CAPTURE_ENABLED: Cell<bool> = const { Cell::new(false) };
}

// BVLS-03 control-only recorder.  Values enter it only after the shared
// controller has produced them; it is deliberately not an input to either
// factorization or the refinement decision.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum M1TrustRegionBvls04ReservationOwner {
    Scalar,
    Guard,
    Admitted,
}

#[cfg(test)]
#[derive(Clone, Debug, Default)]
struct RefinementObservationTrace {
    // Copied at the actual refinement boundary.  These metadata never enter
    // face preparation, factorization, masks, or arithmetic.
    face_free_ids: Option<Vec<usize>>,
    factor_order: Option<Vec<usize>>,
    factor_a: Option<Vec<Vec<f64>>>,
    factor_v: Option<Vec<Vec<f64>>>,
    factor_sigma: Option<Vec<f64>>,
    weighted_residual: Option<Vec<f64>>,
    weighted_matrix: Option<Vec<Vec<f64>>>,
    scaled_lower_bits: Option<[u64; 21]>,
    scaled_upper_bits: Option<[u64; 21]>,
    lambda_bits: Option<u64>,
    reduced_face_radius_bits: Option<u64>,
    free_mask: Option<[bool; 21]>,
    held_mask: Option<[bool; 21]>,
    live_state_entry: Option<[u64; 21]>,
    live_state_exit: Option<[u64; 21]>,
    p0: Option<[f64; 21]>,
    residual0: Option<[f64; 21]>,
    h0: Option<Vec<f64>>,
    p0_full_norm2: Option<f64>,
    p0_full_norm: Option<f64>,
    p0_reduced_norm2: Option<f64>,
    p0_reduced_norm: Option<f64>,
    delta0: Option<Vec<f64>>,
    p1: Option<[f64; 21]>,
    p1_full_norm2: Option<f64>,
    p1_full_norm: Option<f64>,
    p1_reduced_norm2: Option<f64>,
    p1_reduced_norm: Option<f64>,
    residual1: Option<[f64; 21]>,
    h1: Option<Vec<f64>>,
    inverse_t: Option<Vec<f64>>,
    inverse_denominator: Option<Vec<f64>>,
    inverse_z: Option<Vec<f64>>,
    delta1: Option<Vec<f64>>,
    p2: Option<[f64; 21]>,
    p2_full_norm2: Option<f64>,
    p2_full_norm: Option<f64>,
    p2_reduced_norm2: Option<f64>,
    p2_reduced_norm: Option<f64>,
    remaining_radius: Option<f64>,
    radius_gap: Option<f64>,
    radius_tolerance: Option<f64>,
    factor_identity: Option<usize>,
    factor_application_identities: Vec<usize>,
    factor_application_snapshots: Vec<RefinementFactorApplicationSnapshot>,
    factor_applications: u8,
    // This is an operation-site marker, not a deduction from optional copied
    // fields.  It makes a missing copy distinguishable from a terminal that
    // occurred before that copy.
    factor_output_copy_boundary: Option<(u8, RefinementFactorOutputCopyBoundary)>,
    eligibility_scalar_operations: Option<u64>,
    eligibility_guard_events: Option<u64>,
    reservation_denial_owner: Option<M1TrustRegionBvls04ReservationOwner>,
    lower_mask_p0: Option<[bool; 21]>,
    upper_mask_p0: Option<[bool; 21]>,
    lower_mask_p1: Option<[bool; 21]>,
    upper_mask_p1: Option<[bool; 21]>,
    lower_mask_p2: Option<[bool; 21]>,
    upper_mask_p2: Option<[bool; 21]>,
    lower_mask_exit: Option<[bool; 21]>,
    upper_mask_exit: Option<[bool; 21]>,
    // Snapshot after the actual refinement call returns (including refusal).
    // This is copied from the controller ledger, never reconstructed.
    work: Option<super::M1TrustRegionWorkObservation>,
    terminal_refusal: Option<Box<super::M1TrustRegionSubproblemRefusal>>,
    ordered_norms: Vec<RefinementOrderedNormTrace>,
    partial_ordered_norms: Vec<RefinementPartialOrderedNormTrace>,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementFactorApplicationSnapshot {
    ordinal: u8,
    identity: usize,
    h_bits: Option<Vec<u64>>,
    inverse_t_bits: Option<Vec<u64>>,
    inverse_denominator_bits: Option<Vec<u64>>,
    inverse_z_bits: Option<Vec<u64>>,
    delta_bits: Option<Vec<u64>>,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
enum RefinementFactorOutputCopyBoundary {
    BeforeInverse,
    AfterInverse,
    AfterDelta,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementPartialOrderedNormTrace {
    role: &'static str,
    coordinate_ids: Vec<usize>,
    value_bits: Vec<u64>,
    square_bits: Vec<u64>,
    running_sum_bits: Vec<u64>,
    terminal_operation: &'static str,
    sqrt_bits: Option<u64>,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementOrderedNormTrace {
    role: &'static str,
    coordinate_ids: Vec<usize>,
    value_bits: Vec<u64>,
    square_bits: Vec<u64>,
    running_sum_bits: Vec<u64>,
    norm2_bits: u64,
    norm_bits: u64,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
enum RefinementRawCandidateMutation {
    P0Subnormal {
        coordinate: usize,
    },
    FinalBox {
        coordinate: usize,
        scaled_value: f64,
    },
    ScratchRadius {
        coordinate: usize,
        scaled_value: f64,
        radius: f64,
    },
    ActiveValue {
        coordinate: usize,
        scaled_value: f64,
    },
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, PartialEq)]
enum M1TrustRegionBvls04Poison {
    DenominatorOverflow(usize),
    DivisionNonfinite(usize),
    DefensiveInverseOutputInvariant(usize),
    CoordinateUpdateNonfinite(usize),
    P1LowerBox(usize),
    P1UpperBox(usize),
    P1FullNormNonfinite(usize),
    P1ReducedRadiusExcess,
    P2FullNormNonfinite(usize),
    P2ReducedRadiusExcess,
    P2ClosenessGap(usize),
}
#[cfg(test)]
impl M1TrustRegionBvls04Poison {
    fn denominator_overflow(i: usize) -> Self {
        Self::DenominatorOverflow(i)
    }
    fn division_nonfinite(i: usize) -> Self {
        Self::DivisionNonfinite(i)
    }
    fn defensive_inverse_output_invariant(i: usize) -> Self {
        Self::DefensiveInverseOutputInvariant(i)
    }
    fn coordinate_update_nonfinite(i: usize) -> Self {
        Self::CoordinateUpdateNonfinite(i)
    }
    fn p1_lower_box(i: usize) -> Self {
        Self::P1LowerBox(i)
    }
    fn p1_upper_box(i: usize) -> Self {
        Self::P1UpperBox(i)
    }
    fn p1_full_norm_nonfinite(i: usize) -> Self {
        Self::P1FullNormNonfinite(i)
    }
    fn p1_reduced_radius_excess() -> Self {
        Self::P1ReducedRadiusExcess
    }
    fn p2_full_norm_nonfinite(i: usize) -> Self {
        Self::P2FullNormNonfinite(i)
    }
    fn p2_reduced_radius_excess() -> Self {
        Self::P2ReducedRadiusExcess
    }
    fn p2_closeness_gap(i: usize) -> Self {
        Self::P2ClosenessGap(i)
    }
}

#[cfg(test)]
thread_local! {
    static REFINEMENT_OBSERVATION: RefCell<Option<RefinementObservationTrace>> = const { RefCell::new(None) };
    static REFINEMENT_NORM_ROLE: RefCell<Option<&'static str>> = const { RefCell::new(None) };
    static REFUSAL_CAPTURE_ARMED: Cell<bool> = const { Cell::new(false) };
    static REFUSAL_CAPTURE_TRACE: RefCell<Option<M1RefusalCaptureTrace>> = const { RefCell::new(None) };
    static REFINEMENT_RAW_MUTATION: RefCell<Option<RefinementRawCandidateMutation>> = const { RefCell::new(None) };
    static BVLS04_POISON: RefCell<Option<M1TrustRegionBvls04Poison>> = const { RefCell::new(None) };
    static BVLS04_POISON_CONSUMED: RefCell<Option<(u64, M1TrustRegionRefinementGuardStage)>> = const { RefCell::new(None) };
    static BVLS04_OUTPUT_CHECK_EVENT: RefCell<Option<(usize, u64)>> = const { RefCell::new(None) };
    static BVLS04_POISON_SITE: Cell<Option<usize>> = const { Cell::new(None) };
    static BVLS04_KKT_ENTRIES: Cell<u32> = const { Cell::new(0) };
}
#[cfg(test)]
struct RefinementNormRoleScope(Option<&'static str>);
#[cfg(test)]
impl RefinementNormRoleScope {
    fn begin(role: &'static str) -> Self {
        let active = REFINEMENT_OBSERVATION.with(|slot| slot.borrow().is_some());
        Self(REFINEMENT_NORM_ROLE.with(|slot| slot.replace(active.then_some(role))))
    }
}
#[cfg(test)]
impl Drop for RefinementNormRoleScope {
    fn drop(&mut self) {
        REFINEMENT_NORM_ROLE.with(|slot| *slot.borrow_mut() = self.0.take());
    }
}

/// Test-only, default-off copy observer for one actual Stage-1 subproblem.
/// It records values already evaluated by the solver and is consumed only by
/// the detached refusal-capture entry after the controller returns.
#[cfg(test)]
#[derive(Debug)]
pub(crate) struct M1RefusalCaptureTrace {
    input_raw_residual_bits: [u64; 21],
    input_raw_jacobian_bits: [[u64; 21]; 21],
    input_normalizer_bits: [u64; 21],
    input_scale_bits: [u64; 21],
    input_lower_bits: [u64; 21],
    input_upper_bits: [u64; 21],
    input_base_bits: [u64; 21],
    initial_radius_bits: u64,
    refinement: RefinementObservationTrace,
}

#[cfg(test)]
pub(crate) fn arm_refusal_capture_for_test() {
    REFUSAL_CAPTURE_ARMED.with(|armed| armed.set(true));
    REFUSAL_CAPTURE_TRACE.with(|trace| *trace.borrow_mut() = None);
}

#[cfg(test)]
pub(crate) fn take_refusal_capture_for_test() -> Option<M1RefusalCaptureTrace> {
    REFUSAL_CAPTURE_TRACE.with(|trace| trace.borrow_mut().take())
}

#[cfg(test)]
fn refusal_capture_work_json(
    work: Option<super::M1TrustRegionWorkObservation>,
) -> serde_json::Value {
    serde_json::to_value(work.map(|work| serde_json::json!({
        "stage1_calls": work.stage1_calls, "entered_svd_factorizations": work.entered_svd_factorizations,
        "completed_face_pivots": work.completed_face_pivots, "total_jacobi_sweeps": work.total_jacobi_sweeps,
        "refinement_scalar_operations": work.refinement_scalar_operations, "refinement_guard_events": work.refinement_guard_events,
        "refinement_attempted_entries": work.refinement_attempted_entries, "refinement_denied_entries": work.refinement_denied_entries,
        "bvls04_positive_entries": work.bvls04_positive_entries, "bvls04_factor_applications": work.bvls04_factor_applications,
        "bvls04_dot2_residual_rows": work.bvls04_dot2_residual_rows, "bvls04_dot2_free_gradients": work.bvls04_dot2_free_gradients,
        "bvls04_ordered_norms": work.bvls04_ordered_norms, "first_residual_operations": work.first_residual_operations,
        "second_dot2_operations": work.second_dot2_operations, "factor_application_operations": work.factor_application_operations,
        "coordinate_update_operations": work.coordinate_update_operations, "whole_kkt_operations": work.whole_kkt_operations,
        "whole_kkt_guard_events": work.whole_kkt_guard_events, "upward_enclosure_operations": work.upward_enclosure_operations,
        "upward_enclosure_guard_events": work.upward_enclosure_guard_events, "bvls05_role_joins_attempted": work.bvls05_role_joins_attempted,
        "bvls05_role_joins_completed": work.bvls05_role_joins_completed, "bvls05_column_entry_tests_attempted": work.bvls05_column_entry_tests_attempted,
        "bvls05_column_entry_tests_completed": work.bvls05_column_entry_tests_completed, "bvls05_mask_joins_attempted": work.bvls05_mask_joins_attempted,
        "bvls05_mask_joins_completed": work.bvls05_mask_joins_completed, "bvls05_held_base_copies_attempted": work.bvls05_held_base_copies_attempted,
        "bvls05_held_base_copies_completed": work.bvls05_held_base_copies_completed,
    }))).expect("capture work ledger")
}

#[cfg(test)]
fn add_capture_masks(
    map: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
) {
    for (name, value) in [
        (
            "free_mask",
            serde_json::to_value(trace.free_mask).expect("capture field"),
        ),
        (
            "held_mask",
            serde_json::to_value(trace.held_mask).expect("capture field"),
        ),
        (
            "lower_mask_p0",
            serde_json::to_value(trace.lower_mask_p0).expect("capture field"),
        ),
        (
            "upper_mask_p0",
            serde_json::to_value(trace.upper_mask_p0).expect("capture field"),
        ),
        (
            "lower_mask_p1",
            serde_json::to_value(trace.lower_mask_p1).expect("capture field"),
        ),
        (
            "upper_mask_p1",
            serde_json::to_value(trace.upper_mask_p1).expect("capture field"),
        ),
        (
            "lower_mask_p2",
            serde_json::to_value(trace.lower_mask_p2).expect("capture field"),
        ),
        (
            "upper_mask_p2",
            serde_json::to_value(trace.upper_mask_p2).expect("capture field"),
        ),
        (
            "lower_mask_exit",
            serde_json::to_value(trace.lower_mask_exit).expect("capture field"),
        ),
        (
            "upper_mask_exit",
            serde_json::to_value(trace.upper_mask_exit).expect("capture field"),
        ),
    ] {
        map.insert(name.into(), value);
    }
}

#[cfg(test)]
fn refusal_capture_input_json(value: &M1RefusalCaptureTrace) -> serde_json::Value {
    serde_json::json!({
        "coordinate_ids": (0usize..21).collect::<Vec<_>>(), "row_ids": (0usize..21).collect::<Vec<_>>(),
        "raw_residual_bits": value.input_raw_residual_bits, "raw_jacobian_bits": value.input_raw_jacobian_bits,
        "normalizer_bits": value.input_normalizer_bits, "scale_bits": value.input_scale_bits,
        "lower_bits": value.input_lower_bits, "upper_bits": value.input_upper_bits,
        "base_bits": value.input_base_bits, "initial_radius_bits": value.initial_radius_bits,
    })
}

#[cfg(test)]
fn refusal_capture_terminal_json(
    refusal: Option<Box<super::M1TrustRegionSubproblemRefusal>>,
) -> serde_json::Value {
    serde_json::to_value(refusal.map(|refusal| {
        let refinement = refusal.refinement.as_ref().map(|metadata| serde_json::json!({
            "reason": format!("{:?}", metadata.reason), "correction_position": metadata.correction_position.map(|value| format!("{value:?}")), "guard_stage": format!("{:?}", metadata.guard_stage),
            "row": metadata.row, "term": metadata.term, "coordinate": metadata.coordinate, "lower_active": metadata.lower_active, "upper_active": metadata.upper_active, "free": metadata.free,
            "lambda_bits": metadata.lambda.to_bits(), "original_trust_radius_bits": metadata.original_trust_radius.to_bits(), "reduced_face_radius_bits": metadata.reduced_face_radius.to_bits(), "scratch_box_feasible": metadata.scratch_box_feasible,
        }));
        serde_json::json!({
            "kind": format!("{:?}", refusal.kind), "optimality_reason": refusal.optimality_reason, "optimality_coordinate": refusal.optimality_coordinate,
            "optimality_radius_bits": refusal.optimality_radius.map(|value| value.to_bits()), "optimality_lambda_bits": refusal.optimality_lambda.map(|value| value.to_bits()),
            "attempted_subproblems": refusal.attempted_subproblems, "completed_jacobi_sweeps": refusal.completed_jacobi_sweeps, "completed_face_pivots": refusal.completed_face_pivots,
            "entered_svd_factorizations": refusal.entered_svd_factorizations, "raw_residual_max_bits": refusal.raw_residual_max.to_bits(), "refinement": refinement,
        })
    })).expect("capture terminal refusal")
}

#[cfg(test)]
fn add_refusal_capture_factor_fields(
    map: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
) {
    macro_rules! put {
        ($name:literal, $v:expr) => {
            map.insert(
                $name.into(),
                serde_json::to_value($v).expect("capture field"),
            );
        };
    }
    let bits = |values: Vec<f64>| values.into_iter().map(f64::to_bits).collect::<Vec<_>>();
    let matrix_bits = |values: Vec<Vec<f64>>| {
        values
            .into_iter()
            .map(|row| row.into_iter().map(f64::to_bits).collect::<Vec<_>>())
            .collect::<Vec<_>>()
    };
    put!("free_ids", trace.face_free_ids.clone());
    put!("factor_order", trace.factor_order.clone());
    put!("factor_a_bits", trace.factor_a.clone().map(matrix_bits));
    put!("factor_v_bits", trace.factor_v.clone().map(matrix_bits));
    put!("factor_sigma_bits", trace.factor_sigma.clone().map(bits));
    put!(
        "weighted_residual_bits",
        trace.weighted_residual.clone().map(bits)
    );
    put!(
        "weighted_matrix_bits",
        trace.weighted_matrix.clone().map(matrix_bits)
    );
    put!("scaled_lower_bits", trace.scaled_lower_bits);
    put!("scaled_upper_bits", trace.scaled_upper_bits);
    put!("lambda_bits", trace.lambda_bits);
    put!("reduced_face_radius_bits", trace.reduced_face_radius_bits);
    put!("live_state_entry_bits", trace.live_state_entry);
    put!("live_state_exit_bits", trace.live_state_exit);
    put!("factor_identity", trace.factor_identity);
    put!(
        "factor_application_identities",
        trace.factor_application_identities.clone()
    );
    put!(
        "factor_application_snapshots",
        trace
            .factor_application_snapshots
            .iter()
            .map(|snapshot| serde_json::json!({
                "ordinal": snapshot.ordinal,
                "identity": snapshot.identity,
                "h_bits": snapshot.h_bits,
                "inverse_t_bits": snapshot.inverse_t_bits,
                "inverse_denominator_bits": snapshot.inverse_denominator_bits,
                "inverse_z_bits": snapshot.inverse_z_bits,
                "delta_bits": snapshot.delta_bits,
            }))
            .collect::<Vec<_>>()
    );
    put!(
        "factor_output_copy_boundary",
        trace
            .factor_output_copy_boundary
            .map(|(ordinal, boundary)| {
                serde_json::json!({
                    "ordinal": ordinal,
                    "boundary": match boundary {
                        RefinementFactorOutputCopyBoundary::BeforeInverse => "before_inverse",
                        RefinementFactorOutputCopyBoundary::AfterInverse => "after_inverse",
                        RefinementFactorOutputCopyBoundary::AfterDelta => "after_delta",
                    },
                })
            })
    );
    put!("factor_applications", trace.factor_applications);
    put!(
        "eligibility_scalar_operations",
        trace.eligibility_scalar_operations
    );
    put!("eligibility_guard_events", trace.eligibility_guard_events);
    put!(
        "reservation_denial_owner",
        trace.reservation_denial_owner.map(|v| format!("{v:?}"))
    );
}

#[cfg(test)]
fn add_refusal_capture_first_norm_fields(
    map: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
) {
    macro_rules! put {
        ($name:literal, $v:expr) => {
            map.insert(
                $name.into(),
                serde_json::to_value($v).expect("capture field"),
            );
        };
    }
    let bits = |values: Vec<f64>| values.into_iter().map(f64::to_bits).collect::<Vec<_>>();
    put!("p0_bits", trace.p0.map(|v| v.map(f64::to_bits)));
    put!(
        "residual0_bits",
        trace.residual0.map(|v| v.map(f64::to_bits))
    );
    put!("h0_bits", trace.h0.clone().map(bits));
    put!("p0_full_norm2_bits", trace.p0_full_norm2.map(f64::to_bits));
    put!("p0_full_norm_bits", trace.p0_full_norm.map(f64::to_bits));
    put!(
        "p0_reduced_norm2_bits",
        trace.p0_reduced_norm2.map(f64::to_bits)
    );
    put!(
        "p0_reduced_norm_bits",
        trace.p0_reduced_norm.map(f64::to_bits)
    );
    put!("delta0_bits", trace.delta0.clone().map(bits));
    put!("p1_bits", trace.p1.map(|v| v.map(f64::to_bits)));
    put!("p1_full_norm2_bits", trace.p1_full_norm2.map(f64::to_bits));
    put!("p1_full_norm_bits", trace.p1_full_norm.map(f64::to_bits));
    put!(
        "p1_reduced_norm2_bits",
        trace.p1_reduced_norm2.map(f64::to_bits)
    );
    put!(
        "p1_reduced_norm_bits",
        trace.p1_reduced_norm.map(f64::to_bits)
    );
}

#[cfg(test)]
fn add_refusal_capture_second_norm_fields(
    map: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
) {
    macro_rules! put {
        ($name:literal, $v:expr) => {
            map.insert(
                $name.into(),
                serde_json::to_value($v).expect("capture field"),
            );
        };
    }
    let bits = |values: Vec<f64>| values.into_iter().map(f64::to_bits).collect::<Vec<_>>();
    put!(
        "residual1_bits",
        trace.residual1.map(|v| v.map(f64::to_bits))
    );
    put!("h1_bits", trace.h1.clone().map(bits));
    put!("inverse_t_bits", trace.inverse_t.clone().map(bits));
    put!(
        "inverse_denominator_bits",
        trace.inverse_denominator.clone().map(bits)
    );
    put!("inverse_z_bits", trace.inverse_z.clone().map(bits));
    put!("delta1_bits", trace.delta1.clone().map(bits));
    put!("p2_bits", trace.p2.map(|v| v.map(f64::to_bits)));
    put!("p2_full_norm2_bits", trace.p2_full_norm2.map(f64::to_bits));
    put!("p2_full_norm_bits", trace.p2_full_norm.map(f64::to_bits));
    put!(
        "p2_reduced_norm2_bits",
        trace.p2_reduced_norm2.map(f64::to_bits)
    );
    put!(
        "p2_reduced_norm_bits",
        trace.p2_reduced_norm.map(f64::to_bits)
    );
    put!(
        "remaining_radius_bits",
        trace.remaining_radius.map(f64::to_bits)
    );
    put!("radius_gap_bits", trace.radius_gap.map(f64::to_bits));
    put!(
        "radius_tolerance_bits",
        trace.radius_tolerance.map(f64::to_bits)
    );
    put!(
        "partial_ordered_norms",
        trace
            .partial_ordered_norms
            .iter()
            .map(|norm| serde_json::json!({
                "role": norm.role,
                "coordinate_ids": norm.coordinate_ids,
                "value_bits": norm.value_bits,
                "square_bits": norm.square_bits,
                "running_sum_bits": norm.running_sum_bits,
                "terminal_operation": norm.terminal_operation,
                "sqrt_bits": norm.sqrt_bits,
            }))
            .collect::<Vec<_>>()
    );
}

#[cfg(test)]
fn refusal_capture_completeness_json(
    trace: &RefinementObservationTrace,
    witness: &str,
) -> serde_json::Value {
    let terminal = trace
        .terminal_refusal
        .as_deref()
        .and_then(|refusal| refusal.refinement.as_ref());
    let terminal_refusal = trace.terminal_refusal.as_deref();
    let terminal_metadata_complete = terminal_refusal.is_some_and(|refusal| {
        matches!(
            refusal.kind,
            super::M1TrustRegionRefusalKind::TrustRegionRefinementIndeterminate
        )
    }) && terminal.is_some();
    let refinement_complete = terminal_metadata_complete
        && refinement_capture_terminal_complete(trace, terminal.map(Box::as_ref));
    let expected_terminal_match = trace
        .terminal_refusal
        .as_ref()
        .and_then(|refusal| refusal.refinement.as_ref())
        .is_some_and(|metadata| match witness {
            "W1" => {
                matches!(
                    metadata.correction_position,
                    Some(super::M1TrustRegionCorrectionPosition::First)
                ) && matches!(
                    metadata.guard_stage,
                    super::M1TrustRegionRefinementGuardStage::ScratchFullRadius
                )
            }
            "W2" => {
                matches!(
                    metadata.correction_position,
                    Some(super::M1TrustRegionCorrectionPosition::Second)
                ) && matches!(
                    metadata.guard_stage,
                    super::M1TrustRegionRefinementGuardStage::FinalBoxLower
                ) && metadata.coordinate == Some(5)
            }
            _ => false,
        });
    let actual_stage = terminal.map(|metadata| format!("{:?}", metadata.guard_stage));
    let reached_prefix_complete = refinement_complete;
    serde_json::json!({
        "reached_prefix_complete": reached_prefix_complete, "witness": witness,
        "actual_terminal_stage": actual_stage,
        "actual_terminal_kind": terminal_refusal.map(|refusal| format!("{:?}", refusal.kind)),
        "actual_terminal_reason": terminal.map(|metadata| format!("{:?}", metadata.reason)),
        "actual_correction_position": terminal.and_then(|metadata| metadata.correction_position).map(|value| format!("{value:?}")),
        "expected_terminal_match": expected_terminal_match,
        "actual_branch_complete": refinement_complete,
        "missing_capture_is_incomplete": !reached_prefix_complete,
    })
}

#[cfg(test)]
fn refinement_capture_common_complete(trace: &RefinementObservationTrace) -> bool {
    let Some(free_ids) = trace.face_free_ids.as_ref() else {
        return false;
    };
    let Some(order) = trace.factor_order.as_ref() else {
        return false;
    };
    let Some(a) = trace.factor_a.as_ref() else {
        return false;
    };
    let Some(v) = trace.factor_v.as_ref() else {
        return false;
    };
    let Some(sigma) = trace.factor_sigma.as_ref() else {
        return false;
    };
    trace
        .weighted_residual
        .as_ref()
        .is_some_and(|values| values.len() == 21)
        && trace
            .weighted_matrix
            .as_ref()
            .is_some_and(|matrix| matrix.len() == 21 && matrix.iter().all(|row| row.len() == 21))
        && trace.scaled_lower_bits.is_some()
        && trace.scaled_upper_bits.is_some()
        && trace.free_mask.is_some()
        && trace.held_mask.is_some()
        && trace.live_state_entry.is_some()
        && trace.live_state_exit.is_some()
        && trace.factor_applications as usize == trace.factor_application_identities.len()
        && !free_ids.is_empty()
        && free_ids.iter().all(|id| *id < 21)
        && free_ids
            .iter()
            .enumerate()
            .all(|(index, id)| !free_ids[..index].contains(id))
        && order.len() == free_ids.len()
        && order.iter().all(|id| *id < free_ids.len())
        && order
            .iter()
            .enumerate()
            .all(|(index, id)| !order[..index].contains(id))
        && a.len() == 21
        && v.len() == free_ids.len()
        && sigma.len() == free_ids.len()
        && a.iter().all(|row| row.len() == free_ids.len())
        && v.iter().all(|row| row.len() == free_ids.len())
        && trace.work.is_some()
}

/// Select required copies from the typed terminal guard, never from a witness's
/// historical outcome.  A stage whose copy boundary was not reached is reported
/// incomplete; it is not relabelled as the expected refusal.
#[cfg(test)]
fn refinement_capture_lineage_complete(
    trace: &RefinementObservationTrace,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) -> bool {
    let Some(held) = trace.held_mask else {
        return false;
    };
    // `metadata.free` is the raw state mask.  The actual face is its ordered
    // free-and-not-held subset; held is therefore a subset, not its complement.
    if !held
        .iter()
        .zip(metadata.free)
        .all(|(held, free)| !*held || free)
    {
        return false;
    }
    let expected_free_ids: Vec<_> = metadata
        .free
        .iter()
        .zip(held)
        .enumerate()
        .filter_map(|(index, (free, held))| (*free && !held).then_some(index))
        .collect();
    trace.free_mask == Some(metadata.free)
        && trace.face_free_ids.as_deref() == Some(expected_free_ids.as_slice())
        && trace.live_state_entry == trace.live_state_exit
        && trace.lower_mask_p0 == Some(metadata.lower_active)
        && trace.upper_mask_p0 == Some(metadata.upper_active)
        && trace
            .lower_mask_p1
            .is_none_or(|mask| mask == metadata.lower_active)
        && trace
            .upper_mask_p1
            .is_none_or(|mask| mask == metadata.upper_active)
        && trace
            .lower_mask_p2
            .is_none_or(|mask| mask == metadata.lower_active)
        && trace
            .upper_mask_p2
            .is_none_or(|mask| mask == metadata.upper_active)
        && trace.lower_mask_exit == Some(metadata.lower_active)
        && trace.upper_mask_exit == Some(metadata.upper_active)
}

#[cfg(test)]
fn refinement_capture_final_radius_operands_join(
    trace: &RefinementObservationTrace,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    require_closeness: bool,
) -> bool {
    let Some(radius) = trace.remaining_radius else {
        return false;
    };
    if radius.to_bits() != metadata.reduced_face_radius.to_bits() {
        return false;
    }
    let Some(free_norm) = trace.p2_reduced_norm else {
        return false;
    };
    // This is the source comparison at FinalReducedRadius.  The captured
    // operands alone do not establish that this terminal was actually taken.
    if !require_closeness {
        return free_norm > radius;
    }
    // Closeness is reached only after the reduced-radius rejection was not
    // taken, so its copied free norm must be on the other side of that guard.
    if free_norm > radius {
        return false;
    }
    let Some(gap) = trace.radius_gap else {
        return false;
    };
    let Some(tolerance) = trace.radius_tolerance else {
        return false;
    };
    let expected_gap = radius - free_norm;
    let a = 2_f64.powi(-40) * radius;
    let b = 64.0 * f64::EPSILON * radius.max(1.0);
    gap.to_bits() == expected_gap.to_bits()
        && tolerance.to_bits() == a.max(b).to_bits()
        // FinalRadiusCloseness is the rejecting side of the exact source guard.
        && gap > tolerance
}

#[cfg(test)]
fn refinement_capture_factor_snapshot_complete(
    trace: &RefinementObservationTrace,
    ordinal: u8,
    require_inverse: bool,
) -> bool {
    let Some(snapshot) = trace
        .factor_application_snapshots
        .get(usize::from(ordinal - 1))
    else {
        return false;
    };
    let h = match ordinal {
        1 => trace.h0.as_ref(),
        2 => trace.h1.as_ref(),
        _ => return false,
    };
    let delta = match ordinal {
        1 => trace.delta0.as_ref(),
        2 => trace.delta1.as_ref(),
        _ => return false,
    };
    let bits = |values: &[f64]| {
        values
            .iter()
            .map(|value| value.to_bits())
            .collect::<Vec<_>>()
    };
    trace.factor_application_snapshots.len() == usize::from(trace.factor_applications)
        && trace
            .factor_application_snapshots
            .iter()
            .enumerate()
            .all(|(index, entry)| {
                Some(entry.ordinal) == u8::try_from(index + 1).ok()
                    && trace.factor_application_identities.get(index) == Some(&entry.identity)
            })
        && snapshot.h_bits == h.map(|values| bits(values))
        && snapshot.delta_bits == delta.map(|values| bits(values))
        && if require_inverse {
            let copied = snapshot.inverse_t_bits.is_some()
                && snapshot.inverse_denominator_bits.is_some()
                && snapshot.inverse_z_bits.is_some();
            copied
                && if ordinal == trace.factor_applications {
                    snapshot.inverse_t_bits.as_ref().is_some_and(|values| {
                        trace
                            .inverse_t
                            .as_ref()
                            .is_some_and(|legacy| *values == bits(legacy))
                    }) && snapshot
                        .inverse_denominator_bits
                        .as_ref()
                        .is_some_and(|values| {
                            trace
                                .inverse_denominator
                                .as_ref()
                                .is_some_and(|legacy| *values == bits(legacy))
                        })
                        && snapshot.inverse_z_bits.as_ref().is_some_and(|values| {
                            trace
                                .inverse_z
                                .as_ref()
                                .is_some_and(|legacy| *values == bits(legacy))
                        })
                } else {
                    true
                }
        } else {
            snapshot.h_bits.is_none()
                && snapshot.inverse_t_bits.is_none()
                && snapshot.inverse_denominator_bits.is_none()
                && snapshot.inverse_z_bits.is_none()
        }
}

#[cfg(test)]
fn refinement_capture_legacy_inverse_matches(
    trace: &RefinementObservationTrace,
    snapshot: &RefinementFactorApplicationSnapshot,
) -> bool {
    let bits = |values: &[f64]| {
        values
            .iter()
            .map(|value| value.to_bits())
            .collect::<Vec<_>>()
    };
    snapshot.inverse_t_bits.as_ref().is_some_and(|values| {
        trace
            .inverse_t
            .as_ref()
            .is_some_and(|legacy| *values == bits(legacy))
    }) && snapshot
        .inverse_denominator_bits
        .as_ref()
        .is_some_and(|values| {
            trace
                .inverse_denominator
                .as_ref()
                .is_some_and(|legacy| *values == bits(legacy))
        })
        && snapshot.inverse_z_bits.as_ref().is_some_and(|values| {
            trace
                .inverse_z
                .as_ref()
                .is_some_and(|legacy| *values == bits(legacy))
        })
}

#[cfg(test)]
fn refinement_capture_legacy_inverse_absent(trace: &RefinementObservationTrace) -> bool {
    trace.inverse_t.is_none() && trace.inverse_denominator.is_none() && trace.inverse_z.is_none()
}

#[cfg(test)]
fn refinement_capture_factor_output_boundary_valid(
    positive_lambda: bool,
    boundary: RefinementFactorOutputCopyBoundary,
) -> bool {
    matches!(
        (positive_lambda, boundary),
        (
            true | false,
            RefinementFactorOutputCopyBoundary::BeforeInverse
        ) | (true, RefinementFactorOutputCopyBoundary::AfterInverse)
            | (false, RefinementFactorOutputCopyBoundary::AfterDelta)
    )
}

#[cfg(test)]
type RefinementCaptureFactorOutputInputs<'a> = (
    bool,
    &'a RefinementFactorApplicationSnapshot,
    Option<&'a Vec<f64>>,
    Option<&'a Vec<f64>>,
);

#[cfg(test)]
fn refinement_capture_factor_output_inputs<'a>(
    trace: &'a RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    ordinal: u8,
) -> Option<RefinementCaptureFactorOutputInputs<'a>> {
    if resolved.factor_output_ordinal != Some(ordinal) {
        return None;
    }
    let residual = match ordinal {
        1 => trace.residual0.is_some(),
        2 => trace.residual1.is_some(),
        _ => return None,
    };
    let h = match ordinal {
        1 => trace.h0.as_ref(),
        2 => trace.h1.as_ref(),
        _ => return None,
    };
    let delta = match ordinal {
        1 => trace.delta0.as_ref(),
        2 => trace.delta1.as_ref(),
        _ => return None,
    };
    if trace.factor_applications == 0 {
        return None;
    }
    if trace.factor_applications != ordinal
        || trace.factor_application_identities.len() != usize::from(ordinal)
        || trace.factor_application_snapshots.len() != usize::from(ordinal)
    {
        return None;
    }
    let snapshot = trace
        .factor_application_snapshots
        .get(usize::from(ordinal - 1))?;
    match resolved.copy.marker {
        Some((marked_ordinal, boundary))
            if marked_ordinal == ordinal
                && trace.factor_output_copy_boundary == Some((marked_ordinal, boundary)) =>
        {
            if resolved.copy.boundary_valid {
                Some((residual, snapshot, h, delta))
            } else {
                None
            }
        }
        _ => None,
    }
}

#[cfg(test)]
fn refinement_capture_factor_output_inverse_continuity(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    ordinal: u8,
    positive_lambda: bool,
    inverse_state: RefinementCaptureTerminalFieldState,
) -> bool {
    if !positive_lambda {
        return refinement_capture_legacy_inverse_absent(trace);
    }
    if inverse_state != RefinementCaptureTerminalFieldState::Interrupted {
        return true;
    }
    if ordinal == 1 {
        refinement_capture_legacy_inverse_absent(trace)
    } else {
        resolved.copy.generic_inverse_owner == Some(1)
            && trace
                .factor_application_snapshots
                .first()
                .is_some_and(|first| refinement_capture_legacy_inverse_matches(trace, first))
    }
}

#[cfg(test)]
fn refinement_capture_factor_output_prefix(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    ordinal: u8,
    positive_lambda: bool,
) -> bool {
    let Some((residual, snapshot, h, delta)) =
        refinement_capture_factor_output_inputs(trace, resolved, ordinal)
    else {
        return false;
    };
    let bits = |values: &[f64]| {
        values
            .iter()
            .map(|value| value.to_bits())
            .collect::<Vec<_>>()
    };
    let inverse_state = resolved.field_state(if ordinal == 1 {
        "factor_application_snapshot_1_inverse_t_bits"
    } else {
        "factor_application_snapshot_2_inverse_t_bits"
    });
    let delta_state = resolved.field_state(if ordinal == 1 {
        "factor_application_snapshot_1_delta_bits"
    } else {
        "factor_application_snapshot_2_delta_bits"
    });
    let inverse_present = snapshot.inverse_t_bits.is_some()
        && snapshot.inverse_denominator_bits.is_some()
        && snapshot.inverse_z_bits.is_some();
    let inverse_content = match inverse_state {
        RefinementCaptureTerminalFieldState::Required => {
            inverse_present && refinement_capture_legacy_inverse_matches(trace, snapshot)
        }
        RefinementCaptureTerminalFieldState::Interrupted
        | RefinementCaptureTerminalFieldState::Absent
        | RefinementCaptureTerminalFieldState::InapplicableZeroLambda => {
            !inverse_present
                && snapshot.inverse_t_bits.is_none()
                && snapshot.inverse_denominator_bits.is_none()
                && snapshot.inverse_z_bits.is_none()
        }
        RefinementCaptureTerminalFieldState::MissingTerminalMetadata => false,
    };
    let delta_content = match delta_state {
        RefinementCaptureTerminalFieldState::Required => {
            delta.is_some_and(|values| snapshot.delta_bits == Some(bits(values)))
        }
        RefinementCaptureTerminalFieldState::Interrupted
        | RefinementCaptureTerminalFieldState::Absent
        | RefinementCaptureTerminalFieldState::InapplicableZeroLambda => {
            delta.is_none() && snapshot.delta_bits.is_none()
        }
        RefinementCaptureTerminalFieldState::MissingTerminalMetadata => false,
    };
    let h_content = if positive_lambda {
        residual && h.is_some() && snapshot.h_bits == h.map(|values| bits(values))
    } else {
        snapshot.h_bits.is_none()
    };
    snapshot.ordinal == ordinal
        && trace.factor_identity == Some(snapshot.identity)
        && trace
            .factor_application_identities
            .iter()
            .zip(&trace.factor_application_snapshots)
            .enumerate()
            .all(|(index, (identity, entry))| {
                Some(entry.ordinal) == u8::try_from(index + 1).ok()
                    && *identity == snapshot.identity
                    && entry.identity == snapshot.identity
            })
        && h_content
        && inverse_content
        && delta_content
        && refinement_capture_factor_output_inverse_continuity(
            trace,
            resolved,
            ordinal,
            positive_lambda,
            inverse_state,
        )
}

#[cfg(test)]
fn refinement_capture_applications_complete(trace: &RefinementObservationTrace, count: u8) -> bool {
    trace.factor_applications == count
        && trace.factor_application_identities.len() == usize::from(count)
        && trace.factor_application_snapshots.len() == usize::from(count)
        && if count == 0 {
            // The identity copy precedes the first application.  Count zero
            // therefore constrains application lineage and legacy inverse,
            // while the resolved terminal separately owns whether identity was
            // reached at this prefix.
            refinement_capture_legacy_inverse_absent(trace)
        } else {
            trace.factor_identity.is_some_and(|identity| {
                trace
                    .factor_application_identities
                    .iter()
                    .zip(&trace.factor_application_snapshots)
                    .enumerate()
                    .all(|(index, (seen, snapshot))| {
                        Some(snapshot.ordinal) == u8::try_from(index + 1).ok()
                            && *seen == identity
                            && snapshot.identity == identity
                    })
            })
        }
}

#[cfg(test)]
fn refinement_capture_no_p1(trace: &RefinementObservationTrace, p1_present: bool) -> bool {
    !p1_present
        && trace.p1.is_none()
        && trace.lower_mask_p1.is_none()
        && trace.upper_mask_p1.is_none()
        && trace.p1_full_norm.is_none()
        && trace.p1_full_norm2.is_none()
        && trace.p1_reduced_norm.is_none()
        && trace.p1_reduced_norm2.is_none()
        && trace.residual1.is_none()
        && trace.h1.is_none()
        && trace.delta1.is_none()
        && trace.p2.is_none()
        && trace.lower_mask_p2.is_none()
        && trace.upper_mask_p2.is_none()
        && trace.p2_full_norm.is_none()
        && trace.p2_full_norm2.is_none()
        && trace.p2_reduced_norm.is_none()
        && trace.p2_reduced_norm2.is_none()
        && trace.remaining_radius.is_none()
        && trace.radius_gap.is_none()
        && trace.radius_tolerance.is_none()
        && !trace
            .ordered_norms
            .iter()
            .any(|norm| norm.role.starts_with("p1_") || norm.role.starts_with("p2_"))
        && !trace
            .partial_ordered_norms
            .iter()
            .any(|norm| norm.role.starts_with("p1_") || norm.role.starts_with("p2_"))
}

/// Exact absence set before the factor identity is copied.  This is deliberately
/// separate from a zero application count: post-factor refusals can also have
/// no completed application, but must retain the copied identity/prefix.
#[cfg(test)]
fn refinement_capture_pre_factor_absence(trace: &RefinementObservationTrace) -> bool {
    refinement_capture_applications_complete(trace, 0)
        && trace.residual0.is_none()
        && trace.h0.is_none()
        && trace.delta0.is_none()
        && refinement_capture_no_p1(trace, false)
}

#[cfg(test)]
fn refinement_capture_first_residual_or_h0_prefix(
    trace: &RefinementObservationTrace,
    residual0_required: bool,
    positive_lambda: bool,
) -> bool {
    // The identity is copied between p0 and residual0.  A first-residual
    // refusal has no residual; an H0 refusal has the residual but cannot have
    // started the application.  These are distinct actual prefixes.
    trace.factor_identity.is_some()
        && trace.factor_applications == 0
        && trace.factor_application_identities.is_empty()
        && trace.factor_application_snapshots.is_empty()
        && refinement_capture_legacy_inverse_absent(trace)
        && trace.h0.is_none()
        && trace.delta0.is_none()
        && if positive_lambda && residual0_required {
            trace.residual0.is_some()
        } else {
            trace.residual0.is_none()
        }
        && if positive_lambda {
            true
        } else {
            trace.h0.is_none()
        }
}

#[cfg(test)]
fn refinement_capture_second_residual_or_h1_prefix(
    trace: &RefinementObservationTrace,
    residual1_required: bool,
    positive_lambda: bool,
) -> bool {
    // First application is complete.  The second identity is the same copied
    // factor and exists before residual1; neither a residual1 nor H1 refusal
    // has a second snapshot.
    refinement_capture_applications_complete(trace, 1)
        && trace.factor_identity.is_some()
        && trace.h1.is_none()
        && trace.delta1.is_none()
        && if positive_lambda && residual1_required {
            trace.residual1.is_some()
        } else {
            trace.residual1.is_none()
        }
        && if positive_lambda {
            true
        } else {
            trace.h1.is_none()
        }
}

#[cfg(test)]
fn refinement_capture_no_p2(trace: &RefinementObservationTrace, p2_present: bool) -> bool {
    !p2_present
        && trace.p2.is_none()
        && trace.lower_mask_p2.is_none()
        && trace.upper_mask_p2.is_none()
        && trace.p2_full_norm.is_none()
        && trace.p2_full_norm2.is_none()
        && trace.p2_reduced_norm.is_none()
        && trace.p2_reduced_norm2.is_none()
        && trace.remaining_radius.is_none()
        && trace.radius_gap.is_none()
        && trace.radius_tolerance.is_none()
        && !trace
            .ordered_norms
            .iter()
            .any(|norm| norm.role.starts_with("p2_"))
        && !trace
            .partial_ordered_norms
            .iter()
            .any(|norm| norm.role.starts_with("p2_"))
}

#[cfg(test)]
fn refinement_capture_metadata_radii_are_admitted(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) -> bool {
    // BVLS-03 fixes a positive finite initial trust radius.  Observation
    // metadata represents that already-admitted trajectory, so it must not
    // manufacture a terminal from a zero/nonfinite original radius.
    metadata.original_trust_radius.is_finite()
        && metadata.original_trust_radius > 0.0
        && metadata.reduced_face_radius.is_finite()
        && metadata.reduced_face_radius > 0.0
}

#[cfg(test)]
fn refinement_capture_selected_first_product_or_accumulation(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    positive: bool,
    dot: bool,
    row: bool,
    scratch: Option<bool>,
) -> bool {
    use super::{
        M1TrustRegionRefinementGuardStage as Stage, M1TrustRegionRefinementReason as Reason,
    };
    if positive && resolved.family.h_locator == Some(RefinementCaptureHLocator::H0) {
        refinement_capture_h_locator_free_id_join(trace, metadata, resolved.family.h_locator)
            && (matches!(
                metadata.reason,
                Reason::NonfiniteOperand | Reason::SubnormalIntermediate
            ) || (metadata.guard_stage == Stage::PrimaryProduct
                && metadata.reason == Reason::UnderflowToZero
                && metadata.row.is_some()))
    } else {
        dot && row
            && scratch.is_none()
            && refinement_capture_residual_locator(metadata)
            && (metadata.guard_stage != Stage::Accumulation
                || !matches!(metadata.reason, Reason::UnderflowToZero))
    }
}

#[cfg(test)]
fn refinement_capture_selected_terminal_kind_resolved(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
) -> bool {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    if !refinement_capture_metadata_radii_are_admitted(metadata) {
        return false;
    }
    let positive = metadata.lambda.is_finite() && metadata.lambda > 0.0;
    let zero = metadata.lambda == 0.0;
    let dot = matches!(
        metadata.reason,
        Reason::NonfiniteOperand | Reason::SubnormalIntermediate | Reason::UnderflowToZero
    );
    let row = metadata.row.is_some_and(|value| value < 21);
    let coordinate = metadata.coordinate.is_some_and(|value| value < 21);
    let no_locator =
        metadata.row.is_none() && metadata.term.is_none() && metadata.coordinate.is_none();
    let scratch = metadata.scratch_box_feasible;
    match (metadata.correction_position, metadata.guard_stage) {
        (None, Stage::ActiveFinite) => {
            positive
                && metadata.reason == Reason::SubnormalIntermediate
                && coordinate
                && metadata.row.is_none()
                && metadata.term.is_none()
                && scratch.is_none()
        }
        (None, Stage::P0FullRadius) => {
            positive && no_locator && (metadata.reason == Reason::FinalRadius || dot)
        }
        (None, Stage::OrderedNorm) => {
            zero && metadata.reason == Reason::NonfiniteOperand && no_locator
        }
        (Some(Position::First), Stage::ResidualSourceTerm) => {
            metadata.reason == Reason::SubnormalIntermediate
                && row
                && scratch.is_none()
                && refinement_capture_residual_locator(metadata)
        }
        (Some(Position::First), Stage::PrimaryProduct | Stage::Accumulation) => {
            refinement_capture_selected_first_product_or_accumulation(
                metadata, trace, resolved, positive, dot, row, scratch,
            )
        }
        (Some(Position::First), Stage::FactorApplicationOutput) => {
            metadata.reason == Reason::FactorOutput && no_locator && scratch.is_none()
        }
        (Some(Position::First), Stage::CoordinateUpdate) => {
            metadata.reason == Reason::CoordinateUpdate
                && coordinate
                && metadata.row.is_none()
                && metadata.term.is_none()
                && scratch.is_none()
        }
        (Some(Position::First), Stage::ScratchBoxLower | Stage::ScratchBoxUpper) => {
            positive
                && metadata.reason == Reason::ScratchBox
                && coordinate
                && metadata.row.is_none()
                && metadata.term.is_none()
                && scratch == Some(false)
        }
        (Some(Position::First), Stage::ScratchFullRadius) => {
            positive
                && no_locator
                && scratch == Some(true)
                && (dot || metadata.reason == Reason::ScratchRadius)
        }
        (Some(Position::First), Stage::ScratchReducedRadius) => {
            positive
                && no_locator
                && scratch == Some(true)
                && metadata.reason == Reason::ScratchRadius
        }
        (Some(Position::First), Stage::OrderedNorm) => {
            zero && metadata.reason == Reason::NonfiniteOperand && no_locator && scratch.is_some()
        }
        (Some(Position::First), Stage::RadiusComparison) => {
            zero && metadata.reason == Reason::ScratchRadius && no_locator && scratch.is_some()
        }
        (Some(Position::Second), _) => {
            refinement_capture_selected_second_terminal(metadata, trace, resolved)
        }
        _ => false,
    }
}

#[cfg(test)]
fn refinement_capture_selected_second_terminal(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
) -> bool {
    use super::{
        M1TrustRegionRefinementGuardStage as Stage, M1TrustRegionRefinementReason as Reason,
    };
    let positive = metadata.lambda.is_finite() && metadata.lambda > 0.0;
    let zero = metadata.lambda == 0.0;
    let row = metadata.row.is_some_and(|value| value < 21);
    let coordinate = metadata.coordinate.is_some_and(|value| value < 21);
    let no_locator =
        metadata.row.is_none() && metadata.term.is_none() && metadata.coordinate.is_none();
    let scratch = metadata.scratch_box_feasible;
    match metadata.guard_stage {
        Stage::PrimaryProduct
        | Stage::SplitterProduct
        | Stage::SplitOutput
        | Stage::EftRemainder
        | Stage::TwoSumResult
        | Stage::TwoSumRemainder
        | Stage::Accumulation => {
            if positive && resolved.family.h_locator == Some(RefinementCaptureHLocator::H1) {
                refinement_capture_h_locator_free_id_join(
                    trace,
                    metadata,
                    resolved.family.h_locator,
                ) && refinement_capture_second_dot_reason(metadata.guard_stage, metadata.reason)
            } else {
                row && (positive && scratch == Some(true) || zero && scratch.is_some())
                    && refinement_capture_residual_locator(metadata)
                    && refinement_capture_second_dot_reason(metadata.guard_stage, metadata.reason)
            }
        }
        Stage::FactorApplicationOutput => {
            metadata.reason == Reason::FactorOutput
                && no_locator
                && (positive && scratch == Some(true) || zero && scratch.is_some())
        }
        Stage::CoordinateUpdate => {
            metadata.reason == Reason::CoordinateUpdate
                && coordinate
                && metadata.row.is_none()
                && metadata.term.is_none()
                && (positive && scratch == Some(true) || zero && scratch.is_some())
        }
        Stage::FinalBoxLower | Stage::FinalBoxUpper => {
            metadata.reason == Reason::FinalBox
                && coordinate
                && metadata.row.is_none()
                && metadata.term.is_none()
                && (positive && scratch == Some(true) || zero && scratch.is_some())
        }
        Stage::FinalFullRadius => {
            positive
                && no_locator
                && scratch == Some(true)
                && matches!(
                    metadata.reason,
                    Reason::NonfiniteOperand
                        | Reason::SubnormalIntermediate
                        | Reason::UnderflowToZero
                        | Reason::FinalRadius
                )
        }
        Stage::FinalReducedRadius | Stage::FinalRadiusCloseness => {
            positive
                && no_locator
                && scratch == Some(true)
                && metadata.reason == Reason::FinalRadius
        }
        Stage::OrderedNorm | Stage::RadiusComparison => {
            zero && no_locator && scratch.is_some() && metadata.reason == Reason::FinalRadius
        }
        _ => false,
    }
}

#[cfg(test)]
fn refinement_capture_selected_terminal_kind(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    trace: &RefinementObservationTrace,
) -> bool {
    let resolved =
        refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary);
    refinement_capture_selected_terminal_kind_resolved(metadata, trace, &resolved)
}

#[cfg(test)]
fn refinement_capture_residual_locator(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) -> bool {
    match (metadata.term, metadata.coordinate) {
        (None, None) => matches!(
            metadata.guard_stage,
            super::M1TrustRegionRefinementGuardStage::Accumulation
        ),
        (Some(0), None) => {
            matches!(
                metadata.guard_stage,
                super::M1TrustRegionRefinementGuardStage::ResidualSourceTerm
                    | super::M1TrustRegionRefinementGuardStage::SplitterProduct
                    | super::M1TrustRegionRefinementGuardStage::SplitOutput
                    | super::M1TrustRegionRefinementGuardStage::EftRemainder
                    | super::M1TrustRegionRefinementGuardStage::Accumulation
            ) && !(metadata.guard_stage == super::M1TrustRegionRefinementGuardStage::Accumulation
                && metadata.correction_position
                    == Some(super::M1TrustRegionCorrectionPosition::Second))
        }
        (Some(term @ 1..=21), Some(coordinate)) => coordinate == term - 1,
        _ => false,
    }
}

#[cfg(test)]
fn refinement_capture_second_dot_reason(
    stage: super::M1TrustRegionRefinementGuardStage,
    reason: super::M1TrustRegionRefinementReason,
) -> bool {
    use super::{
        M1TrustRegionRefinementGuardStage as Stage, M1TrustRegionRefinementReason as Reason,
    };
    match stage {
        Stage::PrimaryProduct => matches!(
            reason,
            Reason::NonfiniteOperand | Reason::SubnormalIntermediate | Reason::UnderflowToZero
        ),
        Stage::SplitterProduct => matches!(
            reason,
            Reason::SplitterOverflow | Reason::SubnormalIntermediate | Reason::UnderflowToZero
        ),
        Stage::SplitOutput => matches!(
            reason,
            Reason::NonfiniteOperand | Reason::SubnormalIntermediate
        ),
        Stage::EftRemainder => matches!(
            reason,
            Reason::NonfiniteOperand | Reason::SubnormalIntermediate | Reason::UnderflowToZero
        ),
        Stage::TwoSumResult | Stage::TwoSumRemainder => matches!(
            reason,
            Reason::NonfiniteOperand | Reason::SubnormalIntermediate
        ),
        Stage::Accumulation => matches!(
            reason,
            Reason::NonfiniteOperand | Reason::SubnormalIntermediate
        ),
        _ => false,
    }
}

#[cfg(test)]
fn refinement_capture_h0_locator(metadata: &super::M1TrustRegionRefinementFailureMetadata) -> bool {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
    };

    let Some(slot) = metadata.term else {
        return false;
    };
    metadata.correction_position == Some(Position::First)
        && metadata.lambda.is_finite()
        && metadata.lambda > 0.0
        && matches!(metadata.guard_stage, Stage::PrimaryProduct | Stage::Accumulation)
        && slot < 21
        // Residual guards use coordinate = term - 1. H0 observes the ordered
        // free ID at a slot, whose coordinate can never be below that slot.
        && metadata
            .coordinate
            .is_some_and(|coordinate| coordinate >= slot && coordinate < 21)
        && metadata.row.is_none_or(|row| row < 21)
        && metadata.scratch_box_feasible.is_none()
}

#[cfg(test)]
fn refinement_capture_h1_locator(metadata: &super::M1TrustRegionRefinementFailureMetadata) -> bool {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
    };

    if metadata.correction_position != Some(Position::Second)
        || !metadata.lambda.is_finite()
        || metadata.lambda <= 0.0
        || !matches!(
            metadata.guard_stage,
            Stage::PrimaryProduct
                | Stage::SplitterProduct
                | Stage::SplitOutput
                | Stage::EftRemainder
                | Stage::TwoSumResult
                | Stage::TwoSumRemainder
                | Stage::Accumulation
        )
    {
        return false;
    }
    if metadata.guard_stage == Stage::Accumulation
        && metadata.term.is_none()
        && metadata
            .coordinate
            .is_some_and(|coordinate| coordinate < 21)
        && metadata.row.is_none()
        && metadata.scratch_box_feasible == Some(true)
    {
        return true;
    }
    let Some(term) = metadata.term else {
        return false;
    };
    (match metadata.guard_stage {
        Stage::TwoSumResult | Stage::TwoSumRemainder | Stage::Accumulation => term >= 1,
        _ => true,
    }) && term <= 21
        && metadata
            .coordinate
            .is_some_and(|coordinate| coordinate < 21)
        && metadata.row.is_none()
        && metadata.scratch_box_feasible == Some(true)
}

#[cfg(test)]
fn refinement_capture_h_locator_free_id_join(
    trace: &RefinementObservationTrace,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    locator: Option<RefinementCaptureHLocator>,
) -> bool {
    let Some(locator) = locator else {
        return true;
    };
    let Some(ids) = trace.face_free_ids.as_ref() else {
        return false;
    };
    match locator {
        RefinementCaptureHLocator::H0 => metadata.term.is_some_and(|slot| {
            usize::from(slot) < ids.len()
                && metadata.coordinate == u8::try_from(ids[usize::from(slot)]).ok()
        }),
        RefinementCaptureHLocator::H1 => metadata
            .coordinate
            .is_some_and(|coordinate| ids.contains(&usize::from(coordinate))),
    }
}

#[cfg(test)]
fn refinement_capture_terminal_complete(
    trace: &RefinementObservationTrace,
    terminal: Option<&super::M1TrustRegionRefinementFailureMetadata>,
) -> bool {
    let Some(metadata) = terminal else {
        return false;
    };
    // The metadata position identifies the executed correction.  The guard
    // stage alone is intentionally insufficient: Dot2 guards recur in p0,
    // the first residual/factor/update, and the second residual/factor/update.
    let positive_lambda = metadata.lambda.is_finite() && metadata.lambda > 0.0;
    let zero_lambda = metadata.lambda == 0.0;
    if !positive_lambda && !zero_lambda {
        return false;
    }
    if zero_lambda && !refinement_capture_legacy_inverse_absent(trace) {
        return false;
    }
    let resolved =
        refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary);
    if !refinement_capture_selected_terminal_kind_resolved(metadata, trace, &resolved) {
        return false;
    }
    // Keep the counted applications tied to the same per-field descriptor
    // that classifies the public `factor_applications` observation.  This is
    // deliberately before witness completeness: absence of a required count
    // remains instrumentation failure rather than an alternate terminal.
    let counted_application = resolved.expected_application_count > 0;
    if !counted_application && trace.factor_applications != 0 {
        return false;
    }
    if resolved.factor_output_ordinal.is_some()
        != (metadata.guard_stage
            == super::M1TrustRegionRefinementGuardStage::FactorApplicationOutput)
    {
        return false;
    }
    if !refinement_capture_applications_complete(trace, resolved.expected_application_count) {
        return false;
    }
    // Resolved content validators check arithmetic and copy lineage, while
    // the descriptor owns each public observation's required state. Consume
    // the complete public map here so a new field cannot pass by extending a
    // content validator without a resolved field obligation.
    if !resolved.public_status_complete(trace) {
        return false;
    }
    let boundary =
        trace.live_state_entry.is_some() && trace.live_state_exit.is_some() && trace.work.is_some();
    let structural = refinement_capture_common_complete(trace);
    refinement_capture_terminal_content_complete(
        trace,
        &resolved,
        RefinementCapturePrefixFlags {
            boundary,
            structural,
            lambda: (positive_lambda, zero_lambda),
        },
    )
}

#[cfg(test)]
#[derive(Clone, Copy)]
struct RefinementCapturePrefixFlags {
    boundary: bool,
    structural: bool,
    lambda: (bool, bool),
}

#[cfg(test)]
fn refinement_capture_terminal_content_complete(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    flags: RefinementCapturePrefixFlags,
) -> bool {
    let metadata = resolved.metadata;
    let RefinementCapturePrefixFlags {
        boundary,
        structural,
        lambda: (positive_lambda, zero_lambda),
    } = flags;
    let Some(p0) = trace.p0.as_ref() else {
        return false;
    };
    let Some(free_ids) = trace.face_free_ids.as_deref() else {
        return false;
    };
    let required =
        |name| resolved.field_state(name) == RefinementCaptureTerminalFieldState::Required;
    // These copy seams are resolved independently of application count: an
    // update refusal has an application but no p1 copy, while an active/box
    // refusal has the p1 copy before it has a second residual.
    let p1 = required("p1_bits").then_some(trace.p1.as_ref()).flatten();
    let p2 = required("p2_bits").then_some(trace.p2.as_ref()).flatten();
    if (required("p1_bits") && p1.is_none()) || (required("p2_bits") && p2.is_none()) {
        return false;
    }
    boundary
        && structural
        && refinement_capture_lineage_complete(trace, metadata)
        && refinement_capture_h_locator_free_id_join(trace, metadata, resolved.family.h_locator)
        && (positive_lambda || zero_lambda)
        && refinement_capture_norm_roles_are_plan_bounded(trace, resolved)
        && refinement_capture_resolved_norm_content(trace, resolved, p0, p1, p2, free_ids)
        && refinement_capture_resolved_refusing_comparison(trace, resolved)
        && refinement_capture_resolved_copy_boundaries(trace, resolved, positive_lambda)
        && refinement_capture_resolved_factor_content(trace, resolved, positive_lambda)
        && refinement_capture_resolved_radius_content(trace, resolved)
}

#[cfg(test)]
fn refinement_capture_resolved_copy_boundaries(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    positive_lambda: bool,
) -> bool {
    let state = |name| resolved.field_state(name);
    let p1_absent = state("p1_bits") == RefinementCaptureTerminalFieldState::Absent;
    let p2_absent = state("p2_bits") == RefinementCaptureTerminalFieldState::Absent;
    let factor_absent = state("factor_identity") == RefinementCaptureTerminalFieldState::Absent;
    let before_first_application = resolved.expected_application_count == 0;
    // Each branch is selected by a resolved copy state rather than optional
    // trace data.  The helpers check the complete absence/prefix sets, which
    // prevents a stray later vector, norm, or scalar from passing status-only
    // validation.
    (!p1_absent || refinement_capture_no_p1(trace, false))
        && (!p2_absent || refinement_capture_no_p2(trace, false))
        && (!before_first_application
            || !factor_absent
            || refinement_capture_pre_factor_absence(trace))
        && (!before_first_application
            || factor_absent
            || refinement_capture_first_residual_or_h0_prefix(
                trace,
                resolved.family.first.residual,
                positive_lambda,
            ))
        && (!(resolved.family.position == RefinementCaptureFamilyPosition::Second
            && resolved.expected_application_count == 1)
            || refinement_capture_second_residual_or_h1_prefix(
                trace,
                resolved.family.second.residual,
                positive_lambda,
            ))
}

#[cfg(test)]
fn refinement_capture_norm_scalar_values(
    trace: &RefinementObservationTrace,
    fields: (&'static str, &'static str),
) -> (Option<f64>, Option<f64>) {
    match fields {
        ("p0_full_norm2_bits", "p0_full_norm_bits") => (trace.p0_full_norm2, trace.p0_full_norm),
        ("p0_reduced_norm2_bits", "p0_reduced_norm_bits") => {
            (trace.p0_reduced_norm2, trace.p0_reduced_norm)
        }
        ("p1_full_norm2_bits", "p1_full_norm_bits") => (trace.p1_full_norm2, trace.p1_full_norm),
        ("p1_reduced_norm2_bits", "p1_reduced_norm_bits") => {
            (trace.p1_reduced_norm2, trace.p1_reduced_norm)
        }
        ("p2_full_norm2_bits", "p2_full_norm_bits") => (trace.p2_full_norm2, trace.p2_full_norm),
        ("p2_reduced_norm2_bits", "p2_reduced_norm_bits") => {
            (trace.p2_reduced_norm2, trace.p2_reduced_norm)
        }
        _ => panic!("unknown resolved norm scalar fields: {fields:?}"),
    }
}

#[cfg(test)]
fn refinement_capture_resolved_norm_content(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    p0: &[f64; 21],
    p1: Option<&[f64; 21]>,
    p2: Option<&[f64; 21]>,
    free_ids: &[usize],
) -> bool {
    let full: Vec<_> = (0..21).collect();
    let value = |vector| match vector {
        RefinementCaptureNormVector::P0 => Some(p0),
        RefinementCaptureNormVector::P1 => p1,
        RefinementCaptureNormVector::P2 => p2,
    };
    resolved
        .norm_obligations
        .iter()
        .flatten()
        .all(|obligation| {
            let values = value(obligation.vector);
            let coordinates = match obligation.domain {
                RefinementCaptureNormDomain::Full => full.as_slice(),
                RefinementCaptureNormDomain::Free => free_ids,
            };
            match obligation.completion {
                RefinementCaptureNormCompletion::Complete => values.is_some_and(|values| {
                    refinement_capture_exact_norm(trace, obligation.role, values, coordinates)
                        && obligation.scalar_fields.is_none_or(|fields| {
                            let (norm2, norm) =
                                refinement_capture_norm_scalar_values(trace, fields);
                            refinement_capture_norm_field_join(trace, obligation.role, norm2, norm)
                        })
                }),
                RefinementCaptureNormCompletion::Interrupted => values.is_some_and(|values| {
                    refinement_capture_exact_partial_norm(
                        trace,
                        obligation.role,
                        values,
                        coordinates,
                    )
                }),
            }
        })
}

#[cfg(test)]
fn refinement_capture_resolved_refusing_comparison(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
) -> bool {
    let Some(comparison) = resolved.refusing_comparison else {
        return true;
    };
    let role = match comparison {
        RefinementCaptureRefusingComparison::OriginalRadius(role)
        | RefinementCaptureRefusingComparison::ReducedRadius(role) => role,
    };
    let norm = trace
        .ordered_norms
        .iter()
        .find(|entry| entry.role == role)
        .map(|entry| f64::from_bits(entry.norm_bits));
    let Some(norm) = norm else {
        return false;
    };
    match comparison {
        RefinementCaptureRefusingComparison::OriginalRadius(_) => {
            norm > resolved.metadata.original_trust_radius
        }
        RefinementCaptureRefusingComparison::ReducedRadius(_) => {
            norm > resolved.metadata.reduced_face_radius
        }
    }
}

#[cfg(test)]
fn refinement_capture_resolved_factor_content(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
    positive_lambda: bool,
) -> bool {
    if !resolved.copy.marker_valid {
        return false;
    }
    if let Some(owner) = resolved.copy.generic_inverse_owner {
        let Some(snapshot) = trace
            .factor_application_snapshots
            .get(usize::from(owner - 1))
        else {
            return false;
        };
        if resolved.field_state("inverse_t_bits") == RefinementCaptureTerminalFieldState::Required
            && !refinement_capture_legacy_inverse_matches(trace, snapshot)
        {
            return false;
        }
    }
    if let Some(ordinal) = resolved.factor_output_ordinal {
        return (1..ordinal).all(|completed| {
            refinement_capture_factor_snapshot_complete(trace, completed, positive_lambda)
        }) && refinement_capture_factor_output_prefix(
            trace,
            resolved,
            ordinal,
            positive_lambda,
        );
    }
    (1..=resolved.expected_application_count)
        .all(|ordinal| refinement_capture_factor_snapshot_complete(trace, ordinal, positive_lambda))
}

#[cfg(test)]
fn refinement_capture_resolved_radius_content(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
) -> bool {
    // The copied arithmetic operands are validated only when the resolved
    // descriptor requires them.  A trace cannot manufacture this boundary.
    if resolved.field_state("remaining_radius_bits")
        != RefinementCaptureTerminalFieldState::Required
    {
        return trace.remaining_radius.is_none()
            && trace.radius_gap.is_none()
            && trace.radius_tolerance.is_none();
    }
    refinement_capture_final_radius_operands_join(
        trace,
        resolved.metadata,
        trace.radius_gap.is_some() || trace.radius_tolerance.is_some(),
    )
}

#[cfg(test)]
fn refinement_capture_norm_roles_are_plan_bounded(
    trace: &RefinementObservationTrace,
    resolved: &RefinementCaptureResolvedTerminal<'_>,
) -> bool {
    let allowed = |role: &str| {
        resolved
            .norm_obligations
            .iter()
            .flatten()
            .any(|obligation| obligation.role == role)
    };
    let exact_once = |role: &str| {
        trace
            .ordered_norms
            .iter()
            .filter(|entry| entry.role == role)
            .count()
            + trace
                .partial_ordered_norms
                .iter()
                .filter(|entry| entry.role == role)
                .count()
            <= 1
    };
    resolved
        .norm_obligations
        .iter()
        .flatten()
        .all(|obligation| {
            let count = match obligation.completion {
                RefinementCaptureNormCompletion::Complete => trace
                    .ordered_norms
                    .iter()
                    .filter(|entry| entry.role == obligation.role)
                    .count(),
                RefinementCaptureNormCompletion::Interrupted => trace
                    .partial_ordered_norms
                    .iter()
                    .filter(|entry| entry.role == obligation.role)
                    .count(),
            };
            count == 1 && exact_once(obligation.role)
        })
        && trace.ordered_norms.iter().all(|entry| allowed(entry.role))
        && trace
            .partial_ordered_norms
            .iter()
            .all(|entry| allowed(entry.role))
}

#[cfg(test)]
fn refinement_capture_exact_norm(
    trace: &RefinementObservationTrace,
    role: &str,
    expected: &[f64],
    coordinate_ids: &[usize],
) -> bool {
    let mut matches = trace.ordered_norms.iter().filter(|norm| norm.role == role);
    let Some(norm) = matches.next() else {
        return false;
    };
    if matches.next().is_some()
        || norm.coordinate_ids != coordinate_ids
        || norm.value_bits.len() != coordinate_ids.len()
        || norm.square_bits.len() != coordinate_ids.len()
        || norm.running_sum_bits.len() != coordinate_ids.len()
    {
        return false;
    }
    let mut sum = 0.0;
    for (((&coordinate, &value_bits), &square_bits), &running_sum_bits) in coordinate_ids
        .iter()
        .zip(&norm.value_bits)
        .zip(&norm.square_bits)
        .zip(&norm.running_sum_bits)
    {
        let value = expected[coordinate];
        if value.to_bits() != value_bits {
            return false;
        }
        let square = value * value;
        sum += square;
        if square.to_bits() != square_bits || sum.to_bits() != running_sum_bits {
            return false;
        }
    }
    sum.to_bits() == norm.norm2_bits && sum.sqrt().to_bits() == norm.norm_bits
}

#[cfg(test)]
fn refinement_capture_exact_partial_norm(
    trace: &RefinementObservationTrace,
    role: &str,
    expected: &[f64],
    coordinate_ids: &[usize],
) -> bool {
    if trace.ordered_norms.iter().any(|norm| norm.role == role) {
        return false;
    }
    let mut partials = trace
        .partial_ordered_norms
        .iter()
        .filter(|norm| norm.role == role);
    let Some(partial) = partials.next() else {
        return false;
    };
    if partials.next().is_some()
        || partial.value_bits.len() > coordinate_ids.len()
        || partial.coordinate_ids.len() != partial.value_bits.len()
        || partial.square_bits.len() > partial.value_bits.len()
        || partial.running_sum_bits.len() > partial.square_bits.len()
        || partial.coordinate_ids != coordinate_ids[..partial.value_bits.len()]
    {
        return false;
    }
    let mut sum = 0.0;
    for index in 0..partial.value_bits.len() {
        let value = expected[coordinate_ids[index]];
        if partial.value_bits[index] != value.to_bits() {
            return false;
        }
        let square = value * value;
        if index < partial.square_bits.len() && partial.square_bits[index] != square.to_bits() {
            return false;
        }
        sum += square;
        if index < partial.running_sum_bits.len()
            && partial.running_sum_bits[index] != sum.to_bits()
        {
            return false;
        }
    }
    match partial.terminal_operation {
        // Fixed ordered coordinate lists and admitted inputs rule out coordinate
        // and value-guard refusals on the selected path.
        "square_guard" => {
            partial.square_bits.len() == partial.value_bits.len()
                && partial.running_sum_bits.len() + 1 == partial.square_bits.len()
                && partial.sqrt_bits.is_none()
        }
        "running_sum_guard" => {
            partial.running_sum_bits.len() == partial.square_bits.len()
                && partial.square_bits.len() == partial.value_bits.len()
                && partial.sqrt_bits.is_none()
        }
        _ => false,
    }
}

#[cfg(test)]
fn refinement_capture_norm_field_join(
    trace: &RefinementObservationTrace,
    role: &str,
    norm2: Option<f64>,
    norm: Option<f64>,
) -> bool {
    let mut matches = trace
        .ordered_norms
        .iter()
        .filter(|entry| entry.role == role);
    let Some(entry) = matches.next() else {
        return false;
    };
    matches.next().is_none()
        && norm2.is_some_and(|value| value.to_bits() == entry.norm2_bits)
        && norm.is_some_and(|value| value.to_bits() == entry.norm_bits)
}

#[cfg(test)]
fn refinement_capture_field_status(
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
    name: &str,
    present: bool,
) -> &'static str {
    match refinement_capture_resolved_field_descriptor(resolved, name).state {
        RefinementCaptureTerminalFieldState::Required => {
            refinement_capture_expected_field_status(true, present)
        }
        RefinementCaptureTerminalFieldState::Interrupted => {
            if present {
                "contradictory_stray_presence"
            } else {
                "interrupted"
            }
        }
        RefinementCaptureTerminalFieldState::Absent => {
            refinement_capture_expected_field_status(false, present)
        }
        RefinementCaptureTerminalFieldState::InapplicableZeroLambda => {
            if present {
                "contradictory_stray_presence"
            } else {
                "inapplicable_zero_lambda"
            }
        }
        RefinementCaptureTerminalFieldState::MissingTerminalMetadata => "missing_terminal_metadata",
    }
}

/// The only per-field terminal authority.  The operation-site copy marker and
/// typed terminal select a required copy, an interrupted copy, or an absent
/// copy before any witness presence is considered.  Acceptance and every
/// public status consume this descriptor so an omitted witness cannot change
/// the terminal's expected boundary.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementCaptureTerminalFieldState {
    Required,
    Interrupted,
    Absent,
    InapplicableZeroLambda,
    MissingTerminalMetadata,
}

/// One terminal model carries both the exact application ordinal and the
/// field's operation/copy state.  Callers may validate copied bits and
/// lineage separately, but may not choose a second reach/count boundary.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct RefinementCaptureTerminalFieldDescriptor {
    state: RefinementCaptureTerminalFieldState,
    expected_application_count: u8,
    factor_output_ordinal: Option<u8>,
}

#[cfg(test)]
fn refinement_capture_resolved_field_descriptor(
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
    name: &str,
) -> RefinementCaptureTerminalFieldDescriptor {
    let Some(resolved) = resolved else {
        return RefinementCaptureTerminalFieldDescriptor {
            state: RefinementCaptureTerminalFieldState::MissingTerminalMetadata,
            expected_application_count: 0,
            factor_output_ordinal: None,
        };
    };
    RefinementCaptureTerminalFieldDescriptor {
        state: resolved.field_state(name),
        expected_application_count: resolved.expected_application_count,
        factor_output_ordinal: resolved.factor_output_ordinal,
    }
}

#[cfg(test)]
impl RefinementCaptureResolvedTerminal<'_> {
    /// Acceptance consumes the same complete public projection as external
    /// observers. A missing required copy or an injected unreached copy is a
    /// terminal failure; neither can select a different terminal boundary.
    fn public_status_complete(&self, trace: &RefinementObservationTrace) -> bool {
        let serde_json::Value::Object(statuses) =
            refinement_capture_field_status_json_resolved(trace, Some(self))
        else {
            return false;
        };
        self.expected_application_count <= 2
            && !statuses.values().any(|status| {
                matches!(
                    status.as_str(),
                    Some(
                        "missing_terminal_metadata"
                            | "missing_instrumentation"
                            | "contradictory_stray_presence"
                    )
                )
            })
    }

    fn field_state(&self, name: &str) -> RefinementCaptureTerminalFieldState {
        self.obligations
            .iter()
            .find(|obligation| obligation.name == name)
            .map_or_else(
                || panic!("unknown resolved public field: {name}"),
                |obligation| obligation.state,
            )
    }
}

#[cfg(test)]
fn refinement_capture_expected_field_status(expected: bool, present: bool) -> &'static str {
    match (expected, present) {
        (true, true) => "captured",
        (true, false) => "missing_instrumentation",
        (false, true) => "contradictory_stray_presence",
        (false, false) => "naturally_unreached",
    }
}

/// The one terminal/copy relation used by acceptance, expected application
/// counts, and field-status classification.  It is deliberately derived from
/// the typed terminal metadata only: copied witness fields may corroborate a
/// relation but never create one.
#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct RefinementCaptureResolvedTerminal<'a> {
    metadata: &'a super::M1TrustRegionRefinementFailureMetadata,
    expected_application_count: u8,
    factor_output_ordinal: Option<u8>,
    family: RefinementCaptureTerminalFamily,
    copy: RefinementCaptureCopyObligations,
    obligations: [RefinementCaptureFieldObligation; 68],
    norm_obligations: [Option<RefinementCaptureNormObligation>; 9],
    refusing_comparison: Option<RefinementCaptureRefusingComparison>,
}

/// Copy ownership is resolved once with the terminal family. The marker is
/// input data to resolution; copied arrays only validate this selected record.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct RefinementCaptureCopyObligations {
    marker: Option<(u8, RefinementFactorOutputCopyBoundary)>,
    generic_inverse_owner: Option<u8>,
    boundary_valid: bool,
    marker_valid: bool,
}

#[cfg(test)]
fn refinement_capture_copy_obligations(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    count: u8,
    factor_output_ordinal: Option<u8>,
    marker: Option<(u8, RefinementFactorOutputCopyBoundary)>,
) -> RefinementCaptureCopyObligations {
    let boundary_valid = marker.is_none_or(|(_, boundary)| {
        refinement_capture_factor_output_boundary_valid(metadata.lambda > 0.0, boundary)
    });
    let marker_valid = factor_output_ordinal.is_some()
        || marker
            == if count == 0 {
                None
            } else {
                Some((count, RefinementFactorOutputCopyBoundary::AfterDelta))
            };
    let generic_inverse_owner = if metadata.lambda <= 0.0
        || count == 0
        || (factor_output_ordinal == Some(1)
            && marker.is_some_and(|(_, boundary)| {
                boundary == RefinementFactorOutputCopyBoundary::BeforeInverse
            })) {
        None
    } else if factor_output_ordinal == Some(2)
        && marker.is_some_and(|(_, boundary)| {
            boundary == RefinementFactorOutputCopyBoundary::BeforeInverse
        })
    {
        Some(1)
    } else {
        Some(count)
    };
    RefinementCaptureCopyObligations {
        marker,
        generic_inverse_owner,
        boundary_valid,
        marker_valid,
    }
}

#[cfg(test)]
/// Immutable public-field obligation selected once from the typed terminal
/// and its explicit copy-boundary input.  Status and content consumers only
/// look up this record; copied operands never select a different reach state.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct RefinementCaptureFieldObligation {
    name: &'static str,
    state: RefinementCaptureTerminalFieldState,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementCaptureNormCompletion {
    Complete,
    Interrupted,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementCaptureNormDomain {
    Full,
    Free,
}
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementCaptureNormVector {
    P0,
    P1,
    P2,
}
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct RefinementCaptureNormObligation {
    role: &'static str,
    completion: RefinementCaptureNormCompletion,
    vector: RefinementCaptureNormVector,
    domain: RefinementCaptureNormDomain,
    scalar_fields: Option<(&'static str, &'static str)>,
}
#[cfg(test)]
fn refinement_capture_norm_obligation(
    role: &'static str,
    completion: RefinementCaptureNormCompletion,
) -> RefinementCaptureNormObligation {
    let (vector, domain, scalar_fields) = match role {
        "p0_full" => (
            RefinementCaptureNormVector::P0,
            RefinementCaptureNormDomain::Full,
            Some(("p0_full_norm2_bits", "p0_full_norm_bits")),
        ),
        "p0_free" => (
            RefinementCaptureNormVector::P0,
            RefinementCaptureNormDomain::Free,
            Some(("p0_reduced_norm2_bits", "p0_reduced_norm_bits")),
        ),
        "p1_full" => (
            RefinementCaptureNormVector::P1,
            RefinementCaptureNormDomain::Full,
            Some(("p1_full_norm2_bits", "p1_full_norm_bits")),
        ),
        "p1_free" => (
            RefinementCaptureNormVector::P1,
            RefinementCaptureNormDomain::Free,
            Some(("p1_reduced_norm2_bits", "p1_reduced_norm_bits")),
        ),
        "p2_full" => (
            RefinementCaptureNormVector::P2,
            RefinementCaptureNormDomain::Full,
            Some(("p2_full_norm2_bits", "p2_full_norm_bits")),
        ),
        "p2_free" => (
            RefinementCaptureNormVector::P2,
            RefinementCaptureNormDomain::Free,
            Some(("p2_reduced_norm2_bits", "p2_reduced_norm_bits")),
        ),
        "p0_zero_lambda_eligibility" => (
            RefinementCaptureNormVector::P0,
            RefinementCaptureNormDomain::Full,
            None,
        ),
        "p1_zero_lambda_scratch" => (
            RefinementCaptureNormVector::P1,
            RefinementCaptureNormDomain::Full,
            None,
        ),
        "p2_zero_lambda_final" => (
            RefinementCaptureNormVector::P2,
            RefinementCaptureNormDomain::Full,
            None,
        ),
        _ => panic!("unknown resolved norm role: {role}"),
    };
    RefinementCaptureNormObligation {
        role,
        completion,
        vector,
        domain,
        scalar_fields,
    }
}

#[cfg(test)]
fn refinement_capture_norm_obligations(
    completed: &[&'static str],
    partial: &[&'static str],
) -> [Option<RefinementCaptureNormObligation>; 9] {
    let mut obligations = [None; 9];
    for (index, role) in completed.iter().chain(partial).enumerate() {
        let completion = if index < completed.len() {
            RefinementCaptureNormCompletion::Complete
        } else {
            RefinementCaptureNormCompletion::Interrupted
        };
        obligations[index] = Some(refinement_capture_norm_obligation(role, completion));
    }
    obligations
}

/// A rejecting comparison is selected from typed terminal metadata once.  Its
/// operand witness is validated later and cannot select or erase the refusal.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementCaptureRefusingComparison {
    OriginalRadius(&'static str),
    ReducedRadius(&'static str),
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct RefinementCaptureTerminalFamily {
    position: RefinementCaptureFamilyPosition,
    h_locator: Option<RefinementCaptureHLocator>,
    first: RefinementCaptureOrdinalReach,
    second: RefinementCaptureOrdinalReach,
    candidate: RefinementCaptureCandidateReach,
    final_reach: RefinementCaptureFinalReach,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementCaptureFamilyPosition {
    None,
    First,
    Second,
}
#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct RefinementCaptureOrdinalReach {
    residual: bool,
    h: bool,
    delta: bool,
}
#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct RefinementCaptureCandidateReach {
    p0: bool,
    p1: bool,
    p2: bool,
}
#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct RefinementCaptureFinalReach {
    radius: bool,
    closeness: bool,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementCaptureHLocator {
    H0,
    H1,
}

#[cfg(test)]
fn refinement_capture_terminal_family(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) -> (RefinementCaptureTerminalFamily, u8) {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
    };
    let stage = metadata.guard_stage;
    let residual_prefix = matches!(
        stage,
        Stage::ResidualSourceTerm
            | Stage::ResidualSourceWeight
            | Stage::PrimaryProduct
            | Stage::SplitterProduct
            | Stage::SplitOutput
            | Stage::EftRemainder
            | Stage::TwoSumResult
            | Stage::TwoSumRemainder
            | Stage::Accumulation
    );
    let first_update = matches!(
        stage,
        Stage::ActiveFinite
            | Stage::ActiveEquality
            | Stage::ScratchBoxLower
            | Stage::ScratchBoxUpper
            | Stage::ScratchFullRadius
            | Stage::ScratchReducedRadius
            | Stage::OrderedNorm
            | Stage::RadiusComparison
    );
    let second_update = matches!(
        stage,
        Stage::ActiveFinite
            | Stage::ActiveEquality
            | Stage::FinalBoxLower
            | Stage::FinalBoxUpper
            | Stage::FinalFullRadius
            | Stage::FinalReducedRadius
            | Stage::FinalRadiusCloseness
            | Stage::FinalInstallEquality
            | Stage::OrderedNorm
            | Stage::RadiusComparison
    );
    let factor_output = stage == Stage::FactorApplicationOutput;
    let first = metadata.correction_position == Some(Position::First);
    let second = metadata.correction_position == Some(Position::Second);
    let h0_locator = first && refinement_capture_h0_locator(metadata);
    let h1_locator = second && refinement_capture_h1_locator(metadata);
    let count = match metadata.correction_position {
        None => 0,
        Some(Position::First) if residual_prefix => 0,
        Some(Position::First) => 1,
        Some(Position::Second) if residual_prefix => 1,
        Some(Position::Second) => 2,
    };
    (
        RefinementCaptureTerminalFamily {
            position: if second {
                RefinementCaptureFamilyPosition::Second
            } else if first {
                RefinementCaptureFamilyPosition::First
            } else {
                RefinementCaptureFamilyPosition::None
            },
            h_locator: if h0_locator {
                Some(RefinementCaptureHLocator::H0)
            } else if h1_locator {
                Some(RefinementCaptureHLocator::H1)
            } else {
                None
            },
            first: RefinementCaptureOrdinalReach {
                residual: second || (first && (h0_locator || !residual_prefix)),
                h: second || (first && !h0_locator && !residual_prefix),
                delta: second || (first && !residual_prefix && !factor_output),
            },
            second: RefinementCaptureOrdinalReach {
                residual: second && (h1_locator || !residual_prefix),
                h: second && !h1_locator && !residual_prefix,
                delta: second && !residual_prefix && !factor_output,
            },
            candidate: RefinementCaptureCandidateReach {
                p0: stage != Stage::P0AssemblyEquality,
                p1: second || (first && first_update),
                p2: second && second_update,
            },
            final_reach: RefinementCaptureFinalReach {
                radius: matches!(
                    stage,
                    Stage::FinalReducedRadius | Stage::FinalRadiusCloseness
                ),
                closeness: stage == Stage::FinalRadiusCloseness,
            },
        },
        count,
    )
}

#[cfg(test)]
fn refinement_capture_set_obligations(
    obligations: &mut [RefinementCaptureFieldObligation; 68],
    names: &[&'static str],
    state: RefinementCaptureTerminalFieldState,
) {
    for name in names {
        let obligation = obligations
            .iter_mut()
            .find(|obligation| obligation.name == *name)
            .unwrap_or_else(|| panic!("unknown resolved public field: {name}"));
        obligation.state = state;
    }
}

#[cfg(test)]
fn refinement_capture_factor_copy_obligations(
    obligations: &mut [RefinementCaptureFieldObligation; 68],
    ordinal: u8,
    lambda_positive: bool,
    boundary: Option<(u8, RefinementFactorOutputCopyBoundary)>,
) {
    const GENERIC: &[&str] = &[
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
    ];
    const H1: &[&str] = &["factor_application_snapshot_1_h_bits"];
    const H2: &[&str] = &["factor_application_snapshot_2_h_bits"];
    const I1: &[&str] = &[
        "factor_application_snapshot_1_inverse_t_bits",
        "factor_application_snapshot_1_inverse_denominator_bits",
        "factor_application_snapshot_1_inverse_z_bits",
    ];
    const I2: &[&str] = &[
        "factor_application_snapshot_2_inverse_t_bits",
        "factor_application_snapshot_2_inverse_denominator_bits",
        "factor_application_snapshot_2_inverse_z_bits",
    ];
    const D1: &[&str] = &["delta0_bits", "factor_application_snapshot_1_delta_bits"];
    const D2: &[&str] = &["delta1_bits", "factor_application_snapshot_2_delta_bits"];
    let (current_inverse, current_delta) = if ordinal == 1 { (I1, D1) } else { (I2, D2) };
    let relevant = if ordinal == 1 {
        [GENERIC, I1, D1].concat()
    } else {
        [GENERIC, I1, D1, I2, D2].concat()
    };
    refinement_capture_set_obligations(
        obligations,
        &relevant,
        RefinementCaptureTerminalFieldState::Absent,
    );
    if lambda_positive {
        refinement_capture_set_obligations(
            obligations,
            H1,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if lambda_positive && ordinal == 2 {
        refinement_capture_set_obligations(
            obligations,
            H2,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    let Some((marked_ordinal, marker)) = boundary else {
        refinement_capture_set_obligations(
            obligations,
            &relevant,
            RefinementCaptureTerminalFieldState::Required,
        );
        return;
    };
    if marked_ordinal != ordinal {
        refinement_capture_set_obligations(
            obligations,
            &relevant,
            RefinementCaptureTerminalFieldState::Required,
        );
        return;
    }
    if ordinal == 2 {
        if lambda_positive {
            refinement_capture_set_obligations(
                obligations,
                I1,
                RefinementCaptureTerminalFieldState::Required,
            );
        }
        refinement_capture_set_obligations(
            obligations,
            D1,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    let inverse = if marker >= RefinementFactorOutputCopyBoundary::AfterInverse {
        RefinementCaptureTerminalFieldState::Required
    } else {
        RefinementCaptureTerminalFieldState::Interrupted
    };
    let delta = if marker >= RefinementFactorOutputCopyBoundary::AfterDelta {
        RefinementCaptureTerminalFieldState::Required
    } else {
        RefinementCaptureTerminalFieldState::Interrupted
    };
    if lambda_positive {
        refinement_capture_set_obligations(obligations, current_inverse, inverse);
        let generic = if ordinal == 2 && marker == RefinementFactorOutputCopyBoundary::BeforeInverse
        {
            RefinementCaptureTerminalFieldState::Required
        } else {
            inverse
        };
        refinement_capture_set_obligations(obligations, GENERIC, generic);
    }
    refinement_capture_set_obligations(obligations, current_delta, delta);
}

#[cfg(test)]
fn refinement_capture_initialize_structure_obligations(
    obligations: &mut [RefinementCaptureFieldObligation; 68],
) {
    const STRUCTURE: &[&str] = &[
        "free_ids",
        "factor_order",
        "factor_a_bits",
        "factor_v_bits",
        "factor_sigma_bits",
        "weighted_residual_bits",
        "weighted_matrix_bits",
        "scaled_lower_bits",
        "scaled_upper_bits",
        "lambda_bits",
        "reduced_face_radius_bits",
    ];
    const LIVE: &[&str] = &[
        "live_state_entry_bits",
        "live_state_exit_bits",
        "lower_mask_exit",
        "upper_mask_exit",
    ];
    refinement_capture_set_obligations(
        obligations,
        STRUCTURE,
        RefinementCaptureTerminalFieldState::Required,
    );
    refinement_capture_set_obligations(
        obligations,
        LIVE,
        RefinementCaptureTerminalFieldState::Required,
    );
}

#[cfg(test)]
fn refinement_capture_apply_family_obligations(
    obligations: &mut [RefinementCaptureFieldObligation; 68],
    family: RefinementCaptureTerminalFamily,
) {
    const ELIGIBILITY: &[&str] = &[
        "eligibility_scalar_operations",
        "eligibility_guard_events",
        "factor_identity",
    ];
    const P0: &[&str] = &["p0_bits", "lower_mask_p0", "upper_mask_p0"];
    const P1: &[&str] = &["p1_bits", "lower_mask_p1", "upper_mask_p1"];
    const P2: &[&str] = &["p2_bits", "lower_mask_p2", "upper_mask_p2"];
    if family.position != RefinementCaptureFamilyPosition::None {
        refinement_capture_set_obligations(
            obligations,
            ELIGIBILITY,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.candidate.p0 {
        refinement_capture_set_obligations(
            obligations,
            P0,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.first.residual {
        refinement_capture_set_obligations(
            obligations,
            &["residual0_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.first.h {
        refinement_capture_set_obligations(
            obligations,
            &["h0_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.first.delta {
        refinement_capture_set_obligations(
            obligations,
            &["delta0_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.candidate.p1 {
        refinement_capture_set_obligations(
            obligations,
            P1,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.second.residual {
        refinement_capture_set_obligations(
            obligations,
            &["residual1_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.second.h {
        refinement_capture_set_obligations(
            obligations,
            &["h1_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.second.delta {
        refinement_capture_set_obligations(
            obligations,
            &["delta1_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.candidate.p2 {
        refinement_capture_set_obligations(
            obligations,
            P2,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.final_reach.radius {
        refinement_capture_set_obligations(
            obligations,
            &["remaining_radius_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if family.final_reach.closeness {
        refinement_capture_set_obligations(
            obligations,
            &["radius_gap_bits", "radius_tolerance_bits"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
}

#[cfg(test)]
fn refinement_capture_apply_application_obligations(
    obligations: &mut [RefinementCaptureFieldObligation; 68],
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    count: u8,
    copy_boundary: Option<(u8, RefinementFactorOutputCopyBoundary)>,
) {
    const APPLICATIONS: &[&str] = &[
        "factor_application_identities",
        "factor_application_snapshots",
        "factor_applications",
        "factor_output_copy_boundary",
    ];
    const SNAPSHOT1: &[&str] = &[
        "factor_application_snapshot_1_h_bits",
        "factor_application_snapshot_1_inverse_t_bits",
        "factor_application_snapshot_1_inverse_denominator_bits",
        "factor_application_snapshot_1_inverse_z_bits",
        "factor_application_snapshot_1_delta_bits",
    ];
    const SNAPSHOT2: &[&str] = &[
        "factor_application_snapshot_2_h_bits",
        "factor_application_snapshot_2_inverse_t_bits",
        "factor_application_snapshot_2_inverse_denominator_bits",
        "factor_application_snapshot_2_inverse_z_bits",
        "factor_application_snapshot_2_delta_bits",
    ];
    if count > 0 {
        refinement_capture_set_obligations(
            obligations,
            APPLICATIONS,
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    let factor_output =
        metadata.guard_stage == super::M1TrustRegionRefinementGuardStage::FactorApplicationOutput;
    if count > 0 && !factor_output {
        let snapshot1 = if metadata.lambda > 0.0 {
            SNAPSHOT1
        } else {
            &["factor_application_snapshot_1_delta_bits"]
        };
        refinement_capture_set_obligations(
            obligations,
            snapshot1,
            RefinementCaptureTerminalFieldState::Required,
        );
        if count > 1 {
            let snapshot2 = if metadata.lambda > 0.0 {
                SNAPSHOT2
            } else {
                &["factor_application_snapshot_2_delta_bits"]
            };
            refinement_capture_set_obligations(
                obligations,
                snapshot2,
                RefinementCaptureTerminalFieldState::Required,
            );
        }
    }
    if metadata.lambda > 0.0 && count > 0 {
        refinement_capture_set_obligations(
            obligations,
            &[
                "inverse_t_bits",
                "inverse_denominator_bits",
                "inverse_z_bits",
            ],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if factor_output && count > 0 {
        refinement_capture_factor_copy_obligations(
            obligations,
            count,
            metadata.lambda > 0.0,
            copy_boundary,
        );
    }
}

#[cfg(test)]
fn refinement_capture_apply_norm_obligations(
    obligations: &mut [RefinementCaptureFieldObligation; 68],
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    norm_obligations: &[Option<RefinementCaptureNormObligation>; 9],
) {
    for norm in norm_obligations.iter().flatten() {
        let Some(fields) = norm.scalar_fields else {
            continue;
        };
        let state = if metadata.lambda == 0.0 {
            RefinementCaptureTerminalFieldState::InapplicableZeroLambda
        } else if norm.completion == RefinementCaptureNormCompletion::Complete {
            RefinementCaptureTerminalFieldState::Required
        } else {
            RefinementCaptureTerminalFieldState::Interrupted
        };
        refinement_capture_set_obligations(obligations, &[fields.0, fields.1], state);
    }
    if norm_obligations
        .iter()
        .flatten()
        .any(|norm| norm.completion == RefinementCaptureNormCompletion::Complete)
    {
        refinement_capture_set_obligations(
            obligations,
            &["ordered_norm_traces"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
    if norm_obligations
        .iter()
        .flatten()
        .any(|norm| norm.completion == RefinementCaptureNormCompletion::Interrupted)
    {
        refinement_capture_set_obligations(
            obligations,
            &["partial_ordered_norms"],
            RefinementCaptureTerminalFieldState::Required,
        );
    }
}

#[cfg(test)]
fn refinement_capture_apply_zero_lambda_obligations(
    obligations: &mut [RefinementCaptureFieldObligation; 68],
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) {
    if metadata.lambda == 0.0 {
        for obligation in obligations {
            if (obligation.name.ends_with("_norm2_bits") || obligation.name.ends_with("_norm_bits"))
                || obligation.name.starts_with('h')
                || obligation.name.ends_with("_h_bits")
                || obligation.name.starts_with("inverse_")
                || (obligation.name.starts_with("factor_application_snapshot_")
                    && obligation.name.contains("inverse"))
            {
                obligation.state = RefinementCaptureTerminalFieldState::InapplicableZeroLambda;
            }
        }
    }
}

#[cfg(test)]
fn refinement_capture_build_obligations(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    family: RefinementCaptureTerminalFamily,
    count: u8,
    norm_obligations: &[Option<RefinementCaptureNormObligation>; 9],
    copy_boundary: Option<(u8, RefinementFactorOutputCopyBoundary)>,
) -> [RefinementCaptureFieldObligation; 68] {
    let mut obligations = std::array::from_fn(|index| RefinementCaptureFieldObligation {
        name: refinement_capture_public_field_registry()[index],
        state: RefinementCaptureTerminalFieldState::Absent,
    });
    refinement_capture_initialize_structure_obligations(&mut obligations);
    refinement_capture_apply_family_obligations(&mut obligations, family);
    refinement_capture_apply_application_obligations(
        &mut obligations,
        metadata,
        count,
        copy_boundary,
    );
    refinement_capture_apply_norm_obligations(&mut obligations, metadata, norm_obligations);
    refinement_capture_apply_zero_lambda_obligations(&mut obligations, metadata);
    obligations
}

#[cfg(test)]
fn refinement_capture_resolved_terminal(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    copy_boundary: Option<(u8, RefinementFactorOutputCopyBoundary)>,
) -> RefinementCaptureResolvedTerminal<'_> {
    let (family, expected_application_count) = refinement_capture_terminal_family(metadata);
    let (completed_norm_roles, partial_norm_roles) =
        refinement_capture_terminal_norm_roles(metadata);
    let norm_obligations =
        refinement_capture_norm_obligations(completed_norm_roles, partial_norm_roles);
    let factor_output_ordinal = (metadata.guard_stage
        == super::M1TrustRegionRefinementGuardStage::FactorApplicationOutput)
        .then_some(expected_application_count)
        .filter(|ordinal| *ordinal > 0);
    let copy = refinement_capture_copy_obligations(
        metadata,
        expected_application_count,
        factor_output_ordinal,
        copy_boundary,
    );
    let obligations = refinement_capture_build_obligations(
        metadata,
        family,
        expected_application_count,
        &norm_obligations,
        copy.marker,
    );
    RefinementCaptureResolvedTerminal {
        metadata,
        expected_application_count,
        factor_output_ordinal,
        family,
        copy,
        obligations,
        norm_obligations,
        refusing_comparison: refinement_capture_refusing_comparison(metadata),
    }
}

#[cfg(test)]
fn refinement_capture_refusing_comparison(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) -> Option<RefinementCaptureRefusingComparison> {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    match (
        metadata.correction_position,
        metadata.guard_stage,
        metadata.reason,
    ) {
        (None, Stage::P0FullRadius, Reason::FinalRadius) => Some(
            RefinementCaptureRefusingComparison::OriginalRadius("p0_full"),
        ),
        (None, Stage::P0ReducedRadius, Reason::FinalRadius) => Some(
            RefinementCaptureRefusingComparison::ReducedRadius("p0_free"),
        ),
        (Some(Position::First), Stage::ScratchFullRadius, Reason::ScratchRadius) => Some(
            RefinementCaptureRefusingComparison::OriginalRadius("p1_full"),
        ),
        (Some(Position::First), Stage::ScratchReducedRadius, Reason::ScratchRadius) => Some(
            RefinementCaptureRefusingComparison::ReducedRadius("p1_free"),
        ),
        (Some(Position::First), Stage::RadiusComparison, Reason::ScratchRadius) => Some(
            RefinementCaptureRefusingComparison::OriginalRadius("p1_zero_lambda_scratch"),
        ),
        (Some(Position::Second), Stage::FinalFullRadius, Reason::FinalRadius) => Some(
            RefinementCaptureRefusingComparison::OriginalRadius("p2_full"),
        ),
        (Some(Position::Second), Stage::FinalReducedRadius, Reason::FinalRadius) => Some(
            RefinementCaptureRefusingComparison::ReducedRadius("p2_free"),
        ),
        (Some(Position::Second), Stage::RadiusComparison, Reason::FinalRadius) => Some(
            RefinementCaptureRefusingComparison::OriginalRadius("p2_zero_lambda_final"),
        ),
        _ => None,
    }
}

/// The terminal plan owns norm role expectations, including interrupted
/// operations.  Presence of a partial witness is checked later as content and
/// cannot remove a role from this list.
#[cfg(test)]
fn refinement_capture_terminal_norm_roles(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) -> (&'static [&'static str], &'static [&'static str]) {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
    };
    match (
        metadata.correction_position,
        metadata.lambda == 0.0,
        metadata.guard_stage,
    ) {
        (None, true, Stage::OrderedNorm) => (&[], &["p0_zero_lambda_eligibility"]),
        (None, false, Stage::P0FullRadius)
            if metadata.reason == super::M1TrustRegionRefinementReason::FinalRadius =>
        {
            (&["p0_full"], &[])
        }
        (None, false, Stage::P0FullRadius) => (&[], &["p0_full"]),
        (None, false, Stage::P0ReducedRadius)
            if metadata.reason == super::M1TrustRegionRefinementReason::FinalRadius =>
        {
            (&["p0_full", "p0_free"], &[])
        }
        (None, false, Stage::P0ReducedRadius) => (&["p0_full"], &["p0_free"]),
        (Some(Position::First), true, Stage::OrderedNorm) => {
            (&["p0_zero_lambda_eligibility"], &["p1_zero_lambda_scratch"])
        }
        (Some(Position::First), true, Stage::RadiusComparison) => (
            &["p0_zero_lambda_eligibility", "p1_zero_lambda_scratch"],
            &[],
        ),
        (Some(Position::First), false, Stage::ScratchFullRadius)
            if metadata.reason == super::M1TrustRegionRefinementReason::ScratchRadius =>
        {
            (&["p0_full", "p0_free", "p1_full"], &[])
        }
        (Some(Position::First), false, Stage::ScratchFullRadius) => {
            (&["p0_full", "p0_free"], &["p1_full"])
        }
        (Some(Position::First), false, Stage::ScratchReducedRadius)
            if metadata.reason == super::M1TrustRegionRefinementReason::ScratchRadius =>
        {
            (&["p0_full", "p0_free", "p1_full", "p1_free"], &[])
        }
        (Some(Position::First), false, Stage::ScratchReducedRadius) => {
            (&["p0_full", "p0_free", "p1_full"], &["p1_free"])
        }
        (Some(Position::Second), true, Stage::OrderedNorm) => (
            &["p0_zero_lambda_eligibility", "p1_zero_lambda_scratch"],
            &["p2_zero_lambda_final"],
        ),
        (Some(Position::Second), true, Stage::RadiusComparison | Stage::FinalInstallEquality) => (
            &[
                "p0_zero_lambda_eligibility",
                "p1_zero_lambda_scratch",
                "p2_zero_lambda_final",
            ],
            &[],
        ),
        (Some(Position::Second), false, Stage::FinalFullRadius)
            if metadata.reason == super::M1TrustRegionRefinementReason::FinalRadius =>
        {
            (
                &["p0_full", "p0_free", "p1_full", "p1_free", "p2_full"],
                &[],
            )
        }
        (Some(Position::Second), false, Stage::FinalFullRadius) => {
            (&["p0_full", "p0_free", "p1_full", "p1_free"], &["p2_full"])
        }
        (Some(Position::Second), false, Stage::FinalReducedRadius)
            if metadata.reason == super::M1TrustRegionRefinementReason::FinalRadius =>
        {
            (
                &[
                    "p0_full", "p0_free", "p1_full", "p1_free", "p2_full", "p2_free",
                ],
                &[],
            )
        }
        (Some(Position::Second), false, Stage::FinalReducedRadius) => (
            &["p0_full", "p0_free", "p1_full", "p1_free", "p2_full"],
            &["p2_free"],
        ),
        (Some(Position::Second), false, Stage::FinalRadiusCloseness) => (
            &[
                "p0_full", "p0_free", "p1_full", "p1_free", "p2_full", "p2_free",
            ],
            &[],
        ),
        // Every terminal after the initial p0 route inherits the completed
        // predecessor norms.  These are resolved plan obligations, never
        // inferred from the optional scalar copies in a witness.
        (Some(Position::First), false, _) => (&["p0_full", "p0_free"], &[]),
        (Some(Position::First), true, _) => (&["p0_zero_lambda_eligibility"], &[]),
        (Some(Position::Second), false, _) => (&["p0_full", "p0_free", "p1_full", "p1_free"], &[]),
        (Some(Position::Second), true, _) => (
            &["p0_zero_lambda_eligibility", "p1_zero_lambda_scratch"],
            &[],
        ),
        _ => (&[], &[]),
    }
}

/// Nonphysical custody control for the reviewed finite terminal inventory.  It
/// reads only the detached JSON table at compile time and performs no solver,
/// evaluator, fixture, poison, or capture invocation.
#[cfg(test)]
fn refinement_capture_inventory_schema_locator_assertions(
    entry: &serde_json::Value,
    locator: &serde_json::Value,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    row_descriptor: Option<&str>,
    term_descriptor: Option<&str>,
    coordinate_descriptor: Option<&str>,
) {
    let trace = RefinementObservationTrace {
        face_free_ids: Some(vec![2, 5, 9]),
        ..Default::default()
    };
    let rows: Vec<_> = if row_descriptor.is_some() {
        (0..21_u8).map(Some).collect()
    } else {
        vec![metadata.row]
    };
    let terms: Vec<_> = match term_descriptor {
        Some(value) if value.contains("null final") => {
            std::iter::once(None).chain((1..=21_u8).map(Some)).collect()
        }
        Some(value) if value.contains("0..21") => (0..=21_u8).map(Some).collect(),
        Some(value) if value.contains("1..21") => (1..=21_u8).map(Some).collect(),
        Some(value) if value.contains("slot") => (0..3_u8).map(Some).collect(),
        _ => vec![metadata.term],
    };
    let scratch_values: Vec<_> = locator["scratch_box_feasible"].as_array().map_or_else(
        || vec![metadata.scratch_box_feasible],
        |_| vec![Some(false), Some(true)],
    );
    for row in rows {
        for term in &terms {
            let coordinates: Vec<_> = if coordinate_descriptor
                .is_some_and(|value| value.contains("free_ids"))
                && term_descriptor.is_some_and(|value| value.contains("slot"))
            {
                vec![term.and_then(|slot| [2, 5, 9].get(usize::from(slot)).copied())]
            } else if coordinate_descriptor.is_some_and(|value| value.contains("free_ids")) {
                vec![Some(2), Some(5), Some(9)]
            } else if coordinate_descriptor.is_some_and(|value| value.contains("term-1")) {
                vec![term.and_then(|value| (value > 0).then(|| value - 1))]
            } else if coordinate_descriptor == Some("0..20") {
                (0..21_u8).map(Some).collect()
            } else {
                vec![metadata.coordinate]
            };
            for coordinate in coordinates {
                for scratch_box_feasible in &scratch_values {
                    let mut variant = metadata.clone();
                    variant.row = row;
                    variant.term = *term;
                    variant.coordinate = coordinate;
                    variant.scratch_box_feasible = *scratch_box_feasible;
                    let accepted = refinement_capture_selected_terminal_kind(&variant, &trace);
                    if entry["lambda"] == "positive"
                        && *scratch_box_feasible == Some(false)
                        && metadata.scratch_box_feasible != Some(false)
                    {
                        assert!(
                            !accepted,
                            "impossible positive/false scratch accepted: {}",
                            entry["id"]
                        );
                    } else {
                        assert!(accepted, "approved locator rejected: {}", entry["id"]);
                    }
                }
            }
        }
    }
}

#[cfg(test)]
fn refinement_capture_inventory_schema_locator_variant(
    entry: &serde_json::Value,
    stage: &str,
    reason: &str,
    position: Option<super::M1TrustRegionCorrectionPosition>,
    locator: &serde_json::Value,
    locator_variant: Option<&serde_json::Value>,
) {
    let row_descriptor = locator["row"]
        .as_str()
        .or_else(|| locator_variant.and_then(|item| item["row"].as_str()));
    let h1 = position == Some(super::M1TrustRegionCorrectionPosition::Second)
        && entry["lambda"] == "positive"
        && row_descriptor.is_none()
        && matches!(
            stage,
            "PrimaryProduct"
                | "SplitterProduct"
                | "SplitOutput"
                | "EftRemainder"
                | "TwoSumResult"
                | "TwoSumRemainder"
                | "Accumulation"
        );
    let term_descriptor = locator["term"]
        .as_str()
        .or_else(|| locator_variant.and_then(|item| item["term"].as_str()));
    let term = locator_variant
        .and_then(|item| item["term"].as_u64())
        .or_else(|| locator["term"].as_u64())
        .map(|value| u8::try_from(value).expect("approved term fits u8"))
        .or_else(|| {
            term_descriptor
                .map(|value| u8::from(!(value.contains("0..21") || value.contains("slot"))))
        });
    let coordinate_descriptor = locator["coordinate"]
        .as_str()
        .or_else(|| locator_variant.and_then(|item| item["coordinate"].as_str()));
    let coordinate = if h1 || coordinate_descriptor.is_some_and(|value| value.contains("free_ids"))
    {
        Some(2)
    } else if coordinate_descriptor.is_some_and(|value| value.contains("term-1")) {
        term.and_then(|value| (value > 0).then(|| value - 1))
    } else if coordinate_descriptor.is_some_and(|value| value == "0..20") {
        Some(0)
    } else {
        None
    };
    let metadata = super::M1TrustRegionRefinementFailureMetadata {
        reason: m1_refinement_inventory_reason(reason),
        correction_position: position,
        guard_stage: m1_refinement_inventory_stage(stage),
        row: row_descriptor.map(|_| 0),
        term,
        coordinate,
        lower_active: [false; 21],
        upper_active: [false; 21],
        free: [true; 21],
        lambda: if entry["lambda"] == "positive" {
            1.0
        } else {
            0.0
        },
        original_trust_radius: 1.0,
        reduced_face_radius: 1.0,
        scratch_box_feasible: locator["scratch_box_feasible"].as_bool().or_else(|| {
            locator["scratch_box_feasible"]
                .as_array()
                .map(|_| entry["lambda"] == "positive")
        }),
    };
    refinement_capture_inventory_schema_locator_assertions(
        entry,
        locator,
        &metadata,
        row_descriptor,
        term_descriptor,
        coordinate_descriptor,
    );
}

#[cfg(test)]
fn refinement_capture_inventory_schema_entry(entry: &serde_json::Value) -> bool {
    for key in [
        "lambda",
        "position",
        "stage",
        "reason",
        "locator",
        "reached",
        "absent",
        "partial_roles",
    ] {
        assert!(entry.get(key).is_some(), "missing {key}");
    }
    assert!(entry["locator"].is_object());
    assert!(entry["reached"].is_array());
    assert!(entry["absent"].is_array());
    let stage = entry["stage"].as_str().expect("stage string");
    let reason = entry["reason"].as_str().expect("reason string");
    if stage == "not-applicable" {
        assert_eq!(entry["position"], "not-refinement");
        assert_eq!(reason, "not-applicable");
        return false;
    }
    assert_eq!(format!("{:?}", m1_refinement_inventory_stage(stage)), stage);
    assert_eq!(
        format!("{:?}", m1_refinement_inventory_reason(reason)),
        reason
    );
    let locator = &entry["locator"];
    let position = match entry["position"].as_str().expect("position string") {
        "None" => None,
        "First" => Some(super::M1TrustRegionCorrectionPosition::First),
        "Second" => Some(super::M1TrustRegionCorrectionPosition::Second),
        value => panic!("unknown position {value}"),
    };
    let alternatives = locator["variants"]
        .as_array()
        .or_else(|| locator["term_coordinate"].as_array());
    let locator_variants: Vec<_> =
        alternatives.map_or_else(|| vec![None], |items| items.iter().map(Some).collect());
    for locator_variant in locator_variants {
        refinement_capture_inventory_schema_locator_variant(
            entry,
            stage,
            reason,
            position,
            locator,
            locator_variant,
        );
    }
    true
}

#[cfg(test)]
fn refinement_capture_inventory_schema_terminal_rejections() {
    let metadata = super::M1TrustRegionRefinementFailureMetadata {
        reason: super::M1TrustRegionRefinementReason::NonfiniteOperand,
        correction_position: None,
        guard_stage: super::M1TrustRegionRefinementGuardStage::P0FullRadius,
        row: None,
        term: None,
        coordinate: None,
        lower_active: [false; 21],
        upper_active: [false; 21],
        free: [true; 21],
        lambda: 1.0,
        original_trust_radius: 1.0,
        reduced_face_radius: 1.0,
        scratch_box_feasible: None,
    };
    assert!(refinement_capture_selected_terminal_kind(
        &metadata,
        &RefinementObservationTrace::default()
    ));
    let mut impossible = metadata;
    impossible.reason = super::M1TrustRegionRefinementReason::SplitterOverflow;
    assert!(!refinement_capture_selected_terminal_kind(
        &impossible,
        &RefinementObservationTrace::default()
    ));
}

#[cfg(test)]
#[test]
fn m1_refinement_atomic_terminal_inventory_schema_control() {
    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory is valid JSON");
    let entries = inventory["entries"]
        .as_array()
        .expect("approved inventory entries array");
    assert_eq!(entries.len(), 109);
    let (refinement_rows, work_cap_rows) = entries.iter().fold((0, 0), |counts, entry| {
        if refinement_capture_inventory_schema_entry(entry) {
            (counts.0 + 1, counts.1)
        } else {
            (counts.0, counts.1 + 1)
        }
    });
    assert_eq!((refinement_rows, work_cap_rows), (107, 2));
    refinement_capture_inventory_schema_terminal_rejections();
}

/// Inventory semantics are an authority separate from the implementation
/// plan.  This control keeps the reviewed reached/absent/partial-role groups
/// exhaustive before any inert trace is projected through public statuses.
#[cfg(test)]
fn refinement_capture_inventory_known_semantic_groups() -> std::collections::BTreeSet<&'static str>
{
    std::collections::BTreeSet::from([
        "H/inverse",
        "app1 complete",
        "app1 inverse",
        "app1 inverse/delta",
        "app1 snapshot h",
        "app1 snapshot h=None",
        "app2 inverse",
        "app2 inverse/delta",
        "app2 snapshot h",
        "app2 snapshot h=None",
        "delta0",
        "delta0_bits",
        "delta1",
        "delta1_bits",
        "eligibility counters",
        "factor apps",
        "first correction complete",
        "h0/app1/delta0/p1/p2",
        "h0_bits",
        "h1/app2/delta1/p2",
        "h1_bits",
        "later",
        "later gap/tolerance",
        "later radius",
        "legacy inverse current snapshot",
        "live_state_entry_bits",
        "live_state_exit_bits",
        "lower_mask_exit",
        "lower_mask_p0",
        "p0 bits/masks",
        "p0 scalar norms/traces",
        "p0_bits",
        "p0_free and later",
        "p0_full scalars",
        "p0_full_norm2_bits",
        "p0_full_norm_bits",
        "p1 bits/masks",
        "p1 norm scalars",
        "p1 norms/p2",
        "p1/later",
        "p1/p2",
        "p2 bits/masks",
        "p2 free/later",
        "p2 full/free norms",
        "p2 norm scalar",
        "p2 norm/radius",
        "p2 zero trace",
        "p2/later",
        "positive fields",
        "positive fields/p2",
        "positive norm/H/inverse/radius fields",
        "radius_gap",
        "radius_tolerance",
        "remaining_radius",
        "reservation_denial_owner",
        "residual0/app1/delta0",
        "residual0/h0/app1/delta0/p1/p2",
        "residual0_bits",
        "residual1/h1/app2/delta1/p2",
        "residual1_bits",
        "second residual/app2/delta1",
        "terminal_refusal.refinement",
        "upper_mask_exit",
        "upper_mask_p0",
        "work_ledger",
    ])
}

#[cfg(test)]
fn refinement_capture_inventory_known_norm_role(role: &str) -> bool {
    matches!(
        role,
        "p0_full"
            | "p0_free"
            | "p0_zero_lambda_eligibility"
            | "p1_full"
            | "p1_free"
            | "p1_zero_lambda_scratch"
            | "p2_full"
            | "p2_free"
            | "p2_zero_lambda_final"
    )
}

#[cfg(test)]
fn refinement_capture_inventory_semantic_entry<'a>(
    entry: &'a serde_json::Value,
    known_groups: &std::collections::BTreeSet<&'static str>,
    reached_groups: &mut std::collections::BTreeSet<&'a str>,
    absent_groups: &mut std::collections::BTreeSet<&'a str>,
    partial_roles: &mut std::collections::BTreeSet<&'a str>,
) -> bool {
    let stage = entry["stage"].as_str().expect("stage");
    if stage == "not-applicable" {
        return false;
    }
    let reached = entry["reached"].as_array().expect("reached group");
    let absent = entry["absent"].as_array().expect("absent group");
    let partial = entry["partial_roles"].as_array().expect("partial roles");
    assert!(
        !reached.is_empty(),
        "row has no reached group: {}",
        entry["id"]
    );
    for value in reached {
        let group = value.as_str().expect("reached text");
        assert!(
            known_groups.contains(group),
            "unknown reached group: {group}"
        );
        reached_groups.insert(group);
    }
    for value in absent {
        let field = value.as_str().expect("absent text");
        assert!(
            known_groups.contains(field),
            "unknown absent group: {field}"
        );
        assert!(
            !reached.iter().any(|reached| reached == value),
            "field appears in both groups for {}: {field}",
            entry["id"]
        );
        absent_groups.insert(field);
    }
    for role in entry["completed_roles"]
        .as_array()
        .expect("completed roles")
    {
        let role = role.as_str().expect("completed role text");
        assert!(
            refinement_capture_inventory_known_norm_role(role),
            "unknown completed norm role: {role}"
        );
    }
    for role in partial {
        let role = role.as_str().expect("partial role text");
        assert!(
            refinement_capture_inventory_known_norm_role(role),
            "unknown partial norm role: {role}"
        );
        partial_roles.insert(role);
    }
    true
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_semantic_groups_control() {
    use std::collections::BTreeSet;

    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory is valid JSON");
    let entries = inventory["entries"].as_array().expect("inventory entries");
    let mut refinement_rows = 0;
    let mut work_cap_rows = 0;
    let mut reached_groups = BTreeSet::new();
    let mut absent_groups = BTreeSet::new();
    let mut partial_roles = BTreeSet::new();
    let known_groups = refinement_capture_inventory_known_semantic_groups();
    for entry in entries {
        if refinement_capture_inventory_semantic_entry(
            entry,
            &known_groups,
            &mut reached_groups,
            &mut absent_groups,
            &mut partial_roles,
        ) {
            refinement_rows += 1;
        } else {
            work_cap_rows += 1;
        }
    }
    assert_eq!((refinement_rows, work_cap_rows), (107, 2));
    assert!(reached_groups.contains("work_ledger"));
    assert!(reached_groups.contains("live_state_entry_bits"));
    assert!(absent_groups.iter().any(|field| field.contains("factor")));
    assert!(partial_roles.contains("p0_full"));
    assert!(partial_roles.contains("p1_full"));
    assert!(partial_roles.contains("p2_full"));
}

/// The inventory has compact semantic groups rather than an implementation
/// reach matrix.  Expand those groups here, independently of the resolved
/// terminal model, into the public projection names.  Keeping the expansion
/// group-oriented makes a new inventory term fail closed instead of silently
/// inheriting a nearby guard stage's status.
#[cfg(test)]
fn refinement_capture_inventory_application_copy_fields(
    group: &str,
) -> Option<&'static [&'static str]> {
    Some(match group {
        "first correction complete" | "app1 complete" => &[
            "residual0_bits",
            "h0_bits",
            "delta0_bits",
            "factor_identity",
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
            "factor_application_snapshot_1_h_bits",
            "factor_application_snapshot_1_inverse_t_bits",
            "factor_application_snapshot_1_inverse_denominator_bits",
            "factor_application_snapshot_1_inverse_z_bits",
            "factor_application_snapshot_1_delta_bits",
            "inverse_t_bits",
            "inverse_denominator_bits",
            "inverse_z_bits",
        ],
        "factor apps" => &[
            "factor_identity",
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
        ],
        "eligibility counters" => &["eligibility_scalar_operations", "eligibility_guard_events"],
        "reservation_denial_owner" => &["reservation_denial_owner"],
        "H/inverse" | "positive norm/H/inverse/radius fields" => &[
            "h0_bits",
            "h1_bits",
            "inverse_t_bits",
            "inverse_denominator_bits",
            "inverse_z_bits",
        ],
        "app1 inverse" => &[
            "factor_application_snapshot_1_inverse_t_bits",
            "factor_application_snapshot_1_inverse_denominator_bits",
            "factor_application_snapshot_1_inverse_z_bits",
            "inverse_t_bits",
            "inverse_denominator_bits",
            "inverse_z_bits",
        ],
        "app1 inverse/delta" => &[
            "factor_application_snapshot_1_inverse_t_bits",
            "factor_application_snapshot_1_inverse_denominator_bits",
            "factor_application_snapshot_1_inverse_z_bits",
            "factor_application_snapshot_1_delta_bits",
            "inverse_t_bits",
            "inverse_denominator_bits",
            "inverse_z_bits",
        ],
        "app2 inverse" => &[
            "factor_application_snapshot_2_inverse_t_bits",
            "factor_application_snapshot_2_inverse_denominator_bits",
            "factor_application_snapshot_2_inverse_z_bits",
            "inverse_t_bits",
            "inverse_denominator_bits",
            "inverse_z_bits",
        ],
        "app2 inverse/delta" => &[
            "factor_application_snapshot_2_inverse_t_bits",
            "factor_application_snapshot_2_inverse_denominator_bits",
            "factor_application_snapshot_2_inverse_z_bits",
            "factor_application_snapshot_2_delta_bits",
            "inverse_t_bits",
            "inverse_denominator_bits",
            "inverse_z_bits",
        ],
        _ => return None,
    })
}

#[cfg(test)]
fn refinement_capture_inventory_application_sequence_fields(
    group: &str,
) -> Option<&'static [&'static str]> {
    Some(match group {
        "app1 snapshot h" => &[
            "factor_identity",
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
            "factor_application_snapshot_1_h_bits",
        ],
        "app2 snapshot h" => &[
            "factor_identity",
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
            "factor_application_snapshot_2_h_bits",
        ],
        "residual0/app1/delta0" | "residual0/h0/app1/delta0/p1/p2" => &[
            "residual0_bits",
            "h0_bits",
            "delta0_bits",
            "factor_identity",
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
            "factor_application_snapshot_1_delta_bits",
        ],
        "second residual/app2/delta1" | "residual1/h1/app2/delta1/p2" => &[
            "residual1_bits",
            "h1_bits",
            "delta1_bits",
            "factor_identity",
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
            "factor_application_snapshot_2_delta_bits",
        ],
        _ => return None,
    })
}

#[cfg(test)]
fn refinement_capture_inventory_group_fields(group: &str) -> &'static [&'static str] {
    if let Some(fields) = refinement_capture_inventory_application_copy_fields(group) {
        return fields;
    }
    if let Some(fields) = refinement_capture_inventory_application_sequence_fields(group) {
        return fields;
    }
    match group {
        "p0 bits/masks" => &["p0_bits", "lower_mask_p0", "upper_mask_p0"],
        "p0_bits" => &["p0_bits"],
        "p1 bits/masks" => &["p1_bits", "lower_mask_p1", "upper_mask_p1"],
        "p2 bits/masks" => &["p2_bits", "lower_mask_p2", "upper_mask_p2"],
        "live_state_entry_bits" => &["live_state_entry_bits"],
        "live_state_exit_bits" => &["live_state_exit_bits"],
        "lower_mask_exit" => &["lower_mask_exit"],
        "upper_mask_exit" => &["upper_mask_exit"],
        "residual0_bits" => &["residual0_bits"],
        "residual1_bits" => &["residual1_bits"],
        "h0_bits" => &["h0_bits"],
        "h1_bits" => &["h1_bits"],
        "delta0" | "delta0_bits" => &["delta0_bits"],
        "delta1" | "delta1_bits" => &["delta1_bits"],
        "remaining_radius" => &["remaining_radius_bits"],
        "radius_gap" => &["radius_gap_bits"],
        "radius_tolerance" => &["radius_tolerance_bits"],
        "p0_full_norm2_bits" => &["p0_full_norm2_bits"],
        "p0_full_norm_bits" => &["p0_full_norm_bits"],
        "p0_full scalars" | "p0 scalar norms/traces" => &[
            "p0_full_norm2_bits",
            "p0_full_norm_bits",
            "ordered_norm_traces",
        ],
        "p1 norm scalars" => &["p1_full_norm2_bits", "p1_full_norm_bits"],
        "p2 norm scalar" | "p2 norm/radius" => &["p2_full_norm2_bits", "p2_full_norm_bits"],
        "p2 full/free norms" => &[
            "p2_full_norm2_bits",
            "p2_full_norm_bits",
            "p2_reduced_norm2_bits",
            "p2_reduced_norm_bits",
        ],
        "app1 snapshot h=None"
        | "app2 snapshot h=None"
        | "later"
        | "later gap/tolerance"
        | "later radius"
        | "p0_free and later"
        | "p1 norms/p2"
        | "p1/later"
        | "p1/p2"
        | "p2 free/later"
        | "p2 zero trace"
        | "p2/later"
        | "positive fields"
        | "positive fields/p2"
        | "terminal_refusal.refinement"
        | "work_ledger" => &[],
        "legacy inverse current snapshot" => &[
            "inverse_t_bits",
            "inverse_denominator_bits",
            "inverse_z_bits",
        ],
        "lower_mask_p0" => &["lower_mask_p0"],
        "upper_mask_p0" => &["upper_mask_p0"],
        value => panic!("unknown inventory semantic group: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_public_field_registry() -> &'static [&'static str] {
    &[
        "free_ids",
        "factor_order",
        "factor_a_bits",
        "factor_v_bits",
        "factor_sigma_bits",
        "weighted_residual_bits",
        "weighted_matrix_bits",
        "scaled_lower_bits",
        "scaled_upper_bits",
        "lambda_bits",
        "reduced_face_radius_bits",
        "live_state_entry_bits",
        "live_state_exit_bits",
        "lower_mask_exit",
        "upper_mask_exit",
        "factor_identity",
        "factor_application_identities",
        "factor_application_snapshots",
        "factor_output_copy_boundary",
        "factor_applications",
        "eligibility_scalar_operations",
        "eligibility_guard_events",
        "reservation_denial_owner",
        "p0_bits",
        "p0_full_norm2_bits",
        "p0_full_norm_bits",
        "p0_reduced_norm2_bits",
        "p0_reduced_norm_bits",
        "lower_mask_p0",
        "upper_mask_p0",
        "residual0_bits",
        "h0_bits",
        "delta0_bits",
        "p1_bits",
        "p1_full_norm2_bits",
        "p1_full_norm_bits",
        "p1_reduced_norm2_bits",
        "p1_reduced_norm_bits",
        "lower_mask_p1",
        "upper_mask_p1",
        "residual1_bits",
        "h1_bits",
        "delta1_bits",
        "p2_bits",
        "p2_full_norm2_bits",
        "p2_full_norm_bits",
        "p2_reduced_norm2_bits",
        "p2_reduced_norm_bits",
        "lower_mask_p2",
        "upper_mask_p2",
        "remaining_radius_bits",
        "radius_gap_bits",
        "radius_tolerance_bits",
        "factor_application_snapshot_1_h_bits",
        "factor_application_snapshot_1_inverse_t_bits",
        "factor_application_snapshot_1_inverse_denominator_bits",
        "factor_application_snapshot_1_inverse_z_bits",
        "factor_application_snapshot_1_delta_bits",
        "factor_application_snapshot_2_h_bits",
        "factor_application_snapshot_2_inverse_t_bits",
        "factor_application_snapshot_2_inverse_denominator_bits",
        "factor_application_snapshot_2_inverse_z_bits",
        "factor_application_snapshot_2_delta_bits",
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
        "ordered_norm_traces",
        "partial_ordered_norms",
    ]
}

/// The independent inventory oracle consumes the implementation registry only
/// as a complete public-key shape check; it never supplies reachability.
/// This literal is transcribed from the retained checkpoint03 baseline key
/// extraction. It is intentionally independent from the implementation
/// registry: either side changing requires an explicit semantic disposition.
#[cfg(test)]
fn refinement_capture_inventory_public_fields() -> &'static [&'static str] {
    &[
        "free_ids",
        "factor_order",
        "factor_a_bits",
        "factor_v_bits",
        "factor_sigma_bits",
        "weighted_residual_bits",
        "weighted_matrix_bits",
        "scaled_lower_bits",
        "scaled_upper_bits",
        "lambda_bits",
        "reduced_face_radius_bits",
        "live_state_entry_bits",
        "live_state_exit_bits",
        "lower_mask_exit",
        "upper_mask_exit",
        "factor_identity",
        "factor_application_identities",
        "factor_application_snapshots",
        "factor_output_copy_boundary",
        "factor_applications",
        "eligibility_scalar_operations",
        "eligibility_guard_events",
        "reservation_denial_owner",
        "p0_bits",
        "p0_full_norm2_bits",
        "p0_full_norm_bits",
        "p0_reduced_norm2_bits",
        "p0_reduced_norm_bits",
        "lower_mask_p0",
        "upper_mask_p0",
        "residual0_bits",
        "h0_bits",
        "delta0_bits",
        "p1_bits",
        "p1_full_norm2_bits",
        "p1_full_norm_bits",
        "p1_reduced_norm2_bits",
        "p1_reduced_norm_bits",
        "lower_mask_p1",
        "upper_mask_p1",
        "residual1_bits",
        "h1_bits",
        "delta1_bits",
        "p2_bits",
        "p2_full_norm2_bits",
        "p2_full_norm_bits",
        "p2_reduced_norm2_bits",
        "p2_reduced_norm_bits",
        "lower_mask_p2",
        "upper_mask_p2",
        "remaining_radius_bits",
        "radius_gap_bits",
        "radius_tolerance_bits",
        "factor_application_snapshot_1_h_bits",
        "factor_application_snapshot_1_inverse_t_bits",
        "factor_application_snapshot_1_inverse_denominator_bits",
        "factor_application_snapshot_1_inverse_z_bits",
        "factor_application_snapshot_1_delta_bits",
        "factor_application_snapshot_2_h_bits",
        "factor_application_snapshot_2_inverse_t_bits",
        "factor_application_snapshot_2_inverse_denominator_bits",
        "factor_application_snapshot_2_inverse_z_bits",
        "factor_application_snapshot_2_delta_bits",
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
        "ordered_norm_traces",
        "partial_ordered_norms",
    ]
}

#[cfg(test)]
fn refinement_capture_inventory_public_keyset_is_baseline_exact() -> bool {
    let inventory = refinement_capture_inventory_public_fields();
    let implementation = refinement_capture_public_field_registry();
    inventory.len() == 68
        && inventory.len() == implementation.len()
        && inventory.iter().all(|name| implementation.contains(name))
        && implementation.iter().all(|name| inventory.contains(name))
}

#[cfg(test)]
fn refinement_capture_inventory_zero_lambda_field(name: &str) -> bool {
    matches!(
        name,
        "p0_full_norm2_bits"
            | "p0_full_norm_bits"
            | "p0_reduced_norm2_bits"
            | "p0_reduced_norm_bits"
            | "p1_full_norm2_bits"
            | "p1_full_norm_bits"
            | "p1_reduced_norm2_bits"
            | "p1_reduced_norm_bits"
            | "p2_full_norm2_bits"
            | "p2_full_norm_bits"
            | "p2_reduced_norm2_bits"
            | "p2_reduced_norm_bits"
    ) || name.starts_with('h')
        || name.starts_with("inverse_")
        || name.starts_with("factor_application_snapshot_") && name.contains("inverse")
        || name.ends_with("_h_bits")
}

/// The approved public inventory is intentionally literal, so each member has
/// an explicit semantic disposition before row-specific reachability is
/// expanded.  A new key must join one of these classes rather than silently
/// inheriting natural absence from an implementation registry change.
#[cfg(test)]
fn refinement_capture_inventory_initial_status(name: &str, zero_lambda: bool) -> &'static str {
    match name {
        "free_ids"
        | "factor_order"
        | "factor_a_bits"
        | "factor_v_bits"
        | "factor_sigma_bits"
        | "weighted_residual_bits"
        | "weighted_matrix_bits"
        | "scaled_lower_bits"
        | "scaled_upper_bits"
        | "lambda_bits"
        | "reduced_face_radius_bits"
        | "live_state_entry_bits"
        | "live_state_exit_bits"
        | "lower_mask_exit"
        | "upper_mask_exit" => "captured",
        "p0_full_norm2_bits"
        | "p0_full_norm_bits"
        | "p0_reduced_norm2_bits"
        | "p0_reduced_norm_bits"
        | "p1_full_norm2_bits"
        | "p1_full_norm_bits"
        | "p1_reduced_norm2_bits"
        | "p1_reduced_norm_bits"
        | "p2_full_norm2_bits"
        | "p2_full_norm_bits"
        | "p2_reduced_norm2_bits"
        | "p2_reduced_norm_bits"
        | "h0_bits"
        | "h1_bits"
        | "inverse_t_bits"
        | "inverse_denominator_bits"
        | "inverse_z_bits"
        | "factor_application_snapshot_1_h_bits"
        | "factor_application_snapshot_1_inverse_t_bits"
        | "factor_application_snapshot_1_inverse_denominator_bits"
        | "factor_application_snapshot_1_inverse_z_bits"
        | "factor_application_snapshot_2_h_bits"
        | "factor_application_snapshot_2_inverse_t_bits"
        | "factor_application_snapshot_2_inverse_denominator_bits"
        | "factor_application_snapshot_2_inverse_z_bits" => {
            if zero_lambda {
                "inapplicable_zero_lambda"
            } else {
                "naturally_unreached"
            }
        }
        "reservation_denial_owner"
        | "factor_identity"
        | "factor_application_identities"
        | "factor_application_snapshots"
        | "factor_output_copy_boundary"
        | "factor_applications"
        | "eligibility_scalar_operations"
        | "eligibility_guard_events"
        | "p0_bits"
        | "lower_mask_p0"
        | "upper_mask_p0"
        | "residual0_bits"
        | "delta0_bits"
        | "p1_bits"
        | "lower_mask_p1"
        | "upper_mask_p1"
        | "residual1_bits"
        | "delta1_bits"
        | "p2_bits"
        | "lower_mask_p2"
        | "upper_mask_p2"
        | "remaining_radius_bits"
        | "radius_gap_bits"
        | "radius_tolerance_bits"
        | "factor_application_snapshot_1_delta_bits"
        | "factor_application_snapshot_2_delta_bits"
        | "ordered_norm_traces"
        | "partial_ordered_norms" => "naturally_unreached",
        value => panic!("unknown approved inventory public field semantic: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_role_scalar_fields(role: &str) -> &'static [&'static str] {
    match role {
        "p0_full" => &["p0_full_norm2_bits", "p0_full_norm_bits"],
        "p0_free" => &["p0_reduced_norm2_bits", "p0_reduced_norm_bits"],
        "p1_full" => &["p1_full_norm2_bits", "p1_full_norm_bits"],
        "p1_free" => &["p1_reduced_norm2_bits", "p1_reduced_norm_bits"],
        "p2_full" => &["p2_full_norm2_bits", "p2_full_norm_bits"],
        "p2_free" => &["p2_reduced_norm2_bits", "p2_reduced_norm_bits"],
        "p0_zero_lambda_eligibility" | "p1_zero_lambda_scratch" | "p2_zero_lambda_final" => &[],
        _ => panic!("unknown inventory norm role: {role}"),
    }
}

/// Independent expected public statuses for an approved inventory row.  This
/// consumes only the inventory's semantic vocabulary and its norm-role lists;
/// it deliberately neither constructs nor consults a resolved terminal.
#[cfg(test)]
fn refinement_capture_inventory_capture(
    fields: &mut serde_json::Map<String, serde_json::Value>,
    name: &str,
) {
    fields.insert(name.into(), serde_json::Value::String("captured".into()));
}

#[cfg(test)]
fn refinement_capture_inventory_initial_statuses(
    zero_lambda: bool,
) -> serde_json::Map<String, serde_json::Value> {
    refinement_capture_inventory_public_fields()
        .iter()
        .map(|name| {
            (
                (*name).into(),
                serde_json::Value::String(
                    refinement_capture_inventory_initial_status(name, zero_lambda).into(),
                ),
            )
        })
        .collect()
}

#[cfg(test)]
fn refinement_capture_inventory_apply_reached_groups(
    entry: &serde_json::Value,
    zero_lambda: bool,
    fields: &mut serde_json::Map<String, serde_json::Value>,
) {
    for group in entry["reached"]
        .as_array()
        .expect("approved reached groups")
    {
        let group = group.as_str().expect("approved reached group text");
        for name in refinement_capture_inventory_group_fields(group) {
            if !(zero_lambda && refinement_capture_inventory_zero_lambda_field(name)) {
                refinement_capture_inventory_capture(fields, name);
            }
        }
    }
}

#[cfg(test)]
fn refinement_capture_inventory_apply_norm_statuses(
    entry: &serde_json::Value,
    fields: &mut serde_json::Map<String, serde_json::Value>,
) {
    let completed = entry["completed_roles"]
        .as_array()
        .expect("completed roles");
    let partial = entry["partial_roles"].as_array().expect("partial roles");
    if !completed.is_empty() {
        refinement_capture_inventory_capture(fields, "ordered_norm_traces");
    }
    if !partial.is_empty() {
        refinement_capture_inventory_capture(fields, "partial_ordered_norms");
    }
    for role in completed {
        for name in refinement_capture_inventory_role_scalar_fields(role.as_str().expect("role")) {
            refinement_capture_inventory_capture(fields, name);
        }
    }
    for role in partial {
        for name in refinement_capture_inventory_role_scalar_fields(role.as_str().expect("role")) {
            fields.insert(
                (*name).into(),
                serde_json::Value::String("interrupted".into()),
            );
        }
    }
    let role_names: Vec<_> = completed
        .iter()
        .chain(partial)
        .map(|role| role.as_str().expect("role"))
        .collect();
    for (prefix, fields_for_vector) in [
        ("p0_", ["p0_bits", "lower_mask_p0", "upper_mask_p0"]),
        ("p1_", ["p1_bits", "lower_mask_p1", "upper_mask_p1"]),
        ("p2_", ["p2_bits", "lower_mask_p2", "upper_mask_p2"]),
    ] {
        if role_names.iter().any(|role| role.starts_with(prefix)) {
            for name in fields_for_vector {
                refinement_capture_inventory_capture(fields, name);
            }
        }
    }
}

#[cfg(test)]
fn refinement_capture_inventory_apply_completed_applications(
    entry: &serde_json::Value,
    fields: &mut serde_json::Map<String, serde_json::Value>,
) {
    for ordinal in [1_u8, 2_u8] {
        let completed = if ordinal == 1 {
            entry["position"] == "Second"
                || fields["p1_bits"] == "captured"
                || fields["delta0_bits"] == "captured"
        } else {
            fields["p2_bits"] == "captured" || fields["delta1_bits"] == "captured"
        };
        if !completed {
            continue;
        }
        for name in if ordinal == 1 {
            ["residual0_bits", "delta0_bits"]
        } else {
            ["residual1_bits", "delta1_bits"]
        } {
            refinement_capture_inventory_capture(fields, name);
        }
        if entry["lambda"] == "positive" {
            refinement_capture_inventory_capture(
                fields,
                if ordinal == 1 { "h0_bits" } else { "h1_bits" },
            );
            for suffix in [
                "h_bits",
                "inverse_t_bits",
                "inverse_denominator_bits",
                "inverse_z_bits",
            ] {
                refinement_capture_inventory_capture(
                    fields,
                    &format!("factor_application_snapshot_{ordinal}_{suffix}"),
                );
            }
        }
        refinement_capture_inventory_capture(
            fields,
            &format!("factor_application_snapshot_{ordinal}_delta_bits"),
        );
        for name in [
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
        ] {
            refinement_capture_inventory_capture(fields, name);
        }
        if entry["lambda"] == "positive" {
            for name in [
                "inverse_t_bits",
                "inverse_denominator_bits",
                "inverse_z_bits",
            ] {
                refinement_capture_inventory_capture(fields, name);
            }
        }
    }
}

#[cfg(test)]
fn refinement_capture_inventory_apply_terminal_statuses(
    entry: &serde_json::Value,
    fields: &mut serde_json::Map<String, serde_json::Value>,
) {
    if entry["position"] != "None" {
        for name in [
            "eligibility_scalar_operations",
            "eligibility_guard_events",
            "factor_identity",
        ] {
            refinement_capture_inventory_capture(fields, name);
        }
    }
    let reached = entry["reached"].as_array().expect("reached groups");
    if reached
        .iter()
        .any(|group| group == "delta1" || group == "delta1_bits")
    {
        for name in [
            "factor_application_identities",
            "factor_application_snapshots",
            "factor_output_copy_boundary",
            "factor_applications",
            "factor_application_snapshot_2_delta_bits",
        ] {
            refinement_capture_inventory_capture(fields, name);
        }
        if entry["lambda"] == "positive" {
            for name in [
                "h1_bits",
                "factor_application_snapshot_2_h_bits",
                "factor_application_snapshot_2_inverse_t_bits",
                "factor_application_snapshot_2_inverse_denominator_bits",
                "factor_application_snapshot_2_inverse_z_bits",
                "inverse_t_bits",
                "inverse_denominator_bits",
                "inverse_z_bits",
            ] {
                refinement_capture_inventory_capture(fields, name);
            }
        }
    }
    if entry["stage"] == "FinalReducedRadius" {
        refinement_capture_inventory_capture(fields, "remaining_radius_bits");
    }
    if entry["stage"] == "FactorApplicationOutput" {
        refinement_capture_inventory_apply_factor_output_statuses(entry, fields);
    }
}

#[cfg(test)]
fn refinement_capture_inventory_apply_factor_output_statuses(
    entry: &serde_json::Value,
    fields: &mut serde_json::Map<String, serde_json::Value>,
) {
    use serde_json::Value;

    let ordinal = if entry["position"] == "Second" { 2 } else { 1 };
    for name in [
        "factor_identity",
        "factor_application_identities",
        "factor_application_snapshots",
        "factor_output_copy_boundary",
        "factor_applications",
    ] {
        refinement_capture_inventory_capture(fields, name);
    }
    if entry["lambda"] == "positive" {
        refinement_capture_inventory_capture(
            fields,
            if ordinal == 1 { "h0_bits" } else { "h1_bits" },
        );
        refinement_capture_inventory_capture(
            fields,
            &format!("factor_application_snapshot_{ordinal}_h_bits"),
        );
    }
    let delta_name = if ordinal == 1 {
        "delta0_bits"
    } else {
        "delta1_bits"
    };
    if fields[delta_name] == "captured" {
        refinement_capture_inventory_capture(
            fields,
            &format!("factor_application_snapshot_{ordinal}_delta_bits"),
        );
    }
    for name in [
        delta_name,
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
    ] {
        if fields[name] == "naturally_unreached" {
            fields.insert(name.into(), Value::String("interrupted".into()));
        }
    }
    for suffix in [
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
        "delta_bits",
    ] {
        let name = format!("factor_application_snapshot_{ordinal}_{suffix}");
        if fields[&name] == "naturally_unreached" {
            fields.insert(name, Value::String("interrupted".into()));
        }
    }
}

#[cfg(test)]
fn refinement_capture_inventory_expected_statuses(entry: &serde_json::Value) -> serde_json::Value {
    use serde_json::Value;

    assert!(
        refinement_capture_inventory_public_keyset_is_baseline_exact(),
        "public status keys differ from the retained checkpoint03 baseline"
    );
    let zero_lambda = entry["lambda"] == "zero";
    let mut fields = refinement_capture_inventory_initial_statuses(zero_lambda);
    refinement_capture_inventory_apply_reached_groups(entry, zero_lambda, &mut fields);
    refinement_capture_inventory_apply_norm_statuses(entry, &mut fields);
    refinement_capture_inventory_apply_completed_applications(entry, &mut fields);
    refinement_capture_inventory_apply_terminal_statuses(entry, &mut fields);
    Value::Object(fields)
}

#[cfg(test)]
fn refinement_capture_inventory_domain_metadata(
    entry: &serde_json::Value,
    locator: &RefinementCaptureInventoryLocator,
) -> super::M1TrustRegionRefinementFailureMetadata {
    use super::M1TrustRegionCorrectionPosition as Position;

    let position = match entry["position"].as_str().expect("position") {
        "None" => None,
        "First" => Some(Position::First),
        "Second" => Some(Position::Second),
        value => panic!("unknown approved position {value}"),
    };
    let free = locator
        .coordinate
        .is_some()
        .then_some([2, 5, 9])
        .map_or([true; 21], |ids| {
            let mut mask = [false; 21];
            for id in ids {
                mask[id] = true;
            }
            mask
        });
    super::M1TrustRegionRefinementFailureMetadata {
        reason: m1_refinement_inventory_reason(entry["reason"].as_str().expect("reason")),
        correction_position: position,
        guard_stage: m1_refinement_inventory_stage(entry["stage"].as_str().expect("stage")),
        row: locator.row,
        term: locator.term,
        coordinate: locator.coordinate,
        lower_active: [false; 21],
        upper_active: [false; 21],
        free,
        lambda: if entry["lambda"] == "positive" {
            1.0
        } else {
            0.0
        },
        original_trust_radius: 1.0,
        reduced_face_radius: 1.0,
        scratch_box_feasible: locator.scratch_box_feasible,
    }
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementCaptureInventoryLocator {
    id: String,
    row: Option<u8>,
    term: Option<u8>,
    coordinate: Option<u8>,
    scratch_box_feasible: Option<bool>,
    partial_operation: Option<&'static str>,
}

#[cfg(test)]
fn refinement_capture_inventory_domain_values(
    descriptor: Option<&str>,
    term: Option<u8>,
    slot_index: bool,
) -> Vec<Option<u8>> {
    match descriptor {
        Some(value) if value.contains("0..20") => (0..21).map(Some).collect(),
        Some(value) if value.contains("free_ids") && slot_index => term
            .and_then(|slot| [2, 5, 9].get(usize::from(slot)).copied())
            .map_or_else(|| vec![None], |coordinate| vec![Some(coordinate)]),
        Some(value) if value.contains("free_ids") => vec![Some(2), Some(5), Some(9)],
        Some(value) if value.contains("term-1") => {
            vec![term.and_then(|item| (item > 0).then_some(item - 1))]
        }
        _ => vec![None],
    }
}

#[cfg(test)]
fn refinement_capture_inventory_domain_terms(descriptor: Option<&str>) -> Vec<Option<u8>> {
    match descriptor {
        Some(value) if value.contains("0..21") => (0..=21).map(Some).collect(),
        Some(value) if value.contains("1..21") && value.contains("null") => {
            std::iter::once(None).chain((1..=21).map(Some)).collect()
        }
        Some(value) if value.contains("1..21") => (1..=21).map(Some).collect(),
        Some(value) if value.contains("slot") => (0..3).map(Some).collect(),
        _ => vec![None],
    }
}

#[cfg(test)]
fn refinement_capture_inventory_locator_domain(
    entry: &serde_json::Value,
) -> Vec<RefinementCaptureInventoryLocator> {
    let locator = &entry["locator"];
    let alternatives: Vec<_> = locator["variants"]
        .as_array()
        .or_else(|| locator["term_coordinate"].as_array())
        .map_or_else(|| vec![None], |items| items.iter().map(Some).collect());
    let scratches: Vec<_> = locator["scratch_box_feasible"].as_array().map_or_else(
        || vec![locator["scratch_box_feasible"].as_bool()],
        |items| items.iter().map(serde_json::Value::as_bool).collect(),
    );
    let operations: Vec<_> = entry["partial_operations_exact"].as_array().map_or_else(
        || vec![None],
        |items| {
            if items.is_empty() {
                vec![None]
            } else {
                items.iter().map(serde_json::Value::as_str).collect()
            }
        },
    );
    let mut out = Vec::new();
    for (alternative_index, alternative) in alternatives.into_iter().enumerate() {
        let text = |name: &str| {
            alternative
                .and_then(|item| item[name].as_str())
                .or_else(|| locator[name].as_str())
        };
        let rows: Vec<_> = text("row").map_or_else(|| vec![None], |_| (0..21).map(Some).collect());
        let numeric_term = alternative
            .and_then(|item| item["term"].as_u64())
            .or_else(|| locator["term"].as_u64())
            .map(|value| u8::try_from(value).expect("approved numeric term"));
        let terms = numeric_term.map_or_else(
            || refinement_capture_inventory_domain_terms(text("term")),
            |term| vec![Some(term)],
        );
        let slot_index = text("term").is_some_and(|value| value.contains("slot"));
        for row in rows {
            for term in &terms {
                for coordinate in refinement_capture_inventory_domain_values(
                    text("coordinate"),
                    *term,
                    slot_index,
                ) {
                    for scratch in &scratches {
                        for operation in &operations {
                            out.push(RefinementCaptureInventoryLocator {
                                id: format!(
                                    "{}:a{alternative_index}:r{row:?}:t{term:?}:c{coordinate:?}:s{scratch:?}:o{operation:?}",
                                    entry["id"]
                                ),
                                row,
                                term: *term,
                                coordinate,
                                scratch_box_feasible: *scratch,
                                partial_operation: operation.map(refinement_capture_inventory_static_operation),
                            });
                        }
                    }
                }
            }
        }
    }
    out
}

#[cfg(test)]
fn refinement_capture_inventory_captured(expected: &serde_json::Value, name: &str) -> bool {
    expected[name] == "captured"
}

#[cfg(test)]
fn refinement_capture_inventory_role_values(
    trace: &RefinementObservationTrace,
    role: &str,
) -> [f64; 21] {
    match role {
        "p0_full" | "p0_free" | "p0_zero_lambda_eligibility" => trace.p0.unwrap_or([0.0; 21]),
        "p1_full" | "p1_free" | "p1_zero_lambda_scratch" => trace.p1.unwrap_or([0.0; 21]),
        "p2_full" | "p2_free" | "p2_zero_lambda_final" => trace.p2.unwrap_or([0.0; 21]),
        _ => panic!("unknown inventory role values: {role}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_static_role(role: &str) -> &'static str {
    match role {
        "p0_full" => "p0_full",
        "p0_free" => "p0_free",
        "p0_zero_lambda_eligibility" => "p0_zero_lambda_eligibility",
        "p1_full" => "p1_full",
        "p1_free" => "p1_free",
        "p1_zero_lambda_scratch" => "p1_zero_lambda_scratch",
        "p2_full" => "p2_full",
        "p2_free" => "p2_free",
        "p2_zero_lambda_final" => "p2_zero_lambda_final",
        value => panic!("unknown inventory norm role: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_static_operation(operation: &str) -> &'static str {
    match operation {
        "square_guard" => "square_guard",
        "running_sum_guard" => "running_sum_guard",
        value => panic!("unknown partial operation: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_norms(
    trace: &mut RefinementObservationTrace,
    entry: &serde_json::Value,
    partial_operation: Option<&str>,
) {
    for role in entry["completed_roles"]
        .as_array()
        .expect("completed roles")
    {
        let role = refinement_capture_inventory_static_role(role.as_str().expect("role"));
        let values = refinement_capture_inventory_role_values(trace, role);
        let mut norm = refinement_capture_complete_norm(role, &values);
        if matches!(role, "p0_free" | "p1_free" | "p2_free") {
            let ids = trace.face_free_ids.as_ref().expect("free ids");
            let selected: Vec<_> = ids.iter().map(|id| values[*id]).collect();
            norm = refinement_capture_complete_norm(role, &selected);
            norm.coordinate_ids = ids.clone();
        }
        trace.ordered_norms.push(norm);
    }
    for role in entry["partial_roles"].as_array().expect("partial roles") {
        let role = refinement_capture_inventory_static_role(role.as_str().expect("role"));
        let values = refinement_capture_inventory_role_values(trace, role);
        let value = values[0];
        let operation = refinement_capture_inventory_static_operation(
            partial_operation.expect("expanded partial operation"),
        );
        trace
            .partial_ordered_norms
            .push(RefinementPartialOrderedNormTrace {
                role,
                coordinate_ids: vec![0],
                value_bits: vec![value.to_bits()],
                square_bits: vec![(value * value).to_bits()],
                running_sum_bits: (operation == "running_sum_guard")
                    .then_some(vec![(value * value).to_bits()])
                    .unwrap_or_default(),
                terminal_operation: operation,
                sqrt_bits: None,
            });
    }
}

#[cfg(test)]
fn refinement_capture_inventory_scalar_norms(
    trace: &mut RefinementObservationTrace,
    expected: &serde_json::Value,
) {
    let norms: std::collections::BTreeMap<_, _> = trace
        .ordered_norms
        .iter()
        .map(|entry| {
            (
                entry.role,
                (
                    f64::from_bits(entry.norm2_bits),
                    f64::from_bits(entry.norm_bits),
                ),
            )
        })
        .collect();
    let scalar = |role, name| {
        refinement_capture_inventory_captured(expected, name)
            .then(|| *norms.get(role).expect("captured scalar has completed norm"))
    };
    (trace.p0_full_norm2, trace.p0_full_norm) = (
        scalar("p0_full", "p0_full_norm2_bits").map(|item| item.0),
        scalar("p0_full", "p0_full_norm_bits").map(|item| item.1),
    );
    (trace.p0_reduced_norm2, trace.p0_reduced_norm) = (
        scalar("p0_free", "p0_reduced_norm2_bits").map(|item| item.0),
        scalar("p0_free", "p0_reduced_norm_bits").map(|item| item.1),
    );
    (trace.p1_full_norm2, trace.p1_full_norm) = (
        scalar("p1_full", "p1_full_norm2_bits").map(|item| item.0),
        scalar("p1_full", "p1_full_norm_bits").map(|item| item.1),
    );
    (trace.p1_reduced_norm2, trace.p1_reduced_norm) = (
        scalar("p1_free", "p1_reduced_norm2_bits").map(|item| item.0),
        scalar("p1_free", "p1_reduced_norm_bits").map(|item| item.1),
    );
    (trace.p2_full_norm2, trace.p2_full_norm) = (
        scalar("p2_full", "p2_full_norm2_bits").map(|item| item.0),
        scalar("p2_full", "p2_full_norm_bits").map(|item| item.1),
    );
    (trace.p2_reduced_norm2, trace.p2_reduced_norm) = (
        scalar("p2_free", "p2_reduced_norm2_bits").map(|item| item.0),
        scalar("p2_free", "p2_reduced_norm_bits").map(|item| item.1),
    );
}

#[cfg(test)]
fn refinement_capture_inventory_steps(
    trace: &mut RefinementObservationTrace,
    expected: &serde_json::Value,
    zero_lambda: bool,
    refusing_terminal: bool,
) {
    let interior = if refusing_terminal { 1.0 } else { 0.125 };
    let p0 = if zero_lambda {
        [0.0; 21]
    } else {
        [interior; 21]
    };
    let p1 = [interior; 21];
    let p2 = [interior; 21];
    trace.p0 = refinement_capture_inventory_captured(expected, "p0_bits").then_some(p0);
    trace.lower_mask_p0 =
        refinement_capture_inventory_captured(expected, "lower_mask_p0").then_some([false; 21]);
    trace.upper_mask_p0 =
        refinement_capture_inventory_captured(expected, "upper_mask_p0").then_some([false; 21]);
    trace.residual0 =
        refinement_capture_inventory_captured(expected, "residual0_bits").then_some([0.0; 21]);
    trace.h0 = refinement_capture_inventory_captured(expected, "h0_bits").then_some(vec![1.0; 21]);
    trace.delta0 =
        refinement_capture_inventory_captured(expected, "delta0_bits").then_some(vec![2.0; 21]);
    trace.p1 = refinement_capture_inventory_captured(expected, "p1_bits").then_some(p1);
    trace.lower_mask_p1 =
        refinement_capture_inventory_captured(expected, "lower_mask_p1").then_some([false; 21]);
    trace.upper_mask_p1 =
        refinement_capture_inventory_captured(expected, "upper_mask_p1").then_some([false; 21]);
    trace.residual1 =
        refinement_capture_inventory_captured(expected, "residual1_bits").then_some([0.0; 21]);
    trace.h1 = refinement_capture_inventory_captured(expected, "h1_bits").then_some(vec![3.0; 21]);
    trace.delta1 =
        refinement_capture_inventory_captured(expected, "delta1_bits").then_some(vec![8.0; 21]);
    trace.p2 = refinement_capture_inventory_captured(expected, "p2_bits").then_some(p2);
    trace.lower_mask_p2 =
        refinement_capture_inventory_captured(expected, "lower_mask_p2").then_some([false; 21]);
    trace.upper_mask_p2 =
        refinement_capture_inventory_captured(expected, "upper_mask_p2").then_some([false; 21]);
    trace.remaining_radius =
        refinement_capture_inventory_captured(expected, "remaining_radius_bits").then_some(9.0);
    trace.radius_gap =
        refinement_capture_inventory_captured(expected, "radius_gap_bits").then_some(1.0);
    trace.radius_tolerance =
        refinement_capture_inventory_captured(expected, "radius_tolerance_bits").then_some(0.5);
}

#[cfg(test)]
fn refinement_capture_inventory_trace(
    entry: &serde_json::Value,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    partial_operation: Option<&str>,
) -> RefinementObservationTrace {
    let expected = refinement_capture_inventory_expected_statuses(entry);
    let full: Vec<_> = if metadata.coordinate.is_some() {
        vec![2, 5, 9]
    } else {
        (0..21).collect()
    };
    let width = full.len();
    let mut free_mask = [true; 21];
    if width < 21 {
        free_mask = [false; 21];
        for id in &full {
            free_mask[*id] = true;
        }
    }
    let held_mask = [false; 21];
    let mut trace = RefinementObservationTrace {
        face_free_ids: Some(full.clone()),
        factor_order: Some((0..width).collect()),
        factor_a: Some(vec![vec![0.0; width]; 21]),
        factor_v: Some(vec![vec![0.0; width]; width]),
        factor_sigma: Some(vec![0.0; width]),
        weighted_residual: Some(vec![0.0; 21]),
        weighted_matrix: Some(vec![vec![0.0; 21]; 21]),
        scaled_lower_bits: Some([0; 21]),
        scaled_upper_bits: Some([0; 21]),
        lambda_bits: Some(metadata.lambda.to_bits()),
        reduced_face_radius_bits: Some(metadata.reduced_face_radius.to_bits()),
        free_mask: Some(free_mask),
        held_mask: Some(held_mask),
        live_state_entry: Some([0; 21]),
        live_state_exit: Some([0; 21]),
        lower_mask_exit: Some([false; 21]),
        upper_mask_exit: Some([false; 21]),
        work: Some(super::M1TrustRegionWorkObservation::default()),
        terminal_refusal: Some(Box::new(refinement_capture_terminal_refusal(metadata))),
        ..Default::default()
    };
    let refusing_terminal = matches!(
        entry["stage"].as_str(),
        Some(
            "P0FullRadius"
                | "P0ReducedRadius"
                | "ScratchFullRadius"
                | "ScratchReducedRadius"
                | "FinalFullRadius"
                | "FinalReducedRadius"
                | "RadiusComparison"
        )
    ) && matches!(
        entry["reason"].as_str(),
        Some("FinalRadius" | "ScratchRadius")
    );
    refinement_capture_inventory_steps(
        &mut trace,
        &expected,
        metadata.lambda == 0.0,
        refusing_terminal,
    );
    if width < 21 {
        trace.h0 = trace.h0.as_ref().map(|_| vec![1.0; width]);
        trace.h1 = trace.h1.as_ref().map(|_| vec![3.0; width]);
        trace.delta0 = trace.delta0.as_ref().map(|_| vec![2.0; width]);
        trace.delta1 = trace.delta1.as_ref().map(|_| vec![8.0; width]);
    }
    trace.eligibility_scalar_operations =
        refinement_capture_inventory_captured(&expected, "eligibility_scalar_operations")
            .then_some(0);
    trace.eligibility_guard_events =
        refinement_capture_inventory_captured(&expected, "eligibility_guard_events").then_some(0);
    trace.factor_identity =
        refinement_capture_inventory_captured(&expected, "factor_identity").then_some(7);
    refinement_capture_inventory_norms(&mut trace, entry, partial_operation);
    refinement_capture_inventory_scalar_norms(&mut trace, &expected);
    if matches!(
        entry["stage"].as_str(),
        Some("FinalReducedRadius" | "FinalRadiusCloseness")
    ) {
        let radius = metadata.reduced_face_radius;
        trace.remaining_radius = Some(radius);
        if entry["stage"] == "FinalRadiusCloseness" {
            let free_norm = trace.p2_reduced_norm.expect("final free norm");
            trace.radius_gap = Some(radius - free_norm);
            trace.radius_tolerance =
                Some((2_f64.powi(-40) * radius).max(64.0 * f64::EPSILON * radius.max(1.0)));
        }
    }
    refinement_capture_inventory_factor_applications(&mut trace, &expected, metadata, entry);
    trace
}

#[cfg(test)]
fn refinement_capture_inventory_expected_application_count(
    expected: &serde_json::Value,
    entry: &serde_json::Value,
) -> u8 {
    let present = |name| refinement_capture_inventory_captured(expected, name);
    let second = [
        "factor_application_snapshot_2_h_bits",
        "factor_application_snapshot_2_inverse_t_bits",
        "factor_application_snapshot_2_delta_bits",
        "delta1_bits",
    ]
    .into_iter()
    .any(&present);
    let first = second
        || [
            "factor_application_snapshot_1_h_bits",
            "factor_application_snapshot_1_inverse_t_bits",
            "factor_application_snapshot_1_delta_bits",
            "delta0_bits",
            "factor_application_snapshots",
        ]
        .into_iter()
        .any(present);
    let factor_output = entry["stage"] == "FactorApplicationOutput";
    if factor_output {
        if entry["position"] == "Second" { 2 } else { 1 }
    } else {
        u8::from(first) + u8::from(second)
    }
}

#[cfg(test)]
fn refinement_capture_inventory_application_snapshot(
    ordinal: u8,
    width: usize,
    positive_lambda: bool,
) -> RefinementFactorApplicationSnapshot {
    RefinementFactorApplicationSnapshot {
        ordinal,
        identity: 7,
        h_bits: positive_lambda.then_some(vec![
            (if ordinal == 1 { 1.0_f64 } else { 3.0_f64 })
                .to_bits();
            width
        ]),
        inverse_t_bits: positive_lambda.then_some(vec![4.0_f64.to_bits(); width]),
        inverse_denominator_bits: positive_lambda.then_some(vec![5.0_f64.to_bits(); width]),
        inverse_z_bits: positive_lambda.then_some(vec![6.0_f64.to_bits(); width]),
        delta_bits: Some(vec![
            (if ordinal == 1 { 2.0_f64 } else { 8.0_f64 }).to_bits();
            width
        ]),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_filter_application_snapshot(
    snapshot: &mut RefinementFactorApplicationSnapshot,
    expected: &serde_json::Value,
) {
    let prefix = format!("factor_application_snapshot_{}", snapshot.ordinal);
    snapshot.h_bits = refinement_capture_inventory_captured(expected, &format!("{prefix}_h_bits"))
        .then_some(snapshot.h_bits.take().unwrap_or_default());
    snapshot.inverse_t_bits =
        refinement_capture_inventory_captured(expected, &format!("{prefix}_inverse_t_bits"))
            .then_some(snapshot.inverse_t_bits.take().unwrap_or_default());
    snapshot.inverse_denominator_bits = refinement_capture_inventory_captured(
        expected,
        &format!("{prefix}_inverse_denominator_bits"),
    )
    .then_some(snapshot.inverse_denominator_bits.take().unwrap_or_default());
    snapshot.inverse_z_bits =
        refinement_capture_inventory_captured(expected, &format!("{prefix}_inverse_z_bits"))
            .then_some(snapshot.inverse_z_bits.take().unwrap_or_default());
    snapshot.delta_bits =
        refinement_capture_inventory_captured(expected, &format!("{prefix}_delta_bits"))
            .then_some(snapshot.delta_bits.take().unwrap_or_default());
}

#[cfg(test)]
fn refinement_capture_inventory_application_boundary(
    entry: &serde_json::Value,
    applications: u8,
) -> RefinementFactorOutputCopyBoundary {
    if entry["stage"] != "FactorApplicationOutput" {
        return RefinementFactorOutputCopyBoundary::AfterDelta;
    }
    let reached = entry["reached"].as_array().expect("reached groups");
    let has_group = |group| reached.iter().any(|item| item == group);
    if has_group(if applications == 1 {
        "app1 inverse/delta"
    } else {
        "app2 inverse/delta"
    }) || has_group(if applications == 1 {
        "delta0_bits"
    } else {
        "delta1_bits"
    }) {
        RefinementFactorOutputCopyBoundary::AfterDelta
    } else if has_group(if applications == 1 {
        "app1 inverse"
    } else {
        "app2 inverse"
    }) {
        RefinementFactorOutputCopyBoundary::AfterInverse
    } else {
        RefinementFactorOutputCopyBoundary::BeforeInverse
    }
}

#[cfg(test)]
fn refinement_capture_inventory_factor_applications(
    trace: &mut RefinementObservationTrace,
    expected: &serde_json::Value,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
    entry: &serde_json::Value,
) {
    let width = trace.face_free_ids.as_ref().expect("free ids").len();
    let applications = refinement_capture_inventory_expected_application_count(expected, entry);
    if applications == 0 {
        return;
    }
    trace.factor_identity = Some(7);
    trace.factor_application_identities = vec![7; usize::from(applications)];
    trace.factor_application_snapshots = (1..=applications)
        .map(|ordinal| {
            refinement_capture_inventory_application_snapshot(ordinal, width, metadata.lambda > 0.0)
        })
        .collect();
    for snapshot in &mut trace.factor_application_snapshots {
        refinement_capture_inventory_filter_application_snapshot(snapshot, expected);
    }
    trace.factor_applications = applications;
    trace.inverse_t = refinement_capture_inventory_captured(expected, "inverse_t_bits")
        .then_some(vec![4.0; width]);
    trace.inverse_denominator =
        refinement_capture_inventory_captured(expected, "inverse_denominator_bits")
            .then_some(vec![5.0; width]);
    trace.inverse_z = refinement_capture_inventory_captured(expected, "inverse_z_bits")
        .then_some(vec![6.0; width]);
    let boundary = refinement_capture_inventory_application_boundary(entry, applications);
    trace.factor_output_copy_boundary = Some((applications, boundary));
}

#[cfg(test)]
fn refinement_capture_inventory_set_structure_presence(
    trace: &mut RefinementObservationTrace,
    name: &str,
    present: bool,
) -> bool {
    let ids: Vec<_> = (0..21).collect();
    match name {
        "free_ids" => trace.face_free_ids = present.then_some(ids),
        "factor_order" => trace.factor_order = present.then_some(ids),
        "factor_a_bits" => trace.factor_a = present.then_some(vec![vec![0.0; 21]; 21]),
        "factor_v_bits" => trace.factor_v = present.then_some(vec![vec![0.0; 21]; 21]),
        "factor_sigma_bits" => trace.factor_sigma = present.then_some(vec![0.0; 21]),
        "weighted_residual_bits" => trace.weighted_residual = present.then_some(vec![0.0; 21]),
        "weighted_matrix_bits" => {
            trace.weighted_matrix = present.then_some(vec![vec![0.0; 21]; 21]);
        }
        "scaled_lower_bits" => trace.scaled_lower_bits = present.then_some([0; 21]),
        "scaled_upper_bits" => trace.scaled_upper_bits = present.then_some([0; 21]),
        "lambda_bits" => trace.lambda_bits = present.then_some(1.0_f64.to_bits()),
        "reduced_face_radius_bits" => {
            trace.reduced_face_radius_bits = present.then_some(10.0_f64.to_bits());
        }
        "live_state_entry_bits" => trace.live_state_entry = present.then_some([0; 21]),
        "live_state_exit_bits" => trace.live_state_exit = present.then_some([0; 21]),
        "lower_mask_exit" => trace.lower_mask_exit = present.then_some([false; 21]),
        "upper_mask_exit" => trace.upper_mask_exit = present.then_some([false; 21]),
        "factor_identity" => trace.factor_identity = present.then_some(7),
        "eligibility_scalar_operations" => {
            trace.eligibility_scalar_operations = present.then_some(0);
        }
        "eligibility_guard_events" => trace.eligibility_guard_events = present.then_some(0),
        "reservation_denial_owner" => {
            trace.reservation_denial_owner =
                present.then_some(M1TrustRegionBvls04ReservationOwner::Scalar);
        }
        _ => return false,
    }
    true
}

#[cfg(test)]
fn refinement_capture_inventory_set_step_presence(
    trace: &mut RefinementObservationTrace,
    name: &str,
    present: bool,
) -> bool {
    match name {
        "p0_bits" => trace.p0 = present.then_some([1.0; 21]),
        "lower_mask_p0" => trace.lower_mask_p0 = present.then_some([false; 21]),
        "upper_mask_p0" => trace.upper_mask_p0 = present.then_some([false; 21]),
        "residual0_bits" => trace.residual0 = present.then_some([0.0; 21]),
        "h0_bits" => trace.h0 = present.then_some(vec![1.0; 21]),
        "delta0_bits" => trace.delta0 = present.then_some(vec![2.0; 21]),
        "p1_bits" => trace.p1 = present.then_some([1.0; 21]),
        "lower_mask_p1" => trace.lower_mask_p1 = present.then_some([false; 21]),
        "upper_mask_p1" => trace.upper_mask_p1 = present.then_some([false; 21]),
        "residual1_bits" => trace.residual1 = present.then_some([0.0; 21]),
        "h1_bits" => trace.h1 = present.then_some(vec![3.0; 21]),
        "delta1_bits" => trace.delta1 = present.then_some(vec![8.0; 21]),
        "p2_bits" => trace.p2 = present.then_some([1.0; 21]),
        "lower_mask_p2" => trace.lower_mask_p2 = present.then_some([false; 21]),
        "upper_mask_p2" => trace.upper_mask_p2 = present.then_some([false; 21]),
        "remaining_radius_bits" => trace.remaining_radius = present.then_some(9.0),
        "radius_gap_bits" => trace.radius_gap = present.then_some(1.0),
        "radius_tolerance_bits" => trace.radius_tolerance = present.then_some(0.5),
        _ => return false,
    }
    true
}

#[cfg(test)]
fn refinement_capture_inventory_empty_snapshot(
    ordinal: u8,
    identity: usize,
) -> RefinementFactorApplicationSnapshot {
    RefinementFactorApplicationSnapshot {
        ordinal,
        identity,
        h_bits: None,
        inverse_t_bits: None,
        inverse_denominator_bits: None,
        inverse_z_bits: None,
        delta_bits: None,
    }
}

#[cfg(test)]
fn refinement_capture_inventory_set_factor_presence(
    trace: &mut RefinementObservationTrace,
    name: &str,
    present: bool,
) -> bool {
    let identity = trace.factor_identity.unwrap_or(7);
    match name {
        "inverse_t_bits" => {
            let width = trace.face_free_ids.as_ref().expect("free ids").len();
            trace.inverse_t = present.then_some(vec![4.0; width]);
        }
        "inverse_denominator_bits" => {
            let width = trace.face_free_ids.as_ref().expect("free ids").len();
            trace.inverse_denominator = present.then_some(vec![5.0; width]);
        }
        "inverse_z_bits" => {
            let width = trace.face_free_ids.as_ref().expect("free ids").len();
            trace.inverse_z = present.then_some(vec![6.0; width]);
        }
        "factor_applications" => {
            trace.factor_applications = if present {
                trace.factor_applications.max(1)
            } else {
                0
            };
        }
        "factor_application_identities" => {
            if !present {
                trace.factor_application_identities.clear();
            } else if trace.factor_application_identities.is_empty() {
                trace.factor_application_identities =
                    vec![identity; usize::from(trace.factor_applications.max(1))];
            }
        }
        "factor_application_snapshots" => {
            if !present {
                trace.factor_application_snapshots.clear();
            } else if trace.factor_application_snapshots.is_empty() {
                trace.factor_application_snapshots = (1..=trace.factor_applications.max(1))
                    .map(|ordinal| refinement_capture_inventory_empty_snapshot(ordinal, identity))
                    .collect();
            }
        }
        "factor_output_copy_boundary" => {
            if !present {
                trace.factor_output_copy_boundary = None;
            } else if trace.factor_output_copy_boundary.is_none() {
                trace.factor_output_copy_boundary = Some((
                    trace.factor_applications.max(1),
                    RefinementFactorOutputCopyBoundary::BeforeInverse,
                ));
            }
        }
        _ => return false,
    }
    true
}

#[cfg(test)]
fn refinement_capture_inventory_snapshot_member(name: &str) -> Option<(u8, &'static str)> {
    match name {
        "factor_application_snapshot_1_h_bits" => Some((1, "h_bits")),
        "factor_application_snapshot_1_inverse_t_bits" => Some((1, "inverse_t_bits")),
        "factor_application_snapshot_1_inverse_denominator_bits" => {
            Some((1, "inverse_denominator_bits"))
        }
        "factor_application_snapshot_1_inverse_z_bits" => Some((1, "inverse_z_bits")),
        "factor_application_snapshot_1_delta_bits" => Some((1, "delta_bits")),
        "factor_application_snapshot_2_h_bits" => Some((2, "h_bits")),
        "factor_application_snapshot_2_inverse_t_bits" => Some((2, "inverse_t_bits")),
        "factor_application_snapshot_2_inverse_denominator_bits" => {
            Some((2, "inverse_denominator_bits"))
        }
        "factor_application_snapshot_2_inverse_z_bits" => Some((2, "inverse_z_bits")),
        "factor_application_snapshot_2_delta_bits" => Some((2, "delta_bits")),
        _ => None,
    }
}

#[cfg(test)]
fn refinement_capture_inventory_set_snapshot_presence(
    trace: &mut RefinementObservationTrace,
    ordinal: u8,
    member: &str,
    present: bool,
) {
    let index = usize::from(ordinal - 1);
    if present {
        let identity = trace.factor_identity.unwrap_or(7);
        while trace.factor_application_snapshots.len() <= index {
            let snapshot_ordinal = u8::try_from(trace.factor_application_snapshots.len())
                .expect("at most two factor snapshots")
                + 1;
            trace
                .factor_application_snapshots
                .push(refinement_capture_inventory_empty_snapshot(
                    snapshot_ordinal,
                    identity,
                ));
        }
    } else if trace.factor_application_snapshots.len() <= index {
        return;
    }

    let width = trace.face_free_ids.as_ref().expect("free ids").len();
    let snapshot = &mut trace.factor_application_snapshots[index];
    match member {
        "h_bits" => {
            snapshot.h_bits = present.then_some(vec![
                (if ordinal == 1 { 1.0_f64 } else { 3.0_f64 })
                    .to_bits();
                width
            ]);
        }
        "inverse_t_bits" => {
            snapshot.inverse_t_bits = present.then_some(vec![4.0_f64.to_bits(); width]);
        }
        "inverse_denominator_bits" => {
            snapshot.inverse_denominator_bits = present.then_some(vec![5.0_f64.to_bits(); width]);
        }
        "inverse_z_bits" => {
            snapshot.inverse_z_bits = present.then_some(vec![6.0_f64.to_bits(); width]);
        }
        "delta_bits" => {
            snapshot.delta_bits =
                present.then_some(vec![
                    (if ordinal == 1 { 2.0_f64 } else { 8.0_f64 }).to_bits();
                    width
                ]);
        }
        value => panic!("unknown snapshot presence member: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_set_norm_collection_presence(
    trace: &mut RefinementObservationTrace,
    name: &str,
    present: bool,
) -> bool {
    match name {
        "ordered_norm_traces" => {
            if !present {
                trace.ordered_norms.clear();
            } else if trace.ordered_norms.is_empty() {
                let p0 = trace.p0.expect("p0 for ordered norm injection");
                trace
                    .ordered_norms
                    .push(refinement_capture_complete_norm("p0_full", &p0));
            }
        }
        "partial_ordered_norms" => {
            if !present {
                trace.partial_ordered_norms.clear();
            } else if trace.partial_ordered_norms.is_empty() {
                let p0 = trace.p0.expect("p0 for partial norm injection");
                let value = p0[0];
                trace
                    .partial_ordered_norms
                    .push(RefinementPartialOrderedNormTrace {
                        role: "p0_full",
                        coordinate_ids: vec![0],
                        value_bits: vec![value.to_bits()],
                        square_bits: vec![(value * value).to_bits()],
                        running_sum_bits: Vec::new(),
                        terminal_operation: "square_guard",
                        sqrt_bits: None,
                    });
            }
        }
        _ => return false,
    }
    true
}

#[cfg(test)]
fn refinement_capture_inventory_presence_changes(
    before: &RefinementObservationTrace,
    after: &RefinementObservationTrace,
) -> Vec<&'static str> {
    let snapshots = |trace: &RefinementObservationTrace, ordinal: usize, member: &str| {
        trace
            .factor_application_snapshots
            .get(ordinal)
            .is_some_and(|snapshot| match member {
                "h_bits" => snapshot.h_bits.is_some(),
                "inverse_t_bits" => snapshot.inverse_t_bits.is_some(),
                "inverse_denominator_bits" => snapshot.inverse_denominator_bits.is_some(),
                "inverse_z_bits" => snapshot.inverse_z_bits.is_some(),
                "delta_bits" => snapshot.delta_bits.is_some(),
                value => panic!("unknown snapshot presence member: {value}"),
            })
    };
    let present = |trace: &RefinementObservationTrace, name| match name {
        "inverse_t_bits" => trace.inverse_t.is_some(),
        "inverse_denominator_bits" => trace.inverse_denominator.is_some(),
        "inverse_z_bits" => trace.inverse_z.is_some(),
        "factor_application_identities" => !trace.factor_application_identities.is_empty(),
        "factor_application_snapshots" => !trace.factor_application_snapshots.is_empty(),
        "factor_applications" => trace.factor_applications > 0,
        "factor_output_copy_boundary" => trace.factor_output_copy_boundary.is_some(),
        "ordered_norm_traces" => !trace.ordered_norms.is_empty(),
        "partial_ordered_norms" => !trace.partial_ordered_norms.is_empty(),
        "factor_application_snapshot_1_h_bits" => snapshots(trace, 0, "h_bits"),
        "factor_application_snapshot_1_inverse_t_bits" => snapshots(trace, 0, "inverse_t_bits"),
        "factor_application_snapshot_1_inverse_denominator_bits" => {
            snapshots(trace, 0, "inverse_denominator_bits")
        }
        "factor_application_snapshot_1_inverse_z_bits" => snapshots(trace, 0, "inverse_z_bits"),
        "factor_application_snapshot_1_delta_bits" => snapshots(trace, 0, "delta_bits"),
        "factor_application_snapshot_2_h_bits" => snapshots(trace, 1, "h_bits"),
        "factor_application_snapshot_2_inverse_t_bits" => snapshots(trace, 1, "inverse_t_bits"),
        "factor_application_snapshot_2_inverse_denominator_bits" => {
            snapshots(trace, 1, "inverse_denominator_bits")
        }
        "factor_application_snapshot_2_inverse_z_bits" => snapshots(trace, 1, "inverse_z_bits"),
        "factor_application_snapshot_2_delta_bits" => snapshots(trace, 1, "delta_bits"),
        value => panic!("unknown shared presence member: {value}"),
    };
    [
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
        "factor_application_identities",
        "factor_application_snapshots",
        "factor_applications",
        "factor_output_copy_boundary",
        "ordered_norm_traces",
        "partial_ordered_norms",
        "factor_application_snapshot_1_h_bits",
        "factor_application_snapshot_1_inverse_t_bits",
        "factor_application_snapshot_1_inverse_denominator_bits",
        "factor_application_snapshot_1_inverse_z_bits",
        "factor_application_snapshot_1_delta_bits",
        "factor_application_snapshot_2_h_bits",
        "factor_application_snapshot_2_inverse_t_bits",
        "factor_application_snapshot_2_inverse_denominator_bits",
        "factor_application_snapshot_2_inverse_z_bits",
        "factor_application_snapshot_2_delta_bits",
    ]
    .into_iter()
    .filter(|name| present(before, name) != present(after, name))
    .collect()
}

#[cfg(test)]
fn refinement_capture_inventory_set_presence(
    trace: &mut RefinementObservationTrace,
    name: &str,
    present: bool,
) -> Vec<&'static str> {
    let before = trace.clone();
    if name.starts_with("factor_application_snapshot_") {
        let (ordinal, member) = refinement_capture_inventory_snapshot_member(name)
            .unwrap_or_else(|| panic!("unknown snapshot presence member: {name}"));
        refinement_capture_inventory_set_snapshot_presence(trace, ordinal, member, present);
    } else if refinement_capture_inventory_set_factor_presence(trace, name, present)
        || refinement_capture_inventory_set_norm_collection_presence(trace, name, present)
        || refinement_capture_inventory_set_structure_presence(trace, name, present)
        || refinement_capture_inventory_set_step_presence(trace, name, present)
    {
    } else {
        match name {
            "p0_full_norm2_bits" => trace.p0_full_norm2 = present.then_some(0.0),
            "p0_full_norm_bits" => trace.p0_full_norm = present.then_some(0.0),
            "p0_reduced_norm2_bits" => trace.p0_reduced_norm2 = present.then_some(0.0),
            "p0_reduced_norm_bits" => trace.p0_reduced_norm = present.then_some(0.0),
            "p1_full_norm2_bits" => trace.p1_full_norm2 = present.then_some(0.0),
            "p1_full_norm_bits" => trace.p1_full_norm = present.then_some(0.0),
            "p1_reduced_norm2_bits" => trace.p1_reduced_norm2 = present.then_some(0.0),
            "p1_reduced_norm_bits" => trace.p1_reduced_norm = present.then_some(0.0),
            "p2_full_norm2_bits" => trace.p2_full_norm2 = present.then_some(0.0),
            "p2_full_norm_bits" => trace.p2_full_norm = present.then_some(0.0),
            "p2_reduced_norm2_bits" => trace.p2_reduced_norm2 = present.then_some(0.0),
            "p2_reduced_norm_bits" => trace.p2_reduced_norm = present.then_some(0.0),
            value => panic!("unknown inventory presence member: {value}"),
        }
    }
    refinement_capture_inventory_presence_changes(&before, trace)
}

#[cfg(test)]
fn refinement_capture_inventory_member_present(
    trace: &RefinementObservationTrace,
    name: &str,
) -> bool {
    let snapshot = |ordinal: usize, member: &str| {
        trace
            .factor_application_snapshots
            .get(ordinal)
            .is_some_and(|snapshot| match member {
                "h_bits" => snapshot.h_bits.is_some(),
                "inverse_t_bits" => snapshot.inverse_t_bits.is_some(),
                "inverse_denominator_bits" => snapshot.inverse_denominator_bits.is_some(),
                "inverse_z_bits" => snapshot.inverse_z_bits.is_some(),
                "delta_bits" => snapshot.delta_bits.is_some(),
                value => panic!("unknown snapshot presence member: {value}"),
            })
    };
    match name {
        "free_ids" => trace.face_free_ids.is_some(),
        "factor_order" => trace.factor_order.is_some(),
        "factor_a_bits" => trace.factor_a.is_some(),
        "factor_v_bits" => trace.factor_v.is_some(),
        "factor_sigma_bits" => trace.factor_sigma.is_some(),
        "weighted_residual_bits" => trace.weighted_residual.is_some(),
        "weighted_matrix_bits" => trace.weighted_matrix.is_some(),
        "scaled_lower_bits" => trace.scaled_lower_bits.is_some(),
        "scaled_upper_bits" => trace.scaled_upper_bits.is_some(),
        "lambda_bits" => trace.lambda_bits.is_some(),
        "reduced_face_radius_bits" => trace.reduced_face_radius_bits.is_some(),
        "live_state_entry_bits" => trace.live_state_entry.is_some(),
        "live_state_exit_bits" => trace.live_state_exit.is_some(),
        "lower_mask_exit" => trace.lower_mask_exit.is_some(),
        "upper_mask_exit" => trace.upper_mask_exit.is_some(),
        "factor_identity" => trace.factor_identity.is_some(),
        "factor_application_identities" => !trace.factor_application_identities.is_empty(),
        "factor_application_snapshots" => !trace.factor_application_snapshots.is_empty(),
        "factor_output_copy_boundary" => trace.factor_output_copy_boundary.is_some(),
        "factor_applications" => trace.factor_applications > 0,
        "eligibility_scalar_operations" => trace.eligibility_scalar_operations.is_some(),
        "eligibility_guard_events" => trace.eligibility_guard_events.is_some(),
        "reservation_denial_owner" => trace.reservation_denial_owner.is_some(),
        "p0_bits" => trace.p0.is_some(),
        "p0_full_norm2_bits" => trace.p0_full_norm2.is_some(),
        "p0_full_norm_bits" => trace.p0_full_norm.is_some(),
        "p0_reduced_norm2_bits" => trace.p0_reduced_norm2.is_some(),
        "p0_reduced_norm_bits" => trace.p0_reduced_norm.is_some(),
        "lower_mask_p0" => trace.lower_mask_p0.is_some(),
        "upper_mask_p0" => trace.upper_mask_p0.is_some(),
        "residual0_bits" => trace.residual0.is_some(),
        "h0_bits" => trace.h0.is_some(),
        "delta0_bits" => trace.delta0.is_some(),
        "p1_bits" => trace.p1.is_some(),
        "p1_full_norm2_bits" => trace.p1_full_norm2.is_some(),
        "p1_full_norm_bits" => trace.p1_full_norm.is_some(),
        "p1_reduced_norm2_bits" => trace.p1_reduced_norm2.is_some(),
        "p1_reduced_norm_bits" => trace.p1_reduced_norm.is_some(),
        "lower_mask_p1" => trace.lower_mask_p1.is_some(),
        "upper_mask_p1" => trace.upper_mask_p1.is_some(),
        "residual1_bits" => trace.residual1.is_some(),
        "h1_bits" => trace.h1.is_some(),
        "delta1_bits" => trace.delta1.is_some(),
        "p2_bits" => trace.p2.is_some(),
        "p2_full_norm2_bits" => trace.p2_full_norm2.is_some(),
        "p2_full_norm_bits" => trace.p2_full_norm.is_some(),
        "p2_reduced_norm2_bits" => trace.p2_reduced_norm2.is_some(),
        "p2_reduced_norm_bits" => trace.p2_reduced_norm.is_some(),
        "lower_mask_p2" => trace.lower_mask_p2.is_some(),
        "upper_mask_p2" => trace.upper_mask_p2.is_some(),
        "remaining_radius_bits" => trace.remaining_radius.is_some(),
        "radius_gap_bits" => trace.radius_gap.is_some(),
        "radius_tolerance_bits" => trace.radius_tolerance.is_some(),
        "factor_application_snapshot_1_h_bits" => snapshot(0, "h_bits"),
        "factor_application_snapshot_1_inverse_t_bits" => snapshot(0, "inverse_t_bits"),
        "factor_application_snapshot_1_inverse_denominator_bits" => {
            snapshot(0, "inverse_denominator_bits")
        }
        "factor_application_snapshot_1_inverse_z_bits" => snapshot(0, "inverse_z_bits"),
        "factor_application_snapshot_1_delta_bits" => snapshot(0, "delta_bits"),
        "factor_application_snapshot_2_h_bits" => snapshot(1, "h_bits"),
        "factor_application_snapshot_2_inverse_t_bits" => snapshot(1, "inverse_t_bits"),
        "factor_application_snapshot_2_inverse_denominator_bits" => {
            snapshot(1, "inverse_denominator_bits")
        }
        "factor_application_snapshot_2_inverse_z_bits" => snapshot(1, "inverse_z_bits"),
        "factor_application_snapshot_2_delta_bits" => snapshot(1, "delta_bits"),
        "inverse_t_bits" => trace.inverse_t.is_some(),
        "inverse_denominator_bits" => trace.inverse_denominator.is_some(),
        "inverse_z_bits" => trace.inverse_z.is_some(),
        "ordered_norm_traces" => !trace.ordered_norms.is_empty(),
        "partial_ordered_norms" => !trace.partial_ordered_norms.is_empty(),
        value => panic!("unknown inventory presence member: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_application_count(entry: &serde_json::Value) -> u8 {
    let dot = matches!(
        entry["stage"].as_str(),
        Some(
            "ResidualSourceTerm"
                | "ResidualSourceWeight"
                | "PrimaryProduct"
                | "SplitterProduct"
                | "SplitOutput"
                | "EftRemainder"
                | "TwoSumResult"
                | "TwoSumRemainder"
                | "Accumulation"
        )
    );
    match entry["position"].as_str().expect("inventory position") {
        "None" => 0,
        "First" if dot => 0,
        "First" => 1,
        "Second" if dot => 1,
        "Second" => 2,
        value => panic!("unknown refinement position: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_mutated_status(baseline: &str, present: bool) -> &'static str {
    match baseline {
        "captured" => {
            if present {
                "captured"
            } else {
                "missing_instrumentation"
            }
        }
        "naturally_unreached" => {
            if present {
                "contradictory_stray_presence"
            } else {
                "naturally_unreached"
            }
        }
        "interrupted" => {
            if present {
                "contradictory_stray_presence"
            } else {
                "interrupted"
            }
        }
        "inapplicable_zero_lambda" => {
            if present {
                "contradictory_stray_presence"
            } else {
                "inapplicable_zero_lambda"
            }
        }
        value => panic!("unknown independent baseline status: {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_inventory_marker_loss_fields(entry: &serde_json::Value) -> Vec<&'static str> {
    let applications = refinement_capture_inventory_application_count(entry);
    if applications == 0 {
        return Vec::new();
    }
    let positive = entry["lambda"] == "positive";
    let mut fields = vec![
        "factor_application_snapshot_1_delta_bits",
        "delta0_bits",
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
    ];
    if positive {
        fields.extend([
            "factor_application_snapshot_1_h_bits",
            "factor_application_snapshot_1_inverse_t_bits",
            "factor_application_snapshot_1_inverse_denominator_bits",
            "factor_application_snapshot_1_inverse_z_bits",
        ]);
    }
    if applications == 2 {
        fields.push("factor_application_snapshot_2_delta_bits");
        fields.push("delta1_bits");
        if positive {
            fields.extend([
                "factor_application_snapshot_2_h_bits",
                "factor_application_snapshot_2_inverse_t_bits",
                "factor_application_snapshot_2_inverse_denominator_bits",
                "factor_application_snapshot_2_inverse_z_bits",
            ]);
        }
    }
    fields
}

#[cfg(test)]
fn refinement_capture_inventory_mutation_expected_statuses(
    entry: &serde_json::Value,
    baseline: &serde_json::Value,
    trace: &RefinementObservationTrace,
    mutated: &RefinementObservationTrace,
    name: &str,
    changed: &[&str],
) -> serde_json::Value {
    let mut expected = baseline.as_object().expect("baseline status map").clone();
    let mut affected = std::collections::BTreeSet::new();
    affected.insert(name);
    affected.extend(changed.iter().copied());
    // A deleted copy-boundary marker is the sole declared exception to the
    // otherwise immutable baseline obligations: the approved copy policy
    // conservatively makes all existing-ordinal copies required.  It never
    // promotes a future ordinal and never reads the mutated public map.
    let marker_loss = name == "factor_output_copy_boundary"
        && entry["stage"] == "FactorApplicationOutput"
        && !refinement_capture_inventory_member_present(mutated, name);
    if marker_loss {
        affected.extend(refinement_capture_inventory_marker_loss_fields(entry));
    }
    for field in affected {
        let baseline_status = baseline[field].as_str().expect("baseline field status");
        let marker_requires_field = marker_loss
            && refinement_capture_inventory_marker_loss_fields(entry).contains(&field)
            && (entry["lambda"] == "positive"
                || matches!(
                    field,
                    "delta0_bits"
                        | "delta1_bits"
                        | "factor_application_snapshot_1_delta_bits"
                        | "factor_application_snapshot_2_delta_bits"
                ));
        let expected_status = if marker_requires_field {
            refinement_capture_inventory_mutated_status(
                "captured",
                refinement_capture_inventory_member_present(mutated, field),
            )
        } else {
            refinement_capture_inventory_mutated_status(
                baseline_status,
                refinement_capture_inventory_member_present(mutated, field),
            )
        };
        expected.insert(
            field.into(),
            serde_json::Value::String(expected_status.into()),
        );
    }
    assert!(
        refinement_capture_inventory_member_present(trace, name)
            != refinement_capture_inventory_member_present(mutated, name),
        "mutation did not change requested logical presence: {name}"
    );
    serde_json::Value::Object(expected)
}

/// Exercise the detached semantic expansion against every recorded locator
/// alternative before the exhaustive acceptance/mutation controls consume the
/// same builder.  This is deliberately inventory-driven: no resolved-terminal
/// status is consulted while expected public fields are expanded.
#[cfg(test)]
fn refinement_capture_inventory_oracle_builder_family(
    family: &str,
    accepts: fn(&serde_json::Value) -> bool,
) {
    use std::collections::BTreeSet;

    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    let mut rows = 0;
    let mut alternatives = 0;
    let mut covered = BTreeSet::new();
    let mut failures = Vec::new();
    for entry in inventory["entries"].as_array().expect("inventory entries") {
        if entry["stage"] == "not-applicable" || !accepts(entry) {
            continue;
        }
        rows += 1;
        let expected = refinement_capture_inventory_expected_statuses(entry);
        assert_eq!(
            expected.as_object().expect("expected status object").len(),
            refinement_capture_inventory_public_fields().len(),
            "incomplete independent expected map: {}",
            entry["id"]
        );
        for locator in refinement_capture_inventory_locator_domain(entry) {
            let identity = locator.id.clone();
            assert!(
                covered.insert(identity.clone()),
                "duplicate inventory locator identity: {identity}"
            );
            let metadata = refinement_capture_inventory_domain_metadata(entry, &locator);
            let trace =
                refinement_capture_inventory_trace(entry, &metadata, locator.partial_operation);
            let selected = refinement_capture_selected_terminal_kind(&metadata, &trace);
            let complete = refinement_capture_terminal_complete(&trace, Some(&metadata));
            let actual = refinement_capture_field_status_json(&trace);
            let expected_fields = expected.as_object().expect("expected map object");
            let actual_fields = actual.as_object().expect("actual map object");
            let keys: BTreeSet<_> = actual_fields.keys().chain(expected_fields.keys()).collect();
            let differences: Vec<_> = keys
                .into_iter()
                .filter(|name| actual_fields.get(*name) != expected_fields.get(*name))
                .map(|name| {
                    format!(
                        "{name}={:?}!={:?}",
                        actual_fields.get(name),
                        expected_fields.get(name)
                    )
                })
                .collect();
            if !selected || !complete || !differences.is_empty() {
                failures.push(format!(
                    "{identity}: selected={selected} complete={complete} differences=[{}]",
                    differences.join(",")
                ));
            }
            alternatives += 1;
        }
    }
    assert!(rows > 0, "empty inventory family: {family}");
    assert!(alternatives > 0, "empty locator family: {family}");
    assert_eq!(covered.len(), alternatives, "unbound locator coverage");
    assert!(
        failures.is_empty(),
        "inventory family {family} failures:\n{}",
        failures.join("\n")
    );
}

#[cfg(test)]
fn refinement_capture_inventory_mutation_family(
    family: &str,
    lambda: &str,
    accepts: fn(&serde_json::Value) -> bool,
) {
    use std::collections::BTreeSet;

    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    let fields = refinement_capture_inventory_public_fields();
    let mut row_ids = BTreeSet::new();
    let mut locator_ids = BTreeSet::new();
    let mut mutations = 0_usize;
    for entry in inventory["entries"].as_array().expect("inventory entries") {
        if entry["stage"] == "not-applicable" || entry["lambda"] != lambda || !accepts(entry) {
            continue;
        }
        let row_id = entry["id"].as_str().expect("inventory row id");
        assert!(
            row_ids.insert(row_id.to_owned()),
            "duplicate inventory row: {row_id}"
        );
        let baseline = refinement_capture_inventory_expected_statuses(entry);
        for locator in refinement_capture_inventory_locator_domain(entry) {
            let identity = locator.id.clone();
            assert!(
                locator_ids.insert(identity.clone()),
                "duplicate inventory locator: {identity}"
            );
            let metadata = refinement_capture_inventory_domain_metadata(entry, &locator);
            let trace =
                refinement_capture_inventory_trace(entry, &metadata, locator.partial_operation);
            assert!(
                refinement_capture_selected_terminal_kind(&metadata, &trace),
                "unselected mutation baseline: {identity}"
            );
            assert!(
                refinement_capture_terminal_complete(&trace, Some(&metadata)),
                "incomplete mutation baseline: {identity}"
            );
            assert_eq!(
                refinement_capture_field_status_json(&trace),
                baseline,
                "baseline public map mismatch before mutation: {identity}"
            );
            for &name in fields {
                let baseline_status = baseline[name].as_str().expect("baseline field status");
                let present = match baseline_status {
                    "captured" => false,
                    "naturally_unreached" | "interrupted" | "inapplicable_zero_lambda" => true,
                    value => panic!("unknown independent baseline status: {value}"),
                };
                let mut mutated = trace.clone();
                let changed =
                    refinement_capture_inventory_set_presence(&mut mutated, name, present);
                assert_eq!(
                    refinement_capture_inventory_member_present(&mutated, name),
                    present,
                    "mutation did not set requested presence: {identity} {name}"
                );
                let expected = refinement_capture_inventory_mutation_expected_statuses(
                    entry, &baseline, &trace, &mutated, name, &changed,
                );
                assert!(
                    !refinement_capture_terminal_complete(&mutated, Some(&metadata)),
                    "mutation remained accepted: {identity} {name}"
                );
                assert_eq!(
                    refinement_capture_field_status_json(&mutated),
                    expected,
                    "mutation public map mismatch: {identity} {name}; collateral={changed:?}"
                );
                mutations += 1;
            }
        }
    }
    assert!(
        !row_ids.is_empty(),
        "empty mutation family: {family}/{lambda}"
    );
    assert!(
        !locator_ids.is_empty(),
        "empty mutation locator family: {family}/{lambda}"
    );
    eprintln!(
        "mutation coverage family={family} lambda={lambda} rows={} locators={} mutations={} row_ids={:?} locator_ids={:?}",
        row_ids.len(),
        locator_ids.len(),
        mutations,
        row_ids,
        locator_ids
    );
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_oracle_p0_control() {
    refinement_capture_inventory_oracle_builder_family("p0", |entry| entry["position"] == "None");
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_oracle_first_residual_h0_control() {
    refinement_capture_inventory_oracle_builder_family("first-residual-h0", |entry| {
        entry["position"] == "First"
            && matches!(
                entry["stage"].as_str(),
                Some(
                    "ResidualSourceTerm"
                        | "ResidualSourceWeight"
                        | "PrimaryProduct"
                        | "SplitterProduct"
                        | "SplitOutput"
                        | "EftRemainder"
                        | "TwoSumResult"
                        | "TwoSumRemainder"
                        | "Accumulation"
                )
            )
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_oracle_first_factor_scratch_control() {
    refinement_capture_inventory_oracle_builder_family("first-factor-scratch", |entry| {
        entry["position"] == "First"
            && !matches!(
                entry["stage"].as_str(),
                Some(
                    "ResidualSourceTerm"
                        | "ResidualSourceWeight"
                        | "PrimaryProduct"
                        | "SplitterProduct"
                        | "SplitOutput"
                        | "EftRemainder"
                        | "TwoSumResult"
                        | "TwoSumRemainder"
                        | "Accumulation"
                )
            )
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_oracle_second_residual_h1_control() {
    refinement_capture_inventory_oracle_builder_family("second-residual-h1", |entry| {
        entry["position"] == "Second"
            && matches!(
                entry["stage"].as_str(),
                Some(
                    "ResidualSourceTerm"
                        | "ResidualSourceWeight"
                        | "PrimaryProduct"
                        | "SplitterProduct"
                        | "SplitOutput"
                        | "EftRemainder"
                        | "TwoSumResult"
                        | "TwoSumRemainder"
                        | "Accumulation"
                )
            )
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_oracle_second_factor_final_control() {
    refinement_capture_inventory_oracle_builder_family("second-factor-final", |entry| {
        entry["position"] == "Second"
            && !matches!(
                entry["stage"].as_str(),
                Some(
                    "ResidualSourceTerm"
                        | "ResidualSourceWeight"
                        | "PrimaryProduct"
                        | "SplitterProduct"
                        | "SplitOutput"
                        | "EftRemainder"
                        | "TwoSumResult"
                        | "TwoSumRemainder"
                        | "Accumulation"
                )
            )
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_p0_positive_control() {
    refinement_capture_inventory_mutation_family("p0", "positive", |entry| {
        entry["position"] == "None"
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_p0_zero_control() {
    refinement_capture_inventory_mutation_family("p0", "zero", |entry| entry["position"] == "None");
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_first_residual_h0_positive_control() {
    refinement_capture_inventory_mutation_family("first-residual-h0", "positive", |entry| {
        entry["position"] == "First" && refinement_capture_inventory_application_count(entry) == 0
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_first_residual_h0_zero_control() {
    refinement_capture_inventory_mutation_family("first-residual-h0", "zero", |entry| {
        entry["position"] == "First" && refinement_capture_inventory_application_count(entry) == 0
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_first_factor_scratch_positive_control() {
    refinement_capture_inventory_mutation_family("first-factor-scratch", "positive", |entry| {
        entry["position"] == "First" && refinement_capture_inventory_application_count(entry) == 1
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_first_factor_scratch_zero_control() {
    refinement_capture_inventory_mutation_family("first-factor-scratch", "zero", |entry| {
        entry["position"] == "First" && refinement_capture_inventory_application_count(entry) == 1
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_second_residual_h1_positive_control() {
    refinement_capture_inventory_mutation_family("second-residual-h1", "positive", |entry| {
        entry["position"] == "Second" && refinement_capture_inventory_application_count(entry) == 1
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_second_residual_h1_zero_control() {
    refinement_capture_inventory_mutation_family("second-residual-h1", "zero", |entry| {
        entry["position"] == "Second" && refinement_capture_inventory_application_count(entry) == 1
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_second_factor_final_positive_control() {
    refinement_capture_inventory_mutation_family("second-factor-final", "positive", |entry| {
        entry["position"] == "Second" && refinement_capture_inventory_application_count(entry) == 2
    });
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_second_factor_final_zero_control() {
    refinement_capture_inventory_mutation_family("second-factor-final", "zero", |entry| {
        entry["position"] == "Second" && refinement_capture_inventory_application_count(entry) == 2
    });
}

/// Keep the inventory's alternative encoding structurally complete. Semantic
/// locator acceptance is exercised by the atomic-terminal control above.
#[cfg(test)]
#[test]
fn m1_refinement_inventory_mutation_partition_coverage_control() {
    use std::collections::{BTreeMap, BTreeSet};

    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    let mut rows_by_partition: BTreeMap<String, BTreeSet<String>> = BTreeMap::new();
    let mut locators_by_partition: BTreeMap<String, BTreeSet<String>> = BTreeMap::new();
    let mut union = BTreeSet::new();
    for entry in inventory["entries"].as_array().expect("inventory entries") {
        if entry["stage"] == "not-applicable" {
            continue;
        }
        let family = match (
            entry["position"].as_str().expect("inventory position"),
            refinement_capture_inventory_application_count(entry),
        ) {
            ("None", 0) => "p0",
            ("First", 0) => "first-residual-h0",
            ("First", 1) => "first-factor-scratch",
            ("Second", 1) => "second-residual-h1",
            ("Second", 2) => "second-factor-final",
            (position, applications) => {
                panic!("unassigned mutation partition: {position}/{applications}")
            }
        };
        let lambda = entry["lambda"].as_str().expect("inventory lambda");
        assert!(matches!(lambda, "positive" | "zero"));
        let partition = format!("{family}/{lambda}");
        let row_id = entry["id"].as_str().expect("inventory row id").to_owned();
        assert!(
            union.insert(row_id.clone()),
            "row appears in more than one mutation partition: {row_id}"
        );
        rows_by_partition
            .entry(partition.clone())
            .or_default()
            .insert(row_id);
        for locator in refinement_capture_inventory_locator_domain(entry) {
            assert!(
                locators_by_partition
                    .entry(partition.clone())
                    .or_default()
                    .insert(locator.id),
                "duplicate locator in mutation partition {partition}"
            );
        }
    }
    assert_eq!(
        union.len(),
        107,
        "mutation partitions must cover all refinement rows"
    );
    assert_eq!(
        rows_by_partition.len(),
        10,
        "missing lambda/family partition"
    );
    for (partition, rows) in &rows_by_partition {
        let locators = locators_by_partition
            .get(partition)
            .expect("partition locator coverage");
        assert!(
            !rows.is_empty() && !locators.is_empty(),
            "empty partition: {partition}"
        );
        eprintln!(
            "mutation partition coverage {partition}: rows={} locators={} row_ids={rows:?} locator_ids={locators:?}",
            rows.len(),
            locators.len()
        );
    }
}

/// Work-cap records retain their outer observations but cannot manufacture a
/// refinement terminal.  Keep their two approved rows separate from the 107
/// refinement successes so an absent terminal refusal remains a hard failure.
#[cfg(test)]
fn refinement_capture_inventory_work_cap_norms(
    trace: &mut RefinementObservationTrace,
    entry: &serde_json::Value,
) {
    if entry["lambda"] == "zero" {
        trace.lambda_bits = Some(0.0_f64.to_bits());
        trace.p0 = Some([0.0; 21]);
        trace.p0_full_norm2 = None;
        trace.p0_full_norm = None;
        trace.p0_reduced_norm2 = None;
        trace.p0_reduced_norm = None;
        trace.ordered_norms = vec![refinement_capture_complete_norm(
            "p0_zero_lambda_eligibility",
            trace.p0.as_ref().expect("zero work-cap p0"),
        )];
    } else {
        let p0 = trace.p0.as_ref().expect("positive work-cap p0");
        let free = trace
            .face_free_ids
            .as_ref()
            .expect("positive work-cap free ids");
        let selected: Vec<_> = free.iter().map(|id| p0[*id]).collect();
        let mut p0_free = refinement_capture_complete_norm("p0_free", &selected);
        p0_free.coordinate_ids = free.clone();
        trace.p0_reduced_norm2 = Some(f64::from_bits(p0_free.norm2_bits));
        trace.p0_reduced_norm = Some(f64::from_bits(p0_free.norm_bits));
        trace.ordered_norms.push(p0_free);
    }
}

#[cfg(test)]
fn refinement_capture_inventory_work_cap_trace(
    entry: &serde_json::Value,
    expected_roles: &std::collections::BTreeSet<&str>,
) -> RefinementObservationTrace {
    let (mut trace, _) = refinement_capture_complete_p0_terminal();
    let entry_state = trace.live_state_entry;
    let exit_state = trace.live_state_exit;
    let lower_p0 = trace.lower_mask_p0;
    let upper_p0 = trace.upper_mask_p0;
    trace.eligibility_scalar_operations = Some(7);
    trace.eligibility_guard_events = Some(3);
    trace.reservation_denial_owner = Some(M1TrustRegionBvls04ReservationOwner::Scalar);
    refinement_capture_inventory_work_cap_norms(&mut trace, entry);
    assert_eq!(trace.live_state_entry, entry_state, "entry state retained");
    assert_eq!(trace.live_state_exit, exit_state, "exit state retained");
    assert_eq!(trace.lower_mask_p0, lower_p0, "lower mask retained");
    assert_eq!(trace.upper_mask_p0, upper_p0, "upper mask retained");
    let work = super::M1TrustRegionWorkObservation {
        stage1_calls: 1,
        refinement_scalar_operations: 7,
        refinement_guard_events: 3,
        refinement_attempted_entries: 1,
        refinement_denied_entries: 1,
        bvls04_positive_entries: u32::from(entry["lambda"] == "positive"),
        bvls04_ordered_norms: u32::try_from(expected_roles.len())
            .expect("bounded expected norm role count"),
        ..Default::default()
    };
    trace.work = Some(work.clone());
    trace.terminal_refusal = Some(Box::new(super::M1TrustRegionSubproblemRefusal {
        kind: super::M1TrustRegionRefusalKind::WorkCap,
        optimality_reason: None,
        optimality_coordinate: None,
        optimality_radius: None,
        optimality_lambda: None,
        attempted_subproblems: 1,
        completed_jacobi_sweeps: 0,
        completed_face_pivots: 0,
        entered_svd_factorizations: 0,
        raw_residual_max: 0.0,
        work: Box::new(work),
        refinement: None,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_refusal: None,
    }));
    trace
}

#[cfg(test)]
fn refinement_capture_inventory_assert_work_cap_reached(
    entry: &serde_json::Value,
    row_id: &str,
    trace: &RefinementObservationTrace,
) {
    let reached: std::collections::BTreeSet<_> = entry["reached"]
        .as_array()
        .expect("work-cap reached")
        .iter()
        .map(|group| group.as_str().expect("reached group"))
        .collect();
    for group in [
        ("p0 bits/masks", "p0 reach"),
        ("eligibility counters", "eligibility reach"),
        ("reservation_denial_owner", "reservation reach"),
        ("work_ledger", "work reach"),
    ] {
        assert!(reached.contains(group.0), "missing {}: {row_id}", group.1);
    }
    assert!(trace.p0.is_some() && trace.lower_mask_p0.is_some() && trace.upper_mask_p0.is_some());
    assert!(
        trace.eligibility_scalar_operations.is_some()
            && trace.eligibility_guard_events.is_some()
            && trace.reservation_denial_owner.is_some()
            && trace.work.is_some(),
        "outer work-cap observations missing: {row_id}"
    );
}

#[cfg(test)]
fn refinement_capture_inventory_assert_work_cap_serialization(
    entry: &serde_json::Value,
    row_id: &str,
    trace: &RefinementObservationTrace,
    expected_roles: &std::collections::BTreeSet<&str>,
) {
    let serialized = refusal_capture_terminal_json(trace.terminal_refusal.clone());
    assert_eq!(
        serialized["kind"], "WorkCap",
        "outer refusal kind: {row_id}"
    );
    assert!(
        serialized["refinement"].is_null(),
        "outer refinement absent: {row_id}"
    );
    let serialized_work = refusal_capture_work_json(trace.work.clone());
    assert_eq!(serialized_work["refinement_scalar_operations"], 7);
    assert_eq!(serialized_work["refinement_guard_events"], 3);
    assert_eq!(serialized_work["refinement_denied_entries"], 1);
    assert_eq!(
        serialized_work["bvls04_positive_entries"],
        u32::from(entry["lambda"] == "positive")
    );
    let refusal_work = &trace
        .terminal_refusal
        .as_ref()
        .expect("typed work-cap refusal")
        .work;
    assert_eq!(
        refusal_work.refinement_scalar_operations,
        trace
            .work
            .as_ref()
            .expect("trace work")
            .refinement_scalar_operations
    );
    assert_eq!(
        refusal_work.refinement_denied_entries,
        trace
            .work
            .as_ref()
            .expect("trace work")
            .refinement_denied_entries
    );
    assert_eq!(trace.eligibility_scalar_operations, Some(7));
    assert_eq!(trace.eligibility_guard_events, Some(3));
    assert_eq!(
        trace.reservation_denial_owner,
        Some(M1TrustRegionBvls04ReservationOwner::Scalar)
    );
    let actual_roles: std::collections::BTreeSet<_> =
        trace.ordered_norms.iter().map(|norm| norm.role).collect();
    assert_eq!(
        actual_roles, *expected_roles,
        "completed roles mismatch: {row_id}"
    );
    assert!(
        trace.terminal_refusal.as_ref().is_some_and(|refusal| {
            refusal.kind == super::M1TrustRegionRefusalKind::WorkCap && refusal.refinement.is_none()
        }) && !refinement_capture_terminal_complete(trace, None),
        "outer work-cap observations cannot manufacture refinement metadata: {row_id}"
    );
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_work_cap_control() {
    use std::collections::BTreeSet;

    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    let rows: Vec<_> = inventory["entries"]
        .as_array()
        .expect("inventory entries")
        .iter()
        .filter(|entry| entry["stage"] == "not-applicable")
        .collect();
    assert_eq!(rows.len(), 2);
    let mut covered = BTreeSet::new();
    for entry in rows {
        let row_id = entry["id"].as_str().expect("work-cap row id");
        assert!(
            covered.insert(row_id.to_owned()),
            "duplicate work-cap row: {row_id}"
        );
        assert_eq!(entry["position"], "not-refinement");
        assert_eq!(entry["reason"], "not-applicable");
        let expected_roles: BTreeSet<_> = entry["completed_roles"]
            .as_array()
            .expect("work-cap completed roles")
            .iter()
            .map(|role| refinement_capture_inventory_static_role(role.as_str().expect("role")))
            .collect();
        let trace = refinement_capture_inventory_work_cap_trace(entry, &expected_roles);
        refinement_capture_inventory_assert_work_cap_reached(entry, row_id, &trace);
        refinement_capture_inventory_assert_work_cap_serialization(
            entry,
            row_id,
            &trace,
            &expected_roles,
        );
    }
    assert_eq!(covered.len(), 2, "work-cap row coverage");
    eprintln!("work-cap row coverage: {covered:?}");
}

#[cfg(test)]
fn refinement_capture_inventory_impossible_baseline_row(
    inventory: &serde_json::Value,
    row_id: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
) {
    let entry = inventory["entries"]
        .as_array()
        .expect("inventory entries")
        .iter()
        .find(|entry| entry["id"] == row_id)
        .unwrap_or_else(|| panic!("unknown approved impossible baseline row: {row_id}"));
    assert_eq!(entry["id"], row_id, "impossible baseline identity");
    assert_ne!(
        entry["stage"], "not-applicable",
        "work-cap cannot seed impossible tuple"
    );
    let locator = refinement_capture_inventory_locator_domain(entry)
        .into_iter()
        .next()
        .expect("approved baseline locator");
    let metadata = refinement_capture_inventory_domain_metadata(entry, &locator);
    let trace = refinement_capture_inventory_trace(entry, &metadata, locator.partial_operation);
    assert!(
        refinement_capture_selected_terminal_kind(&metadata, &trace)
            && refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "invalid impossible-case baseline: {}",
        entry["id"]
    );
    (trace, metadata)
}

#[cfg(test)]
fn refinement_capture_inventory_sync_terminal(
    trace: &mut RefinementObservationTrace,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) {
    trace.terminal_refusal = Some(Box::new(refinement_capture_terminal_refusal(metadata)));
}

#[cfg(test)]
fn refinement_capture_public_completeness_case(
    inventory: &serde_json::Value,
    row_id: &str,
    witness: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    serde_json::Value,
) {
    let entry = inventory["entries"]
        .as_array()
        .expect("entries")
        .iter()
        .find(|entry| entry["id"] == row_id)
        .expect("approved row");
    let locator = refinement_capture_inventory_locator_domain(entry)
        .into_iter()
        .find(|locator| witness != "W2" || locator.coordinate == Some(5))
        .expect("approved completeness locator");
    let metadata = refinement_capture_inventory_domain_metadata(entry, &locator);
    let trace = refinement_capture_inventory_trace(entry, &metadata, locator.partial_operation);
    assert!(refinement_capture_terminal_complete(
        &trace,
        Some(&metadata)
    ));
    (
        trace,
        metadata,
        refinement_capture_inventory_expected_statuses(entry),
    )
}

#[cfg(test)]
fn refinement_capture_assert_public_completeness_baseline(
    completeness: &serde_json::Value,
    row_id: &str,
    witness: &str,
    arithmetic: &str,
) {
    assert_eq!(
        completeness.as_object().expect("completeness object").len(),
        9,
        "public completeness key count: {row_id}"
    );
    assert_eq!(completeness["witness"], witness, "witness: {row_id}");
    assert_eq!(
        completeness["actual_terminal_kind"], "TrustRegionRefinementIndeterminate",
        "terminal kind: {row_id}"
    );
    let (stage, reason, position) = match row_id {
        "first-positive-ScratchFullRadius-compare" => {
            ("ScratchFullRadius", "ScratchRadius", "First")
        }
        "first-positive-ScratchFullRadius-NonfiniteOperand" => {
            ("ScratchFullRadius", "NonfiniteOperand", "First")
        }
        "second-positive-FinalBoxLower" | "second-zero-FinalBoxLower" => {
            ("FinalBoxLower", "FinalBox", "Second")
        }
        _ => unreachable!("approved completeness row"),
    };
    assert_eq!(
        completeness["actual_terminal_stage"], stage,
        "stage: {row_id}"
    );
    assert_eq!(
        completeness["actual_terminal_reason"], reason,
        "reason: {row_id}"
    );
    assert_eq!(
        completeness["actual_correction_position"], position,
        "position: {row_id}"
    );
    assert_eq!(
        completeness["reached_prefix_complete"], true,
        "{arithmetic}: {row_id}"
    );
    assert_eq!(
        completeness["actual_branch_complete"], true,
        "{arithmetic}: {row_id}"
    );
    assert_eq!(
        completeness["missing_capture_is_incomplete"], false,
        "{arithmetic}: {row_id}"
    );
    assert_eq!(
        completeness["expected_terminal_match"], true,
        "{arithmetic}: {row_id}"
    );
}

#[cfg(test)]
#[test]
fn m1_refinement_public_completeness_model_control() {
    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    for (row_id, witness, arithmetic) in [
        (
            "first-positive-ScratchFullRadius-compare",
            "W1",
            "completed",
        ),
        (
            "first-positive-ScratchFullRadius-NonfiniteOperand",
            "W1",
            "interrupted",
        ),
        ("second-positive-FinalBoxLower", "W2", "positive"),
        ("second-zero-FinalBoxLower", "W2", "zero"),
    ] {
        let (mut trace, metadata, expected) =
            refinement_capture_public_completeness_case(&inventory, row_id, witness);
        refinement_capture_inventory_sync_terminal(&mut trace, &metadata);
        assert_eq!(
            refinement_capture_field_status_json(&trace),
            expected,
            "full map: {row_id}"
        );
        let completeness = refusal_capture_completeness_json(&trace, witness);
        refinement_capture_assert_public_completeness_baseline(
            &completeness,
            row_id,
            witness,
            arithmetic,
        );
        let mut missing = trace.clone();
        missing.residual0 = None;
        refinement_capture_inventory_sync_terminal(&mut missing, &metadata);
        assert!(
            !refinement_capture_terminal_complete(&missing, Some(&metadata)),
            "centralized required member: {row_id}"
        );
        let mut missing_expected = expected.as_object().expect("full status map").clone();
        missing_expected.insert(
            "residual0_bits".into(),
            serde_json::Value::String("missing_instrumentation".into()),
        );
        assert_eq!(
            refinement_capture_field_status_json(&missing),
            serde_json::Value::Object(missing_expected),
            "mutated full map: {row_id}"
        );
        let incomplete = refusal_capture_completeness_json(&missing, witness);
        assert_eq!(
            incomplete["reached_prefix_complete"], false,
            "required member: {row_id}"
        );
        assert_eq!(
            incomplete["actual_branch_complete"], false,
            "required member: {row_id}"
        );
        assert_eq!(
            incomplete["missing_capture_is_incomplete"], true,
            "required member: {row_id}"
        );
        assert_eq!(
            incomplete["expected_terminal_match"], true,
            "protocol diagnostic: {row_id}"
        );
    }
}

#[cfg(test)]
fn refinement_capture_inventory_assert_impossible_metadata_case(
    inventory: &serde_json::Value,
    row_id: &str,
    stage: &str,
    reason: &str,
    descriptor: &str,
) {
    let (mut trace, mut metadata) =
        refinement_capture_inventory_impossible_baseline_row(inventory, row_id);
    metadata.guard_stage = m1_refinement_inventory_stage(stage);
    metadata.reason = m1_refinement_inventory_reason(reason);
    refinement_capture_inventory_sync_terminal(&mut trace, &metadata);
    assert!(
        !refinement_capture_selected_terminal_kind(&metadata, &trace)
            && !refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "impossible metadata variant accepted: {descriptor} {row_id} {stage}/{reason}"
    );
}

#[cfg(test)]
fn refinement_capture_inventory_impossible_presence_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> Option<(
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
)> {
    let (trace, metadata, selected) = match descriptor {
        "zero lambda with positive H/inverse/full/free fields" => {
            let (mut trace, metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "first-zero-factor-lambda-step-failure",
            );
            refinement_capture_inventory_set_presence(&mut trace, "h0_bits", true);
            (trace, metadata, true)
        }
        "positive lambda with zero role" => {
            let (mut trace, metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "none-positive-p0full-compare",
            );
            let p0 = trace.p0.expect("positive p0");
            trace.ordered_norms.push(refinement_capture_complete_norm(
                "p0_zero_lambda_eligibility",
                &p0,
            ));
            (trace, metadata, true)
        }
        "box terminal after P2 norm" => {
            let (mut trace, metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "second-positive-FinalBoxLower",
            );
            refinement_capture_inventory_set_presence(&mut trace, "p2_full_norm2_bits", true);
            refinement_capture_inventory_set_presence(&mut trace, "p2_full_norm_bits", true);
            (trace, metadata, true)
        }
        "app2 without app1" => {
            let (mut trace, metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "second-positive-factor-after-inverse",
            );
            trace.factor_application_identities.remove(0);
            trace.factor_application_snapshots.remove(0);
            (trace, metadata, true)
        }
        "zero missing factor: solve_face factor Some immutable" => {
            let (mut trace, metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "first-zero-factor-lambda-step-failure",
            );
            trace.factor_identity = None;
            (trace, metadata, true)
        }
        _ => return None,
    };
    Some((trace, metadata, selected))
}

#[cfg(test)]
fn refinement_capture_inventory_impossible_simple_metadata_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> Option<(
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
)> {
    let (trace, mut metadata) = match descriptor {
        "None/RadiusComparison" => refinement_capture_inventory_impossible_baseline_row(
            inventory,
            "none-positive-p0full-compare",
        ),
        "FinalInstallEquality: refinement_install_final_step writes p2 then immediately compares identical bits; no production arithmetic branch makes a refusal" => {
            refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "final-closeness-gap-exceeds-tolerance",
            )
        }
        "H1 FactorApplicationOutput Nonfinite shape: positive entry validates immutable factor/free shape and no shape poison exists" => {
            refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "second-positive-factor-before-inverse",
            )
        }
        "H0 validation shape/coordinate Nonfinite all-null" => {
            refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "first-h0-positive-PrimaryProduct-NonfiniteOperand",
            )
        }
        _ => return None,
    };
    match descriptor {
        "None/RadiusComparison" => {
            metadata.guard_stage = m1_refinement_inventory_stage("RadiusComparison");
        }
        "FinalInstallEquality: refinement_install_final_step writes p2 then immediately compares identical bits; no production arithmetic branch makes a refusal" =>
        {
            metadata.guard_stage = m1_refinement_inventory_stage("FinalInstallEquality");
        }
        "H1 FactorApplicationOutput Nonfinite shape: positive entry validates immutable factor/free shape and no shape poison exists" =>
        {
            metadata.guard_stage = m1_refinement_inventory_stage("FactorApplicationOutput");
            metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
        }
        "H0 validation shape/coordinate Nonfinite all-null" => {
            metadata.guard_stage = m1_refinement_inventory_stage("PrimaryProduct");
            metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
            metadata.row = None;
            metadata.term = None;
            metadata.coordinate = None;
        }
        _ => unreachable!(),
    }
    Some((trace, metadata, false))
}

#[cfg(test)]
fn refinement_capture_impossible_first_residual_weight_case(
    inventory: &serde_json::Value,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "first-residual-positive-ResidualSourceTerm-SubnormalIntermediate",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ResidualSourceWeight");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_h0_weight_case(
    inventory: &serde_json::Value,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "first-h0-positive-PrimaryProduct-NonfiniteOperand",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ResidualSourceWeight");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_h0_source_case(
    inventory: &serde_json::Value,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "first-h0-positive-PrimaryProduct-NonfiniteOperand",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ResidualSourceTerm");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_first_residual_source_case(
    inventory: &serde_json::Value,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "first-residual-positive-ResidualSourceTerm-SubnormalIntermediate",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ResidualSourceTerm");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_p0_assembly_case(
    inventory: &serde_json::Value,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "none-positive-p0full-compare",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("P0AssemblyEquality");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_splitter_overflow_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    for (row_id, stage) in [
        ("none-positive-p0full-compare", "P0FullRadius"),
        (
            "first-positive-ScratchFullRadius-compare",
            "ScratchFullRadius",
        ),
        (
            "final-closeness-gap-exceeds-tolerance",
            "FinalRadiusCloseness",
        ),
    ] {
        refinement_capture_inventory_assert_impossible_metadata_case(
            inventory,
            row_id,
            stage,
            "SplitterOverflow",
            descriptor,
        );
    }
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "second-residual-positive-SplitterProduct-SplitterOverflow",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("OrderedNorm");
    metadata.reason = m1_refinement_inventory_reason("SplitterOverflow");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_h0_source_pair_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    for stage in ["ResidualSourceTerm", "ResidualSourceWeight"] {
        refinement_capture_inventory_assert_impossible_metadata_case(
            inventory,
            "first-h0-positive-PrimaryProduct-NonfiniteOperand",
            stage,
            "NonfiniteOperand",
            descriptor,
        );
    }
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "first-h0-positive-PrimaryProduct-NonfiniteOperand",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ResidualSourceTerm");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_reduced_norm_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    for (row_id, stage) in [
        ("none-positive-p0full-compare", "P0ReducedRadius"),
        (
            "first-positive-ScratchReducedRadius-compare",
            "ScratchReducedRadius",
        ),
        (
            "final-positive-FinalReducedRadius-compare",
            "FinalReducedRadius",
        ),
    ] {
        refinement_capture_inventory_assert_impossible_metadata_case(
            inventory,
            row_id,
            stage,
            "NonfiniteOperand",
            descriptor,
        );
    }
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "none-positive-p0full-compare",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("OrderedNorm");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_none_active_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    refinement_capture_inventory_assert_impossible_metadata_case(
        inventory,
        "none-positive-activefinite-SubnormalIntermediate",
        "ActiveEquality",
        "NonfiniteOperand",
        descriptor,
    );
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "none-positive-activefinite-SubnormalIntermediate",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ActiveFinite");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_first_second_active_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    for row_id in [
        "first-positive-factor-before-inverse",
        "second-positive-factor-before-inverse",
    ] {
        for stage in ["ActiveFinite", "ActiveEquality"] {
            refinement_capture_inventory_assert_impossible_metadata_case(
                inventory,
                row_id,
                stage,
                "NonfiniteOperand",
                descriptor,
            );
        }
    }
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "first-positive-factor-before-inverse",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ActiveFinite");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_second_residual_source_pair_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    refinement_capture_inventory_assert_impossible_metadata_case(
        inventory,
        "second-residual-positive-PrimaryProduct-NonfiniteOperand",
        "ResidualSourceTerm",
        "NonfiniteOperand",
        descriptor,
    );
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "second-residual-positive-PrimaryProduct-NonfiniteOperand",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ResidualSourceWeight");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_impossible_h1_source_pair_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    refinement_capture_inventory_assert_impossible_metadata_case(
        inventory,
        "second-h1-positive-PrimaryProduct-NonfiniteOperand",
        "ResidualSourceTerm",
        "NonfiniteOperand",
        descriptor,
    );
    let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "second-h1-positive-PrimaryProduct-NonfiniteOperand",
    );
    metadata.guard_stage = m1_refinement_inventory_stage("ResidualSourceWeight");
    metadata.reason = m1_refinement_inventory_reason("NonfiniteOperand");
    (trace, metadata, false)
}

#[cfg(test)]
fn refinement_capture_inventory_impossible_dispatch_case(
    inventory: &serde_json::Value,
    descriptor: &str,
) -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
    bool,
) {
    match descriptor {
        "SplitterOverflow in bvls04_ordered_norm/lambda_norm/final radius closeness" => {
            refinement_capture_impossible_splitter_overflow_case(inventory, descriptor)
        }
        "first residual ResidualSourceWeight: p0 admitted before residual" => {
            refinement_capture_impossible_first_residual_weight_case(inventory)
        }
        "H0 ResidualSourceWeight: p0[free] ActiveFinite and lambda input validation already admitted operands" => {
            refinement_capture_impossible_h0_weight_case(inventory)
        }
        "H0 source term/weight: admitted immutable operands and normal selected lambda" => {
            refinement_capture_impossible_h0_source_pair_case(inventory, descriptor)
        }
        "second residual ResidualSourceTerm/Weight: prepared terms and p1 admitted before second residual" => {
            refinement_capture_impossible_second_residual_source_pair_case(inventory, descriptor)
        }
        "H1 ResidualSourceTerm/Weight: factor/lambda, residual1, and p1 admitted before H1" => {
            refinement_capture_impossible_h1_source_pair_case(inventory, descriptor)
        }
        "H0 ResidualSourceTerm Nonfinite: factor/free shape, immutable factor.a, and residual0 were admitted before H0; only positive-lambda Subnormal guard remains" => {
            refinement_capture_impossible_h0_source_case(inventory)
        }
        "first residual ResidualSourceTerm Nonfinite: weighted_system rejects nonfinite prepared residual/matrix before selection" => {
            refinement_capture_impossible_first_residual_source_case(inventory)
        }
        "Positive P0/Scratch/Final reduced ordered-norm interruption: free_ids is validated ascending subset; reduced follows successful full identical values and monotone nonnegative prefix cannot newly fail." => {
            refinement_capture_impossible_reduced_norm_case(inventory, descriptor)
        }
        "P0AssemblyEquality selected path: solve_face factor/face invariants and immutable p0 bit copy" => {
            refinement_capture_impossible_p0_assembly_case(inventory)
        }
        "None ActiveFinite Nonfinite/ActiveEquality selected path admissions" => {
            refinement_capture_impossible_none_active_case(inventory, descriptor)
        }
        "First/Second ActiveFinite/ActiveEquality no-poison corrections and active invariants" => {
            refinement_capture_impossible_first_second_active_case(inventory, descriptor)
        }
        "zero First ScratchBox: function returns immediately without refusal" => {
            let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "first-zero-factor-lambda-step-failure",
            );
            metadata.guard_stage = m1_refinement_inventory_stage("ScratchBoxLower");
            metadata.reason = m1_refinement_inventory_reason("ScratchBox");
            metadata.scratch_box_feasible = Some(false);
            (trace, metadata, false)
        }
        "positive delta validation: shifted inverse normal-or-zero output" => {
            let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "first-positive-factor-before-inverse",
            );
            metadata.guard_stage = m1_refinement_inventory_stage("FactorApplicationOutput");
            metadata.reason = m1_refinement_inventory_reason("SubnormalIntermediate");
            (trace, metadata, false)
        }
        "positive P0ReducedRadius comparison: svd_lambda_ball and repeated free norm identical ascending operands" =>
        {
            let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "none-positive-p0full-compare",
            );
            metadata.guard_stage = m1_refinement_inventory_stage("P0ReducedRadius");
            metadata.reason = m1_refinement_inventory_reason("FinalRadius");
            (trace, metadata, false)
        }
        "FinalRadiusCloseness radius/a Subnormal: selected radius=sqrt(representable positive r2), then 2^-40 radius remains normal" =>
        {
            let (trace, mut metadata) = refinement_capture_inventory_impossible_baseline_row(
                inventory,
                "final-closeness-gap-exceeds-tolerance",
            );
            metadata.guard_stage = m1_refinement_inventory_stage("FinalRadiusCloseness");
            metadata.reason = m1_refinement_inventory_reason("SubnormalIntermediate");
            (trace, metadata, false)
        }
        value => panic!("unknown approved impossible descriptor: {value}"),
    }
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_impossible_tuples_control() {
    use std::collections::BTreeSet;

    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    let descriptors = inventory["impossible"]
        .as_array()
        .expect("impossible tuples");
    assert_eq!(descriptors.len(), 25, "approved impossible tuple count");
    let mut covered = BTreeSet::new();
    for descriptor in descriptors {
        let descriptor = descriptor.as_str().expect("impossible descriptor");
        assert!(
            covered.insert(descriptor),
            "duplicate impossible descriptor: {descriptor}"
        );
        let (mut trace, metadata, selected) = if let Some(case) =
            refinement_capture_inventory_impossible_presence_case(&inventory, descriptor)
        {
            case
        } else if let Some(case) =
            refinement_capture_inventory_impossible_simple_metadata_case(&inventory, descriptor)
        {
            case
        } else {
            refinement_capture_inventory_impossible_dispatch_case(&inventory, descriptor)
        };
        refinement_capture_inventory_sync_terminal(&mut trace, &metadata);
        assert_eq!(
            refinement_capture_selected_terminal_kind(&metadata, &trace),
            selected,
            "impossible selected-terminal binding: {descriptor}"
        );
        assert!(
            !refinement_capture_terminal_complete(&trace, Some(&metadata)),
            "impossible tuple was accepted: {descriptor}"
        );
    }
    assert_eq!(covered.len(), 25, "impossible tuple coverage");
    eprintln!("impossible tuple coverage: {covered:?}");
}

#[cfg(test)]
fn refinement_capture_locator_semantics_scratch_case() {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let trace = RefinementObservationTrace {
        face_free_ids: Some(vec![2, 5, 9]),
        ..Default::default()
    };
    let metadata = |position, stage, reason, row, term, coordinate, lambda, scratch| {
        super::M1TrustRegionRefinementFailureMetadata {
            reason,
            correction_position: position,
            guard_stage: stage,
            row,
            term,
            coordinate,
            lower_active: [false; 21],
            upper_active: [false; 21],
            free: [true; 21],
            lambda,
            original_trust_radius: 1.0,
            reduced_face_radius: 1.0,
            scratch_box_feasible: scratch,
        }
    };
    let impossible_scratch = metadata(
        Some(Position::First),
        Stage::OrderedNorm,
        Reason::NonfiniteOperand,
        None,
        None,
        None,
        1.0,
        Some(false),
    );
    assert!(!refinement_capture_selected_terminal_kind(
        &impossible_scratch,
        &trace
    ));
}
/// Keep every approved locator alternative explicit in the detached inventory.
/// This is a metadata-only guard: it neither drives nor invokes the evaluator.
#[cfg(test)]
#[test]
fn m1_refinement_inventory_locator_alternatives_control() {
    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory is valid JSON");
    let entries = inventory["entries"]
        .as_array()
        .expect("approved inventory entries array");
    let mut h0_matrix = false;
    let mut h0_shift = false;
    let mut h1_inner = false;
    let mut h1_final_add = false;
    let mut nonidentity_free_id = false;
    let mut scratch_false = false;
    let mut scratch_true = false;
    for entry in entries
        .iter()
        .filter(|entry| entry["stage"] != "not-applicable")
    {
        let locator = &entry["locator"];
        let alternatives = locator["variants"]
            .as_array()
            .or_else(|| locator["term_coordinate"].as_array());
        for alternative in alternatives.into_iter().flatten() {
            let operation = alternative["operation"].as_str();
            h0_matrix |= operation == Some("matrix");
            h0_shift |= operation == Some("shift");
            let coordinate = alternative["coordinate"].as_str();
            nonidentity_free_id |= coordinate.is_some_and(|value| value.contains("free_ids"));
        }
        let term = locator["term"].as_str();
        h1_inner |= term.is_some_and(|value| value.contains("inner"));
        h1_final_add |= term.is_some_and(|value| value.contains("final-add"));
        if let Some(values) = locator["scratch_box_feasible"].as_array() {
            scratch_false |= values.iter().any(|value| value == false);
            scratch_true |= values.iter().any(|value| value == true);
        }
    }
    assert!(h0_matrix && h0_shift);
    assert!(h1_inner && h1_final_add);
    assert!(nonidentity_free_id);
    assert!(scratch_false && scratch_true);
}

#[cfg(test)]
fn refinement_capture_locator_semantics_h_cases() {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let trace = RefinementObservationTrace {
        face_free_ids: Some(vec![2, 5, 9]),
        ..Default::default()
    };
    let metadata = |position, stage, reason, row, term, coordinate, lambda, scratch| {
        super::M1TrustRegionRefinementFailureMetadata {
            reason,
            correction_position: position,
            guard_stage: stage,
            row,
            term,
            coordinate,
            lower_active: [false; 21],
            upper_active: [false; 21],
            free: [true; 21],
            lambda,
            original_trust_radius: 1.0,
            reduced_face_radius: 1.0,
            scratch_box_feasible: scratch,
        }
    };
    for row in [Some(0), None] {
        let h0 = metadata(
            Some(Position::First),
            Stage::PrimaryProduct,
            Reason::NonfiniteOperand,
            row,
            Some(0),
            Some(2),
            1.0,
            None,
        );
        assert!(refinement_capture_selected_terminal_kind(&h0, &trace));
    }
    let impossible_h0_slot = metadata(
        Some(Position::First),
        Stage::PrimaryProduct,
        Reason::NonfiniteOperand,
        Some(0),
        Some(0),
        Some(5),
        1.0,
        None,
    );
    assert!(!refinement_capture_selected_terminal_kind(
        &impossible_h0_slot,
        &trace
    ));
    for (stage, term) in [
        (Stage::PrimaryProduct, Some(0)),
        (Stage::Accumulation, None),
    ] {
        let h1 = metadata(
            Some(Position::Second),
            stage,
            Reason::NonfiniteOperand,
            None,
            term,
            Some(2),
            1.0,
            Some(true),
        );
        assert!(refinement_capture_selected_terminal_kind(&h1, &trace));
    }
    refinement_capture_locator_semantics_scratch_case();
}
#[cfg(test)]
#[test]
fn m1_refinement_inventory_alternative_shape_control() {
    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory is valid JSON");
    let entries = inventory["entries"]
        .as_array()
        .expect("approved inventory entries array");
    let mut refinement_rows = 0_usize;
    let mut work_cap_rows = 0_usize;
    let mut locator_alternatives = 0_usize;
    let mut scratch_alternatives = 0_usize;
    for entry in entries {
        let locator = &entry["locator"];
        if entry["stage"] == "not-applicable" {
            work_cap_rows += 1;
            assert_eq!(entry["position"], "not-refinement");
            assert_eq!(entry["reason"], "not-applicable");
            continue;
        }
        refinement_rows += 1;
        let alternatives = locator["variants"]
            .as_array()
            .or_else(|| locator["term_coordinate"].as_array());
        if let Some(alternatives) = alternatives {
            assert!(!alternatives.is_empty(), "empty locator alternative set");
            for alternative in alternatives {
                assert!(
                    alternative.is_object(),
                    "locator alternative is not an object"
                );
                locator_alternatives += 1;
            }
        } else {
            locator_alternatives += 1;
        }
        match locator["scratch_box_feasible"].as_array() {
            Some(values) => {
                assert!(!values.is_empty(), "empty scratch alternative set");
                for value in values {
                    assert!(value.is_boolean(), "scratch alternative is not boolean");
                    scratch_alternatives += 1;
                }
            }
            None => scratch_alternatives += 1,
        }
    }
    assert_eq!((refinement_rows, work_cap_rows), (107, 2));
    assert!(locator_alternatives > refinement_rows);
    assert!(scratch_alternatives > refinement_rows);
}

#[cfg(test)]
fn refinement_capture_locator_semantics_generic_inverse(inventory: &serde_json::Value) {
    let generic_entry = inventory["entries"]
        .as_array()
        .expect("entries")
        .iter()
        .find(|entry| entry["id"] == "second-positive-factor-before-inverse")
        .expect("generic inverse owner row");
    let generic_expected = refinement_capture_inventory_expected_statuses(generic_entry);
    let (mut generic_trace, generic_metadata) =
        refinement_capture_inventory_impossible_baseline_row(
            inventory,
            "second-positive-factor-before-inverse",
        );
    assert!(
        refinement_capture_terminal_complete(&generic_trace, Some(&generic_metadata)),
        "accepted generic inverse owner baseline"
    );
    assert_eq!(
        refinement_capture_field_status_json(&generic_trace),
        generic_expected,
        "full public map: generic inverse owner baseline"
    );
    generic_trace.inverse_t = Some(vec![9.0]);
    refinement_capture_inventory_sync_terminal(&mut generic_trace, &generic_metadata);
    assert!(
        !refinement_capture_terminal_complete(&generic_trace, Some(&generic_metadata)),
        "generic inverse from the wrong ordinal owner accepted"
    );
    assert_eq!(
        refinement_capture_field_status_json(&generic_trace),
        generic_expected,
        "full public map: generic inverse value mismatch"
    );
}

#[cfg(test)]
fn refinement_capture_locator_semantics_inverse_owner(inventory: &serde_json::Value) {
    let owner_entry = inventory["entries"]
        .as_array()
        .expect("entries")
        .iter()
        .find(|entry| entry["id"] == "second-positive-factor-after-inverse")
        .expect("second completed inverse row");
    let owner_expected = refinement_capture_inventory_expected_statuses(owner_entry);
    let (mut owner_trace, owner_metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "second-positive-factor-after-inverse",
    );
    let first = owner_trace
        .factor_application_snapshots
        .first_mut()
        .expect("first completed snapshot");
    first.inverse_t_bits = Some(vec![1.0_f64.to_bits()]);
    first.inverse_denominator_bits = Some(vec![2.0_f64.to_bits()]);
    first.inverse_z_bits = Some(vec![3.0_f64.to_bits()]);
    assert!(
        refinement_capture_terminal_complete(&owner_trace, Some(&owner_metadata)),
        "accepted owner-two generic inverse baseline"
    );
    assert_eq!(
        refinement_capture_field_status_json(&owner_trace),
        owner_expected,
        "full public map: owner-two generic inverse baseline"
    );
    owner_trace.inverse_t = Some(vec![1.0]);
    owner_trace.inverse_denominator = Some(vec![2.0]);
    owner_trace.inverse_z = Some(vec![3.0]);
    refinement_capture_inventory_sync_terminal(&mut owner_trace, &owner_metadata);
    assert!(
        !refinement_capture_terminal_complete(&owner_trace, Some(&owner_metadata)),
        "generic inverse incorrectly accepted ordinal-one copies for ordinal-two owner"
    );
    assert_eq!(
        refinement_capture_field_status_json(&owner_trace),
        owner_expected,
        "full public map: generic inverse wrong ordinal owner"
    );
}

#[cfg(test)]
fn refinement_capture_locator_semantics_coordinate_mutations(inventory: &serde_json::Value) {
    for (row_id, label, replacement_coordinate) in [
        (
            "first-h0-positive-PrimaryProduct-NonfiniteOperand",
            "H0 nonidentity slot/member join",
            5,
        ),
        (
            "second-h1-positive-PrimaryProduct-NonfiniteOperand",
            "H1 coordinate outside free IDs",
            0,
        ),
    ] {
        let entry = inventory["entries"]
            .as_array()
            .expect("entries")
            .iter()
            .find(|entry| entry["id"] == row_id)
            .expect("H locator row");
        let expected = refinement_capture_inventory_expected_statuses(entry);
        let (mut trace, mut metadata) =
            refinement_capture_inventory_impossible_baseline_row(inventory, row_id);
        assert!(
            refinement_capture_terminal_complete(&trace, Some(&metadata)),
            "accepted H locator baseline: {label}"
        );
        assert_eq!(
            metadata.coordinate,
            Some(2),
            "nonidentity H locator baseline: {label}"
        );
        metadata.coordinate = Some(replacement_coordinate);
        refinement_capture_inventory_sync_terminal(&mut trace, &metadata);
        assert!(
            !refinement_capture_terminal_complete(&trace, Some(&metadata)),
            "H locator corruption accepted: {label}"
        );
        assert_eq!(
            refinement_capture_field_status_json(&trace),
            expected,
            "full public map: {label}"
        );
    }
}

#[cfg(test)]
fn refinement_capture_locator_semantics_partial_norms(inventory: &serde_json::Value) {
    let partial_entry = inventory["entries"]
        .as_array()
        .expect("entries")
        .iter()
        .find(|entry| entry["id"] == "none-positive-p0full-SubnormalIntermediate")
        .expect("partial norm row");
    let partial_expected = refinement_capture_inventory_expected_statuses(partial_entry);
    let (partial_baseline, partial_metadata) = refinement_capture_inventory_impossible_baseline_row(
        inventory,
        "none-positive-p0full-SubnormalIntermediate",
    );
    for (label, mut trace) in [
        ("interrupted norm role", {
            let mut trace = partial_baseline.clone();
            trace.partial_ordered_norms[0].role = "p1_full";
            trace
        }),
        ("interrupted norm domain", {
            let mut trace = partial_baseline.clone();
            trace.partial_ordered_norms[0].coordinate_ids = vec![1];
            trace
        }),
    ] {
        refinement_capture_inventory_sync_terminal(&mut trace, &partial_metadata);
        assert!(
            !refinement_capture_terminal_complete(&trace, Some(&partial_metadata)),
            "interrupted norm corruption accepted: {label}"
        );
        assert_eq!(
            refinement_capture_field_status_json(&trace),
            partial_expected,
            "full public map: {label}"
        );
    }
}

#[cfg(test)]
fn refinement_capture_locator_semantics_selected_cases() {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let trace = RefinementObservationTrace {
        face_free_ids: Some(vec![2, 5, 9]),
        ..Default::default()
    };
    let metadata = |position, stage, reason, row, term, coordinate, lambda, scratch| {
        super::M1TrustRegionRefinementFailureMetadata {
            reason,
            correction_position: position,
            guard_stage: stage,
            row,
            term,
            coordinate,
            lower_active: [false; 21],
            upper_active: [false; 21],
            free: [true; 21],
            lambda,
            original_trust_radius: 1.0,
            reduced_face_radius: 1.0,
            scratch_box_feasible: scratch,
        }
    };
    for (term, coordinate) in [(0, None), (1, Some(0))] {
        let residual = metadata(
            Some(Position::First),
            Stage::ResidualSourceTerm,
            Reason::SubnormalIntermediate,
            Some(0),
            Some(term),
            coordinate,
            1.0,
            None,
        );
        assert!(refinement_capture_selected_terminal_kind(&residual, &trace));
    }
    let impossible_residual = metadata(
        Some(Position::First),
        Stage::ResidualSourceTerm,
        Reason::SubnormalIntermediate,
        Some(0),
        Some(0),
        Some(1),
        1.0,
        None,
    );
    assert!(!refinement_capture_selected_terminal_kind(
        &impossible_residual,
        &trace
    ));
    refinement_capture_locator_semantics_h_cases();
}

#[cfg(test)]
fn refinement_capture_locator_semantics_marker_expected(
    expected: &serde_json::Value,
) -> serde_json::Value {
    let mut statuses = expected.as_object().expect("baseline status map").clone();
    for name in [
        "delta0_bits",
        "factor_application_snapshot_1_delta_bits",
        "factor_application_snapshot_1_inverse_t_bits",
        "factor_application_snapshot_1_inverse_denominator_bits",
        "factor_application_snapshot_1_inverse_z_bits",
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
    ] {
        statuses.insert(
            name.into(),
            serde_json::Value::String("missing_instrumentation".into()),
        );
    }
    serde_json::Value::Object(statuses)
}

#[cfg(test)]
fn refinement_capture_locator_semantics_cases(
    baseline: &RefinementObservationTrace,
    expected: &serde_json::Value,
) -> Vec<(&'static str, RefinementObservationTrace, serde_json::Value)> {
    let mut cases: Vec<(&'static str, RefinementObservationTrace, serde_json::Value)> = Vec::new();
    let mut marker = baseline.clone();
    marker.factor_output_copy_boundary =
        Some((2, RefinementFactorOutputCopyBoundary::BeforeInverse));
    cases.push((
        "marker ordinal",
        marker,
        refinement_capture_locator_semantics_marker_expected(expected),
    ));
    let mut marker_boundary = baseline.clone();
    marker_boundary.factor_output_copy_boundary =
        Some((1, RefinementFactorOutputCopyBoundary::AfterDelta));
    cases.push((
        "marker boundary",
        marker_boundary,
        refinement_capture_locator_semantics_marker_expected(expected),
    ));
    let mut count = baseline.clone();
    count.factor_applications = 2;
    cases.push(("application count", count, expected.clone()));
    let mut snapshot = baseline.clone();
    snapshot.factor_application_snapshots[0].ordinal = 2;
    cases.push(("snapshot ordinal", snapshot, expected.clone()));
    let mut snapshot_count = baseline.clone();
    snapshot_count
        .factor_application_snapshots
        .push(RefinementFactorApplicationSnapshot {
            ordinal: 2,
            identity: baseline.factor_application_snapshots[0].identity,
            h_bits: None,
            inverse_t_bits: None,
            inverse_denominator_bits: None,
            inverse_z_bits: None,
            delta_bits: None,
        });
    cases.push(("snapshot count", snapshot_count, expected.clone()));
    let mut free = baseline.clone();
    free.face_free_ids = Some(vec![0]);
    cases.push(("H free-id", free, expected.clone()));
    let mut inverse = baseline.clone();
    inverse.inverse_t = Some(vec![9.0]);
    let mut inverse_expected = expected.as_object().expect("baseline status map").clone();
    inverse_expected.insert(
        "inverse_t_bits".into(),
        serde_json::Value::String("contradictory_stray_presence".into()),
    );
    cases.push((
        "inverse owner",
        inverse,
        serde_json::Value::Object(inverse_expected),
    ));
    let mut norm = baseline.clone();
    norm.ordered_norms[0].coordinate_ids = vec![0];
    cases.push(("norm domain", norm, expected.clone()));
    let mut norm_role = baseline.clone();
    norm_role.ordered_norms[0].role = "p1_full";
    cases.push(("norm role", norm_role, expected.clone()));
    let mut scalar = baseline.clone();
    scalar.p0_full_norm = Some(9.0);
    cases.push(("scalar copy", scalar, expected.clone()));
    let mut shape = baseline.clone();
    shape.factor_application_snapshots[0].h_bits = Some(Vec::new());
    cases.push(("malformed snapshot vector", shape, expected.clone()));
    cases
}
/// Concrete metadata controls for locator alternatives that share a guard
/// stage name but select distinct operation sites.
#[cfg(test)]
#[test]
fn m1_refinement_inventory_locator_semantics_control() {
    refinement_capture_locator_semantics_selected_cases();
    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("inventory");
    let entry = inventory["entries"]
        .as_array()
        .expect("entries")
        .iter()
        .find(|entry| entry["id"] == "first-positive-factor-before-inverse")
        .expect("factor row");
    let expected = refinement_capture_inventory_expected_statuses(entry);
    let (baseline, metadata) = refinement_capture_inventory_impossible_baseline_row(
        &inventory,
        "first-positive-factor-before-inverse",
    );
    assert!(
        refinement_capture_terminal_complete(&baseline, Some(&metadata)),
        "accepted join baseline"
    );
    let cases = refinement_capture_locator_semantics_cases(&baseline, &expected);
    for (label, mut trace, expected) in cases {
        refinement_capture_inventory_sync_terminal(&mut trace, &metadata);
        assert!(
            !refinement_capture_terminal_complete(&trace, Some(&metadata)),
            "join corruption accepted: {label}"
        );
        assert_eq!(
            refinement_capture_field_status_json(&trace),
            expected,
            "full public map: {label}"
        );
    }
    refinement_capture_locator_semantics_generic_inverse(&inventory);
    refinement_capture_locator_semantics_inverse_owner(&inventory);
    refinement_capture_locator_semantics_coordinate_mutations(&inventory);
    refinement_capture_locator_semantics_partial_norms(&inventory);
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_compound_copy_boundary_control() {
    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    let expected = |row_id: &str| {
        refinement_capture_inventory_expected_statuses(
            inventory["entries"]
                .as_array()
                .expect("entries")
                .iter()
                .find(|entry| entry["id"] == row_id)
                .expect("approved row"),
        )
    };
    let assert_baseline = |trace: &RefinementObservationTrace,
                           metadata: &super::M1TrustRegionRefinementFailureMetadata,
                           expected: &serde_json::Value,
                           label: &str| {
        assert!(
            refinement_capture_terminal_complete(trace, Some(metadata)),
            "accepted baseline: {label}"
        );
        assert_eq!(
            refinement_capture_field_status_json(trace),
            *expected,
            "full baseline map: {label}"
        );
    };
    let (mut positive, mut positive_metadata) =
        refinement_capture_inventory_impossible_baseline_row(
            &inventory,
            "first-positive-CoordinateUpdate",
        );
    let positive_expected = expected("first-positive-CoordinateUpdate");
    assert_baseline(
        &positive,
        &positive_metadata,
        &positive_expected,
        "positive completed application",
    );
    positive_metadata.guard_stage =
        super::M1TrustRegionRefinementGuardStage::FactorApplicationOutput;
    positive_metadata.reason = super::M1TrustRegionRefinementReason::FactorOutput;
    positive_metadata.row = None;
    positive_metadata.term = None;
    positive_metadata.coordinate = None;
    refinement_capture_inventory_sync_terminal(&mut positive, &positive_metadata);
    assert!(
        !refinement_capture_terminal_complete(&positive, Some(&positive_metadata)),
        "positive AfterDelta accepted"
    );
    assert_eq!(
        refinement_capture_field_status_json(&positive),
        positive_expected,
        "full map: positive AfterDelta"
    );
    let (mut zero, zero_metadata) = refinement_capture_inventory_impossible_baseline_row(
        &inventory,
        "first-zero-factor-lambda-step-failure",
    );
    let zero_expected = expected("first-zero-factor-lambda-step-failure");
    assert_baseline(&zero, &zero_metadata, &zero_expected, "zero BeforeInverse");
    zero.factor_output_copy_boundary = Some((1, RefinementFactorOutputCopyBoundary::AfterInverse));
    assert!(
        !refinement_capture_terminal_complete(&zero, Some(&zero_metadata)),
        "zero AfterInverse accepted"
    );
    assert_eq!(
        refinement_capture_field_status_json(&zero),
        zero_expected,
        "full map: zero AfterInverse"
    );
    for marker in [
        Some((1, RefinementFactorOutputCopyBoundary::BeforeInverse)),
        Some((2, RefinementFactorOutputCopyBoundary::AfterDelta)),
    ] {
        let (mut trace, metadata) = refinement_capture_inventory_impossible_baseline_row(
            &inventory,
            "first-positive-CoordinateUpdate",
        );
        assert_baseline(
            &trace,
            &metadata,
            &positive_expected,
            "completed marker baseline",
        );
        trace.factor_output_copy_boundary = marker;
        assert!(
            !refinement_capture_terminal_complete(&trace, Some(&metadata)),
            "completed marker accepted: {marker:?}"
        );
        assert_eq!(
            refinement_capture_field_status_json(&trace),
            positive_expected,
            "full map: completed marker {marker:?}"
        );
    }
}

#[cfg(test)]
#[test]
fn m1_refinement_inventory_locator_numeric_domains_control() {
    // Each malformed tuple starts from an accepted, inventory-built full
    // terminal. The expected public map remains the independently expanded
    // valid observation contract; malformed metadata must reject without
    // permitting a status-key/value escape.
    let inventory: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../inventory-approved-discovery.json"
    )))
    .expect("approved inventory JSON");
    let assert_invalid =
        |row_id: &str,
         label: &str,
         mutator: fn(&mut super::M1TrustRegionRefinementFailureMetadata)| {
            let (mut trace, mut metadata) =
                refinement_capture_inventory_impossible_baseline_row(&inventory, row_id);
            assert!(
                refinement_capture_terminal_complete(&trace, Some(&metadata)),
                "valid baseline: {label}"
            );
            let expected = refinement_capture_inventory_expected_statuses(
                inventory["entries"]
                    .as_array()
                    .expect("entries")
                    .iter()
                    .find(|entry| entry["id"] == row_id)
                    .expect("baseline row"),
            );
            mutator(&mut metadata);
            refinement_capture_inventory_sync_terminal(&mut trace, &metadata);
            assert!(
                !refinement_capture_terminal_complete(&trace, Some(&metadata)),
                "invalid tuple accepted: {label}"
            );
            assert_eq!(
                refinement_capture_field_status_json(&trace),
                expected,
                "full public map: {label}"
            );
        };
    for (label, mutator) in [
        (
            "lambda NaN",
            (|metadata: &mut super::M1TrustRegionRefinementFailureMetadata| {
                metadata.lambda = f64::NAN;
            }) as fn(&mut super::M1TrustRegionRefinementFailureMetadata),
        ),
        ("lambda infinity", |metadata| {
            metadata.lambda = f64::INFINITY;
        }),
        ("lambda negative", |metadata| metadata.lambda = -1.0),
        ("original radius zero", |metadata| {
            metadata.original_trust_radius = 0.0;
        }),
        ("original radius infinity", |metadata| {
            metadata.original_trust_radius = f64::INFINITY;
        }),
        ("original radius NaN", |metadata| {
            metadata.original_trust_radius = f64::NAN;
        }),
        ("original radius negative", |metadata| {
            metadata.original_trust_radius = -1.0;
        }),
        ("reduced radius zero", |metadata| {
            metadata.reduced_face_radius = 0.0;
        }),
        ("reduced radius negative", |metadata| {
            metadata.reduced_face_radius = -1.0;
        }),
        ("reduced radius infinity", |metadata| {
            metadata.reduced_face_radius = f64::INFINITY;
        }),
        ("reduced radius NaN", |metadata| {
            metadata.reduced_face_radius = f64::NAN;
        }),
    ] {
        assert_invalid("none-positive-p0full-compare", label, mutator);
    }
    assert_invalid(
        "first-residual-positive-PrimaryProduct-NonfiniteOperand",
        "locator out of range",
        |metadata| metadata.coordinate = Some(21),
    );
    assert_invalid(
        "first-residual-positive-PrimaryProduct-NonfiniteOperand",
        "locator incompatible null",
        |metadata| metadata.coordinate = None,
    );
    assert_invalid(
        "first-residual-positive-PrimaryProduct-NonfiniteOperand",
        "reason stage conflict",
        |metadata| metadata.reason = super::M1TrustRegionRefinementReason::ScratchRadius,
    );
    assert_invalid(
        "first-residual-positive-PrimaryProduct-NonfiniteOperand",
        "scratch conflict",
        |metadata| metadata.scratch_box_feasible = Some(false),
    );
    refinement_capture_inventory_locator_numeric_domains_range_cases();
}
#[cfg(test)]
fn refinement_capture_inventory_locator_numeric_domains_range_cases() {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let trace = RefinementObservationTrace {
        face_free_ids: Some(vec![2, 5, 9]),
        ..Default::default()
    };
    let terminal = |stage, row, term, coordinate| super::M1TrustRegionRefinementFailureMetadata {
        reason: Reason::NonfiniteOperand,
        correction_position: Some(Position::Second),
        guard_stage: stage,
        row,
        term,
        coordinate,
        lower_active: [false; 21],
        upper_active: [false; 21],
        free: [true; 21],
        lambda: 1.0,
        original_trust_radius: 1.0,
        reduced_face_radius: 1.0,
        scratch_box_feasible: Some(true),
    };
    for row in 0..21_u8 {
        for term in 1..=21_u8 {
            let residual = super::M1TrustRegionRefinementFailureMetadata {
                reason: Reason::NonfiniteOperand,
                correction_position: Some(Position::First),
                guard_stage: Stage::PrimaryProduct,
                row: Some(row),
                term: Some(term),
                coordinate: Some(term - 1),
                lower_active: [false; 21],
                upper_active: [false; 21],
                free: [true; 21],
                lambda: 1.0,
                original_trust_radius: 1.0,
                reduced_face_radius: 1.0,
                scratch_box_feasible: None,
            };
            assert!(refinement_capture_selected_terminal_kind(&residual, &trace));
        }
    }
    for (slot, coordinate) in [(0_u8, 2_u8), (1, 5), (2, 9)] {
        for row in 0..21_u8 {
            let matrix = super::M1TrustRegionRefinementFailureMetadata {
                reason: Reason::NonfiniteOperand,
                correction_position: Some(Position::First),
                guard_stage: Stage::PrimaryProduct,
                row: Some(row),
                term: Some(slot),
                coordinate: Some(coordinate),
                lower_active: [false; 21],
                upper_active: [false; 21],
                free: [true; 21],
                lambda: 1.0,
                original_trust_radius: 1.0,
                reduced_face_radius: 1.0,
                scratch_box_feasible: None,
            };
            assert!(refinement_capture_selected_terminal_kind(&matrix, &trace));
        }
        for term in 0..=21_u8 {
            assert!(refinement_capture_selected_terminal_kind(
                &terminal(Stage::PrimaryProduct, None, Some(term), Some(coordinate)),
                &trace
            ));
        }
        for term in 1..=21_u8 {
            assert!(refinement_capture_selected_terminal_kind(
                &terminal(Stage::Accumulation, None, Some(term), Some(coordinate)),
                &trace
            ));
        }
        assert!(refinement_capture_selected_terminal_kind(
            &terminal(Stage::Accumulation, None, None, Some(coordinate)),
            &trace
        ));
    }
}

#[cfg(test)]
fn refinement_capture_factor_output_zero_lambda_tail(
    metadata: &mut super::M1TrustRegionRefinementFailureMetadata,
    trace: &mut RefinementObservationTrace,
) {
    use super::M1TrustRegionCorrectionPosition as Position;
    metadata.lambda = 0.0;
    metadata.correction_position = Some(Position::First);
    trace.factor_application_snapshots.truncate(1);
    trace.factor_application_identities.truncate(1);
    trace.factor_applications = 1;
    trace.factor_output_copy_boundary =
        Some((1, RefinementFactorOutputCopyBoundary::BeforeInverse));
    trace
        .terminal_refusal
        .as_mut()
        .expect("terminal refusal")
        .refinement = Some(Box::new(metadata.clone()));
    trace.inverse_t = None;
    trace.inverse_denominator = None;
    trace.inverse_z = None;
    trace.delta0 = None;
    trace.factor_application_snapshots[0].delta_bits = None;
    let statuses = refinement_capture_field_status_json(trace);
    assert_eq!(statuses["delta0_bits"], "interrupted");
    trace.delta0 = Some(vec![4.0]);
    trace.factor_application_snapshots[0].delta_bits = Some(vec![4.0_f64.to_bits()]);
    trace.factor_output_copy_boundary = Some((1, RefinementFactorOutputCopyBoundary::AfterDelta));
    let statuses = refinement_capture_field_status_json(trace);
    assert_eq!(statuses["delta0_bits"], "captured");
    trace.delta0 = None;
    let statuses = refinement_capture_field_status_json(trace);
    assert_eq!(statuses["delta0_bits"], "missing_instrumentation");
    trace.delta0 = Some(vec![4.0]);
    trace.inverse_t = None;
    trace.inverse_denominator = None;
    trace.inverse_z = None;
    let snapshot = trace
        .factor_application_snapshots
        .last_mut()
        .expect("first snapshot");
    snapshot.h_bits = None;
    snapshot.inverse_t_bits = None;
    snapshot.inverse_denominator_bits = None;
    snapshot.inverse_z_bits = None;
    trace.factor_output_copy_boundary =
        Some((1, RefinementFactorOutputCopyBoundary::BeforeInverse));
    assert_ne!(
        refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary)
            .field_state("delta0_bits"),
        RefinementCaptureTerminalFieldState::Required
    );
    trace.delta0 = Some(vec![4.0]);
    trace
        .factor_application_snapshots
        .last_mut()
        .expect("first snapshot")
        .delta_bits = Some(vec![4.0_f64.to_bits()]);
    trace.factor_output_copy_boundary = Some((1, RefinementFactorOutputCopyBoundary::AfterDelta));
    assert_eq!(
        refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary)
            .field_state("delta0_bits"),
        RefinementCaptureTerminalFieldState::Required
    );
}

#[cfg(test)]
fn refinement_capture_factor_output_second_ordinal(
    metadata: &mut super::M1TrustRegionRefinementFailureMetadata,
    trace: &mut RefinementObservationTrace,
) {
    use super::M1TrustRegionCorrectionPosition as Position;
    metadata.correction_position = Some(Position::Second);
    trace
        .factor_application_snapshots
        .push(RefinementFactorApplicationSnapshot {
            ordinal: 2,
            identity: 7,
            h_bits: Some(vec![4.0_f64.to_bits()]),
            inverse_t_bits: None,
            inverse_denominator_bits: None,
            inverse_z_bits: None,
            delta_bits: None,
        });
    trace.factor_application_identities = vec![7, 7];
    trace.factor_applications = 2;
    trace.factor_identity = Some(7);
    trace.residual0 = Some([0.0; 21]);
    trace.h0 = Some(vec![1.0]);
    trace.delta0 = Some(vec![9.0]);
    trace.factor_application_snapshots[0].delta_bits = Some(vec![9.0_f64.to_bits()]);
    trace.residual1 = Some([0.0; 21]);
    trace.h1 = Some(vec![4.0]);
    trace.factor_output_copy_boundary =
        Some((2, RefinementFactorOutputCopyBoundary::BeforeInverse));
    trace
        .terminal_refusal
        .as_mut()
        .expect("terminal refusal")
        .refinement = Some(Box::new(metadata.clone()));
    let statuses = refinement_capture_field_status_json(trace);
    assert!(refinement_capture_factor_output_prefix(
        trace,
        &refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary),
        2,
        true,
    ));
    assert!(refinement_capture_resolved_factor_content(
        trace,
        &refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary),
        true,
    ));
    assert_eq!(statuses["inverse_t_bits"], "captured");
    assert_eq!(statuses["inverse_denominator_bits"], "captured");
    assert_eq!(statuses["inverse_z_bits"], "captured");
    assert_eq!(
        statuses["factor_application_snapshot_1_inverse_t_bits"],
        "captured"
    );
    assert_eq!(
        statuses["factor_application_snapshot_2_inverse_t_bits"],
        "interrupted"
    );
    trace.factor_application_snapshots[0].inverse_t_bits = None;
    assert!(
        !refinement_capture_resolved_factor_content(
            trace,
            &refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary),
            true,
        ),
        "ordinal-two factor refusal must retain a complete ordinal-one snapshot"
    );
    let statuses = refinement_capture_field_status_json(trace);
    assert_eq!(
        statuses["factor_application_snapshot_1_inverse_t_bits"],
        "missing_instrumentation"
    );
    trace.factor_application_snapshots[0].inverse_t_bits = Some(vec![1.0_f64.to_bits()]);
    trace.factor_application_snapshots[1].inverse_t_bits = Some(vec![4.0_f64.to_bits()]);
    trace.factor_application_snapshots[1].inverse_denominator_bits = Some(vec![5.0_f64.to_bits()]);
    trace.factor_application_snapshots[1].inverse_z_bits = Some(vec![6.0_f64.to_bits()]);
    trace.inverse_t = Some(vec![4.0]);
    trace.inverse_denominator = Some(vec![5.0]);
    trace.inverse_z = Some(vec![6.0]);
    trace.factor_output_copy_boundary = Some((2, RefinementFactorOutputCopyBoundary::AfterInverse));
    let statuses = refinement_capture_field_status_json(trace);
    assert!(refinement_capture_factor_output_prefix(
        trace,
        &refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary),
        2,
        true,
    ));
    assert_eq!(statuses["inverse_t_bits"], "captured");
    assert_eq!(statuses["inverse_denominator_bits"], "captured");
    assert_eq!(statuses["inverse_z_bits"], "captured");
}
#[cfg(test)]
fn refinement_capture_factor_output_copy_boundary_metadata()
-> super::M1TrustRegionRefinementFailureMetadata {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };

    super::M1TrustRegionRefinementFailureMetadata {
        reason: Reason::FactorOutput,
        correction_position: Some(Position::First),
        guard_stage: Stage::FactorApplicationOutput,
        row: None,
        term: None,
        coordinate: None,
        lower_active: [false; 21],
        upper_active: [false; 21],
        free: [true; 21],
        lambda: 1.0,
        original_trust_radius: 1.0,
        reduced_face_radius: 1.0,
        scratch_box_feasible: None,
    }
}

#[cfg(test)]
#[test]
fn m1_refinement_factor_output_copy_boundary_control() {
    let mut metadata = refinement_capture_factor_output_copy_boundary_metadata();
    let mut trace = RefinementObservationTrace::default();
    trace
        .factor_application_snapshots
        .push(RefinementFactorApplicationSnapshot {
            ordinal: 1,
            identity: 7,
            h_bits: Some(vec![1.0_f64.to_bits()]),
            inverse_t_bits: None,
            inverse_denominator_bits: None,
            inverse_z_bits: None,
            delta_bits: None,
        });
    trace.factor_applications = 1;
    trace.factor_output_copy_boundary =
        Some((1, RefinementFactorOutputCopyBoundary::BeforeInverse));
    trace.terminal_refusal = Some(Box::new(super::M1TrustRegionSubproblemRefusal {
        kind: super::M1TrustRegionRefusalKind::TrustRegionRefinementIndeterminate,
        optimality_reason: None,
        optimality_coordinate: None,
        optimality_radius: None,
        optimality_lambda: None,
        attempted_subproblems: 0,
        completed_jacobi_sweeps: 0,
        completed_face_pivots: 0,
        entered_svd_factorizations: 0,
        raw_residual_max: 0.0,
        work: Box::default(),
        refinement: Some(Box::new(metadata.clone())),
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_refusal: None,
    }));
    refinement_capture_assert_full_public_status_map(&trace);
    let statuses = refinement_capture_field_status_json(&trace);
    assert_eq!(statuses["inverse_t_bits"], "interrupted");
    assert_eq!(statuses["factor_output_copy_boundary"], "captured");
    trace.factor_output_copy_boundary = None;
    let statuses = refinement_capture_field_status_json(&trace);
    assert_eq!(
        statuses["factor_output_copy_boundary"],
        "missing_instrumentation"
    );
    // A missing operation marker cannot turn the already-selected H/inverse
    // boundary into natural absence.  Every public projection must retain a
    // required expectation until the marker is restored.
    assert_eq!(statuses["factor_application_snapshot_1_h_bits"], "captured");
    assert_eq!(
        statuses["factor_application_snapshot_1_inverse_t_bits"],
        "missing_instrumentation"
    );
    assert_eq!(statuses["inverse_t_bits"], "missing_instrumentation");
    trace.factor_output_copy_boundary =
        Some((1, RefinementFactorOutputCopyBoundary::BeforeInverse));
    trace.inverse_t = Some(vec![1.0]);
    let statuses = refinement_capture_field_status_json(&trace);
    assert_eq!(statuses["inverse_t_bits"], "contradictory_stray_presence");
    trace.inverse_t = None;
    assert_ne!(
        refinement_capture_resolved_terminal(&metadata, trace.factor_output_copy_boundary)
            .field_state("inverse_t_bits"),
        RefinementCaptureTerminalFieldState::Required
    );
    trace.inverse_t = Some(vec![1.0]);
    trace.inverse_denominator = Some(vec![2.0]);
    trace.inverse_z = Some(vec![3.0]);
    let snapshot = trace
        .factor_application_snapshots
        .last_mut()
        .expect("first snapshot");
    snapshot.inverse_t_bits = Some(vec![1.0_f64.to_bits()]);
    snapshot.inverse_denominator_bits = Some(vec![2.0_f64.to_bits()]);
    snapshot.inverse_z_bits = Some(vec![3.0_f64.to_bits()]);
    trace.factor_output_copy_boundary = Some((1, RefinementFactorOutputCopyBoundary::AfterInverse));
    assert_eq!(
        refinement_capture_resolved_terminal(&metadata, trace.factor_output_copy_boundary)
            .field_state("inverse_t_bits"),
        RefinementCaptureTerminalFieldState::Required
    );
    trace.inverse_denominator = None;
    let statuses = refinement_capture_field_status_json(&trace);
    assert_eq!(
        statuses["inverse_denominator_bits"],
        "missing_instrumentation"
    );
    trace.inverse_denominator = Some(vec![2.0]);
    refinement_capture_factor_output_second_ordinal(&mut metadata, &mut trace);
    refinement_capture_factor_output_zero_lambda_tail(&mut metadata, &mut trace);
}

/// Refusal comparisons are resolved by metadata but must still prove the
/// rejecting side of the copied ordered operand, including zero-lambda paths.
#[cfg(test)]
#[test]
fn m1_refinement_resolved_refusal_comparison_control() {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let metadata =
        |position, stage, reason, lambda| super::M1TrustRegionRefinementFailureMetadata {
            reason,
            correction_position: position,
            guard_stage: stage,
            row: None,
            term: None,
            coordinate: None,
            lower_active: [false; 21],
            upper_active: [false; 21],
            free: [true; 21],
            lambda,
            original_trust_radius: 1.0,
            reduced_face_radius: 0.5,
            scratch_box_feasible: Some(true),
        };
    for (terminal, role, expected) in [
        (
            metadata(None, Stage::P0FullRadius, Reason::FinalRadius, 1.0),
            "p0_full",
            1.0_f64,
        ),
        (
            metadata(
                Some(Position::First),
                Stage::ScratchReducedRadius,
                Reason::ScratchRadius,
                1.0,
            ),
            "p1_free",
            0.5,
        ),
        (
            metadata(
                Some(Position::First),
                Stage::RadiusComparison,
                Reason::ScratchRadius,
                0.0,
            ),
            "p1_zero_lambda_scratch",
            1.0,
        ),
        (
            metadata(
                Some(Position::Second),
                Stage::RadiusComparison,
                Reason::FinalRadius,
                0.0,
            ),
            "p2_zero_lambda_final",
            1.0,
        ),
    ] {
        let mut trace = RefinementObservationTrace::default();
        trace.ordered_norms.push(RefinementOrderedNormTrace {
            role,
            coordinate_ids: Vec::new(),
            value_bits: Vec::new(),
            square_bits: Vec::new(),
            running_sum_bits: Vec::new(),
            norm2_bits: 0.0_f64.to_bits(),
            norm_bits: (expected * 2.0).to_bits(),
        });
        let resolved =
            refinement_capture_resolved_terminal(&terminal, trace.factor_output_copy_boundary);
        assert!(refinement_capture_resolved_refusing_comparison(
            &trace, &resolved
        ));
        trace.ordered_norms[0].norm_bits = expected.to_bits();
        assert!(!refinement_capture_resolved_refusing_comparison(
            &trace, &resolved
        ));
    }
}

#[cfg(test)]
fn refinement_capture_complete_norm(
    role: &'static str,
    values: &[f64],
) -> RefinementOrderedNormTrace {
    let coordinate_ids: Vec<_> = (0..values.len()).collect();
    let value_bits: Vec<_> = values.iter().map(|value| value.to_bits()).collect();
    let square_bits: Vec<_> = values
        .iter()
        .map(|value| (value * value).to_bits())
        .collect();
    let mut sum = 0.0;
    let running_sum_bits = values
        .iter()
        .map(|value| {
            sum += value * value;
            sum.to_bits()
        })
        .collect();
    RefinementOrderedNormTrace {
        role,
        coordinate_ids,
        value_bits,
        square_bits,
        running_sum_bits,
        norm2_bits: sum.to_bits(),
        norm_bits: sum.sqrt().to_bits(),
    }
}

#[cfg(test)]
fn refinement_capture_terminal_refusal(
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) -> super::M1TrustRegionSubproblemRefusal {
    super::M1TrustRegionSubproblemRefusal {
        kind: super::M1TrustRegionRefusalKind::TrustRegionRefinementIndeterminate,
        optimality_reason: None,
        optimality_coordinate: None,
        optimality_radius: None,
        optimality_lambda: None,
        attempted_subproblems: 0,
        completed_jacobi_sweeps: 0,
        completed_face_pivots: 0,
        entered_svd_factorizations: 0,
        raw_residual_max: 0.0,
        work: Box::default(),
        refinement: Some(Box::new(metadata.clone())),
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_refusal: None,
    }
}

#[cfg(test)]
fn refinement_capture_assert_attached_public_status_map(
    trace: &RefinementObservationTrace,
    metadata: &super::M1TrustRegionRefinementFailureMetadata,
) {
    let attached = refinement_capture_field_status_json(trace);
    let resolved_terminal =
        refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary);
    let resolved = refinement_capture_field_status_json_resolved(trace, Some(&resolved_terminal));
    refinement_capture_assert_full_public_status_map(trace);
    assert_eq!(
        attached, resolved,
        "trace-owned terminal metadata changed public status"
    );
}

#[cfg(test)]
fn refinement_capture_complete_p0_terminal() -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
) {
    use super::{
        M1TrustRegionRefinementGuardStage as Stage, M1TrustRegionRefinementReason as Reason,
    };
    let metadata = super::M1TrustRegionRefinementFailureMetadata {
        reason: Reason::FinalRadius,
        correction_position: None,
        guard_stage: Stage::P0FullRadius,
        row: None,
        term: None,
        coordinate: None,
        lower_active: [false; 21],
        upper_active: [false; 21],
        free: [true; 21],
        lambda: 1.0,
        original_trust_radius: 1.0,
        reduced_face_radius: 0.5,
        scratch_box_feasible: None,
    };
    let p0 = [1.0; 21];
    let full: Vec<_> = (0..21).collect();
    let norm = refinement_capture_complete_norm("p0_full", &p0);
    let trace = RefinementObservationTrace {
        face_free_ids: Some(full.clone()),
        factor_order: Some(full),
        factor_a: Some(vec![vec![0.0; 21]; 21]),
        factor_v: Some(vec![vec![0.0; 21]; 21]),
        factor_sigma: Some(vec![0.0; 21]),
        weighted_residual: Some(vec![0.0; 21]),
        weighted_matrix: Some(vec![vec![0.0; 21]; 21]),
        scaled_lower_bits: Some([0; 21]),
        scaled_upper_bits: Some([0; 21]),
        lambda_bits: Some(1.0_f64.to_bits()),
        reduced_face_radius_bits: Some(0.5_f64.to_bits()),
        free_mask: Some([true; 21]),
        held_mask: Some([false; 21]),
        live_state_entry: Some([0; 21]),
        live_state_exit: Some([0; 21]),
        p0: Some(p0),
        p0_full_norm2: Some(f64::from_bits(norm.norm2_bits)),
        p0_full_norm: Some(f64::from_bits(norm.norm_bits)),
        lower_mask_p0: Some([false; 21]),
        upper_mask_p0: Some([false; 21]),
        lower_mask_exit: Some([false; 21]),
        upper_mask_exit: Some([false; 21]),
        work: Some(super::M1TrustRegionWorkObservation::default()),
        terminal_refusal: Some(Box::new(refinement_capture_terminal_refusal(&metadata))),
        ordered_norms: vec![norm],
        ..Default::default()
    };
    (trace, metadata)
}

#[cfg(test)]
#[test]
fn m1_refinement_complete_terminal_scalar_and_comparison_control() {
    let (mut trace, metadata) = refinement_capture_complete_p0_terminal();
    refinement_capture_assert_attached_public_status_map(&trace, &metadata);
    assert!(refinement_capture_terminal_complete(
        &trace,
        Some(&metadata)
    ));
    trace.p0_full_norm = Some(0.0);
    assert!(
        !refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "completed ordinary norm scalar must exactly join its ordered trace"
    );
    trace.p0 = Some([0.125; 21]);
    trace.ordered_norms[0] = refinement_capture_complete_norm(
        "p0_full",
        trace.p0.as_ref().expect("p0 comparison fixture"),
    );
    trace.p0_full_norm2 = Some(f64::from_bits(trace.ordered_norms[0].norm2_bits));
    trace.p0_full_norm = Some(f64::from_bits(trace.ordered_norms[0].norm_bits));
    assert!(
        !refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "recorded final-radius refusal must retain the rejecting comparison"
    );
}

#[cfg(test)]
#[test]
fn m1_refinement_complete_zero_lambda_terminal_control() {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let (mut trace, mut metadata) = refinement_capture_complete_p0_terminal();
    metadata.reason = Reason::ScratchRadius;
    metadata.correction_position = Some(Position::First);
    metadata.guard_stage = Stage::RadiusComparison;
    metadata.lambda = 0.0;
    metadata.scratch_box_feasible = Some(true);
    trace.lambda_bits = Some(0.0_f64.to_bits());
    trace.p0 = Some([0.0; 21]);
    trace.p0_full_norm2 = None;
    trace.p0_full_norm = None;
    trace.ordered_norms = vec![
        refinement_capture_complete_norm("p0_zero_lambda_eligibility", &[0.0; 21]),
        refinement_capture_complete_norm("p1_zero_lambda_scratch", &[1.0; 21]),
    ];
    trace.residual0 = Some([0.0; 21]);
    trace.delta0 = Some(vec![4.0; 21]);
    trace.p1 = Some([1.0; 21]);
    trace.lower_mask_p1 = Some([false; 21]);
    trace.upper_mask_p1 = Some([false; 21]);
    trace.factor_identity = Some(7);
    trace.factor_application_identities = vec![7];
    trace.factor_application_snapshots = vec![RefinementFactorApplicationSnapshot {
        ordinal: 1,
        identity: 7,
        h_bits: None,
        inverse_t_bits: None,
        inverse_denominator_bits: None,
        inverse_z_bits: None,
        delta_bits: Some(vec![4.0_f64.to_bits(); 21]),
    }];
    trace.factor_applications = 1;
    trace.factor_output_copy_boundary = Some((1, RefinementFactorOutputCopyBoundary::AfterDelta));
    trace.eligibility_scalar_operations = Some(0);
    trace.eligibility_guard_events = Some(0);
    trace.terminal_refusal = Some(Box::new(refinement_capture_terminal_refusal(&metadata)));
    refinement_capture_assert_attached_public_status_map(&trace, &metadata);
    assert!(
        refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "a completed zero-lambda ordered terminal has no scalar norm copies"
    );
    trace.p1 = Some([0.125; 21]);
    trace.ordered_norms[1] = refinement_capture_complete_norm(
        "p1_zero_lambda_scratch",
        trace.p1.as_ref().expect("p1 comparison fixture"),
    );
    assert!(
        !refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "zero-lambda refusing comparison must reject a non-refusing ordered norm"
    );
}

#[cfg(test)]
fn refinement_capture_complete_second_factor_terminal() -> (
    RefinementObservationTrace,
    super::M1TrustRegionRefinementFailureMetadata,
) {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let (mut trace, mut metadata) = refinement_capture_complete_p0_terminal();
    metadata.reason = Reason::FactorOutput;
    metadata.correction_position = Some(Position::Second);
    metadata.guard_stage = Stage::FactorApplicationOutput;
    metadata.scratch_box_feasible = Some(true);
    metadata.original_trust_radius = 10.0;
    metadata.reduced_face_radius = 10.0;
    trace.reduced_face_radius_bits = Some(10.0_f64.to_bits());
    let values = [1.0; 21];
    let p0_norm = refinement_capture_complete_norm("p0_full", &values);
    let p0_free = refinement_capture_complete_norm("p0_free", &values);
    let p1_norm = refinement_capture_complete_norm("p1_full", &values);
    let p1_free = refinement_capture_complete_norm("p1_free", &values);
    trace.p0_full_norm2 = Some(f64::from_bits(p0_norm.norm2_bits));
    trace.p0_full_norm = Some(f64::from_bits(p0_norm.norm_bits));
    trace.p0_reduced_norm2 = Some(f64::from_bits(p0_free.norm2_bits));
    trace.p0_reduced_norm = Some(f64::from_bits(p0_free.norm_bits));
    trace.ordered_norms = vec![p0_norm, p0_free, p1_norm.clone(), p1_free.clone()];
    trace.residual0 = Some([0.0; 21]);
    trace.h0 = Some(vec![1.0; 21]);
    trace.delta0 = Some(vec![2.0; 21]);
    trace.p1 = Some(values);
    trace.p1_full_norm2 = Some(f64::from_bits(p1_norm.norm2_bits));
    trace.p1_full_norm = Some(f64::from_bits(p1_norm.norm_bits));
    trace.p1_reduced_norm2 = Some(f64::from_bits(p1_free.norm2_bits));
    trace.p1_reduced_norm = Some(f64::from_bits(p1_free.norm_bits));
    trace.lower_mask_p1 = Some([false; 21]);
    trace.upper_mask_p1 = Some([false; 21]);
    trace.residual1 = Some([0.0; 21]);
    trace.h1 = Some(vec![3.0; 21]);
    trace.inverse_t = Some(vec![4.0; 21]);
    trace.inverse_denominator = Some(vec![5.0; 21]);
    trace.inverse_z = Some(vec![6.0; 21]);
    trace.factor_identity = Some(7);
    trace.factor_application_identities = vec![7, 7];
    trace.factor_application_snapshots = vec![
        RefinementFactorApplicationSnapshot {
            ordinal: 1,
            identity: 7,
            h_bits: Some(vec![1.0_f64.to_bits(); 21]),
            inverse_t_bits: Some(vec![4.0_f64.to_bits(); 21]),
            inverse_denominator_bits: Some(vec![5.0_f64.to_bits(); 21]),
            inverse_z_bits: Some(vec![6.0_f64.to_bits(); 21]),
            delta_bits: Some(vec![2.0_f64.to_bits(); 21]),
        },
        RefinementFactorApplicationSnapshot {
            ordinal: 2,
            identity: 7,
            h_bits: Some(vec![3.0_f64.to_bits(); 21]),
            inverse_t_bits: None,
            inverse_denominator_bits: None,
            inverse_z_bits: None,
            delta_bits: None,
        },
    ];
    trace.factor_applications = 2;
    trace.factor_output_copy_boundary =
        Some((2, RefinementFactorOutputCopyBoundary::BeforeInverse));
    trace.eligibility_scalar_operations = Some(0);
    trace.eligibility_guard_events = Some(0);
    trace.terminal_refusal = Some(Box::new(refinement_capture_terminal_refusal(&metadata)));
    (trace, metadata)
}

#[cfg(test)]
#[test]
fn m1_refinement_complete_second_factor_snapshot_control() {
    let (mut trace, metadata) = refinement_capture_complete_second_factor_terminal();
    refinement_capture_assert_attached_public_status_map(&trace, &metadata);
    assert!(refinement_capture_terminal_complete(
        &trace,
        Some(&metadata)
    ));
    trace.p1_full_norm = Some(0.0);
    assert!(
        !refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "a completed p1 ordinary scalar must join its ordered norm exactly"
    );
    trace.p1_full_norm = Some(f64::from_bits(trace.ordered_norms[2].norm_bits));
    assert!(refinement_capture_terminal_complete(
        &trace,
        Some(&metadata)
    ));
    trace.factor_application_snapshots[0].inverse_z_bits = None;
    assert!(
        !refinement_capture_terminal_complete(&trace, Some(&metadata)),
        "a second factor-output refusal cannot accept a corrupt completed first snapshot"
    );
}

/// Completed ordered prefixes and the current partial norm are both real
/// observations at full-radius terminals.  Status must preserve each member
/// of that mixed collection instead of classifying the prefix as stray.
#[cfg(test)]
#[test]
fn m1_refinement_mixed_norm_prefix_status_control() {
    use super::{
        M1TrustRegionCorrectionPosition as Position, M1TrustRegionRefinementGuardStage as Stage,
        M1TrustRegionRefinementReason as Reason,
    };
    let metadata = super::M1TrustRegionRefinementFailureMetadata {
        reason: Reason::NonfiniteOperand,
        correction_position: Some(Position::First),
        guard_stage: Stage::ScratchFullRadius,
        row: None,
        term: None,
        coordinate: None,
        lower_active: [false; 21],
        upper_active: [false; 21],
        free: [true; 21],
        lambda: 1.0,
        original_trust_radius: 1.0,
        reduced_face_radius: 1.0,
        scratch_box_feasible: Some(true),
    };
    let mut trace = RefinementObservationTrace {
        terminal_refusal: Some(Box::new(super::M1TrustRegionSubproblemRefusal {
            kind: super::M1TrustRegionRefusalKind::TrustRegionRefinementIndeterminate,
            optimality_reason: None,
            optimality_coordinate: None,
            optimality_radius: None,
            optimality_lambda: None,
            attempted_subproblems: 0,
            completed_jacobi_sweeps: 0,
            completed_face_pivots: 0,
            entered_svd_factorizations: 0,
            raw_residual_max: 0.0,
            work: Box::default(),
            refinement: Some(Box::new(metadata)),
            #[cfg(feature = "m1-trust-region-physical-stage")]
            budget_refusal: None,
        })),
        ordered_norms: vec![RefinementOrderedNormTrace {
            role: "p0_full",
            coordinate_ids: vec![0],
            value_bits: vec![0],
            square_bits: vec![0],
            running_sum_bits: vec![0],
            norm2_bits: 0,
            norm_bits: 0,
        }],
        partial_ordered_norms: vec![RefinementPartialOrderedNormTrace {
            role: "p1_full",
            coordinate_ids: vec![0],
            value_bits: vec![0],
            square_bits: vec![0],
            running_sum_bits: vec![0],
            terminal_operation: "square_guard",
            sqrt_bits: None,
        }],
        ..Default::default()
    };
    let statuses = refinement_capture_field_status_json(&trace);
    refinement_capture_assert_full_public_status_map(&trace);
    assert_eq!(statuses["ordered_norm_traces"], "captured");
    assert_eq!(statuses["partial_ordered_norms"], "captured");
    trace.ordered_norms.clear();
    let statuses = refinement_capture_field_status_json(&trace);
    assert_eq!(statuses["ordered_norm_traces"], "missing_instrumentation");
    trace.ordered_norms.push(RefinementOrderedNormTrace {
        role: "p0_full",
        coordinate_ids: vec![0],
        value_bits: vec![0],
        square_bits: vec![0],
        running_sum_bits: vec![0],
        norm2_bits: 0,
        norm_bits: 0,
    });
    trace.partial_ordered_norms.clear();
    let statuses = refinement_capture_field_status_json(&trace);
    assert_eq!(statuses["partial_ordered_norms"], "missing_instrumentation");
}

#[cfg(test)]
fn m1_refinement_inventory_reason(value: &str) -> super::M1TrustRegionRefinementReason {
    use super::M1TrustRegionRefinementReason as R;
    match value {
        "NonfiniteOperand" => R::NonfiniteOperand,
        "SplitterOverflow" => R::SplitterOverflow,
        "UnderflowToZero" => R::UnderflowToZero,
        "SubnormalIntermediate" => R::SubnormalIntermediate,
        "FactorOutput" => R::FactorOutput,
        "CoordinateUpdate" => R::CoordinateUpdate,
        "ScratchBox" => R::ScratchBox,
        "ScratchRadius" => R::ScratchRadius,
        "FinalBox" => R::FinalBox,
        "FinalRadius" => R::FinalRadius,
        _ => panic!("unknown approved reason {value}"),
    }
}

#[cfg(test)]
fn m1_refinement_inventory_stage(value: &str) -> super::M1TrustRegionRefinementGuardStage {
    use super::M1TrustRegionRefinementGuardStage as S;
    match value {
        "ActiveFinite" => S::ActiveFinite,
        "ActiveEquality" => S::ActiveEquality,
        "P0AssemblyEquality" => S::P0AssemblyEquality,
        "P0FullRadius" => S::P0FullRadius,
        "P0ReducedRadius" => S::P0ReducedRadius,
        "OrderedNorm" => S::OrderedNorm,
        "ResidualSourceTerm" => S::ResidualSourceTerm,
        "ResidualSourceWeight" => S::ResidualSourceWeight,
        "PrimaryProduct" => S::PrimaryProduct,
        "SplitterProduct" => S::SplitterProduct,
        "SplitOutput" => S::SplitOutput,
        "EftRemainder" => S::EftRemainder,
        "TwoSumResult" => S::TwoSumResult,
        "TwoSumRemainder" => S::TwoSumRemainder,
        "Accumulation" => S::Accumulation,
        "FactorApplicationOutput" => S::FactorApplicationOutput,
        "CoordinateUpdate" => S::CoordinateUpdate,
        "ScratchBoxLower" => S::ScratchBoxLower,
        "ScratchBoxUpper" => S::ScratchBoxUpper,
        "ScratchFullRadius" => S::ScratchFullRadius,
        "ScratchReducedRadius" => S::ScratchReducedRadius,
        "RadiusComparison" => S::RadiusComparison,
        "FinalBoxLower" => S::FinalBoxLower,
        "FinalBoxUpper" => S::FinalBoxUpper,
        "FinalFullRadius" => S::FinalFullRadius,
        "FinalReducedRadius" => S::FinalReducedRadius,
        "FinalRadiusCloseness" => S::FinalRadiusCloseness,
        "FinalInstallEquality" => S::FinalInstallEquality,
        _ => panic!("unknown approved stage {value}"),
    }
}

#[cfg(test)]
fn refinement_capture_status_insert(
    fields: &mut serde_json::Map<String, serde_json::Value>,
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
    name: &str,
    present: bool,
) {
    fields.insert(
        name.into(),
        serde_json::Value::String(refinement_capture_field_status(resolved, name, present).into()),
    );
}

#[cfg(test)]
fn refinement_capture_status_structure(
    fields: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
) {
    macro_rules! put {
        ($n:literal,$p:expr) => {
            refinement_capture_status_insert(fields, resolved, $n, $p)
        };
    }
    put!("free_ids", trace.face_free_ids.is_some());
    put!("factor_order", trace.factor_order.is_some());
    put!("factor_a_bits", trace.factor_a.is_some());
    put!("factor_v_bits", trace.factor_v.is_some());
    put!("factor_sigma_bits", trace.factor_sigma.is_some());
    put!("weighted_residual_bits", trace.weighted_residual.is_some());
    put!("weighted_matrix_bits", trace.weighted_matrix.is_some());
    put!("scaled_lower_bits", trace.scaled_lower_bits.is_some());
    put!("scaled_upper_bits", trace.scaled_upper_bits.is_some());
    put!("lambda_bits", trace.lambda_bits.is_some());
    put!(
        "reduced_face_radius_bits",
        trace.reduced_face_radius_bits.is_some()
    );
    put!("live_state_entry_bits", trace.live_state_entry.is_some());
    put!("live_state_exit_bits", trace.live_state_exit.is_some());
    put!("lower_mask_exit", trace.lower_mask_exit.is_some());
    put!("upper_mask_exit", trace.upper_mask_exit.is_some());
    put!("factor_identity", trace.factor_identity.is_some());
    put!(
        "factor_application_identities",
        !trace.factor_application_identities.is_empty()
    );
    put!(
        "factor_application_snapshots",
        !trace.factor_application_snapshots.is_empty()
    );
    put!(
        "factor_output_copy_boundary",
        trace.factor_output_copy_boundary.is_some()
    );
    put!("factor_applications", trace.factor_applications > 0);
    put!(
        "eligibility_scalar_operations",
        trace.eligibility_scalar_operations.is_some()
    );
    put!(
        "eligibility_guard_events",
        trace.eligibility_guard_events.is_some()
    );
    put!(
        "reservation_denial_owner",
        trace.reservation_denial_owner.is_some()
    );
}

#[cfg(test)]
fn refinement_capture_status_steps(
    fields: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
) {
    macro_rules! put {
        ($n:literal,$p:expr,[$($r:literal),*]) => {
            refinement_capture_status_insert(fields, resolved, $n, $p)
        };
    }
    put!("p0_bits", trace.p0.is_some(), []);
    put!(
        "p0_full_norm2_bits",
        trace.p0_full_norm2.is_some(),
        ["p0_full"]
    );
    put!(
        "p0_full_norm_bits",
        trace.p0_full_norm.is_some(),
        ["p0_full"]
    );
    put!(
        "p0_reduced_norm2_bits",
        trace.p0_reduced_norm2.is_some(),
        ["p0_free"]
    );
    put!(
        "p0_reduced_norm_bits",
        trace.p0_reduced_norm.is_some(),
        ["p0_free"]
    );
    put!("lower_mask_p0", trace.lower_mask_p0.is_some(), []);
    put!("upper_mask_p0", trace.upper_mask_p0.is_some(), []);
    put!("residual0_bits", trace.residual0.is_some(), []);
    put!("h0_bits", trace.h0.is_some(), []);
    put!("delta0_bits", trace.delta0.is_some(), []);
    put!("p1_bits", trace.p1.is_some(), []);
    put!(
        "p1_full_norm2_bits",
        trace.p1_full_norm2.is_some(),
        ["p1_full"]
    );
    put!(
        "p1_full_norm_bits",
        trace.p1_full_norm.is_some(),
        ["p1_full"]
    );
    put!(
        "p1_reduced_norm2_bits",
        trace.p1_reduced_norm2.is_some(),
        ["p1_free"]
    );
    put!(
        "p1_reduced_norm_bits",
        trace.p1_reduced_norm.is_some(),
        ["p1_free"]
    );
    put!("lower_mask_p1", trace.lower_mask_p1.is_some(), []);
    put!("upper_mask_p1", trace.upper_mask_p1.is_some(), []);
    refinement_capture_status_final_steps(fields, trace, resolved);
}

#[cfg(test)]
fn refinement_capture_status_final_steps(
    fields: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
) {
    macro_rules! put {
        ($n:literal,$p:expr,[$($r:literal),*]) => {
            refinement_capture_status_insert(fields, resolved, $n, $p)
        };
    }
    put!("residual1_bits", trace.residual1.is_some(), []);
    put!("h1_bits", trace.h1.is_some(), []);
    put!("delta1_bits", trace.delta1.is_some(), []);
    put!("p2_bits", trace.p2.is_some(), []);
    put!(
        "p2_full_norm2_bits",
        trace.p2_full_norm2.is_some(),
        ["p2_full"]
    );
    put!(
        "p2_full_norm_bits",
        trace.p2_full_norm.is_some(),
        ["p2_full"]
    );
    put!(
        "p2_reduced_norm2_bits",
        trace.p2_reduced_norm2.is_some(),
        ["p2_free"]
    );
    put!(
        "p2_reduced_norm_bits",
        trace.p2_reduced_norm.is_some(),
        ["p2_free"]
    );
    put!("lower_mask_p2", trace.lower_mask_p2.is_some(), []);
    put!("upper_mask_p2", trace.upper_mask_p2.is_some(), []);
    put!(
        "remaining_radius_bits",
        trace.remaining_radius.is_some(),
        []
    );
    put!("radius_gap_bits", trace.radius_gap.is_some(), []);
    put!(
        "radius_tolerance_bits",
        trace.radius_tolerance.is_some(),
        []
    );
}

#[cfg(test)]
fn refinement_capture_status_inverse_and_traces(
    fields: &mut serde_json::Map<String, serde_json::Value>,
    trace: &RefinementObservationTrace,
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
) {
    for ordinal in 1..=2_u8 {
        let snapshot = trace
            .factor_application_snapshots
            .get(usize::from(ordinal - 1));
        let prefix = format!("factor_application_snapshot_{ordinal}");
        for (suffix, present) in [
            ("h_bits", snapshot.is_some_and(|item| item.h_bits.is_some())),
            (
                "inverse_t_bits",
                snapshot.is_some_and(|item| item.inverse_t_bits.is_some()),
            ),
            (
                "inverse_denominator_bits",
                snapshot.is_some_and(|item| item.inverse_denominator_bits.is_some()),
            ),
            (
                "inverse_z_bits",
                snapshot.is_some_and(|item| item.inverse_z_bits.is_some()),
            ),
            (
                "delta_bits",
                snapshot.is_some_and(|item| item.delta_bits.is_some()),
            ),
        ] {
            refinement_capture_status_insert(
                fields,
                resolved,
                &format!("{prefix}_{suffix}"),
                present,
            );
        }
    }
    refinement_capture_status_insert(
        fields,
        resolved,
        "inverse_t_bits",
        trace.inverse_t.is_some(),
    );
    refinement_capture_status_insert(
        fields,
        resolved,
        "inverse_denominator_bits",
        trace.inverse_denominator.is_some(),
    );
    refinement_capture_status_insert(
        fields,
        resolved,
        "inverse_z_bits",
        trace.inverse_z.is_some(),
    );
    refinement_capture_status_insert(
        fields,
        resolved,
        "ordered_norm_traces",
        !trace.ordered_norms.is_empty(),
    );
    refinement_capture_status_insert(
        fields,
        resolved,
        "partial_ordered_norms",
        !trace.partial_ordered_norms.is_empty(),
    );
}

#[cfg(test)]
fn refinement_capture_field_status_json(trace: &RefinementObservationTrace) -> serde_json::Value {
    let resolved = trace
        .terminal_refusal
        .as_deref()
        .and_then(|refusal| refusal.refinement.as_deref())
        .map(|metadata| {
            refinement_capture_resolved_terminal(metadata, trace.factor_output_copy_boundary)
        });
    refinement_capture_field_status_json_resolved(trace, resolved.as_ref())
}

#[cfg(test)]
fn refinement_capture_field_status_json_resolved(
    trace: &RefinementObservationTrace,
    resolved: Option<&RefinementCaptureResolvedTerminal<'_>>,
) -> serde_json::Value {
    let mut fields = serde_json::Map::new();
    refinement_capture_status_structure(&mut fields, trace, resolved);
    refinement_capture_status_steps(&mut fields, trace, resolved);
    refinement_capture_status_inverse_and_traces(&mut fields, trace, resolved);
    serde_json::Value::Object(fields)
}

/// Every terminal control consumes this complete public projection.  Keep the
/// field inventory explicit so a new status producer cannot be silently
/// omitted from the terminal acceptance map.
#[cfg(test)]
fn refinement_capture_assert_full_public_status_map(trace: &RefinementObservationTrace) {
    let statuses = refinement_capture_field_status_json(trace);
    let statuses = statuses.as_object().expect("public status object");
    let expected = [
        "free_ids",
        "factor_order",
        "factor_a_bits",
        "factor_v_bits",
        "factor_sigma_bits",
        "weighted_residual_bits",
        "weighted_matrix_bits",
        "scaled_lower_bits",
        "scaled_upper_bits",
        "lambda_bits",
        "reduced_face_radius_bits",
        "live_state_entry_bits",
        "live_state_exit_bits",
        "lower_mask_exit",
        "upper_mask_exit",
        "factor_identity",
        "factor_application_identities",
        "factor_application_snapshots",
        "factor_output_copy_boundary",
        "factor_applications",
        "eligibility_scalar_operations",
        "eligibility_guard_events",
        "reservation_denial_owner",
        "p0_bits",
        "p0_full_norm2_bits",
        "p0_full_norm_bits",
        "p0_reduced_norm2_bits",
        "p0_reduced_norm_bits",
        "lower_mask_p0",
        "upper_mask_p0",
        "residual0_bits",
        "h0_bits",
        "delta0_bits",
        "p1_bits",
        "p1_full_norm2_bits",
        "p1_full_norm_bits",
        "p1_reduced_norm2_bits",
        "p1_reduced_norm_bits",
        "lower_mask_p1",
        "upper_mask_p1",
        "residual1_bits",
        "h1_bits",
        "delta1_bits",
        "p2_bits",
        "p2_full_norm2_bits",
        "p2_full_norm_bits",
        "p2_reduced_norm2_bits",
        "p2_reduced_norm_bits",
        "lower_mask_p2",
        "upper_mask_p2",
        "remaining_radius_bits",
        "radius_gap_bits",
        "radius_tolerance_bits",
        "factor_application_snapshot_1_h_bits",
        "factor_application_snapshot_1_inverse_t_bits",
        "factor_application_snapshot_1_inverse_denominator_bits",
        "factor_application_snapshot_1_inverse_z_bits",
        "factor_application_snapshot_1_delta_bits",
        "factor_application_snapshot_2_h_bits",
        "factor_application_snapshot_2_inverse_t_bits",
        "factor_application_snapshot_2_inverse_denominator_bits",
        "factor_application_snapshot_2_inverse_z_bits",
        "factor_application_snapshot_2_delta_bits",
        "inverse_t_bits",
        "inverse_denominator_bits",
        "inverse_z_bits",
        "ordered_norm_traces",
        "partial_ordered_norms",
    ];
    assert_eq!(
        statuses.len(),
        expected.len(),
        "unexpected public status field"
    );
    for name in expected {
        assert!(statuses.contains_key(name), "missing public status: {name}");
    }
}

#[cfg(test)]
pub(crate) fn refusal_capture_json_for_test(
    value: Option<M1RefusalCaptureTrace>,
    witness: &str,
) -> serde_json::Value {
    use serde_json::{Map, Value};
    let Some(value) = value else {
        return Value::Null;
    };
    let trace = &value.refinement;
    let input = refusal_capture_input_json(&value);
    let mut r = Map::new();
    // These names describe the already-copied values below.  They are schema
    // metadata only: the observer never selects a formulation or changes a
    // controller branch.
    r.insert(
        "formulation".into(),
        Value::String(
            match witness {
                "W1" | "W2" => "full",
                "W3" => "reduced",
                _ => "unknown",
            }
            .into(),
        ),
    );
    r.insert(
        "logical_to_physical_map".into(),
        serde_json::json!((0usize..21).collect::<Vec<_>>()),
    );
    r.insert(
        "state_roles".into(),
        serde_json::json!({
            "base_physical": "input.base_bits",
            "face_start_scaled": "live_state_entry_bits",
            "initial_scaled": "p0_bits",
            "private_scratch": "p1_bits",
            "final_candidate": "p2_bits",
            "live_face_exit": "live_state_exit_bits",
        }),
    );
    add_refusal_capture_factor_fields(&mut r, trace);
    add_refusal_capture_first_norm_fields(&mut r, trace);
    add_refusal_capture_second_norm_fields(&mut r, trace);
    add_capture_masks(&mut r, trace);
    r.insert(
        "ordered_norm_traces".into(),
        serde_json::json!(
            trace
                .ordered_norms
                .iter()
                .map(|norm| serde_json::json!({
                    "role": norm.role,
                    "coordinate_ids": norm.coordinate_ids,
                    "value_bits": norm.value_bits,
                    "square_bits": norm.square_bits,
                    "running_sum_bits": norm.running_sum_bits,
                    "norm2_bits": norm.norm2_bits,
                    "norm_bits": norm.norm_bits,
                }))
                .collect::<Vec<_>>()
        ),
    );
    r.insert(
        "work_ledger".into(),
        refusal_capture_work_json(trace.work.clone()),
    );
    r.insert(
        "terminal_refusal".into(),
        refusal_capture_terminal_json(trace.terminal_refusal.clone()),
    );
    r.insert(
        "completeness".into(),
        refusal_capture_completeness_json(trace, witness),
    );
    r.insert("fixed_coordinate_reconstruction".into(), Value::String("full/reduced norms use the captured p0/p1/p2 scaled-step vector with its matching free/held and lower/upper masks; squares accumulate in ascending coordinate_ids order".into()));
    r.insert(
        "field_status".into(),
        refinement_capture_field_status_json(trace),
    );
    let mut out = Map::new();
    out.insert("input".into(), input);
    out.insert("refinement".into(), Value::Object(r));
    Value::Object(out)
}
#[cfg(test)]
struct RefusalCaptureScope {
    active: bool,
    input: M1RefusalCaptureTrace,
}

#[cfg(test)]
impl RefusalCaptureScope {
    fn begin_armed(input: &super::M1TrustRegionSubproblemInput, active: bool) -> Option<Self> {
        active.then(|| Self {
            active,
            input: M1RefusalCaptureTrace {
                input_raw_residual_bits: input.raw_residual.map(f64::to_bits),
                input_raw_jacobian_bits: input.raw_jacobian.map(|row| row.map(f64::to_bits)),
                input_normalizer_bits: input.normalizers.map(f64::to_bits),
                input_scale_bits: input.scales.map(f64::to_bits),
                input_lower_bits: input.lower.map(f64::to_bits),
                input_upper_bits: input.upper.map(f64::to_bits),
                input_base_bits: input.base.map(f64::to_bits),
                initial_radius_bits: input.initial_radius.to_bits(),
                refinement: RefinementObservationTrace::default(),
            },
        })
    }
}

#[cfg(test)]
impl Drop for RefusalCaptureScope {
    fn drop(&mut self) {
        if self.active {
            self.input.refinement = refinement_observation_take().unwrap_or_default();
            REFUSAL_CAPTURE_TRACE.with(|trace| {
                *trace.borrow_mut() = Some(std::mem::replace(
                    &mut self.input,
                    M1RefusalCaptureTrace {
                        input_raw_residual_bits: [0; 21],
                        input_raw_jacobian_bits: [[0; 21]; 21],
                        input_normalizer_bits: [0; 21],
                        input_scale_bits: [0; 21],
                        input_lower_bits: [0; 21],
                        input_upper_bits: [0; 21],
                        input_base_bits: [0; 21],
                        initial_radius_bits: 0,
                        refinement: RefinementObservationTrace::default(),
                    },
                ));
            });
        }
    }
}

#[cfg(test)]
struct Bvls04PoisonScope {
    poison: Option<M1TrustRegionBvls04Poison>,
    consumed: Option<(u64, M1TrustRegionRefinementGuardStage)>,
    kkt: u32,
    output_event: Option<(usize, u64)>,
    site: Option<usize>,
}
#[cfg(test)]
impl Bvls04PoisonScope {
    fn install(poison: M1TrustRegionBvls04Poison) -> Self {
        Self {
            poison: BVLS04_POISON.with(|slot| slot.replace(Some(poison))),
            consumed: BVLS04_POISON_CONSUMED.with(std::cell::RefCell::take),
            kkt: BVLS04_KKT_ENTRIES.with(Cell::get),
            output_event: BVLS04_OUTPUT_CHECK_EVENT.with(std::cell::RefCell::take),
            site: BVLS04_POISON_SITE.with(|slot| slot.replace(None)),
        }
    }
}
#[cfg(test)]
impl Drop for Bvls04PoisonScope {
    fn drop(&mut self) {
        BVLS04_POISON.with(|slot| *slot.borrow_mut() = self.poison);
        BVLS04_POISON_CONSUMED.with(|slot| *slot.borrow_mut() = self.consumed);
        BVLS04_KKT_ENTRIES.with(|slot| slot.set(self.kkt));
        BVLS04_OUTPUT_CHECK_EVENT.with(|slot| *slot.borrow_mut() = self.output_event);
        BVLS04_POISON_SITE.with(|slot| slot.set(self.site));
    }
}

#[cfg(test)]
#[derive(Debug)]
struct M1TrustRegionBvls04PoisonObservation {
    p1_reduced_norm_bits: Option<u64>,
    p2_reduced_norm_bits: Option<u64>,
    metadata: Box<super::M1TrustRegionRefinementFailureMetadata>,
    bvls02_fallback_calls: u32,
    live_state_bits_before: [u64; 21],
    live_state_bits_after: [u64; 21],
    #[cfg(feature = "m1-trust-region-physical-stage")]
    owner_snapshot_before: RefinementScratchGlobalSnapshot,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    owner_snapshot_after: RefinementScratchGlobalSnapshot,
    mutated_operand_bits: Option<u64>,
    reached_stage: M1TrustRegionRefinementGuardStage,
    output_check_event: Option<(usize, u64)>,
    mutation_site: Option<usize>,
}
#[cfg(test)]
fn m1_trust_region_bvls04_poison_for_test(
    poison: M1TrustRegionBvls04Poison,
) -> Result<(), Box<M1TrustRegionBvls04PoisonObservation>> {
    let capture: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/shifted-face-observed-capture.json"
    ))).expect("frozen positive capture");
    #[cfg(feature = "m1-trust-region-physical-stage")]
    let owner_before = refinement_scratch_global_snapshot();
    let scope = Bvls04PoisonScope::install(poison);
    let prior = (
        scope.poison,
        scope.consumed,
        scope.kkt,
        scope.output_event,
        scope.site,
    );
    let result =
        m1_trust_region_refinement_retained_face_raw_for_test(&capture["face_capture"], None, None);
    let consumed = BVLS04_POISON_CONSUMED.with(|slot| *slot.borrow());
    let kkt = BVLS04_KKT_ENTRIES.with(Cell::get) - prior.2;
    let output_check_event = BVLS04_OUTPUT_CHECK_EVENT.with(|slot| *slot.borrow());
    let mutation_site = BVLS04_POISON_SITE.with(Cell::get);
    drop(scope);
    assert_eq!(BVLS04_POISON.with(|slot| *slot.borrow()), prior.0);
    assert_eq!(BVLS04_POISON_CONSUMED.with(|slot| *slot.borrow()), prior.1);
    assert_eq!(BVLS04_KKT_ENTRIES.with(Cell::get), prior.2);
    assert_eq!(
        BVLS04_OUTPUT_CHECK_EVENT.with(|slot| *slot.borrow()),
        prior.3
    );
    assert_eq!(BVLS04_POISON_SITE.with(Cell::get), prior.4);
    assert!(
        consumed.is_some(),
        "requested operand hook was not consumed"
    );
    #[cfg(feature = "m1-trust-region-physical-stage")]
    let owner_after = refinement_scratch_global_snapshot();
    match result {
        Ok(_) => Ok(()),
        Err(refusal) => {
            let metadata = refusal.refinement.expect("actual refinement refusal");
            Err(Box::new(M1TrustRegionBvls04PoisonObservation {
                p1_reduced_norm_bits: refusal.p1_reduced_norm_bits,
                p2_reduced_norm_bits: refusal.p2_reduced_norm_bits,
                reached_stage: metadata.guard_stage,
                mutated_operand_bits: consumed.map(|value| value.0),
                metadata,
                bvls02_fallback_calls: kkt,
                live_state_bits_before: refusal.live_state_bits_before,
                live_state_bits_after: refusal.live_state_bits_after,
                #[cfg(feature = "m1-trust-region-physical-stage")]
                owner_snapshot_before: owner_before,
                #[cfg(feature = "m1-trust-region-physical-stage")]
                owner_snapshot_after: owner_after,
                output_check_event,
                mutation_site,
            }))
        }
    }
}

#[cfg(test)]
fn refinement_mutate(position: u8, point: &mut [f64; 21]) -> Option<f64> {
    REFINEMENT_RAW_MUTATION
        .try_with(|slot| {
            let mutation = *slot.try_borrow().ok()?.as_ref()?;
            match mutation {
                RefinementRawCandidateMutation::P0Subnormal { coordinate } if position == 0 => {
                    point[coordinate] = f64::from_bits(1);
                    None
                }
                RefinementRawCandidateMutation::ScratchRadius {
                    coordinate,
                    scaled_value,
                    radius,
                    ..
                } if position == 1 => {
                    point[coordinate] = scaled_value;
                    Some(radius)
                }
                RefinementRawCandidateMutation::FinalBox {
                    coordinate,
                    scaled_value,
                    ..
                } if position == 2 => {
                    point[coordinate] = scaled_value;
                    None
                }
                RefinementRawCandidateMutation::ActiveValue {
                    coordinate,
                    scaled_value,
                    ..
                } if position == 2 => {
                    point[coordinate] = scaled_value;
                    None
                }
                _ => None,
            }
        })
        .ok()
        .flatten()
}

#[cfg(test)]
fn refinement_observe(mut update: impl FnMut(&mut RefinementObservationTrace)) {
    let _ = REFINEMENT_OBSERVATION.try_with(|slot| {
        if let Ok(mut slot) = slot.try_borrow_mut() {
            if let Some(trace) = slot.as_mut() {
                update(trace);
            }
        }
    });
}

#[cfg(test)]
fn refinement_observation_take() -> Option<RefinementObservationTrace> {
    REFINEMENT_OBSERVATION
        .try_with(|slot| slot.try_borrow_mut().ok().and_then(|mut slot| slot.take()))
        .ok()
        .flatten()
}

#[cfg(test)]
struct RefinementObservationScope(Option<RefinementObservationTrace>);

#[cfg(test)]
impl RefinementObservationScope {
    fn begin() -> Self {
        let prior = REFINEMENT_OBSERVATION
            .try_with(|slot| {
                slot.try_borrow_mut()
                    .ok()
                    .and_then(|mut slot| slot.replace(RefinementObservationTrace::default()))
            })
            .ok()
            .flatten();
        Self(prior)
    }
}

#[cfg(test)]
impl Drop for RefinementObservationScope {
    fn drop(&mut self) {
        let _ = REFINEMENT_OBSERVATION.try_with(|slot| {
            if let Ok(mut slot) = slot.try_borrow_mut() {
                *slot = self.0.take();
            }
        });
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) struct M1FacePivotCaptureScope {
    prior_enabled: bool,
    prior_capture: Option<M1FacePivotCapture>,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
impl Drop for M1FacePivotCaptureScope {
    fn drop(&mut self) {
        let _ = FACE_PIVOT_CAPTURE_ENABLED.try_with(|enabled| enabled.set(self.prior_enabled));
        let _ = FACE_PIVOT_CAPTURE.try_with(|cell| {
            if let Ok(mut capture) = cell.try_borrow_mut() {
                *capture = self.prior_capture.take();
            }
        });
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_face_pivot_capture_begin_for_test() -> M1FacePivotCaptureScope {
    let prior_enabled = FACE_PIVOT_CAPTURE_ENABLED
        .try_with(Cell::get)
        .unwrap_or(false);
    let prior_capture = FACE_PIVOT_CAPTURE
        .try_with(|cell| cell.try_borrow().ok().and_then(|capture| capture.clone()))
        .ok()
        .flatten();
    let _ = FACE_PIVOT_CAPTURE_ENABLED.try_with(|enabled| enabled.set(true));
    let _ = FACE_PIVOT_CAPTURE.try_with(|cell| {
        if let Ok(mut capture) = cell.try_borrow_mut() {
            *capture = None;
        }
    });
    M1FacePivotCaptureScope {
        prior_enabled,
        prior_capture,
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_face_pivot_capture_enabled_for_test() -> bool {
    FACE_PIVOT_CAPTURE_ENABLED
        .try_with(Cell::get)
        .unwrap_or(false)
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_face_pivot_capture_take_for_test() -> Option<M1FacePivotCapture> {
    FACE_PIVOT_CAPTURE
        .try_with(|cell| {
            cell.try_borrow_mut()
                .ok()
                .and_then(|mut capture| capture.take())
        })
        .ok()
        .flatten()
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_bits<const N: usize>(output: &mut String, values: &[f64; N]) {
    use std::fmt::Write;

    output.push('[');
    for (index, value) in values.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        let _ = write!(output, "\"{:016x}\"", value.to_bits());
    }
    output.push(']');
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_bool_bits<const N: usize>(output: &mut String, values: &[bool; N]) {
    output.push('[');
    for (index, value) in values.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        output.push_str(if *value { "true" } else { "false" });
    }
    output.push(']');
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_optional_bits<const N: usize>(output: &mut String, values: Option<[f64; N]>) {
    match values {
        Some(values) => append_bits(output, &values),
        None => output.push_str("null"),
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_optional_bit(output: &mut String, value: Option<f64>) {
    use std::fmt::Write;

    match value {
        Some(value) => {
            let _ = write!(output, "\"{:016x}\"", value.to_bits());
        }
        None => output.push_str("null"),
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_optional_bits_array<const N: usize>(output: &mut String, values: &[Option<f64>; N]) {
    output.push('[');
    for (index, value) in values.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        append_optional_bit(output, *value);
    }
    output.push(']');
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_hydraulics(output: &mut String, hydraulics: M1TrustRegionCurrentHydraulics) {
    match hydraulics {
        M1TrustRegionCurrentHydraulics::Pending => output.push_str("null"),
        M1TrustRegionCurrentHydraulics::Complete(values) => append_bits(output, &values),
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_named_bits<const N: usize>(output: &mut String, name: &str, values: &[f64; N]) {
    use std::fmt::Write;

    let _ = write!(output, "\"{name}\":");
    append_bits(output, values);
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_optimality_json(
    output: &mut String,
    observation: Option<&super::M1TrustRegionOptimalityObservation>,
) {
    use std::fmt::Write;

    let Some(observation) = observation else {
        output.push_str("null");
        return;
    };
    let _ = write!(
        output,
        "{{\"scalar_operations\":{},\"coordinates\":[",
        observation.scalar_operations
    );
    for (index, coordinate) in observation.coordinates.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        let _ = write!(
            output,
            "{{\"coordinate\":{},\"h\":\"{:016x}\",\"cbar\":\"{:016x}\",\"tau\":\"{:016x}\",\"class\":\"{:?}\"}}",
            coordinate.coordinate,
            coordinate.h.to_bits(),
            coordinate.cbar.to_bits(),
            coordinate.tau.to_bits(),
            coordinate.class
        );
    }
    output.push_str("],\"selected_release\":");
    match observation.selected_release {
        Some(release) => {
            let _ = write!(
                output,
                "{{\"coordinate\":{},\"lower\":{},\"ratio\":",
                release.coordinate, release.lower
            );
            append_optional_bit(output, release.ratio);
            let _ = write!(
                output,
                ",\"tied_coordinates\":{}}}",
                release.tied_coordinates
            );
        }
        None => output.push_str("null"),
    }
    output.push('}');
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_operation_json(output: &mut String, operation: &M1FacePivotCaptureOperation) {
    use std::fmt::Write;

    let _ = write!(
        output,
        "{{\"action\":\"{}\",\"applied\":{}",
        operation.action, operation.applied
    );
    for (name, values) in [
        ("p_before", &operation.p_before),
        ("p_candidate", &operation.p_candidate),
        ("conceptual_p_after", &operation.conceptual_p_after),
    ] {
        output.push(',');
        append_named_bits(output, name, values);
    }
    let _ = write!(output, ",\"scratch_p_at_refusal\":");
    append_optional_bits(output, operation.scratch_p_at_refusal);
    for (name, values) in [
        ("lower_before", &operation.lower_before),
        ("upper_before", &operation.upper_before),
        ("free_before", &operation.free_before),
        ("lower_after", &operation.lower_after),
        ("upper_after", &operation.upper_after),
        ("free_after", &operation.free_after),
    ] {
        let _ = write!(output, ",\"{name}\":");
        append_bool_bits(output, values);
    }
    let _ = write!(
        output,
        ",\"free_ids\":{:?},\"radius\":\"{:016x}\",\"lambda\":",
        operation.free_ids,
        operation.radius.to_bits()
    );
    match operation.lambda {
        Some(value) => {
            let _ = write!(output, "\"{:016x}\"", value.to_bits());
        }
        None => output.push_str("null"),
    }
    output.push_str(",\"weighted_residual\":");
    append_optional_bits(output, operation.weighted_residual);
    output.push_str(",\"weighted_matrix\":");
    match &operation.weighted_matrix {
        Some(matrix) => {
            output.push('[');
            for (index, row) in matrix.iter().enumerate() {
                if index != 0 {
                    output.push(',');
                }
                output.push('[');
                append_slice_bits(output, row);
                output.push(']');
            }
            output.push(']');
        }
        None => output.push_str("null"),
    }
    output.push_str(",\"theta\":");
    append_optional_bit(output, operation.crossing_theta);
    let _ = write!(output, ",\"coordinate\":");
    match operation.selected_coordinate {
        Some(value) => {
            let _ = write!(output, "{value}");
        }
        None => output.push_str("null"),
    }
    let _ = write!(output, ",\"lower\":");
    match operation.selected_lower {
        Some(value) => {
            let _ = write!(output, "{value}");
        }
        None => output.push_str("null"),
    }
    let _ = write!(
        output,
        ",\"entered\":{},\"pivots\":{},\"sweeps\":{}",
        operation.entered_factorizations, operation.completed_pivots, operation.completed_sweeps
    );
    for (name, values) in [
        ("residual", operation.residual),
        ("g", operation.g),
        ("lambda_times_p", operation.lambda_times_p),
        ("h", operation.h),
    ] {
        let _ = write!(output, ",\"{name}\":");
        append_optional_bits(output, values);
    }
    output.push_str(",\"optimality\":");
    append_optimality_json(output, operation.optimality.as_ref());
    output.push('}');
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_capture_input_json(output: &mut String, capture: &M1FacePivotCapture) {
    use std::fmt::Write;

    for (index, (name, values)) in [
        ("base", &capture.base),
        ("raw_residual", &capture.raw_residual),
        ("normalizers", &capture.normalizers),
        ("scales", &capture.scales),
        ("lower", &capture.lower),
        ("upper", &capture.upper),
    ]
    .iter()
    .enumerate()
    {
        if index != 0 {
            output.push(',');
        }
        append_named_bits(output, name, values);
    }
    output.push_str(",\"raw_jacobian\":[");
    for (index, row) in capture.raw_jacobian.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        append_bits(output, row);
    }
    output.push_str("],\"weighted_residual\":[");
    append_slice_bits(output, &capture.weighted_residual);
    output.push_str("],\"weighted_matrix\":[");
    for (index, row) in capture.weighted_matrix.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        output.push('[');
        append_slice_bits(output, row);
        output.push(']');
    }
    let _ = write!(
        output,
        "],\"initial_radius\":\"{:016x}\",\"operations\":[",
        capture.initial_radius.to_bits()
    );
    for (index, operation) in capture.operations.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        append_operation_json(output, operation);
    }
    output.push_str("],\"completed_subproblems\":[");
    for (index, summary) in capture.completed_subproblems.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        let _ = write!(
            output,
            "{{\"entered\":{},\"pivots\":{},\"sweeps\":{},\"refused\":{}}}",
            summary.entered_factorizations,
            summary.completed_pivots,
            summary.completed_sweeps,
            summary.refused
        );
    }
    output.push_str("],\"bvls05_lifecycle\":[");
    for (index, event) in capture.bvls05_lifecycle.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        let provenance = event.provenance.map(|value| {
            serde_json::json!({
                "role_columns":value.role_columns,
                "structural_areas":value.structural_areas.map(f64::to_bits),
                "wet_fractions":value.wet_fractions.map(f64::to_bits)
            })
        });
        let value = serde_json::json!({
            "provenance":provenance,
            "held":event.held,
            "reused":event.reused,
            "free_ids":event.free_ids,
            "work":format!("{:?}", event.work)
        });
        output.push_str(&value.to_string());
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_slice_bits(output: &mut String, values: &[f64]) {
    use std::fmt::Write;

    for (index, value) in values.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        let _ = write!(output, "\"{:016x}\"", value.to_bits());
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_installs_json(output: &mut String, installs: &[M1FacePivotAcceptedInstall]) {
    use std::fmt::Write;

    output.push_str("],\"accepted_installs\":[");
    for (index, install) in installs.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        output.push('{');
        for (number, (name, values)) in [
            ("base_before", &install.base_before),
            ("raw_before", &install.raw_before),
            ("normalizers_before", &install.normalizers_before),
            ("base_after", &install.base_after),
            ("raw_after", &install.raw_after),
            ("normalizers_after", &install.normalizers_after),
            ("scaled_step", &install.scaled_step),
        ]
        .iter()
        .enumerate()
        {
            if number != 0 {
                output.push(',');
            }
            append_named_bits(output, name, values);
        }
        let _ = write!(
            output,
            ",\"rho\":\"{:016x}\",\"predicted\":\"{:016x}\",\"actual\":\"{:016x}\",\"max_before\":\"{:016x}\",\"max_after\":\"{:016x}\",\"radius_before\":\"{:016x}\",\"radius_after\":\"{:016x}\"}}",
            install.rho.to_bits(),
            install.predicted_reduction.to_bits(),
            install.actual_reduction.to_bits(),
            install.dynamic_max_before.to_bits(),
            install.dynamic_max_after.to_bits(),
            install.radius_before.to_bits(),
            install.radius_after.to_bits()
        );
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_admissions_json(output: &mut String, admissions: &[M1FacePivotPostUpdateAdmission]) {
    use std::fmt::Write;

    output.push_str("],\"post_update_admissions\":[");
    for (index, admission) in admissions.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        output.push('{');
        for (number, (name, values)) in [
            ("previous_coordinates", &admission.previous_coordinates),
            ("previous_raw", &admission.previous_raw),
            ("previous_normalizers", &admission.previous_normalizers),
            ("current_coordinates", &admission.current_coordinates),
            ("current_raw", &admission.current_raw),
            ("current_normalizers", &admission.current_normalizers),
        ]
        .iter()
        .enumerate()
        {
            if number != 0 {
                output.push(',');
            }
            append_named_bits(output, name, values);
        }
        output.push(',');
        append_named_bits(output, "thresholds", &admission.governed_thresholds);
        output.push(',');
        append_named_bits(output, "previous_beta", &admission.previous_beta);
        output.push(',');
        append_named_bits(output, "previous_ci_pa", &admission.previous_ci_pa);
        output.push(',');
        append_named_bits(output, "current_beta", &admission.current_beta);
        output.push(',');
        append_named_bits(output, "current_ci_pa", &admission.current_ci_pa);
        output.push_str(",\"previous_hydraulics\":");
        append_hydraulics(output, admission.previous_hydraulics);
        output.push_str(",\"current_hydraulics\":");
        append_hydraulics(output, admission.current_hydraulics);
        output.push_str(",\"previous_wet_temperature_k\":");
        append_optional_bits_array(output, &admission.previous_wet_temperature_k);
        output.push_str(",\"current_wet_temperature_k\":");
        append_optional_bits_array(output, &admission.current_wet_temperature_k);
        let _ = write!(
            output,
            ",\"current_max\":\"{:016x}\",\"temperature\":",
            admission.current_max.to_bits()
        );
        append_optional_bit(output, admission.governed_temperature);
        output.push_str(",\"humidity\":");
        append_optional_bit(output, admission.governed_humidity);
        output.push_str(",\"hydraulic\":");
        append_optional_bit(output, admission.governed_hydraulic);
        output.push_str(",\"beta\":");
        append_optional_bit(output, admission.governed_beta);
        output.push_str(",\"ci\":");
        append_optional_bits(output, admission.governed_ci);
        let _ = write!(
            output,
            ",\"pass\":{},\"admitted\":{}}}",
            admission
                .governed_pass
                .map_or("null".to_owned(), |value| value.to_string()),
            admission.admitted
        );
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_matrix_bits(output: &mut String, matrix: &[Vec<f64>]) {
    output.push('[');
    for (index, row) in matrix.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        output.push('[');
        append_slice_bits(output, row);
        output.push(']');
    }
    output.push(']');
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_lambda_trace_json(output: &mut String, trace: Option<&M1FacePivotLambdaTraceCapture>) {
    use std::fmt::Write;

    let Some(trace) = trace else {
        output.push_str("null");
        return;
    };
    output.push_str("{\"initial_bracket\":");
    append_bits(output, &trace.initial_bracket);
    output.push_str(",\"bracket\":");
    append_bits(output, &trace.bracket);
    for (name, values) in [
        ("bracket_evaluations", &trace.bracket_evaluations),
        ("bisection_evaluations", &trace.bisection_evaluations),
    ] {
        let _ = write!(output, ",\"{name}\":[");
        for (index, (lambda, norm)) in values.iter().enumerate() {
            if index != 0 {
                output.push(',');
            }
            let _ = write!(
                output,
                "[\"{:016x}\",\"{:016x}\"]",
                lambda.to_bits(),
                norm.to_bits()
            );
        }
        output.push(']');
    }
    let _ = write!(
        output,
        ",\"lambda\":\"{:016x}\",\"natural_step\":[",
        trace.lambda.to_bits()
    );
    append_slice_bits(output, &trace.natural_step);
    output.push_str("],\"pre_hook_step\":[");
    append_slice_bits(output, &trace.pre_hook_step);
    output.push_str("],\"post_hook_step\":[");
    append_slice_bits(output, &trace.post_hook_step);
    let _ = write!(
        output,
        "] ,\"norm\":\"{:016x}\",\"gap\":\"{:016x}\",\"tolerance\":\"{:016x}\"}}",
        trace.norm.to_bits(),
        trace.gap.to_bits(),
        trace.tolerance.to_bits()
    );
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_factor_json(output: &mut String, factor: Option<&M1FacePivotFactorCapture>) {
    use std::fmt::Write;

    let Some(factor) = factor else {
        output.push_str("null");
        return;
    };
    output.push_str("{\"same_invocation_identity\":");
    match factor.same_invocation_identity {
        Some(identity) => {
            let _ = write!(output, "{identity}");
        }
        None => output.push_str("null"),
    }
    let _ = write!(
        output,
        ",\"same_invocation_identity_available\":{},\"a\":",
        factor.same_invocation_identity_available
    );
    append_matrix_bits(output, &factor.a);
    output.push_str(",\"b\":");
    append_matrix_bits(output, &factor.b);
    output.push_str(",\"v\":");
    append_matrix_bits(output, &factor.v);
    output.push_str(",\"sigma\":[");
    append_slice_bits(output, &factor.sigma);
    output.push_str("],\"rank_max\":");
    append_optional_bit(output, factor.rank_max);
    output.push_str(",\"rank_threshold\":");
    append_optional_bit(output, factor.rank_threshold);
    let _ = write!(output, ",\"order\":{:?},\"visits\":[", factor.order);
    for (index, visit) in factor.visits.iter().enumerate() {
        if index != 0 {
            output.push(',');
        }
        let _ = write!(
            output,
            "{{\"left\":{},\"right\":{},\"rotated\":{},\"sweep\":{}}}",
            visit.left, visit.right, visit.rotated, visit.sweep
        );
    }
    let _ = write!(
        output,
        "],\"order_computed\":{},\"rotations\":{},\"sweeps\":{}}}",
        factor.order_computed, factor.rotations, factor.sweeps
    );
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn append_refusal_json(output: &mut String, capture: &M1FacePivotCapture) {
    use std::fmt::Write;

    let _ = write!(
        output,
        "],\"lifecycle\":{:?},\"refusal\":",
        capture.lifecycle
    );
    match &capture.refusal {
        Some(refusal) => {
            let _ = write!(
                output,
                "{{\"stage\":\"{}\",\"kind\":\"{:?}\",\"reason\":",
                refusal.stage, refusal.kind,
            );
            match refusal.optimality_reason {
                Some(reason) => output.push_str(
                    &serde_json::to_string(reason).expect("static optimality reason serializes"),
                ),
                None => output.push_str("null"),
            }
            output.push_str(",\"coordinate\":");
            match refusal.optimality_coordinate {
                Some(coordinate) => {
                    let _ = write!(output, "{coordinate}");
                }
                None => output.push_str("null"),
            }
            output.push_str(",\"radius\":");
            append_optional_bit(output, refusal.radius);
            output.push_str(",\"lambda\":");
            append_optional_bit(output, refusal.lambda);
            let _ = write!(
                output,
                ",\"free_ids\":{:?},\"entered\":{},\"pivots\":{},\"sweeps\":{},\"p\":",
                refusal.free_ids,
                refusal.entered_factorizations,
                refusal.completed_pivots,
                refusal.completed_sweeps
            );
            append_bits(output, &refusal.p);
            output.push_str(",\"lower\":");
            append_bool_bits(output, &refusal.lower);
            output.push_str(",\"upper\":");
            append_bool_bits(output, &refusal.upper);
            output.push_str(",\"free\":");
            append_bool_bits(output, &refusal.free);
            output.push_str(",\"scaled_lower\":");
            append_optional_bits(output, refusal.scaled_lower);
            output.push_str(",\"scaled_upper\":");
            append_optional_bits(output, refusal.scaled_upper);
            output.push_str(",\"optimality\":");
            append_optimality_json(output, refusal.optimality.as_ref());
            output.push_str(",\"lambda_trace\":");
            append_lambda_trace_json(output, refusal.lambda_trace.as_ref());
            output.push_str(",\"factor\":");
            append_factor_json(output, refusal.factor.as_ref());
            output.push('}');
        }
        None => output.push_str("null"),
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_face_pivot_capture_json_for_test(capture: Option<&M1FacePivotCapture>) -> String {
    let Some(capture) = capture else {
        return "null".to_owned();
    };
    let mut output = String::from("{");
    append_capture_input_json(&mut output, capture);
    append_installs_json(&mut output, &capture.accepted_installs);
    append_admissions_json(&mut output, &capture.post_update_admissions);
    append_refusal_json(&mut output, capture);
    output.push('}');
    output
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn populated_face_pivot_operation_for_test() -> M1FacePivotCaptureOperation {
    M1FacePivotCaptureOperation {
        action: "activate-cap",
        p_before: [0.0; 21],
        p_candidate: [1.0; 21],
        conceptual_p_after: [0.0; 21],
        scratch_p_at_refusal: Some([1.0; 21]),
        applied: false,
        lower_before: [false; 21],
        upper_before: [false; 21],
        free_before: [true; 21],
        lower_after: [false; 21],
        upper_after: [false; 21],
        free_after: [true; 21],
        free_ids: vec![1],
        radius: 1.0,
        lambda: Some(-0.0),
        weighted_residual: None,
        weighted_matrix: None,
        crossing_theta: Some(f64::INFINITY),
        selected_coordinate: Some(1),
        selected_lower: Some(true),
        residual: Some([0.5; 21]),
        g: Some([1.0; 21]),
        lambda_times_p: Some([2.0; 21]),
        h: Some([3.0; 21]),
        optimality: None,
        entered_factorizations: 43,
        completed_pivots: 42,
        completed_sweeps: 7,
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn populated_face_pivot_refusal_for_test() -> M1FacePivotCaptureRefusal {
    M1FacePivotCaptureRefusal {
        stage: "cap",
        kind: M1TrustRegionRefusalKind::FacePivotLimit,
        optimality_reason: None,
        optimality_coordinate: None,
        radius: None,
        lambda: None,
        free_ids: Vec::new(),
        p: [1.0; 21],
        lower: [false; 21],
        upper: [true; 21],
        free: [false; 21],
        scaled_lower: None,
        scaled_upper: None,
        entered_factorizations: 43,
        completed_pivots: 42,
        completed_sweeps: 7,
        optimality: None,
        lambda_trace: Some(M1FacePivotLambdaTraceCapture {
            initial_bracket: [0.0, 1.0],
            bracket: [0.5, 1.0],
            bracket_evaluations: vec![(0.0, 2.0), (1.0, 1.0)],
            bisection_evaluations: vec![(0.5, 1.5)],
            lambda: 1.0,
            natural_step: vec![1.0],
            pre_hook_step: vec![1.0],
            post_hook_step: vec![1.0],
            norm: 1.0,
            gap: 0.0,
            tolerance: 1.0e-12,
        }),
        factor: Some(M1FacePivotFactorCapture {
            same_invocation_identity: Some(17),
            same_invocation_identity_available: true,
            a: vec![vec![1.0]],
            b: vec![vec![1.0]],
            v: vec![vec![1.0]],
            sigma: vec![1.0],
            rank_max: None,
            rank_threshold: None,
            order: vec![0],
            order_computed: true,
            visits: vec![super::M1TrustRegionJacobiPair {
                left: 0,
                right: 1,
                rotated: true,
                sweep: 1,
            }],
            rotations: 1,
            sweeps: 1,
        }),
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn populated_face_pivot_capture_for_test() -> M1FacePivotCapture {
    M1FacePivotCapture {
        base: [f64::NEG_INFINITY; 21],
        raw_residual: [-0.0; 21],
        raw_jacobian: [[0.0; 21]; 21],
        normalizers: [1.0; 21],
        scales: [1.0; 21],
        lower: [0.0; 21],
        upper: [1.0; 21],
        weighted_residual: vec![f64::INFINITY],
        weighted_matrix: vec![vec![f64::NAN]],
        initial_radius: 1.0,
        completed_subproblems: vec![M1FacePivotSubproblemSummary {
            entered_factorizations: 1,
            completed_pivots: 0,
            completed_sweeps: 0,
            refused: false,
        }],
        operations: vec![populated_face_pivot_operation_for_test()],
        accepted_installs: vec![M1FacePivotAcceptedInstall {
            base_before: [0.0; 21],
            raw_before: [1.0; 21],
            normalizers_before: [2.0; 21],
            base_after: [3.0; 21],
            raw_after: [4.0; 21],
            normalizers_after: [5.0; 21],
            scaled_step: [6.0; 21],
            rho: 0.5,
            predicted_reduction: 1.0,
            actual_reduction: 0.5,
            dynamic_max_before: 1.0,
            dynamic_max_after: 0.5,
            radius_before: 1.0,
            radius_after: 2.0,
        }],
        post_update_admissions: vec![M1FacePivotPostUpdateAdmission {
            previous_coordinates: [0.0; 21],
            previous_raw: [1.0; 21],
            previous_normalizers: [2.0; 21],
            previous_wet_temperature_k: [Some(273.15), None],
            previous_hydraulics: M1TrustRegionCurrentHydraulics::Complete([1.0; 8]),
            previous_beta: [1.0; 4],
            previous_ci_pa: [2.0; 4],
            current_coordinates: [3.0; 21],
            current_raw: [4.0; 21],
            current_normalizers: [5.0; 21],
            current_wet_temperature_k: [Some(274.15), Some(275.15)],
            current_hydraulics: M1TrustRegionCurrentHydraulics::Complete([2.0; 8]),
            current_beta: [3.0; 4],
            current_ci_pa: [4.0; 4],
            current_max: 0.5,
            governed_temperature: Some(1.0),
            governed_humidity: Some(2.0),
            governed_hydraulic: Some(3.0),
            governed_beta: Some(4.0),
            governed_ci: Some([5.0; 4]),
            governed_pass: Some(false),
            governed_thresholds: [1.0; 4],
            admitted: false,
        }],
        bvls05_lifecycle: Vec::new(),
        lifecycle: vec!["test"],
        rank_refusal_factor: None,
        refusal: Some(populated_face_pivot_refusal_for_test()),
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[test]
fn m1_face_pivot_populated_capture_json_parses() {
    let mut capture = populated_face_pivot_capture_for_test();
    let json = m1_face_pivot_capture_json_for_test(Some(&capture));
    let parsed: serde_json::Value = serde_json::from_str(&json).expect("valid populated JSON");
    assert_eq!(parsed["operations"][0]["coordinate"], 1);
    assert_eq!(parsed["operations"][0]["lower"], true);
    assert_eq!(parsed["post_update_admissions"][0]["pass"], false);
    assert_eq!(parsed["refusal"]["kind"], "FacePivotLimit");
    assert!(parsed["refusal"]["reason"].is_null());
    assert!(parsed["refusal"]["coordinate"].is_null());
    assert!(parsed["refusal"]["radius"].is_null());
    assert!(parsed["refusal"]["lambda"].is_null());
    assert_eq!(
        parsed["refusal"]["lambda_trace"]["lambda"],
        "3ff0000000000000"
    );
    assert_eq!(parsed["refusal"]["factor"]["same_invocation_identity"], 17);
    assert_eq!(parsed["refusal"]["factor"]["order_computed"], true);
    assert_eq!(parsed["refusal"]["factor"]["visits"][0]["sweep"], 1);

    let refusal = capture.refusal.as_mut().expect("populated refusal");
    refusal.optimality_reason = Some("optimality_nonfinite");
    refusal.optimality_coordinate = Some(3);
    refusal.radius = Some(-0.0);
    refusal.lambda = Some(f64::INFINITY);
    let json = m1_face_pivot_capture_json_for_test(Some(&capture));
    let parsed: serde_json::Value = serde_json::from_str(&json).expect("valid populated JSON");
    assert_eq!(parsed["refusal"]["reason"], "optimality_nonfinite");
    assert_eq!(parsed["refusal"]["coordinate"], 3);
    assert_eq!(parsed["refusal"]["radius"], "8000000000000000");
    assert_eq!(parsed["refusal"]["lambda"], "7ff0000000000000");
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[test]
fn m1_face_pivot_capture_scope_restores_nested_observer_control() {
    let outer = m1_face_pivot_capture_begin_for_test();
    assert!(m1_face_pivot_capture_enabled_for_test());
    {
        let inner = m1_face_pivot_capture_begin_for_test();
        assert!(m1_face_pivot_capture_enabled_for_test());
        drop(inner);
    }
    assert!(m1_face_pivot_capture_enabled_for_test());
    drop(outer);
    assert!(!m1_face_pivot_capture_enabled_for_test());
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn record_face_pivot_capture(f: impl FnOnce(&mut M1FacePivotCapture)) {
    let enabled = FACE_PIVOT_CAPTURE_ENABLED
        .try_with(Cell::get)
        .unwrap_or(false);
    if !enabled {
        return;
    }
    let _ = FACE_PIVOT_CAPTURE.try_with(|cell| {
        if let Ok(mut capture) = cell.try_borrow_mut() {
            if let Some(capture) = capture.as_mut() {
                f(capture);
            }
        }
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn seed_kkt_transition_capture_for_test(
    weighted_matrix: &[Vec<f64>],
    weighted_residual: &[f64; 21],
    lower: [f64; 21],
    upper: [f64; 21],
) {
    if !m1_face_pivot_capture_enabled_for_test() {
        return;
    }
    let raw_jacobian =
        std::array::from_fn(|row| std::array::from_fn(|column| weighted_matrix[row][column]));
    let _ = FACE_PIVOT_CAPTURE.try_with(|cell| {
        if let Ok(mut capture) = cell.try_borrow_mut() {
            *capture = Some(M1FacePivotCapture {
                base: [0.0; 21],
                raw_residual: *weighted_residual,
                raw_jacobian,
                normalizers: [1.0; 21],
                scales: [1.0; 21],
                lower,
                upper,
                weighted_residual: weighted_residual.to_vec(),
                weighted_matrix: weighted_matrix.to_vec(),
                initial_radius: 1.0,
                completed_subproblems: Vec::new(),
                operations: Vec::new(),
                accepted_installs: Vec::new(),
                post_update_admissions: Vec::new(),
                lifecycle: Vec::new(),
                bvls05_lifecycle: Vec::new(),
                rank_refusal_factor: None,
                refusal: None,
            });
        }
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_face_pivot_capture_accepted_install_for_test(install: M1FacePivotAcceptedInstall) {
    record_face_pivot_capture(|capture| {
        capture.accepted_installs.push(install);
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_face_pivot_capture_post_update_admission_for_test(
    admission: M1FacePivotPostUpdateAdmission,
) {
    record_face_pivot_capture(|capture| {
        capture.post_update_admissions.push(admission);
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_face_pivot_capture_lifecycle_for_test(event: &'static str) {
    record_face_pivot_capture(|capture| capture.lifecycle.push(event));
}

pub(crate) fn checked_sum_squares(values: &[f64]) -> Result<f64, &'static str> {
    let mut sum = 0.0;
    for &value in values {
        if !value.is_finite() {
            return Err("nonfinite operand");
        }
        let square = value * value;
        if !square.is_finite() {
            return Err("nonfinite square");
        }
        sum += square;
        if !sum.is_finite() {
            return Err("nonfinite sum");
        }
    }
    Ok(sum)
}

pub(crate) fn weighted_system(
    raw: &[f64],
    jacobian: &[&[f64]],
    normalizers: &[f64],
    scales: &[f64],
) -> Result<(Vec<f64>, Vec<Vec<f64>>), &'static str> {
    if raw.len() != jacobian.len() || raw.len() != normalizers.len() {
        return Err("dimension mismatch");
    }
    let mut f = Vec::with_capacity(raw.len());
    let mut a = Vec::with_capacity(raw.len());
    for row in 0..raw.len() {
        if jacobian[row].len() != scales.len()
            || !raw[row].is_finite()
            || !normalizers[row].is_finite()
            || normalizers[row] <= 0.0
        {
            return Err("invalid weighted system input");
        }
        let weight = 1.0 / normalizers[row];
        let weighted_residual = weight * raw[row];
        if !weight.is_finite() || !weighted_residual.is_finite() {
            return Err("nonfinite weighting");
        }
        let mut a_row = Vec::with_capacity(scales.len());
        for col in 0..scales.len() {
            if !jacobian[row][col].is_finite() || !scales[col].is_finite() {
                return Err("nonfinite weighted system operand");
            }
            let weighted_jacobian = weight * jacobian[row][col];
            let coefficient = weighted_jacobian * scales[col];
            if !weighted_jacobian.is_finite() || !coefficient.is_finite() {
                return Err("nonfinite weighted system product");
            }
            a_row.push(coefficient);
        }
        f.push(weighted_residual);
        a.push(a_row);
    }
    Ok((f, a))
}

pub(crate) fn frozen_weighted_merit(
    raw: &[f64],
    jacobian: &[&[f64]],
    normalizers: &[f64],
    scales: &[f64],
    step: &[f64],
    candidate_raw: &[f64],
    moving_normalizers: &[f64],
) -> Result<(f64, f64, f64, f64), &'static str> {
    #[cfg(test)]
    REFINEMENT_FROZEN_WEIGHTED_MERIT_ENTRIES.with(|count| count.set(count.get().saturating_add(1)));
    if raw.len() != jacobian.len()
        || raw.len() != normalizers.len()
        || raw.len() != candidate_raw.len()
        || raw.len() != moving_normalizers.len()
    {
        return Err("dimension mismatch");
    }
    let (f, a) = weighted_system(raw, jacobian, normalizers, scales)?;
    let vector_input = MeritVectorInput {
        raw,
        normalizers,
        scales,
        step,
        candidate_raw,
        moving_normalizers,
        weighted_residual: &f,
        weighted_matrix: &a,
    };
    let vectors = merit_vectors(&vector_input)?;
    merit_reductions(&f, vectors)
}

struct MeritVectorInput<'a> {
    raw: &'a [f64],
    normalizers: &'a [f64],
    scales: &'a [f64],
    step: &'a [f64],
    candidate_raw: &'a [f64],
    moving_normalizers: &'a [f64],
    weighted_residual: &'a [f64],
    weighted_matrix: &'a [Vec<f64>],
}

struct MeritVectors {
    linear: Vec<f64>,
    candidate: Vec<f64>,
    moving: Vec<f64>,
}

fn merit_vectors(input: &MeritVectorInput<'_>) -> Result<MeritVectors, &'static str> {
    let MeritVectorInput {
        raw,
        normalizers,
        scales,
        step,
        candidate_raw,
        moving_normalizers,
        weighted_residual,
        weighted_matrix,
    } = input;
    let mut linear = Vec::with_capacity(raw.len());
    let mut candidate = Vec::with_capacity(raw.len());
    let mut moving = Vec::with_capacity(raw.len());
    for row in 0..raw.len() {
        if !moving_normalizers[row].is_finite() || moving_normalizers[row] <= 0.0 {
            return Err("invalid normalizer");
        }
        if scales.len() != step.len() {
            return Err("dimension mismatch");
        }
        let weight = 1.0 / normalizers[row];
        let moving_weight = 1.0 / moving_normalizers[row];
        if !weight.is_finite() || !moving_weight.is_finite() {
            return Err("nonfinite weight");
        }
        let weighted = weighted_residual[row];
        let frozen_candidate = weight * candidate_raw[row];
        let moving_candidate = moving_weight * candidate_raw[row];
        if !weighted.is_finite() || !frozen_candidate.is_finite() || !moving_candidate.is_finite() {
            return Err("nonfinite weighting");
        }
        let mut ap = 0.0;
        for col in 0..scales.len() {
            if !step[col].is_finite() {
                return Err("nonfinite operand");
            }
            let term = weighted_matrix[row][col] * step[col];
            if !term.is_finite() {
                return Err("nonfinite intermediate");
            }
            ap += term;
            if !ap.is_finite() {
                return Err("nonfinite accumulation");
            }
        }
        let linear_value = weighted + ap;
        if !linear_value.is_finite() {
            return Err("nonfinite residual");
        }
        linear.push(linear_value);
        candidate.push(frozen_candidate);
        moving.push(moving_candidate);
    }
    Ok(MeritVectors {
        linear,
        candidate,
        moving,
    })
}

fn merit_reductions(
    f: &[f64],
    vectors: MeritVectors,
) -> Result<(f64, f64, f64, f64), &'static str> {
    let MeritVectors {
        linear,
        candidate,
        moving,
    } = vectors;
    let f2 = checked_sum_squares(f)?;
    let linear2 = checked_sum_squares(linear.as_slice())?;
    let candidate2 = checked_sum_squares(candidate.as_slice())?;
    let predicted = predicted_reduction_from_squares(f2, linear2);
    let actual = (0.5 * f2) - (0.5 * candidate2);
    let moving_merit = 0.5 * checked_sum_squares(moving.as_slice())?;
    let rho = actual / predicted;
    if !f2.is_finite()
        || !linear2.is_finite()
        || !candidate2.is_finite()
        || !predicted.is_finite()
        || !actual.is_finite()
        || !moving_merit.is_finite()
        || !rho.is_finite()
    {
        return Err("nonfinite merit");
    }
    Ok((predicted, actual, rho, moving_merit))
}

pub(crate) fn predicted_reduction_from_squares(f2: f64, linear2: f64) -> f64 {
    0.5 * (f2 - linear2)
}

pub(crate) fn m1_trust_region_frozen_merit_for_test(
    _input: &super::M1CoupledColumnInput,
    _trial: &super::M1CoupledColumnTrial,
    value: M1TrustRegionMeritInput,
) -> Result<M1TrustRegionMeritObservation, &'static str> {
    let rows: [&[f64]; 2] = [&value.raw_jacobian[0], &value.raw_jacobian[1]];
    let (predicted_reduction, actual_reduction, rho, moving_weight_trial_merit) =
        frozen_weighted_merit(
            &value.raw_residual,
            &rows,
            &value.frozen_normalizers,
            &value.coordinate_scales,
            &value.scaled_step,
            &value.candidate_raw_residual,
            &value.moving_candidate_normalizers,
        )?;
    Ok(M1TrustRegionMeritObservation {
        predicted_reduction,
        actual_reduction,
        rho,
        moving_weight_trial_merit,
    })
}

struct JacobiFactor {
    // Keep the input matrix as well as its rotated columns.  The frozen method
    // defines U as A_free * V / sigma, with this multiplication accumulated in
    // ascending free-coordinate order; the rotated B is not a substitute in
    // binary64 arithmetic.
    a: Vec<Vec<f64>>,
    b: Vec<Vec<f64>>,
    v: Vec<Vec<f64>>,
    sigma: Vec<f64>,
    order: Vec<usize>,
    visits: Vec<M1TrustRegionJacobiPair>,
    rotations: usize,
    sweeps: u8,
}

pub(crate) struct LambdaTrace {
    pub(crate) initial_bracket: [f64; 2],
    pub(crate) bracket: [f64; 2],
    pub(crate) bracket_evaluations: Vec<(f64, f64)>,
    pub(crate) bisection_evaluations: Vec<(f64, f64)>,
    pub(crate) lambda: f64,
    pub(crate) step: Vec<f64>,
    pub(crate) natural_step: Vec<f64>,
    pub(crate) pre_hook_step: Vec<f64>,
    pub(crate) post_hook_step: Vec<f64>,
    pub(crate) norm: f64,
    pub(crate) gap: f64,
    pub(crate) tolerance: f64,
}

impl Default for LambdaTrace {
    fn default() -> Self {
        Self {
            initial_bracket: [0.0, 0.0],
            bracket: [0.0, 0.0],
            bracket_evaluations: Vec::new(),
            bisection_evaluations: Vec::new(),
            lambda: 0.0,
            step: Vec::new(),
            natural_step: Vec::new(),
            pre_hook_step: Vec::new(),
            post_hook_step: Vec::new(),
            norm: f64::NAN,
            gap: f64::NAN,
            tolerance: f64::NAN,
        }
    }
}

#[derive(Default)]
struct RefinementWorkLedger {
    scalar_operations: u64,
    guard_events: u64,
    attempted_entries: u16,
    denied_entries: u16,
    bvls04_positive_entries: u32,
    bvls04_factor_applications: u32,
    bvls04_dot2_residual_rows: u32,
    bvls04_dot2_free_gradients: u32,
    bvls04_ordered_norms: u32,
    first_residual_operations: u64,
    second_dot2_operations: u64,
    factor_application_operations: u64,
    coordinate_update_operations: u64,
    whole_kkt_operations: u64,
    whole_kkt_guard_events: u64,
    upward_enclosure_operations: u64,
    upward_enclosure_guard_events: u64,
}

impl RefinementWorkLedger {
    fn scalar(&mut self) {
        self.scalar_operations += 1;
    }

    fn guard(&mut self) {
        self.guard_events += 1;
    }

    fn absorb_dot2(&mut self, counters: RefinementDot2Counters) {
        self.scalar_operations += u64::from(counters.arithmetic);
        self.guard_events += u64::from(counters.guards);
    }
}

const REFINEMENT_SCALAR_CAP: u64 = 4_118_712;
const REFINEMENT_GUARD_CAP: u64 = 12_367_101;

fn refinement_required_work(free_coordinates: usize) -> (u64, u64) {
    let m = free_coordinates as u64;
    let scalar = 12_306 + 88 * m * m + 138 * m + 39_816 + 1_827 + 129;
    let guards = 3 * scalar + 213 + 2 * m;
    (scalar, guards)
}

fn bvls04_required_work(free_coordinates: usize) -> (u64, u64) {
    let m = free_coordinates as u64;
    let scalar = 12_306 + 597 * m + 8 * m * m + 39_816 + 1_827 + 129 + (6 * m + 3) + 4;
    (scalar, 3 * scalar + 324 + 4 * m)
}

/// The `U^T y` projection belongs to one fixed SVD factor and right-hand side.
/// It is deliberately private to the damping search: refinement keeps calling
/// `lambda_step` without a projection and therefore retains its original work.
enum LambdaProjection<'a> {
    Reconstruct,
    Record(&'a mut Vec<f64>),
    Reuse(&'a [f64]),
}

#[cfg(test)]
thread_local! {
    static LAMBDA_PROJECTION_SEARCH_ENTRIES: Cell<u32> = const { Cell::new(0) };
    static LAMBDA_PROJECTION_CAPTURE_ENABLED: Cell<bool> = const { Cell::new(false) };
}

#[cfg(test)]
pub(crate) fn lambda_projection_search_entries_for_test() -> u32 {
    LAMBDA_PROJECTION_SEARCH_ENTRIES.with(Cell::get)
}

#[cfg(test)]
pub(crate) fn reset_lambda_projection_search_entries_for_test() {
    LAMBDA_PROJECTION_SEARCH_ENTRIES.with(|entries| entries.set(0));
}

#[cfg(test)]
pub(crate) fn set_lambda_projection_capture_for_test(enabled: bool) {
    LAMBDA_PROJECTION_CAPTURE_ENABLED.with(|capture| capture.set(enabled));
}

// Keep the frozen arithmetic and first-error order together for direct audit.
#[allow(clippy::too_many_lines)]
fn lambda_step(
    factor: &JacobiFactor,
    y: &[f64],
    lambda: f64,
    mut refinement_work: Option<&mut RefinementWorkLedger>,
    mut projection: LambdaProjection<'_>,
) -> Result<Vec<f64>, &'static str> {
    macro_rules! scalar {
        () => {
            if let Some(work) = refinement_work.as_deref_mut() {
                work.scalar();
            }
        };
    }
    macro_rules! guard {
        () => {
            if let Some(work) = refinement_work.as_deref_mut() {
                work.guard();
            }
        };
    }
    guard!();
    if y.len() != factor.b.len() || !lambda.is_finite() || lambda < 0.0 {
        return Err("invalid lambda input");
    }
    #[cfg(test)]
    if matches!(&projection, LambdaProjection::Record(_))
        && LAMBDA_PROJECTION_CAPTURE_ENABLED.with(Cell::get)
    {
        LAMBDA_PROJECTION_SEARCH_ENTRIES.with(|entries| {
            entries.set(entries.get().saturating_add(1));
        });
    }
    let cols = factor.sigma.len();
    let mut coefficients = vec![0.0; cols];
    for sorted in 0..cols {
        let j = factor.order[sorted];
        let sigma = factor.sigma[j];
        let uty = match &mut projection {
            LambdaProjection::Reuse(values) => values[j],
            LambdaProjection::Reconstruct | LambdaProjection::Record(_) => {
                let mut uty = 0.0;
                for (row, &y_value) in y.iter().enumerate() {
                    let mut av = 0.0;
                    for free in 0..cols {
                        scalar!();
                        let term = factor.a[row][free] * factor.v[free][j];
                        guard!();
                        if !term.is_finite() {
                            return Err("nonfinite A_free V product");
                        }
                        scalar!();
                        av += term;
                        guard!();
                        if !av.is_finite() {
                            return Err("nonfinite A_free V sum");
                        }
                    }
                    scalar!();
                    let u = av / sigma;
                    guard!();
                    if !u.is_finite() || !y_value.is_finite() {
                        return Err("nonfinite U");
                    }
                    scalar!();
                    let term = u * y_value;
                    guard!();
                    if !term.is_finite() {
                        return Err("nonfinite Uty product");
                    }
                    scalar!();
                    uty += term;
                    guard!();
                    if !uty.is_finite() {
                        return Err("nonfinite Uty sum");
                    }
                }
                uty
            }
        };
        // Record at the original per-singular-value boundary, before the
        // lambda-dependent coefficient guard.  This preserves first-refusal
        // precedence during the zero-lambda evaluation that seeds the cache.
        if let LambdaProjection::Record(values) = &mut projection {
            values[j] = uty;
        }
        scalar!();
        let sigma_square = sigma * sigma;
        scalar!();
        let denom = sigma_square + lambda;
        scalar!();
        let gain = sigma / denom;
        scalar!();
        // The frozen grouped expression contains both the multiplication and
        // the unary negation; charge both without changing its rounding.
        scalar!();
        let coefficient = -(gain * uty);
        guard!();
        if !denom.is_finite() || !gain.is_finite() || !coefficient.is_finite() {
            return Err("nonfinite lambda coefficient");
        }
        coefficients[j] = coefficient;
    }
    let mut step = vec![0.0; cols];
    for (out, output) in step.iter_mut().enumerate() {
        let mut sum = 0.0;
        for sorted in 0..cols {
            let j = factor.order[sorted];
            scalar!();
            let term = factor.v[out][j] * coefficients[j];
            guard!();
            if !term.is_finite() {
                return Err("nonfinite V product");
            }
            scalar!();
            sum += term;
            guard!();
            if !sum.is_finite() {
                return Err("nonfinite V sum");
            }
        }
        *output = sum;
    }
    Ok(step)
}

// BVLS-04 keeps the captured factor intact.  These helpers deliberately use
// the existing guarded binary64 primitives: their operation order is the
// authority, and the ledger is charged at each owning arithmetic operation.
fn bvls04_normal_or_signed_zero(
    value: f64,
    work: &mut RefinementWorkLedger,
) -> Result<(), RefinementDot2Reason> {
    work.guard();
    if !value.is_finite() {
        return Err(RefinementDot2Reason::NonfiniteOperand);
    }
    if value != 0.0 && value.abs() < f64::MIN_POSITIVE {
        return Err(RefinementDot2Reason::SubnormalIntermediate);
    }
    Ok(())
}

fn bvls04_product_guard(
    left: f64,
    right: f64,
    value: f64,
    work: &mut RefinementWorkLedger,
) -> Result<(), RefinementDot2Reason> {
    bvls04_normal_or_signed_zero(value, work)?;
    if left != 0.0 && right != 0.0 && value == 0.0 {
        return Err(RefinementDot2Reason::UnderflowToZero);
    }
    Ok(())
}

fn bvls04_validate_shifted_inverse_input(
    factor: &JacobiFactor,
    h: &[f64],
    lambda: f64,
    work: &mut RefinementWorkLedger,
) -> Result<usize, &'static str> {
    let m = h.len();
    work.guard();
    if !lambda.is_finite()
        || lambda <= 0.0
        || factor.v.len() != m
        || factor.sigma.len() != m
        || factor.order.len() != m
        || factor.v.iter().any(|row| row.len() != m)
    {
        return Err("invalid shifted factor shape");
    }
    if bvls04_normal_or_signed_zero(lambda, work).is_err() {
        return Err("invalid shifted lambda source");
    }
    let mut seen = vec![false; m];
    for &j in &factor.order {
        work.guard();
        if j >= m || std::mem::replace(&mut seen[j], true) {
            return Err("invalid shifted factor order");
        }
    }
    Ok(m)
}

#[cfg(test)]
fn refinement_observe_shifted_inverse(trace_t: &[f64], trace_denominator: &[f64], z: &[f64]) {
    refinement_observe(|trace| {
        trace.inverse_t = Some(trace_t.to_vec());
        trace.inverse_denominator = Some(trace_denominator.to_vec());
        trace.inverse_z = Some(z.to_vec());
        if let Some(snapshot) = trace.factor_application_snapshots.last_mut() {
            snapshot.inverse_t_bits = Some(trace_t.iter().map(|value| value.to_bits()).collect());
            snapshot.inverse_denominator_bits = Some(
                trace_denominator
                    .iter()
                    .map(|value| value.to_bits())
                    .collect(),
            );
            snapshot.inverse_z_bits = Some(z.iter().map(|value| value.to_bits()).collect());
        }
        if let Some((_, boundary)) = trace.factor_output_copy_boundary.as_mut() {
            *boundary = RefinementFactorOutputCopyBoundary::AfterInverse;
        }
    });
}

fn bvls04_shifted_inverse(
    factor: &JacobiFactor,
    h: &[f64],
    lambda: f64,
    work: &mut RefinementWorkLedger,
) -> Result<Vec<f64>, &'static str> {
    let m = bvls04_validate_shifted_inverse_input(factor, h, lambda, work)?;

    let mut z = vec![0.0; m];
    let mut trace_t = vec![0.0; m];
    let mut trace_denominator = vec![0.0; m];
    for &j in &factor.order {
        let mut t = 0.0;
        for (i, &h_value) in h.iter().enumerate().take(m) {
            if bvls04_normal_or_signed_zero(factor.v[i][j], work).is_err()
                || bvls04_normal_or_signed_zero(h_value, work).is_err()
            {
                return Err("nonfinite shifted inverse source");
            }
            work.scalar();
            let product = factor.v[i][j] * h_value;
            if bvls04_product_guard(factor.v[i][j], h_value, product, work).is_err() {
                return Err("invalid shifted transpose product");
            }
            work.scalar();
            t += product;
            if bvls04_normal_or_signed_zero(t, work).is_err() {
                return Err("nonfinite shifted transpose sum");
            }
        }
        #[cfg(test)]
        let sigma = BVLS04_POISON.with(|slot| {
            let mut slot = slot.borrow_mut();
            if matches!(*slot, Some(M1TrustRegionBvls04Poison::DenominatorOverflow(index)) if index == j) {
                *slot = None;
                BVLS04_POISON_SITE.with(|site| site.set(Some(j)));
                BVLS04_POISON_CONSUMED.with(|seen| *seen.borrow_mut() = Some((f64::MAX.to_bits(), M1TrustRegionRefinementGuardStage::FactorApplicationOutput)));
                f64::MAX
            } else { factor.sigma[j] }
        });
        #[cfg(not(test))]
        let sigma = factor.sigma[j];
        if bvls04_normal_or_signed_zero(sigma, work).is_err() {
            return Err("invalid shifted sigma source");
        }
        work.scalar();
        let sigma_square = sigma * sigma;
        if bvls04_product_guard(sigma, sigma, sigma_square, work).is_err() {
            return Err("invalid shifted denominator square");
        }
        work.scalar();
        let denominator = sigma_square + lambda;
        if bvls04_normal_or_signed_zero(denominator, work).is_err() || denominator == 0.0 {
            return Err("invalid shifted denominator");
        }
        work.scalar();
        #[cfg(test)] let (t, denominator) = BVLS04_POISON.with(|slot| { let mut slot=slot.borrow_mut(); if matches!(*slot,Some(M1TrustRegionBvls04Poison::DivisionNonfinite(index)) if index == j) { *slot=None; BVLS04_POISON_SITE.with(|site| site.set(Some(j))); BVLS04_POISON_CONSUMED.with(|seen| *seen.borrow_mut()=Some((f64::MAX.to_bits(),M1TrustRegionRefinementGuardStage::FactorApplicationOutput))); (f64::MAX,f64::MIN_POSITIVE) } else {(t,denominator)} });
        z[j] = t / denominator;
        if bvls04_normal_or_signed_zero(z[j], work).is_err() || (t != 0.0 && z[j] == 0.0) {
            return Err("invalid shifted division");
        }
        trace_t[j] = t;
        trace_denominator[j] = denominator;
    }
    #[cfg(test)]
    refinement_observe_shifted_inverse(&trace_t, &trace_denominator, &z);

    let mut delta = vec![0.0; m];
    for (i, delta_slot) in delta.iter_mut().enumerate().take(m) {
        let mut sum = 0.0;
        for &j in &factor.order {
            work.scalar();
            #[cfg(test)]
            let (v, z_value) = (factor.v[i][j], z[j]);
            #[cfg(not(test))]
            let (v, z_value) = (factor.v[i][j], z[j]);
            let product = v * z_value;
            if bvls04_product_guard(v, z_value, product, work).is_err() {
                return Err("invalid shifted inverse product");
            }
            work.scalar();
            sum += product;
            if bvls04_normal_or_signed_zero(sum, work).is_err() {
                return Err("nonfinite shifted inverse sum");
            }
        }
        #[cfg(test)] BVLS04_POISON.with(|slot| { let mut slot=slot.borrow_mut(); if matches!(*slot,Some(M1TrustRegionBvls04Poison::DefensiveInverseOutputInvariant(index)) if index == i) { *slot=None; BVLS04_POISON_SITE.with(|site| site.set(Some(i))); sum=f64::INFINITY; BVLS04_POISON_CONSUMED.with(|seen| *seen.borrow_mut()=Some((f64::INFINITY.to_bits(),M1TrustRegionRefinementGuardStage::FactorApplicationOutput))); } });
        work.scalar();
        *delta_slot = -sum;
        #[cfg(test)]
        BVLS04_OUTPUT_CHECK_EVENT
            .with(|event| *event.borrow_mut() = Some((i, delta_slot.to_bits())));
        if bvls04_normal_or_signed_zero(*delta_slot, work).is_err()
            || (sum != 0.0 && *delta_slot == 0.0)
        {
            return Err("invalid shifted inverse output");
        }
    }
    Ok(delta)
}

fn bvls04_validate_ordinary_defect_input(
    factor: &JacobiFactor,
    free: &[usize],
    lambda: f64,
    work: &mut RefinementWorkLedger,
) -> Result<(), RefinementDot2Reason> {
    work.guard();
    if free.len() != factor.a.first().map_or(0, Vec::len)
        || factor.a.len() != 21
        || free.iter().any(|&id| id >= 21)
    {
        return Err(RefinementDot2Reason::NonfiniteOperand);
    }
    bvls04_normal_or_signed_zero(lambda, work)
}

fn bvls04_add_shift(
    h: &mut f64,
    lambda: f64,
    q: f64,
    work: &mut RefinementWorkLedger,
) -> Result<(), (RefinementDot2Reason, M1TrustRegionRefinementGuardStage)> {
    bvls04_normal_or_signed_zero(q, work).map_err(|reason| {
        (
            reason,
            M1TrustRegionRefinementGuardStage::ResidualSourceWeight,
        )
    })?;
    work.scalar();
    let shift = lambda * q;
    bvls04_product_guard(lambda, q, shift, work)
        .map_err(|reason| (reason, M1TrustRegionRefinementGuardStage::PrimaryProduct))?;
    work.scalar();
    *h += shift;
    bvls04_normal_or_signed_zero(*h, work)
        .map_err(|reason| (reason, M1TrustRegionRefinementGuardStage::Accumulation))
}

fn bvls04_ordinary_defect(
    factor: &JacobiFactor,
    residual: &[f64; 21],
    p: &[f64; 21],
    free: &[usize],
    lambda: f64,
    work: &mut RefinementWorkLedger,
) -> Result<Vec<f64>, RefinementDot2Refusal> {
    macro_rules! fail {
        ($reason:expr, $stage:expr, $row:expr, $term:expr, $coordinate:expr) => {
            return Err(RefinementDot2Refusal {
                reason: $reason,
                guard_stage: $stage,
                row: $row,
                term: $term,
                coordinate: $coordinate,
                arithmetic: 0,
                guards: 0,
                exceptional_guards: 0,
                signed_zero_values: 0,
            })
        };
    }
    if let Err(reason) = bvls04_validate_ordinary_defect_input(factor, free, lambda, work) {
        fail!(
            reason,
            M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
            None,
            None,
            None
        );
    }
    let mut h = vec![0.0; free.len()];
    for slot in 0..free.len() {
        for (row, &residual_value) in residual.iter().enumerate() {
            if let Err(reason) = bvls04_normal_or_signed_zero(factor.a[row][slot], work) {
                fail!(
                    reason,
                    M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                    Some(refinement_face_index(row)),
                    Some(refinement_face_index(slot)),
                    Some(refinement_face_index(free[slot]))
                );
            }
            if let Err(reason) = bvls04_normal_or_signed_zero(residual_value, work) {
                fail!(
                    reason,
                    M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                    Some(refinement_face_index(row)),
                    Some(refinement_face_index(slot)),
                    Some(refinement_face_index(free[slot]))
                );
            }
            work.scalar();
            let product = factor.a[row][slot] * residual_value;
            if let Err(reason) =
                bvls04_product_guard(factor.a[row][slot], residual_value, product, work)
            {
                fail!(
                    reason,
                    M1TrustRegionRefinementGuardStage::PrimaryProduct,
                    Some(refinement_face_index(row)),
                    Some(refinement_face_index(slot)),
                    Some(refinement_face_index(free[slot]))
                );
            }
            work.scalar();
            h[slot] += product;
            if let Err(reason) = bvls04_normal_or_signed_zero(h[slot], work) {
                fail!(
                    reason,
                    M1TrustRegionRefinementGuardStage::Accumulation,
                    Some(refinement_face_index(row)),
                    Some(refinement_face_index(slot)),
                    Some(refinement_face_index(free[slot]))
                );
            }
        }
        if let Err((reason, guard_stage)) =
            bvls04_add_shift(&mut h[slot], lambda, p[free[slot]], work)
        {
            fail!(
                reason,
                guard_stage,
                None,
                Some(refinement_face_index(slot)),
                Some(refinement_face_index(free[slot]))
            );
        }
    }
    Ok(h)
}

fn lambda_norm(
    step: &[f64],
    mut refinement_work: Option<&mut RefinementWorkLedger>,
) -> Result<f64, &'static str> {
    #[cfg(test)]
    let role = REFINEMENT_NORM_ROLE.with(|slot| *slot.borrow());
    #[cfg(test)]
    let mut values = Vec::new();
    #[cfg(test)]
    let mut squares = Vec::new();
    #[cfg(test)]
    let mut running_sums = Vec::new();
    let mut sum = 0.0;
    #[cfg(test)]
    macro_rules! partial {
        ($operation:literal) => {
            if let Some(role) = role {
                let ids: Vec<usize> = (0..step.len()).collect();
                refinement_observe_partial_ordered_norm(
                    role,
                    &ids,
                    &values,
                    &squares,
                    &running_sums,
                    $operation,
                    None,
                );
            }
        };
    }
    for &x in step {
        if let Some(work) = refinement_work.as_deref_mut() {
            work.scalar();
        }
        let sq = x * x;
        #[cfg(test)]
        if role.is_some() {
            values.push(x.to_bits());
            squares.push(sq.to_bits());
        }
        if let Some(work) = refinement_work.as_deref_mut() {
            work.guard();
        }
        if !sq.is_finite() {
            #[cfg(test)]
            partial!("square_guard");
            return Err("nonfinite norm");
        }
        if let Some(work) = refinement_work.as_deref_mut() {
            work.scalar();
        }
        sum += sq;
        #[cfg(test)]
        if role.is_some() {
            running_sums.push(sum.to_bits());
        }
        if let Some(work) = refinement_work.as_deref_mut() {
            work.guard();
        }
        if !sum.is_finite() {
            #[cfg(test)]
            partial!("running_sum_guard");
            return Err("nonfinite norm");
        }
    }
    if let Some(work) = refinement_work {
        work.scalar();
        work.guard();
    }
    let norm = sum.sqrt();
    if norm.is_finite() {
        #[cfg(test)]
        if let Some(role) = role {
            refinement_observe(|trace| {
                trace.ordered_norms.push(RefinementOrderedNormTrace {
                    role,
                    coordinate_ids: (0..step.len()).collect(),
                    value_bits: values.clone(),
                    square_bits: squares.clone(),
                    running_sum_bits: running_sums.clone(),
                    norm2_bits: sum.to_bits(),
                    norm_bits: norm.to_bits(),
                });
            });
        }
        Ok(norm)
    } else {
        #[cfg(test)]
        if let Some(role) = role {
            let ids: Vec<usize> = (0..step.len()).collect();
            refinement_observe_partial_ordered_norm(
                role,
                &ids,
                values.as_ref(),
                squares.as_ref(),
                running_sums.as_ref(),
                "sqrt_guard",
                Some(norm.to_bits()),
            );
        }
        Err("nonfinite norm")
    }
}

#[cfg(test)]
fn refinement_observe_partial_ordered_norm(
    role: &'static str,
    coordinates: &[usize],
    values: &[u64],
    squares: &[u64],
    running_sums: &[u64],
    terminal_operation: &'static str,
    sqrt_bits: Option<u64>,
) {
    refinement_observe(|trace| {
        trace
            .partial_ordered_norms
            .push(RefinementPartialOrderedNormTrace {
                role,
                coordinate_ids: coordinates[..values.len()].to_vec(),
                value_bits: values.to_vec(),
                square_bits: squares.to_vec(),
                running_sum_bits: running_sums.to_vec(),
                terminal_operation,
                sqrt_bits,
            });
    });
}

#[cfg(test)]
fn refinement_observe_partial_ordered_norm_if_active(
    role: &'static str,
    coordinates: &[usize],
    values: Option<&Vec<u64>>,
    squares: Option<&Vec<u64>>,
    running_sums: Option<&Vec<u64>>,
    operation: &'static str,
    sqrt_bits: Option<u64>,
) {
    if let (Some(values), Some(squares), Some(running_sums)) = (values, squares, running_sums) {
        refinement_observe_partial_ordered_norm(
            role,
            coordinates,
            values,
            squares,
            running_sums,
            operation,
            sqrt_bits,
        );
    }
}

#[cfg(test)]
fn refinement_observe_completed_ordered_norm(
    role: &'static str,
    coordinates: &[usize],
    values: Option<Vec<u64>>,
    squares: Option<Vec<u64>>,
    running_sums: Option<Vec<u64>>,
    norm2: f64,
    norm: f64,
) {
    if let (Some(values), Some(squares), Some(running_sums)) = (values, squares, running_sums) {
        refinement_observe(|trace| {
            trace.ordered_norms.push(RefinementOrderedNormTrace {
                role,
                coordinate_ids: coordinates.to_vec(),
                value_bits: values.clone(),
                square_bits: squares.clone(),
                running_sum_bits: running_sums.clone(),
                norm2_bits: norm2.to_bits(),
                norm_bits: norm.to_bits(),
            });
        });
    }
}

fn bvls04_ordered_norm(
    p: &[f64; 21],
    coordinates: &[usize],
    work: &mut RefinementWorkLedger,
    role: &'static str,
) -> Result<(f64, f64), RefinementDot2Reason> {
    work.bvls04_ordered_norms += 1;
    let mut sum = 0.0;
    #[cfg(test)]
    let active = REFINEMENT_OBSERVATION.with(|slot| slot.borrow().is_some());
    #[cfg(test)]
    let mut values = active.then(|| Vec::with_capacity(coordinates.len()));
    #[cfg(test)]
    let mut squares = active.then(|| Vec::with_capacity(coordinates.len()));
    #[cfg(test)]
    let mut running_sums = active.then(|| Vec::with_capacity(coordinates.len()));
    #[cfg(test)]
    macro_rules! partial {
        ($operation:literal) => {
            refinement_observe_partial_ordered_norm_if_active(
                role,
                coordinates,
                values.as_ref(),
                squares.as_ref(),
                running_sums.as_ref(),
                $operation,
                None,
            );
        };
    }
    for &coordinate in coordinates {
        if coordinate >= 21 {
            #[cfg(test)]
            partial!("coordinate");
            return Err(RefinementDot2Reason::NonfiniteOperand);
        }
        #[cfg(test)]
        if let Some(values) = &mut values {
            values.push(p[coordinate].to_bits());
        }
        if let Err(reason) = bvls04_normal_or_signed_zero(p[coordinate], work) {
            #[cfg(test)]
            partial!("value_guard");
            return Err(reason);
        }
        work.scalar();
        let square = p[coordinate] * p[coordinate];
        #[cfg(test)]
        if let Some(squares) = &mut squares {
            squares.push(square.to_bits());
        }
        if let Err(reason) = bvls04_product_guard(p[coordinate], p[coordinate], square, work) {
            #[cfg(test)]
            partial!("square_guard");
            return Err(reason);
        }
        work.scalar();
        sum += square;
        #[cfg(test)]
        if let Some(running_sums) = &mut running_sums {
            running_sums.push(sum.to_bits());
        }
        if let Err(reason) = bvls04_normal_or_signed_zero(sum, work) {
            #[cfg(test)]
            partial!("running_sum_guard");
            return Err(reason);
        }
    }
    work.scalar();
    let norm = sum.sqrt();
    if let Err(reason) = bvls04_normal_or_signed_zero(norm, work) {
        #[cfg(test)]
        if let (Some(values), Some(squares), Some(running_sums)) =
            (&values, &squares, &running_sums)
        {
            refinement_observe_partial_ordered_norm(
                role,
                coordinates,
                values,
                squares,
                running_sums,
                "sqrt_guard",
                Some(norm.to_bits()),
            );
        }
        return Err(reason);
    }
    #[cfg(test)]
    refinement_observe_completed_ordered_norm(
        role,
        coordinates,
        values,
        squares,
        running_sums,
        sum,
        norm,
    );
    Ok((sum, norm))
}

#[cfg(test)]
struct M1TrustRegionBvls04AnalyticInput {
    v: Vec<Vec<f64>>,
    sigma: Vec<f64>,
    factor_order: Vec<usize>,
    free_ids: Vec<usize>,
    unshifted_gradient: Vec<f64>,
    lambda: f64,
    q: Vec<f64>,
}

#[cfg(test)]
struct M1TrustRegionBvls04ShiftedInverseInput {
    v: Vec<Vec<f64>>,
    sigma: Vec<f64>,
    lambda: f64,
    complete_shifted_defect: Vec<f64>,
    free_ids: Vec<usize>,
    factor_order: Vec<usize>,
}

#[cfg(test)]
struct M1TrustRegionBvls04InverseObservation {
    t_bits: Vec<u64>,
    denominator_bits: Vec<u64>,
    z_bits: Vec<u64>,
    delta_free_slot_bits: Vec<u64>,
    delta_coordinate_bits: Vec<u64>,
    factor_order: Vec<usize>,
    free_ids: Vec<usize>,
}

#[cfg(test)]
struct M1TrustRegionBvls04AnalyticObservation {
    shifted_gradient_bits: Vec<u64>,
    t_bits: Vec<u64>,
    z_bits: Vec<u64>,
    delta_free_slot_bits: Vec<u64>,
    delta_coordinate_bits: Vec<u64>,
    factor_order: Vec<usize>,
    free_ids: Vec<usize>,
}

#[cfg(test)]
fn bvls04_factor_for_test(v: Vec<Vec<f64>>, sigma: Vec<f64>, order: Vec<usize>) -> JacobiFactor {
    let m = sigma.len();
    JacobiFactor {
        a: vec![vec![0.0; m]; 21],
        b: vec![vec![0.0; m]; 21],
        v,
        sigma,
        order,
        visits: Vec::new(),
        rotations: 0,
        sweeps: 0,
    }
}

#[cfg(test)]
fn m1_trust_region_bvls04_shifted_inverse_for_test(
    input: M1TrustRegionBvls04ShiftedInverseInput,
) -> Result<M1TrustRegionBvls04InverseObservation, &'static str> {
    let factor = bvls04_factor_for_test(input.v, input.sigma, input.factor_order.clone());
    let m = input.complete_shifted_defect.len();
    let mut work = RefinementWorkLedger::default();
    let _scope = RefinementObservationScope::begin();
    let delta = bvls04_shifted_inverse(
        &factor,
        &input.complete_shifted_defect,
        input.lambda,
        &mut work,
    )?;
    let trace = refinement_observation_take().ok_or("inverse trace missing")?;
    let t = trace.inverse_t.ok_or("inverse t missing")?;
    let denominator = trace
        .inverse_denominator
        .ok_or("inverse denominator missing")?;
    let z = trace.inverse_z.ok_or("inverse z missing")?;
    let mut by_coordinate = vec![0_u64; m];
    for (slot, &coordinate) in input.free_ids.iter().enumerate() {
        if coordinate >= m {
            return Err("invalid free coordinate");
        }
        by_coordinate[coordinate] = delta[slot].to_bits();
    }
    Ok(M1TrustRegionBvls04InverseObservation {
        t_bits: t.into_iter().map(f64::to_bits).collect(),
        denominator_bits: denominator.into_iter().map(f64::to_bits).collect(),
        z_bits: z.into_iter().map(f64::to_bits).collect(),
        delta_free_slot_bits: delta.into_iter().map(f64::to_bits).collect(),
        delta_coordinate_bits: by_coordinate,
        factor_order: input.factor_order,
        free_ids: input.free_ids,
    })
}

#[cfg(test)]
fn m1_trust_region_bvls04_analytic_for_test(
    input: M1TrustRegionBvls04AnalyticInput,
) -> Result<M1TrustRegionBvls04AnalyticObservation, &'static str> {
    if input.unshifted_gradient.len() != input.q.len() {
        return Err("analytic dimension");
    }
    let mut factor = bvls04_factor_for_test(input.v, input.sigma, input.factor_order.clone());
    let mut residual = [0.0; 21];
    let mut p = [0.0; 21];
    for (slot, &coordinate) in input.free_ids.iter().enumerate() {
        if coordinate >= 21 {
            return Err("analytic free coordinate");
        }
        factor.a[coordinate][slot] = 1.0;
        residual[coordinate] = input.unshifted_gradient[slot];
        p[coordinate] = input.q[slot];
    }
    let mut work = RefinementWorkLedger::default();
    let h = bvls04_ordinary_defect(
        &factor,
        &residual,
        &p,
        &input.free_ids,
        input.lambda,
        &mut work,
    )
    .map_err(|_| "analytic shifted defect")?;
    let inverse =
        m1_trust_region_bvls04_shifted_inverse_for_test(M1TrustRegionBvls04ShiftedInverseInput {
            v: factor.v.clone(),
            sigma: factor.sigma.clone(),
            lambda: input.lambda,
            complete_shifted_defect: h.clone(),
            free_ids: input.free_ids.clone(),
            factor_order: input.factor_order.clone(),
        })?;
    Ok(M1TrustRegionBvls04AnalyticObservation {
        shifted_gradient_bits: h.into_iter().map(f64::to_bits).collect(),
        t_bits: inverse.t_bits,
        z_bits: inverse.z_bits,
        delta_free_slot_bits: inverse.delta_free_slot_bits,
        delta_coordinate_bits: inverse.delta_coordinate_bits,
        factor_order: input.factor_order,
        free_ids: input.free_ids,
    })
}

fn svd_lambda_ball(
    factor: &JacobiFactor,
    y: &[f64],
    radius: f64,
    override_endpoint: Option<&[f64]>,
    trace: &mut LambdaTrace,
) -> Result<(), M1TrustRegionRefusalKind> {
    if !radius.is_finite() || radius <= 0.0 {
        return Err(M1TrustRegionRefusalKind::DegenerateFace);
    }
    let mut projection = vec![0.0; factor.sigma.len()];
    let zero = lambda_step(
        factor,
        y,
        0.0,
        None,
        LambdaProjection::Record(&mut projection),
    )
    .map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
    let n0 = lambda_norm(&zero, None).map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
    trace.initial_bracket = [0.0, 0.0];
    trace.bracket = [0.0, 0.0];
    trace.bracket_evaluations.push((0.0, n0));
    if n0 <= radius {
        trace.lambda = 0.0;
        trace.step = zero.clone();
        trace.natural_step = zero.clone();
        trace.pre_hook_step = zero.clone();
        trace.post_hook_step = zero;
        trace.norm = n0;
        trace.gap = radius - n0;
        trace.tolerance = (2_f64.powi(-40) * radius).max(64.0 * f64::EPSILON * radius.max(1.0));
        return Ok(());
    }
    let mut lo = 0.0;
    let mut hi = 1.0;
    let mut high = lambda_step(factor, y, hi, None, LambdaProjection::Reuse(&projection))
        .map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
    let mut nh = lambda_norm(&high, None).map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
    trace.initial_bracket = [0.0, hi];
    trace.bracket = [0.0, hi];
    trace.bracket_evaluations.push((hi, nh));
    for _ in 0..48 {
        if nh <= radius {
            break;
        }
        lo = hi;
        hi *= 4.0;
        high = lambda_step(factor, y, hi, None, LambdaProjection::Reuse(&projection))
            .map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
        nh = lambda_norm(&high, None).map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
        trace.bracket_evaluations.push((hi, nh));
    }
    if nh > radius {
        return Err(M1TrustRegionRefusalKind::LambdaBracket);
    }
    for _ in 0..48 {
        let mid = (lo + hi) * 0.5;
        let step = lambda_step(factor, y, mid, None, LambdaProjection::Reuse(&projection))
            .map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
        let norm = lambda_norm(&step, None).map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
        trace.bisection_evaluations.push((mid, norm));
        if norm <= radius {
            hi = mid;
            high = step;
        } else {
            lo = mid;
        }
    }
    trace.bracket = [lo, hi];
    trace.lambda = hi;
    trace.natural_step = high.clone();
    trace.pre_hook_step = high;
    trace.post_hook_step =
        override_endpoint.map_or_else(|| trace.pre_hook_step.clone(), <[f64]>::to_vec);
    trace.step = trace.post_hook_step.clone();
    let norm =
        lambda_norm(&trace.step, None).map_err(|_| M1TrustRegionRefusalKind::SvdNonFinite)?;
    let gap = radius - norm;
    let tolerance = (2_f64.powi(-40) * radius).max(64.0 * f64::EPSILON * radius.max(1.0));
    trace.norm = norm;
    trace.gap = gap;
    trace.tolerance = tolerance;
    if norm > radius || gap > tolerance {
        return Err(M1TrustRegionRefusalKind::BallAccuracy);
    }
    Ok(())
}

pub(crate) fn m1_trust_region_validate_ball_endpoint_for_test(
    endpoint: M1TrustRegionBallEndpoint,
) -> M1TrustRegionBallObservation {
    // This is deliberately only a data adapter around the shared factorization
    // and ball solve.  The test seam may replace the final coordinate after the
    // canonical bisections; it does not select a verdict or alter their count.
    let mut observed_sweeps = 0;
    let factor = jacobi_factor(vec![vec![endpoint.a]], &[0], 0, &mut observed_sweeps);
    let mut trace = LambdaTrace::default();
    let (factorization_entered, kind) = match factor {
        Ok(factor) => {
            let y = [endpoint.f];
            let result = svd_lambda_ball(
                &factor,
                &y,
                endpoint.radius,
                endpoint.endpoint_override.as_ref().map(|x| &x[..]),
                &mut trace,
            );
            (true, result.err())
        }
        Err("rank deficient") => (true, Some(M1TrustRegionRefusalKind::RankDeficient)),
        Err("no convergence") => (true, Some(M1TrustRegionRefusalKind::SvdNoConvergence)),
        Err(_) => (true, Some(M1TrustRegionRefusalKind::SvdNonFinite)),
    };
    let evaluation = |(lambda, norm): &(f64, f64)| M1TrustRegionLambdaEvaluation {
        lambda: *lambda,
        norm: *norm,
        feasible: *norm <= endpoint.radius,
    };
    let scalar = |values: &[f64]| values.first().copied().unwrap_or(f64::NAN);
    M1TrustRegionBallObservation {
        factorization_entered,
        bracket_endpoint_evaluations: trace.bracket_evaluations.iter().map(evaluation).collect(),
        bisection_evaluations: trace.bisection_evaluations.iter().map(evaluation).collect(),
        bracket_initial: trace.initial_bracket,
        bracket_final: trace.bracket,
        final_upper_lambda: trace.lambda,
        natural_upper_endpoint: scalar(&trace.natural_step),
        pre_hook_endpoint: scalar(&trace.pre_hook_step),
        endpoint_hook_observed: endpoint.endpoint_override,
        post_hook_endpoint: [scalar(&trace.post_hook_step)],
        computed_norm: trace.norm,
        computed_gap: trace.gap,
        computed_tolerance: trace.tolerance,
        accepted: kind.is_none(),
        kind,
    }
}

fn jacobi_column_products(
    matrix: &[Vec<f64>],
    left: usize,
    right: usize,
) -> Result<(f64, f64, f64), &'static str> {
    let mut alpha = 0.0;
    let mut beta = 0.0;
    let mut gamma = 0.0;
    for row in matrix {
        let left_value = row[left];
        let right_value = row[right];
        let left_square = left_value * left_value;
        let right_square = right_value * right_value;
        let product = left_value * right_value;
        if !left_square.is_finite() || !right_square.is_finite() || !product.is_finite() {
            return Err("nonfinite SVD product");
        }
        alpha += left_square;
        beta += right_square;
        gamma += product;
        if !alpha.is_finite() || !beta.is_finite() || !gamma.is_finite() {
            return Err("nonfinite SVD accumulation");
        }
    }
    Ok((alpha, beta, gamma))
}

fn rotate_jacobi_columns(
    matrix: &mut [Vec<f64>],
    left: usize,
    right: usize,
    cosine: f64,
    sine: f64,
) -> Result<(), &'static str> {
    for row in matrix {
        let left_value = row[left];
        let right_value = row[right];
        let new_left = cosine * left_value - sine * right_value;
        let new_right = sine * left_value + cosine * right_value;
        if !new_left.is_finite() || !new_right.is_finite() {
            return Err("nonfinite rotation product");
        }
        row[left] = new_left;
        row[right] = new_right;
    }
    Ok(())
}

type SortedSingularValues =
    Result<(Vec<f64>, Vec<usize>), (&'static str, Vec<f64>, f64, Option<f64>)>;

fn sorted_singular_values(rotated_b: &[Vec<f64>], free_ids: &[usize]) -> SortedSingularValues {
    let cols = free_ids.len();
    let mut sigma = vec![0.0; cols];
    for col in 0..cols {
        for row in rotated_b {
            let square = row[col] * row[col];
            if !square.is_finite() {
                return Err(("nonfinite singular value", sigma, f64::NAN, None));
            }
            sigma[col] += square;
            if !sigma[col].is_finite() {
                return Err(("nonfinite singular value", sigma, f64::NAN, None));
            }
        }
        sigma[col] = sigma[col].sqrt();
        if !sigma[col].is_finite() {
            return Err(("nonfinite singular value", sigma, f64::NAN, None));
        }
    }
    let max = sigma.iter().copied().fold(0.0, f64::max);
    let mut refusal_threshold = None;
    if max == 0.0
        || sigma.iter().any(|s| {
            let threshold = 2_f64.powi(-40) * max;
            let refused = *s <= threshold;
            if refused {
                refusal_threshold = Some(threshold);
            }
            refused
        })
    {
        return Err(("rank deficient", sigma, max, refusal_threshold));
    }
    let mut order: Vec<usize> = (0..cols).collect();
    order.sort_by(|a, b| {
        sigma[*b]
            .total_cmp(&sigma[*a])
            .then_with(|| free_ids[*a].cmp(&free_ids[*b]))
    });
    Ok((sigma, order))
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_rank_refusal_factor(
    result: &SortedSingularValues,
    a: &[Vec<f64>],
    b: &[Vec<f64>],
    v: &[Vec<f64>],
    visits: &[super::M1TrustRegionJacobiPair],
    rotations: usize,
    sweeps: u8,
) {
    let Err(("rank deficient", sigma, rank_max, rank_threshold)) = result else {
        return;
    };
    record_face_pivot_capture(|capture| {
        capture.rank_refusal_factor = Some(M1FacePivotFactorCapture {
            same_invocation_identity: None,
            same_invocation_identity_available: false,
            a: a.to_vec(),
            b: b.to_vec(),
            v: v.to_vec(),
            sigma: sigma.clone(),
            rank_max: Some(*rank_max),
            rank_threshold: *rank_threshold,
            order: Vec::new(),
            order_computed: false,
            visits: visits.to_vec(),
            rotations,
            sweeps,
        });
    });
}

/// Drives the authenticated C6 face through the ordinary retained BVLS/SVD
/// subproblem entry.  The fixture supplies every face operand; this seam does
/// not synthesize a candidate, controller trial, or materialization outcome.
#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn m1_separate_accuracy_c6_rank_refusal_for_test(
    matrix: &[Vec<f64>],
    f: f64,
    base: f64,
    lower: f64,
    upper: f64,
    radius: f64,
) -> Result<super::M1TrustRegionSubproblemObservation, super::M1TrustRegionSubproblemRefusal> {
    assert!(matrix.len() == 21 && matrix.iter().all(|row| row.len() == 11));
    let mut raw_jacobian = [[0.0; 21]; 21];
    for (row_index, row) in matrix.iter().enumerate() {
        raw_jacobian[row_index][..11].copy_from_slice(row);
    }
    let mut lower_bounds = [base; 21];
    let mut upper_bounds = [base; 21];
    lower_bounds[..11].fill(lower);
    upper_bounds[..11].fill(upper);
    let mut raw_residual = [0.0; 21];
    raw_residual[0] = f;
    solve_subproblem(&super::M1TrustRegionSubproblemInput {
        raw_residual,
        raw_jacobian,
        normalizers: [1.0; 21],
        scales: [1.0; 21],
        lower: lower_bounds,
        upper: upper_bounds,
        initial_radius: radius,
        base: [base; 21],
        test_work: super::M1TrustRegionTestWorkState::default(),
    })
}

fn jacobi_factor(
    mut b: Vec<Vec<f64>>,
    free_ids: &[usize],
    completed_sweeps: u8,
    work_counter: &mut u8,
) -> Result<JacobiFactor, &'static str> {
    let a = b.clone();
    let cols = free_ids.len();
    if cols == 0
        || b.iter()
            .any(|row| row.len() != cols || row.iter().any(|x| !x.is_finite()))
    {
        return Err("invalid SVD input");
    }
    let mut v = vec![vec![0.0; cols]; cols];
    for (index, row) in v.iter_mut().enumerate() {
        row[index] = 1.0;
    }
    let mut visits = Vec::new();
    let mut rotations = 0usize;
    let mut sweeps = completed_sweeps;
    *work_counter = completed_sweeps;
    if completed_sweeps >= 64 {
        return Err("no convergence");
    }
    for sweep in (completed_sweeps + 1)..=64u8 {
        let mut any = false;
        for left in 0..cols {
            for right in left + 1..cols {
                let (alpha, beta, gamma) = jacobi_column_products(&b, left, right)?;
                if !alpha.is_finite() || !beta.is_finite() || !gamma.is_finite() {
                    return Err("nonfinite SVD intermediate");
                }
                let product = alpha * beta;
                let root = product.sqrt();
                let threshold = 2_f64.powi(-48) * root;
                if !product.is_finite() || !root.is_finite() || !threshold.is_finite() {
                    return Err("nonfinite SVD threshold");
                }
                let rotate = gamma.abs() > threshold;
                visits.push(M1TrustRegionJacobiPair {
                    left,
                    right,
                    rotated: rotate,
                    sweep,
                });
                if rotate {
                    let numerator = beta - alpha;
                    let denominator = 2.0 * gamma;
                    let tau = numerator / denominator;
                    let hypot = tau.hypot(1.0);
                    let divisor = tau.abs() + hypot;
                    let tangent = if tau == 0.0 {
                        1.0
                    } else {
                        tau.signum() / divisor
                    };
                    let cosine = 1.0 / tangent.hypot(1.0);
                    let sine = cosine * tangent;
                    if !numerator.is_finite()
                        || !denominator.is_finite()
                        || !tau.is_finite()
                        || !hypot.is_finite()
                        || !divisor.is_finite()
                        || !tangent.is_finite()
                        || !cosine.is_finite()
                        || !sine.is_finite()
                    {
                        return Err("nonfinite rotation");
                    }
                    rotate_jacobi_columns(&mut b, left, right, cosine, sine)?;
                    rotate_jacobi_columns(&mut v, left, right, cosine, sine)?;
                    rotations += 1;
                    any = true;
                }
            }
        }
        sweeps = sweep;
        *work_counter = sweeps;
        if !any {
            break;
        }
    }
    if sweeps == 64
        && visits
            .iter()
            .rev()
            .take(cols * (cols - 1) / 2)
            .any(|p| p.rotated)
    {
        return Err("no convergence");
    }
    let result = sorted_singular_values(&b, free_ids);
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    capture_rank_refusal_factor(&result, &a, &b, &v, &visits, rotations, sweeps);
    let (sigma, order) = result.map_err(|(error, _, _, _)| error)?;
    Ok(JacobiFactor {
        a,
        b,
        v,
        sigma,
        order,
        visits,
        rotations,
        sweeps,
    })
}

pub(crate) fn m1_trust_region_jacobi_observation_for_test(
    input: M1TrustRegionJacobiInput,
) -> M1TrustRegionJacobiObservation {
    let mut observed_sweeps = 0;
    let factor = jacobi_factor(
        input.matrix.iter().map(|row| row.to_vec()).collect(),
        &input.free_ids,
        0,
        &mut observed_sweeps,
    )
    .expect("Jacobi fixture");
    let column = |m: &Vec<Vec<f64>>, c| [m[0][c], m[1][c], m[2][c]];
    let mut sorted_b = [[0.0; 3]; 3];
    let mut sorted_v = [[0.0; 3]; 3];
    let mut sorted_sigma = [0.0; 3];
    let mut sorted_ids = [0; 3];
    let mut order = [0; 3];
    for k in 0..3 {
        let c = factor.order[k];
        order[k] = c;
        sorted_sigma[k] = factor.sigma[c];
        sorted_ids[k] = input.free_ids[c];
        sorted_b[k] = column(&factor.b, c);
        sorted_v[k] = column(&factor.v, c);
    }
    M1TrustRegionJacobiObservation {
        completed_sweeps: factor.sweeps,
        pair_visits: factor.visits,
        rotations: factor.rotations,
        b_columns: [
            column(&factor.b, 0),
            column(&factor.b, 1),
            column(&factor.b, 2),
        ],
        v_columns: [
            column(&factor.v, 0),
            column(&factor.v, 1),
            column(&factor.v, 2),
        ],
        unsorted_singular_values: [factor.sigma[0], factor.sigma[1], factor.sigma[2]],
        sorted_singular_values: sorted_sigma,
        sorted_free_ids: sorted_ids,
        sorted_from_unsorted: order,
        sorted_b_columns: sorted_b,
        sorted_v_columns: sorted_v,
    }
}

fn subproblem_refusal(
    kind: M1TrustRegionRefusalKind,
    attempted_subproblems: u8,
    completed_jacobi_sweeps: u8,
    completed_face_pivots: u8,
    entered_svd_factorizations: u8,
    raw_residual_max: f64,
) -> super::M1TrustRegionSubproblemRefusal {
    super::M1TrustRegionSubproblemRefusal {
        kind,
        optimality_reason: None,
        optimality_coordinate: None,
        optimality_radius: None,
        optimality_lambda: None,
        attempted_subproblems,
        completed_jacobi_sweeps,
        completed_face_pivots,
        entered_svd_factorizations,
        raw_residual_max,
        work: Box::new(super::M1TrustRegionWorkObservation {
            stage1_calls: 1,
            entered_svd_factorizations: u32::from(entered_svd_factorizations),
            completed_face_pivots: u32::from(completed_face_pivots),
            ..Default::default()
        }),
        refinement: None,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_refusal: None,
    }
}

struct PreparedSubproblem {
    raw_max: f64,
    weighted_residual: Vec<f64>,
    weighted_matrix: Vec<Vec<f64>>,
    scaled_lower: [f64; 21],
    scaled_upper: [f64; 21],
}

struct KktValues {
    residual: [f64; 21],
    gradient: [f64; 21],
    lambda_times_step: [f64; 21],
    h: [f64; 21],
}

struct SubproblemState {
    p: [f64; 21],
    lower_active: [bool; 21],
    upper_active: [bool; 21],
    free: [bool; 21],
    initial_free: [bool; 21],
    // BVLS-05 is an assembly-owned direction hold.  It is deliberately
    // separate from the physical active-bound masks.
    held: [bool; 21],
    bvls05_inspected: bool,
    bvls05_work: super::M1TrustRegionWorkObservation,
    events: Vec<super::M1TrustRegionKktEvent>,
    entered: u8,
    completed_pivots: u8,
    completed_sweeps: u8,
    last_face_radius: Option<f64>,
    total_jacobi_sweeps: u32,
    refinement_work: RefinementWorkLedger,
}

impl SubproblemState {
    fn new(input: &super::M1TrustRegionSubproblemInput) -> Self {
        let mut free = [false; 21];
        for (col, is_free) in free.iter_mut().enumerate() {
            *is_free = input.lower[col].partial_cmp(&input.upper[col]) != Some(Ordering::Equal);
        }
        Self {
            p: [0.0; 21],
            lower_active: [false; 21],
            upper_active: [false; 21],
            initial_free: free,
            free,
            held: [false; 21],
            bvls05_inspected: false,
            bvls05_work: super::M1TrustRegionWorkObservation::default(),
            events: Vec::new(),
            entered: 0,
            completed_pivots: input.test_work.completed_face_pivots,
            completed_sweeps: input.test_work.completed_jacobi_sweeps,
            last_face_radius: None,
            total_jacobi_sweeps: 0,
            refinement_work: RefinementWorkLedger::default(),
        }
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_operation(state: &SubproblemState, operation: M1FacePivotCaptureOperation) {
    record_face_pivot_capture(|capture| {
        capture.operations.push(M1FacePivotCaptureOperation {
            action: operation.action,
            p_before: operation.p_before,
            p_candidate: operation.p_candidate,
            conceptual_p_after: operation.conceptual_p_after,
            scratch_p_at_refusal: operation.scratch_p_at_refusal,
            applied: operation.applied,
            lower_before: operation.lower_before,
            upper_before: operation.upper_before,
            free_before: operation.free_before,
            lower_after: state.lower_active,
            upper_after: state.upper_active,
            free_after: state.free,
            free_ids: operation.free_ids,
            radius: operation.radius,
            lambda: operation.lambda,
            weighted_residual: operation.weighted_residual,
            weighted_matrix: operation.weighted_matrix,
            crossing_theta: operation.crossing_theta,
            selected_coordinate: operation.selected_coordinate,
            selected_lower: operation.selected_lower,
            residual: operation.residual,
            g: operation.g,
            lambda_times_p: operation.lambda_times_p,
            h: operation.h,
            optimality: operation.optimality,
            entered_factorizations: state.entered,
            completed_pivots: state.completed_pivots,
            completed_sweeps: state.completed_sweeps,
        });
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_refusal(
    refusal_stage: &'static str,
    kind: M1TrustRegionRefusalKind,
    state: &mut SubproblemState,
    prepared: &PreparedSubproblem,
) {
    record_face_pivot_capture(|capture| {
        capture.refusal = Some(M1FacePivotCaptureRefusal {
            stage: refusal_stage,
            kind,
            optimality_reason: None,
            optimality_coordinate: None,
            radius: state.last_face_radius,
            lambda: None,
            free_ids: state
                .free
                .iter()
                .enumerate()
                .filter_map(|(index, free)| free.then_some(index))
                .collect(),
            p: state.p,
            lower: state.lower_active,
            upper: state.upper_active,
            free: state.free,
            scaled_lower: Some(prepared.scaled_lower),
            scaled_upper: Some(prepared.scaled_upper),
            entered_factorizations: state.entered,
            completed_pivots: state.completed_pivots,
            completed_sweeps: state.completed_sweeps,
            optimality: None,
            lambda_trace: None,
            factor: capture.rank_refusal_factor.clone(),
        });
        capture
            .completed_subproblems
            .push(M1FacePivotSubproblemSummary {
                entered_factorizations: state.entered,
                completed_pivots: state.completed_pivots,
                completed_sweeps: state.completed_sweeps,
                refused: true,
            });
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_optimality_failure(
    state: &mut SubproblemState,
    solution: &FaceSolution,
    prepared: &PreparedSubproblem,
    values: Option<&KktValues>,
    assessment: Option<&OptimalityAssessment>,
    failure: OptimalityFailure,
) {
    record_face_pivot_capture(|capture| {
        if let Some(values) = values {
            capture.operations.push(M1FacePivotCaptureOperation {
                action: "optimality-refusal",
                p_before: state.p,
                p_candidate: state.p,
                conceptual_p_after: state.p,
                scratch_p_at_refusal: None,
                applied: false,
                lower_before: state.lower_active,
                upper_before: state.upper_active,
                free_before: state.free,
                lower_after: state.lower_active,
                upper_after: state.upper_active,
                free_after: state.free,
                free_ids: solution.free_ids.clone(),
                radius: solution.radius,
                lambda: Some(solution.trace.lambda),
                weighted_residual: Some(
                    prepared
                        .weighted_residual
                        .clone()
                        .try_into()
                        .expect("fixed KKT dimension"),
                ),
                weighted_matrix: Some(prepared.weighted_matrix.clone()),
                crossing_theta: None,
                selected_coordinate: None,
                selected_lower: None,
                residual: Some(values.residual),
                g: Some(values.gradient),
                lambda_times_p: Some(values.lambda_times_step),
                h: Some(values.h),
                optimality: assessment.map(|value| value.observation.clone()),
                entered_factorizations: state.entered,
                completed_pivots: state.completed_pivots,
                completed_sweeps: state.completed_sweeps,
            });
        }
        capture.refusal = Some(M1FacePivotCaptureRefusal {
            stage: "kkt-optimality",
            kind: M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate,
            optimality_reason: Some(failure.reason),
            optimality_coordinate: Some(failure.coordinate),
            radius: Some(solution.radius),
            lambda: Some(solution.trace.lambda),
            free_ids: solution.free_ids.clone(),
            p: state.p,
            lower: state.lower_active,
            upper: state.upper_active,
            free: state.free,
            scaled_lower: Some(prepared.scaled_lower),
            scaled_upper: Some(prepared.scaled_upper),
            entered_factorizations: state.entered,
            completed_pivots: state.completed_pivots,
            completed_sweeps: state.completed_sweeps,
            optimality: assessment.map(|value| value.observation.clone()),
            lambda_trace: Some(M1FacePivotLambdaTraceCapture {
                initial_bracket: solution.trace.initial_bracket,
                bracket: solution.trace.bracket,
                bracket_evaluations: solution.trace.bracket_evaluations.clone(),
                bisection_evaluations: solution.trace.bisection_evaluations.clone(),
                lambda: solution.trace.lambda,
                natural_step: solution.trace.natural_step.clone(),
                pre_hook_step: solution.trace.pre_hook_step.clone(),
                post_hook_step: solution.trace.post_hook_step.clone(),
                norm: solution.trace.norm,
                gap: solution.trace.gap,
                tolerance: solution.trace.tolerance,
            }),
            factor: solution
                .factor
                .as_ref()
                .map(|factor| M1FacePivotFactorCapture {
                    same_invocation_identity: Some(std::ptr::from_ref(factor) as usize),
                    same_invocation_identity_available: true,
                    a: factor.a.clone(),
                    b: factor.b.clone(),
                    v: factor.v.clone(),
                    sigma: factor.sigma.clone(),
                    rank_max: None,
                    rank_threshold: None,
                    order: factor.order.clone(),
                    order_computed: true,
                    visits: factor.visits.clone(),
                    rotations: factor.rotations,
                    sweeps: factor.sweeps,
                }),
        });
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_successful_subproblem(state: &SubproblemState) {
    record_face_pivot_capture(|capture| {
        capture
            .completed_subproblems
            .push(M1FacePivotSubproblemSummary {
                entered_factorizations: state.entered,
                completed_pivots: state.completed_pivots,
                completed_sweeps: state.completed_sweeps,
                refused: false,
            });
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_activation(
    state: &SubproblemState,
    solution: &FaceSolution,
    p_before: [f64; 21],
    p_candidate: [f64; 21],
    masks_before: ([bool; 21], [bool; 21], [bool; 21]),
    crossing: (f64, usize, bool),
    applied: bool,
) {
    if !m1_face_pivot_capture_enabled_for_test() {
        return;
    }
    let (crossing_theta, selected_coordinate, selected_lower) = crossing;
    let (lower_before, upper_before, free_before) = masks_before;
    capture_operation(
        state,
        M1FacePivotCaptureOperation {
            action: if applied { "activate" } else { "activate-cap" },
            p_before,
            p_candidate,
            conceptual_p_after: if applied { state.p } else { p_before },
            scratch_p_at_refusal: (!applied).then_some(p_candidate),
            applied,
            lower_before,
            upper_before,
            free_before,
            lower_after: [false; 21],
            upper_after: [false; 21],
            free_after: [false; 21],
            free_ids: solution.free_ids.clone(),
            radius: solution.radius,
            lambda: Some(solution.trace.lambda),
            weighted_residual: None,
            weighted_matrix: None,
            crossing_theta: Some(crossing_theta),
            selected_coordinate: Some(selected_coordinate),
            selected_lower: Some(selected_lower),
            residual: None,
            g: None,
            lambda_times_p: None,
            h: None,
            optimality: None,
            entered_factorizations: 0,
            completed_pivots: 0,
            completed_sweeps: 0,
        },
    );
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
struct ReleaseCapture<'a> {
    solution: &'a FaceSolution,
    prepared: &'a PreparedSubproblem,
    values: &'a KktValues,
    assessment: &'a OptimalityAssessment,
    p_before: [f64; 21],
    masks_before: ([bool; 21], [bool; 21], [bool; 21]),
    selected: (usize, bool),
    applied: bool,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_release(state: &SubproblemState, capture: &ReleaseCapture<'_>) {
    if !m1_face_pivot_capture_enabled_for_test() {
        return;
    }
    let (lower_before, upper_before, free_before) = capture.masks_before;
    let (selected_coordinate, selected_lower) = capture.selected;
    capture_operation(
        state,
        M1FacePivotCaptureOperation {
            action: if capture.applied {
                "release"
            } else {
                "release-cap"
            },
            p_before: capture.p_before,
            p_candidate: state.p,
            conceptual_p_after: capture.p_before,
            scratch_p_at_refusal: (!capture.applied).then_some(state.p),
            applied: capture.applied,
            lower_before,
            upper_before,
            free_before,
            lower_after: [false; 21],
            upper_after: [false; 21],
            free_after: [false; 21],
            free_ids: capture.solution.free_ids.clone(),
            radius: capture.solution.radius,
            lambda: Some(capture.solution.trace.lambda),
            weighted_residual: Some(
                capture
                    .prepared
                    .weighted_residual
                    .clone()
                    .try_into()
                    .expect("fixed KKT dimension"),
            ),
            weighted_matrix: Some(capture.prepared.weighted_matrix.clone()),
            crossing_theta: None,
            selected_coordinate: Some(selected_coordinate),
            selected_lower: Some(selected_lower),
            residual: Some(capture.values.residual),
            g: Some(capture.values.gradient),
            lambda_times_p: Some(capture.values.lambda_times_step),
            h: Some(capture.values.h),
            optimality: Some(capture.assessment.observation.clone()),
            entered_factorizations: 0,
            completed_pivots: 0,
            completed_sweeps: 0,
        },
    );
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_return(
    state: &SubproblemState,
    solution: &FaceSolution,
    prepared: &PreparedSubproblem,
    values: &KktValues,
    assessment: &OptimalityAssessment,
) {
    capture_operation(
        state,
        M1FacePivotCaptureOperation {
            action: "kkt-return",
            p_before: state.p,
            p_candidate: state.p,
            conceptual_p_after: state.p,
            scratch_p_at_refusal: None,
            applied: true,
            lower_before: state.lower_active,
            upper_before: state.upper_active,
            free_before: state.free,
            lower_after: [false; 21],
            upper_after: [false; 21],
            free_after: [false; 21],
            free_ids: solution.free_ids.clone(),
            radius: solution.radius,
            lambda: Some(solution.trace.lambda),
            weighted_residual: Some(
                prepared
                    .weighted_residual
                    .clone()
                    .try_into()
                    .expect("fixed KKT dimension"),
            ),
            weighted_matrix: Some(prepared.weighted_matrix.clone()),
            crossing_theta: None,
            selected_coordinate: None,
            selected_lower: None,
            residual: Some(values.residual),
            g: Some(values.gradient),
            lambda_times_p: Some(values.lambda_times_step),
            h: Some(values.h),
            optimality: Some(assessment.observation.clone()),
            entered_factorizations: 0,
            completed_pivots: 0,
            completed_sweeps: 0,
        },
    );
}

fn state_refusal(
    kind: M1TrustRegionRefusalKind,
    state: &SubproblemState,
    raw_max: f64,
) -> super::M1TrustRegionSubproblemRefusal {
    let mut refusal = subproblem_refusal(
        kind,
        1,
        state.completed_sweeps,
        state.completed_pivots,
        state.entered,
        raw_max,
    );
    refusal.work = Box::new(state_work_observation(state));
    refusal
}

fn state_work_observation(state: &SubproblemState) -> super::M1TrustRegionWorkObservation {
    super::M1TrustRegionWorkObservation {
        stage1_calls: 1,
        entered_svd_factorizations: u32::from(state.entered),
        completed_face_pivots: u32::from(state.completed_pivots),
        total_jacobi_sweeps: state.total_jacobi_sweeps,
        refinement_scalar_operations: state.refinement_work.scalar_operations,
        refinement_guard_events: state.refinement_work.guard_events,
        refinement_attempted_entries: u32::from(state.refinement_work.attempted_entries),
        refinement_denied_entries: u32::from(state.refinement_work.denied_entries),
        bvls04_positive_entries: state.refinement_work.bvls04_positive_entries,
        bvls04_factor_applications: state.refinement_work.bvls04_factor_applications,
        bvls04_dot2_residual_rows: state.refinement_work.bvls04_dot2_residual_rows,
        bvls04_dot2_free_gradients: state.refinement_work.bvls04_dot2_free_gradients,
        bvls04_ordered_norms: state.refinement_work.bvls04_ordered_norms,
        first_residual_operations: state.refinement_work.first_residual_operations,
        second_dot2_operations: state.refinement_work.second_dot2_operations,
        factor_application_operations: state.refinement_work.factor_application_operations,
        coordinate_update_operations: state.refinement_work.coordinate_update_operations,
        whole_kkt_operations: state.refinement_work.whole_kkt_operations,
        whole_kkt_guard_events: state.refinement_work.whole_kkt_guard_events,
        upward_enclosure_operations: state.refinement_work.upward_enclosure_operations,
        upward_enclosure_guard_events: state.refinement_work.upward_enclosure_guard_events,
        bvls05_role_joins_attempted: state.bvls05_work.bvls05_role_joins_attempted,
        bvls05_role_joins_completed: state.bvls05_work.bvls05_role_joins_completed,
        bvls05_column_entry_tests_attempted: state.bvls05_work.bvls05_column_entry_tests_attempted,
        bvls05_column_entry_tests_completed: state.bvls05_work.bvls05_column_entry_tests_completed,
        bvls05_mask_joins_attempted: state.bvls05_work.bvls05_mask_joins_attempted,
        bvls05_mask_joins_completed: state.bvls05_work.bvls05_mask_joins_completed,
        bvls05_held_base_copies_attempted: state.bvls05_work.bvls05_held_base_copies_attempted,
        bvls05_held_base_copies_completed: state.bvls05_work.bvls05_held_base_copies_completed,
    }
}

fn optimality_state_refusal(
    failure: OptimalityFailure,
    state: &SubproblemState,
    raw_max: f64,
    solution: &FaceSolution,
) -> super::M1TrustRegionSubproblemRefusal {
    let mut refusal = state_refusal(
        M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate,
        state,
        raw_max,
    );
    refusal.optimality_reason = Some(failure.reason);
    refusal.optimality_coordinate = Some(failure.coordinate);
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    {
        refusal.optimality_radius = Some(Box::new(solution.radius));
        refusal.optimality_lambda = Some(Box::new(solution.trace.lambda));
    }
    refusal
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn state_budget_refusal(
    state: &SubproblemState,
    raw_max: f64,
    budget_refusal: crate::M1PhysicalBudgetRefusal,
) -> super::M1TrustRegionSubproblemRefusal {
    let mut refusal = state_refusal(M1TrustRegionRefusalKind::WorkCap, state, raw_max);
    refusal.budget_refusal = Some(Box::new(budget_refusal));
    refusal
}

#[derive(Clone, Copy, Debug)]
struct OptimalityFailure {
    reason: &'static str,
    coordinate: usize,
}

struct KktAccounting<'a> {
    ledger: Option<&'a mut RefinementWorkLedger>,
    refined: bool,
}

impl<'a> KktAccounting<'a> {
    fn untracked() -> Self {
        Self {
            ledger: None,
            refined: false,
        }
    }

    fn tracked(ledger: &'a mut RefinementWorkLedger, refined: bool) -> Self {
        Self {
            ledger: Some(ledger),
            refined,
        }
    }

    fn kkt_operation(&mut self) {
        if let Some(ledger) = &mut self.ledger {
            ledger.whole_kkt_operations += 1;
            if self.refined {
                ledger.scalar();
            }
        }
    }

    fn kkt_admission(&mut self) {
        if let Some(ledger) = &mut self.ledger {
            ledger.whole_kkt_guard_events += 1;
            if self.refined {
                ledger.guard();
            }
        }
    }

    fn enclosure_operation(&mut self) {
        if let Some(ledger) = &mut self.ledger {
            ledger.upward_enclosure_operations += 1;
            if self.refined {
                ledger.scalar();
            }
        }
    }

    fn enclosure_admission(&mut self) {
        if let Some(ledger) = &mut self.ledger {
            ledger.upward_enclosure_guard_events += 1;
            if self.refined {
                ledger.guard();
            }
        }
    }
}

fn optimality_failure(reason: &'static str, coordinate: usize) -> OptimalityFailure {
    OptimalityFailure { reason, coordinate }
}

fn checked_optimality_operand(value: f64, coordinate: usize) -> Result<(), OptimalityFailure> {
    if !value.is_finite() {
        return Err(optimality_failure("optimality_nonfinite", coordinate));
    }
    if value != 0.0 && !value.is_normal() {
        return Err(optimality_failure(
            "optimality_non_normal_operand",
            coordinate,
        ));
    }
    Ok(())
}

fn checked_optimality_product(
    left: f64,
    right: f64,
    coordinate: usize,
    accounting: &mut KktAccounting<'_>,
) -> Result<f64, OptimalityFailure> {
    accounting.kkt_admission();
    checked_optimality_operand(left, coordinate)?;
    accounting.kkt_admission();
    checked_optimality_operand(right, coordinate)?;
    accounting.kkt_operation();
    let product = left * right;
    accounting.kkt_admission();
    if !product.is_finite() {
        return Err(optimality_failure("optimality_nonfinite", coordinate));
    }
    if product == 0.0 && left != 0.0 && right != 0.0 {
        return Err(optimality_failure(
            "optimality_underflow_to_zero",
            coordinate,
        ));
    }
    if product != 0.0 && !product.is_normal() {
        return Err(optimality_failure(
            "optimality_subnormal_intermediate",
            coordinate,
        ));
    }
    Ok(product)
}

fn checked_optimality_add(
    left: f64,
    right: f64,
    coordinate: usize,
    accounting: &mut KktAccounting<'_>,
) -> Result<f64, OptimalityFailure> {
    accounting.kkt_admission();
    checked_optimality_operand(left, coordinate)?;
    accounting.kkt_admission();
    checked_optimality_operand(right, coordinate)?;
    accounting.kkt_operation();
    let sum = left + right;
    accounting.kkt_admission();
    if !sum.is_finite() {
        return Err(optimality_failure("optimality_nonfinite", coordinate));
    }
    if sum == 0.0 && (left != 0.0 || right != 0.0) && left.to_bits() != (-right).to_bits() {
        return Err(optimality_failure("optimality_zero_addition", coordinate));
    }
    if sum != 0.0 && !sum.is_normal() {
        return Err(optimality_failure(
            "optimality_subnormal_intermediate",
            coordinate,
        ));
    }
    Ok(sum)
}

fn box_feasible_kkt_values(
    weighted_matrix: &[Vec<f64>],
    weighted_residual: &[f64],
    step: &[f64; 21],
    lambda: f64,
) -> Result<KktValues, OptimalityFailure> {
    let mut accounting = KktAccounting::untracked();
    box_feasible_kkt_values_with_accounting(
        weighted_matrix,
        weighted_residual,
        step,
        lambda,
        &mut accounting,
    )
}

fn box_feasible_kkt_values_with_accounting(
    weighted_matrix: &[Vec<f64>],
    weighted_residual: &[f64],
    step: &[f64; 21],
    lambda: f64,
    accounting: &mut KktAccounting<'_>,
) -> Result<KktValues, OptimalityFailure> {
    const N: usize = 21;
    accounting.kkt_admission();
    if lambda < 0.0 {
        return Err(optimality_failure("optimality_negative_lambda", 0));
    }
    checked_optimality_operand(lambda, 0)?;
    let mut residual = [0.0; N];
    let mut gradient = [0.0; N];
    let mut lambda_times_step = [0.0; N];
    let mut h = [0.0; N];
    for row in 0..N {
        let mut ap_sum = 0.0;
        for col in 0..N {
            let term =
                checked_optimality_product(weighted_matrix[row][col], step[col], col, accounting)?;
            ap_sum = checked_optimality_add(ap_sum, term, col, accounting)?;
        }
        residual[row] = checked_optimality_add(weighted_residual[row], ap_sum, row, accounting)?;
    }
    for col in 0..N {
        for row in 0..N {
            let term = checked_optimality_product(
                weighted_matrix[row][col],
                residual[row],
                col,
                accounting,
            )?;
            gradient[col] = checked_optimality_add(gradient[col], term, col, accounting)?;
        }
        lambda_times_step[col] = checked_optimality_product(lambda, step[col], col, accounting)?;
        h[col] = checked_optimality_add(gradient[col], lambda_times_step[col], col, accounting)?;
    }
    Ok(KktValues {
        residual,
        gradient,
        lambda_times_step,
        h,
    })
}

struct FacePreparation {
    radius: f64,
    free_ids: Vec<usize>,
    residual: [f64; 21],
    matrix: Vec<Vec<f64>>,
}

#[derive(Clone, Copy)]
struct FaceMaskContext<'a> {
    lower_active: &'a [bool; 21],
    upper_active: &'a [bool; 21],
    free: &'a [bool; 21],
    held: &'a [bool; 21],
}

fn prepare_face(
    initial_radius: f64,
    step: &[f64; 21],
    masks: FaceMaskContext<'_>,
    weighted_residual: &[f64],
    weighted_matrix: &[Vec<f64>],
) -> Result<FacePreparation, M1TrustRegionRefusalKind> {
    const N: usize = 21;
    let mut active_square_sum = 0.0;
    for (col, value) in step.iter().enumerate() {
        if masks.lower_active[col] || masks.upper_active[col] {
            let square = value * value;
            if !square.is_finite() {
                return Err(M1TrustRegionRefusalKind::SvdNonFinite);
            }
            active_square_sum += square;
            if !active_square_sum.is_finite() {
                return Err(M1TrustRegionRefusalKind::SvdNonFinite);
            }
        }
    }
    let r2 = initial_radius * initial_radius - active_square_sum;
    if !r2.is_finite()
        || r2 < 0.0
        || r2 == 0.0
        || !(0..N).any(|index| masks.free[index] && !masks.held[index])
    {
        return Err(M1TrustRegionRefusalKind::DegenerateFace);
    }
    let free_ids: Vec<usize> = (0..N)
        .filter(|&index| masks.free[index] && !masks.held[index])
        .collect();
    let mut residual = [0.0; N];
    for row in 0..N {
        let mut active_product_sum = 0.0;
        for col in 0..N {
            if masks.lower_active[col] || masks.upper_active[col] {
                let term = weighted_matrix[row][col] * step[col];
                if !term.is_finite() {
                    return Err(M1TrustRegionRefusalKind::SvdNonFinite);
                }
                active_product_sum += term;
                if !active_product_sum.is_finite() {
                    return Err(M1TrustRegionRefusalKind::SvdNonFinite);
                }
            }
        }
        residual[row] = weighted_residual[row] + active_product_sum;
        if !residual[row].is_finite() {
            return Err(M1TrustRegionRefusalKind::SvdNonFinite);
        }
    }
    let matrix = (0..N)
        .map(|row| {
            free_ids
                .iter()
                .map(|&col| weighted_matrix[row][col])
                .collect()
        })
        .collect();
    Ok(FacePreparation {
        radius: r2.sqrt(),
        free_ids,
        residual,
        matrix,
    })
}

fn first_crossing(
    step: &[f64; 21],
    previous_step: &[f64; 21],
    free_ids: &[usize],
    lower: &[f64; 21],
    upper: &[f64; 21],
) -> Result<Option<(f64, usize, bool)>, M1TrustRegionRefusalKind> {
    let mut crossing = None;
    for &col in free_ids {
        let bound = if step[col] < lower[col] {
            Some((lower[col], true))
        } else if step[col] > upper[col] {
            Some((upper[col], false))
        } else {
            None
        };
        if let Some((bound, is_lower)) = bound {
            let theta = (bound - previous_step[col]) / (step[col] - previous_step[col]);
            if !theta.is_finite() || !(0.0..=1.0).contains(&theta) {
                return Err(M1TrustRegionRefusalKind::SvdNonFinite);
            }
            if crossing.is_none_or(|(best, index, _)| {
                theta < best || (theta.partial_cmp(&best) == Some(Ordering::Equal) && col < index)
            }) {
                crossing = Some((theta, col, is_lower));
            }
        }
    }
    Ok(crossing)
}

fn upward_operand_with_accounting(
    value: f64,
    coordinate: usize,
    accounting: &mut KktAccounting<'_>,
) -> Result<f64, OptimalityFailure> {
    accounting.enclosure_admission();
    checked_optimality_operand(value, coordinate)?;
    let magnitude = value.abs();
    if !magnitude.is_finite() || (magnitude != 0.0 && !magnitude.is_normal()) {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    Ok(magnitude)
}

fn upward_mul(
    left: f64,
    right: f64,
    coordinate: usize,
    operations: &mut u16,
) -> Result<f64, OptimalityFailure> {
    let mut accounting = KktAccounting::untracked();
    upward_mul_with_accounting(left, right, coordinate, operations, &mut accounting)
}

fn upward_mul_with_accounting(
    left: f64,
    right: f64,
    coordinate: usize,
    operations: &mut u16,
    accounting: &mut KktAccounting<'_>,
) -> Result<f64, OptimalityFailure> {
    if left < 0.0 || right < 0.0 {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    let left = upward_operand_with_accounting(left, coordinate, accounting)?;
    let right = upward_operand_with_accounting(right, coordinate, accounting)?;
    if left == 0.0 || right == 0.0 {
        return Ok(0.0);
    }
    *operations += 1;
    accounting.enclosure_operation();
    let product = left * right;
    accounting.enclosure_admission();
    if !product.is_finite() {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    if product == 0.0 {
        return Err(optimality_failure(
            "optimality_underflow_to_zero",
            coordinate,
        ));
    }
    if !product.is_normal() {
        return Err(optimality_failure(
            "optimality_subnormal_intermediate",
            coordinate,
        ));
    }
    *operations += 1;
    accounting.enclosure_operation();
    let upward = product.next_up();
    accounting.enclosure_admission();
    if !upward.is_finite() || !upward.is_normal() {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    Ok(upward)
}

fn upward_add_with_accounting(
    left: f64,
    right: f64,
    coordinate: usize,
    operations: &mut u16,
    accounting: &mut KktAccounting<'_>,
) -> Result<f64, OptimalityFailure> {
    if left < 0.0 || right < 0.0 {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    let left = upward_operand_with_accounting(left, coordinate, accounting)?;
    let right = upward_operand_with_accounting(right, coordinate, accounting)?;
    if right == 0.0 {
        return Ok(left);
    }
    *operations += 1;
    accounting.enclosure_operation();
    let sum = left + right;
    accounting.enclosure_admission();
    if !sum.is_finite() || sum == 0.0 {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    if !sum.is_normal() {
        return Err(optimality_failure(
            "optimality_subnormal_intermediate",
            coordinate,
        ));
    }
    *operations += 1;
    accounting.enclosure_operation();
    let upward = sum.next_up();
    accounting.enclosure_admission();
    if !upward.is_finite() || !upward.is_normal() {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    Ok(upward)
}

fn cbar_and_tau(
    weighted_matrix: &[Vec<f64>],
    weighted_residual: &[f64],
    step: &[f64; 21],
    lambda: f64,
    coordinate: usize,
    operations: &mut u16,
    accounting: &mut KktAccounting<'_>,
) -> Result<(f64, f64), OptimalityFailure> {
    let mut cbar = 0.0;
    for row in 0..21 {
        let mut inner = 0.0;
        for column in 0..21 {
            let term = upward_mul_with_accounting(
                upward_operand_with_accounting(
                    weighted_matrix[row][column],
                    coordinate,
                    accounting,
                )?,
                upward_operand_with_accounting(step[column], coordinate, accounting)?,
                coordinate,
                operations,
                accounting,
            )?;
            inner = upward_add_with_accounting(inner, term, coordinate, operations, accounting)?;
        }
        let row_scale = upward_add_with_accounting(
            upward_operand_with_accounting(weighted_residual[row], coordinate, accounting)?,
            inner,
            coordinate,
            operations,
            accounting,
        )?;
        let row_term = upward_mul_with_accounting(
            upward_operand_with_accounting(
                weighted_matrix[row][coordinate],
                coordinate,
                accounting,
            )?,
            row_scale,
            coordinate,
            operations,
            accounting,
        )?;
        cbar = upward_add_with_accounting(cbar, row_term, coordinate, operations, accounting)?;
    }
    let lambda_term = upward_mul_with_accounting(
        upward_operand_with_accounting(lambda, coordinate, accounting)?,
        upward_operand_with_accounting(step[coordinate], coordinate, accounting)?,
        coordinate,
        operations,
        accounting,
    )?;
    cbar = upward_add_with_accounting(cbar, lambda_term, coordinate, operations, accounting)?;
    if cbar == 0.0 {
        return Ok((0.0, 0.0));
    }
    let gamma = (87.0 / (TWO_POW_53 - 87.0)).next_up();
    accounting.enclosure_admission();
    if !gamma.is_finite() || !gamma.is_normal() {
        return Err(optimality_failure(
            "optimality_upward_enclosure",
            coordinate,
        ));
    }
    let tau = upward_mul_with_accounting(gamma, cbar, coordinate, operations, accounting)?;
    Ok((cbar, tau))
}

struct OptimalityAssessment {
    observation: super::M1TrustRegionOptimalityObservation,
    release: Option<(usize, bool)>,
    free_refusal: Option<usize>,
}

struct KktTransitionOutcome {
    values: Option<KktValues>,
    observation: super::M1TrustRegionOptimalityObservation,
}

#[derive(Clone, Copy)]
struct OptimalityMasks<'a> {
    lower_active: &'a [bool; 21],
    upper_active: &'a [bool; 21],
    initial_free: &'a [bool; 21],
}

fn select_optimality_release(
    candidates: &mut [(usize, bool, Option<f64>)],
) -> Option<super::M1TrustRegionOptimalityReleaseObservation> {
    candidates.sort_by(|left, right| match (left.2, right.2) {
        (None, None) => left.0.cmp(&right.0),
        (None, Some(_)) => Ordering::Less,
        (Some(_), None) => Ordering::Greater,
        (Some(left_ratio), Some(right_ratio)) => right_ratio
            .total_cmp(&left_ratio)
            .then_with(|| left.0.cmp(&right.0)),
    });
    candidates.first().map(|(coordinate, lower, ratio)| {
        let tied_coordinates = candidates
            .iter()
            .filter(|(_, _, candidate_ratio)| candidate_ratio == ratio)
            .fold(0_u8, |count, _| count + 1);
        super::M1TrustRegionOptimalityReleaseObservation {
            coordinate: *coordinate,
            lower: *lower,
            ratio: *ratio,
            tied_coordinates,
        }
    })
}

fn assess_optimality(
    prepared: &PreparedSubproblem,
    p: &[f64; 21],
    masks: OptimalityMasks<'_>,
    values: &KktValues,
    lambda: f64,
    accounting: &mut KktAccounting<'_>,
) -> Result<OptimalityAssessment, OptimalityFailure> {
    let mut operations = 0;
    let mut coordinates = Vec::with_capacity(21);
    let mut candidates: Vec<(usize, bool, Option<f64>)> = Vec::new();
    let mut free_refusal = None;
    for coordinate in 0..21 {
        let (cbar, tau) = cbar_and_tau(
            &prepared.weighted_matrix,
            &prepared.weighted_residual,
            p,
            lambda,
            coordinate,
            &mut operations,
            accounting,
        )?;
        let h = values.h[coordinate];
        accounting.kkt_admission();
        checked_optimality_operand(h, coordinate)?;
        let fixed = !masks.initial_free[coordinate];
        let class = if fixed {
            super::M1TrustRegionOptimalityClass::Fixed
        } else if masks.lower_active[coordinate] {
            if h < -tau {
                let ratio = if tau == 0.0 {
                    None
                } else {
                    let ratio = h.abs() / tau;
                    accounting.kkt_admission();
                    if !ratio.is_finite() || !ratio.is_normal() {
                        return Err(optimality_failure("optimality_release_ratio", coordinate));
                    }
                    Some(ratio)
                };
                candidates.push((coordinate, true, ratio));
                super::M1TrustRegionOptimalityClass::ReleaseLower
            } else {
                super::M1TrustRegionOptimalityClass::RetainLower
            }
        } else if masks.upper_active[coordinate] {
            if h > tau {
                let ratio = if tau == 0.0 {
                    None
                } else {
                    let ratio = h.abs() / tau;
                    accounting.kkt_admission();
                    if !ratio.is_finite() || !ratio.is_normal() {
                        return Err(optimality_failure("optimality_release_ratio", coordinate));
                    }
                    Some(ratio)
                };
                candidates.push((coordinate, false, ratio));
                super::M1TrustRegionOptimalityClass::ReleaseUpper
            } else {
                super::M1TrustRegionOptimalityClass::RetainUpper
            }
        } else if h.abs() <= tau {
            super::M1TrustRegionOptimalityClass::FreePass
        } else {
            free_refusal.get_or_insert(coordinate);
            super::M1TrustRegionOptimalityClass::FreeRefuse
        };
        if cbar == 0.0 && h != 0.0 {
            return Err(optimality_failure(
                "optimality_free_stationarity",
                coordinate,
            ));
        }
        coordinates.push(super::M1TrustRegionOptimalityCoordinateObservation {
            coordinate,
            h,
            cbar,
            tau,
            class,
        });
    }
    let selected_release = select_optimality_release(&mut candidates);
    Ok(OptimalityAssessment {
        release: selected_release.map(|selected| (selected.coordinate, selected.lower)),
        free_refusal: selected_release.is_none().then_some(free_refusal).flatten(),
        observation: super::M1TrustRegionOptimalityObservation {
            coordinates,
            selected_release,
            scalar_operations: operations,
        },
    })
}

fn prepare_subproblem(
    input: &super::M1TrustRegionSubproblemInput,
) -> Result<PreparedSubproblem, Box<super::M1TrustRegionSubproblemRefusal>> {
    const N: usize = 21;
    let mut raw_max = 0.0_f64;
    for row in 0..N {
        raw_max = raw_max.max(input.raw_residual[row].abs());
        if !input.raw_residual[row].is_finite()
            || !input.normalizers[row].is_finite()
            || input.normalizers[row] <= 0.0
            || !input.base[row].is_finite()
            || !input.scales[row].is_finite()
            || input.scales[row] <= 0.0
            || input.lower[row].is_nan()
            || input.upper[row].is_nan()
            || input.lower[row] > input.upper[row]
            || input.base[row] < input.lower[row]
            || input.base[row] > input.upper[row]
        {
            return Err(Box::new(subproblem_refusal(
                M1TrustRegionRefusalKind::SvdNonFinite,
                1,
                input.test_work.completed_jacobi_sweeps,
                input.test_work.completed_face_pivots,
                0,
                raw_max,
            )));
        }
    }
    if !input.initial_radius.is_finite() || input.initial_radius <= 0.0 {
        return Err(Box::new(subproblem_refusal(
            M1TrustRegionRefusalKind::DegenerateFace,
            1,
            input.test_work.completed_jacobi_sweeps,
            input.test_work.completed_face_pivots,
            0,
            raw_max,
        )));
    }
    let rows: Vec<&[f64]> = input.raw_jacobian.iter().map(|row| &row[..]).collect();
    let (weighted_residual, weighted_matrix) = weighted_system(
        &input.raw_residual,
        &rows,
        &input.normalizers,
        &input.scales,
    )
    .map_err(|_| {
        Box::new(subproblem_refusal(
            M1TrustRegionRefusalKind::SvdNonFinite,
            1,
            input.test_work.completed_jacobi_sweeps,
            input.test_work.completed_face_pivots,
            0,
            raw_max,
        ))
    })?;
    let mut scaled_lower = [0.0; N];
    let mut scaled_upper = [0.0; N];
    for col in 0..N {
        scaled_lower[col] = (input.lower[col] - input.base[col]) / input.scales[col];
        scaled_upper[col] = (input.upper[col] - input.base[col]) / input.scales[col];
        if scaled_lower[col].is_nan()
            || scaled_upper[col].is_nan()
            || scaled_lower[col] > scaled_upper[col]
            || (input.lower[col].is_finite() && !scaled_lower[col].is_finite())
            || (input.upper[col].is_finite() && !scaled_upper[col].is_finite())
        {
            return Err(Box::new(subproblem_refusal(
                M1TrustRegionRefusalKind::SvdNonFinite,
                1,
                input.test_work.completed_jacobi_sweeps,
                input.test_work.completed_face_pivots,
                0,
                raw_max,
            )));
        }
    }
    Ok(PreparedSubproblem {
        raw_max,
        weighted_residual,
        weighted_matrix,
        scaled_lower,
        scaled_upper,
    })
}

fn candidate_coordinates(
    input: &super::M1TrustRegionSubproblemInput,
    step: &[f64; 21],
) -> Option<[f64; 21]> {
    let mut candidate = [0.0; 21];
    for col in 0..21 {
        candidate[col] = input.base[col] + input.scales[col] * step[col];
        if !candidate[col].is_finite() {
            return None;
        }
    }
    Some(candidate)
}

fn raw_jacobian_columns(input: &super::M1TrustRegionSubproblemInput) -> [[f64; 21]; 21] {
    let mut columns = [[0.0; 21]; 21];
    for (col, column) in columns.iter_mut().enumerate() {
        for (row, entry) in column.iter_mut().enumerate() {
            *entry = input.raw_jacobian[row][col];
        }
    }
    columns
}

// BVLS-05 test-build numerical ownership.  The certificate derives a stable
// held set from already assembled operands and is admitted by the owning solve
// path; controls may inspect that same admission before factorization.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Bvls05Role {
    SunLeaf,
    ShadeLeaf,
    DryStem,
    Other,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct Bvls05RoleInput {
    role: Bvls05Role,
    column: usize,
    structural_area: f64,
    wet_fraction: f64,
    initial_free: bool,
    physical_current_free: bool,
}

#[cfg(test)]
#[derive(Clone, Debug, Default)]
struct Bvls05CertificateObservation {
    held: [bool; 21],
    work: super::M1TrustRegionWorkObservation,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
pub(crate) struct M1TrustRegionBvls05Certificate {
    held: [bool; 21],
}

/// Bounded test-only view of the actual admitted assembly.  It is constructed
/// by the same preparation and certificate admission path as the solver, but
/// deliberately stops before factorization and proposal construction.
#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug)]
pub(crate) struct M1TrustRegionBvls05AssemblyInspection {
    pub(crate) provenance: Option<super::M1TrustRegionBvls05TestProvenance>,
    pub(crate) held: [bool; 21],
    pub(crate) retained_free_ids: Vec<usize>,
    pub(crate) weighted_residual: Vec<f64>,
    pub(crate) weighted_matrix: Vec<Vec<f64>>,
    pub(crate) input: super::M1TrustRegionSubproblemInput,
    pub(crate) work: super::M1TrustRegionWorkObservation,
}

#[cfg(test)]
fn bvls05_certificate_for_test(
    roles: &[Bvls05RoleInput],
    raw: &[[f64; 21]; 21],
    weighted: &[Vec<f64>],
) -> Bvls05CertificateObservation {
    let mut observed = Bvls05CertificateObservation::default();
    for input in roles {
        observed.work.bvls05_role_joins_attempted += 1;
        observed.work.bvls05_role_joins_completed += 1;
        let dry_temperature = matches!(
            input.role,
            Bvls05Role::SunLeaf | Bvls05Role::ShadeLeaf | Bvls05Role::DryStem
        );
        let effective_dry_area = input.structural_area * (1.0 - input.wet_fraction);
        let eligible_prefix = dry_temperature
            && input.structural_area.is_finite()
            && input.structural_area > 0.0
            && input.wet_fraction.to_bits() == 1.0_f64.to_bits()
            && effective_dry_area == 0.0
            && input.initial_free
            && input.physical_current_free;
        let mut zero = true;
        for (row, raw_row) in raw.iter().enumerate() {
            observed.work.bvls05_column_entry_tests_attempted += 2;
            let Some(weighted_entry) = weighted
                .get(row)
                .and_then(|values| values.get(input.column))
            else {
                zero = false;
                break;
            };
            if raw_row[input.column] != 0.0 || *weighted_entry != 0.0 {
                zero = false;
            }
            observed.work.bvls05_column_entry_tests_completed += 2;
        }
        if eligible_prefix && input.column < 21 && weighted.len() == 21 && zero {
            observed.held[input.column] = true;
        }
    }
    // No provenance takes the default-empty shortcut with no BVLS-05 work.
    // An inspected certificate joins its completed held set to all face slots.
    if !roles.is_empty() {
        observed.work.bvls05_mask_joins_attempted = 21;
        observed.work.bvls05_mask_joins_completed = 21;
    }
    observed
}

#[cfg(test)]
fn bvls05_admit_for_input(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &SubproblemState,
) -> Bvls05CertificateObservation {
    let Some(provenance) = input.test_work.bvls05_provenance else {
        return Bvls05CertificateObservation::default();
    };
    let kinds = [
        Bvls05Role::SunLeaf,
        Bvls05Role::ShadeLeaf,
        Bvls05Role::DryStem,
        Bvls05Role::SunLeaf,
        Bvls05Role::ShadeLeaf,
        Bvls05Role::DryStem,
    ];
    let roles: [Bvls05RoleInput; 6] = std::array::from_fn(|slot| {
        let column = provenance.role_columns[slot];
        Bvls05RoleInput {
            role: kinds[slot],
            column,
            structural_area: provenance.structural_areas[slot],
            wet_fraction: provenance.wet_fractions[slot],
            // State masks retain ordinary face semantics.  Provenance is the
            // independent physical-Jx/Jy certificate conjunction supplied by
            // the adapter, and must also pass before BVLS admission.
            initial_free: state.initial_free[column] && provenance.initial_free[slot],
            physical_current_free: state.free[column] && provenance.physical_current_free[slot],
        }
    });
    bvls05_certificate_for_test(&roles, &input.raw_jacobian, &prepared.weighted_matrix)
}

#[cfg(test)]
fn bvls05_scatter_held(
    base: [f64; 21],
    held: [bool; 21],
    mut step: [f64; 21],
    mut candidate: [f64; 21],
    work: &mut super::M1TrustRegionWorkObservation,
) -> ([f64; 21], [f64; 21]) {
    for coordinate in 0..21 {
        if held[coordinate] {
            work.bvls05_held_base_copies_attempted += 1;
            step[coordinate] = 0.0;
            candidate[coordinate] = base[coordinate];
            work.bvls05_held_base_copies_completed += 1;
        }
    }
    (step, candidate)
}

#[cfg(test)]
fn bvls05_admit_state(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    certificate_cache: &mut Option<M1TrustRegionBvls05Certificate>,
) {
    if input.test_work.bvls05_provenance.is_none() {
        return;
    }
    if let Some(certificate) = *certificate_cache {
        state.held = certificate.held;
        state.bvls05_inspected = true;
        return;
    }
    let certificate = bvls05_admit_for_input(input, prepared, state);
    state.held = certificate.held;
    state.bvls05_work = certificate.work;
    state.bvls05_inspected = true;
    // Certificate admission does not itself enter a face; each actual face
    // charges its own full-coordinate mask join in solve_face.
    state.bvls05_work.bvls05_mask_joins_attempted = 0;
    state.bvls05_work.bvls05_mask_joins_completed = 0;
    *certificate_cache = Some(M1TrustRegionBvls05Certificate {
        held: certificate.held,
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn capture_bvls05_admission(
    input: &super::M1TrustRegionSubproblemInput,
    state: &SubproblemState,
    reused: bool,
) {
    if !state.bvls05_inspected {
        return;
    }
    record_face_pivot_capture(|capture| {
        capture.bvls05_lifecycle.push(M1FacePivotBvls05Capture {
            provenance: input.test_work.bvls05_provenance,
            held: state.held,
            reused,
            free_ids: (0..21)
                .filter(|&coordinate| state.free[coordinate] && !state.held[coordinate])
                .collect(),
            work: state.bvls05_work.clone(),
        });
    });
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
pub(crate) fn inspect_bvls05_assembly_with_certificate(
    input: &super::M1TrustRegionSubproblemInput,
    certificate_cache: &mut Option<M1TrustRegionBvls05Certificate>,
) -> Result<M1TrustRegionBvls05AssemblyInspection, super::M1TrustRegionSubproblemRefusal> {
    let prepared = prepare_subproblem(input).map_err(|refusal| *refusal)?;
    let mut state = SubproblemState::new(input);
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let bvls05_reused = certificate_cache.is_some();
    bvls05_admit_state(input, &prepared, &mut state, certificate_cache);
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    capture_bvls05_admission(input, &state, bvls05_reused);
    if state.bvls05_inspected {
        // Inspection constructs the same retained free-coordinate face view as
        // an entered solve face, so it owns one full-coordinate mask join.
        state.bvls05_work.bvls05_mask_joins_attempted += 21;
        state.bvls05_work.bvls05_mask_joins_completed += 21;
    }
    Ok(M1TrustRegionBvls05AssemblyInspection {
        provenance: input.test_work.bvls05_provenance,
        held: state.held,
        retained_free_ids: (0..21)
            .filter(|&coordinate| state.free[coordinate] && !state.held[coordinate])
            .collect(),
        weighted_residual: prepared.weighted_residual,
        weighted_matrix: prepared.weighted_matrix,
        input: input.clone(),
        work: state.bvls05_work,
    })
}

struct FaceSolution {
    free_ids: Vec<usize>,
    trace: LambdaTrace,
    refined: bool,
    // BVLS-03 applies its two corrections through the exact factor already
    // constructed for this face.  Keeping ownership here prevents a second
    // factorization or a numerically distinct reconstruction.
    factor: Option<JacobiFactor>,
    radius: f64,
}

fn solve_face(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
) -> Result<FaceSolution, super::M1TrustRegionSubproblemRefusal> {
    if state.bvls05_inspected {
        state.bvls05_work.bvls05_mask_joins_attempted += 21;
        state.bvls05_work.bvls05_mask_joins_completed += 21;
    }
    let face = prepare_face(
        input.initial_radius,
        &state.p,
        FaceMaskContext {
            lower_active: &state.lower_active,
            upper_active: &state.upper_active,
            free: &state.free,
            held: &state.held,
        },
        &prepared.weighted_residual,
        &prepared.weighted_matrix,
    )
    .map_err(|kind| state_refusal(kind, state, prepared.raw_max))?;
    state.last_face_radius = Some(face.radius);
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    if let Err(budget_refusal) =
        crate::m1_physical_budget_enter(crate::M1PhysicalBudgetOperation::Stage1Factorization)
    {
        return Err(state_budget_refusal(
            state,
            prepared.raw_max,
            budget_refusal,
        ));
    }
    state.entered += 1;
    let factor_result = jacobi_factor(
        face.matrix,
        &face.free_ids,
        input.test_work.completed_jacobi_sweeps,
        &mut state.completed_sweeps,
    );
    let sweeps_added = state
        .completed_sweeps
        .checked_sub(input.test_work.completed_jacobi_sweeps)
        .ok_or_else(|| {
            state_refusal(
                M1TrustRegionRefusalKind::SvdNoConvergence,
                state,
                prepared.raw_max,
            )
        })?;
    state.total_jacobi_sweeps += u32::from(sweeps_added);
    let factor = match factor_result {
        Ok(value) => value,
        Err("rank deficient") => {
            return Err(state_refusal(
                M1TrustRegionRefusalKind::RankDeficient,
                state,
                prepared.raw_max,
            ));
        }
        Err("no convergence") => {
            return Err(state_refusal(
                M1TrustRegionRefusalKind::SvdNoConvergence,
                state,
                prepared.raw_max,
            ));
        }
        Err(_) => {
            return Err(state_refusal(
                M1TrustRegionRefusalKind::SvdNonFinite,
                state,
                prepared.raw_max,
            ));
        }
    };
    state.completed_sweeps = state.completed_sweeps.max(factor.sweeps);
    let mut trace = LambdaTrace::default();
    svd_lambda_ball(&factor, &face.residual, face.radius, None, &mut trace)
        .map_err(|kind| state_refusal(kind, state, prepared.raw_max))?;
    Ok(FaceSolution {
        free_ids: face.free_ids,
        trace,
        refined: false,
        factor: Some(factor),
        radius: face.radius,
    })
}

// The BVLS-03 retained controls carry source operands as hexadecimal binary64
// JSON.  Decode only those operands here, then hand the resulting state to the
// ordinary preparation/factorization path.  This is a test-only custody seam:
// expected Dot2 or KKT results never enter it.
#[cfg(test)]
fn refinement_capture_bit(value: &serde_json::Value) -> Result<f64, String> {
    let text = value
        .as_str()
        .ok_or_else(|| "refinement capture bit is not a string".to_owned())?;
    u64::from_str_radix(text, 16)
        .map(f64::from_bits)
        .map_err(|_| "refinement capture bit is not hexadecimal".to_owned())
}

#[cfg(test)]
fn refinement_capture_vector(value: &serde_json::Value) -> Result<[f64; 21], String> {
    let values = value
        .as_array()
        .ok_or_else(|| "refinement capture vector is not an array".to_owned())?;
    if values.len() != 21 {
        return Err("refinement capture vector has wrong dimension".to_owned());
    }
    let mut result = [0.0; 21];
    for (index, entry) in values.iter().enumerate() {
        result[index] = refinement_capture_bit(entry)?;
    }
    Ok(result)
}

#[cfg(test)]
fn refinement_capture_mask(value: &serde_json::Value) -> Result<[bool; 21], String> {
    let values = value
        .as_array()
        .ok_or_else(|| "refinement capture mask is not an array".to_owned())?;
    if values.len() != 21 {
        return Err("refinement capture mask has wrong dimension".to_owned());
    }
    let mut result = [false; 21];
    for (index, entry) in values.iter().enumerate() {
        result[index] = entry
            .as_bool()
            .ok_or_else(|| "refinement capture mask is not boolean".to_owned())?;
    }
    Ok(result)
}

#[cfg(test)]
fn refinement_capture_matrix(value: &serde_json::Value) -> Result<[[f64; 21]; 21], String> {
    let rows = value
        .as_array()
        .ok_or_else(|| "refinement capture matrix is not an array".to_owned())?;
    if rows.len() != 21 {
        return Err("refinement capture matrix has wrong row count".to_owned());
    }
    let mut result = [[0.0; 21]; 21];
    for (row, values) in rows.iter().enumerate() {
        result[row] = refinement_capture_vector(values)?;
    }
    Ok(result)
}

#[cfg(test)]
fn refinement_capture_operation(capture: &serde_json::Value) -> Result<&serde_json::Value, String> {
    capture["operations"]
        .as_array()
        .and_then(|operations| operations.get(1))
        .ok_or_else(|| "refinement capture lacks operation 1".to_owned())
}

#[cfg(test)]
fn refinement_decode_captured_face(
    capture: &serde_json::Value,
) -> Result<
    (
        super::M1TrustRegionSubproblemInput,
        PreparedSubproblem,
        SubproblemState,
    ),
    String,
> {
    let input = super::M1TrustRegionSubproblemInput {
        raw_residual: refinement_capture_vector(&capture["raw_residual"])?,
        raw_jacobian: refinement_capture_matrix(&capture["raw_jacobian"])?,
        normalizers: refinement_capture_vector(&capture["normalizers"])?,
        scales: refinement_capture_vector(&capture["scales"])?,
        lower: refinement_capture_vector(&capture["lower"])?,
        upper: refinement_capture_vector(&capture["upper"])?,
        initial_radius: refinement_capture_bit(&capture["initial_radius"])?,
        base: refinement_capture_vector(&capture["base"])?,
        test_work: super::M1TrustRegionTestWorkState::default(),
    };
    let prepared = prepare_subproblem(&input)
        .map_err(|_| "refinement capture preparation refused".to_owned())?;
    let operation = refinement_capture_operation(capture)?;
    let mut state = SubproblemState::new(&input);
    state.p = refinement_capture_vector(&operation["p_before"])?;
    state.lower_active = refinement_capture_mask(&operation["lower_before"])?;
    state.upper_active = refinement_capture_mask(&operation["upper_before"])?;
    state.free = refinement_capture_mask(&operation["free_before"])?;
    if !(0..21).all(|column| {
        usize::from(state.lower_active[column])
            + usize::from(state.upper_active[column])
            + usize::from(state.free[column])
            == 1
    }) {
        return Err("refinement capture active/free partition is incomplete".to_owned());
    }
    Ok((input, prepared, state))
}

#[cfg(test)]
fn refinement_solve_captured_face(
    capture: &serde_json::Value,
) -> Result<
    (
        super::M1TrustRegionSubproblemInput,
        PreparedSubproblem,
        SubproblemState,
        FaceSolution,
    ),
    String,
> {
    let (input, prepared, mut state) = refinement_decode_captured_face(capture)?;
    let solution = solve_face(&input, &prepared, &mut state)
        .map_err(|_| "refinement capture face solve refused".to_owned())?;
    Ok((input, prepared, state, solution))
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct RefinementWorkReservation {
    remaining_scalar_operations: u64,
    remaining_guard_events: u64,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementRetainedFaceObservation {
    lambda_bits: u64,
    live_state_bits_entry: [u64; 21],
    live_state_bits_exit: [u64; 21],
    p0_bits: Vec<u64>,
    delta0_free_bits: Vec<u64>,
    p1_bits: Vec<u64>,
    dot2_residual_bits: Vec<u64>,
    delta1_free_bits: Vec<u64>,
    p2_bits: Vec<u64>,
    r0_bits: Vec<u64>,
    residual1_bits: Vec<u64>,
    final_residual_bits: Option<Vec<u64>>,
    final_gradient_bits: Option<Vec<u64>>,
    final_lambda_p_bits: Option<Vec<u64>>,
    h0_free_bits: Option<Vec<u64>>,
    h1_free_bits: Option<Vec<u64>>,
    p0_full_norm2_bits: Option<u64>,
    p0_full_norm_bits: Option<u64>,
    p0_reduced_norm2_bits: Option<u64>,
    p0_reduced_norm_bits: Option<u64>,
    p1_full_norm2_bits: Option<u64>,
    p1_full_norm_bits: Option<u64>,
    p1_reduced_norm2_bits: Option<u64>,
    p1_reduced_norm_bits: Option<u64>,
    p2_full_norm2_bits: Option<u64>,
    p2_full_norm_bits: Option<u64>,
    p2_reduced_norm2_bits: Option<u64>,
    p2_reduced_norm_bits: Option<u64>,
    original_radius_bits: u64,
    remaining_radius_bits: Option<u64>,
    radius_gap_bits: Option<u64>,
    radius_tolerance_bits: Option<u64>,
    factor_applications: u8,
    active_coordinate: usize,
    h_bits: Vec<u64>,
    cbar_bits: Vec<u64>,
    tau_bits: Vec<u64>,
    classes: Vec<String>,
    box_feasible: bool,
    ball_feasible: bool,
    factorizations_added: u8,
    factor_application_count: u8,
    factor_identity_before: usize,
    factor_identity_after: usize,
    factor_application_identities: Vec<usize>,
    lower_mask_p0: Vec<bool>,
    upper_mask_p0: Vec<bool>,
    lower_mask_p1: Vec<bool>,
    upper_mask_p1: Vec<bool>,
    lower_mask_p2: Vec<bool>,
    upper_mask_p2: Vec<bool>,
    lower_mask_exit: Vec<bool>,
    upper_mask_exit: Vec<bool>,
    corrections: u8,
    bvls02_pass: bool,
    bvls04_entries: u32,
    refinement_attempted_entries: u32,
    refinement_scalar_operations: u64,
    full_work: super::M1TrustRegionWorkObservation,
    first_residual_operations: u64,
    second_dot2_operations: u64,
    factor_application_operations: u64,
    coordinate_update_operations: u64,
    whole_kkt_operations: u64,
    whole_kkt_guard_events: u64,
    upward_enclosure_operations: u64,
    upward_enclosure_guard_events: u64,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_before: Option<crate::M1PhysicalBudgetSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_after: Option<crate::M1PhysicalBudgetSnapshot>,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementObservationRefusal {
    p1_reduced_norm_bits: Option<u64>,
    p2_reduced_norm_bits: Option<u64>,
    reason: &'static str,
    refinement: Option<Box<super::M1TrustRegionRefinementFailureMetadata>>,
    work: Box<super::M1TrustRegionWorkObservation>,
    returned_step: Option<[f64; 21]>,
    bvls02_fallback_calls: u8,
    materialization_calls: u8,
    physical_evaluator_calls: u8,
    hook_log: Vec<&'static str>,
    owner_snapshot_before: [u64; 21],
    owner_snapshot_after: [u64; 21],
    live_state_bits_before: [u64; 21],
    live_state_bits_after: [u64; 21],
    required_scalar_operations: u64,
    required_guard_events: u64,
    attempted_entries_before: u16,
    attempted_entries_after: u16,
    denied_entries_before: u16,
    denied_entries_after: u16,
    corrections: u8,
    dot2_operations: u64,
    factor_applications: u8,
    denied_entry_executed_scalar_operations: u64,
    denied_entry_executed_guard_events: u64,
    prior_eligibility_scalar_operations: u64,
    prior_eligibility_guard_events: u64,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    global_before: Option<RefinementScratchGlobalSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    global_after: Option<RefinementScratchGlobalSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_before: Option<crate::M1PhysicalBudgetSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_after: Option<crate::M1PhysicalBudgetSnapshot>,
}

#[cfg(test)]
fn refinement_class_name(class: super::M1TrustRegionOptimalityClass) -> &'static str {
    match class {
        super::M1TrustRegionOptimalityClass::Fixed => "fixed",
        super::M1TrustRegionOptimalityClass::ReleaseLower => "release_lower",
        super::M1TrustRegionOptimalityClass::RetainLower => "retain_lower",
        super::M1TrustRegionOptimalityClass::ReleaseUpper => "release_upper",
        super::M1TrustRegionOptimalityClass::RetainUpper => "retain_upper",
        super::M1TrustRegionOptimalityClass::FreePass => "free_pass",
        super::M1TrustRegionOptimalityClass::FreeRefuse => "free_refuse",
    }
}

#[cfg(test)]
fn refinement_observation_refusal(
    reason: &'static str,
    state: &SubproblemState,
) -> Box<RefinementObservationRefusal> {
    let bits = state.p.map(f64::to_bits);
    Box::new(RefinementObservationRefusal {
        p1_reduced_norm_bits: None,
        p2_reduced_norm_bits: None,
        reason,
        refinement: None,
        work: Box::new(state_work_observation(state)),
        returned_step: None,
        bvls02_fallback_calls: 0,
        materialization_calls: 0,
        physical_evaluator_calls: 0,
        hook_log: Vec::new(),
        owner_snapshot_before: bits,
        owner_snapshot_after: bits,
        live_state_bits_before: bits,
        live_state_bits_after: bits,
        required_scalar_operations: 0,
        required_guard_events: 0,
        attempted_entries_before: state.refinement_work.attempted_entries,
        attempted_entries_after: state.refinement_work.attempted_entries,
        denied_entries_before: state.refinement_work.denied_entries,
        denied_entries_after: state.refinement_work.denied_entries,
        corrections: 0,
        dot2_operations: 0,
        factor_applications: 0,
        denied_entry_executed_scalar_operations: 0,
        denied_entry_executed_guard_events: 0,
        prior_eligibility_scalar_operations: 0,
        prior_eligibility_guard_events: 0,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        global_before: None,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        global_after: None,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_before: None,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_after: None,
    })
}

#[cfg(test)]
struct RefinementRetainedFaceObservationContext<'a> {
    input: &'a super::M1TrustRegionSubproblemInput,
    prepared: &'a PreparedSubproblem,
    state: &'a SubproblemState,
    trace: RefinementObservationTrace,
    p2: [f64; 21],
    p2_norm: f64,
    entered_before_refinement: u8,
    factor_identity_before: usize,
    factor_identity_after: usize,
    lower: [bool; 21],
    upper: [bool; 21],
    bvls02_pass: bool,
    optimality: super::M1TrustRegionOptimalityObservation,
    values: Option<KktValues>,
    lambda: f64,
}

#[cfg(test)]
struct RefinementRetainedFaceTraceBits {
    p0: Vec<u64>,
    delta0: Vec<u64>,
    p1: Vec<u64>,
    residual1: Vec<u64>,
    delta1: Vec<u64>,
    p2: Vec<u64>,
}

#[cfg(test)]
fn refinement_retained_face_trace_bits(
    trace: &RefinementObservationTrace,
    p2: [f64; 21],
    state: &SubproblemState,
) -> Result<RefinementRetainedFaceTraceBits, Box<RefinementObservationRefusal>> {
    Ok(RefinementRetainedFaceTraceBits {
        p0: trace
            .p0
            .ok_or_else(|| refinement_observation_refusal("refinement_p0_missing", state))?
            .map(f64::to_bits)
            .to_vec(),
        delta0: trace
            .delta0
            .as_ref()
            .ok_or_else(|| refinement_observation_refusal("refinement_delta0_missing", state))?
            .iter()
            .map(|value| value.to_bits())
            .collect(),
        p1: trace
            .p1
            .ok_or_else(|| refinement_observation_refusal("refinement_p1_missing", state))?
            .map(f64::to_bits)
            .to_vec(),
        residual1: trace
            .residual1
            .ok_or_else(|| refinement_observation_refusal("refinement_residual1_missing", state))?
            .map(f64::to_bits)
            .to_vec(),
        delta1: trace
            .delta1
            .as_ref()
            .ok_or_else(|| refinement_observation_refusal("refinement_delta1_missing", state))?
            .iter()
            .map(|value| value.to_bits())
            .collect(),
        p2: p2.map(f64::to_bits).to_vec(),
    })
}

#[cfg(test)]
struct RefinementRetainedFaceRefusalContext<'a> {
    refusal: super::M1TrustRegionSubproblemRefusal,
    state: &'a SubproblemState,
    trace: RefinementObservationTrace,
    required_scalar_operations: u64,
    required_guard_events: u64,
    attempted_entries_before: u16,
    denied_entries_before: u16,
    ledger_before_refinement: u64,
    guards_before_refinement: u64,
}

#[cfg(test)]
fn refinement_build_retained_face_refusal(
    context: RefinementRetainedFaceRefusalContext<'_>,
) -> Result<RefinementRetainedFaceObservation, Box<RefinementObservationRefusal>> {
    let RefinementRetainedFaceRefusalContext {
        refusal,
        state,
        trace,
        required_scalar_operations,
        required_guard_events,
        attempted_entries_before,
        denied_entries_before,
        ledger_before_refinement,
        guards_before_refinement,
    } = context;
    let mut observed = refinement_observation_refusal(
        if refusal.kind == M1TrustRegionRefusalKind::WorkCap {
            "refinement_work_cap"
        } else {
            refusal.optimality_reason.unwrap_or("refinement_refusal")
        },
        state,
    );
    observed.p1_reduced_norm_bits = trace.p1_reduced_norm.map(f64::to_bits);
    observed.p2_reduced_norm_bits = trace.p2_reduced_norm.map(f64::to_bits);
    observed.refinement = refusal.refinement;
    observed.work = refusal.work;
    observed.required_scalar_operations = required_scalar_operations;
    observed.required_guard_events = required_guard_events;
    observed.attempted_entries_before = attempted_entries_before;
    observed.attempted_entries_after = state.refinement_work.attempted_entries;
    observed.denied_entries_before = denied_entries_before;
    observed.denied_entries_after = state.refinement_work.denied_entries;
    observed.corrections = trace.factor_applications;
    observed.dot2_operations = state.refinement_work.second_dot2_operations;
    observed.factor_applications = trace.factor_applications;
    observed.prior_eligibility_scalar_operations = trace
        .eligibility_scalar_operations
        .ok_or_else(|| refinement_observation_refusal("refinement_observation_missing", state))?;
    observed.prior_eligibility_guard_events = trace
        .eligibility_guard_events
        .ok_or_else(|| refinement_observation_refusal("refinement_observation_missing", state))?;
    observed.denied_entry_executed_scalar_operations = state
        .refinement_work
        .scalar_operations
        .saturating_sub(ledger_before_refinement)
        .saturating_sub(observed.prior_eligibility_scalar_operations);
    observed.denied_entry_executed_guard_events = state
        .refinement_work
        .guard_events
        .saturating_sub(guards_before_refinement)
        .saturating_sub(observed.prior_eligibility_guard_events);
    observed.live_state_bits_before = trace
        .live_state_entry
        .ok_or_else(|| refinement_observation_refusal("refinement_observation_missing", state))?;
    observed.live_state_bits_after = trace
        .live_state_exit
        .ok_or_else(|| refinement_observation_refusal("refinement_observation_missing", state))?;
    Err(observed)
}

#[cfg(test)]
fn refinement_required_observation_live_state_bits(
    trace: &RefinementObservationTrace,
    state: &SubproblemState,
) -> Result<([u64; 21], [u64; 21]), Box<RefinementObservationRefusal>> {
    Ok((
        trace.live_state_entry.ok_or_else(|| {
            refinement_observation_refusal("refinement_observation_missing", state)
        })?,
        trace.live_state_exit.ok_or_else(|| {
            refinement_observation_refusal("refinement_observation_missing", state)
        })?,
    ))
}

fn refinement_required_observation_residual_bits(
    trace: &RefinementObservationTrace,
    state: &SubproblemState,
) -> Result<(Vec<u64>, Vec<u64>), Box<RefinementObservationRefusal>> {
    Ok((
        trace
            .residual0
            .ok_or_else(|| refinement_observation_refusal("refinement_r0_missing", state))?
            .map(f64::to_bits)
            .to_vec(),
        trace
            .residual1
            .ok_or_else(|| refinement_observation_refusal("refinement_residual1_missing", state))?
            .map(f64::to_bits)
            .to_vec(),
    ))
}

struct RefinementObservationMasks {
    lower_p0: Vec<bool>,
    upper_p0: Vec<bool>,
    lower_p1: Vec<bool>,
    upper_p1: Vec<bool>,
    lower_p2: Vec<bool>,
    upper_p2: Vec<bool>,
    active_coordinate: usize,
}
type RefinementFinalValueBits = (Option<Vec<u64>>, Option<Vec<u64>>, Option<Vec<u64>>);

fn refinement_observation_masks(
    trace: &RefinementObservationTrace,
    lower: [bool; 21],
    upper: [bool; 21],
) -> RefinementObservationMasks {
    RefinementObservationMasks {
        lower_p0: trace.lower_mask_p0.unwrap_or(lower).to_vec(),
        upper_p0: trace.upper_mask_p0.unwrap_or(upper).to_vec(),
        lower_p1: trace.lower_mask_p1.unwrap_or(lower).to_vec(),
        upper_p1: trace.upper_mask_p1.unwrap_or(upper).to_vec(),
        lower_p2: trace.lower_mask_p2.unwrap_or(lower).to_vec(),
        upper_p2: trace.upper_mask_p2.unwrap_or(upper).to_vec(),
        active_coordinate: lower.iter().position(|value| *value).unwrap_or(0),
    }
}

fn refinement_optimality_observation_fields(
    optimality: &super::M1TrustRegionOptimalityObservation,
) -> (Vec<u64>, Vec<u64>, Vec<u64>, Vec<String>) {
    (
        optimality
            .coordinates
            .iter()
            .map(|value| value.h.to_bits())
            .collect(),
        optimality
            .coordinates
            .iter()
            .map(|value| value.cbar.to_bits())
            .collect(),
        optimality
            .coordinates
            .iter()
            .map(|value| value.tau.to_bits())
            .collect(),
        optimality
            .coordinates
            .iter()
            .map(|value| refinement_class_name(value.class).to_owned())
            .collect(),
    )
}

fn refinement_final_value_bits(values: Option<&KktValues>) -> RefinementFinalValueBits {
    (
        values.map(|value| value.residual.map(f64::to_bits).to_vec()),
        values.map(|value| value.gradient.map(f64::to_bits).to_vec()),
        values.map(|value| value.lambda_times_step.map(f64::to_bits).to_vec()),
    )
}

fn refinement_observation_defect_bits(
    trace: &RefinementObservationTrace,
) -> (Option<Vec<u64>>, Option<Vec<u64>>) {
    (
        trace
            .h0
            .as_ref()
            .map(|values| values.iter().map(|value| value.to_bits()).collect()),
        trace
            .h1
            .as_ref()
            .map(|values| values.iter().map(|value| value.to_bits()).collect()),
    )
}

type RefinementRequiredObservationBits = (([u64; 21], [u64; 21]), (Vec<u64>, Vec<u64>));

fn refinement_observation_required_bits(
    trace: &RefinementObservationTrace,
    state: &SubproblemState,
) -> Result<RefinementRequiredObservationBits, Box<RefinementObservationRefusal>> {
    Ok((
        refinement_required_observation_live_state_bits(trace, state)?,
        refinement_required_observation_residual_bits(trace, state)?,
    ))
}

fn refinement_build_retained_face_observation(
    context: RefinementRetainedFaceObservationContext<'_>,
) -> Result<RefinementRetainedFaceObservation, Box<RefinementObservationRefusal>> {
    let RefinementRetainedFaceObservationContext {
        input,
        prepared,
        state,
        trace,
        p2,
        lower,
        upper,
        bvls02_pass,
        optimality,
        values,
        lambda,
        p2_norm,
        entered_before_refinement,
        factor_identity_before,
        factor_identity_after,
        ..
    } = context;
    let trace_bits = refinement_retained_face_trace_bits(&trace, p2, state)?;
    let ((live_state_bits_entry, live_state_bits_exit), (r0_bits, residual1_bits)) =
        refinement_observation_required_bits(&trace, state)?;
    let masks = refinement_observation_masks(&trace, lower, upper);
    let (final_residual_bits, final_gradient_bits, final_lambda_p_bits) =
        refinement_final_value_bits(values.as_ref());
    let (h_bits, cbar_bits, tau_bits, classes) =
        refinement_optimality_observation_fields(&optimality);
    let (h0_free_bits, h1_free_bits) = refinement_observation_defect_bits(&trace);
    Ok(RefinementRetainedFaceObservation {
        lambda_bits: lambda.to_bits(),
        live_state_bits_entry,
        live_state_bits_exit,
        p0_bits: trace_bits.p0,
        delta0_free_bits: trace_bits.delta0,
        p1_bits: trace_bits.p1,
        dot2_residual_bits: trace_bits.residual1,
        delta1_free_bits: trace_bits.delta1,
        p2_bits: trace_bits.p2,
        r0_bits,
        residual1_bits,
        final_residual_bits,
        final_gradient_bits,
        final_lambda_p_bits,
        h0_free_bits,
        h1_free_bits,
        p0_full_norm2_bits: trace.p0_full_norm2.map(f64::to_bits),
        p0_full_norm_bits: trace.p0_full_norm.map(f64::to_bits),
        p0_reduced_norm2_bits: trace.p0_reduced_norm2.map(f64::to_bits),
        p0_reduced_norm_bits: trace.p0_reduced_norm.map(f64::to_bits),
        p1_full_norm2_bits: trace.p1_full_norm2.map(f64::to_bits),
        p1_full_norm_bits: trace.p1_full_norm.map(f64::to_bits),
        p1_reduced_norm2_bits: trace.p1_reduced_norm2.map(f64::to_bits),
        p1_reduced_norm_bits: trace.p1_reduced_norm.map(f64::to_bits),
        p2_full_norm2_bits: trace.p2_full_norm2.map(f64::to_bits),
        p2_full_norm_bits: trace.p2_full_norm.map(f64::to_bits),
        p2_reduced_norm2_bits: trace.p2_reduced_norm2.map(f64::to_bits),
        p2_reduced_norm_bits: trace.p2_reduced_norm.map(f64::to_bits),
        original_radius_bits: input.initial_radius.to_bits(),
        remaining_radius_bits: trace.remaining_radius.map(f64::to_bits),
        radius_gap_bits: trace.radius_gap.map(f64::to_bits),
        radius_tolerance_bits: trace.radius_tolerance.map(f64::to_bits),
        factor_applications: trace.factor_applications,
        active_coordinate: masks.active_coordinate,
        h_bits,
        cbar_bits,
        tau_bits,
        classes,
        box_feasible: refinement_box_admit(prepared, &p2, None, None).is_none(),
        ball_feasible: p2_norm <= input.initial_radius,
        factorizations_added: state.entered - entered_before_refinement,
        factor_application_count: trace.factor_applications,
        factor_identity_before,
        factor_identity_after,
        factor_application_identities: trace.factor_application_identities,
        lower_mask_p0: masks.lower_p0,
        upper_mask_p0: masks.upper_p0,
        lower_mask_p1: masks.lower_p1,
        upper_mask_p1: masks.upper_p1,
        lower_mask_p2: masks.lower_p2,
        upper_mask_p2: masks.upper_p2,
        lower_mask_exit: trace.lower_mask_exit.unwrap_or(state.lower_active).to_vec(),
        upper_mask_exit: trace.upper_mask_exit.unwrap_or(state.upper_active).to_vec(),
        corrections: trace.factor_applications,
        bvls02_pass,
        bvls04_entries: state.refinement_work.bvls04_positive_entries,
        refinement_attempted_entries: u32::from(state.refinement_work.attempted_entries),
        refinement_scalar_operations: state.refinement_work.scalar_operations,
        full_work: state_work_observation(state),
        first_residual_operations: state.refinement_work.first_residual_operations,
        second_dot2_operations: state.refinement_work.second_dot2_operations,
        factor_application_operations: state.refinement_work.factor_application_operations,
        coordinate_update_operations: state.refinement_work.coordinate_update_operations,
        whole_kkt_operations: state.refinement_work.whole_kkt_operations,
        whole_kkt_guard_events: state.refinement_work.whole_kkt_guard_events,
        upward_enclosure_operations: state.refinement_work.upward_enclosure_operations,
        upward_enclosure_guard_events: state.refinement_work.upward_enclosure_guard_events,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_before: None,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_after: None,
    })
}

#[cfg(test)]
fn refinement_override_signed_zero_for_test(
    solution: &mut FaceSolution,
    state: &SubproblemState,
    lambda_zero_override: Option<f64>,
) -> Result<(), Box<RefinementObservationRefusal>> {
    if let Some(lambda) = lambda_zero_override {
        if solution.trace.lambda != 0.0 || lambda != 0.0 {
            return Err(refinement_observation_refusal(
                "refinement_signed_zero_not_natural",
                state,
            ));
        }
        solution.trace.lambda = lambda;
    }
    Ok(())
}

#[cfg(test)]
fn m1_trust_region_refinement_retained_face_raw_for_test(
    capture: &serde_json::Value,
    reservation: Option<RefinementWorkReservation>,
    lambda_zero_override: Option<f64>,
) -> Result<RefinementRetainedFaceObservation, Box<RefinementObservationRefusal>> {
    let (input, prepared, mut state, mut solution) = refinement_solve_captured_face(capture)
        .map_err(|_| {
            refinement_observation_refusal(
                "refinement_capture_decode",
                &SubproblemState::new(&super::M1TrustRegionSubproblemInput {
                    raw_residual: [0.0; 21],
                    raw_jacobian: [[0.0; 21]; 21],
                    normalizers: [1.0; 21],
                    scales: [1.0; 21],
                    lower: [f64::NEG_INFINITY; 21],
                    upper: [f64::INFINITY; 21],
                    initial_radius: 1.0,
                    base: [0.0; 21],
                    test_work: super::M1TrustRegionTestWorkState::default(),
                }),
            )
        })?;
    let factor_identity_before = solution
        .factor
        .as_ref()
        .map_or(0, |factor| std::ptr::from_ref(factor) as usize);
    refinement_override_signed_zero_for_test(&mut solution, &state, lambda_zero_override)?;
    let entered_before_refinement = state.entered;
    let (required_scalar_operations, required_guard_events) =
        if solution.trace.lambda.is_finite() && solution.trace.lambda > 0.0 {
            bvls04_required_work(solution.free_ids.len())
        } else {
            refinement_required_work(solution.free_ids.len())
        };
    if let Some(reservation) = reservation {
        // The caller supplies remaining capacity only.  Required work remains
        // derived from the actual free-face dimension in the shared core.
        state.refinement_work.scalar_operations =
            REFINEMENT_SCALAR_CAP.saturating_sub(reservation.remaining_scalar_operations);
        state.refinement_work.guard_events =
            REFINEMENT_GUARD_CAP.saturating_sub(reservation.remaining_guard_events);
    }
    let attempted_entries_before = state.refinement_work.attempted_entries;
    let denied_entries_before = state.refinement_work.denied_entries;
    let ledger_before_refinement = state.refinement_work.scalar_operations;
    let guards_before_refinement = state.refinement_work.guard_events;
    let lower = state.lower_active;
    let upper = state.upper_active;
    let _observation_scope = RefinementObservationScope::begin();
    if let Err(refusal) = refine_face_before_crossing(&input, &prepared, &mut state, &mut solution)
    {
        let trace = refinement_observation_take().ok_or_else(|| {
            refinement_observation_refusal("refinement_observation_missing", &state)
        })?;
        return refinement_build_retained_face_refusal(RefinementRetainedFaceRefusalContext {
            refusal,
            state: &state,
            trace,
            required_scalar_operations,
            required_guard_events,
            attempted_entries_before,
            denied_entries_before,
            ledger_before_refinement,
            guards_before_refinement,
        });
    }
    let trace = refinement_observation_take()
        .ok_or_else(|| refinement_observation_refusal("refinement_observation_missing", &state))?;
    for (slot, &column) in solution.free_ids.iter().enumerate() {
        state.p[column] = solution.trace.step[slot];
    }
    let transition = kkt_transition(&prepared, &mut state, &solution).map_err(|refusal| {
        refinement_observation_refusal(
            refusal.optimality_reason.unwrap_or("refinement_bvls02"),
            &state,
        )
    })?;
    let bvls02_pass = transition.values.is_some();
    let values = transition.values;
    let optimality = transition.observation;
    let p2 = trace
        .p2
        .ok_or_else(|| refinement_observation_refusal("refinement_p2_missing", &state))?;
    let p2_norm = lambda_norm(&p2, None)
        .map_err(|_| refinement_observation_refusal("refinement_final_radius", &state))?;
    let factor_identity_after = solution
        .factor
        .as_ref()
        .map_or(0, |factor| std::ptr::from_ref(factor) as usize);
    refinement_build_retained_face_observation(RefinementRetainedFaceObservationContext {
        input: &input,
        prepared: &prepared,
        state: &state,
        trace,
        p2,
        p2_norm,
        entered_before_refinement,
        factor_identity_before,
        factor_identity_after,
        lower,
        upper,
        bvls02_pass,
        optimality,
        values,
        lambda: solution.trace.lambda,
    })
}

#[cfg(test)]
fn m1_trust_region_refinement_retained_face_for_test(
    capture: &serde_json::Value,
    reservation: Option<RefinementWorkReservation>,
) -> Result<RefinementRetainedFaceObservation, Box<RefinementObservationRefusal>> {
    #[cfg(feature = "m1-trust-region-physical-stage")]
    {
        let _outer_scope =
            crate::m1_physical_budget_scope_seeded_for_test(crate::M1PhysicalBudgetSnapshot {
                core: 7,
                core_attempted: 7,
                ..Default::default()
            });
        let before = crate::m1_physical_budget_observation_for_test();
        let result = {
            let _inner_scope = crate::m1_physical_budget_scope_for_test();
            m1_trust_region_refinement_retained_face_raw_for_test(capture, reservation, None)
        };
        let after = crate::m1_physical_budget_observation_for_test();
        match result {
            Ok(mut observation) => {
                observation.budget_before = before;
                observation.budget_after = after;
                Ok(observation)
            }
            Err(mut refusal) => {
                refusal.budget_before = before;
                refusal.budget_after = after;
                Err(refusal)
            }
        }
    }
    #[cfg(not(feature = "m1-trust-region-physical-stage"))]
    {
        m1_trust_region_refinement_retained_face_raw_for_test(capture, reservation, None)
    }
}

#[cfg(test)]
struct M1TrustRegionBvls03SignedZeroObservation {
    lambda_bits: u64,
    result_bits: Vec<u64>,
    bvls03_entries: u32,
    bvls04_entries: u32,
    factor_application_count: u8,
    first_residual_operations: u64,
    second_dot2_operations: u64,
    full_work: super::M1TrustRegionWorkObservation,
}

#[cfg(test)]
fn m1_trust_region_bvls03_signed_zero_for_test(
    capture: &serde_json::Value,
    sign: f64,
) -> Result<M1TrustRegionBvls03SignedZeroObservation, Box<RefinementObservationRefusal>> {
    let observed =
        m1_trust_region_refinement_retained_face_raw_for_test(capture, None, Some(sign))?;
    if observed.bvls04_entries != 0 || observed.refinement_attempted_entries == 0 {
        return Err(refinement_observation_refusal(
            "refinement_signed_zero_entry_accounting",
            &SubproblemState::new(&super::M1TrustRegionSubproblemInput {
                raw_residual: [0.0; 21],
                raw_jacobian: [[0.0; 21]; 21],
                normalizers: [1.0; 21],
                scales: [1.0; 21],
                lower: [f64::NEG_INFINITY; 21],
                upper: [f64::INFINITY; 21],
                initial_radius: 1.0,
                base: [0.0; 21],
                test_work: super::M1TrustRegionTestWorkState::default(),
            }),
        ));
    }
    Ok(M1TrustRegionBvls03SignedZeroObservation {
        lambda_bits: observed.lambda_bits,
        result_bits: observed.p2_bits,
        bvls03_entries: observed.refinement_attempted_entries,
        bvls04_entries: observed.bvls04_entries,
        factor_application_count: observed.factor_application_count,
        first_residual_operations: observed.first_residual_operations,
        second_dot2_operations: observed.second_dot2_operations,
        full_work: observed.full_work,
    })
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct M1TrustRegionBvls04Reservation {
    scalar_capacity: u64,
    guard_capacity: u64,
    free_count: usize,
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct M1TrustRegionBvls04WorkBoundaryObservation {
    attempted_delta: u32,
    denied_delta: u32,
    required_scalar: u64,
    required_guards: u64,
    denial_owner: M1TrustRegionBvls04ReservationOwner,
    total_scalar_delta: u64,
    total_guard_delta: u64,
    eligibility_scalar_delta: u64,
    eligibility_guard_delta: u64,
    category_entry_delta: u32,
    factor_delta: u32,
    dot2_delta: u32,
    inverse_delta: u32,
    update_delta: u64,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    phase_delta: u32,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    evaluator_delta: u32,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    hydraulic_delta: u32,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    materialization_delta: u32,
    owner_snapshot_before: [u64; 21],
    owner_snapshot_after: [u64; 21],
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_before: Option<crate::M1PhysicalBudgetSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_after: Option<crate::M1PhysicalBudgetSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    scratch_global_before: RefinementScratchGlobalSnapshot,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    scratch_global_after: RefinementScratchGlobalSnapshot,
    reservation_is_conservative: bool,
}

// This seam deliberately stops at the shared positive eligibility and work
// reservation boundary.  The identity factor is structural input only: no
// factor application or correction is requested here.
#[cfg(test)]
struct M1TrustRegionBvls04WorkBoundaryFixture {
    input: super::M1TrustRegionSubproblemInput,
    prepared: PreparedSubproblem,
    state: SubproblemState,
    solution: FaceSolution,
}

#[cfg(test)]
fn m1_trust_region_bvls04_work_boundary_fixture(
    reservation: M1TrustRegionBvls04Reservation,
) -> M1TrustRegionBvls04WorkBoundaryFixture {
    let free_count = reservation.free_count;
    let input = super::M1TrustRegionSubproblemInput {
        raw_residual: [0.0; 21],
        raw_jacobian: [[0.0; 21]; 21],
        normalizers: [1.0; 21],
        scales: [1.0; 21],
        lower: [-1.0; 21],
        upper: [1.0; 21],
        initial_radius: 1.0,
        base: [0.0; 21],
        test_work: super::M1TrustRegionTestWorkState::default(),
    };
    let prepared = PreparedSubproblem {
        raw_max: 0.0,
        weighted_residual: vec![0.0; 21],
        weighted_matrix: vec![vec![0.0; 21]; 21],
        scaled_lower: [-1.0; 21],
        scaled_upper: [1.0; 21],
    };
    let mut state = SubproblemState::new(&input);
    state.refinement_work.scalar_operations =
        REFINEMENT_SCALAR_CAP.saturating_sub(reservation.scalar_capacity);
    state.refinement_work.guard_events =
        REFINEMENT_GUARD_CAP.saturating_sub(reservation.guard_capacity);
    state.free = std::array::from_fn(|coordinate| coordinate < free_count);
    let mut v = vec![vec![0.0; free_count]; free_count];
    for (coordinate, row) in v.iter_mut().enumerate() {
        row[coordinate] = 1.0;
    }
    let solution = FaceSolution {
        free_ids: (0..free_count).collect(),
        trace: LambdaTrace {
            lambda: 1.0,
            step: vec![0.0; free_count],
            ..Default::default()
        },
        refined: false,
        factor: Some(JacobiFactor {
            a: vec![vec![0.0; free_count]; 21],
            b: vec![vec![0.0; free_count]; 21],
            v,
            sigma: vec![1.0; free_count],
            order: (0..free_count).collect(),
            visits: Vec::new(),
            rotations: 0,
            sweeps: 0,
        }),
        radius: 1.0,
    };
    M1TrustRegionBvls04WorkBoundaryFixture {
        input,
        prepared,
        state,
        solution,
    }
}

#[cfg(test)]
fn m1_trust_region_bvls04_work_boundary_for_test(
    reservation: M1TrustRegionBvls04Reservation,
) -> Result<
    M1TrustRegionBvls04WorkBoundaryObservation,
    Box<M1TrustRegionBvls04WorkBoundaryObservation>,
> {
    assert!(
        reservation.free_count <= 21,
        "BVLS-04 boundary free count exceeds face"
    );
    let free_count = reservation.free_count;
    let M1TrustRegionBvls04WorkBoundaryFixture {
        input,
        prepared,
        mut state,
        solution,
    } = m1_trust_region_bvls04_work_boundary_fixture(reservation);
    let owner_snapshot_before = state.p.map(f64::to_bits);
    #[cfg(feature = "m1-trust-region-physical-stage")]
    let scratch_global_before = refinement_scratch_global_snapshot();
    let attempted_before = state.refinement_work.attempted_entries;
    let denied_before = state.refinement_work.denied_entries;
    let category_before = state.refinement_work.bvls04_positive_entries;
    let factor_before = state.refinement_work.bvls04_factor_applications;
    let dot2_before = state.refinement_work.bvls04_dot2_residual_rows;
    let inverse_before = state.refinement_work.factor_application_operations;
    let update_before = state.refinement_work.coordinate_update_operations;
    let scalar_before = state.refinement_work.scalar_operations;
    let guards_before = state.refinement_work.guard_events;
    let _observation_scope = RefinementObservationScope::begin();
    let result =
        refinement_bvls04_positive_eligibility_prefix(&input, &prepared, &mut state, &solution);
    let trace = refinement_observation_take()
        .expect("BVLS-04 boundary shared eligibility trace must be present");
    #[cfg(feature = "m1-trust-region-physical-stage")]
    let scratch_global_after = refinement_scratch_global_snapshot();
    let observed = M1TrustRegionBvls04WorkBoundaryObservation {
        attempted_delta: u32::from(state.refinement_work.attempted_entries - attempted_before),
        denied_delta: u32::from(state.refinement_work.denied_entries - denied_before),
        required_scalar: bvls04_required_work(free_count).0,
        required_guards: bvls04_required_work(free_count).1,
        denial_owner: trace
            .reservation_denial_owner
            .unwrap_or(M1TrustRegionBvls04ReservationOwner::Admitted),
        total_scalar_delta: state.refinement_work.scalar_operations - scalar_before,
        total_guard_delta: state.refinement_work.guard_events - guards_before,
        eligibility_scalar_delta: trace
            .eligibility_scalar_operations
            .expect("BVLS-04 boundary shared scalar eligibility observation"),
        eligibility_guard_delta: trace
            .eligibility_guard_events
            .expect("BVLS-04 boundary shared guard eligibility observation"),
        category_entry_delta: state.refinement_work.bvls04_positive_entries - category_before,
        factor_delta: state.refinement_work.bvls04_factor_applications - factor_before,
        dot2_delta: state.refinement_work.bvls04_dot2_residual_rows - dot2_before,
        inverse_delta: u32::try_from(
            state.refinement_work.factor_application_operations - inverse_before,
        )
        .unwrap_or(u32::MAX),
        update_delta: state.refinement_work.coordinate_update_operations - update_before,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        phase_delta: scratch_global_after.phase_join_selections
            - scratch_global_before.phase_join_selections,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        evaluator_delta: scratch_global_after.complete_evaluator_entries
            - scratch_global_before.complete_evaluator_entries,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        hydraulic_delta: scratch_global_after.actual_hydraulic_entries
            - scratch_global_before.actual_hydraulic_entries,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        materialization_delta: scratch_global_after.materialization_entries
            - scratch_global_before.materialization_entries,
        owner_snapshot_before,
        owner_snapshot_after: state.p.map(f64::to_bits),
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_before: scratch_global_before.budget,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_after: scratch_global_after.budget,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        scratch_global_before,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        scratch_global_after,
        reservation_is_conservative: bvls04_required_work(free_count).0
            >= state.refinement_work.scalar_operations - scalar_before
            && bvls04_required_work(free_count).1
                >= state.refinement_work.guard_events - guards_before,
    };
    if result.is_ok() {
        Ok(observed)
    } else {
        Err(Box::new(observed))
    }
}

#[cfg(test)]
struct RefinementMutationScope(Option<RefinementRawCandidateMutation>);

#[cfg(test)]
impl RefinementMutationScope {
    fn install(mutation: Option<RefinementRawCandidateMutation>) -> Self {
        let prior = REFINEMENT_RAW_MUTATION
            .try_with(|slot| {
                slot.try_borrow_mut()
                    .ok()
                    .map(|mut slot| std::mem::replace(&mut *slot, mutation))
            })
            .ok()
            .flatten()
            .flatten();
        Self(prior)
    }
}

#[cfg(test)]
impl Drop for RefinementMutationScope {
    fn drop(&mut self) {
        let _ = REFINEMENT_RAW_MUTATION.try_with(|slot| {
            if let Ok(mut slot) = slot.try_borrow_mut() {
                *slot = self.0;
            }
        });
    }
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementScratchHooksObservation {
    p1_free_box_violation: bool,
    physical_evaluator_calls: u32,
    hydraulic_calls: u32,
    materialization_calls: u32,
    live_state_bits_before: [u64; 21],
    live_state_bits_after: [u64; 21],
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_before: Option<crate::M1PhysicalBudgetSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    budget_after: Option<crate::M1PhysicalBudgetSnapshot>,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    global_before: RefinementScratchGlobalSnapshot,
    #[cfg(feature = "m1-trust-region-physical-stage")]
    global_after: RefinementScratchGlobalSnapshot,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
#[derive(Clone, Debug, PartialEq)]
struct RefinementScratchGlobalSnapshot {
    activity: crate::M1LoopActivityObservation,
    accepted_binding: Option<(crate::M1CoupledColumnInput, [f64; 21])>,
    phase_join_selections: u32,
    frozen_weighted_merit_entries: u32,
    complete_evaluator_entries: u32,
    hydraulic_entries: u32,
    actual_hydraulic_entries: u32,
    trial_entries: u32,
    materialization_entries: u32,
    final_assemblies: u32,
    work: (u32, u32),
    budget: Option<crate::M1PhysicalBudgetSnapshot>,
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn refinement_scratch_global_snapshot() -> RefinementScratchGlobalSnapshot {
    let activity = crate::m1_loop_activity_observation_for_test();
    let accepted_binding = crate::m1_captured_accepted_adapter_binding_for_test();
    RefinementScratchGlobalSnapshot {
        activity: activity.clone(),
        accepted_binding,
        phase_join_selections: crate::m1_refinement_phase_join_selections_for_test(),
        frozen_weighted_merit_entries: refinement_frozen_weighted_merit_entries_for_test(),
        complete_evaluator_entries: activity.complete_evaluator_entries,
        hydraulic_entries: activity.hydraulic_entries,
        actual_hydraulic_entries: activity.actual_hydraulic_entries,
        trial_entries: activity.trial_entries,
        materialization_entries: activity.materialization_entries,
        final_assemblies: activity.final_assemblies,
        work: crate::m1_work_observation_for_test(),
        budget: crate::m1_physical_budget_observation_for_test(),
    }
}

#[cfg(test)]
fn m1_trust_region_refinement_scratch_hooks_for_test(
    capture: &serde_json::Value,
    mutation: Option<RefinementRawCandidateMutation>,
) -> Result<RefinementScratchHooksObservation, Box<RefinementObservationRefusal>> {
    let (_, prepared, initial_state) = refinement_decode_captured_face(capture).map_err(|_| {
        refinement_observation_refusal(
            "refinement_capture_decode",
            &SubproblemState::new(&super::M1TrustRegionSubproblemInput {
                raw_residual: [0.0; 21],
                raw_jacobian: [[0.0; 21]; 21],
                normalizers: [1.0; 21],
                scales: [1.0; 21],
                lower: [f64::NEG_INFINITY; 21],
                upper: [f64::INFINITY; 21],
                initial_radius: 1.0,
                base: [0.0; 21],
                test_work: super::M1TrustRegionTestWorkState::default(),
            }),
        )
    })?;
    #[cfg(feature = "m1-trust-region-physical-stage")]
    let global_before = refinement_scratch_global_snapshot();
    let _scope = RefinementMutationScope::install(mutation);
    let result = m1_trust_region_refinement_retained_face_for_test(capture, None);
    #[cfg(feature = "m1-trust-region-physical-stage")]
    let global_after = refinement_scratch_global_snapshot();
    let observed = match result {
        Ok(observed) => observed,
        Err(mut refusal) => {
            // The mutation scope remains live through this snapshot and restores
            // its predecessor on return through Drop.
            #[cfg(feature = "m1-trust-region-physical-stage")]
            {
                refusal.global_before = Some(global_before);
                refusal.global_after = Some(global_after);
            }
            return Err(refusal);
        }
    };
    let p1 = observed
        .p1_bits
        .iter()
        .copied()
        .map(f64::from_bits)
        .collect::<Vec<_>>();
    let p1_box_violation = p1.iter().enumerate().any(|(column, value)| {
        initial_state.free[column]
            && (*value < prepared.scaled_lower[column] || *value > prepared.scaled_upper[column])
    });
    Ok(RefinementScratchHooksObservation {
        p1_free_box_violation: p1_box_violation,
        physical_evaluator_calls: {
            #[cfg(feature = "m1-trust-region-physical-stage")]
            {
                global_after.complete_evaluator_entries - global_before.complete_evaluator_entries
            }
            #[cfg(not(feature = "m1-trust-region-physical-stage"))]
            {
                0
            }
        },
        hydraulic_calls: {
            #[cfg(feature = "m1-trust-region-physical-stage")]
            {
                global_after.actual_hydraulic_entries - global_before.actual_hydraulic_entries
            }
            #[cfg(not(feature = "m1-trust-region-physical-stage"))]
            {
                0
            }
        },
        materialization_calls: {
            #[cfg(feature = "m1-trust-region-physical-stage")]
            {
                global_after.materialization_entries - global_before.materialization_entries
            }
            #[cfg(not(feature = "m1-trust-region-physical-stage"))]
            {
                0
            }
        },
        live_state_bits_before: observed.live_state_bits_entry,
        live_state_bits_after: observed.live_state_bits_exit,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_before: observed.budget_before,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        budget_after: observed.budget_after,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        global_before,
        #[cfg(feature = "m1-trust-region-physical-stage")]
        global_after,
    })
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
struct RefinementEligibilityProbe {
    lambda: f64,
    radius: f64,
    p0_outside_box: bool,
    p0_norm_value: f64,
}

#[cfg(test)]
impl RefinementEligibilityProbe {
    fn from_captured_face(capture: &serde_json::Value) -> Self {
        let operation = refinement_capture_operation(capture).expect("retained operation");
        let p0 = refinement_capture_vector(&operation["p_candidate"]).expect("retained p0");
        Self {
            lambda: refinement_capture_bit(&operation["lambda"]).expect("retained lambda"),
            radius: refinement_capture_bit(&operation["radius"]).expect("retained radius"),
            p0_outside_box: false,
            p0_norm_value: lambda_norm(&p0, None).expect("retained p0 norm"),
        }
    }
    fn with_lambda(mut self, lambda: f64) -> Self {
        self.lambda = lambda;
        self
    }
    fn with_trust_radius(mut self, radius: f64) -> Self {
        self.radius = radius;
        self
    }
    fn with_p0_free_coordinate_outside_box(mut self) -> Self {
        self.p0_outside_box = true;
        self
    }
    fn p0_norm(self) -> f64 {
        self.p0_norm_value
    }
}

#[cfg(test)]
#[derive(Clone, Debug, PartialEq, Eq)]
struct RefinementBvls02Outcome {
    outcome: String,
    kind: Option<M1TrustRegionRefusalKind>,
    reason: Option<&'static str>,
    coordinate: Option<usize>,
    crossing_action: Option<super::M1TrustRegionKktAction>,
    lower_mask_before: Vec<bool>,
    upper_mask_before: Vec<bool>,
    lower_mask: Vec<bool>,
    upper_mask: Vec<bool>,
    work: u64,
}

#[cfg(test)]
fn refinement_bvls02_face_outcome(
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
) -> RefinementBvls02Outcome {
    let lower_mask_before = state.lower_active.to_vec();
    let upper_mask_before = state.upper_active.to_vec();
    match activate_first_crossing(prepared, state, solution) {
        Ok(true) => RefinementBvls02Outcome {
            outcome: "crossing".to_owned(),
            kind: None,
            reason: None,
            coordinate: state.events.last().map(|event| event.selected_coordinate),
            crossing_action: state.events.last().map(|event| event.action),
            lower_mask_before,
            upper_mask_before,
            lower_mask: state.lower_active.to_vec(),
            upper_mask: state.upper_active.to_vec(),
            work: 0,
        },
        Ok(false) => match kkt_transition(prepared, state, solution) {
            Ok(value) => RefinementBvls02Outcome {
                outcome: if value.values.is_some() {
                    "return".to_owned()
                } else {
                    "transition".to_owned()
                },
                kind: None,
                reason: None,
                coordinate: None,
                crossing_action: None,
                lower_mask_before,
                upper_mask_before,
                lower_mask: state.lower_active.to_vec(),
                upper_mask: state.upper_active.to_vec(),
                work: u64::from(value.observation.scalar_operations),
            },
            Err(refusal) => RefinementBvls02Outcome {
                outcome: "refusal".to_owned(),
                kind: Some(refusal.kind),
                reason: refusal.optimality_reason,
                coordinate: refusal.optimality_coordinate,
                crossing_action: None,
                lower_mask_before,
                upper_mask_before,
                lower_mask: state.lower_active.to_vec(),
                upper_mask: state.upper_active.to_vec(),
                work: 0,
            },
        },
        Err(refusal) => RefinementBvls02Outcome {
            outcome: "refusal".to_owned(),
            kind: Some(refusal.kind),
            reason: refusal.optimality_reason,
            coordinate: refusal.optimality_coordinate,
            crossing_action: None,
            lower_mask_before,
            upper_mask_before,
            lower_mask: state.lower_active.to_vec(),
            upper_mask: state.upper_active.to_vec(),
            work: 0,
        },
    }
}

#[cfg(test)]
#[derive(Clone, Debug)]
struct RefinementEligibilityObservation {
    action: String,
    maximum_corrections: u8,
    bvls02_outcome: String,
    bvls02: RefinementBvls02Outcome,
    lower_mask_before: Vec<bool>,
    upper_mask_before: Vec<bool>,
    lower_mask_after: Vec<bool>,
    upper_mask_after: Vec<bool>,
    bvls02_work: u64,
    attempted_work_before: u64,
    attempted_work_after: u64,
    denied_work: u64,
}

#[cfg(test)]
fn refinement_apply_eligibility_probe(
    input: &mut super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    solution: &mut FaceSolution,
    probe: RefinementEligibilityProbe,
) {
    input.initial_radius = probe.radius;
    solution.trace.lambda = probe.lambda;
    if probe.p0_outside_box {
        if let Some((&column, value)) = solution
            .free_ids
            .first()
            .zip(solution.trace.step.first_mut())
        {
            *value = prepared.scaled_upper[column] + 1.0;
        }
    }
}

#[cfg(test)]
fn m1_trust_region_bvls02_outcome_for_test(
    capture: &serde_json::Value,
    probe: RefinementEligibilityProbe,
) -> Result<RefinementBvls02Outcome, Box<RefinementObservationRefusal>> {
    let (mut input, prepared, mut state, mut solution) = refinement_solve_captured_face(capture)
        .map_err(|_| {
            refinement_observation_refusal(
                "refinement_capture_decode",
                &SubproblemState::new(&super::M1TrustRegionSubproblemInput {
                    raw_residual: [0.0; 21],
                    raw_jacobian: [[0.0; 21]; 21],
                    normalizers: [1.0; 21],
                    scales: [1.0; 21],
                    lower: [f64::NEG_INFINITY; 21],
                    upper: [f64::INFINITY; 21],
                    initial_radius: 1.0,
                    base: [0.0; 21],
                    test_work: super::M1TrustRegionTestWorkState::default(),
                }),
            )
        })?;
    refinement_apply_eligibility_probe(&mut input, &prepared, &mut solution, probe);
    Ok(refinement_bvls02_face_outcome(
        &prepared, &mut state, &solution,
    ))
}

#[cfg(test)]
fn m1_trust_region_refinement_eligibility_for_test(
    capture: &serde_json::Value,
    probe: RefinementEligibilityProbe,
    _baseline: Option<&RefinementBvls02Outcome>,
) -> Result<RefinementEligibilityObservation, Box<RefinementObservationRefusal>> {
    let (mut input, prepared, mut state, mut solution) = refinement_solve_captured_face(capture)
        .map_err(|_| {
            refinement_observation_refusal(
                "refinement_capture_decode",
                &SubproblemState::new(&super::M1TrustRegionSubproblemInput {
                    raw_residual: [0.0; 21],
                    raw_jacobian: [[0.0; 21]; 21],
                    normalizers: [1.0; 21],
                    scales: [1.0; 21],
                    lower: [f64::NEG_INFINITY; 21],
                    upper: [f64::INFINITY; 21],
                    initial_radius: 1.0,
                    base: [0.0; 21],
                    test_work: super::M1TrustRegionTestWorkState::default(),
                }),
            )
        })?;
    refinement_apply_eligibility_probe(&mut input, &prepared, &mut solution, probe);
    let before = state.refinement_work.scalar_operations;
    let _observation_scope = RefinementObservationScope::begin();
    let result = refine_face_before_crossing(&input, &prepared, &mut state, &mut solution);
    let trace = refinement_observation_take();
    let refined = result.is_ok()
        && trace
            .as_ref()
            .is_some_and(|value| value.factor_applications == 2);
    let bvls02 = refinement_bvls02_face_outcome(&prepared, &mut state, &solution);
    let after = state.refinement_work.scalar_operations;
    Ok(RefinementEligibilityObservation {
        action: if refined {
            "refine".to_owned()
        } else {
            "bvls02".to_owned()
        },
        maximum_corrections: if refined { 2 } else { 0 },
        bvls02_outcome: bvls02.outcome.clone(),
        lower_mask_before: bvls02.lower_mask_before.clone(),
        upper_mask_before: bvls02.upper_mask_before.clone(),
        lower_mask_after: bvls02.lower_mask.clone(),
        upper_mask_after: bvls02.upper_mask.clone(),
        bvls02_work: bvls02.work,
        bvls02,
        attempted_work_before: before,
        attempted_work_after: after,
        denied_work: after - before,
    })
}

struct RefinementScratch {
    p1: [f64; 21],
}

#[derive(Clone, Copy)]
struct RefinementFailureSite {
    correction_position: Option<super::M1TrustRegionCorrectionPosition>,
    guard_stage: super::M1TrustRegionRefinementGuardStage,
    row: Option<u8>,
    term: Option<u8>,
    coordinate: Option<u8>,
    scratch_box_feasible: Option<bool>,
}

fn refinement_metadata_refusal(
    state: &SubproblemState,
    raw_max: f64,
    solution: &FaceSolution,
    original_trust_radius: f64,
    reason: super::M1TrustRegionRefinementReason,
    site: RefinementFailureSite,
) -> super::M1TrustRegionSubproblemRefusal {
    let RefinementFailureSite {
        correction_position,
        guard_stage,
        row,
        term,
        coordinate,
        scratch_box_feasible,
    } = site;
    let reason_text = match reason {
        super::M1TrustRegionRefinementReason::NonfiniteOperand => "refinement_nonfinite_operand",
        super::M1TrustRegionRefinementReason::SplitterOverflow => "refinement_splitter_overflow",
        super::M1TrustRegionRefinementReason::UnderflowToZero => "refinement_underflow_to_zero",
        super::M1TrustRegionRefinementReason::SubnormalIntermediate => {
            "refinement_subnormal_intermediate"
        }
        super::M1TrustRegionRefinementReason::FactorOutput => "refinement_factor_output",
        super::M1TrustRegionRefinementReason::CoordinateUpdate => "refinement_coordinate_update",
        super::M1TrustRegionRefinementReason::ActiveValue => "refinement_active_value",
        super::M1TrustRegionRefinementReason::ScratchBox => "refinement_scratch_box",
        super::M1TrustRegionRefinementReason::ScratchRadius => "refinement_scratch_radius",
        super::M1TrustRegionRefinementReason::FinalBox => "refinement_final_box",
        super::M1TrustRegionRefinementReason::FinalRadius => "refinement_final_radius",
    };
    let mut refusal = state_refusal(
        M1TrustRegionRefusalKind::TrustRegionRefinementIndeterminate,
        state,
        raw_max,
    );
    refusal.optimality_reason = Some(reason_text);
    refusal.refinement = Some(Box::new(super::M1TrustRegionRefinementFailureMetadata {
        reason,
        correction_position,
        guard_stage,
        row,
        term,
        coordinate,
        lower_active: state.lower_active,
        upper_active: state.upper_active,
        free: state.free,
        lambda: solution.trace.lambda,
        original_trust_radius,
        reduced_face_radius: solution.radius,
        scratch_box_feasible,
    }));
    refusal
}

fn refinement_dot2_metadata_refusal(
    state: &SubproblemState,
    raw_max: f64,
    solution: &FaceSolution,
    original_trust_radius: f64,
    site: RefinementFailureSite,
    reason: RefinementDot2Reason,
) -> super::M1TrustRegionSubproblemRefusal {
    let reason = if site.guard_stage == super::M1TrustRegionRefinementGuardStage::ActiveEquality {
        super::M1TrustRegionRefinementReason::ActiveValue
    } else {
        match reason {
            RefinementDot2Reason::NonfiniteOperand => {
                super::M1TrustRegionRefinementReason::NonfiniteOperand
            }
            RefinementDot2Reason::SplitterOverflow => {
                super::M1TrustRegionRefinementReason::SplitterOverflow
            }
            RefinementDot2Reason::UnderflowToZero => {
                super::M1TrustRegionRefinementReason::UnderflowToZero
            }
            RefinementDot2Reason::SubnormalIntermediate => {
                super::M1TrustRegionRefinementReason::SubnormalIntermediate
            }
        }
    };
    refinement_metadata_refusal(
        state,
        raw_max,
        solution,
        original_trust_radius,
        reason,
        site,
    )
}

fn refinement_p0(
    state_p: &[f64; 21],
    solution: &FaceSolution,
    mut refinement_work: Option<&mut RefinementWorkLedger>,
) -> Result<[f64; 21], &'static str> {
    if solution.free_ids.len() != solution.trace.step.len() {
        return Err("refinement_face_dimension");
    }
    let mut p0 = *state_p;
    for (slot, &column) in solution.free_ids.iter().enumerate() {
        if let Some(work) = refinement_work.as_deref_mut() {
            work.guard();
        }
        p0[column] = solution.trace.step[slot];
        if let Some(work) = refinement_work.as_deref_mut() {
            work.guard();
        }
        if p0[column].to_bits() != solution.trace.step[slot].to_bits() {
            return Err("refinement_factor_output");
        }
    }
    Ok(p0)
}

fn refinement_box_admit(
    prepared: &PreparedSubproblem,
    p: &[f64; 21],
    free_ids: Option<&[usize]>,
    mut refinement_work: Option<&mut RefinementWorkLedger>,
) -> Option<(u8, M1TrustRegionRefinementGuardStage)> {
    let mut admit = |column: usize| -> Option<M1TrustRegionRefinementGuardStage> {
        if let Some(work) = refinement_work.as_deref_mut() {
            work.guard();
        }
        if p[column] < prepared.scaled_lower[column] {
            return Some(M1TrustRegionRefinementGuardStage::FinalBoxLower);
        }
        if let Some(work) = refinement_work.as_deref_mut() {
            work.guard();
        }
        (p[column] > prepared.scaled_upper[column])
            .then_some(M1TrustRegionRefinementGuardStage::FinalBoxUpper)
    };
    if let Some(free_ids) = free_ids {
        for &column in free_ids {
            if let Some(stage) = admit(column) {
                return Some((refinement_face_index(column), stage));
            }
        }
    } else {
        for column in 0..21 {
            if let Some(stage) = admit(column) {
                return Some((refinement_face_index(column), stage));
            }
        }
    }
    None
}

fn refinement_face_index(index: usize) -> u8 {
    match u8::try_from(index) {
        Ok(index) => index,
        Err(_) => unreachable!("the fixed 21-coordinate refinement face fits u8"),
    }
}

fn refinement_active_admit(
    p: &[f64; 21],
    lower_active: &[bool; 21],
    upper_active: &[bool; 21],
    state_p: &[f64; 21],
) -> Result<RefinementDot2Counters, RefinementDot2Refusal> {
    let mut counters = RefinementDot2Counters::default();
    for column in 0..21 {
        if let Err(reason) = refinement_dot2_guard(p[column], &mut counters) {
            return Err(RefinementDot2Refusal {
                reason,
                guard_stage: M1TrustRegionRefinementGuardStage::ActiveFinite,
                row: None,
                term: None,
                coordinate: Some(refinement_face_index(column)),
                arithmetic: counters.arithmetic,
                guards: counters.guards,
                exceptional_guards: counters.exceptional_guards,
                signed_zero_values: counters.signed_zero_values,
            });
        }
        if lower_active[column] || upper_active[column] {
            counters.guards += 1;
            if p[column].to_bits() == state_p[column].to_bits() {
                continue;
            }
            return Err(RefinementDot2Refusal {
                reason: RefinementDot2Reason::NonfiniteOperand,
                guard_stage: M1TrustRegionRefinementGuardStage::ActiveEquality,
                row: None,
                term: None,
                coordinate: Some(refinement_face_index(column)),
                arithmetic: counters.arithmetic,
                guards: counters.guards,
                exceptional_guards: counters.exceptional_guards,
                signed_zero_values: counters.signed_zero_values,
            });
        }
    }
    Ok(counters)
}

fn refinement_eligibility_active_admit(
    p: &[f64; 21],
    lower_active: &[bool; 21],
    upper_active: &[bool; 21],
    state_p: &[f64; 21],
    mut refinement_work: Option<&mut RefinementWorkLedger>,
) -> bool {
    for column in 0..21 {
        if let Some(work) = refinement_work.as_deref_mut() {
            work.guard();
        }
        if !p[column].is_finite() {
            return false;
        }
        if lower_active[column] || upper_active[column] {
            if let Some(work) = refinement_work.as_deref_mut() {
                work.guard();
            }
            if p[column].to_bits() != state_p[column].to_bits() {
                return false;
            }
        }
    }
    true
}

fn refinement_first_residual(
    prepared: &PreparedSubproblem,
    p: &[f64; 21],
) -> Result<([f64; 21], RefinementDot2Counters), RefinementDot2Refusal> {
    let mut counters = RefinementDot2Counters::default();
    let refusal =
        |reason, guard_stage, row, term, coordinate, counters: &RefinementDot2Counters| {
            RefinementDot2Refusal {
                reason,
                guard_stage,
                row: Some(refinement_face_index(row)),
                term: Some(refinement_face_index(term)),
                coordinate,
                arithmetic: counters.arithmetic,
                guards: counters.guards,
                exceptional_guards: counters.exceptional_guards,
                signed_zero_values: counters.signed_zero_values,
            }
        };
    let mut residual = [0.0; 21];
    for row in 0..21 {
        if let Err(reason) = refinement_dot2_guard(prepared.weighted_residual[row], &mut counters) {
            return Err(refusal(
                reason,
                M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                row,
                0,
                None,
                &counters,
            ));
        }
        let mut sum = 0.0;
        for (column, &step) in p.iter().enumerate() {
            if let Err(reason) =
                refinement_dot2_guard(prepared.weighted_matrix[row][column], &mut counters)
            {
                return Err(refusal(
                    reason,
                    M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                    row,
                    column + 1,
                    Some(refinement_face_index(column)),
                    &counters,
                ));
            }
            if let Err(reason) = refinement_dot2_guard(step, &mut counters) {
                return Err(refusal(
                    reason,
                    M1TrustRegionRefinementGuardStage::ResidualSourceWeight,
                    row,
                    column + 1,
                    Some(refinement_face_index(column)),
                    &counters,
                ));
            }
            let product =
                refinement_dot2_mul(prepared.weighted_matrix[row][column], step, &mut counters)
                    .map_err(|reason| {
                        refusal(
                            reason,
                            M1TrustRegionRefinementGuardStage::PrimaryProduct,
                            row,
                            column + 1,
                            Some(refinement_face_index(column)),
                            &counters,
                        )
                    })?;
            sum = refinement_dot2_add(sum, product, &mut counters).map_err(|reason| {
                refusal(
                    reason,
                    M1TrustRegionRefinementGuardStage::Accumulation,
                    row,
                    column + 1,
                    Some(refinement_face_index(column)),
                    &counters,
                )
            })?;
        }
        residual[row] = refinement_dot2_add(prepared.weighted_residual[row], sum, &mut counters)
            .map_err(|reason| {
                refusal(
                    reason,
                    M1TrustRegionRefinementGuardStage::Accumulation,
                    row,
                    0,
                    None,
                    &counters,
                )
            })?;
    }
    Ok((residual, counters))
}

fn refinement_second_residual(
    prepared: &PreparedSubproblem,
    p: &[f64; 21],
) -> Result<([f64; 21], RefinementDot2Counters), RefinementDot2Refusal> {
    let mut residual = [0.0; 21];
    let mut counters = RefinementDot2Counters::default();
    for (row, residual_entry) in residual.iter_mut().enumerate() {
        let mut terms = [0.0; 22];
        let mut weights = [0.0; 22];
        terms[0] = prepared.weighted_residual[row];
        weights[0] = 1.0;
        terms[1..].copy_from_slice(&prepared.weighted_matrix[row]);
        weights[1..].copy_from_slice(p);
        match m1_trust_region_refinement_dot2_for_test(terms, weights) {
            Ok(observation) => {
                counters.arithmetic += observation.arithmetic;
                counters.guards += observation.guards;
                counters.exceptional_guards += observation.exceptional_guards;
                counters.signed_zero_values += observation.signed_zero_values;
                *residual_entry = observation.value;
            }
            Err(refusal) => {
                counters.arithmetic += refusal.arithmetic;
                counters.guards += refusal.guards;
                counters.exceptional_guards += refusal.exceptional_guards;
                counters.signed_zero_values += refusal.signed_zero_values;
                return Err(RefinementDot2Refusal {
                    reason: refusal.reason,
                    guard_stage: refusal.guard_stage,
                    row: Some(refinement_face_index(row)),
                    term: refusal.term,
                    coordinate: refusal.coordinate,
                    arithmetic: counters.arithmetic,
                    guards: counters.guards,
                    exceptional_guards: counters.exceptional_guards,
                    signed_zero_values: counters.signed_zero_values,
                });
            }
        }
    }
    Ok((residual, counters))
}

fn refinement_reserve_work(
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    free_len: usize,
    scalar_before: u64,
    guards_before: u64,
    lambda: f64,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    let (required_scalar, required_guards) = if lambda.is_finite() && lambda > 0.0 {
        bvls04_required_work(free_len)
    } else {
        refinement_required_work(free_len)
    };
    state.refinement_work.attempted_entries += 1;
    let eligibility_scalar = state.refinement_work.scalar_operations - scalar_before;
    let eligibility_guards = state.refinement_work.guard_events - guards_before;
    let Some(remaining_scalar) = required_scalar.checked_sub(eligibility_scalar) else {
        state.refinement_work.denied_entries += 1;
        #[cfg(test)]
        refinement_observe(|trace| {
            trace.reservation_denial_owner = Some(M1TrustRegionBvls04ReservationOwner::Scalar);
        });
        return Err(state_refusal(
            M1TrustRegionRefusalKind::WorkCap,
            state,
            prepared.raw_max,
        ));
    };
    let Some(remaining_guards) = required_guards.checked_sub(eligibility_guards) else {
        state.refinement_work.denied_entries += 1;
        #[cfg(test)]
        refinement_observe(|trace| {
            trace.reservation_denial_owner = Some(M1TrustRegionBvls04ReservationOwner::Guard);
        });
        return Err(state_refusal(
            M1TrustRegionRefusalKind::WorkCap,
            state,
            prepared.raw_max,
        ));
    };
    let scalar_refused =
        state.refinement_work.scalar_operations + remaining_scalar > REFINEMENT_SCALAR_CAP;
    let guard_refused =
        state.refinement_work.guard_events + remaining_guards > REFINEMENT_GUARD_CAP;
    if scalar_refused || guard_refused {
        state.refinement_work.denied_entries += 1;
        #[cfg(test)]
        refinement_observe(|trace| {
            trace.reservation_denial_owner = Some(if scalar_refused {
                M1TrustRegionBvls04ReservationOwner::Scalar
            } else {
                M1TrustRegionBvls04ReservationOwner::Guard
            });
        });
        return Err(state_refusal(
            M1TrustRegionRefusalKind::WorkCap,
            state,
            prepared.raw_max,
        ));
    }
    Ok(())
}

fn refinement_assemble_eligible_p0(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
) -> Result<[f64; 21], super::M1TrustRegionSubproblemRefusal> {
    let mut p0 =
        refinement_p0(&state.p, solution, Some(&mut state.refinement_work)).map_err(|_| {
            refinement_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                M1TrustRegionRefinementReason::FactorOutput,
                RefinementFailureSite {
                    correction_position: None,
                    guard_stage: M1TrustRegionRefinementGuardStage::P0AssemblyEquality,
                    row: None,
                    term: None,
                    coordinate: None,
                    scratch_box_feasible: None,
                },
            )
        })?;
    #[cfg(test)]
    let _ = refinement_mutate(0, &mut p0);
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p0 = Some(p0);
        trace.lower_mask_p0 = Some(state.lower_active);
        trace.upper_mask_p0 = Some(state.upper_active);
    });
    Ok(p0)
}

fn refinement_check_positive_p0_radii(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    p0: &[f64; 21],
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    let full_ids: Vec<usize> = (0..21).collect();
    let (full_norm2, full_norm) =
        bvls04_ordered_norm(p0, &full_ids, &mut state.refinement_work, "p0_full").map_err(
            |reason| {
                refinement_dot2_metadata_refusal(
                    state,
                    prepared.raw_max,
                    solution,
                    input.initial_radius,
                    RefinementFailureSite {
                        correction_position: None,
                        guard_stage: M1TrustRegionRefinementGuardStage::P0FullRadius,
                        row: None,
                        term: None,
                        coordinate: None,
                        scratch_box_feasible: None,
                    },
                    reason,
                )
            },
        )?;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p0_full_norm2 = Some(full_norm2);
        trace.p0_full_norm = Some(full_norm);
    });
    state.refinement_work.guard();
    if full_norm > input.initial_radius {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            RefinementFailureSite {
                correction_position: None,
                guard_stage: M1TrustRegionRefinementGuardStage::P0FullRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: None,
            },
        ));
    }
    let (free_norm2, free_norm) = bvls04_ordered_norm(
        p0,
        &solution.free_ids,
        &mut state.refinement_work,
        "p0_free",
    )
    .map_err(|reason| {
        refinement_dot2_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            RefinementFailureSite {
                correction_position: None,
                guard_stage: M1TrustRegionRefinementGuardStage::P0ReducedRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: None,
            },
            reason,
        )
    })?;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p0_reduced_norm2 = Some(free_norm2);
        trace.p0_reduced_norm = Some(free_norm);
    });
    state.refinement_work.guard();
    if free_norm > solution.radius {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            RefinementFailureSite {
                correction_position: None,
                guard_stage: M1TrustRegionRefinementGuardStage::P0ReducedRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: None,
            },
        ));
    }
    Ok(())
}

fn refinement_record_p0_eligibility_and_reserve(
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    reservation_scalar_before: u64,
    reservation_guards_before: u64,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.eligibility_scalar_operations =
            Some(state.refinement_work.scalar_operations - reservation_scalar_before);
        trace.eligibility_guard_events =
            Some(state.refinement_work.guard_events - reservation_guards_before);
    });
    refinement_reserve_work(
        prepared,
        state,
        solution.free_ids.len(),
        reservation_scalar_before,
        reservation_guards_before,
        solution.trace.lambda,
    )
}

fn refinement_eligible_p0(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    reservation_scalar_before: u64,
    reservation_guards_before: u64,
) -> Result<Option<[f64; 21]>, super::M1TrustRegionSubproblemRefusal> {
    if solution.trace.lambda != 0.0
        && !(solution.trace.lambda.is_finite() && solution.trace.lambda > 0.0)
    {
        return Ok(None);
    }
    let p0 = refinement_assemble_eligible_p0(input, prepared, state, solution)?;
    if solution.trace.lambda > 0.0 {
        let active =
            refinement_active_admit(&p0, &state.lower_active, &state.upper_active, &state.p);
        match active {
            Ok(counters) => state.refinement_work.absorb_dot2(counters),
            Err(refusal) => {
                state.refinement_work.absorb_dot2(RefinementDot2Counters {
                    arithmetic: refusal.arithmetic,
                    guards: refusal.guards,
                    exceptional_guards: refusal.exceptional_guards,
                    signed_zero_values: refusal.signed_zero_values,
                });
                return Err(refinement_dot2_metadata_refusal(
                    state,
                    prepared.raw_max,
                    solution,
                    input.initial_radius,
                    RefinementFailureSite {
                        correction_position: None,
                        guard_stage: refusal.guard_stage,
                        row: refusal.row,
                        term: refusal.term,
                        coordinate: refusal.coordinate,
                        scratch_box_feasible: None,
                    },
                    refusal.reason,
                ));
            }
        }
        // The sole eligible BVLS-04 route into the old crossing machinery is
        // an otherwise-valid original-box violation of a free coordinate.
        if refinement_box_admit(prepared, &p0, None, Some(&mut state.refinement_work)).is_some() {
            return Ok(None);
        }
    } else if refinement_box_admit(prepared, &p0, None, Some(&mut state.refinement_work)).is_some()
        || !refinement_eligibility_active_admit(
            &p0,
            &state.lower_active,
            &state.upper_active,
            &state.p,
            Some(&mut state.refinement_work),
        )
    {
        return Ok(None);
    }
    let p0_norm = if solution.trace.lambda == 0.0 {
        #[cfg(test)]
        let _norm_role = RefinementNormRoleScope::begin("p0_zero_lambda_eligibility");
        Some(
            lambda_norm(&p0, Some(&mut state.refinement_work)).map_err(|_| {
                refinement_metadata_refusal(
                    state,
                    prepared.raw_max,
                    solution,
                    input.initial_radius,
                    M1TrustRegionRefinementReason::NonfiniteOperand,
                    RefinementFailureSite {
                        correction_position: None,
                        guard_stage: M1TrustRegionRefinementGuardStage::OrderedNorm,
                        row: None,
                        term: None,
                        coordinate: None,
                        scratch_box_feasible: None,
                    },
                )
            })?,
        )
    } else {
        None
    };
    if let Some(p0_norm) = p0_norm {
        state.refinement_work.guard();
        if p0_norm.partial_cmp(&input.initial_radius) != Some(Ordering::Less) {
            return Ok(None);
        }
    }
    if solution.trace.lambda > 0.0 {
        refinement_check_positive_p0_radii(input, prepared, state, solution, &p0)?;
    }
    refinement_record_p0_eligibility_and_reserve(
        prepared,
        state,
        solution,
        reservation_scalar_before,
        reservation_guards_before,
    )?;
    Ok(Some(p0))
}

fn refinement_first_residual_for_face(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    p0: &[f64; 21],
) -> Result<[f64; 21], super::M1TrustRegionSubproblemRefusal> {
    match refinement_first_residual(prepared, p0) {
        Ok((residual, counters)) => {
            state.refinement_work.absorb_dot2(counters);
            state.refinement_work.first_residual_operations += u64::from(counters.arithmetic);
            #[cfg(test)]
            refinement_observe(|trace| trace.residual0 = Some(residual));
            Ok(residual)
        }
        Err(refusal) => {
            state.refinement_work.absorb_dot2(RefinementDot2Counters {
                arithmetic: refusal.arithmetic,
                guards: refusal.guards,
                exceptional_guards: refusal.exceptional_guards,
                signed_zero_values: refusal.signed_zero_values,
            });
            state.refinement_work.first_residual_operations += u64::from(refusal.arithmetic);
            Err(refinement_dot2_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::First),
                    guard_stage: refusal.guard_stage,
                    row: refusal.row,
                    term: refusal.term,
                    coordinate: refusal.coordinate,
                    scratch_box_feasible: None,
                },
                refusal.reason,
            ))
        }
    }
}

fn refinement_validate_factor_delta(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    delta: &[f64],
    correction_position: M1TrustRegionCorrectionPosition,
    scratch_box_feasible: Option<bool>,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    macro_rules! refusal {
        () => {
            refinement_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                M1TrustRegionRefinementReason::FactorOutput,
                RefinementFailureSite {
                    correction_position: Some(correction_position),
                    guard_stage: M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                    row: None,
                    term: None,
                    coordinate: None,
                    scratch_box_feasible,
                },
            )
        };
    }
    if delta.len() != solution.free_ids.len() {
        return Err(refusal!());
    }
    let mut factor_counters = RefinementDot2Counters::default();
    for &value in delta {
        if refinement_dot2_guard(value, &mut factor_counters).is_err() {
            state.refinement_work.absorb_dot2(factor_counters);
            return Err(refusal!());
        }
    }
    state.refinement_work.absorb_dot2(factor_counters);
    Ok(())
}

#[cfg(test)]
fn refinement_observe_factor_application(
    trace: &mut RefinementObservationTrace,
    factor: &JacobiFactor,
    h: Option<&[f64]>,
) {
    trace.factor_applications += 1;
    let identity = std::ptr::from_ref(factor) as usize;
    trace.factor_application_identities.push(identity);
    trace
        .factor_application_snapshots
        .push(RefinementFactorApplicationSnapshot {
            ordinal: trace.factor_applications,
            identity,
            h_bits: h.map(|values| values.iter().map(|value| value.to_bits()).collect()),
            inverse_t_bits: None,
            inverse_denominator_bits: None,
            inverse_z_bits: None,
            delta_bits: None,
        });
    trace.factor_output_copy_boundary = Some((
        trace.factor_applications,
        RefinementFactorOutputCopyBoundary::BeforeInverse,
    ));
}

fn refinement_apply_first_factor(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    factor: &JacobiFactor,
    residual0: [f64; 21],
    p0: &[f64; 21],
) -> Result<Vec<f64>, super::M1TrustRegionSubproblemRefusal> {
    let factor_before = state.refinement_work.scalar_operations;
    let delta0 = if solution.trace.lambda > 0.0 {
        let h0 = bvls04_ordinary_defect(
            factor,
            &residual0,
            p0,
            &solution.free_ids,
            solution.trace.lambda,
            &mut state.refinement_work,
        );
        #[cfg(test)]
        if let Ok(ref h0) = h0 {
            refinement_observe(|trace| trace.h0 = Some(h0.clone()));
        }
        let h0 = h0.map_err(|refusal| {
            refinement_dot2_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::First),
                    guard_stage: refusal.guard_stage,
                    row: refusal.row,
                    term: refusal.term,
                    coordinate: refusal.coordinate,
                    scratch_box_feasible: None,
                },
                refusal.reason,
            )
        })?;
        state.refinement_work.bvls04_factor_applications += 1;
        #[cfg(test)]
        refinement_observe(|trace| refinement_observe_factor_application(trace, factor, Some(&h0)));
        bvls04_shifted_inverse(
            factor,
            &h0,
            solution.trace.lambda,
            &mut state.refinement_work,
        )
    } else {
        #[cfg(test)]
        refinement_observe(|trace| refinement_observe_factor_application(trace, factor, None));
        lambda_step(
            factor,
            &residual0,
            0.0,
            Some(&mut state.refinement_work),
            LambdaProjection::Reconstruct,
        )
    };
    state.refinement_work.factor_application_operations +=
        state.refinement_work.scalar_operations - factor_before;
    let delta0 = delta0.map_err(|_| {
        refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FactorOutput,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage: M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: None,
            },
        )
    })?;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.delta0 = Some(delta0.clone());
        if let Some(snapshot) = trace.factor_application_snapshots.last_mut() {
            snapshot.delta_bits = Some(delta0.iter().map(|value| value.to_bits()).collect());
        }
        trace.factor_output_copy_boundary =
            Some((1, RefinementFactorOutputCopyBoundary::AfterDelta));
    });
    refinement_validate_factor_delta(
        input,
        prepared,
        state,
        solution,
        &delta0,
        M1TrustRegionCorrectionPosition::First,
        None,
    )?;
    Ok(delta0)
}
fn refinement_apply_second_factor(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    factor: &JacobiFactor,
    residual1: [f64; 21],
    p1_state: (&[f64; 21], bool),
) -> Result<Vec<f64>, super::M1TrustRegionSubproblemRefusal> {
    let (p1, p1_box_feasible) = p1_state;
    let mut factor_before = state.refinement_work.scalar_operations;
    let delta1 = if solution.trace.lambda > 0.0 {
        let h1 = bvls04_dot2_defect(
            factor,
            &residual1,
            p1,
            &solution.free_ids,
            solution.trace.lambda,
            &mut state.refinement_work,
        )
        .map_err(|refusal| {
            refinement_dot2_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                    guard_stage: refusal.guard_stage,
                    row: refusal.row,
                    term: refusal.term,
                    coordinate: refusal.coordinate,
                    scratch_box_feasible: Some(p1_box_feasible),
                },
                refusal.reason,
            )
        })?;
        #[cfg(test)]
        refinement_observe(|trace| trace.h1 = Some(h1.clone()));
        factor_before = state.refinement_work.scalar_operations;
        state.refinement_work.bvls04_factor_applications += 1;
        #[cfg(test)]
        refinement_observe(|trace| refinement_observe_factor_application(trace, factor, Some(&h1)));
        bvls04_shifted_inverse(
            factor,
            &h1,
            solution.trace.lambda,
            &mut state.refinement_work,
        )
    } else {
        #[cfg(test)]
        refinement_observe(|trace| refinement_observe_factor_application(trace, factor, None));
        lambda_step(
            factor,
            &residual1,
            0.0,
            Some(&mut state.refinement_work),
            LambdaProjection::Reconstruct,
        )
    };
    state.refinement_work.factor_application_operations +=
        state.refinement_work.scalar_operations - factor_before;
    let delta1 = delta1.map_err(|_| {
        refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FactorOutput,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                guard_stage: M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        )
    })?;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.delta1 = Some(delta1.clone());
        if let Some(snapshot) = trace.factor_application_snapshots.last_mut() {
            snapshot.delta_bits = Some(delta1.iter().map(|value| value.to_bits()).collect());
        }
        trace.factor_output_copy_boundary =
            Some((2, RefinementFactorOutputCopyBoundary::AfterDelta));
    });
    refinement_validate_factor_delta(
        input,
        prepared,
        state,
        solution,
        &delta1,
        M1TrustRegionCorrectionPosition::Second,
        Some(p1_box_feasible),
    )?;
    Ok(delta1)
}

fn refinement_apply_first_update(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    p0: [f64; 21],
    delta0: &[f64],
) -> Result<RefinementScratch, super::M1TrustRegionSubproblemRefusal> {
    let mut scratch = RefinementScratch { p1: p0 };
    for (slot, &column) in solution.free_ids.iter().enumerate() {
        let mut counters = RefinementDot2Counters::default();
        #[cfg(test)] let (left,right)=BVLS04_POISON.with(|poison_slot| { let mut poison_slot=poison_slot.borrow_mut(); if matches!(*poison_slot,Some(M1TrustRegionBvls04Poison::CoordinateUpdateNonfinite(index)) if index == column) { *poison_slot=None; BVLS04_POISON_SITE.with(|site| site.set(Some(column))); BVLS04_POISON_CONSUMED.with(|seen| *seen.borrow_mut()=Some((f64::MAX.to_bits(),M1TrustRegionRefinementGuardStage::CoordinateUpdate))); (f64::MAX,f64::MAX) } else {(scratch.p1[column],delta0[slot])} });
        #[cfg(not(test))]
        let (left, right) = (scratch.p1[column], delta0[slot]);
        let updated = refinement_dot2_add(left, right, &mut counters);
        state.refinement_work.absorb_dot2(counters);
        state.refinement_work.coordinate_update_operations += u64::from(counters.arithmetic);
        scratch.p1[column] = updated.map_err(|_| {
            refinement_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                M1TrustRegionRefinementReason::CoordinateUpdate,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::First),
                    guard_stage: M1TrustRegionRefinementGuardStage::CoordinateUpdate,
                    row: None,
                    term: None,
                    coordinate: Some(refinement_face_index(column)),
                    scratch_box_feasible: None,
                },
            )
        })?;
    }
    Ok(scratch)
}

fn refinement_prepare_first_scratch(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &mut RefinementScratch,
) -> (Option<bool>, f64) {
    #[cfg(test)]
    let refinement_test_radius =
        refinement_mutate(1, &mut scratch.p1).unwrap_or(input.initial_radius);
    #[cfg(test)]
    BVLS04_POISON.with(|slot| {
        let mut slot = slot.borrow_mut();
        match *slot {
            Some(M1TrustRegionBvls04Poison::P1LowerBox(coordinate)) if coordinate < 21 => {
                let value = prepared.scaled_lower[coordinate] - 1.0;
                scratch.p1[coordinate] = value;
                *slot = None;
                BVLS04_POISON_CONSUMED.with(|seen| {
                    *seen.borrow_mut() = Some((
                        value.to_bits(),
                        M1TrustRegionRefinementGuardStage::ScratchBoxLower,
                    ));
                });
            }
            Some(M1TrustRegionBvls04Poison::P1UpperBox(coordinate)) if coordinate < 21 => {
                let value = prepared.scaled_upper[coordinate] + 1.0;
                scratch.p1[coordinate] = value;
                *slot = None;
                BVLS04_POISON_CONSUMED.with(|seen| {
                    *seen.borrow_mut() = Some((
                        value.to_bits(),
                        M1TrustRegionRefinementGuardStage::ScratchBoxUpper,
                    ));
                });
            }
            _ => {}
        }
    });
    #[cfg(not(test))]
    let refinement_test_radius = input.initial_radius;
    let p1_box_feasible = if solution.trace.lambda > 0.0 {
        None
    } else {
        Some(
            refinement_box_admit(
                prepared,
                &scratch.p1,
                Some(&solution.free_ids),
                Some(&mut state.refinement_work),
            )
            .is_none(),
        )
    };
    (p1_box_feasible, refinement_test_radius)
}

fn refinement_check_first_scratch_active(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &RefinementScratch,
    p1_box_feasible: Option<bool>,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    match refinement_active_admit(
        &scratch.p1,
        &state.lower_active,
        &state.upper_active,
        &state.p,
    ) {
        Ok(counters) => state.refinement_work.absorb_dot2(counters),
        Err(refusal) => {
            state.refinement_work.absorb_dot2(RefinementDot2Counters {
                arithmetic: refusal.arithmetic,
                guards: refusal.guards,
                exceptional_guards: refusal.exceptional_guards,
                signed_zero_values: refusal.signed_zero_values,
            });
            return Err(refinement_dot2_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::First),
                    guard_stage: refusal.guard_stage,
                    row: refusal.row,
                    term: refusal.term,
                    coordinate: refusal.coordinate,
                    scratch_box_feasible: p1_box_feasible,
                },
                refusal.reason,
            ));
        }
    }
    Ok(())
}

fn refinement_first_scratch_box_feasible(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &RefinementScratch,
    prior_box_feasible: Option<bool>,
) -> Result<bool, super::M1TrustRegionSubproblemRefusal> {
    let positive_lambda = solution.trace.lambda > 0.0;
    if !positive_lambda {
        return Ok(prior_box_feasible == Some(true));
    }
    if let Some((coordinate, stage)) = refinement_box_admit(
        prepared,
        &scratch.p1,
        None,
        Some(&mut state.refinement_work),
    ) {
        let guard_stage = match stage {
            M1TrustRegionRefinementGuardStage::FinalBoxLower => {
                M1TrustRegionRefinementGuardStage::ScratchBoxLower
            }
            _ => M1TrustRegionRefinementGuardStage::ScratchBoxUpper,
        };
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::ScratchBox,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage,
                row: None,
                term: None,
                coordinate: Some(coordinate),
                scratch_box_feasible: Some(false),
            },
        ));
    }
    Ok(true)
}

fn refinement_check_positive_first_scratch_full_radius(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &RefinementScratch,
    refinement_test_radius: f64,
    p1_box_feasible: bool,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    let full_ids: Vec<usize> = (0..21).collect();
    let mut full_p1 = scratch.p1;
    #[cfg(test)]
    BVLS04_POISON.with(|slot| {
        let mut slot = slot.borrow_mut();
        if let Some(M1TrustRegionBvls04Poison::P1FullNormNonfinite(coordinate)) = *slot {
            if coordinate < 21 {
                full_p1[coordinate] = f64::MAX;
                *slot = None;
                BVLS04_POISON_CONSUMED.with(|seen| {
                    *seen.borrow_mut() = Some((
                        f64::MAX.to_bits(),
                        M1TrustRegionRefinementGuardStage::ScratchFullRadius,
                    ));
                });
            }
        }
    });
    let (full_norm2, full_norm) =
        bvls04_ordered_norm(&full_p1, &full_ids, &mut state.refinement_work, "p1_full").map_err(
            |reason| {
                refinement_dot2_metadata_refusal(
                    state,
                    prepared.raw_max,
                    solution,
                    input.initial_radius,
                    RefinementFailureSite {
                        correction_position: Some(M1TrustRegionCorrectionPosition::First),
                        guard_stage: M1TrustRegionRefinementGuardStage::ScratchFullRadius,
                        row: None,
                        term: None,
                        coordinate: None,
                        scratch_box_feasible: Some(p1_box_feasible),
                    },
                    reason,
                )
            },
        )?;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p1_full_norm2 = Some(full_norm2);
        trace.p1_full_norm = Some(full_norm);
    });
    state.refinement_work.guard();
    if full_norm > refinement_test_radius {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::ScratchRadius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage: M1TrustRegionRefinementGuardStage::ScratchFullRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        ));
    }
    Ok(())
}

fn refinement_check_positive_first_scratch_reduced_radius(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &RefinementScratch,
    p1_box_feasible: bool,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    let (free_norm2, free_norm) = bvls04_ordered_norm(
        &scratch.p1,
        &solution.free_ids,
        &mut state.refinement_work,
        "p1_free",
    )
    .map_err(|reason| {
        refinement_dot2_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage: M1TrustRegionRefinementGuardStage::ScratchReducedRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
            reason,
        )
    })?;
    #[cfg(test)]
    let reduced_radius = BVLS04_POISON.with(|slot| {
        let mut slot = slot.borrow_mut();
        if matches!(
            *slot,
            Some(M1TrustRegionBvls04Poison::P1ReducedRadiusExcess)
        ) {
            let value = 0.5_f64;
            *slot = None;
            BVLS04_POISON_CONSUMED.with(|seen| {
                *seen.borrow_mut() = Some((
                    value.to_bits(),
                    M1TrustRegionRefinementGuardStage::ScratchReducedRadius,
                ));
            });
            value
        } else {
            solution.radius
        }
    });
    #[cfg(not(test))]
    let reduced_radius = solution.radius;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p1_reduced_norm2 = Some(free_norm2);
        trace.p1_reduced_norm = Some(free_norm);
    });
    state.refinement_work.guard();
    if free_norm > reduced_radius {
        let mut refusal = refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::ScratchRadius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage: M1TrustRegionRefinementGuardStage::ScratchReducedRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        );
        if let Some(metadata) = refusal.refinement.as_mut() {
            metadata.reduced_face_radius = reduced_radius;
        }
        return Err(refusal);
    }
    Ok(())
}

fn refinement_check_first_scratch(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &RefinementScratch,
    refinement_test_radius: f64,
    p1_box_feasible: Option<bool>,
) -> Result<bool, super::M1TrustRegionSubproblemRefusal> {
    #[cfg(test)]
    refinement_observe(|trace| {
        // p1 exists before the first active and box admissions; preserve that
        // reached prefix when either admission itself refuses.
        trace.p1 = Some(scratch.p1);
        trace.lower_mask_p1 = Some(state.lower_active);
        trace.upper_mask_p1 = Some(state.upper_active);
    });
    refinement_check_first_scratch_active(
        input,
        prepared,
        state,
        solution,
        scratch,
        p1_box_feasible,
    )?;
    let p1_box_feasible = refinement_first_scratch_box_feasible(
        input,
        prepared,
        state,
        solution,
        scratch,
        p1_box_feasible,
    )?;
    if solution.trace.lambda > 0.0 {
        refinement_check_positive_first_scratch_full_radius(
            input,
            prepared,
            state,
            solution,
            scratch,
            refinement_test_radius,
            p1_box_feasible,
        )?;
        refinement_check_positive_first_scratch_reduced_radius(
            input,
            prepared,
            state,
            solution,
            scratch,
            p1_box_feasible,
        )?;
        return Ok(true);
    }
    #[cfg(test)]
    let _norm_role = RefinementNormRoleScope::begin("p1_zero_lambda_scratch");
    let p1_norm = lambda_norm(&scratch.p1, Some(&mut state.refinement_work)).map_err(|_| {
        refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::NonfiniteOperand,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage: M1TrustRegionRefinementGuardStage::OrderedNorm,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        )
    })?;
    state.refinement_work.guard();
    if p1_norm > refinement_test_radius {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::ScratchRadius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage: M1TrustRegionRefinementGuardStage::RadiusComparison,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        ));
    }
    Ok(p1_box_feasible)
}

fn refinement_second_residual_for_scratch(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &RefinementScratch,
    p1_box_feasible: bool,
) -> Result<[f64; 21], super::M1TrustRegionSubproblemRefusal> {
    let residual1 = match refinement_second_residual(prepared, &scratch.p1) {
        Ok((residual, counters)) => {
            state.refinement_work.absorb_dot2(counters);
            state.refinement_work.second_dot2_operations += u64::from(counters.arithmetic);
            if solution.trace.lambda > 0.0 {
                state.refinement_work.bvls04_dot2_residual_rows += 21;
            }
            residual
        }
        Err(refusal) => {
            state.refinement_work.absorb_dot2(RefinementDot2Counters {
                arithmetic: refusal.arithmetic,
                guards: refusal.guards,
                exceptional_guards: refusal.exceptional_guards,
                signed_zero_values: refusal.signed_zero_values,
            });
            state.refinement_work.second_dot2_operations += u64::from(refusal.arithmetic);
            if solution.trace.lambda > 0.0 {
                // A Dot2 refusal carries aggregate counters; its completed row
                // count is intentionally not inferred from a reservation.
                state.refinement_work.bvls04_dot2_residual_rows +=
                    u32::from(refusal.row.unwrap_or(0)) + 1;
            }
            return Err(refinement_dot2_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                    guard_stage: refusal.guard_stage,
                    row: refusal.row,
                    term: refusal.term,
                    coordinate: refusal.coordinate,
                    scratch_box_feasible: Some(p1_box_feasible),
                },
                refusal.reason,
            ));
        }
    };
    #[cfg(test)]
    refinement_observe(|trace| trace.residual1 = Some(residual1));
    Ok(residual1)
}

fn refinement_apply_second_update(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    scratch: &RefinementScratch,
    delta1: &[f64],
    p1_box_feasible: bool,
) -> Result<[f64; 21], super::M1TrustRegionSubproblemRefusal> {
    let mut p2 = scratch.p1;
    for (slot, &column) in solution.free_ids.iter().enumerate() {
        let mut counters = RefinementDot2Counters::default();
        let updated = refinement_dot2_add(p2[column], delta1[slot], &mut counters);
        state.refinement_work.absorb_dot2(counters);
        state.refinement_work.coordinate_update_operations += u64::from(counters.arithmetic);
        let updated = updated.map_err(|_| {
            refinement_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                M1TrustRegionRefinementReason::CoordinateUpdate,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                    guard_stage: M1TrustRegionRefinementGuardStage::CoordinateUpdate,
                    row: None,
                    term: None,
                    coordinate: Some(refinement_face_index(column)),
                    scratch_box_feasible: Some(p1_box_feasible),
                },
            )
        })?;
        p2[column] = updated;
    }
    #[cfg(test)]
    BVLS04_POISON.with(|slot| {
        let mut slot = slot.borrow_mut();
        if let Some(M1TrustRegionBvls04Poison::P2ClosenessGap(coordinate)) = *slot {
            if coordinate < 21 {
                for &free in &solution.free_ids {
                    p2[free] *= 0.5;
                }
                *slot = None;
                BVLS04_POISON_CONSUMED.with(|seen| {
                    *seen.borrow_mut() = Some((
                        p2[coordinate].to_bits(),
                        M1TrustRegionRefinementGuardStage::FinalRadiusCloseness,
                    ));
                });
            }
        }
    });
    #[cfg(test)]
    let _ = refinement_mutate(2, &mut p2);
    Ok(p2)
}

fn refinement_check_final_candidate(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    p2: &[f64; 21],
    p1_box_feasible: bool,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    #[cfg(test)]
    refinement_observe(|trace| {
        // This is the reached seam immediately before active/box admission.
        trace.p2 = Some(*p2);
        trace.lower_mask_p2 = Some(state.lower_active);
        trace.upper_mask_p2 = Some(state.upper_active);
    });
    let p2_active = refinement_active_admit(p2, &state.lower_active, &state.upper_active, &state.p);
    match p2_active {
        Ok(counters) => state.refinement_work.absorb_dot2(counters),
        Err(refusal) => {
            state.refinement_work.absorb_dot2(RefinementDot2Counters {
                arithmetic: refusal.arithmetic,
                guards: refusal.guards,
                exceptional_guards: refusal.exceptional_guards,
                signed_zero_values: refusal.signed_zero_values,
            });
            return Err(refinement_dot2_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                    guard_stage: refusal.guard_stage,
                    row: refusal.row,
                    term: refusal.term,
                    coordinate: refusal.coordinate,
                    scratch_box_feasible: Some(p1_box_feasible),
                },
                refusal.reason,
            ));
        }
    }
    if let Some((coordinate, guard_stage)) =
        refinement_box_admit(prepared, p2, None, Some(&mut state.refinement_work))
    {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalBox,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                guard_stage,
                row: None,
                term: None,
                coordinate: Some(coordinate),
                scratch_box_feasible: Some(p1_box_feasible),
            },
        ));
    }
    Ok(())
}

fn refinement_final_full_radius(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    p2: [f64; 21],
    p1_box_feasible: bool,
) -> Result<(f64, f64), super::M1TrustRegionSubproblemRefusal> {
    let full_ids: Vec<usize> = (0..21).collect();
    let mut full_p2 = p2;
    #[cfg(test)]
    BVLS04_POISON.with(|slot| {
        let mut slot = slot.borrow_mut();
        if let Some(M1TrustRegionBvls04Poison::P2FullNormNonfinite(coordinate)) = *slot {
            if coordinate < 21 {
                full_p2[coordinate] = f64::MAX;
                *slot = None;
                BVLS04_POISON_CONSUMED.with(|seen| {
                    *seen.borrow_mut() = Some((
                        f64::MAX.to_bits(),
                        M1TrustRegionRefinementGuardStage::FinalFullRadius,
                    ));
                });
            }
        }
    });
    let (full_norm2, full_norm) =
        bvls04_ordered_norm(&full_p2, &full_ids, &mut state.refinement_work, "p2_full").map_err(
            |reason| {
                refinement_dot2_metadata_refusal(
                    state,
                    prepared.raw_max,
                    solution,
                    input.initial_radius,
                    RefinementFailureSite {
                        correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                        guard_stage: M1TrustRegionRefinementGuardStage::FinalFullRadius,
                        row: None,
                        term: None,
                        coordinate: None,
                        scratch_box_feasible: Some(p1_box_feasible),
                    },
                    reason,
                )
            },
        )?;
    state.refinement_work.guard();
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p2_full_norm2 = Some(full_norm2);
        trace.p2_full_norm = Some(full_norm);
    });
    if full_norm > input.initial_radius {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                guard_stage: M1TrustRegionRefinementGuardStage::FinalFullRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        ));
    }
    Ok((full_norm2, full_norm))
}

fn refinement_final_reduced_radius(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    p2: &[f64; 21],
    p1_box_feasible: bool,
) -> Result<(f64, f64), super::M1TrustRegionSubproblemRefusal> {
    let (free_norm2, free_norm) = bvls04_ordered_norm(
        p2,
        &solution.free_ids,
        &mut state.refinement_work,
        "p2_free",
    )
    .map_err(|reason| {
        refinement_dot2_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                guard_stage: M1TrustRegionRefinementGuardStage::FinalReducedRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
            reason,
        )
    })?;
    #[cfg(test)]
    let reduced_radius = BVLS04_POISON.with(|slot| {
        let mut slot = slot.borrow_mut();
        if matches!(
            *slot,
            Some(M1TrustRegionBvls04Poison::P2ReducedRadiusExcess)
        ) {
            let value = 0.5_f64;
            *slot = None;
            BVLS04_POISON_CONSUMED.with(|seen| {
                *seen.borrow_mut() = Some((
                    value.to_bits(),
                    M1TrustRegionRefinementGuardStage::FinalReducedRadius,
                ));
            });
            value
        } else {
            solution.radius
        }
    });
    #[cfg(not(test))]
    let reduced_radius = solution.radius;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p2_reduced_norm2 = Some(free_norm2);
        trace.p2_reduced_norm = Some(free_norm);
        trace.remaining_radius = Some(reduced_radius);
    });
    state.refinement_work.guard();
    if free_norm > reduced_radius {
        let mut refusal = refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                guard_stage: M1TrustRegionRefinementGuardStage::FinalReducedRadius,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        );
        if let Some(metadata) = refusal.refinement.as_mut() {
            metadata.reduced_face_radius = reduced_radius;
        }
        return Err(refusal);
    }
    Ok((free_norm2, free_norm))
}

fn refinement_install_final_step(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &mut FaceSolution,
    p2: &[f64; 21],
    p1_box_feasible: bool,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    for (slot, &column) in solution.free_ids.iter().enumerate() {
        state.refinement_work.guard();
        solution.trace.step[slot] = p2[column];
        if solution.trace.step[slot].to_bits() != p2[column].to_bits() {
            return Err(refinement_metadata_refusal(
                state,
                prepared.raw_max,
                solution,
                input.initial_radius,
                M1TrustRegionRefinementReason::CoordinateUpdate,
                RefinementFailureSite {
                    correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                    guard_stage: M1TrustRegionRefinementGuardStage::FinalInstallEquality,
                    row: None,
                    term: None,
                    coordinate: Some(refinement_face_index(column)),
                    scratch_box_feasible: Some(p1_box_feasible),
                },
            ));
        }
    }
    solution.refined = true;
    Ok(())
}

fn refinement_check_zero_lambda_final_radius(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    p2: &[f64; 21],
    p1_box_feasible: bool,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    #[cfg(test)]
    let _norm_role = RefinementNormRoleScope::begin("p2_zero_lambda_final");
    let p2_norm = lambda_norm(p2, Some(&mut state.refinement_work)).map_err(|_| {
        refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                guard_stage: M1TrustRegionRefinementGuardStage::OrderedNorm,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        )
    })?;
    state.refinement_work.guard();
    if p2_norm > input.initial_radius {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::Second),
                guard_stage: M1TrustRegionRefinementGuardStage::RadiusComparison,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: Some(p1_box_feasible),
            },
        ));
    }
    Ok(())
}

fn refinement_final_radius_closeness_site(p1_box_feasible: bool) -> RefinementFailureSite {
    RefinementFailureSite {
        correction_position: Some(M1TrustRegionCorrectionPosition::Second),
        guard_stage: M1TrustRegionRefinementGuardStage::FinalRadiusCloseness,
        row: None,
        term: None,
        coordinate: None,
        scratch_box_feasible: Some(p1_box_feasible),
    }
}

fn refinement_check_final_radius_closeness(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    free_norm: f64,
    p1_box_feasible: bool,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    macro_rules! guard {
        ($value:expr) => {
            if let Err(reason) = $value {
                return Err(refinement_dot2_metadata_refusal(
                    state,
                    prepared.raw_max,
                    solution,
                    input.initial_radius,
                    refinement_final_radius_closeness_site(p1_box_feasible),
                    reason,
                ));
            }
        };
    }
    guard!(bvls04_normal_or_signed_zero(
        solution.radius,
        &mut state.refinement_work
    ));
    guard!(bvls04_normal_or_signed_zero(
        free_norm,
        &mut state.refinement_work
    ));
    state.refinement_work.scalar();
    let gap = solution.radius - free_norm;
    #[cfg(test)]
    refinement_observe(|trace| trace.radius_gap = Some(gap));
    guard!(bvls04_normal_or_signed_zero(
        gap,
        &mut state.refinement_work
    ));
    state.refinement_work.scalar();
    let a = 2_f64.powi(-40) * solution.radius;
    guard!(bvls04_product_guard(
        2_f64.powi(-40),
        solution.radius,
        a,
        &mut state.refinement_work
    ));
    state.refinement_work.scalar();
    let b0 = 64.0 * f64::EPSILON;
    guard!(bvls04_normal_or_signed_zero(b0, &mut state.refinement_work));
    state.refinement_work.scalar();
    state.refinement_work.guard();
    let scale = solution.radius.max(1.0);
    let b = b0 * scale;
    guard!(bvls04_product_guard(
        b0,
        scale,
        b,
        &mut state.refinement_work
    ));
    state.refinement_work.guard();
    let tolerance = a.max(b);
    #[cfg(test)]
    refinement_observe(|trace| trace.radius_tolerance = Some(tolerance));
    guard!(bvls04_normal_or_signed_zero(
        tolerance,
        &mut state.refinement_work
    ));
    state.refinement_work.guard();
    if gap < 0.0 {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            refinement_final_radius_closeness_site(p1_box_feasible),
        ));
    }
    state.refinement_work.guard();
    if gap > tolerance {
        return Err(refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FinalRadius,
            refinement_final_radius_closeness_site(p1_box_feasible),
        ));
    }
    Ok(())
}

fn refinement_finalize_candidate(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &mut FaceSolution,
    p2: [f64; 21],
    p1_box_feasible: bool,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    if solution.trace.lambda == 0.0 {
        refinement_check_zero_lambda_final_radius(
            input,
            prepared,
            state,
            solution,
            &p2,
            p1_box_feasible,
        )?;
    }
    if solution.trace.lambda > 0.0 {
        let (_full_norm2, _full_norm) =
            refinement_final_full_radius(input, prepared, state, solution, p2, p1_box_feasible)?;
        let (_, free_norm) = refinement_final_reduced_radius(
            input,
            prepared,
            state,
            solution,
            &p2,
            p1_box_feasible,
        )?;
        refinement_check_final_radius_closeness(
            input,
            prepared,
            state,
            solution,
            free_norm,
            p1_box_feasible,
        )?;
    }
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.p2 = Some(p2);
        trace.lower_mask_p2 = Some(state.lower_active);
        trace.upper_mask_p2 = Some(state.upper_active);
        trace.lower_mask_exit = Some(state.lower_active);
        trace.upper_mask_exit = Some(state.upper_active);
    });
    refinement_install_final_step(input, prepared, state, solution, &p2, p1_box_feasible)
}

fn refinement_bvls04_factor_shape_valid(
    state: &mut SubproblemState,
    solution: &FaceSolution,
    m: usize,
) -> bool {
    let Some(factor) = solution.factor.as_ref() else {
        return false;
    };
    state.refinement_work.guard();
    if factor.a.len() != 21 {
        return false;
    }
    state.refinement_work.guard();
    if factor.b.len() != 21 {
        return false;
    }
    for row in 0..21 {
        state.refinement_work.guard();
        if (factor.a[row].len(), factor.b[row].len()) != (m, m) {
            return false;
        }
    }
    state.refinement_work.guard();
    if factor.v.len() != m {
        return false;
    }
    for row in &factor.v {
        state.refinement_work.guard();
        if row.len() != m {
            return false;
        }
    }
    state.refinement_work.guard();
    if factor.sigma.len() != m {
        return false;
    }
    state.refinement_work.guard();
    if factor.order.len() != m {
        return false;
    }
    state.refinement_work.guard();
    if solution.trace.step.len() != m {
        return false;
    }
    let mut order_seen = vec![false; m];
    for &order in &factor.order {
        state.refinement_work.guard();
        if order >= m || std::mem::replace(&mut order_seen[order], true) {
            return false;
        }
    }
    true
}

fn refinement_validate_bvls04_positive_structure(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    if solution.trace.lambda.is_finite() && solution.trace.lambda > 0.0 {
        macro_rules! invalid_structure {
            () => {
                return Err(refinement_metadata_refusal(
                    state,
                    prepared.raw_max,
                    solution,
                    input.initial_radius,
                    M1TrustRegionRefinementReason::FactorOutput,
                    RefinementFailureSite {
                        correction_position: None,
                        guard_stage: M1TrustRegionRefinementGuardStage::P0AssemblyEquality,
                        row: None,
                        term: None,
                        coordinate: None,
                        scratch_box_feasible: None,
                    },
                ));
            };
        }
        state.refinement_work.guard();
        state.refinement_work.bvls04_positive_entries += 1;
        let m = solution.free_ids.len();
        state.refinement_work.guard();
        if !(1..=21).contains(&m) {
            invalid_structure!();
        }
        let expected_free: Vec<usize> = state
            .free
            .iter()
            .enumerate()
            .filter_map(|(i, free)| (*free && !state.held[i]).then_some(i))
            .collect();
        state.refinement_work.guard();
        if expected_free.len() != m {
            invalid_structure!();
        }
        for (slot, &coordinate) in solution.free_ids.iter().enumerate() {
            state.refinement_work.guard();
            if coordinate >= 21 || expected_free.get(slot) != Some(&coordinate) {
                invalid_structure!();
            }
        }
        for coordinate in 0..21 {
            state.refinement_work.guard();
            let mask_count = usize::from(state.free[coordinate])
                + usize::from(state.lower_active[coordinate])
                + usize::from(state.upper_active[coordinate]);
            let expected_count = usize::from(
                input.lower[coordinate].partial_cmp(&input.upper[coordinate])
                    != Some(std::cmp::Ordering::Equal),
            );
            if mask_count != expected_count {
                invalid_structure!();
            }
        }
        if !refinement_bvls04_factor_shape_valid(state, solution, m) {
            invalid_structure!();
        }
        state.refinement_work.guard();
        if !solution.radius.is_finite() {
            invalid_structure!();
        }
        state.refinement_work.guard();
        if solution.radius <= 0.0 {
            invalid_structure!();
        }
    }
    Ok(())
}

fn refinement_bvls04_positive_eligibility_prefix(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
) -> Result<Option<[f64; 21]>, super::M1TrustRegionSubproblemRefusal> {
    let scalar_before = state.refinement_work.scalar_operations;
    let guards_before = state.refinement_work.guard_events;
    refinement_validate_bvls04_positive_structure(input, prepared, state, solution)?;
    let p0 = refinement_eligible_p0(
        input,
        prepared,
        state,
        solution,
        scalar_before,
        guards_before,
    )?;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.eligibility_scalar_operations =
            Some(state.refinement_work.scalar_operations - scalar_before);
        trace.eligibility_guard_events = Some(state.refinement_work.guard_events - guards_before);
    });
    Ok(p0)
}

fn refine_face_before_crossing_inner(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &mut FaceSolution,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    let Some(p0) = refinement_bvls04_positive_eligibility_prefix(input, prepared, state, solution)?
    else {
        return Ok(());
    };
    let factor = solution.factor.as_ref().ok_or_else(|| {
        refinement_metadata_refusal(
            state,
            prepared.raw_max,
            solution,
            input.initial_radius,
            M1TrustRegionRefinementReason::FactorOutput,
            RefinementFailureSite {
                correction_position: Some(M1TrustRegionCorrectionPosition::First),
                guard_stage: M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                row: None,
                term: None,
                coordinate: None,
                scratch_box_feasible: None,
            },
        )
    })?;
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.factor_identity = Some(std::ptr::from_ref(factor) as usize);
    });
    let residual0 = refinement_first_residual_for_face(input, prepared, state, solution, &p0)?;
    let delta0 =
        refinement_apply_first_factor(input, prepared, state, solution, factor, residual0, &p0)?;
    let mut scratch = refinement_apply_first_update(input, prepared, state, solution, p0, &delta0)?;
    let (p1_box_feasible, refinement_test_radius) =
        refinement_prepare_first_scratch(input, prepared, state, solution, &mut scratch);
    let p1_box_feasible = refinement_check_first_scratch(
        input,
        prepared,
        state,
        solution,
        &scratch,
        refinement_test_radius,
        p1_box_feasible,
    )?;
    let residual1 = refinement_second_residual_for_scratch(
        input,
        prepared,
        state,
        solution,
        &scratch,
        p1_box_feasible,
    )?;
    let delta1 = refinement_apply_second_factor(
        input,
        prepared,
        state,
        solution,
        factor,
        residual1,
        (&scratch.p1, p1_box_feasible),
    )?;
    let p2 = refinement_apply_second_update(
        input,
        prepared,
        state,
        solution,
        &scratch,
        &delta1,
        p1_box_feasible,
    )?;
    refinement_check_final_candidate(input, prepared, state, solution, &p2, p1_box_feasible)?;
    refinement_finalize_candidate(input, prepared, state, solution, p2, p1_box_feasible)
}

fn refine_face_before_crossing(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &mut FaceSolution,
) -> Result<(), super::M1TrustRegionSubproblemRefusal> {
    #[cfg(test)]
    refinement_observe(|trace| *trace = RefinementObservationTrace::default());
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.face_free_ids = Some(solution.free_ids.clone());
        trace.factor_order = solution.factor.as_ref().map(|factor| factor.order.clone());
        trace.factor_a = solution.factor.as_ref().map(|factor| factor.a.clone());
        trace.factor_v = solution.factor.as_ref().map(|factor| factor.v.clone());
        trace.factor_sigma = solution.factor.as_ref().map(|factor| factor.sigma.clone());
        trace.weighted_residual = Some(prepared.weighted_residual.clone());
        trace.weighted_matrix = Some(prepared.weighted_matrix.clone());
        trace.scaled_lower_bits = Some(prepared.scaled_lower.map(f64::to_bits));
        trace.scaled_upper_bits = Some(prepared.scaled_upper.map(f64::to_bits));
        trace.lambda_bits = Some(solution.trace.lambda.to_bits());
        trace.reduced_face_radius_bits = Some(solution.radius.to_bits());
        trace.free_mask = Some(state.free);
        trace.held_mask = Some(state.held);
        trace.live_state_entry = Some(state.p.map(f64::to_bits));
    });
    let result = refine_face_before_crossing_inner(input, prepared, state, solution);
    #[cfg(test)]
    refinement_observe(|trace| {
        trace.live_state_exit = Some(state.p.map(f64::to_bits));
        trace.lower_mask_exit = Some(state.lower_active);
        trace.upper_mask_exit = Some(state.upper_active);
        trace.work = Some(state_work_observation(state));
        trace.terminal_refusal = result.as_ref().err().cloned().map(Box::new);
    });
    result
}

fn activate_first_crossing(
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
) -> Result<bool, super::M1TrustRegionSubproblemRefusal> {
    let previous_p = state.p;
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let lower_before = state.lower_active;
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let upper_before = state.upper_active;
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let free_before = state.free;
    for (slot, &col) in solution.free_ids.iter().enumerate() {
        state.p[col] = solution.trace.step[slot];
    }
    let crossing = first_crossing(
        &state.p,
        &previous_p,
        &solution.free_ids,
        &prepared.scaled_lower,
        &prepared.scaled_upper,
    )
    .map_err(|kind| state_refusal(kind, state, prepared.raw_max))?;
    let Some((theta, col, is_lower)) = crossing else {
        return Ok(false);
    };
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let candidate_p = state.p;
    if state.completed_pivots >= 42 {
        #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
        {
            capture_activation(
                state,
                solution,
                previous_p,
                candidate_p,
                (lower_before, upper_before, free_before),
                (theta, col, is_lower),
                false,
            );
            capture_refusal(
                "activate-first-crossing",
                M1TrustRegionRefusalKind::FacePivotLimit,
                state,
                prepared,
            );
        }
        return Err(state_refusal(
            M1TrustRegionRefusalKind::FacePivotLimit,
            state,
            prepared.raw_max,
        ));
    }
    for &id in &solution.free_ids {
        state.p[id] = previous_p[id] + theta * (state.p[id] - previous_p[id]);
        if !state.p[id].is_finite() {
            return Err(state_refusal(
                M1TrustRegionRefusalKind::SvdNonFinite,
                state,
                prepared.raw_max,
            ));
        }
    }
    state.p[col] = if is_lower {
        prepared.scaled_lower[col]
    } else {
        prepared.scaled_upper[col]
    };
    state.free[col] = false;
    state.lower_active[col] = is_lower;
    state.upper_active[col] = !is_lower;
    state.completed_pivots += 1;
    state.events.push(super::M1TrustRegionKktEvent {
        action: if is_lower {
            super::M1TrustRegionKktAction::ActivateLower
        } else {
            super::M1TrustRegionKktAction::ActivateUpper
        },
        selected_coordinate: col,
        lower_mask: state.lower_active,
        upper_mask: state.upper_active,
        free_mask: state.free,
        g: None,
        lambda_times_p: None,
        h: None,
    });
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    capture_activation(
        state,
        solution,
        previous_p,
        candidate_p,
        (lower_before, upper_before, free_before),
        (theta, col, is_lower),
        true,
    );
    Ok(true)
}

fn kkt_transition(
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
) -> Result<KktTransitionOutcome, super::M1TrustRegionSubproblemRefusal> {
    #[cfg(test)]
    BVLS04_KKT_ENTRIES.with(|entries| entries.set(entries.get() + 1));
    let lambda = solution.trace.lambda;
    let values_result = {
        let mut accounting = KktAccounting::tracked(&mut state.refinement_work, solution.refined);
        box_feasible_kkt_values_with_accounting(
            &prepared.weighted_matrix,
            &prepared.weighted_residual,
            &state.p,
            lambda,
            &mut accounting,
        )
    };
    let values = match values_result {
        Ok(values) => values,
        Err(failure) => {
            #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
            capture_optimality_failure(state, solution, prepared, None, None, failure);
            return Err(optimality_state_refusal(
                failure,
                state,
                prepared.raw_max,
                solution,
            ));
        }
    };
    let p = state.p;
    let lower_active = state.lower_active;
    let upper_active = state.upper_active;
    let initial_free = state.initial_free;
    let assessment_result = {
        let mut accounting = KktAccounting::tracked(&mut state.refinement_work, solution.refined);
        assess_optimality(
            prepared,
            &p,
            OptimalityMasks {
                lower_active: &lower_active,
                upper_active: &upper_active,
                initial_free: &initial_free,
            },
            &values,
            lambda,
            &mut accounting,
        )
    };
    let assessment = match assessment_result {
        Ok(assessment) => assessment,
        Err(failure) => {
            #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
            capture_optimality_failure(state, solution, prepared, Some(&values), None, failure);
            return Err(optimality_state_refusal(
                failure,
                state,
                prepared.raw_max,
                solution,
            ));
        }
    };
    finish_kkt_transition(prepared, state, solution, values, assessment)
}

fn finish_kkt_transition(
    prepared: &PreparedSubproblem,
    state: &mut SubproblemState,
    solution: &FaceSolution,
    values: KktValues,
    assessment: OptimalityAssessment,
) -> Result<KktTransitionOutcome, super::M1TrustRegionSubproblemRefusal> {
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let p_before = state.p;
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let lower_before = state.lower_active;
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let upper_before = state.upper_active;
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let free_before = state.free;
    if let Some((col, is_lower)) = assessment.release {
        if state.completed_pivots >= 42 {
            #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
            {
                capture_release(
                    state,
                    &ReleaseCapture {
                        solution,
                        prepared,
                        values: &values,
                        assessment: &assessment,
                        p_before,
                        masks_before: (lower_before, upper_before, free_before),
                        selected: (col, is_lower),
                        applied: false,
                    },
                );
                capture_refusal(
                    "kkt-release",
                    M1TrustRegionRefusalKind::FacePivotLimit,
                    state,
                    prepared,
                );
            }
            return Err(state_refusal(
                M1TrustRegionRefusalKind::FacePivotLimit,
                state,
                prepared.raw_max,
            ));
        }
        state.events.push(super::M1TrustRegionKktEvent {
            action: if is_lower {
                super::M1TrustRegionKktAction::ReleaseLower
            } else {
                super::M1TrustRegionKktAction::ReleaseUpper
            },
            selected_coordinate: col,
            lower_mask: state.lower_active,
            upper_mask: state.upper_active,
            free_mask: state.free,
            g: Some(values.gradient),
            lambda_times_p: Some(values.lambda_times_step),
            h: Some(values.h),
        });
        state.lower_active[col] = false;
        state.upper_active[col] = false;
        state.free[col] = true;
        state.completed_pivots += 1;
        #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
        capture_release(
            state,
            &ReleaseCapture {
                solution,
                prepared,
                values: &values,
                assessment: &assessment,
                p_before,
                masks_before: (lower_before, upper_before, free_before),
                selected: (col, is_lower),
                applied: true,
            },
        );
        return Ok(KktTransitionOutcome {
            values: None,
            observation: assessment.observation,
        });
    }
    if let Some(coordinate) = assessment.free_refusal {
        let failure = optimality_failure("optimality_free_stationarity", coordinate);
        #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
        capture_optimality_failure(
            state,
            solution,
            prepared,
            Some(&values),
            Some(&assessment),
            failure,
        );
        return Err(optimality_state_refusal(
            failure,
            state,
            prepared.raw_max,
            solution,
        ));
    }
    Ok(return_kkt_transition(
        state, solution, prepared, values, assessment,
    ))
}

fn return_kkt_transition(
    state: &mut SubproblemState,
    solution: &FaceSolution,
    prepared: &PreparedSubproblem,
    values: KktValues,
    assessment: OptimalityAssessment,
) -> KktTransitionOutcome {
    state.events.push(super::M1TrustRegionKktEvent {
        action: super::M1TrustRegionKktAction::Return,
        selected_coordinate: usize::MAX,
        lower_mask: state.lower_active,
        upper_mask: state.upper_active,
        free_mask: state.free,
        g: Some(values.gradient),
        lambda_times_p: Some(values.lambda_times_step),
        h: Some(values.h),
    });
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    capture_return(state, solution, prepared, &values, &assessment);
    KktTransitionOutcome {
        values: Some(values),
        observation: assessment.observation,
    }
}

#[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
fn begin_face_pivot_capture(
    input: &super::M1TrustRegionSubproblemInput,
    prepared: &PreparedSubproblem,
) {
    if FACE_PIVOT_CAPTURE_ENABLED
        .try_with(Cell::get)
        .unwrap_or(false)
    {
        let _ = FACE_PIVOT_CAPTURE.try_with(|cell| {
            if let Ok(mut slot) = cell.try_borrow_mut() {
                let accepted_installs = slot
                    .as_ref()
                    .map_or_else(Vec::new, |prior| prior.accepted_installs.clone());
                let post_update_admissions = slot
                    .as_ref()
                    .map_or_else(Vec::new, |prior| prior.post_update_admissions.clone());
                let lifecycle = slot
                    .as_ref()
                    .map_or_else(Vec::new, |prior| prior.lifecycle.clone());
                let bvls05_lifecycle = slot
                    .as_ref()
                    .map_or_else(Vec::new, |prior| prior.bvls05_lifecycle.clone());
                let completed_subproblems = slot
                    .as_ref()
                    .map_or_else(Vec::new, |prior| prior.completed_subproblems.clone());
                let operations = slot
                    .as_ref()
                    .map_or_else(Vec::new, |prior| prior.operations.clone());
                *slot = Some(M1FacePivotCapture {
                    base: input.base,
                    raw_residual: input.raw_residual,
                    raw_jacobian: input.raw_jacobian,
                    normalizers: input.normalizers,
                    scales: input.scales,
                    lower: input.lower,
                    upper: input.upper,
                    weighted_residual: prepared.weighted_residual.clone(),
                    weighted_matrix: prepared.weighted_matrix.clone(),
                    initial_radius: input.initial_radius,
                    completed_subproblems,
                    operations,
                    accepted_installs,
                    post_update_admissions,
                    lifecycle,
                    bvls05_lifecycle,
                    rank_refusal_factor: None,
                    refusal: None,
                });
            }
        });
    }
}

pub(crate) fn solve_subproblem(
    input: &super::M1TrustRegionSubproblemInput,
) -> Result<super::M1TrustRegionSubproblemObservation, super::M1TrustRegionSubproblemRefusal> {
    #[cfg(test)]
    let mut certificate = None;
    #[cfg(test)]
    return solve_subproblem_with_certificate(input, &mut certificate);
    #[cfg(not(test))]
    unreachable!()
}

#[cfg(test)]
pub(crate) fn solve_subproblem_with_certificate(
    input: &super::M1TrustRegionSubproblemInput,
    certificate_cache: &mut Option<M1TrustRegionBvls05Certificate>,
) -> Result<super::M1TrustRegionSubproblemObservation, super::M1TrustRegionSubproblemRefusal> {
    const N: usize = 21;
    let capture_armed = REFUSAL_CAPTURE_ARMED.with(|armed| armed.replace(false));
    let _refinement_observation = capture_armed.then(RefinementObservationScope::begin);
    let _refusal_capture = RefusalCaptureScope::begin_armed(input, capture_armed);
    let prepared = prepare_subproblem(input).map_err(|refusal| *refusal)?;
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    begin_face_pivot_capture(input, &prepared);
    let mut state = SubproblemState::new(input);
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    let bvls05_reused = certificate_cache.is_some();
    bvls05_admit_state(input, &prepared, &mut state, certificate_cache);
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    capture_bvls05_admission(input, &state, bvls05_reused);
    loop {
        let mut solution = match solve_face(input, &prepared, &mut state) {
            Ok(solution) => solution,
            Err(refusal) => {
                #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
                capture_refusal("face-factorization", refusal.kind, &mut state, &prepared);
                return Err(refusal);
            }
        };
        refine_face_before_crossing(input, &prepared, &mut state, &mut solution)?;
        if activate_first_crossing(&prepared, &mut state, &solution)? {
            continue;
        }
        let transition = kkt_transition(&prepared, &mut state, &solution)?;
        let Some(values) = transition.values else {
            continue;
        };
        let mut candidate = candidate_coordinates(input, &state.p).ok_or_else(|| {
            state_refusal(
                M1TrustRegionRefusalKind::SvdNonFinite,
                &state,
                prepared.raw_max,
            )
        })?;
        #[cfg(test)]
        {
            (state.p, candidate) = bvls05_scatter_held(
                input.base,
                state.held,
                state.p,
                candidate,
                &mut state.bvls05_work,
            );
        }
        #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
        capture_successful_subproblem(&state);
        return Ok(super::M1TrustRegionSubproblemObservation {
            optimality_observation: Some(transition.observation),
            initial_face_step: [0.0; N],
            base_coordinates: input.base,
            candidate_coordinates: candidate,
            initial_lower_mask: [false; N],
            initial_upper_mask: [false; N],
            initial_free_mask: state.initial_free,
            scaled_step: state.p,
            final_residual: values.residual,
            final_g: values.gradient,
            final_lambda_times_p: values.lambda_times_step,
            final_h: values.h,
            lambda: solution.trace.lambda,
            work: state_work_observation(&state),
            event_trace: state.events,
            entered_svd_factorizations: state.entered,
            completed_face_pivots: state.completed_pivots,
            raw_jacobian_columns: raw_jacobian_columns(input),
            active_lower: state.lower_active,
            active_upper: state.upper_active,
            refinement_scalar_operations: state.refinement_work.scalar_operations,
            refinement_guard_events: state.refinement_work.guard_events,
            refinement_attempted_entries: state.refinement_work.attempted_entries,
            refinement_denied_entries: state.refinement_work.denied_entries,
        });
    }
}

pub(crate) fn m1_trust_region_solve_subproblem_for_test(
    _input: &super::M1CoupledColumnInput,
    _trial: &super::M1CoupledColumnTrial,
    input: &super::M1TrustRegionSubproblemInput,
) -> Result<super::M1TrustRegionSubproblemObservation, super::M1TrustRegionSubproblemRefusal> {
    solve_subproblem(input)
}

#[cfg(test)]
pub(crate) fn m1_trust_region_kkt_transition_for_test(
    weighted_matrix: Vec<Vec<f64>>,
    weighted_residual: [f64; 21],
    step: [f64; 21],
    lower_active: [bool; 21],
    upper_active: [bool; 21],
    free: [bool; 21],
    lambda: f64,
) -> Result<super::M1TrustRegionKktTransitionObservation, super::M1TrustRegionSubproblemRefusal> {
    assert!(
        (0..21).all(|index| {
            usize::from(lower_active[index])
                + usize::from(upper_active[index])
                + usize::from(free[index])
                == 1
        }),
        "test seam requires a complete active/free partition"
    );
    let mut scaled_lower = [f64::NEG_INFINITY; 21];
    let mut scaled_upper = [f64::INFINITY; 21];
    for index in 0..21 {
        if lower_active[index] {
            scaled_lower[index] = step[index];
        }
        if upper_active[index] {
            scaled_upper[index] = step[index];
        }
    }
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    seed_kkt_transition_capture_for_test(
        &weighted_matrix,
        &weighted_residual,
        scaled_lower,
        scaled_upper,
    );
    let prepared = PreparedSubproblem {
        raw_max: weighted_residual
            .iter()
            .fold(0.0_f64, |maximum, value| maximum.max(value.abs())),
        weighted_residual: weighted_residual.to_vec(),
        weighted_matrix,
        scaled_lower,
        scaled_upper,
    };
    let mut state = SubproblemState {
        p: step,
        lower_active,
        upper_active,
        free,
        initial_free: [true; 21],
        held: [false; 21],
        bvls05_inspected: false,
        bvls05_work: super::M1TrustRegionWorkObservation::default(),
        events: Vec::new(),
        entered: 1,
        completed_pivots: 0,
        completed_sweeps: 0,
        last_face_radius: None,
        total_jacobi_sweeps: 0,
        refinement_work: RefinementWorkLedger::default(),
    };
    let solution = FaceSolution {
        free_ids: (0..21).filter(|&index| free[index]).collect(),
        trace: LambdaTrace {
            lambda,
            ..LambdaTrace::default()
        },
        refined: false,
        factor: None,
        radius: 1.0,
    };
    let transition = kkt_transition(&prepared, &mut state, &solution)?;
    Ok(super::M1TrustRegionKktTransitionObservation {
        action: state.events.last().map(|event| event.action),
        selected_coordinate: state.events.last().map(|event| event.selected_coordinate),
        optimality: Some(transition.observation),
    })
}

#[cfg(test)]
fn m1_trust_region_signed_zero_crossing_then_kkt_for_test(
    weighted_matrix: Vec<Vec<f64>>,
    weighted_residual: [f64; 21],
    crossing_step: [f64; 21],
) -> Result<(f64, Vec<super::M1TrustRegionKktAction>), super::M1TrustRegionSubproblemRefusal> {
    let mut lower = [f64::NEG_INFINITY; 21];
    let upper = [f64::INFINITY; 21];
    lower[0] = 0.0;
    let prepared = PreparedSubproblem {
        raw_max: weighted_residual
            .iter()
            .fold(0.0_f64, |maximum, value| maximum.max(value.abs())),
        weighted_residual: weighted_residual.to_vec(),
        weighted_matrix,
        scaled_lower: lower,
        scaled_upper: upper,
    };
    let mut state = SubproblemState {
        p: [0.0; 21],
        lower_active: [false; 21],
        upper_active: [false; 21],
        free: [true; 21],
        initial_free: [true; 21],
        held: [false; 21],
        bvls05_inspected: false,
        bvls05_work: super::M1TrustRegionWorkObservation::default(),
        events: Vec::new(),
        entered: 1,
        completed_pivots: 0,
        completed_sweeps: 0,
        last_face_radius: None,
        total_jacobi_sweeps: 0,
        refinement_work: RefinementWorkLedger::default(),
    };
    let solution = FaceSolution {
        free_ids: (0..21).collect(),
        trace: LambdaTrace {
            lambda: 0.0,
            step: crossing_step.to_vec(),
            ..LambdaTrace::default()
        },
        refined: false,
        factor: None,
        radius: 1.0,
    };
    let theta = first_crossing(
        &crossing_step,
        &state.p,
        &solution.free_ids,
        &prepared.scaled_lower,
        &prepared.scaled_upper,
    )
    .map_err(|kind| state_refusal(kind, &state, prepared.raw_max))?
    .expect("negative candidate crosses lower bound")
    .0;
    assert!(activate_first_crossing(&prepared, &mut state, &solution)?);
    let _ = kkt_transition(&prepared, &mut state, &solution)?;
    Ok((
        theta,
        state.events.iter().map(|event| event.action).collect(),
    ))
}

#[cfg(test)]
mod finite_precision_controls {
    use super::{
        box_feasible_kkt_values, m1_trust_region_kkt_transition_for_test,
        m1_trust_region_signed_zero_crossing_then_kkt_for_test, upward_mul,
    };
    use crate::{
        M1TrustRegionKktAction, M1TrustRegionRefusalKind, M1TrustRegionSubproblemInput,
        M1TrustRegionTestWorkState,
    };
    use serde_json::Value;

    const RETAINED_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/face-pivot-observed-capture.json"
    ));
    const RETAINED_ORACLE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/finite-precision-correctness-oracle-retained-face.json"
    ));

    fn bit(value: &Value) -> f64 {
        f64::from_bits(
            u64::from_str_radix(value.as_str().expect("binary64 hex"), 16)
                .expect("valid binary64 bits"),
        )
    }

    fn vector(value: &Value) -> [f64; 21] {
        std::array::from_fn(|index| bit(&value[index]))
    }

    fn bits(values: [f64; 21]) -> [u64; 21] {
        values.map(f64::to_bits)
    }

    fn partition(lower: [bool; 21], upper: [bool; 21]) -> [bool; 21] {
        std::array::from_fn(|index| !lower[index] && !upper[index])
    }

    fn capture_return_input() -> M1TrustRegionSubproblemInput {
        let mut jacobian = [[0.0; 21]; 21];
        for (coordinate, row) in jacobian.iter_mut().enumerate() {
            row[coordinate] = 1.0;
        }
        M1TrustRegionSubproblemInput {
            raw_residual: [0.0; 21],
            raw_jacobian: jacobian,
            normalizers: [1.0; 21],
            scales: [1.0; 21],
            lower: [f64::NEG_INFINITY; 21],
            upper: [f64::INFINITY; 21],
            initial_radius: 1.0,
            base: [0.0; 21],
            test_work: M1TrustRegionTestWorkState::default(),
        }
    }

    fn capture_nonzero_return_input() -> M1TrustRegionSubproblemInput {
        let mut input = capture_return_input();
        input.raw_residual[0] = 0.25;
        input
    }

    #[test]
    fn retained_capture_uses_shared_ordered_kkt_operation_before_policy_change() {
        let capture: Value = serde_json::from_str(RETAINED_CAPTURE).expect("retained capture");
        let oracle: Value =
            serde_json::from_str(RETAINED_ORACLE).expect("independent retained oracle");
        let release = capture["operations"]
            .as_array()
            .expect("operation array")
            .iter()
            .find(|operation| operation["action"] == "release")
            .expect("recorded lower release");
        let matrix = capture["weighted_matrix"]
            .as_array()
            .expect("weighted matrix")
            .iter()
            .map(|row| vector(row).to_vec())
            .collect::<Vec<_>>();
        let values = box_feasible_kkt_values(
            &matrix,
            &vector(&capture["weighted_residual"]),
            &vector(&release["p_before"]),
            bit(&release["lambda"]),
        )
        .expect("shared KKT operation on retained finite operands");
        let recorded_h = vector(&release["h"]);
        assert_eq!(values.h.map(f64::to_bits), recorded_h.map(f64::to_bits));
        let lower = std::array::from_fn(|index| {
            release["lower_before"][index]
                .as_bool()
                .expect("lower mask")
        });
        let upper = std::array::from_fn(|index| {
            release["upper_before"][index]
                .as_bool()
                .expect("upper mask")
        });
        let transition = m1_trust_region_kkt_transition_for_test(
            matrix,
            vector(&capture["weighted_residual"]),
            vector(&release["p_before"]),
            lower,
            upper,
            partition(lower, upper),
            bit(&release["lambda"]),
        )
        .expect("shared retained transition");
        assert_eq!(
            transition.action,
            Some(M1TrustRegionKktAction::ReleaseLower)
        );
        let optimality = transition
            .optimality
            .expect("expected-red: 02 retained all-coordinate observation");
        assert_eq!(optimality.coordinates.len(), 21);
        for (coordinate, actual) in optimality.coordinates.iter().enumerate() {
            assert_eq!(actual.coordinate, coordinate);
        }
        let oracle_coordinates = oracle["coordinates"]
            .as_array()
            .expect("independent oracle coordinates");
        assert_eq!(oracle_coordinates.len(), 21);
        for coordinate in [5usize, 11usize] {
            let expected = &oracle_coordinates[coordinate];
            let actual = &optimality.coordinates[coordinate];
            assert_eq!(
                actual.h.to_bits(),
                bit(&expected["h_hat"]["bits"]).to_bits()
            );
            assert_eq!(
                actual.cbar.to_bits(),
                bit(&expected["cbar"]["bits"]).to_bits()
            );
            assert_eq!(
                actual.tau.to_bits(),
                bit(&expected["tau"]["bits"]).to_bits()
            );
            assert_eq!(
                actual.class,
                if coordinate == 5 {
                    crate::M1TrustRegionOptimalityClass::ReleaseLower
                } else {
                    crate::M1TrustRegionOptimalityClass::FreeRefuse
                }
            );
        }
    }

    #[test]
    fn expected_red_cancellation_band_must_not_release_on_sign_alone() {
        // A real shared KKT calculation gives a negative lower multiplier
        // through cancellation.  The reviewed 02 envelope retains it; this
        // assertion is intentionally red until the shared transition applies
        // that policy, rather than the current sign-only helper.
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        matrix[0][1] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = -1.0 - f64::EPSILON;
        let mut step = [0.0; 21];
        step[1] = 1.0;
        let lower = std::array::from_fn(|index| index == 0);
        let upper = [false; 21];
        assert_eq!(
            m1_trust_region_kkt_transition_for_test(
                matrix,
                residual,
                step,
                lower,
                upper,
                partition(lower, upper),
                0.0
            )
            .expect("shared KKT transition")
            .action,
            Some(M1TrustRegionKktAction::Return),
            "expected-red: reviewed 02 uncertainty-band decision replaces sign-only release"
        );
    }

    #[test]
    fn expected_red_upper_cancellation_band_must_not_release_on_sign_alone() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        matrix[0][1] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = 1.0 + f64::EPSILON;
        let mut step = [0.0; 21];
        step[1] = -1.0;
        let upper = std::array::from_fn(|index| index == 0);
        assert_eq!(
            m1_trust_region_kkt_transition_for_test(
                matrix.clone(),
                residual,
                step,
                [false; 21],
                upper,
                partition([false; 21], upper),
                0.0
            )
            .expect("shared upper transition")
            .action,
            Some(M1TrustRegionKktAction::Return),
            "expected-red: uncertainty-band upper multiplier is retained"
        );
    }

    #[test]
    fn resolvable_upper_violation_releases_through_shared_transition() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = 1.0;
        let upper = std::array::from_fn(|index| index == 0);
        assert_eq!(
            m1_trust_region_kkt_transition_for_test(
                matrix,
                residual,
                [0.0; 21],
                [false; 21],
                upper,
                partition([false; 21], upper),
                0.0,
            )
            .expect("shared resolvable upper transition")
            .action,
            Some(M1TrustRegionKktAction::ReleaseUpper)
        );
    }

    #[test]
    fn expected_red_release_ranking_uses_observed_ratio_not_multiplier_magnitude() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        matrix[1][1] = 1.0;
        matrix[2][0] = 100.0;
        matrix[2][2] = 1.0;
        for (coordinate, row) in matrix.iter_mut().enumerate().skip(3) {
            row[coordinate] = 1.0;
        }
        let mut residual = [0.0; 21];
        residual[0] = -2.0;
        residual[1] = -1.0;
        residual[2] = -1.0;
        let mut step = [0.0; 21];
        step[2] = 1.0;
        let lower = std::array::from_fn(|coordinate| coordinate < 2);
        let transition = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            step,
            lower,
            [false; 21],
            partition(lower, [false; 21]),
            0.0,
        )
        .expect("shared release-ranking transition");
        assert_eq!(
            transition.action,
            Some(M1TrustRegionKktAction::ReleaseLower)
        );
        assert_eq!(
            transition.selected_coordinate,
            Some(1),
            "expected-red: larger absolute multiplier at coordinate 0 has the smaller observed ratio"
        );
        let observation = transition
            .optimality
            .expect("expected-red: release-ranking optimality observation");
        let coordinate_zero = &observation.coordinates[0];
        let coordinate_one = &observation.coordinates[1];
        assert!(coordinate_zero.h.abs() > coordinate_one.h.abs());
        assert!(coordinate_zero.tau.is_normal());
        assert!(coordinate_one.tau.is_normal());
        assert!(
            coordinate_one.h.abs() / coordinate_one.tau
                > coordinate_zero.h.abs() / coordinate_zero.tau,
            "expected-red: shared observed thresholds order release ratios"
        );
    }

    #[test]
    fn expected_red_free_stationarity_must_refuse_from_shared_transition() {
        let mut free_matrix = vec![vec![0.0; 21]; 21];
        free_matrix[0][0] = 1.0;
        let mut free_residual = [0.0; 21];
        free_residual[0] = 1.0;
        let free = [true; 21];
        let refusal = m1_trust_region_kkt_transition_for_test(
            free_matrix,
            free_residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            free,
            0.0,
        )
        .expect_err("expected-red: materially nonstationary free coordinate must refuse");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_free_stationarity")
        );
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn shared_signed_zero_crossing_precedes_genuine_descent_release() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = -1.0;
        let mut step = [0.0; 21];
        step[0] = -f64::MIN_POSITIVE;
        let (theta, actions) =
            m1_trust_region_signed_zero_crossing_then_kkt_for_test(matrix, residual, step)
                .expect("shared signed-zero crossing and descent");
        assert_eq!(theta.to_bits(), (-0.0_f64).to_bits());
        assert_eq!(
            actions,
            vec![
                M1TrustRegionKktAction::ActivateLower,
                M1TrustRegionKktAction::ReleaseLower,
            ]
        );
    }

    #[test]
    fn shared_normal_nonfinite_and_overflow_kkt_operands_are_real_operations() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = 1.0;
        assert!(box_feasible_kkt_values(&matrix, &residual, &[0.0; 21], 0.0).is_ok());
        matrix[0][0] = f64::NAN;
        assert!(box_feasible_kkt_values(&matrix, &residual, &[0.0; 21], 0.0).is_err());
        matrix[0][0] = f64::MAX;
        residual[0] = f64::MAX;
        assert!(box_feasible_kkt_values(&matrix, &residual, &[0.0; 21], 0.0).is_err());
    }

    #[test]
    fn expected_red_nonfinite_kkt_operand_has_typed_optimality_refusal() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::NAN;
        let mut residual = [0.0; 21];
        residual[0] = 1.0;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("expected-red: nonfinite KKT operand must have 02 refusal metadata");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(refusal.optimality_reason, Some("optimality_nonfinite"));
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn expected_red_overflow_kkt_operand_has_typed_optimality_refusal() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::MAX;
        let mut residual = [0.0; 21];
        residual[0] = f64::MAX;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("expected-red: overflowing KKT product must have 02 refusal metadata");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(refusal.optimality_reason, Some("optimality_nonfinite"));
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn expected_red_negative_lambda_has_typed_optimality_refusal() {
        let refusal = m1_trust_region_kkt_transition_for_test(
            vec![vec![0.0; 21]; 21],
            [0.0; 21],
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            -1.0,
        )
        .expect_err("expected-red: negative lambda must have 02 refusal metadata");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_negative_lambda")
        );
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn expected_red_subnormal_kkt_operand_must_refuse() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::from_bits(1);
        let mut residual = [0.0; 21];
        residual[0] = 1.0;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("expected-red: nonzero subnormal KKT operand must refuse");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_non_normal_operand")
        );
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn expected_red_underflow_to_zero_kkt_product_must_refuse() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::MIN_POSITIVE;
        let mut residual = [0.0; 21];
        residual[0] = f64::MIN_POSITIVE;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err(
            "expected-red: nonzero normal operands whose KKT product underflows must refuse",
        );
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_underflow_to_zero")
        );
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn expected_red_subnormal_kkt_intermediate_must_refuse() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::MIN_POSITIVE;
        let mut residual = [0.0; 21];
        residual[0] = 0.5;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("expected-red: nonzero subnormal KKT intermediate must refuse");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_subnormal_intermediate")
        );
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn expected_red_zero_cbar_with_zero_h_is_an_explicit_02_observation() {
        let transition = m1_trust_region_kkt_transition_for_test(
            vec![vec![0.0; 21]; 21],
            [0.0; 21],
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect("shared zero KKT transition");
        let observation = transition
            .optimality
            .expect("expected-red: zero-Cbar 02 observation");
        let coordinate = observation
            .coordinates
            .iter()
            .find(|entry| entry.coordinate == 0)
            .expect("expected-red: zero-Cbar coordinate");
        assert_eq!(coordinate.h.to_bits(), 0.0f64.to_bits());
        assert_eq!(coordinate.cbar.to_bits(), 0.0f64.to_bits());
        assert_eq!(coordinate.tau.to_bits(), 0.0f64.to_bits());
        assert_eq!(
            coordinate.class,
            crate::M1TrustRegionOptimalityClass::FreePass
        );
    }

    #[test]
    fn expected_red_zero_identity_enclosure_records_no_scalar_arithmetic() {
        let transition = m1_trust_region_kkt_transition_for_test(
            vec![vec![0.0; 21]; 21],
            [0.0; 21],
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect("shared zero transition");
        assert_eq!(
            transition
                .optimality
                .expect("02 zero observation")
                .scalar_operations,
            0,
            "expected-red: skipped zero identities perform neither scalar arithmetic nor upward steps"
        );
    }

    #[test]
    fn expected_red_nonzero_enclosure_records_exact_scalar_arithmetic() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = 1.0;
        let lower = std::array::from_fn(|coordinate| coordinate == 0);
        let transition = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            lower,
            [false; 21],
            partition(lower, [false; 21]),
            0.0,
        )
        .expect("shared nonzero enclosure transition");
        let observation = transition.optimality.expect("02 nonzero observation");
        assert_eq!(observation.scalar_operations, 6);
        assert!(observation.scalar_operations <= 39_816);
    }

    #[test]
    fn expected_red_tau_subnormal_has_typed_optimality_refusal() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = f64::MIN_POSITIVE;
        let lower = std::array::from_fn(|coordinate| coordinate == 0);
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            lower,
            [false; 21],
            partition(lower, [false; 21]),
            0.0,
        )
        .expect_err("expected-red: subnormal tau must refuse with its stable reason");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_subnormal_intermediate")
        );
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn expected_red_upward_normal_operands_underflow_with_stable_reason() {
        let mut operations = 0;
        let failure = upward_mul(f64::MIN_POSITIVE, f64::MIN_POSITIVE, 0, &mut operations)
            .expect_err("expected-red: nonzero normal enclosure product underflows");
        assert_eq!(failure.reason, "optimality_underflow_to_zero");
        assert_eq!(failure.coordinate, 0);
        assert_eq!(operations, 1);
    }

    #[test]
    fn expected_red_cbar_overflow_has_typed_02_transition_metadata() {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::MAX;
        let mut residual = [0.0; 21];
        residual[0] = -f64::MAX;
        let mut step = [0.0; 21];
        step[0] = 1.0;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            step,
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("expected-red: 02 upward-enclosure transition refusal");
        assert_eq!(
            refusal.kind,
            M1TrustRegionRefusalKind::TrustRegionOptimalityIndeterminate
        );
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_upward_enclosure")
        );
        assert_eq!(refusal.optimality_coordinate, Some(0));
    }

    #[test]
    fn fixed_finite_bound_uses_shared_prepare_and_full_solve_metadata() {
        let mut jacobian = [[0.0; 21]; 21];
        jacobian[0][1] = 1.0;
        let mut lower = [0.0; 21];
        let mut upper = [0.0; 21];
        lower[1] = f64::NEG_INFINITY;
        upper[1] = f64::INFINITY;
        let result = super::solve_subproblem(&M1TrustRegionSubproblemInput {
            raw_residual: [
                1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0,
            ],
            raw_jacobian: jacobian,
            normalizers: [1.0; 21],
            scales: [1.0; 21],
            lower,
            upper,
            initial_radius: 2.0,
            base: [0.0; 21],
            test_work: M1TrustRegionTestWorkState::default(),
        })
        .expect("shared finite fixed-bound solve");
        assert!(!result.initial_free_mask[0]);
        let observation = result
            .optimality_observation
            .expect("expected-red: fixed coordinate has an explicit 02 observation");
        let fixed = observation
            .coordinates
            .iter()
            .find(|coordinate| coordinate.coordinate == 0)
            .expect("expected-red: fixed coordinate observation");
        assert_eq!(fixed.class, crate::M1TrustRegionOptimalityClass::Fixed);
        assert!(result.initial_free_mask[1]);
        assert_eq!(result.scaled_step[0].to_bits(), 0.0f64.to_bits());
        assert!(result.candidate_coordinates[0].is_finite());
        assert!(result.scaled_step[1].abs() <= 2.0);
    }

    #[test]
    fn expected_red_physical_distinct_bounds_that_collapse_when_scaled_are_free() {
        let mut jacobian = [[0.0; 21]; 21];
        jacobian[0][0] = f64::MIN_POSITIVE;
        for (coordinate, row) in jacobian.iter_mut().enumerate().skip(1) {
            row[coordinate] = 1.0;
        }
        let mut lower = [f64::NEG_INFINITY; 21];
        let mut upper = [f64::INFINITY; 21];
        let mut base = [0.0; 21];
        let mut scales = [1.0; 21];
        lower[0] = 1.0;
        upper[0] = 1.0f64.next_up();
        base[0] = 1.0;
        scales[0] = f64::MAX;
        let result = super::solve_subproblem(&M1TrustRegionSubproblemInput {
            raw_residual: [0.0; 21],
            raw_jacobian: jacobian,
            normalizers: [1.0; 21],
            scales,
            lower,
            upper,
            initial_radius: 1.0,
            base,
            test_work: M1TrustRegionTestWorkState::default(),
        })
        .expect("shared distinct physical-bound solve");
        let observation = result
            .optimality_observation
            .expect("02 physical-bound observation");
        assert_eq!(
            observation.coordinates[0].class,
            crate::M1TrustRegionOptimalityClass::FreePass,
            "expected-red: only physically equal bounds are fixed"
        );
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn expected_red_successful_return_capture_has_complete_02_operands() {
        let _scope = super::m1_face_pivot_capture_begin_for_test();
        let result =
            super::solve_subproblem(&capture_return_input()).expect("shared return capture solve");
        let capture = super::m1_face_pivot_capture_take_for_test()
            .expect("expected-red: successful return capture");
        let operation = capture
            .operations
            .iter()
            .find(|operation| operation.action == "kkt-return")
            .expect("expected-red: return operation");
        assert_eq!(bits(operation.p_before), bits(result.scaled_step));
        assert_eq!(operation.lower_before, result.active_lower);
        assert_eq!(operation.upper_before, result.active_upper);
        assert_eq!(operation.free_before, [true; 21]);
        assert_eq!(operation.radius.to_bits(), 1.0f64.to_bits());
        assert_eq!(operation.lambda, Some(result.lambda));
        assert_eq!(operation.free_ids, (0..21).collect::<Vec<_>>());
        assert_eq!(operation.residual, Some(result.final_residual));
        assert_eq!(operation.g, Some(result.final_g));
        assert_eq!(operation.lambda_times_p, Some(result.final_lambda_times_p));
        assert_eq!(operation.h, Some(result.final_h));
        let optimality = operation
            .optimality
            .as_ref()
            .expect("expected-red: return optimality observation");
        assert_eq!(optimality.coordinates.len(), 21);
        for (coordinate, observation) in optimality.coordinates.iter().enumerate() {
            assert_eq!(observation.coordinate, coordinate);
            assert_eq!(
                observation.class,
                crate::M1TrustRegionOptimalityClass::FreePass
            );
        }
        assert_eq!(optimality.scalar_operations, 0);
        assert_eq!(
            operation.entered_factorizations,
            result.entered_svd_factorizations
        );
        assert_eq!(operation.completed_pivots, result.completed_face_pivots);
        assert_eq!(
            result.refinement_scalar_operations,
            result.work.refinement_scalar_operations
        );
        assert_eq!(
            result.refinement_guard_events,
            result.work.refinement_guard_events
        );
        assert_eq!(
            u32::from(result.refinement_attempted_entries),
            result.work.refinement_attempted_entries
        );
        assert_eq!(
            u32::from(result.refinement_denied_entries),
            result.work.refinement_denied_entries
        );
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn rank_refusal_capture_copies_actual_first_face_factor_without_sorting() {
        let mut input = capture_return_input();
        input.raw_jacobian[0][1] = 1.0;
        input.raw_jacobian[1][1] = 0.0;
        let scope = super::m1_face_pivot_capture_begin_for_test();
        let refusal =
            super::solve_subproblem(&input).expect_err("duplicate first-face column refuses");
        let capture = super::m1_face_pivot_capture_take_for_test().expect("rank refusal capture");
        drop(scope);
        assert_eq!(refusal.kind, M1TrustRegionRefusalKind::RankDeficient);
        assert_eq!(capture.raw_jacobian, input.raw_jacobian);
        assert_eq!(capture.weighted_residual, vec![0.0; 21]);
        let json = super::m1_face_pivot_capture_json_for_test(Some(&capture));
        let parsed: serde_json::Value = serde_json::from_str(&json).expect("rank capture JSON");
        assert_eq!(parsed["refusal"]["factor"]["order"], serde_json::json!([]));
        assert_eq!(parsed["refusal"]["factor"]["order_computed"], false);
        assert!(parsed["refusal"]["factor"]["same_invocation_identity"].is_null());
        assert_eq!(
            parsed["refusal"]["factor"]["same_invocation_identity_available"],
            false
        );
        let refusal = capture.refusal.expect("captured first-face refusal");
        assert_eq!(refusal.kind, M1TrustRegionRefusalKind::RankDeficient);
        assert_eq!(refusal.free_ids, (0..21).collect::<Vec<_>>());
        assert_eq!(refusal.lower, [false; 21]);
        assert_eq!(refusal.upper, [false; 21]);
        assert_eq!(refusal.free, [true; 21]);
        assert_eq!(refusal.radius, Some(1.0));
        let factor = refusal.factor.expect("captured Jacobi factor");
        assert_eq!(factor.a, capture.weighted_matrix);
        assert_eq!(factor.sigma.len(), 21);
        assert_eq!(factor.order, Vec::<usize>::new());
        assert!(!factor.order_computed);
        assert!(factor.rank_max.is_some());
        assert!(factor.rank_threshold.is_some());
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn expected_red_capture_retains_ordered_return_records_across_real_subproblems() {
        let _scope = super::m1_face_pivot_capture_begin_for_test();
        let first =
            super::solve_subproblem(&capture_return_input()).expect("first shared return solve");
        let second = super::solve_subproblem(&capture_nonzero_return_input())
            .expect("second shared return solve");
        let capture = super::m1_face_pivot_capture_take_for_test()
            .expect("expected-red: combined return capture");
        let returns = capture
            .operations
            .iter()
            .filter(|operation| operation.action == "kkt-return")
            .collect::<Vec<_>>();
        assert_eq!(
            returns.len(),
            2,
            "expected-red: both subproblem returns persist"
        );
        for (operation, result) in [(returns[0], &first), (returns[1], &second)] {
            assert_eq!(bits(operation.p_before), bits(result.scaled_step));
            assert_eq!(operation.lower_before, result.active_lower);
            assert_eq!(operation.upper_before, result.active_upper);
            assert_eq!(operation.free_before, [true; 21]);
            assert_eq!(operation.lambda, Some(result.lambda));
            assert_eq!(operation.residual, Some(result.final_residual));
            assert_eq!(operation.g, Some(result.final_g));
            assert_eq!(operation.lambda_times_p, Some(result.final_lambda_times_p));
            assert_eq!(operation.h, Some(result.final_h));
            let recorded = operation
                .optimality
                .as_ref()
                .expect("expected-red: ordered return assessment");
            let observed = result
                .optimality_observation
                .as_ref()
                .expect("02 returned assessment");
            assert_eq!(recorded.coordinates.len(), 21);
            assert_eq!(recorded.scalar_operations, observed.scalar_operations);
            assert_eq!(
                operation.entered_factorizations,
                result.entered_svd_factorizations
            );
            assert_eq!(operation.completed_pivots, result.completed_face_pivots);
            assert_eq!(operation.completed_sweeps, 1);
        }
        assert_eq!(bits(first.final_residual), [0_u64; 21]);
        assert_ne!(bits(second.scaled_step), [0_u64; 21]);
        assert_eq!(capture.completed_subproblems.len(), 2);
        for (summary, result) in capture.completed_subproblems.iter().zip([&first, &second]) {
            assert!(!summary.refused);
            assert_eq!(summary.completed_sweeps, 1);
            assert_eq!(summary.completed_sweeps, result.entered_svd_factorizations);
            assert_eq!(
                summary.entered_factorizations,
                result.entered_svd_factorizations
            );
            assert_eq!(summary.completed_pivots, result.completed_face_pivots);
        }
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn expected_red_nonfinite_transition_capture_records_typed_refusal_without_mutation() {
        let _scope = super::m1_face_pivot_capture_begin_for_test();
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::NAN;
        let mut residual = [0.0; 21];
        residual[0] = 1.0;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("shared nonfinite transition refusal");
        assert_eq!(refusal.optimality_reason, Some("optimality_nonfinite"));
        assert_eq!(
            refusal.optimality_radius.map(|value| value.to_bits()),
            Some(1.0f64.to_bits())
        );
        assert_eq!(
            refusal.optimality_lambda.map(|value| value.to_bits()),
            Some(0.0f64.to_bits())
        );
        let capture = super::m1_face_pivot_capture_take_for_test()
            .expect("expected-red: nonfinite transition capture");
        let recorded = capture
            .refusal
            .expect("expected-red: typed capture refusal");
        assert_eq!(recorded.kind, refusal.kind);
        assert_eq!(recorded.optimality_reason, refusal.optimality_reason);
        assert_eq!(
            recorded.optimality_coordinate,
            refusal.optimality_coordinate
        );
        assert_eq!(bits(recorded.p), [0_u64; 21]);
        assert_eq!(recorded.lower, [false; 21]);
        assert_eq!(recorded.upper, [false; 21]);
        assert_eq!(recorded.free, [true; 21]);
        assert_eq!(recorded.entered_factorizations, 1);
        assert_eq!(recorded.completed_pivots, 0);
        assert_eq!(recorded.completed_sweeps, 0);
        assert!(recorded.optimality.is_none());
        assert!(capture.operations.is_empty());
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn expected_red_enclosure_transition_capture_records_typed_refusal_without_fake_arrays() {
        let _scope = super::m1_face_pivot_capture_begin_for_test();
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = f64::MAX;
        let mut residual = [0.0; 21];
        residual[0] = -f64::MAX;
        let mut step = [0.0; 21];
        step[0] = 1.0;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            step,
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("shared enclosure transition refusal");
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_upward_enclosure")
        );
        assert_eq!(
            refusal.optimality_radius.map(|value| value.to_bits()),
            Some(1.0f64.to_bits())
        );
        assert_eq!(
            refusal.optimality_lambda.map(|value| value.to_bits()),
            Some(0.0f64.to_bits())
        );
        let capture = super::m1_face_pivot_capture_take_for_test()
            .expect("expected-red: enclosure transition capture");
        let recorded = capture
            .refusal
            .expect("expected-red: enclosure typed capture refusal");
        assert_eq!(recorded.kind, refusal.kind);
        assert_eq!(recorded.optimality_reason, refusal.optimality_reason);
        assert_eq!(
            recorded.optimality_coordinate,
            refusal.optimality_coordinate
        );
        assert!(recorded.optimality.is_none());
        let operation = capture
            .operations
            .iter()
            .find(|operation| operation.action == "optimality-refusal")
            .expect("expected-red: enclosure refusal operation");
        assert_eq!(bits(operation.p_before), bits(step));
        assert_eq!(operation.lower_before, [false; 21]);
        assert_eq!(operation.upper_before, [false; 21]);
        assert_eq!(operation.free_before, [true; 21]);
        assert_eq!(operation.radius.to_bits(), 1.0f64.to_bits());
        assert_eq!(operation.lambda, Some(0.0));
        assert_eq!(operation.free_ids, (0..21).collect::<Vec<_>>());
        assert_eq!(operation.residual, Some([0.0; 21]));
        assert_eq!(operation.g, Some([0.0; 21]));
        assert_eq!(operation.lambda_times_p, Some([0.0; 21]));
        assert_eq!(operation.h, Some([0.0; 21]));
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn expected_red_free_stationarity_capture_retains_real_face_metadata() {
        let _scope = super::m1_face_pivot_capture_begin_for_test();
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][0] = 1.0;
        let mut residual = [0.0; 21];
        residual[0] = 1.0;
        let refusal = m1_trust_region_kkt_transition_for_test(
            matrix,
            residual,
            [0.0; 21],
            [false; 21],
            [false; 21],
            [true; 21],
            0.0,
        )
        .expect_err("shared free-stationarity refusal");
        assert_eq!(
            refusal.optimality_reason,
            Some("optimality_free_stationarity")
        );
        assert_eq!(
            refusal.optimality_radius.map(|value| value.to_bits()),
            Some(1.0f64.to_bits())
        );
        assert_eq!(
            refusal.optimality_lambda.map(|value| value.to_bits()),
            Some(0.0f64.to_bits())
        );
        let capture =
            super::m1_face_pivot_capture_take_for_test().expect("shared free-stationarity capture");
        let recorded = capture
            .refusal
            .expect("shared free-stationarity refusal record");
        assert_eq!(recorded.optimality_reason, refusal.optimality_reason);
        assert_eq!(
            recorded.optimality_coordinate,
            refusal.optimality_coordinate
        );
        assert_eq!(bits(recorded.p), [0_u64; 21]);
        assert_eq!(recorded.lower, [false; 21]);
        assert_eq!(recorded.upper, [false; 21]);
        assert_eq!(recorded.free, [true; 21]);
        assert_eq!(recorded.entered_factorizations, 1);
        assert_eq!(recorded.completed_pivots, 0);
        assert_eq!(recorded.completed_sweeps, 0);
        let operation = capture
            .operations
            .iter()
            .find(|operation| operation.action == "optimality-refusal")
            .expect("shared free-stationarity operation");
        assert_eq!(operation.radius.to_bits(), 1.0f64.to_bits());
        assert_eq!(operation.lambda, Some(0.0));
        assert_eq!(operation.free_ids, (0..21).collect::<Vec<_>>());
        assert_eq!(
            operation.residual,
            Some([
                1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0
            ])
        );
        assert_eq!(
            operation.g,
            Some([
                1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0
            ])
        );
        assert_eq!(operation.lambda_times_p, Some([0.0; 21]));
        assert_eq!(
            operation.h,
            Some([
                1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0
            ])
        );
    }

    #[test]
    fn zero_scale_is_rejected_by_shared_preparation_before_kkt_transition() {
        let mut jacobian = [[0.0; 21]; 21];
        jacobian[0][0] = 1.0;
        let mut lower = [0.0; 21];
        let mut upper = [0.0; 21];
        lower[0] = f64::NEG_INFINITY;
        upper[0] = f64::INFINITY;
        let mut scales = [1.0; 21];
        scales[0] = 0.0;
        let refusal = super::solve_subproblem(&M1TrustRegionSubproblemInput {
            raw_residual: [
                1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0,
            ],
            raw_jacobian: jacobian,
            normalizers: [1.0; 21],
            scales,
            lower,
            upper,
            initial_radius: 1.0,
            base: [0.0; 21],
            test_work: M1TrustRegionTestWorkState::default(),
        })
        .expect_err("shared zero-scale preparation refusal");
        assert_eq!(refusal.kind, M1TrustRegionRefusalKind::SvdNonFinite);
        assert_eq!(refusal.optimality_reason, None);
        assert_eq!(refusal.optimality_coordinate, None);
        assert_eq!(refusal.entered_svd_factorizations, 0);
    }

    fn cancellation_band_transition(scale: f64, active_coordinate: usize, step_coordinate: usize) {
        let mut matrix = vec![vec![0.0; 21]; 21];
        matrix[0][active_coordinate] = scale;
        matrix[0][step_coordinate] = scale;
        let mut residual = [0.0; 21];
        residual[0] = (-1.0 - f64::EPSILON) * scale;
        let mut step = [0.0; 21];
        step[step_coordinate] = 1.0;
        let lower = std::array::from_fn(|index| index == active_coordinate);
        assert_eq!(
            m1_trust_region_kkt_transition_for_test(
                matrix,
                residual,
                step,
                lower,
                [false; 21],
                partition(lower, [false; 21]),
                0.0
            )
            .expect("shared permuted transition")
            .action,
            Some(M1TrustRegionKktAction::Return),
            "expected-red: cancellation band remains unresolved"
        );
    }

    #[test]
    fn expected_red_cancellation_band_is_stable_at_unit_scale() {
        cancellation_band_transition(1.0, 0, 1);
    }

    #[test]
    fn expected_red_cancellation_band_is_stable_at_diagonal_scale() {
        cancellation_band_transition(8.0, 0, 1);
    }

    #[test]
    fn expected_red_cancellation_band_is_stable_under_coordinate_permutation() {
        cancellation_band_transition(1.0, 1, 0);
    }
}

// COLD-CANOPY-M1-TR-SVD-BVLS-03 C1 is a test-scoped, non-FMA ORO primitive.
// It has no controller, factor, physical, or materialization connection.
#[cfg(test)]
const REFINEMENT_DOT2_SPLITTER: f64 = 134_217_729.0;

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RefinementDot2Reason {
    NonfiniteOperand,
    SplitterOverflow,
    UnderflowToZero,
    SubnormalIntermediate,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct RefinementDot2Refusal {
    reason: RefinementDot2Reason,
    guard_stage: M1TrustRegionRefinementGuardStage,
    row: Option<u8>,
    term: Option<u8>,
    coordinate: Option<u8>,
    arithmetic: u16,
    guards: u16,
    exceptional_guards: u16,
    signed_zero_values: u16,
}

#[cfg(test)]
impl RefinementDot2Refusal {
    fn reason(self) -> &'static str {
        match self.reason {
            RefinementDot2Reason::NonfiniteOperand => "refinement_nonfinite_operand",
            RefinementDot2Reason::SplitterOverflow => "refinement_splitter_overflow",
            RefinementDot2Reason::UnderflowToZero => "refinement_underflow_to_zero",
            RefinementDot2Reason::SubnormalIntermediate => "refinement_subnormal_intermediate",
        }
    }
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, PartialEq)]
struct RefinementDot2Observation {
    value: f64,
    initial_product_bits: u64,
    arithmetic: u16,
    guards: u16,
    exceptional_guards: u16,
    signed_zero_values: u16,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Default)]
struct RefinementDot2Counters {
    arithmetic: u16,
    guards: u16,
    exceptional_guards: u16,
    signed_zero_values: u16,
}

#[cfg(test)]
fn refinement_dot2_guard(
    value: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<f64, RefinementDot2Reason> {
    counters.guards += 1;
    if value == 0.0 {
        counters.signed_zero_values += 1;
    }
    if !value.is_finite() {
        counters.exceptional_guards += 1;
        return Err(RefinementDot2Reason::NonfiniteOperand);
    }
    if value != 0.0 && value.abs() < f64::MIN_POSITIVE {
        counters.exceptional_guards += 1;
        return Err(RefinementDot2Reason::SubnormalIntermediate);
    }
    Ok(value)
}

#[cfg(test)]
fn refinement_dot2_mul(
    left: f64,
    right: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<f64, RefinementDot2Reason> {
    let value = left * right;
    counters.arithmetic += 1;
    refinement_dot2_guard(value, counters)?;
    if left != 0.0 && right != 0.0 && value == 0.0 {
        counters.exceptional_guards += 1;
        return Err(RefinementDot2Reason::UnderflowToZero);
    }
    Ok(value)
}

#[cfg(test)]
fn refinement_dot2_add(
    left: f64,
    right: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<f64, RefinementDot2Reason> {
    let value = left + right;
    counters.arithmetic += 1;
    refinement_dot2_guard(value, counters)
}

#[cfg(test)]
fn refinement_dot2_sub(
    left: f64,
    right: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<f64, RefinementDot2Reason> {
    let value = left - right;
    counters.arithmetic += 1;
    refinement_dot2_guard(value, counters)
}

#[cfg(test)]
#[derive(Clone, Copy)]
struct RefinementDot2SiteFailure {
    reason: RefinementDot2Reason,
    guard_stage: M1TrustRegionRefinementGuardStage,
}

#[cfg(test)]
fn refinement_dot2_split(
    value: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<(f64, f64), RefinementDot2SiteFailure> {
    let c = match refinement_dot2_mul(REFINEMENT_DOT2_SPLITTER, value, counters) {
        Err(RefinementDot2Reason::NonfiniteOperand) => {
            // `value` was admitted at primitive entry and the splitter is finite,
            // so this exact failed multiplication is the splitter overflow.
            return Err(RefinementDot2SiteFailure {
                reason: RefinementDot2Reason::SplitterOverflow,
                guard_stage: M1TrustRegionRefinementGuardStage::SplitterProduct,
            });
        }
        Err(reason) => {
            return Err(RefinementDot2SiteFailure {
                reason,
                guard_stage: M1TrustRegionRefinementGuardStage::SplitterProduct,
            });
        }
        Ok(value) => value,
    };
    let split_failure = |reason| RefinementDot2SiteFailure {
        reason,
        guard_stage: M1TrustRegionRefinementGuardStage::SplitOutput,
    };
    let abig = refinement_dot2_sub(c, value, counters).map_err(split_failure)?;
    let high = refinement_dot2_sub(c, abig, counters).map_err(split_failure)?;
    let low = refinement_dot2_sub(value, high, counters).map_err(split_failure)?;
    Ok((high, low))
}

#[cfg(test)]
fn refinement_dot2_two_product(
    left: f64,
    right: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<(f64, f64), RefinementDot2SiteFailure> {
    // Preserve the frozen primary-product-before-Split order.
    let product =
        refinement_dot2_mul(left, right, counters).map_err(|reason| RefinementDot2SiteFailure {
            reason,
            guard_stage: M1TrustRegionRefinementGuardStage::PrimaryProduct,
        })?;
    let (left_high, left_low) = refinement_dot2_split(left, counters)?;
    let (right_high, right_low) = refinement_dot2_split(right, counters)?;
    let eft = |reason| RefinementDot2SiteFailure {
        reason,
        guard_stage: M1TrustRegionRefinementGuardStage::EftRemainder,
    };
    let left_high_right_high = refinement_dot2_mul(left_high, right_high, counters).map_err(eft)?;
    let remainder = refinement_dot2_sub(product, left_high_right_high, counters).map_err(eft)?;
    let left_low_right_high = refinement_dot2_mul(left_low, right_high, counters).map_err(eft)?;
    let remainder = refinement_dot2_sub(remainder, left_low_right_high, counters).map_err(eft)?;
    let left_high_right_low = refinement_dot2_mul(left_high, right_low, counters).map_err(eft)?;
    let remainder = refinement_dot2_sub(remainder, left_high_right_low, counters).map_err(eft)?;
    let left_low_right_low = refinement_dot2_mul(left_low, right_low, counters).map_err(eft)?;
    let error = refinement_dot2_sub(left_low_right_low, remainder, counters).map_err(eft)?;
    Ok((product, error))
}

#[cfg(test)]
fn refinement_dot2_two_sum(
    left: f64,
    right: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<(f64, f64), RefinementDot2SiteFailure> {
    let x =
        refinement_dot2_add(left, right, counters).map_err(|reason| RefinementDot2SiteFailure {
            reason,
            guard_stage: M1TrustRegionRefinementGuardStage::TwoSumResult,
        })?;
    let remainder = |reason| RefinementDot2SiteFailure {
        reason,
        guard_stage: M1TrustRegionRefinementGuardStage::TwoSumRemainder,
    };
    let z = refinement_dot2_sub(x, left, counters).map_err(remainder)?;
    let x_minus_z = refinement_dot2_sub(x, z, counters).map_err(remainder)?;
    let left_error = refinement_dot2_sub(left, x_minus_z, counters).map_err(remainder)?;
    let right_error = refinement_dot2_sub(right, z, counters).map_err(remainder)?;
    let error = refinement_dot2_add(left_error, right_error, counters).map_err(remainder)?;
    Ok((x, error))
}

#[cfg(test)]
fn refinement_dot2_refusal(
    counters: RefinementDot2Counters,
    reason: RefinementDot2Reason,
    guard_stage: M1TrustRegionRefinementGuardStage,
    term: Option<usize>,
) -> RefinementDot2Refusal {
    RefinementDot2Refusal {
        reason,
        guard_stage,
        row: None,
        term: term.map(|term| u8::try_from(term).expect("fixed Dot2 term fits u8")),
        coordinate: term
            .filter(|term| *term != 0)
            .map(|term| u8::try_from(term - 1).expect("fixed Dot2 coordinate fits u8")),
        arithmetic: counters.arithmetic,
        guards: counters.guards,
        exceptional_guards: counters.exceptional_guards,
        signed_zero_values: counters.signed_zero_values,
    }
}

#[cfg(test)]
fn refinement_dot2_final_add(
    partial: f64,
    compensation: f64,
    counters: &mut RefinementDot2Counters,
) -> Result<f64, RefinementDot2Refusal> {
    refinement_dot2_add(partial, compensation, counters).map_err(|reason| {
        refinement_dot2_refusal(
            *counters,
            reason,
            M1TrustRegionRefinementGuardStage::Accumulation,
            None,
        )
    })
}

fn m1_trust_region_refinement_dot2_for_test(
    terms: [f64; 22],
    weights: [f64; 22],
) -> Result<RefinementDot2Observation, RefinementDot2Refusal> {
    let mut counters = RefinementDot2Counters::default();
    for (term, value) in terms.into_iter().enumerate() {
        if let Err(reason) = refinement_dot2_guard(value, &mut counters) {
            return Err(refinement_dot2_refusal(
                counters,
                reason,
                M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                Some(term),
            ));
        }
    }
    for (term, value) in weights.into_iter().enumerate() {
        if let Err(reason) = refinement_dot2_guard(value, &mut counters) {
            return Err(refinement_dot2_refusal(
                counters,
                reason,
                M1TrustRegionRefinementGuardStage::ResidualSourceWeight,
                Some(term),
            ));
        }
    }
    let (mut partial, mut compensation) =
        refinement_dot2_two_product(terms[0], weights[0], &mut counters).map_err(|failure| {
            refinement_dot2_refusal(counters, failure.reason, failure.guard_stage, Some(0))
        })?;
    let initial_product_bits = partial.to_bits();
    for index in 1..terms.len() {
        let (head, tail) = refinement_dot2_two_product(terms[index], weights[index], &mut counters)
            .map_err(|failure| {
                refinement_dot2_refusal(counters, failure.reason, failure.guard_stage, Some(index))
            })?;
        let (next_partial, sum_tail) = refinement_dot2_two_sum(partial, head, &mut counters)
            .map_err(|failure| {
                refinement_dot2_refusal(counters, failure.reason, failure.guard_stage, Some(index))
            })?;
        partial = next_partial;
        let sum_tail_plus_tail =
            refinement_dot2_add(sum_tail, tail, &mut counters).map_err(|reason| {
                refinement_dot2_refusal(
                    counters,
                    reason,
                    M1TrustRegionRefinementGuardStage::Accumulation,
                    Some(index),
                )
            })?;
        compensation = refinement_dot2_add(compensation, sum_tail_plus_tail, &mut counters)
            .map_err(|reason| {
                refinement_dot2_refusal(
                    counters,
                    reason,
                    M1TrustRegionRefinementGuardStage::Accumulation,
                    Some(index),
                )
            })?;
    }
    let value = refinement_dot2_final_add(partial, compensation, &mut counters)?;
    Ok(RefinementDot2Observation {
        value,
        initial_product_bits,
        arithmetic: counters.arithmetic,
        guards: counters.guards,
        exceptional_guards: counters.exceptional_guards,
        signed_zero_values: counters.signed_zero_values,
    })
}

fn bvls04_dot2_defect(
    factor: &JacobiFactor,
    residual: &[f64; 21],
    p: &[f64; 21],
    free: &[usize],
    lambda: f64,
    work: &mut RefinementWorkLedger,
) -> Result<Vec<f64>, RefinementDot2Refusal> {
    let mut h = Vec::with_capacity(free.len());
    for (slot, &coordinate) in free.iter().enumerate() {
        if coordinate >= 21
            || factor.a.len() != 21
            || factor.a.iter().any(|row| row.len() != free.len())
        {
            return Err(RefinementDot2Refusal {
                reason: RefinementDot2Reason::NonfiniteOperand,
                guard_stage: M1TrustRegionRefinementGuardStage::FactorApplicationOutput,
                row: None,
                term: None,
                coordinate: None,
                arithmetic: 0,
                guards: 1,
                exceptional_guards: 1,
                signed_zero_values: 0,
            });
        }
        let mut terms = [0.0; 22];
        let mut weights = [0.0; 22];
        for row in 0..21 {
            terms[row] = factor.a[row][slot];
            weights[row] = residual[row];
        }
        terms[21] = lambda;
        weights[21] = p[coordinate];
        match m1_trust_region_refinement_dot2_for_test(terms, weights) {
            Ok(observation) => {
                work.absorb_dot2(RefinementDot2Counters {
                    arithmetic: observation.arithmetic,
                    guards: observation.guards,
                    exceptional_guards: observation.exceptional_guards,
                    signed_zero_values: observation.signed_zero_values,
                });
                work.second_dot2_operations += u64::from(observation.arithmetic);
                work.bvls04_dot2_free_gradients += 1;
                h.push(observation.value);
            }
            Err(refusal) => {
                work.absorb_dot2(RefinementDot2Counters {
                    arithmetic: refusal.arithmetic,
                    guards: refusal.guards,
                    exceptional_guards: refusal.exceptional_guards,
                    signed_zero_values: refusal.signed_zero_values,
                });
                work.second_dot2_operations += u64::from(refusal.arithmetic);
                work.bvls04_dot2_free_gradients += 1;
                return Err(RefinementDot2Refusal {
                    row: None,
                    coordinate: Some(refinement_face_index(coordinate)),
                    ..refusal
                });
            }
        }
    }
    Ok(h)
}

// These controls load independent retained operands/results; they do not
// manufacture a candidate result or invoke a physical controller path.
#[cfg(test)]
mod bvls03_c1_expected_red_controls {
    use super::{
        M1TrustRegionRefinementGuardStage, RefinementDot2Counters, RefinementDot2Reason,
        m1_trust_region_refinement_dot2_for_test, refinement_dot2_final_add, refinement_dot2_split,
        refinement_dot2_two_sum,
    };
    use serde_json::Value;

    const RETAINED_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/finite-precision-observed-capture.json"
    ));
    const RETAINED_RESULTS: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/dot2-results.json"
    ));
    const RETAINED_HISTORICAL_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/face-pivot-observed-capture.json"
    ));

    fn bit(value: &Value) -> f64 {
        f64::from_bits(
            u64::from_str_radix(value.as_str().expect("binary64 hex"), 16)
                .expect("valid binary64 bits"),
        )
    }

    fn retained_row(case: usize, row: usize) -> ([f64; 22], [f64; 22], u64, u64) {
        let capture: Value = serde_json::from_str(if case == 0 {
            RETAINED_CAPTURE
        } else {
            RETAINED_HISTORICAL_CAPTURE
        })
        .expect("retained capture");
        let results: Value = serde_json::from_str(RETAINED_RESULTS).expect("independent results");
        let p = results["cases"][case]["first_correction"]["p_bits"]
            .as_array()
            .expect("retained first correction");
        let matrix = capture["weighted_matrix"]
            .as_array()
            .expect("weighted matrix");
        let residual = capture["weighted_residual"]
            .as_array()
            .expect("weighted residual");
        let terms = std::array::from_fn(|index| {
            if index == 0 {
                bit(&residual[row])
            } else {
                bit(&matrix[row][index - 1])
            }
        });
        let weights =
            std::array::from_fn(|index| if index == 0 { 1.0 } else { bit(&p[index - 1]) });
        let expected = u64::from_str_radix(
            results["cases"][case]["dot2_rows"][row]["bits"]
                .as_str()
                .expect("retained Dot2 bits"),
            16,
        )
        .expect("valid retained Dot2 bits");
        let guards = results["cases"][case]["dot2_rows"][row]["guards"]
            .as_u64()
            .expect("retained guard count");
        (terms, weights, expected, guards)
    }

    #[test]
    fn m1_trust_region_refinement_dot2_all_retained_rows_preserve_independent_bits_and_guards() {
        for case in 0..2 {
            for row in 0..21 {
                let (terms, weights, expected_bits, expected_guards) = retained_row(case, row);
                let observed = m1_trust_region_refinement_dot2_for_test(terms, weights)
                    .expect("admitted retained row");
                assert_eq!(
                    observed.value.to_bits(),
                    expected_bits,
                    "case {case}, row {row}"
                );
                assert_eq!(observed.arithmetic, 543, "case {case}, row {row}");
                assert_eq!(
                    u64::from(observed.guards),
                    expected_guards,
                    "case {case}, row {row}"
                );
                assert_eq!(observed.exceptional_guards, 0, "case {case}, row {row}");
            }
        }
    }

    #[test]
    fn m1_trust_region_refinement_dot2_preserves_negative_zero() {
        let observed = m1_trust_region_refinement_dot2_for_test(
            [
                -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            ],
            [
                1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            ],
        )
        .expect("signed-zero primitive remains admitted");
        assert_eq!(observed.initial_product_bits, (-0.0_f64).to_bits());
        assert_eq!(observed.value.to_bits(), 0.0_f64.to_bits());
        assert!(observed.signed_zero_values > 0);
    }

    #[test]
    fn m1_trust_region_refinement_dot2_refuses_guarded_primitive_domains() {
        for (terms, weights, reason, stage, expected) in [
            (
                [f64::NAN; 22],
                [1.0; 22],
                "refinement_nonfinite_operand",
                M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                (0, 1, 1, 0),
            ),
            (
                [f64::INFINITY; 22],
                [1.0; 22],
                "refinement_nonfinite_operand",
                M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                (0, 1, 1, 0),
            ),
            (
                [f64::from_bits(1); 22],
                [1.0; 22],
                "refinement_subnormal_intermediate",
                M1TrustRegionRefinementGuardStage::ResidualSourceTerm,
                (0, 1, 1, 0),
            ),
            (
                [f64::MIN_POSITIVE; 22],
                [0.5; 22],
                "refinement_subnormal_intermediate",
                M1TrustRegionRefinementGuardStage::PrimaryProduct,
                (1, 45, 1, 0),
            ),
            (
                [f64::MAX; 22],
                [1.0; 22],
                "refinement_splitter_overflow",
                M1TrustRegionRefinementGuardStage::SplitterProduct,
                (2, 46, 1, 0),
            ),
            (
                [f64::MAX; 22],
                [f64::MAX; 22],
                "refinement_nonfinite_operand",
                M1TrustRegionRefinementGuardStage::PrimaryProduct,
                (1, 45, 1, 0),
            ),
            (
                [f64::MIN_POSITIVE; 22],
                [f64::MIN_POSITIVE; 22],
                "refinement_underflow_to_zero",
                M1TrustRegionRefinementGuardStage::PrimaryProduct,
                (1, 45, 1, 1),
            ),
        ] {
            let refusal = m1_trust_region_refinement_dot2_for_test(terms, weights)
                .expect_err("guarded primitive domain must refuse");
            assert_eq!(refusal.reason(), reason);
            assert_eq!(refusal.guard_stage, stage);
            assert_eq!(refusal.term, Some(0));
            assert_eq!(refusal.coordinate, None);
            assert_eq!(
                (
                    refusal.arithmetic,
                    refusal.guards,
                    refusal.exceptional_guards,
                    refusal.signed_zero_values,
                ),
                expected,
            );
        }
        let mut weights = [1.0; 22];
        weights[14] = f64::from_bits(1);
        let refusal = m1_trust_region_refinement_dot2_for_test([1.0; 22], weights)
            .expect_err("nonzero source weight must retain its term provenance");
        assert_eq!(
            refusal.guard_stage,
            M1TrustRegionRefinementGuardStage::ResidualSourceWeight
        );
        assert_eq!(refusal.term, Some(14));
        assert_eq!(refusal.coordinate, Some(13));
    }

    #[test]
    fn m1_trust_region_refinement_dot2_later_primitive_stages_are_observed() {
        let mut counters = RefinementDot2Counters::default();
        let refusal = refinement_dot2_two_sum(f64::MAX, f64::MAX, &mut counters)
            .expect_err("actual first two-sum add overflows");
        assert_eq!(
            refusal.guard_stage,
            M1TrustRegionRefinementGuardStage::TwoSumResult
        );
        let mut counters = RefinementDot2Counters::default();
        let input = f64::from_bits(f64::MIN_POSITIVE.to_bits() + 1);
        let refusal = refinement_dot2_split(input, &mut counters)
            .expect_err("actual split low component is subnormal");
        assert_eq!(
            refusal.guard_stage,
            M1TrustRegionRefinementGuardStage::SplitOutput
        );
        let mut counters = RefinementDot2Counters::default();
        let refusal = refinement_dot2_final_add(f64::MAX, f64::MAX, &mut counters)
            .expect_err("actual final combined add overflows");
        assert_eq!(
            refusal.guard_stage,
            M1TrustRegionRefinementGuardStage::Accumulation
        );
        assert_eq!(refusal.term, None);
        assert_eq!(refusal.coordinate, None);
    }

    #[test]
    fn m1_trust_region_refinement_dot2_remainder_and_per_term_accumulation_metadata_are_observed() {
        let mut eft_terms = [0.0; 22];
        let mut eft_weights = [0.0; 22];
        eft_terms[0] = f64::from_bits(0x20b0_0000_0200_0000);
        eft_weights[0] = f64::from_bits(0x20b0_0000_0000_0000);
        let refusal = m1_trust_region_refinement_dot2_for_test(eft_terms, eft_weights)
            .expect_err("actual EFT remainder becomes subnormal");
        assert_eq!(refusal.reason(), "refinement_subnormal_intermediate");
        assert_eq!(
            refusal.guard_stage,
            M1TrustRegionRefinementGuardStage::EftRemainder
        );
        assert_eq!(refusal.term, Some(0));
        assert_eq!(refusal.coordinate, None);
        assert_eq!(refusal.exceptional_guards, 1);

        let mut counters = RefinementDot2Counters::default();
        let refusal = refinement_dot2_two_sum(
            f64::from_bits(0x0020_0000_0000_0000),
            f64::from_bits(0x0010_0000_0000_0001),
            &mut counters,
        )
        .expect_err("actual TwoSum remainder becomes subnormal");
        assert_eq!(
            refusal.guard_stage,
            M1TrustRegionRefinementGuardStage::TwoSumRemainder
        );
        assert_eq!(refusal.reason, RefinementDot2Reason::SubnormalIntermediate);
        assert_eq!(
            (
                counters.arithmetic,
                counters.guards,
                counters.exceptional_guards,
                counters.signed_zero_values
            ),
            (5, 5, 1, 1)
        );

        let mut accumulation_terms = [0.0; 22];
        let mut accumulation_weights = [0.0; 22];
        accumulation_terms[0] = f64::from_bits(0x2180_0000_0000_0002);
        accumulation_weights[0] = f64::from_bits(0x21d4_0000_0000_0000);
        accumulation_terms[1] = f64::from_bits(0x2180_0000_0000_0002);
        accumulation_weights[1] = f64::from_bits(0x21e4_0000_0800_0000);
        let refusal =
            m1_trust_region_refinement_dot2_for_test(accumulation_terms, accumulation_weights)
                .expect_err("actual per-term accumulation becomes subnormal");
        assert_eq!(refusal.reason(), "refinement_subnormal_intermediate");
        assert_eq!(
            refusal.guard_stage,
            M1TrustRegionRefinementGuardStage::Accumulation
        );
        assert_eq!(refusal.term, Some(1));
        assert_eq!(refusal.coordinate, Some(0));
        assert_eq!(
            (
                refusal.arithmetic,
                refusal.guards,
                refusal.exceptional_guards,
                refusal.signed_zero_values
            ),
            (42, 86, 1, 49)
        );
    }
}

// C2--C4 are expected-red declarations for the next reviewed seam. They bind
// the retained source operands and independent results directly, rather than a
// second numerical implementation or manufactured refusal values.
#[cfg(test)]
mod bvls03_c2_c4_expected_red_controls {
    use super::{
        RefinementEligibilityProbe, RefinementRetainedFaceObservation, RefinementWorkReservation,
        m1_trust_region_bvls02_outcome_for_test, m1_trust_region_refinement_eligibility_for_test,
        m1_trust_region_refinement_retained_face_for_test,
    };
    #[cfg(feature = "m1-trust-region-physical-stage")]
    use super::{
        RefinementMutationScope, RefinementRawCandidateMutation,
        m1_trust_region_refinement_scratch_hooks_for_test, refine_face_before_crossing,
        refinement_solve_captured_face,
    };
    #[cfg(feature = "m1-trust-region-physical-stage")]
    use crate::{
        M1TrustRegionCorrectionPosition, M1TrustRegionRefinementGuardStage,
        M1TrustRegionRefinementReason,
    };
    use crate::{
        M1TrustRegionRefusalKind, M1TrustRegionSubproblemInput, M1TrustRegionTestWorkState,
    };
    use serde_json::Value;

    const ORDINARY_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/finite-precision-observed-capture.json"
    ));
    const HISTORICAL_CAPTURE: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/face-pivot-observed-capture.json"
    ));
    const RESULTS: &str = include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/dot2-results.json"
    ));

    fn retained(case: usize) -> (Value, Value) {
        let capture = serde_json::from_str(if case == 0 {
            ORDINARY_CAPTURE
        } else {
            HISTORICAL_CAPTURE
        })
        .expect("retained capture");
        let results: Value = serde_json::from_str(RESULTS).expect("independent Dot2 results");
        (capture, results["cases"][case].clone())
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    fn assert_scratch_mutation_refusal(
        capture: &Value,
        operation: &Value,
        mutation: RefinementRawCandidateMutation,
        reason: &str,
    ) {
        let refusal = m1_trust_region_refinement_scratch_hooks_for_test(capture, Some(mutation))
            .expect_err("actual mutated retained input must refuse");
        assert_eq!(refusal.reason, reason);
        let metadata = refusal
            .refinement
            .as_ref()
            .expect("actual refinement guard metadata");
        match reason {
            "refinement_final_box" => {
                assert_eq!(metadata.reason, M1TrustRegionRefinementReason::FinalBox);
                assert_eq!(
                    metadata.correction_position,
                    Some(M1TrustRegionCorrectionPosition::Second)
                );
                assert_eq!(
                    metadata.guard_stage,
                    M1TrustRegionRefinementGuardStage::FinalBoxUpper
                );
                assert_eq!(metadata.coordinate, Some(13));
            }
            "refinement_scratch_radius" => {
                assert_eq!(
                    metadata.reason,
                    M1TrustRegionRefinementReason::ScratchRadius
                );
                assert_eq!(
                    metadata.correction_position,
                    Some(M1TrustRegionCorrectionPosition::First)
                );
                assert_eq!(
                    metadata.guard_stage,
                    M1TrustRegionRefinementGuardStage::RadiusComparison
                );
                assert_eq!(metadata.coordinate, None);
            }
            "refinement_active_value" => {
                assert_eq!(metadata.reason, M1TrustRegionRefinementReason::ActiveValue);
                assert_eq!(
                    metadata.correction_position,
                    Some(M1TrustRegionCorrectionPosition::Second)
                );
                assert_eq!(
                    metadata.guard_stage,
                    M1TrustRegionRefinementGuardStage::ActiveEquality
                );
                assert_eq!(metadata.coordinate, Some(5));
            }
            _ => unreachable!("control only names typed refinement refusals"),
        }
        assert_eq!(
            metadata.lower_active.to_vec(),
            mask(&operation["lower_before"])
        );
        assert_eq!(
            metadata.upper_active.to_vec(),
            mask(&operation["upper_before"])
        );
        assert_eq!(metadata.free.to_vec(), mask(&operation["free_before"]));
        assert_eq!(
            metadata.lambda.to_bits(),
            bit(&operation["lambda"]).to_bits()
        );
        assert_eq!(
            metadata.original_trust_radius.to_bits(),
            bit(&capture["initial_radius"]).to_bits()
        );
        assert_eq!(
            metadata.reduced_face_radius.to_bits(),
            bit(&operation["radius"]).to_bits()
        );
        assert_eq!(metadata.scratch_box_feasible, Some(false));
        assert_eq!(
            refusal.live_state_bits_before,
            refusal.live_state_bits_after
        );
        let global_before = refusal
            .global_before
            .expect("actual pre-refusal global snapshot");
        let global_after = refusal
            .global_after
            .expect("actual post-refusal global snapshot");
        assert_eq!(global_before, global_after);
        let budget_before = refusal
            .budget_before
            .expect("actual pre-refusal budget snapshot");
        let budget_after = refusal
            .budget_after
            .expect("actual restored budget snapshot");
        assert_eq!(budget_before, budget_after);
        assert_ne!(budget_before, crate::M1PhysicalBudgetSnapshot::default());
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn m1_trust_region_refinement_p0_subnormal_reports_first_residual_source_weight() {
        let (capture, _) = retained(0);
        let refusal = m1_trust_region_refinement_scratch_hooks_for_test(
            &capture,
            Some(RefinementRawCandidateMutation::P0Subnormal { coordinate: 13 }),
        )
        .expect_err("finite algebraic p0 reaches the first residual guard");
        let metadata = refusal.refinement.expect("typed refusal metadata");
        assert_eq!(
            metadata.reason,
            M1TrustRegionRefinementReason::SubnormalIntermediate
        );
        assert_eq!(
            metadata.correction_position,
            Some(M1TrustRegionCorrectionPosition::First)
        );
        assert_eq!(
            metadata.guard_stage,
            M1TrustRegionRefinementGuardStage::ResidualSourceWeight
        );
        assert_eq!(metadata.row, Some(0));
        assert_eq!(metadata.term, Some(14));
        assert_eq!(metadata.coordinate, Some(13));
        assert_eq!(metadata.scratch_box_feasible, None);
        assert_eq!(refusal.work.refinement_scalar_operations, 69);
        assert_eq!(refusal.work.refinement_guard_events, 203);
        assert_eq!(refusal.work.first_residual_operations, 26);
        assert_eq!(refusal.work.refinement_attempted_entries, 1);
        assert_eq!(refusal.work.refinement_denied_entries, 0);
        assert_eq!(refusal.work.second_dot2_operations, 0);
        assert_eq!(refusal.work.factor_application_operations, 0);
        assert_eq!(refusal.work.coordinate_update_operations, 0);
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn m1_trust_region_refinement_preserves_unequal_original_and_reduced_radius_metadata() {
        let (capture, _) = retained(0);
        let (mut input, prepared, mut state, mut solution) =
            refinement_solve_captured_face(&capture).expect("retained face solves at its radius");
        assert_eq!(input.initial_radius.to_bits(), 1.0_f64.to_bits());
        assert_eq!(solution.radius.to_bits(), 1.0_f64.to_bits());
        input.initial_radius = 2.0;
        assert_eq!(input.initial_radius.to_bits(), 2.0_f64.to_bits());
        assert_ne!(input.initial_radius.to_bits(), solution.radius.to_bits());
        let _mutation =
            RefinementMutationScope::install(Some(RefinementRawCandidateMutation::P0Subnormal {
                coordinate: 13,
            }));
        let refusal = refine_face_before_crossing(&input, &prepared, &mut state, &mut solution)
            .expect_err("the retained P0 guard must preserve unequal radius provenance");
        let metadata = refusal.refinement.expect("typed P0 refinement metadata");
        assert_eq!(
            metadata.reason,
            M1TrustRegionRefinementReason::SubnormalIntermediate
        );
        assert_eq!(
            metadata.correction_position,
            Some(M1TrustRegionCorrectionPosition::First)
        );
        assert_eq!(
            metadata.guard_stage,
            M1TrustRegionRefinementGuardStage::ResidualSourceWeight
        );
        assert_eq!(metadata.row, Some(0));
        assert_eq!(metadata.term, Some(14));
        assert_eq!(metadata.coordinate, Some(13));
        assert_eq!(metadata.original_trust_radius.to_bits(), 2.0_f64.to_bits());
        assert_eq!(metadata.reduced_face_radius.to_bits(), 1.0_f64.to_bits());
        assert_ne!(
            metadata.original_trust_radius.to_bits(),
            metadata.reduced_face_radius.to_bits()
        );
        assert_eq!(metadata.scratch_box_feasible, None);
    }

    fn bits(values: &Value) -> Vec<u64> {
        values
            .as_array()
            .expect("bit array")
            .iter()
            .map(|value| {
                u64::from_str_radix(value.as_str().expect("binary64 bits"), 16).expect("valid bits")
            })
            .collect()
    }

    fn bit(value: &Value) -> f64 {
        f64::from_bits(
            u64::from_str_radix(value.as_str().expect("binary64 bits"), 16).expect("valid bits"),
        )
    }

    fn mask(values: &Value) -> Vec<bool> {
        values
            .as_array()
            .expect("mask array")
            .iter()
            .map(|value| value.as_bool().expect("mask bit"))
            .collect()
    }

    fn coordinate_bits(expected: &Value, field: &str) -> Vec<u64> {
        expected["second_correction"]["assessment"]["coordinates"]
            .as_array()
            .expect("assessment coordinates")
            .iter()
            .map(|coordinate| {
                u64::from_str_radix(coordinate[field].as_str().expect("coordinate bits"), 16)
                    .expect("valid coordinate bits")
            })
            .collect()
    }

    fn assert_retained_face_observation_core(
        capture: &Value,
        expected: &Value,
        observed: &RefinementRetainedFaceObservation,
    ) {
        assert_eq!(
            observed.p0_bits,
            bits(&capture["operations"][1]["p_candidate"])
        );
        assert_eq!(
            observed.delta0_free_bits,
            bits(&expected["first_correction"]["delta_free_bits"])
        );
        assert_eq!(
            observed.p1_bits,
            bits(&expected["first_correction"]["p_bits"])
        );
        assert_eq!(
            observed.dot2_residual_bits,
            expected["dot2_rows"]
                .as_array()
                .expect("rows")
                .iter()
                .map(|row| {
                    u64::from_str_radix(row["bits"].as_str().expect("row bits"), 16)
                        .expect("valid row bits")
                })
                .collect::<Vec<_>>()
        );
        assert_eq!(
            observed.delta1_free_bits,
            bits(&expected["second_correction"]["delta_free_bits"])
        );
        assert_eq!(
            observed.p2_bits,
            bits(&expected["second_correction"]["p_bits"])
        );
        assert_eq!(observed.h_bits, coordinate_bits(expected, "hhat_bits"));
        assert_eq!(observed.cbar_bits, coordinate_bits(expected, "cbar_bits"));
        assert_eq!(observed.tau_bits, coordinate_bits(expected, "tau_bits"));
        assert_eq!(
            observed.classes,
            expected["second_correction"]["assessment"]["coordinates"]
                .as_array()
                .expect("coordinates")
                .iter()
                .map(|coordinate| {
                    coordinate["classification"]
                        .as_str()
                        .expect("class")
                        .to_owned()
                })
                .collect::<Vec<_>>()
        );
        assert_eq!(
            observed.box_feasible,
            expected["second_correction"]["assessment"]["box_feasible"]
                .as_bool()
                .expect("box feasible")
        );
        assert_eq!(
            observed.ball_feasible,
            expected["second_correction"]["assessment"]["ball_feasible"]
                .as_bool()
                .expect("ball feasible")
        );
    }

    fn assert_retained_face_observation_accounting(
        capture: &Value,
        observed: &RefinementRetainedFaceObservation,
        case: usize,
    ) {
        assert_eq!(observed.factorizations_added, 0);
        assert_eq!(observed.factor_application_count, 2);
        assert_eq!(
            observed.factor_identity_before,
            observed.factor_identity_after
        );
        assert_eq!(
            observed.factor_application_identities,
            vec![observed.factor_identity_before; 2]
        );
        assert_eq!(
            observed.lower_mask_p0,
            mask(&capture["operations"][1]["lower_before"])
        );
        assert_eq!(
            observed.upper_mask_p0,
            mask(&capture["operations"][1]["upper_before"])
        );
        assert_eq!(observed.lower_mask_p1, observed.lower_mask_p0);
        assert_eq!(observed.upper_mask_p1, observed.upper_mask_p0);
        assert_eq!(observed.lower_mask_p2, observed.lower_mask_p0);
        assert_eq!(observed.upper_mask_p2, observed.upper_mask_p0);
        assert_eq!(observed.lower_mask_exit, observed.lower_mask_p0);
        assert_eq!(observed.upper_mask_exit, observed.upper_mask_p0);
        assert_eq!(observed.corrections, 2);
        assert_eq!(observed.first_residual_operations, 903);
        assert_eq!(observed.second_dot2_operations, 11_403);
        assert_eq!(observed.factor_application_operations, 37_920);
        assert_eq!(observed.coordinate_update_operations, 40);
        assert_eq!(
            observed.first_residual_operations
                + observed.second_dot2_operations
                + observed.factor_application_operations
                + observed.coordinate_update_operations,
            50_266
        );
        let (expected_upward_operations, expected_upward_guards, expected_scalar) = if case == 0 {
            (6_654, 65_916, 58_876)
        } else {
            (6_522, 65_781, 58_744)
        };
        assert_eq!(observed.whole_kkt_operations, 1_827);
        assert_eq!(observed.whole_kkt_guard_events, 5_503);
        assert_eq!(
            observed.upward_enclosure_operations,
            expected_upward_operations
        );
        assert!(observed.upward_enclosure_operations <= 39_816);
        assert_eq!(
            observed.upward_enclosure_guard_events,
            expected_upward_guards
        );
        assert_eq!(observed.refinement_scalar_operations, expected_scalar);
    }

    #[test]
    fn m1_trust_region_refinement_retained_face_reuses_factor_and_reproduces_all_bits() {
        for case in 0..2 {
            let (capture, expected) = retained(case);
            let observed = m1_trust_region_refinement_retained_face_for_test(&capture, None)
                .expect("retained face completes through unchanged BVLS02 decision");
            assert_retained_face_observation_core(&capture, &expected, &observed);
            assert_retained_face_observation_accounting(&capture, &observed, case);
            assert_eq!(
                observed.bvls02_pass,
                expected["second_correction"]["assessment"]["complete_bvls02_and_feasibility_pass"]
                    .as_bool()
                    .expect("BVLS02 decision")
            );
            assert_eq!(
                observed.bvls02_pass,
                expected["second_correction"]["assessment"]["complete_bvls02_and_feasibility_pass"]
                    .as_bool()
                    .expect("BVLS02 decision")
            );
        }
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn m1_trust_region_refinement_scratch_never_reaches_owner_or_physical_hooks() {
        let (capture, _) = retained(0);
        let observed = m1_trust_region_refinement_scratch_hooks_for_test(&capture, None)
            .expect("retained new-face scratch observation");
        assert!(observed.p1_free_box_violation);
        assert_eq!(observed.physical_evaluator_calls, 0);
        assert_eq!(observed.hydraulic_calls, 0);
        assert_eq!(observed.materialization_calls, 0);
        assert_eq!(observed.global_before, observed.global_after);
        assert_eq!(
            observed.global_after.phase_join_selections
                - observed.global_before.phase_join_selections,
            0
        );
        assert_eq!(
            observed.global_after.frozen_weighted_merit_entries
                - observed.global_before.frozen_weighted_merit_entries,
            0
        );
        assert_eq!(
            observed.live_state_bits_before,
            observed.live_state_bits_after
        );
        assert!(observed.budget_before.is_some());
        assert_eq!(observed.budget_before, observed.budget_after);
        assert_ne!(
            observed.budget_before,
            Some(crate::M1PhysicalBudgetSnapshot::default())
        );
        let operation = &capture["operations"][1];
        let active_coordinate = 5;
        let free_coordinate = 13;
        let p0 = bit(&operation["p_candidate"][free_coordinate]);
        let upper = bit(&capture["upper"][free_coordinate]);
        let base = bit(&capture["base"][free_coordinate]);
        let scale = bit(&capture["scales"][free_coordinate]);
        let scaled_upper = (upper - base) / scale;
        for (mutation, reason) in [
            (
                RefinementRawCandidateMutation::FinalBox {
                    coordinate: free_coordinate,
                    scaled_value: scaled_upper + 1.0,
                },
                "refinement_final_box",
            ),
            (
                RefinementRawCandidateMutation::ScratchRadius {
                    coordinate: free_coordinate,
                    scaled_value: p0,
                    radius: 0.0,
                },
                "refinement_scratch_radius",
            ),
            (
                RefinementRawCandidateMutation::ActiveValue {
                    coordinate: active_coordinate,
                    scaled_value: bit(&operation["p_candidate"][active_coordinate]) + 1.0,
                },
                "refinement_active_value",
            ),
        ] {
            assert_scratch_mutation_refusal(&capture, operation, mutation, reason);
        }
    }

    #[test]
    fn m1_trust_region_refinement_eligibility_uses_raw_face_predicates_and_counts_denied_work() {
        let (capture, _) = retained(0);
        let base = RefinementEligibilityProbe::from_captured_face(&capture);
        for (probe, expected_action) in [
            (base.with_lambda(0.0), "refine"),
            (base.with_lambda(-0.0), "refine"),
            (base.with_lambda(1.0), "bvls02"),
            (base.with_trust_radius(base.p0_norm()), "bvls02"),
            (base.with_p0_free_coordinate_outside_box(), "bvls02"),
        ] {
            let baseline = (expected_action == "bvls02")
                .then(|| m1_trust_region_bvls02_outcome_for_test(&capture, probe))
                .transpose()
                .expect("same-probe unchanged BVLS02 baseline");
            let observed =
                m1_trust_region_refinement_eligibility_for_test(&capture, probe, baseline.as_ref())
                    .expect("actual raw eligibility probe");
            assert_eq!(observed.action, expected_action);
            assert_eq!(
                observed.maximum_corrections,
                if expected_action == "refine" { 2 } else { 0 }
            );
            if expected_action == "bvls02" {
                assert_eq!(observed.bvls02, baseline.expect("BVLS02 baseline"));
            }
            assert_eq!(observed.bvls02_outcome, observed.bvls02.outcome);
            assert_eq!(
                observed.lower_mask_before,
                observed.bvls02.lower_mask_before
            );
            assert_eq!(
                observed.upper_mask_before,
                observed.bvls02.upper_mask_before
            );
            assert_eq!(observed.lower_mask_after, observed.bvls02.lower_mask);
            assert_eq!(observed.upper_mask_after, observed.bvls02.upper_mask);
            assert_eq!(observed.bvls02_work, observed.bvls02.work);
            if probe.p0_outside_box {
                assert_eq!(observed.bvls02.outcome, "crossing");
                let selected = observed
                    .bvls02
                    .coordinate
                    .expect("actual crossing selected a free coordinate");
                assert!(observed.bvls02.crossing_action.is_some());
                assert!(!observed.bvls02.lower_mask_before[selected]);
                assert!(!observed.bvls02.upper_mask_before[selected]);
                assert!(
                    observed.bvls02.lower_mask[selected] || observed.bvls02.upper_mask[selected]
                );
            }
            assert_eq!(
                observed.attempted_work_after,
                observed.attempted_work_before + observed.denied_work
            );
        }
        let refusal = m1_trust_region_refinement_retained_face_for_test(
            &capture,
            Some(RefinementWorkReservation {
                remaining_scalar_operations: 92_037,
                remaining_guard_events: 276_366,
            }),
        )
        .expect_err("one-less-than-required refinement reservation must refuse before entry");
        assert_eq!(refusal.reason, "refinement_work_cap");
        assert_eq!(refusal.required_scalar_operations, 92_038);
        assert_eq!(refusal.required_guard_events, 276_367);
        assert_eq!(
            refusal.attempted_entries_after,
            refusal.attempted_entries_before + 1
        );
        assert_eq!(
            refusal.denied_entries_after,
            refusal.denied_entries_before + 1
        );
        assert_eq!(refusal.corrections, 0);
        assert_eq!(refusal.dot2_operations, 0);
        assert_eq!(refusal.factor_applications, 0);
        assert_eq!(refusal.denied_entry_executed_scalar_operations, 0);
        assert_eq!(refusal.denied_entry_executed_guard_events, 0);
        assert_eq!(refusal.prior_eligibility_scalar_operations, 43);
        assert!(refusal.prior_eligibility_guard_events > 0);
        assert_eq!(refusal.returned_step, None);
        assert_eq!(refusal.bvls02_fallback_calls, 0);
        assert_eq!(refusal.materialization_calls, 0);
        assert_eq!(refusal.physical_evaluator_calls, 0);
        assert!(refusal.hook_log.is_empty());
        assert_eq!(refusal.owner_snapshot_before, refusal.owner_snapshot_after);
        #[cfg(feature = "m1-trust-region-physical-stage")]
        {
            assert!(refusal.budget_before.is_some());
            assert_eq!(refusal.budget_before, refusal.budget_after);
            assert_ne!(
                refusal.budget_before,
                Some(crate::M1PhysicalBudgetSnapshot::default())
            );
        }
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    fn bvls05_captured_g4_input() -> (M1TrustRegionSubproblemInput, Vec<Vec<f64>>) {
        const G4_CAPTURE: &str = include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/g4-rank-capture.json"
        ));
        let capture: serde_json::Value =
            serde_json::from_str(G4_CAPTURE).expect("preserved G4 capture");
        let face = &capture["face_capture"];
        let core = capture["base_core_operands"]
            .as_array()
            .expect("captured core operands");
        let bit = |value: &serde_json::Value| {
            super::refinement_capture_bit(value).expect("captured binary64")
        };
        let upper_areas = core[0]["structural_areas_m2_m2_tile"]
            .as_array()
            .expect("upper areas");
        let lower_areas = core[1]["structural_areas_m2_m2_tile"]
            .as_array()
            .expect("lower areas");
        let upper_wet = bit(&core[0]["wet_fraction"]);
        let lower_wet = bit(&core[1]["wet_fraction"]);
        let provenance = crate::M1TrustRegionBvls05TestProvenance {
            role_columns: [0, 1, 2, 6, 7, 8],
            structural_areas: [
                bit(&upper_areas[0]),
                bit(&upper_areas[1]),
                bit(&upper_areas[2]),
                bit(&lower_areas[0]),
                bit(&lower_areas[1]),
                bit(&lower_areas[2]),
            ],
            wet_fractions: [
                upper_wet, upper_wet, upper_wet, lower_wet, lower_wet, lower_wet,
            ],
            initial_free: [true; 6],
            physical_current_free: [true; 6],
        };
        let weighted = face["weighted_matrix"]
            .as_array()
            .expect("captured weighted rows")
            .iter()
            .map(|row| {
                super::refinement_capture_vector(row)
                    .expect("captured weighted row")
                    .to_vec()
            })
            .collect::<Vec<_>>();
        (
            M1TrustRegionSubproblemInput {
                raw_residual: super::refinement_capture_vector(&face["raw_residual"])
                    .expect("captured raw residual"),
                raw_jacobian: super::refinement_capture_matrix(&face["raw_jacobian"])
                    .expect("captured raw Jacobian"),
                normalizers: super::refinement_capture_vector(&face["normalizers"])
                    .expect("captured normalizers"),
                scales: super::refinement_capture_vector(&face["scales"]).expect("captured scales"),
                lower: super::refinement_capture_vector(&face["lower"]).expect("captured lower"),
                upper: super::refinement_capture_vector(&face["upper"]).expect("captured upper"),
                initial_radius: super::refinement_capture_bit(&face["initial_radius"])
                    .expect("captured radius"),
                base: super::refinement_capture_vector(&face["base"]).expect("captured base"),
                test_work: M1TrustRegionTestWorkState {
                    bvls05_provenance: Some(provenance),
                    ..M1TrustRegionTestWorkState::default()
                },
            },
            weighted,
        )
    }

    fn bvls05_diagonal_input() -> M1TrustRegionSubproblemInput {
        let mut raw_jacobian = [[0.0; 21]; 21];
        for (coordinate, row) in raw_jacobian.iter_mut().enumerate() {
            if coordinate != 1 && coordinate != 2 {
                row[coordinate] = 1.0;
            }
        }
        M1TrustRegionSubproblemInput {
            raw_residual: [0.0; 21],
            raw_jacobian,
            normalizers: [1.0; 21],
            scales: [1.0; 21],
            lower: [-2.0; 21],
            upper: [2.0; 21],
            initial_radius: 8.0,
            base: [0.0; 21],
            test_work: M1TrustRegionTestWorkState {
                bvls05_provenance: Some(bvls05_provenance()),
                ..M1TrustRegionTestWorkState::default()
            },
        }
    }

    fn bvls05_provenance() -> crate::M1TrustRegionBvls05TestProvenance {
        crate::M1TrustRegionBvls05TestProvenance {
            role_columns: [0, 1, 2, 3, 4, 5],
            structural_areas: [0.0, 1.0, 1.0, 1.0, 1.0, 1.0],
            wet_fractions: [1.0, 1.0, 1.0, 0.5, 0.5, 0.5],
            initial_free: [true; 6],
            physical_current_free: [true; 6],
        }
    }

    fn bvls05_roles(input: &M1TrustRegionSubproblemInput) -> [super::Bvls05RoleInput; 6] {
        let provenance = input
            .test_work
            .bvls05_provenance
            .expect("BVLS05 test provenance");
        [
            super::Bvls05RoleInput {
                role: super::Bvls05Role::SunLeaf,
                column: provenance.role_columns[0],
                structural_area: provenance.structural_areas[0],
                wet_fraction: provenance.wet_fractions[0],
                initial_free: provenance.initial_free[0],
                physical_current_free: provenance.physical_current_free[0],
            },
            super::Bvls05RoleInput {
                role: super::Bvls05Role::ShadeLeaf,
                column: provenance.role_columns[1],
                structural_area: provenance.structural_areas[1],
                wet_fraction: provenance.wet_fractions[1],
                initial_free: provenance.initial_free[1],
                physical_current_free: provenance.physical_current_free[1],
            },
            super::Bvls05RoleInput {
                role: super::Bvls05Role::DryStem,
                column: provenance.role_columns[2],
                structural_area: provenance.structural_areas[2],
                wet_fraction: provenance.wet_fractions[2],
                initial_free: provenance.initial_free[2],
                physical_current_free: provenance.physical_current_free[2],
            },
            super::Bvls05RoleInput {
                role: super::Bvls05Role::SunLeaf,
                column: provenance.role_columns[3],
                structural_area: provenance.structural_areas[3],
                wet_fraction: provenance.wet_fractions[3],
                initial_free: provenance.initial_free[3],
                physical_current_free: provenance.physical_current_free[3],
            },
            super::Bvls05RoleInput {
                role: super::Bvls05Role::ShadeLeaf,
                column: provenance.role_columns[4],
                structural_area: provenance.structural_areas[4],
                wet_fraction: provenance.wet_fractions[4],
                initial_free: provenance.initial_free[4],
                physical_current_free: provenance.physical_current_free[4],
            },
            super::Bvls05RoleInput {
                role: super::Bvls05Role::DryStem,
                column: provenance.role_columns[5],
                structural_area: provenance.structural_areas[5],
                wet_fraction: provenance.wet_fractions[5],
                initial_free: provenance.initial_free[5],
                physical_current_free: provenance.physical_current_free[5],
            },
        ]
    }

    fn bvls05_weighted(raw: &[[f64; 21]; 21]) -> Vec<Vec<f64>> {
        raw.iter().map(|row| row.to_vec()).collect()
    }

    fn bvls05_full_h(raw: &[[f64; 21]; 21], f: [f64; 21], p: [f64; 21], lambda: f64) -> [f64; 21] {
        let mut residual = f;
        for row in 0..21 {
            for column in 0..21 {
                residual[row] += raw[row][column] * p[column];
            }
        }
        let mut h = [0.0; 21];
        for column in 0..21 {
            for row in 0..21 {
                h[column] += raw[row][column] * residual[row];
            }
            h[column] += lambda * p[column];
        }
        h
    }

    fn assert_bvls05_exact_array(actual: [f64; 21], expected: [f64; 21]) {
        assert!(actual.iter().zip(expected).all(|(actual, expected)| {
            actual.partial_cmp(&expected) == Some(std::cmp::Ordering::Equal)
        }));
    }

    #[cfg(feature = "m1-trust-region-physical-stage")]
    #[test]
    fn m1_trust_region_bvls05_expected_red_g4_full_wet_hold() {
        let (input, weighted) = bvls05_captured_g4_input();
        let certificate = super::bvls05_certificate_for_test(
            &bvls05_roles(&input),
            &input.raw_jacobian,
            &weighted,
        );
        assert_eq!(certificate.held[1..3], [true, true]);
        assert!(!certificate.held[19]);
        let scope = super::m1_face_pivot_capture_begin_for_test();
        let _terminal = super::solve_subproblem(&input);
        let capture = super::m1_face_pivot_capture_take_for_test().expect("first-face capture");
        drop(scope);
        assert_eq!(capture.raw_jacobian, input.raw_jacobian);
        assert_eq!(capture.weighted_residual.len(), 21, "full f is retained");
        assert_eq!(capture.weighted_matrix.len(), 21, "full A is retained");
        // The terminal result is intentionally independent of the first-face
        // observation: the released body may continue after this face.
        let first_free_ids = if let Some(first) = capture.operations.first() {
            &first.free_ids
        } else {
            let first = capture
                .refusal
                .as_ref()
                .expect("first face refused before any transition");
            assert_eq!(
                first.entered_factorizations, 1,
                "refusal is from the first factorization"
            );
            assert_eq!(first.completed_pivots, 0, "no earlier face transition");
            &first.free_ids
        };
        assert_eq!(capture.weighted_matrix, weighted);
        assert_eq!(
            first_free_ids.len(),
            19,
            "expected-red: unchanged body has not admitted the structural hold"
        );
        assert_eq!(
            *first_free_ids,
            vec![
                0, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20
            ]
        );
    }

    #[test]
    fn m1_trust_region_bvls05_column_guard_red() {
        let mut input = bvls05_diagonal_input();
        let mut roles = bvls05_roles(&input);
        // Eligibility is isolated: a completely zero, fully wet, free
        // temperature column is refused solely because its semantic role is
        // not a dry-temperature role.
        roles[1].role = super::Bvls05Role::Other;
        let unexpected_role = super::bvls05_certificate_for_test(
            &roles,
            &input.raw_jacobian,
            &bvls05_weighted(&input.raw_jacobian),
        );
        assert!(super::prepare_subproblem(&input).is_ok());
        assert!(!unexpected_role.held[1]);
        let certificate = super::bvls05_certificate_for_test(
            &bvls05_roles(&input),
            &input.raw_jacobian,
            &bvls05_weighted(&input.raw_jacobian),
        );
        assert!(certificate.held[1] && certificate.held[2]);
        input.raw_jacobian[0][1] = 1.0;
        let raw_rejection = super::bvls05_certificate_for_test(
            &bvls05_roles(&input),
            &input.raw_jacobian,
            &bvls05_weighted(&input.raw_jacobian),
        );
        assert!(!raw_rejection.held[1]);
        let mut weighted = bvls05_weighted(&input.raw_jacobian);
        weighted[0][2] = 1.0;
        let weighted_rejection = super::bvls05_certificate_for_test(
            &bvls05_roles(&input),
            &input.raw_jacobian,
            &weighted,
        );
        assert!(!weighted_rejection.held[2]);
        assert_eq!(certificate.work.bvls05_role_joins_attempted, 6);
        assert_eq!(certificate.work.bvls05_column_entry_tests_attempted, 252);
        let mut nonfinite_normalizer = input.clone();
        nonfinite_normalizer.normalizers[0] = f64::NAN;
        assert_eq!(
            super::prepare_subproblem(&nonfinite_normalizer)
                .err()
                .expect("nonfinite normalizer retains preparation owner")
                .kind,
            M1TrustRegionRefusalKind::SvdNonFinite
        );
        let mut nonfinite_scale = input;
        nonfinite_scale.scales[0] = f64::NAN;
        assert_eq!(
            super::prepare_subproblem(&nonfinite_scale)
                .err()
                .expect("nonfinite scale retains preparation owner")
                .kind,
            M1TrustRegionRefusalKind::SvdNonFinite
        );
    }

    fn bvls05_fixed_active_certificate_and_partition(
        input: &M1TrustRegionSubproblemInput,
    ) -> super::Bvls05CertificateObservation {
        let weighted = bvls05_weighted(&input.raw_jacobian);
        let mut roles = bvls05_roles(input);
        roles[1].initial_free = false;
        roles[2].physical_current_free = false;
        let rejected = super::bvls05_certificate_for_test(&roles, &input.raw_jacobian, &weighted);
        assert!(!rejected.held[1]);
        assert!(!rejected.held[2]);
        let mut bound_free = bvls05_roles(input);
        bound_free[1].initial_free = true;
        bound_free[1].physical_current_free = true;
        let certificate =
            super::bvls05_certificate_for_test(&bound_free, &input.raw_jacobian, &weighted);
        assert!(certificate.held[1]);
        // Drive the real state partition: coordinate 0 is fixed, 3 is at a
        // lower active bound, 4 at an upper active bound, and 5 is ordinary
        // free/releasable.  The admitted certificate is external to physical
        // bounds and never changes this partition.
        let mut state_input = input.clone();
        state_input.lower[0] = 0.0;
        state_input.upper[0] = 0.0;
        let mut state = super::SubproblemState::new(&state_input);
        state.lower_active[3] = true;
        state.free[3] = false;
        state.upper_active[4] = true;
        state.free[4] = false;
        assert!(!state.initial_free[0]);
        assert!(state.initial_free[1]);
        assert!(state.lower_active[3] && !state.free[3]);
        assert!(state.upper_active[4] && !state.free[4]);
        assert!(state.free[5]);
        state.lower_active[3] = false;
        state.free[3] = true;
        assert!(
            state.free[3],
            "ordinary non-held active coordinates release"
        );
        let mut held_step = [1.0_f64; 21];
        held_step[1] = 0.0;
        held_step[2] = 0.0;
        let (scattered, _) = super::bvls05_scatter_held(
            state_input.base,
            certificate.held,
            [0.0; 21],
            state_input.base,
            &mut crate::M1TrustRegionWorkObservation::default(),
        );
        assert_eq!(scattered[1].to_bits(), held_step[1].to_bits());
        assert_eq!(scattered[2].to_bits(), held_step[2].to_bits());
        certificate
    }

    #[test]
    fn m1_trust_region_bvls05_fixed_bound_active_precedence_red() {
        let input = bvls05_diagonal_input();
        let certificate = bvls05_fixed_active_certificate_and_partition(&input);

        // Exercise the actual KKT owner with a fixed coordinate, two
        // certificate-held free coordinates, and independent lower/upper
        // physical active coordinates.  The certificate is only metadata at
        // this pre-body seam; it does not mutate physical masks.
        let mut kkt_input = bvls05_diagonal_input();
        kkt_input.lower[0] = 0.0;
        kkt_input.upper[0] = 0.0;
        // Physical bounds do not make a coordinate fixed when they are only
        // attained by the base: both certified coordinates remain free.
        kkt_input.lower[1] = -2.0;
        kkt_input.base[1] = -2.0;
        kkt_input.upper[2] = 2.0;
        kkt_input.base[2] = 2.0;
        kkt_input.raw_residual[3] = -1.0;
        kkt_input.raw_residual[4] = -2.0;
        let prepared = super::prepare_subproblem(&kkt_input).expect("KKT preparation");
        let mut kkt_state = super::SubproblemState::new(&kkt_input);
        kkt_state.p[3] = -2.0;
        kkt_state.p[4] = 2.0;
        kkt_state.lower_active[3] = true;
        kkt_state.upper_active[4] = true;
        kkt_state.free[3] = false;
        kkt_state.free[4] = false;
        let held = certificate.held;
        assert!(held[1] && held[2]);
        assert!(kkt_state.initial_free[1] && kkt_state.initial_free[2]);
        assert!(kkt_state.free[1] && kkt_state.free[2]);
        let solution = super::FaceSolution {
            free_ids: (0..21)
                .filter(|coordinate| kkt_state.free[*coordinate])
                .collect(),
            trace: super::LambdaTrace {
                lambda: 0.0,
                ..Default::default()
            },
            refined: false,
            factor: None,
            radius: 8.0,
        };
        let transition = super::kkt_transition(&prepared, &mut kkt_state, &solution)
            .expect("actual KKT transition");
        assert!(transition.values.is_none());
        assert_eq!(transition.observation.coordinates.len(), 21);
        for held_coordinate in [1, 2] {
            let observed = &transition.observation.coordinates[held_coordinate];
            assert_eq!(observed.coordinate, held_coordinate);
            assert_eq!(observed.h.to_bits(), 0.0f64.to_bits());
            assert_eq!(observed.cbar.to_bits(), 0.0f64.to_bits());
            assert_eq!(observed.tau.to_bits(), 0.0f64.to_bits());
            assert_eq!(
                observed.class,
                crate::M1TrustRegionOptimalityClass::FreePass
            );
        }
        assert_eq!(
            transition.observation.coordinates[0].class,
            crate::M1TrustRegionOptimalityClass::Fixed
        );
        assert!(
            kkt_state.free[3],
            "actual owner releases lower-active coordinate 3"
        );
        assert!(
            kkt_state.upper_active[4],
            "upper-active coordinate remains retained"
        );
        assert!(kkt_state.initial_free[1] && kkt_state.initial_free[2]);
        let observation = kkt_state
            .events
            .last()
            .and_then(|event| event.g)
            .expect("KKT event");
        assert_eq!(observation[1].to_bits(), 0.0f64.to_bits());
        assert_eq!(observation[2].to_bits(), 0.0f64.to_bits());
    }

    #[test]
    fn m1_trust_region_bvls05_remaining_rank_refusal_red() {
        let retained = [
            0usize, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        ];
        let mut reduced = vec![vec![0.0_f64; 19]; 21];
        for (slot, original) in retained.iter().enumerate() {
            reduced[*original][slot] = 1.0;
        }
        for values in &mut reduced {
            values[1] = values[0];
        }
        let mut sweeps = 0;
        assert_eq!(
            super::jacobi_factor(reduced, &retained, 0, &mut sweeps).err(),
            Some("rank deficient")
        );
    }

    #[test]
    fn m1_trust_region_bvls05_nonempty_hold_zero_lambda_refinement() {
        let mut input = bvls05_diagonal_input();
        for (coordinate, value) in input.raw_residual.iter_mut().enumerate() {
            if !matches!(coordinate, 1 | 2) {
                *value = -1.0;
            }
        }
        let mut expected_p = [0.0_f64; 21];
        for (coordinate, value) in expected_p.iter_mut().enumerate() {
            if !matches!(coordinate, 1 | 2) {
                *value = 1.0;
            }
        }
        assert_eq!(expected_p[1].to_bits(), 0.0f64.to_bits());
        assert_eq!(expected_p[2].to_bits(), 0.0f64.to_bits());
        assert_eq!(
            expected_p
                .iter()
                .filter(|value| value.to_bits() == 1.0f64.to_bits())
                .count(),
            19
        );
        assert_bvls05_exact_array(
            bvls05_full_h(&input.raw_jacobian, input.raw_residual, expected_p, 0.0),
            [0.0; 21],
        );
        let _scope = super::RefinementObservationScope::begin();
        let result = super::solve_subproblem(&input)
            .expect("expected-red: zero-lambda held refinement requires body consumption");
        let trace = super::refinement_observation_take().expect("actual zero-lambda trace");
        let retained = vec![
            0usize, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        ];
        assert_eq!(trace.face_free_ids.as_ref(), Some(&retained));
        assert_eq!(
            trace.factor_order.as_ref(),
            Some(&(0usize..19).collect::<Vec<_>>())
        );
        assert_eq!(trace.p0, Some(expected_p));
        assert_eq!(trace.p1, Some(expected_p));
        assert_eq!(trace.p2, Some(expected_p));
        for held in [1, 2] {
            assert_eq!(
                trace.p0.map(|point| point[held].to_bits()),
                Some(0.0f64.to_bits())
            );
            assert_eq!(
                trace.p1.map(|point| point[held].to_bits()),
                Some(0.0f64.to_bits())
            );
            assert_eq!(
                trace.p2.map(|point| point[held].to_bits()),
                Some(0.0f64.to_bits())
            );
        }
        assert_eq!(trace.lower_mask_p0, Some([false; 21]));
        assert_eq!(trace.upper_mask_p0, Some([false; 21]));
        assert_eq!(trace.lower_mask_p1, Some([false; 21]));
        assert_eq!(trace.upper_mask_p1, Some([false; 21]));
        assert_eq!(trace.lower_mask_p2, Some([false; 21]));
        assert_eq!(trace.upper_mask_p2, Some([false; 21]));
        assert_bvls05_exact_array(result.scaled_step, expected_p);
        assert_eq!(result.lambda.to_bits(), 0.0f64.to_bits());
        assert_bvls05_exact_array(result.final_residual, [0.0; 21]);
        assert_bvls05_exact_array(result.final_h, [0.0; 21]);
        assert_eq!(
            result
                .optimality_observation
                .expect("full KKT")
                .coordinates
                .len(),
            21
        );
        assert_eq!(result.entered_svd_factorizations, 1);
        assert_eq!(result.work.bvls05_role_joins_attempted, 6);
        assert_eq!(result.work.bvls05_column_entry_tests_attempted, 252);
        assert_eq!(result.work.bvls05_mask_joins_attempted, 21);
        assert_eq!(result.work.bvls05_held_base_copies_completed, 2);
        assert_eq!(
            result.candidate_coordinates[1].to_bits(),
            input.base[1].to_bits()
        );
        assert_eq!(
            result.candidate_coordinates[2].to_bits(),
            input.base[2].to_bits()
        );
    }

    #[test]
    fn m1_trust_region_bvls05_nonempty_hold_positive_lambda_refinement() {
        let mut input = bvls05_diagonal_input();
        input.raw_residual[0] = -1.0;
        input.initial_radius = 0.5;
        let mut expected_p = [0.0_f64; 21];
        expected_p[0] = 0.5;
        assert_eq!(expected_p[1].to_bits(), 0.0f64.to_bits());
        assert_eq!(expected_p[2].to_bits(), 0.0f64.to_bits());
        assert_eq!(expected_p[0].to_bits(), 0.5f64.to_bits());
        assert_bvls05_exact_array(
            bvls05_full_h(&input.raw_jacobian, input.raw_residual, expected_p, 1.0),
            [0.0; 21],
        );
        let _scope = super::RefinementObservationScope::begin();
        let result = super::solve_subproblem(&input)
            .expect("expected-red: positive-lambda held refinement requires body consumption");
        let trace = super::refinement_observation_take().expect("actual positive-lambda trace");
        let retained = vec![
            0usize, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        ];
        assert_eq!(trace.face_free_ids.as_ref(), Some(&retained));
        assert_eq!(
            trace.factor_order.as_ref(),
            Some(&(0usize..19).collect::<Vec<_>>())
        );
        assert_eq!(trace.p0, Some(expected_p));
        assert_eq!(trace.p1, Some(expected_p));
        assert_eq!(trace.p2, Some(expected_p));
        for held in [1, 2] {
            assert_eq!(
                trace.p0.map(|point| point[held].to_bits()),
                Some(0.0f64.to_bits())
            );
            assert_eq!(
                trace.p1.map(|point| point[held].to_bits()),
                Some(0.0f64.to_bits())
            );
            assert_eq!(
                trace.p2.map(|point| point[held].to_bits()),
                Some(0.0f64.to_bits())
            );
        }
        assert_eq!(trace.lower_mask_p0, Some([false; 21]));
        assert_eq!(trace.upper_mask_p0, Some([false; 21]));
        assert_eq!(trace.lower_mask_p1, Some([false; 21]));
        assert_eq!(trace.upper_mask_p1, Some([false; 21]));
        assert_eq!(trace.lower_mask_p2, Some([false; 21]));
        assert_eq!(trace.upper_mask_p2, Some([false; 21]));
        assert_bvls05_exact_array(result.scaled_step, expected_p);
        assert_eq!(result.lambda.to_bits(), 1.0f64.to_bits());
        assert_bvls05_exact_array(
            result.final_residual,
            [
                -0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0,
            ],
        );
        assert_bvls05_exact_array(result.final_h, [0.0; 21]);
        assert_eq!(
            result
                .optimality_observation
                .expect("full KKT")
                .coordinates
                .len(),
            21
        );
        assert_eq!(result.entered_svd_factorizations, 1);
        assert_eq!(result.work.bvls05_role_joins_attempted, 6);
        assert_eq!(result.work.bvls05_column_entry_tests_attempted, 252);
        assert_eq!(result.work.bvls05_mask_joins_attempted, 21);
        assert_eq!(result.work.bvls05_held_base_copies_completed, 2);
        assert_eq!(
            result.candidate_coordinates[1].to_bits(),
            input.base[1].to_bits()
        );
        assert_eq!(
            result.candidate_coordinates[2].to_bits(),
            input.base[2].to_bits()
        );
    }

    #[test]
    fn m1_trust_region_bvls05_default_empty_regression() {
        let mut input = bvls05_diagonal_input();
        input.test_work.bvls05_provenance = None;
        input.raw_jacobian[1][1] = 1.0;
        input.raw_jacobian[2][2] = 1.0;
        let certificate = super::bvls05_certificate_for_test(
            &[],
            &input.raw_jacobian,
            &bvls05_weighted(&input.raw_jacobian),
        );
        assert_eq!(certificate.held, [false; 21]);
        assert_eq!(
            certificate.work,
            crate::M1TrustRegionWorkObservation::default()
        );
        let result =
            super::solve_subproblem(&input).expect("default-empty old route remains solvable");
        assert_bvls05_exact_array(result.scaled_step, [0.0; 21]);
        assert_eq!(result.work.bvls05_mask_joins_attempted, 0);
        assert_eq!(result.work.bvls05_held_base_copies_attempted, 0);

        let mut positive = input;
        positive.raw_residual[0] = -1.0;
        positive.initial_radius = 0.5;
        let positive_result = super::solve_subproblem(&positive)
            .expect("default-empty positive-lambda BVLS04 route remains available");
        assert_eq!(positive_result.lambda.to_bits(), 1.0f64.to_bits());
        assert_eq!(positive_result.scaled_step[0].to_bits(), 0.5f64.to_bits());
        assert_eq!(positive_result.work.bvls05_role_joins_attempted, 0);
        eprintln!(
            "BVLS05_DEFAULT_EMPTY_BASELINE {}",
            serde_json::json!({
                "zero_debug": format!("{result:?}"),
                "positive_debug": format!("{positive_result:?}"),
            })
        );
    }

    #[test]
    fn m1_trust_region_bvls05_accounting_caps() {
        let input = bvls05_diagonal_input();
        let certificate = super::bvls05_certificate_for_test(
            &bvls05_roles(&input),
            &input.raw_jacobian,
            &bvls05_weighted(&input.raw_jacobian),
        );
        assert_eq!(certificate.work.bvls05_role_joins_attempted, 6);
        assert_eq!(certificate.work.bvls05_column_entry_tests_attempted, 252);
        assert_eq!(certificate.work.bvls05_mask_joins_attempted, 21);
        let mut inspected_roles = bvls05_roles(&input);
        for role in &mut inspected_roles {
            role.wet_fraction = 0.5;
        }
        let inspected_empty = super::bvls05_certificate_for_test(
            &inspected_roles,
            &input.raw_jacobian,
            &bvls05_weighted(&input.raw_jacobian),
        );
        assert_eq!(inspected_empty.held, [false; 21]);
        assert_eq!(inspected_empty.work.bvls05_role_joins_attempted, 6);
        assert_eq!(inspected_empty.work.bvls05_role_joins_completed, 6);
        assert_eq!(
            inspected_empty.work.bvls05_column_entry_tests_attempted,
            252
        );
        assert_eq!(
            inspected_empty.work.bvls05_column_entry_tests_completed,
            252
        );
        assert_eq!(inspected_empty.work.bvls05_mask_joins_attempted, 21);
        assert_eq!(inspected_empty.work.bvls05_mask_joins_completed, 21);
        let mut base = input.base;
        base[1] = f64::from_bits(0x4009_21fb_5444_2d18);
        base[2] = f64::from_bits(0xc005_bf0a_8b14_5769);
        let mut work = certificate.work.clone();
        let mut step = [f64::from_bits(0x8000_0000_0000_0000); 21];
        step[0] = 3.0;
        let mut candidate = [f64::from_bits(0x4009_21fb_5444_2d18); 21];
        candidate[0] = f64::from_bits(0xc005_bf0a_8b14_5769);
        let (step, candidate) =
            super::bvls05_scatter_held(base, certificate.held, step, candidate, &mut work);
        assert_eq!(step[1].to_bits(), 0.0f64.to_bits());
        assert_eq!(step[2].to_bits(), 0.0f64.to_bits());
        assert_eq!(candidate[1].to_bits(), base[1].to_bits());
        assert_eq!(candidate[2].to_bits(), base[2].to_bits());
        assert_eq!(step[0].to_bits(), 3.0f64.to_bits());
        assert_eq!(candidate[0].to_bits(), 0xc005_bf0a_8b14_5769);
        assert_eq!(work.bvls05_held_base_copies_attempted, 2);
        assert_eq!(work.bvls05_held_base_copies_completed, 2);
        let numerical_before = work.refinement_scalar_operations;
        let additive = work.clone();
        work.absorb(&additive);
        assert_eq!(work.refinement_scalar_operations, numerical_before);
        assert_eq!(work.bvls05_role_joins_attempted, 12);
        assert_eq!(work.bvls05_held_base_copies_attempted, 4);
        assert_eq!(work.bvls05_held_base_copies_completed, 4);
    }
}
