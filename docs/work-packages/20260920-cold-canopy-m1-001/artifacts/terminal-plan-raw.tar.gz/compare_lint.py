"""Compare diagnostic identities using baseline/candidate source lines, not counts."""
import collections, difflib, json, pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path('/home/roger/openwepp-experiments/cold-canopy-m1-refusal-capture-20261002/checks')
BASE = pathlib.Path('/home/roger/openwepp-experiments/cold-canopy-m1-refusal-diagnosis-20261001/source')
CAND = ROOT / 'source'
kind, candidate_name = sys.argv[1:]
base_name = {'lse':'baseline-lse-clippy', 'vegetation':'baseline-vegetation-fresh-clippy'}[kind]

def diagnostics(path):
    output=[]
    for block in re.split(r'(?=^error(?:\[|:))', path.read_text(), flags=re.M):
        if not block.startswith('error'):
            continue
        location=re.search(r'--> ([^\n]+):(\d+):(\d+)',block)
        if not location:
            continue
        rel,line,col=location.groups()
        lint=re.search(r'rust-clippy/master/index.html#([^\s]+)',block)
        output.append({'message':block.splitlines()[0], 'file':rel,'line':int(line),'column':int(col),'lint':lint.group(1) if lint else None,'block':block})
    return output
baseline=diagnostics(OLD/(base_name+'.stderr'))
candidate=diagnostics(ROOT/'checks'/(candidate_name+'.stderr'))
line_maps={}
for item in candidate:
    rel=item['file']
    if rel in line_maps:
        continue
    a=(BASE/rel).read_text().splitlines();b=(CAND/rel).read_text().splitlines()
    line_map={}
    for match in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_matching_blocks():
        for i in range(match.size):
            line_map[match.b+i+1]=match.a+i+1
    line_maps[rel]=line_map
used=set();rows=[]
for c in candidate:
    original=line_maps[c['file']].get(c['line'])
    matches=[i for i,b in enumerate(baseline) if i not in used and (b['file'],b['line'],b['lint'],b['message'])==(c['file'],original,c['lint'],c['message'])]
    if matches:
        used.add(matches[0]);status='EXACT_DIAGNOSTIC_ON_UNCHANGED_SOURCE_LINE'
    else:
        status='REQUIRES_SOURCE_REVIEW'
    rows.append(dict(c,baseline_line=original,classification=status))
result={'evidence_class':'Static: diagnostic and exact source-line comparison; unresolved entries require independent review','baseline_command_receipt':str(OLD/(base_name+'.json')),'candidate_command_receipt':str(ROOT/'checks'/(candidate_name+'.json')),'baseline_count':len(baseline),'candidate_count':len(candidate),'matched_count':len(used),'unmatched_baseline':[b for i,b in enumerate(baseline) if i not in used],'candidate':rows}
(ROOT/'checks'/(candidate_name+'-comparison.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='candidate' and k!='unmatched_baseline'}))
for row in rows:
    if row['classification']=='REQUIRES_SOURCE_REVIEW':
        print(row['block'])
