"""Independent offline arithmetic on captured IEEE754 operands; never invokes model."""
import fractions,json,math,pathlib,struct,sys
ROOT=pathlib.Path(__file__).resolve().parent
from capture_payload import payload_record
F=fractions.Fraction

def value(bits):return struct.unpack('>d',struct.pack('>Q',bits))[0]
def bits(x):return struct.unpack('>Q',struct.pack('>d',x))[0]
def exact(x):
 if not math.isfinite(x):return None
 f=F.from_float(x);return {'numerator':str(f.numerator),'denominator':str(f.denominator)}
def key(x):
 b=bits(x);return ~b & ((1<<64)-1) if b>>63 else b | (1<<63)
def readable(x):return x if math.isfinite(x) else repr(x)
def pair(left,right,relation,units):
 finite=math.isfinite(left) and math.isfinite(right)
 difference=((F.from_float(left)-F.from_float(right)) if relation=='>' else (F.from_float(right)-F.from_float(left))) if finite else None
 violation=left-right if relation=='>' else right-left
 return {'left_bits':bits(left),'right_bits':bits(right),'left':readable(left),'right':readable(right),'relation':relation,'holds':left>right if relation=='>' else left<right,'signed_violation':readable(violation),'signed_violation_bits':bits(violation),'units':units,'ulp_distance':abs(key(left)-key(right)) if finite else None,'exact_left':exact(left),'exact_right':exact(right),'exact_signed_violation':{'numerator':str(difference.numerator),'denominator':str(difference.denominator)} if difference is not None else None}
def partial_prefix(n):
 # Reconstruct ONLY operations whose result bits were captured. No sqrt or
 # further coordinate is evaluated merely to complete an interrupted trace.
 vals=n['value_bits']; squares=n['square_bits']; sums=n['running_sum_bits']
 total=0.; computed_squares=[];computed_sums=[]; exact_sum=F(0);exact_finite=True
 for i,b in enumerate(squares):
  v=value(vals[i]);computed_squares.append(bits(v*v))
  if math.isfinite(v):exact_sum+=F.from_float(v)**2
  else:exact_finite=False
 for i,b in enumerate(sums):
  total+=value(squares[i]);computed_sums.append(bits(total))
 sqrt_observed=n.get('sqrt_bits')
 sqrt_match=None
 if sqrt_observed is not None:
  sqrt_match=bits(math.sqrt(total))==sqrt_observed if total>=0 else False
 return {'role':n['role'],'terminal_operation':n['terminal_operation'],'coordinate_ids':n['coordinate_ids'],'value_count':len(vals),'square_count':len(squares),'sum_count':len(sums),'squares_match':computed_squares==squares,'running_sums_match':computed_sums==sums,'sqrt_matches_if_observed':sqrt_match,'exact_reached_square_sum':{'numerator':str(exact_sum.numerator),'denominator':str(exact_sum.denominator)} if exact_finite else None,'unreached_operations_evaluated':False}
def main(w):
 raw,payload=payload_record((ROOT/'captures'/f'{w}.stdout').read_bytes(),67108864);r=(payload.get('refinement_capture') or {}).get('refinement');out={'evidence_class':'Ran: independent offline binary64/Fraction arithmetic on actual retained bits only','witness':w,'capture_complete':payload.get('capture_complete'),'controller_result':payload['controller_result'],'norms':[],'inequality':None}
 if r is None:
  out['status']='NO_REACHED_REFINEMENT_OPERANDS'
 else:
  out['terminal']=r.get('terminal_refusal');out['completeness']=r.get('completeness');out['partial_norms_preserved_not_completed']=r.get('partial_ordered_norms',[]);out['partial_norm_reconstruction']=[partial_prefix(n) for n in r.get('partial_ordered_norms',[])];out['factor_snapshots']=r.get('factor_application_snapshots',[])
  for n in r['ordered_norm_traces']:
   total=0.;squares=[];sums=[];exact_sum=F(0)
   for b in n['value_bits']:
    v=value(b);s=v*v;total+=s;squares.append(bits(s));sums.append(bits(total))
    if math.isfinite(v):exact_sum+=F.from_float(v)**2
   norm=math.sqrt(total)
   out['norms'].append({'role':n['role'],'coordinate_ids':n['coordinate_ids'],'squares_match':squares==n['square_bits'],'running_sums_match':sums==n['running_sum_bits'],'norm2_matches':bits(total)==n['norm2_bits'],'sqrt_matches':bits(norm)==n['norm_bits'],'binary64_sum_bits':bits(total),'binary64_norm_bits':bits(norm),'exact_operand_square_sum':{'numerator':str(exact_sum.numerator),'denominator':str(exact_sum.denominator)}})
  terminal=r.get('terminal_refusal') or {};m=terminal.get('refinement') or {};stage=m.get('guard_stage');inp=payload['refinement_capture']['input']
  if stage in ('P0FullRadius','ScratchFullRadius','FinalFullRadius'):
   name={'P0FullRadius':'p0','ScratchFullRadius':'p1','FinalFullRadius':'p2'}[stage];n=r.get(name+'_full_norm_bits')
   if n is not None:out['inequality']=pair(value(n),value(inp['initial_radius_bits']),'>','dimensionless scaled full-step norm')
  elif stage in ('P0ReducedRadius','ScratchReducedRadius','FinalReducedRadius'):
   name={'P0ReducedRadius':'p0','ScratchReducedRadius':'p1','FinalReducedRadius':'p2'}[stage];n=r.get(name+'_reduced_norm_bits')
   if n is not None:out['inequality']=pair(value(n),value(r['remaining_radius_bits'] if stage=='FinalReducedRadius' else r['reduced_face_radius_bits']),'>','dimensionless scaled free-face norm')
  elif stage=='RadiusComparison':
   role={None:'p0_zero_lambda_eligibility','First':'p1_zero_lambda_scratch','Second':'p2_zero_lambda_final'}.get(m.get('correction_position'))
   ns=[n for n in r['ordered_norm_traces'] if n['role']==role]
   if len(ns)==1:out['inequality']=pair(value(ns[0]['norm_bits']),value(inp['initial_radius_bits']),'>','dimensionless zero-lambda full-step norm')
  elif stage=='FinalRadiusCloseness' and r.get('radius_gap_bits') is not None and r.get('radius_tolerance_bits') is not None:
   gap=value(r['radius_gap_bits']); tolerance=value(r['radius_tolerance_bits'])
   out['inequality']=pair(gap,0.,'<','dimensionless radius gap') if gap<0 else pair(gap,tolerance,'>','dimensionless radius gap')
  elif stage in ('FinalBoxLower','FinalBoxUpper','ScratchBoxLower','ScratchBoxUpper'):
   i=m.get('coordinate');name='p2' if stage.startswith('Final') else 'p1';vec=r.get(name+'_bits');lower=stage.endswith('Lower');bound=r.get('scaled_lower_bits' if lower else 'scaled_upper_bits')
   if i is not None and vec is not None and bound is not None:
    out['inequality']=pair(value(vec[i]),value(bound[i]),'<' if lower else '>','dimensionless scaled coordinate');out['inequality']['coordinate']=i
  out['status']='RECONSTRUCTED_REACHED_COMPARISON' if out['inequality'] is not None else 'ACTUAL_BRANCH_REQUIRES_SEPARATE_RECONSTRUCTION_NO_SUBSTITUTE'
 (ROOT/'captures'/f'{w}-independent-arithmetic.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({'witness':w,'status':out['status']}))
if __name__=='__main__':main(sys.argv[1])
