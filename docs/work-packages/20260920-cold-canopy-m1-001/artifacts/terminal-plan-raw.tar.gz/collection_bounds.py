"""Static source excerpts and conservative cardinality proof; no physical execution."""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
rel='crates/openwepp-land-surface-energy/src/m1_trust_region_stage1.rs'
s=(R/'source'/rel).read_text()
names=['refine_face_before_crossing','refine_face_before_crossing_inner','refinement_eligible_p0','refinement_check_positive_p0_radii','refinement_check_first_scratch','refinement_check_positive_first_scratch_full_radius','refinement_check_positive_first_scratch_reduced_radius','refinement_finalize_candidate','refinement_final_full_radius','refinement_final_reduced_radius','refinement_check_zero_lambda_final_radius','refinement_apply_first_factor','refinement_apply_second_factor','refinement_observe_factor_application','bvls04_ordered_norm','lambda_norm','refinement_observe_completed_ordered_norm','refinement_observe_shifted_inverse']
functions={}
for name in names:
 m=re.search(r'^fn '+name+r'\(',s,re.M);assert m,name
 start=s.index('{',m.end());end=start+1;depth=1
 while depth:
  depth+=(s[end]=='{')-(s[end]=='}');end+=1
 body=s[m.start():end]
 functions[name]={'line':s[:m.start()].count('\n')+1,'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'source':body}
result={'status':'STATIC_ARGUMENT_REQUIRES_INDEPENDENT_REVIEW','source_pins':{rel:hashlib.sha256(s.encode()).hexdigest()},'scope':'one retained refinement face, fixed support0 IPC; no aggregate over faces','bounds':{'ordered_norm_traces':6,'partial_ordered_norms':6,'factor_application_snapshots':2},'argument':[
 'refine_face_before_crossing resets the entire RefinementObservationTrace before each call to inner; earlier faces do not accumulate into the retained trace.',
 'inner has one eligibility call, one first-scratch check, one final-candidate/finalization chain; no retry/loop of these stages.',
 'Positive lambda: eligibility calls p0_full then p0_free once each; first scratch calls p1_full then p1_free once each; finalization calls p2_full then p2_free once each. At most six completed norm push sites are reached once.',
 'Zero lambda: one lambda_norm per p0 eligibility, p1 scratch, p2 final. The positive and zero paths are exclusive. Calls with work=None do not install these refinement-role observations.',
 'Each norm call returns immediately after emitting its interrupted prefix; it cannot emit a second partial or successful norm afterward. Its caller propagates error. Six is a conservative independent partial bound (the selected face can actually terminate after only one partial norm).',
 'inner calls first and second factor application at most once each. Each application increments/appends once before its computations; no retry of an application. At most two snapshots.',
 'Each vector inside a norm/snapshot is bounded by the 21-coordinate input/factor dimensions; ordinal is first or second. No observer truncation is used to establish any bound.'
 ],'functions':functions}
(R/'collection-bound-draft.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_pin':result['source_pins'][rel],'bounds':result['bounds']}))
