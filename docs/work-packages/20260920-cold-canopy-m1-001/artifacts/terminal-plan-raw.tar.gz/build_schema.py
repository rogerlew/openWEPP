"""Prospective serialization envelope. Offline source/fixture inspection only."""
import json,pathlib,hashlib,re
ROOT=pathlib.Path(__file__).resolve().parent
S={'kind':'uint64'}
B={'kind':'bool'}
def string(n=1024): return {'kind':'string','max_utf8_bytes':n}
def array(item=S,n=21): return {'kind':'array','max_items':n,'item':item}
def obj(fields): return {'kind':'object','fields':fields}
def opt(v):return {'kind':'optional','value':v}
def fields(names,typ=S):return {n:typ for n in names.split()}
vector=array(); matrix=array(vector)
input_fields=fields('coordinate_ids row_ids raw_residual_bits normalizer_bits scale_bits lower_bits upper_bits base_bits',vector)
input_fields.update(raw_jacobian_bits=matrix, initial_radius_bits=S)
work_names='stage1_calls entered_svd_factorizations completed_face_pivots total_jacobi_sweeps refinement_scalar_operations refinement_guard_events refinement_attempted_entries refinement_denied_entries bvls04_positive_entries bvls04_factor_applications bvls04_dot2_residual_rows bvls04_dot2_free_gradients bvls04_ordered_norms first_residual_operations second_dot2_operations factor_application_operations coordinate_update_operations whole_kkt_operations whole_kkt_guard_events upward_enclosure_operations upward_enclosure_guard_events bvls05_role_joins_attempted bvls05_role_joins_completed bvls05_column_entry_tests_attempted bvls05_column_entry_tests_completed bvls05_mask_joins_attempted bvls05_mask_joins_completed bvls05_held_base_copies_attempted bvls05_held_base_copies_completed'
meta=fields('reason correction_position guard_stage',string())
meta.update(fields('row term coordinate lambda_bits original_trust_radius_bits reduced_face_radius_bits',opt(S)))
meta.update(fields('lower_active upper_active free',array(B)))
meta['scratch_box_feasible']=opt(B)
terminal=fields('kind optimality_reason',opt(string()))
terminal.update(fields('optimality_coordinate optimality_radius_bits optimality_lambda_bits attempted_subproblems completed_jacobi_sweeps completed_face_pivots entered_svd_factorizations raw_residual_max_bits',opt(S)))
terminal['refinement']=opt(obj(meta))
r=fields('free_ids factor_order weighted_residual_bits factor_sigma_bits scaled_lower_bits scaled_upper_bits live_state_entry_bits live_state_exit_bits p0_bits residual0_bits h0_bits delta0_bits p1_bits residual1_bits h1_bits inverse_t_bits inverse_denominator_bits inverse_z_bits delta1_bits p2_bits',opt(vector))
r.update(fields('factor_a_bits factor_v_bits weighted_matrix_bits',opt(matrix)))
r.update(fields('lambda_bits reduced_face_radius_bits factor_identity factor_applications eligibility_scalar_operations eligibility_guard_events p0_full_norm2_bits p0_full_norm_bits p0_reduced_norm2_bits p0_reduced_norm_bits p1_full_norm2_bits p1_full_norm_bits p1_reduced_norm2_bits p1_reduced_norm_bits p2_full_norm2_bits p2_full_norm_bits p2_reduced_norm2_bits p2_reduced_norm_bits remaining_radius_bits radius_gap_bits radius_tolerance_bits',opt(S)))
r.update(fields('free_mask held_mask lower_mask_p0 upper_mask_p0 lower_mask_p1 upper_mask_p1 lower_mask_p2 upper_mask_p2 lower_mask_exit upper_mask_exit',opt(array(B))))
r.update(fields('formulation fixed_coordinate_reconstruction reservation_denial_owner',opt(string())))
r['logical_to_physical_map']=vector
r['factor_application_identities']=array(S,2)
r['state_roles']=obj(fields('base_physical face_start_scaled initial_scaled private_scratch final_candidate live_face_exit',string()))
norm=fields('role',string());norm.update(fields('coordinate_ids value_bits square_bits running_sum_bits',vector));norm.update(fields('norm2_bits norm_bits'))
r['ordered_norm_traces']=array(obj(norm),6)
partial_norm=fields('role terminal_operation',string(256));partial_norm.update(fields('coordinate_ids value_bits square_bits running_sum_bits',vector));partial_norm['sqrt_bits']=opt(S)
r['partial_ordered_norms']=array(obj(partial_norm),6)
factor_snapshot=fields('ordinal identity');factor_snapshot.update(fields('h_bits inverse_t_bits inverse_denominator_bits inverse_z_bits delta_bits',opt(vector)))
r['factor_application_snapshots']=array(obj(factor_snapshot),2)
r['factor_output_copy_boundary']=opt(obj({'ordinal':S,'boundary':string(14)}))

stage1_text=(ROOT/'source/crates/openwepp-land-surface-energy/src/m1_trust_region_stage1.rs').read_text()
from status_keys import status_keys
r['field_status']=obj({name:string(64) for name in status_keys(stage1_text)})
r['terminal_refusal']=opt(obj(terminal));r['work_ledger']=opt(obj(fields(work_names)))
# Updated from final exact serializer before freeze; this draft cannot authorize capture.
r['completeness']=obj(dict(fields('reached_prefix_complete expected_terminal_match actual_branch_complete missing_capture_is_incomplete',B), **fields('witness actual_terminal_stage actual_terminal_kind actual_terminal_reason actual_correction_position',opt(string()))))
context=fields('site state_role representation map_identity pass',string(256))
context['fd_side']=opt(string(256))
context.update(fields('occupancy mass_index enthalpy_index fd_column source_mass_bits source_enthalpy_bits',opt(S)))
context.update(fields('trial_coordinate_bits proposal_direction_bits',opt(vector)))
event=fields('ordinal event_id call_id mass_bits enthalpy_bits')
event.update(temperature_bits=opt(S),predicate=string(),terminal_propagated=B,context=opt(obj(context)))
adapter=fields('current_evaluations natural_assemblies selected_assemblies trial_domain_checks')
adapter.update(fields('current_coordinate_bits raw_residual_bits dynamic_normalizer_bits final_direction_bits',opt(vector)))
adapter['raw_jacobian_bits']=opt(matrix)
adapter['phase_events']=array(obj({'coordinate_bits':vector,'direction_bits':vector,'selections':string(32768),'natural_cache':B}),0)
adapter['controller_terminal_refusal']=opt(string())
request=obj({'witness':string(2),'case':string(22),'support_id':S,'cadence_seconds':S})
root={'schema':string(),'request':request,'case_id':string(22),'support_id':S,'seed_coordinate_bits':vector,'controller_result':string(json.loads((ROOT/'outcome-type-bound-draft.json').read_text())['raw_debug_bound_bytes']),'adapter_observation':obj(adapter),'refinement_capture':opt(obj({'input':obj(input_fields),'refinement':obj(r)})),'mh_refusal_total_count':S,'mh_refusal_truncated':B,'mh_refusal_observer_error':B,'mh_refusal_terminal_event_id':opt(S),'refinement_capture_present':B,'capture_complete':B,'capture_status':string(),'mh_refusal_events':array(obj(event),2048),'phase_note':string()}
schema={'status':'DRAFT_NOT_APPROVED','payload_cap_bytes':67108864,'root':obj(root),'unproved':['Final completeness/context fields not frozen','Natural finite event bound and no-drop behavior','Final source field-to-hook table','Type-derived outcome Debug proof must be revalidated against final source pins','phase_events zero and ordered_norms six proof']}
(ROOT/'schema-draft.json').write_text(json.dumps(schema,indent=2)+'\n')
print('wrote prospective DRAFT only')
