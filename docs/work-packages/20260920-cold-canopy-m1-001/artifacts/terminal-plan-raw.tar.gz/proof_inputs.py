"""Pin source inputs for existing byte/event proofs; never evaluates the model."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent; S=R/'source'
files={
 'event_callgraph':['crates/openwepp-land-surface-energy/src/m1_trust_region_controller.rs','crates/openwepp-land-surface-energy/src/m1_trust_region_controller_interface.rs','crates/openwepp-land-surface-energy/src/solver_covered_evaluation/m1_coupled.rs','crates/openwepp-land-surface-energy/src/m1_coupled_tests.rs','crates/openwepp-vegetation/src/cold_canopy_m1.rs'],
 'norm_and_serializer':['crates/openwepp-land-surface-energy/src/m1_trust_region_stage1.rs'],
 'fixed_fixture':['control-repair-control-fixtures.json']}
outcome=json.loads((R/'outcome-type-bound-draft.json').read_text())
files['outcome_Debug_types']=list(outcome['source_pins'])
collection=json.loads((R/'collection-bound-draft.json').read_text())
for artifact in (outcome,collection):
 for rel,expected in artifact['source_pins'].items():
  actual=hashlib.sha256((S/rel).read_bytes()).hexdigest()
  assert actual==expected, f'Stale proof source pin: {rel}'
files['collection_bounds']=list(collection['source_pins'])
pins={str(S/p):hashlib.sha256((S/p).read_bytes()).hexdigest() for paths in files.values() for p in paths}
original=Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts/original-input-reference.json');pins[str(original)]=hashlib.sha256(original.read_bytes()).hexdigest()
result={'status':'SOURCE_PINS_NOT_APPROVAL','groups':files,'pins':pins,'proof_artifact_pins':{str(R/name):hashlib.sha256((R/name).read_bytes()).hexdigest() for name in ['event-bound-review.json','outcome-type-bound-draft.json','collection-bound-draft.json']},'event_bound':json.loads((R/'event-bound-review.json').read_text()),'obligation':'Independent review must verify unchanged selected physical callgraph, natural caps, norm trace count and dynamic outcome vector bounds; matching pin alone is not review.'}
(R/'proof-inputs.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'proof_pins':len(pins)}))
