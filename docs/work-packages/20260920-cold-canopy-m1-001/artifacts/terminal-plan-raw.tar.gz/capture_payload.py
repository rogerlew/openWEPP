"""Offline strict IPC parsing and schema checks; never invokes a physical model."""
import json

MARKER = b'M1_REFUSAL_CAPTURE '
TEST_PREFIX = b'test m1_coupled_tests::m1_refusal_capture_support0_ipc ... '


def reject_constant(value):
    raise ValueError('Nonstandard JSON constant: ' + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def strict_json(raw):
    return json.loads(raw.decode('utf-8', errors='strict'),
                      parse_constant=reject_constant, object_pairs_hook=unique_object)


def payload_record(stdout, cap):
    # Count all markers, including malformed framing and duplicate records.
    if stdout.count(MARKER) != 1:
        raise ValueError('Exactly one marker required')
    line = next(line for line in stdout.split(b'\n') if MARKER in line)
    prefix, marker, raw = line.partition(MARKER)
    if prefix not in (b'', TEST_PREFIX):
        raise ValueError('Unexpected libtest framing')
    if not marker or len(raw) > cap:
        raise ValueError('Payload cap exceeded')
    return raw, strict_json(raw)


def validate_schema(value, node, path='$'):
    kind = node['kind']
    if kind == 'optional':
        if value is not None:
            validate_schema(value, node['value'], path)
    elif kind == 'object':
        if type(value) is not dict or set(value) != set(node['fields']):
            raise ValueError('Object keys/type: ' + path)
        for key, child in node['fields'].items():
            validate_schema(value[key], child, path + '.' + key)
    elif kind == 'array':
        if type(value) is not list or len(value) > node['max_items']:
            raise ValueError('Array type/bound: ' + path)
        for index, item in enumerate(value):
            validate_schema(item, node['item'], path + '[' + str(index) + ']')
    elif kind == 'uint64':
        if type(value) is not int or not 0 <= value < 2**64:
            raise ValueError('uint64: ' + path)
    elif kind == 'bool':
        if type(value) is not bool:
            raise ValueError('bool: ' + path)
    elif kind == 'string':
        if type(value) is not str or len(value.encode('utf-8')) > node['max_utf8_bytes']:
            raise ValueError('String type/bound: ' + path)
    else:
        raise ValueError('Unknown schema kind: ' + kind)


def validate_payload(payload, schema, witness):
    validate_schema(payload, schema['root'])
    case = 'A_cold_ice_day' if witness == 'W1' else 'C_freeze_then_melt_day'
    expected = {'witness': witness, 'case': case, 'support_id': 0, 'cadence_seconds': 60}
    if (payload['request'] != expected or payload['case_id'] != case
            or payload['support_id'] != 0
            or payload['schema'] != 'cold-canopy-m1-refusal-capture-v1'):
        raise ValueError('Request/schema mismatch')
    if (payload['capture_complete'] is not True or payload['capture_status'] != 'complete'
            or payload['mh_refusal_truncated'] or payload['mh_refusal_observer_error']):
        raise ValueError('Incomplete capture')
    events = payload['mh_refusal_events']
    if payload['mh_refusal_total_count'] != len(events):
        raise ValueError('Event count/no-drop mismatch')
    if [e['ordinal'] for e in events] != list(range(len(events))):
        raise ValueError('Event ordinal mismatch')
    ids = [e['event_id'] for e in events]
    if len(set(ids)) != len(ids) or any(e['context'] is None for e in events):
        raise ValueError('Event identity/context mismatch')
    terminal = payload['mh_refusal_terminal_event_id']
    propagated = [e['event_id'] for e in events if e['terminal_propagated']]
    if propagated != ([] if terminal is None else [terminal]):
        raise ValueError('Terminal event join mismatch')
    if witness == 'W3' and terminal is None:
        raise ValueError('W3 missing terminal event')
    capture = payload['refinement_capture']
    if witness != 'W3':
        if capture is None or not payload['refinement_capture_present']:
            raise ValueError('Missing reached refinement')
        complete = capture['refinement']['completeness']
        if (not complete['reached_prefix_complete'] or not complete['actual_branch_complete']
                or complete['missing_capture_is_incomplete']):
            raise ValueError('Incomplete atomic branch')
        statuses = capture['refinement']['field_status'].values()
        if any(s.startswith(('missing_', 'contradictory_')) for s in statuses):
            raise ValueError('Invalid field status')
