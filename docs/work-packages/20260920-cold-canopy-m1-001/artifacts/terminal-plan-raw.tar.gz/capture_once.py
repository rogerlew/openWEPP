"""Execute one already approved fixed support-0 witness; permanently reserve first."""
import datetime, fcntl, hashlib, json, os, pathlib, selectors, signal, subprocess, sys, time
if not __debug__:
    raise SystemExit('Optimized Python is prohibited; no capture launch')
ROOT = pathlib.Path(__file__).resolve().parent
from capture_payload import payload_record, validate_payload
ART = pathlib.Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
witness = sys.argv[1]
assert witness in ('W1', 'W2', 'W3')
receipt = json.loads((ART / 'terminal-plan-approved.json').read_text())
assert receipt['correctness_approved'] is True and receipt['qa_approved'] is True
assert datetime.datetime.fromisoformat(receipt['sealed_utc']) <= datetime.datetime.fromisoformat(receipt['readiness_deadline_utc'])
now = datetime.datetime.now(datetime.timezone.utc)
assert now + datetime.timedelta(seconds=30) <= datetime.datetime.fromisoformat(receipt['capture_deadline_utc'])
# Do not rebuild: exact immutable artifact and protocol only.
binary = pathlib.Path(receipt['binary_path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == receipt['binary_sha256']
for path, expected in receipt['required_capture_pins'].items():
    assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() == expected, path
schema_path = pathlib.Path(receipt['schema_path'])
assert hashlib.sha256(schema_path.read_bytes()).hexdigest() == receipt['schema_sha256']
schema = json.loads(schema_path.read_text())
ledger_path = ART / 'refusal-branch-completeness-accounting.json'
ledger_lock = (ART / 'refusal-branch-completeness-accounting.lock').open('a')
try:
    fcntl.flock(ledger_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    raise SystemExit('Concurrent reservation holds ledger lock; no launch')

def save_ledger(value):
    temporary = ledger_path.with_suffix('.json.tmp')
    with temporary.open('w') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, ledger_path)
    directory = os.open(str(ART), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

ledger = json.loads(ledger_path.read_text())
assert str(ledger_path.resolve()) == receipt['ledger_path']
assert ledger['anchor_utc'] == receipt['accounting_anchor_utc']
assert ledger['ceiling_seconds'] == receipt['accounting_ceiling_seconds']
assert ledger['readiness_deadline_utc'] == receipt['readiness_deadline_utc']
assert ledger['work_cutoff_utc'] == receipt['capture_deadline_utc']
slot = ledger['slots'][witness]
assert slot['reserved'] == slot['invocations'] == 0
for previous in ('W1', 'W2', 'W3')[:('W1', 'W2', 'W3').index(witness)]:
    assert ledger['slots'][previous]['invocations'] == 1
assert sum(s['elapsed_seconds'] for s in ledger['slots'].values()) < 90
now = datetime.datetime.now(datetime.timezone.utc)
assert now + datetime.timedelta(seconds=30) <= datetime.datetime.fromisoformat(receipt['capture_deadline_utc'])
slot.update(reserved=1, invocations=1, status='RESERVED_BEFORE_PROCESS_START', reserved_utc=now.isoformat())
ledger['physical_invocations'] = sum(s['invocations'] for s in ledger['slots'].values())
save_ledger(ledger)
command = receipt['commands'][witness]
assert command[0] == str(binary)
assert command[1:] == ['--exact', 'm1_coupled_tests::m1_refusal_capture_support0_ipc', '--ignored', '--nocapture', '--test-threads=1']
stdin = receipt['stdin'][witness].encode()
caps = {'stdout': receipt['stdout_transport_cap_bytes'], 'stderr': receipt['stderr_diagnostic_cap_bytes']}
logs = ROOT / 'captures'
logs.mkdir(exist_ok=True)
start = time.monotonic()
record = {'witness': witness, 'command': command, 'stdin': stdin.decode(), 'binary_sha256': receipt['binary_sha256'], 'start_utc': now.isoformat(), 'timeout_seconds': 30, 'process_cutoff_seconds': 29, 'cleanup_reserve_seconds': 1, 'output_cap_bytes': caps}
launch_now = datetime.datetime.now(datetime.timezone.utc)
if launch_now + datetime.timedelta(seconds=30) > datetime.datetime.fromisoformat(receipt['capture_deadline_utc']):
    slot.update(status='RESERVED_NO_LAUNCH_ABSOLUTE_DEADLINE', elapsed_seconds=0)
    save_ledger(ledger)
    raise SystemExit('Absolute capture deadline reached after reservation; no retry')
child = subprocess.Popen(command, cwd=receipt['cwd'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
child.stdin.write(stdin)
child.stdin.close()
sel = selectors.DefaultSelector()
streams = {}
for name, pipe in [('stdout', child.stdout), ('stderr', child.stderr)]:
    sel.register(pipe, selectors.EVENT_READ, name)
    streams[name] = (logs / (witness + '.' + name)).open('wb')
counts = {'stdout': 0, 'stderr': 0}
overflow = {}
stop = None
while sel.get_map():
    remaining = 29 - (time.monotonic() - start)
    if remaining <= 0:
        stop = 'TIMEOUT'
        break
    for key, _ in sel.select(min(remaining, 0.1)):
        capacity = caps[key.data] - counts[key.data]
        chunk = os.read(key.fd, min(65536, capacity + 1))
        if not chunk:
            sel.unregister(key.fileobj)
            continue
        streams[key.data].write(chunk[:capacity])
        counts[key.data] += min(len(chunk), capacity)
        if len(chunk) > capacity:
            overflow[key.data] = chunk[capacity:].hex()
            stop = 'OUTPUT_CAP_EXCEEDED'
            break
    if stop:
        break
if stop:
    os.killpg(child.pid, signal.SIGKILL)
else:
    remaining = max(0.001, 29 - (time.monotonic() - start))
    try:
        child.wait(timeout=remaining)
    except subprocess.TimeoutExpired:
        stop = 'TIMEOUT'
        os.killpg(child.pid, signal.SIGKILL)
child.wait(timeout=1)
for stream in streams.values():
    stream.close()
record.update(exit=child.returncode, stop=stop, elapsed_seconds=time.monotonic()-start, output_bytes=counts)
stdout_bytes = (logs / (witness+'.stdout')).read_bytes()
record['selected_one_test'] = b'running 1 test\n' in stdout_bytes and b'running 0 tests' not in stdout_bytes
record['overflow_bytes_hex'] = overflow
record['capture_records'] = stdout_bytes.count(b'M1_REFUSAL_CAPTURE ')
record['capture_complete'] = False
record['payload_within_cap'] = False
record['schema_valid'] = False
try:
    raw, payload = payload_record(stdout_bytes, receipt['payload_cap_bytes'])
    record['capture_payload_bytes'] = len(raw)
    record['payload_within_cap'] = True
    schema_path = pathlib.Path(receipt['schema_path'])
    assert hashlib.sha256(schema_path.read_bytes()).hexdigest() == receipt['schema_sha256']
    validate_payload(payload, schema, witness)
    record['schema_valid'] = True
    record['capture_complete'] = True
except (ValueError, TypeError, KeyError, AssertionError) as error:
    record['parse_or_validation_error'] = str(error)
record['execution_pass'] = child.returncode == 0 and stop is None and record['selected_one_test'] and record['capture_records'] == 1 and record['payload_within_cap'] and record['capture_complete'] and record['schema_valid']
for suffix in ('stdout', 'stderr'):
    record[suffix+'_sha256'] = hashlib.sha256((logs / (witness+'.'+suffix)).read_bytes()).hexdigest()
(logs / (witness+'.json')).write_text(json.dumps(record, indent=2)+'\n')
slot.update(status='FINISHED_NO_RETRY', elapsed_seconds=record['elapsed_seconds'], exit=record['exit'], stop=stop)
save_ledger(ledger)
print(json.dumps(record))
