"""Static Rust type/fixture-driven Debug byte envelope, no Rust execution."""
import pathlib,re,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT/'source'
ART=pathlib.Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
ANY=object(); structs={};enums={};locations={};pins={};used={};dynamic=[]
def split_top(text):
 parts=[];begin=0;depth=0
 for i,c in enumerate(text):
  if c in '<[(':depth+=1
  elif c in '>])':depth-=1
  elif c==',' and depth==0:parts.append(text[begin:i]);begin=i+1
 if text[begin:].strip():parts.append(text[begin:])
 return parts
for path in sorted((SRC/'crates').rglob('*.rs')):
 text=path.read_text();text=re.sub(r'//[^\n]*','',text);text=re.sub(r'/\*.*?\*/','',text,flags=re.S);text=re.sub(r'#\[.*?\]','',text,flags=re.S)
 for m in re.finditer(r'\b(struct|enum)\s+(\w+)\s*\{([^{}]*)\}',text,re.S):
  kind,name,body=m.groups()
  if name in locations:continue
  locations[name]=str(path.relative_to(SRC))
  if kind=='struct':
   fs=[]
   for f in split_top(body):
    f=re.sub(r'^\s*pub(?:\([^)]*\))?\s+','',f.strip())
    z=re.fullmatch(r'(\w+)\s*:\s*(.+)',f.strip(),re.S)
    if not z:break
    fs.append((z[1],re.sub(r'\s+','',z[2])))
   else:structs[name]=fs
  else:
   vs=[v.strip() for v in split_top(body)]
   if all(re.fullmatch(r'\w+',v) for v in vs):enums[name]=vs

def bound(typ,value=ANY,path='outcome'):
 typ=typ.rsplit('::',1)[-1] if '::' in typ and '<' not in typ else typ
 if typ=='f64':return 330
 if typ=='bool':return 5
 if typ in ('u8','u16','u32','u64','usize','i32','i64'):return 20
 if typ=='String':
  n=64 if value is ANY else len(value.encode())
  assert n<=64,(path,n)
  return 2+10*n
 if typ in ('Sha256Digest','OfeId','TileId'):
  used[typ]={'kind':'derived Debug String newtype','source': 'crates/openwepp-land-surface-energy/src/identity.rs' if typ!='TileId' else 'crates/openwepp-kernel-contract/src/lib_mod/resource_transaction.rs'}
  return len(typ)+2+bound('String',value,path)
 if typ.startswith('Option<'):
  if value is None:return 4
  return max(4,6+bound(typ[7:-1],value,path))
 if typ.startswith('Box<'):return bound(typ[4:-1],value,path)
 if typ.startswith('Vec<'):
  subtype=typ[4:-1]
  if value is ANY:
   key=path.rsplit('.',1)[-1]
   sizes={'residuals':21,'jacobian':21,'occupancies':2,'reservoirs':2,'potentials_mm':4,'root_layer_ids':6,'root_fluxes_kg_m2_tile_s':6,'continuity_residuals_kg_m2_tile_s':4,'all_root_layer_ids':6,'all_root_fluxes_kg_m2_tile_s':6}
   count=21 if path.endswith('jacobian[]') else sizes[key]
   dynamic.append({'path':path,'type':typ,'max_length':count})
   return 2+max(0,count-1)*2+count*bound(subtype,ANY,path+'[]')
  return 2+max(0,len(value)-1)*2+sum(bound(subtype,v,path+'[]') for v in value)
 if typ.startswith('['):
  subtype,n=typ[1:-1].rsplit(';',1);n=int(n)
  vals=[ANY]*n if value is ANY else value
  assert len(vals)==n
  return 2+max(0,n-1)*2+sum(bound(subtype,v,path+'[]') for v in vals)
 if typ in enums:
  used[typ]={'kind':'unit enum','source':locations[typ],'variants':enums[typ]}
  return max(map(len,enums[typ]))
 if typ not in structs:raise ValueError((typ,path))
 fs=structs[typ];used[typ]={'kind':'derived Debug struct','source':locations[typ],'fields':fs}
 if value is not ANY:
  assert set(value)<=set(k for k,t in fs),(typ,set(value)-set(k for k,t in fs))
  missing=[(k,t) for k,t in fs if k not in value];assert all(t.startswith('Option<') for k,t in missing),(typ,missing)
 total=len(typ)+4+max(0,len(fs)-1)*2
 for key,t in fs:
  v=ANY if value is ANY else value.get(key)
  total+=len(key)+2+bound(t,v,path+'.'+key)
 return total
original=ART/'original-input-reference.json'; data=json.loads(original.read_text())['inputs']
assert hashlib.sha256(original.read_bytes()).hexdigest()=='4b324b0a9c136f2203e8073ca260db5be9e7dd07722a37aec60f2cd528be2d54'
input_value={'column':data,'reservoirs':[{'occupancy_id':s,'mass_kg_m2':0.,'enthalpy_j_m2':0.} for s in ['stratum-z-upper::forest','stratum-a-lower::forest']],'support':{'model_definition_id':'OPENWEPP_C3_WOODY_COLD_M1_V1','occupancy_conditions':[{'occupancy_id':s,'liquid_conducting':True,'full_supply':True} for s in ['stratum-z-upper::forest','stratum-a-lower::forest']]},'topology':{'occupancy_ids':['stratum-z-upper::forest','stratum-a-lower::forest'],'soil_layer_ids':['thermal-1','thermal-2','soil-1','soil-2','soil-dry','soil-frozen']},'top_liquid_specific_enthalpy_j_kg':0.}
input_bound=bound('M1CoupledColumnInput',input_value,'accepted_input')
fields=structs['M1CoupledEvaluation'];used['M1CoupledEvaluation']={'kind':'derived Debug struct','source':locations['M1CoupledEvaluation'],'fields':fields}
components={k:input_bound if k=='accepted_input' else bound(t,ANY,k) for k,t in fields}
accepted=10+len('M1CoupledEvaluation')+4+max(0,len(fields)-1)*2+sum(len(k)+2+v for k,v in components.items())
refused=9+bound('M1TrustRegionRefusalKind')
for value in used.values():
 p=SRC/value['source'];pins[value['source']]=hashlib.sha256(p.read_bytes()).hexdigest()
result={'status':'DRAFT_REQUIRES_REVIEW','evidence_class':'Ran: static type parsing and fixture shape only, no physical evaluation','raw_debug_bound_bytes':max(accepted,refused),'accepted_bound_bytes':accepted,'refused_bound_bytes':refused,'json_string_bound_bytes':2+6*max(accepted,refused),'component_bounds':components,'used_type_shapes':used,'dynamic_vector_bounds':dynamic,'source_pins':pins,'primitive_bounds':{'f64':330,'u64_or_usize':20,'bool':5,'String':'2+10*max_UTF8_bytes for Rust Debug; source strings<=64 bytes; JSON escaping separately6x'},'remaining_static_obligations':['Verify all parsed reachable structs use derived Debug and String newtype Debug as described','Verify dynamic vector bounds against materializer/hydraulic allocation and loops','Verify support0 scalar-only changes preserve input data shapes; native_snow_exchange is added by loader if reached and must be included']}
(ROOT/'outcome-type-bound-draft.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':accepted,'refused':refused,'components':components,'types':len(used)}))
