import pathlib,subprocess,json,hashlib,time,sys,datetime,importlib.util,signal,os
R=pathlib.Path('/home/roger/openwepp-experiments/cold-canopy-m1-cut11-continuation-20261003');A=pathlib.Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts'); P='/workdir/openWEPP/.venv/bin/python'
spec=importlib.util.spec_from_file_location('custody',A/'separate-accuracy-source-custody.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
mode=sys.argv[1]
if mode=='proofs':
 d=json.loads((R/'terminal-inventory.json').read_text());d['final_source_sha256']=hashlib.sha256((R/'source/crates/openwepp-land-surface-energy/src/m1_trust_region_stage1.rs').read_bytes()).hexdigest();(R/'terminal-inventory.json').write_text(json.dumps(d,indent=2)+'\n')
 records=[]
 for name,args in [('outcome_type_bound.py',[]),('collection_bounds.py',[]),('build_schema.py',[]),('schema_bound.py',[str(R/'schema-draft.json')]),('schema_coverage.py',[]),('field_table.py',[]),('proof_inputs.py',[]),('status_keys.py',[])]:
  p=subprocess.run([P,str(R/name),*args],cwd=R,capture_output=True,timeout=60);records.append({'command':[P,str(R/name),*args],'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
  if name=='schema_bound.py' and p.returncode==0:(R/'schema-bound-draft.json').write_bytes(p.stdout)
  if p.returncode:break
 (R/'successor-final-proof-generation.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records))
elif mode=='metadata':
 name=sys.argv[2];kind=sys.argv[3];no_run=sys.argv[4];b=R/('target-candidate/release/deps/openwepp_land_surface_energy-70194d0f8e103327' if kind=='release' else 'target-metadata-debug/debug/deps/openwepp_land_surface_energy-9100171ea317aacf');before=C.identity(C.entries(R/'source'));assert before==json.loads((R/'checks'/f'{no_run}.json').read_text())['source_after'];cmd=[str(b),'--exact','m1_trust_region_stage1::m1_refinement_atomic_terminal_inventory_schema_control','--nocapture','--test-threads=1'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (R/'checks'/f'{name}.stdout').open('wb') as o,(R/'checks'/f'{name}.stderr').open('wb') as e:
  p=subprocess.Popen(cmd,cwd=R/'source',stdout=o,stderr=e,start_new_session=True)
  try:code=p.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5);code='TIMEOUT_GROUP_KILLED'
 z={'command':cmd,'source_before':before,'source_after':C.identity(C.entries(R/'source')),'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'start_utc':start,'exit':code,'elapsed_seconds':time.monotonic()-t,'physical_invocations':0}
 for k in ['stdout','stderr']:z[k+'_sha256']=hashlib.sha256((R/'checks'/f'{name}.{k}').read_bytes()).hexdigest()
 (R/'checks'/f'{name}.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps(z));print((R/'checks'/f'{name}.stdout').read_text());print((R/'checks'/f'{name}.stderr').read_text())
elif mode=='patch':
 f='crates/openwepp-land-surface-energy/src/m1_trust_region_stage1.rs';p=subprocess.run(['diff','-u','/home/roger/openwepp-experiments/cold-canopy-m1-refusal-branch-completeness-20261002/source/'+f,str(R/'source'/f)],capture_output=True);(R/'checks'/f'{sys.argv[2]}-stage1.patch').write_bytes(p.stdout);print(C.identity(C.entries(R/'source')));print(hashlib.sha256((R/'source'/f).read_bytes()).hexdigest())
