use std::collections::HashMap;
use std::fmt;
use std::fs::File;
use std::io;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use arrow_array::{ArrayRef, Float64Array, Int8Array, Int16Array, Int32Array, RecordBatch};
use arrow_schema::{DataType, Field, Schema};
use base64::{Engine as _, engine::general_purpose::STANDARD as BASE64_STANDARD};
use flatbuffers::{FlatBufferBuilder, ForwardsUOffset, UnionWIPOffset, Vector, WIPOffset};
use openwepp_sim_contract::units::{OutputUnitRegistryError, validate_output_schema_unit};
use parquet::arrow::{ARROW_SCHEMA_META_KEY, ArrowWriter, arrow_writer::ArrowWriterOptions};
use parquet::basic::Compression;
use parquet::file::metadata::KeyValue as ParquetKeyValue;
use parquet::file::properties::WriterProperties;

/// Default interchange dataset version aligned to WEPPpy/WEPPpyo3.
pub const DEFAULT_DATASET_VERSION_MAJOR: u32 = 1;
pub const DEFAULT_DATASET_VERSION_MINOR: u32 = 4;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct InterchangeVersion {
    pub major: u32,
    pub minor: u32,
}

impl InterchangeVersion {
    #[must_use]
    pub const fn new(major: u32, minor: u32) -> Self {
        Self { major, minor }
    }

    #[must_use]
    pub fn dataset_version(self) -> String {
        format!("{}.{}", self.major, self.minor)
    }
}

impl Default for InterchangeVersion {
    fn default() -> Self {
        Self::new(DEFAULT_DATASET_VERSION_MAJOR, DEFAULT_DATASET_VERSION_MINOR)
    }
}

pub(crate) fn stable_arrow_schema_file_metadata(
    schema: &Schema,
) -> Result<Vec<ParquetKeyValue>, HillslopeWatParquetError> {
    Ok(vec![ParquetKeyValue::new(
        ARROW_SCHEMA_META_KEY.to_string(),
        stable_encoded_arrow_schema(schema)?,
    )])
}

struct StableIpcFieldType<'a> {
    type_type: arrow_ipc::Type,
    type_: WIPOffset<UnionWIPOffset>,
    children: WIPOffset<Vector<'a, ForwardsUOffset<arrow_ipc::Field<'a>>>>,
}

fn stable_metadata_to_fb<'a>(
    fbb: &mut FlatBufferBuilder<'a>,
    metadata: &HashMap<String, String>,
) -> WIPOffset<Vector<'a, ForwardsUOffset<arrow_ipc::KeyValue<'a>>>> {
    let mut metadata_pairs = metadata.iter().collect::<Vec<_>>();
    metadata_pairs.sort_unstable_by_key(|(key, _)| *key);
    let custom_metadata = metadata_pairs
        .into_iter()
        .map(|(key, value)| {
            let fb_key = fbb.create_string(key);
            let fb_value = fbb.create_string(value);

            let mut builder = arrow_ipc::KeyValueBuilder::new(fbb);
            builder.add_key(fb_key);
            builder.add_value(fb_value);
            builder.finish()
        })
        .collect::<Vec<_>>();
    fbb.create_vector(&custom_metadata)
}

fn stable_ipc_field_type<'a>(
    fbb: &mut FlatBufferBuilder<'a>,
    data_type: &DataType,
) -> Result<StableIpcFieldType<'a>, HillslopeWatParquetError> {
    let empty_fields: Vec<WIPOffset<arrow_ipc::Field<'_>>> = Vec::new();
    let children = fbb.create_vector(&empty_fields);
    match data_type {
        DataType::Int8 | DataType::Int16 | DataType::Int32 => {
            let mut builder = arrow_ipc::IntBuilder::new(fbb);
            builder.add_is_signed(true);
            match data_type {
                DataType::Int8 => builder.add_bitWidth(8),
                DataType::Int16 => builder.add_bitWidth(16),
                DataType::Int32 => builder.add_bitWidth(32),
                _ => {}
            }
            Ok(StableIpcFieldType {
                type_type: arrow_ipc::Type::Int,
                type_: builder.finish().as_union_value(),
                children,
            })
        }
        DataType::Float64 => {
            let mut builder = arrow_ipc::FloatingPointBuilder::new(fbb);
            builder.add_precision(arrow_ipc::Precision::DOUBLE);
            Ok(StableIpcFieldType {
                type_type: arrow_ipc::Type::FloatingPoint,
                type_: builder.finish().as_union_value(),
                children,
            })
        }
        DataType::Utf8 => Ok(StableIpcFieldType {
            type_type: arrow_ipc::Type::Utf8,
            type_: arrow_ipc::Utf8Builder::new(fbb).finish().as_union_value(),
            children,
        }),
        other => Err(HillslopeWatParquetError::parquet(format!(
            "stable arrow schema encoding does not support {other:?}"
        ))),
    }
}

fn stable_build_ipc_field<'a>(
    fbb: &mut FlatBufferBuilder<'a>,
    field: &Field,
) -> Result<WIPOffset<arrow_ipc::Field<'a>>, HillslopeWatParquetError> {
    let fb_metadata =
        (!field.metadata().is_empty()).then(|| stable_metadata_to_fb(fbb, field.metadata()));
    let fb_field_name = fbb.create_string(field.name().as_str());
    let field_type = stable_ipc_field_type(fbb, field.data_type())?;

    let mut builder = arrow_ipc::FieldBuilder::new(fbb);
    builder.add_name(fb_field_name);
    builder.add_type_type(field_type.type_type);
    builder.add_nullable(field.is_nullable());
    builder.add_children(field_type.children);
    builder.add_type_(field_type.type_);

    if let Some(fb_metadata) = fb_metadata {
        builder.add_custom_metadata(fb_metadata);
    }

    Ok(builder.finish())
}

fn stable_encoded_arrow_schema(schema: &Schema) -> Result<String, HillslopeWatParquetError> {
    let mut fbb = FlatBufferBuilder::new();
    let schema_header = {
        let fields = schema
            .fields()
            .iter()
            .map(|field| stable_build_ipc_field(&mut fbb, field.as_ref()))
            .collect::<Result<Vec<_>, _>>()?;
        let fb_field_list = fbb.create_vector(&fields);
        let fb_metadata_list = (!schema.metadata().is_empty())
            .then(|| stable_metadata_to_fb(&mut fbb, schema.metadata()));

        let mut builder = arrow_ipc::SchemaBuilder::new(&mut fbb);
        builder.add_fields(fb_field_list);
        if let Some(fb_metadata_list) = fb_metadata_list {
            builder.add_custom_metadata(fb_metadata_list);
        }
        builder.finish().as_union_value()
    };

    let mut message = arrow_ipc::MessageBuilder::new(&mut fbb);
    message.add_version(arrow_ipc::MetadataVersion::V5);
    message.add_header_type(arrow_ipc::MessageHeader::Schema);
    message.add_bodyLength(0);
    message.add_header(schema_header);
    let root = message.finish();
    fbb.finish(root, None);

    let schema_bytes = fbb.finished_data();
    let schema_len = u32::try_from(schema_bytes.len())
        .map_err(|_| HillslopeWatParquetError::parquet("stable arrow schema exceeds u32 length"))?;
    let mut length_prefixed_schema = Vec::with_capacity(schema_bytes.len() + 8);
    length_prefixed_schema.extend_from_slice(&[255_u8, 255, 255, 255]);
    length_prefixed_schema.extend_from_slice(&schema_len.to_le_bytes());
    length_prefixed_schema.extend_from_slice(schema_bytes);

    Ok(BASE64_STANDARD.encode(length_prefixed_schema))
}

#[derive(Debug, Clone, PartialEq)]
pub struct HillslopeWatRow {
    pub wepp_id: i32,
    pub ofe_id: i16,
    pub year: i16,
    pub sim_day_index: i32,
    pub julian: i16,
    pub month: i8,
    pub day_of_month: i8,
    pub water_year: i16,
    pub ofe: i16,
    pub p: f64,
    pub rm: f64,
    pub q: f64,
    pub ep: f64,
    pub es: f64,
    pub er: f64,
    pub dp: f64,
    pub up_strm_q: f64,
    pub sub_r_in: f64,
    pub latqcc: f64,
    pub base: Option<f64>,
    pub total_soil_water: f64,
    pub frozwt: f64,
    pub frdp: f64,
    pub snow_water: f64,
    pub snow_depth: Option<f64>,
    pub meltwater_temperature: Option<f64>,
    pub qofe: f64,
    pub tile: f64,
    pub irr: f64,
    pub area: f64,
    pub soil_water_total: Option<f64>,
    pub profile_depth: Option<f64>,
    pub profile_porosity_cap: Option<f64>,
    pub profile_fc_store: Option<f64>,
    pub profile_wp_store: Option<f64>,
    pub interception: Option<f64>,
    pub interception_storage: Option<f64>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WriteSummary {
    pub rows_written: usize,
}

#[derive(Debug)]
pub enum HillslopeWatParquetError {
    Io { path: PathBuf, source: io::Error },
    Parquet { detail: String },
    UnitMetadata { detail: String },
}

impl HillslopeWatParquetError {
    #[must_use]
    pub const fn code(&self) -> &'static str {
        match self {
            Self::Io { .. } => "OHOUT-WAT-E-001",
            Self::Parquet { .. } => "OHOUT-WAT-E-002",
            Self::UnitMetadata { .. } => "OHOUT-WAT-E-003",
        }
    }

    fn parquet(detail: impl Into<String>) -> Self {
        Self::Parquet {
            detail: detail.into(),
        }
    }
}

impl fmt::Display for HillslopeWatParquetError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Io { path, source } => {
                write!(
                    f,
                    "{} io error at {}: {source}",
                    self.code(),
                    path.display()
                )
            }
            Self::Parquet { detail } => write!(f, "{} parquet error: {detail}", self.code()),
            Self::UnitMetadata { detail } => {
                write!(f, "{} unit metadata error: {detail}", self.code())
            }
        }
    }
}

impl std::error::Error for HillslopeWatParquetError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Io { source, .. } => Some(source),
            Self::Parquet { .. } | Self::UnitMetadata { .. } => None,
        }
    }
}

#[allow(clippy::too_many_lines)]
pub fn hillslope_wat_schema(
    version: InterchangeVersion,
) -> Result<Schema, HillslopeWatParquetError> {
    let mut metadata = HashMap::new();
    metadata.insert("dataset_version".to_string(), version.dataset_version());
    metadata.insert(
        "dataset_version_major".to_string(),
        version.major.to_string(),
    );
    metadata.insert(
        "dataset_version_minor".to_string(),
        version.minor.to_string(),
    );
    metadata.insert("schema_version".to_string(), version.major.to_string());

    let schema = Schema::new_with_metadata(
        vec![
            Field::new("wepp_id", DataType::Int32, false),
            Field::new("ofe_id", DataType::Int16, false),
            Field::new("year", DataType::Int16, false),
            field_with_meta(
                "sim_day_index",
                DataType::Int32,
                false,
                None,
                Some("1-indexed simulation day"),
            ),
            Field::new("julian", DataType::Int16, false),
            Field::new("month", DataType::Int8, false),
            Field::new("day_of_month", DataType::Int8, false),
            Field::new("water_year", DataType::Int16, false),
            Field::new("OFE", DataType::Int16, false),
            field_with_meta(
                "P",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Precipitation"),
            ),
            field_with_meta(
                "RM",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Rainfall+Irrigation+Snowmelt"),
            ),
            field_with_meta(
                "Q",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Daily runoff over eff length"),
            ),
            field_with_meta(
                "Ep",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Plant transpiration"),
            ),
            field_with_meta(
                "Es",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Soil evaporation"),
            ),
            field_with_meta(
                "Er",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Residue evaporation"),
            ),
            field_with_meta(
                "Dp",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Deep percolation"),
            ),
            field_with_meta(
                "UpStrmQ",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Runon added to OFE"),
            ),
            field_with_meta(
                "SubRIn",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Subsurface runon added to OFE"),
            ),
            field_with_meta(
                "latqcc",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Lateral subsurface flow"),
            ),
            field_with_meta(
                "Base",
                DataType::Float64,
                true,
                Some("mm"),
                Some("Generated groundwater-reservoir baseflow"),
            ),
            field_with_meta(
                "Total-Soil",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Unfrozen water in soil profile"),
            ),
            field_with_meta(
                "frozwt",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Frozen water in soil profile"),
            ),
            field_with_meta(
                "frdp",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Active frost-front depth"),
            ),
            field_with_meta(
                "Snow-Water",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Water in surface snow"),
            ),
            field_with_meta(
                "Snow-Depth",
                DataType::Float64,
                true,
                Some("mm"),
                Some("Runtime snow depth diagnostic from snow.runtime_depth_m"),
            ),
            field_with_meta(
                "MeltwaterTemperature",
                DataType::Float64,
                true,
                Some("degC"),
                Some(
                    "Supported Stage 3-Decouple meltwater flux temperature source; null unless layered_thermal_liquid_v1 produces routed meltwater temperature",
                ),
            ),
            field_with_meta(
                "QOFE",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Daily runoff scaled to single OFE"),
            ),
            field_with_meta(
                "Tile",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Tile drainage"),
            ),
            field_with_meta(
                "Irr",
                DataType::Float64,
                false,
                Some("mm"),
                Some("Irrigation"),
            ),
            field_with_meta(
                "Area",
                DataType::Float64,
                false,
                Some("m^2"),
                Some("Area that depths apply over"),
            ),
            field_with_meta(
                "SoilWaterTotal",
                DataType::Float64,
                true,
                Some("mm"),
                Some("Hydout-equivalent aggregate soil water depth from watcon lineage"),
            ),
            field_with_meta(
                "ProfileDepth",
                DataType::Float64,
                true,
                Some("mm"),
                Some("Full soil profile depth (solthk(nsl)), optional producer-authoritative term"),
            ),
            field_with_meta(
                "ProfilePorosityCap",
                DataType::Float64,
                true,
                Some("mm"),
                Some(
                    "Full-profile porosity storage capacity (sum(por * dg)), optional producer-authoritative term",
                ),
            ),
            field_with_meta(
                "ProfileFCStore",
                DataType::Float64,
                true,
                Some("mm"),
                Some(
                    "Full-profile field-capacity storage (sum(thetfc * dg)), optional producer-authoritative term",
                ),
            ),
            field_with_meta(
                "ProfileWPStore",
                DataType::Float64,
                true,
                Some("mm"),
                Some(
                    "Full-profile wilting-point storage (sum(thetdr * dg)), optional producer-authoritative term",
                ),
            ),
            field_with_meta(
                "Interception",
                DataType::Float64,
                true,
                Some("mm"),
                Some(
                    "Daily canopy/residue interception flux I, optional producer-authoritative term",
                ),
            ),
            field_with_meta(
                "InterceptionStorage",
                DataType::Float64,
                true,
                Some("mm"),
                Some(
                    "Plant/residue interception carryover storage (pintlv + resint), optional producer-authoritative term",
                ),
            ),
        ],
        metadata,
    );
    align_output_schema_units("hillslope_wat", &schema)
}

pub fn write_hillslope_wat_parquet(
    path: &Path,
    rows: &[HillslopeWatRow],
    version: InterchangeVersion,
) -> Result<WriteSummary, HillslopeWatParquetError> {
    let mut writer = HillslopeWatParquetRowGroupWriter::create(path, version)?;
    writer.write_rows(rows)?;
    writer.close()
}

pub struct HillslopeWatParquetRowGroupWriter {
    writer: ArrowWriter<File>,
    schema: Arc<Schema>,
    rows_written: usize,
}

impl HillslopeWatParquetRowGroupWriter {
    pub fn create(
        path: &Path,
        version: InterchangeVersion,
    ) -> Result<Self, HillslopeWatParquetError> {
        let schema = Arc::new(hillslope_wat_schema(version)?);
        let file = File::create(path).map_err(|source| HillslopeWatParquetError::Io {
            path: path.to_path_buf(),
            source,
        })?;

        let writer_properties = WriterProperties::builder()
            .set_compression(Compression::SNAPPY)
            .set_key_value_metadata(Some(stable_arrow_schema_file_metadata(&schema)?))
            .build();

        let writer_options = ArrowWriterOptions::new()
            .with_properties(writer_properties)
            .with_skip_arrow_metadata(true);
        let writer = ArrowWriter::try_new_with_options(file, Arc::clone(&schema), writer_options)
            .map_err(|error| HillslopeWatParquetError::parquet(error.to_string()))?;
        Ok(Self {
            writer,
            schema,
            rows_written: 0,
        })
    }

    pub fn write_rows(&mut self, rows: &[HillslopeWatRow]) -> Result<(), HillslopeWatParquetError> {
        if rows.is_empty() {
            return Ok(());
        }
        let batch = hillslope_wat_rows_to_batch(self.schema.as_ref(), rows)?;
        self.writer
            .write(&batch)
            .map_err(|error| HillslopeWatParquetError::parquet(error.to_string()))?;
        self.rows_written = self.rows_written.checked_add(rows.len()).ok_or_else(|| {
            HillslopeWatParquetError::parquet(
                "hillslope WAT row count overflow while writing parquet",
            )
        })?;
        Ok(())
    }

    pub fn close(self) -> Result<WriteSummary, HillslopeWatParquetError> {
        self.writer
            .close()
            .map_err(|error| HillslopeWatParquetError::parquet(error.to_string()))?;
        Ok(WriteSummary {
            rows_written: self.rows_written,
        })
    }
}

fn output_registry_error(error: &OutputUnitRegistryError) -> HillslopeWatParquetError {
    HillslopeWatParquetError::UnitMetadata {
        detail: error.to_string(),
    }
}

fn align_output_schema_units(
    schema_id: &'static str,
    schema: &Schema,
) -> Result<Schema, HillslopeWatParquetError> {
    let mut fields = Vec::with_capacity(schema.fields().len());

    for field_ref in schema.fields() {
        let field = field_ref.as_ref();
        let Some(local_unit) = field.metadata().get("units") else {
            fields.push(field.clone());
            continue;
        };
        let registry_unit = validate_output_schema_unit(schema_id, field.name(), local_unit)
            .map_err(|error| output_registry_error(&error))?;
        let mut metadata = field.metadata().clone();
        metadata.insert("units".to_string(), registry_unit.to_string());
        fields.push(field.clone().with_metadata(metadata));
    }

    Ok(Schema::new_with_metadata(fields, schema.metadata().clone()))
}

fn field_with_meta(
    name: &str,
    data_type: DataType,
    nullable: bool,
    units: Option<&str>,
    description: Option<&str>,
) -> Field {
    let mut field = Field::new(name, data_type, nullable);

    let mut metadata = HashMap::new();
    if let Some(units) = units {
        metadata.insert("units".to_string(), units.to_string());
    }
    if let Some(description) = description {
        metadata.insert("description".to_string(), description.to_string());
    }

    if !metadata.is_empty() {
        field = field.with_metadata(metadata);
    }

    field
}

#[allow(clippy::too_many_lines)]
fn hillslope_wat_rows_to_batch(
    schema: &Schema,
    rows: &[HillslopeWatRow],
) -> Result<RecordBatch, HillslopeWatParquetError> {
    let mut wepp_id = Vec::with_capacity(rows.len());
    let mut ofe_id = Vec::with_capacity(rows.len());
    let mut year = Vec::with_capacity(rows.len());
    let mut sim_day_index = Vec::with_capacity(rows.len());
    let mut julian = Vec::with_capacity(rows.len());
    let mut month = Vec::with_capacity(rows.len());
    let mut day_of_month = Vec::with_capacity(rows.len());
    let mut water_year = Vec::with_capacity(rows.len());
    let mut ofe = Vec::with_capacity(rows.len());
    let mut p = Vec::with_capacity(rows.len());
    let mut rm = Vec::with_capacity(rows.len());
    let mut q = Vec::with_capacity(rows.len());
    let mut ep = Vec::with_capacity(rows.len());
    let mut es = Vec::with_capacity(rows.len());
    let mut er = Vec::with_capacity(rows.len());
    let mut dp = Vec::with_capacity(rows.len());
    let mut up_strm_q = Vec::with_capacity(rows.len());
    let mut sub_r_in = Vec::with_capacity(rows.len());
    let mut latqcc = Vec::with_capacity(rows.len());
    let mut base = Vec::with_capacity(rows.len());
    let mut total_soil_water = Vec::with_capacity(rows.len());
    let mut frozwt = Vec::with_capacity(rows.len());
    let mut frdp = Vec::with_capacity(rows.len());
    let mut snow_water = Vec::with_capacity(rows.len());
    let mut snow_depth = Vec::with_capacity(rows.len());
    let mut meltwater_temperature = Vec::with_capacity(rows.len());
    let mut qofe = Vec::with_capacity(rows.len());
    let mut tile = Vec::with_capacity(rows.len());
    let mut irr = Vec::with_capacity(rows.len());
    let mut area = Vec::with_capacity(rows.len());
    let mut soil_water_total = Vec::with_capacity(rows.len());
    let mut profile_depth = Vec::with_capacity(rows.len());
    let mut profile_porosity_cap = Vec::with_capacity(rows.len());
    let mut profile_fc_store = Vec::with_capacity(rows.len());
    let mut profile_wp_store = Vec::with_capacity(rows.len());
    let mut interception = Vec::with_capacity(rows.len());
    let mut interception_storage = Vec::with_capacity(rows.len());

    for row in rows {
        wepp_id.push(row.wepp_id);
        ofe_id.push(row.ofe_id);
        year.push(row.year);
        sim_day_index.push(row.sim_day_index);
        julian.push(row.julian);
        month.push(row.month);
        day_of_month.push(row.day_of_month);
        water_year.push(row.water_year);
        ofe.push(row.ofe);
        p.push(row.p);
        rm.push(row.rm);
        q.push(row.q);
        ep.push(row.ep);
        es.push(row.es);
        er.push(row.er);
        dp.push(row.dp);
        up_strm_q.push(row.up_strm_q);
        sub_r_in.push(row.sub_r_in);
        latqcc.push(row.latqcc);
        base.push(row.base);
        total_soil_water.push(row.total_soil_water);
        frozwt.push(row.frozwt);
        frdp.push(row.frdp);
        snow_water.push(row.snow_water);
        snow_depth.push(row.snow_depth);
        meltwater_temperature.push(row.meltwater_temperature);
        qofe.push(row.qofe);
        tile.push(row.tile);
        irr.push(row.irr);
        area.push(row.area);
        soil_water_total.push(row.soil_water_total);
        profile_depth.push(row.profile_depth);
        profile_porosity_cap.push(row.profile_porosity_cap);
        profile_fc_store.push(row.profile_fc_store);
        profile_wp_store.push(row.profile_wp_store);
        interception.push(row.interception);
        interception_storage.push(row.interception_storage);
    }

    let columns: Vec<ArrayRef> = vec![
        Arc::new(Int32Array::from(wepp_id)),
        Arc::new(Int16Array::from(ofe_id)),
        Arc::new(Int16Array::from(year)),
        Arc::new(Int32Array::from(sim_day_index)),
        Arc::new(Int16Array::from(julian)),
        Arc::new(Int8Array::from(month)),
        Arc::new(Int8Array::from(day_of_month)),
        Arc::new(Int16Array::from(water_year)),
        Arc::new(Int16Array::from(ofe)),
        Arc::new(Float64Array::from(p)),
        Arc::new(Float64Array::from(rm)),
        Arc::new(Float64Array::from(q)),
        Arc::new(Float64Array::from(ep)),
        Arc::new(Float64Array::from(es)),
        Arc::new(Float64Array::from(er)),
        Arc::new(Float64Array::from(dp)),
        Arc::new(Float64Array::from(up_strm_q)),
        Arc::new(Float64Array::from(sub_r_in)),
        Arc::new(Float64Array::from(latqcc)),
        Arc::new(Float64Array::from(base)),
        Arc::new(Float64Array::from(total_soil_water)),
        Arc::new(Float64Array::from(frozwt)),
        Arc::new(Float64Array::from(frdp)),
        Arc::new(Float64Array::from(snow_water)),
        Arc::new(Float64Array::from(snow_depth)),
        Arc::new(Float64Array::from(meltwater_temperature)),
        Arc::new(Float64Array::from(qofe)),
        Arc::new(Float64Array::from(tile)),
        Arc::new(Float64Array::from(irr)),
        Arc::new(Float64Array::from(area)),
        Arc::new(Float64Array::from(soil_water_total)),
        Arc::new(Float64Array::from(profile_depth)),
        Arc::new(Float64Array::from(profile_porosity_cap)),
        Arc::new(Float64Array::from(profile_fc_store)),
        Arc::new(Float64Array::from(profile_wp_store)),
        Arc::new(Float64Array::from(interception)),
        Arc::new(Float64Array::from(interception_storage)),
    ];

    RecordBatch::try_new(Arc::new(schema.clone()), columns)
        .map_err(|error| HillslopeWatParquetError::parquet(error.to_string()))
}

#[cfg(test)]
mod tests {
    use std::fs;

    use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;

    use super::*;

    fn sample_row() -> HillslopeWatRow {
        HillslopeWatRow {
            wepp_id: 1,
            ofe_id: 1,
            year: 1987,
            sim_day_index: 1,
            julian: 1,
            month: 1,
            day_of_month: 1,
            water_year: 1987,
            ofe: 1,
            p: 10.0,
            rm: 0.0,
            q: 0.0,
            ep: 1.0,
            es: 1.0,
            er: 0.1,
            dp: 0.1,
            up_strm_q: 0.0,
            sub_r_in: 0.0,
            latqcc: 0.0,
            base: Some(0.0),
            total_soil_water: 100.0,
            frozwt: 0.0,
            frdp: 0.0,
            snow_water: 0.0,
            snow_depth: Some(250.0),
            meltwater_temperature: Some(0.0),
            qofe: 0.0,
            tile: 0.0,
            irr: 0.0,
            area: 1.0,
            soil_water_total: Some(100.0),
            profile_depth: Some(1_200.0),
            profile_porosity_cap: Some(400.0),
            profile_fc_store: Some(300.0),
            profile_wp_store: Some(150.0),
            interception: Some(0.25),
            interception_storage: None,
        }
    }

    #[test]
    fn schema_includes_required_dataset_metadata_keys() {
        let schema = hillslope_wat_schema(InterchangeVersion::default())
            .expect("hillslope WAT schema should construct");
        let metadata = schema.metadata();

        for key in [
            "dataset_version",
            "dataset_version_major",
            "dataset_version_minor",
            "schema_version",
        ] {
            assert!(metadata.contains_key(key), "missing key: {key}");
        }
        assert_eq!(
            metadata.get("dataset_version").map(String::as_str),
            Some("1.4")
        );
    }

    #[test]
    fn schema_includes_units_and_description_field_metadata() {
        let schema = hillslope_wat_schema(InterchangeVersion::default())
            .expect("hillslope WAT schema should construct");
        let p_field = schema
            .fields
            .iter()
            .find(|field| field.name() == "P")
            .expect("P field should exist");
        let p_meta = p_field.metadata();

        assert_eq!(p_meta.get("units").map(String::as_str), Some("mm"));
        assert_eq!(
            p_meta.get("description").map(String::as_str),
            Some("Precipitation")
        );

        let snow_water_field = schema
            .fields
            .iter()
            .find(|field| field.name() == "Snow-Water")
            .expect("Snow-Water field should exist");
        assert!(
            !snow_water_field.is_nullable(),
            "Snow-Water remains required SWE, not the optional depth diagnostic"
        );

        let snow_depth_field = schema
            .fields
            .iter()
            .find(|field| field.name() == "Snow-Depth")
            .expect("Snow-Depth field should exist");
        let snow_depth_meta = snow_depth_field.metadata();
        assert!(snow_depth_field.is_nullable());
        assert_eq!(snow_depth_meta.get("units").map(String::as_str), Some("mm"));
        assert!(
            snow_depth_meta
                .get("description")
                .is_some_and(|value| value.contains("snow.runtime_depth_m")),
            "Snow-Depth description should identify the runtime depth source"
        );

        let meltwater_temperature_field = schema
            .fields
            .iter()
            .find(|field| field.name() == "MeltwaterTemperature")
            .expect("MeltwaterTemperature field should exist");
        let meltwater_temperature_meta = meltwater_temperature_field.metadata();
        assert!(meltwater_temperature_field.is_nullable());
        assert_eq!(
            meltwater_temperature_meta.get("units").map(String::as_str),
            Some("degC")
        );
        assert!(
            meltwater_temperature_meta
                .get("description")
                .is_some_and(|value| value.contains("meltwater flux temperature source")),
            "MeltwaterTemperature description should identify the supported temperature source"
        );

        let interception_field = schema
            .fields
            .iter()
            .find(|field| field.name() == "InterceptionStorage")
            .expect("InterceptionStorage field should exist");
        let interception_meta = interception_field.metadata();
        assert_eq!(
            interception_meta.get("units").map(String::as_str),
            Some("mm")
        );
        assert!(
            interception_meta
                .get("description")
                .is_some_and(|value| value.contains("optional producer-authoritative term")),
            "InterceptionStorage description should include optional producer-authoritative note"
        );

        let interception_flux_field = schema
            .fields
            .iter()
            .find(|field| field.name() == "Interception")
            .expect("Interception field should exist");
        let interception_flux_meta = interception_flux_field.metadata();
        assert_eq!(
            interception_flux_meta.get("units").map(String::as_str),
            Some("mm")
        );
        assert!(
            interception_flux_meta
                .get("description")
                .is_some_and(|value| value.contains("interception flux I")),
            "Interception description should identify the daily I flux"
        );
    }

    #[test]
    fn writer_emits_valid_parquet_file_with_schema_metadata() {
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("unix epoch should be before now")
            .as_nanos();
        let output_path =
            std::env::temp_dir().join(format!("openwepp_hillslope_wat_writer_{timestamp}.parquet"));

        let summary = write_hillslope_wat_parquet(
            &output_path,
            &[sample_row()],
            InterchangeVersion::default(),
        )
        .expect("writer should emit parquet");
        assert_eq!(summary.rows_written, 1);

        let file = File::open(&output_path).expect("parquet file should be readable");
        let builder = ParquetRecordBatchReaderBuilder::try_new(file)
            .expect("parquet should have readable footer/schema");
        let schema = builder.schema();

        assert!(schema.metadata().contains_key("dataset_version"));
        assert!(
            schema
                .fields()
                .iter()
                .any(|field| field.name() == "Interception")
        );
        assert!(
            schema
                .fields()
                .iter()
                .any(|field| field.name() == "InterceptionStorage")
        );
        let meltwater_temperature_field = schema
            .fields()
            .iter()
            .find(|field| field.name() == "MeltwaterTemperature")
            .expect("MeltwaterTemperature field should exist in parquet schema");
        assert_eq!(
            meltwater_temperature_field
                .metadata()
                .get("units")
                .map(String::as_str),
            Some("degC")
        );
        let snow_depth_field = schema
            .fields()
            .iter()
            .find(|field| field.name() == "Snow-Depth")
            .expect("Snow-Depth field should exist in parquet schema");
        assert_eq!(
            snow_depth_field.metadata().get("units").map(String::as_str),
            Some("mm")
        );
        let p_field = schema
            .fields()
            .iter()
            .find(|field| field.name() == "P")
            .expect("P field should exist in parquet schema");
        assert_eq!(
            p_field.metadata().get("units").map(String::as_str),
            Some("mm")
        );

        let _ = fs::remove_file(output_path);
    }

    #[test]
    fn writer_emits_byte_stable_parquet_for_identical_rows() {
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("unix epoch should be before now")
            .as_nanos();
        let output_path_a = std::env::temp_dir().join(format!(
            "openwepp_hillslope_wat_writer_stable_a_{timestamp}.parquet"
        ));
        let output_path_b = std::env::temp_dir().join(format!(
            "openwepp_hillslope_wat_writer_stable_b_{timestamp}.parquet"
        ));

        write_hillslope_wat_parquet(
            &output_path_a,
            &[sample_row()],
            InterchangeVersion::default(),
        )
        .expect("first writer should emit parquet");
        write_hillslope_wat_parquet(
            &output_path_b,
            &[sample_row()],
            InterchangeVersion::default(),
        )
        .expect("second writer should emit parquet");

        let first = fs::read(&output_path_a).expect("first parquet should be readable");
        let second = fs::read(&output_path_b).expect("second parquet should be readable");
        assert_eq!(first, second);

        let _ = fs::remove_file(output_path_a);
        let _ = fs::remove_file(output_path_b);
    }
}
