//! Policy14 donor-bound native custody publication, distinct from phase work.
use super::{
    Stage3AcceptedSnowLiquidOutputV1,
    native_snow_liquid_custody::prepare_native_snow_liquid_candidate_v1,
};
use crate::direct_runtime::DirectZeroDurationSnowLiquidInputV1;
use crate::{
    DirectSurfaceLiquidError as Error, DirectZeroDurationSnowLiquidReceiptV1,
    LseSurfaceEnthalpyOwnerEnvelopeV1, SurfaceLiquidConfigurationV2, SurfaceLiquidOwnerEnvelopeV2,
};
use openwepp_coupled_time::{Digest32, FramedField, digest_bytes, framed_sha256};
use openwepp_kernel_contract::TransactionId;
use openwepp_land_surface_energy::{
    LandSurfaceEnergyConfiguration, LandSurfaceEnergyState, LandSurfaceEnergyV3State, Sha256Digest,
};
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

pub(crate) const NATIVE_SNOW_CUSTODY_SCHEMA: &str =
    "OPENWEPP_B01_NATIVE_SNOW_LIQUID_CUSTODY_V2_POLICY14";

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum NativeSnowCustodyKindV1 {
    Drain,
    ParentFinalization,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeSnowCustodyIdentityV1 {
    pub policy_id: u8,
    pub kind: NativeSnowCustodyKindV1,
    pub parent_transaction_sha256: Digest32,
    pub transaction_id: TransactionId,
    pub predecessor_transaction_id: Option<TransactionId>,
    pub parent_start_ns: u128,
    pub parent_end_ns: u128,
    pub support_start_ns: u128,
    pub support_end_ns: u128,
    pub receiver_ordinal: u32,
    pub donor_ending_complete_owner_sha256: Digest32,
    pub receiver_context_sha256: Digest32,
    pub output_set_sha256: Digest32,
    pub predecessor_physical_receipt_chain_sha256: String,
}

/// A complete physical/exact transition record. Its positive support is donor
/// provenance, never a second interval of atmospheric/phase/WB14 work.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeSnowLiquidPublicationV1 {
    schema: String,
    pub runtime_authority: openwepp_coupled_time::Policy14RuntimeAuthority,
    pub identity: NativeSnowCustodyIdentityV1,
    lse_configuration_sha256: Sha256Digest,
    surface_configuration_sha256: String,
    pub active_covered_lse: LandSurfaceEnergyState,
    pub beginning_lse: LandSurfaceEnergyV3State,
    pub ending_lse: LandSurfaceEnergyV3State,
    pub beginning_surface_bytes: Vec<u8>,
    pub ending_surface_bytes: Vec<u8>,
    // Authenticated native V2 projections for consumers without V2 configuration.
    pub beginning_liquid_records: Vec<(crate::DirectSurfaceLiquidStoreKey, f64)>,
    pub ending_liquid_records: Vec<(crate::DirectSurfaceLiquidStoreKey, f64)>,
    pub beginning_exact: LseSurfaceEnthalpyOwnerEnvelopeV1,
    pub ending_exact: LseSurfaceEnthalpyOwnerEnvelopeV1,
    pub outputs: Vec<Stage3AcceptedSnowLiquidOutputV1>,
    pub allocation_receipts: Vec<DirectZeroDurationSnowLiquidReceiptV1>,
    pub receipt_sha256: Digest32,
    pub publication_sha256: Digest32,
}

fn wire_digest(value: Digest32) -> Result<Sha256Digest, Error> {
    Sha256Digest::try_new(
        value
            .as_bytes()
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>(),
    )
    .map_err(|_| Error::Schema("native snow custody digest"))
}
fn surface(
    config: &SurfaceLiquidConfigurationV2,
    bytes: &[u8],
) -> Result<SurfaceLiquidOwnerEnvelopeV2, Error> {
    let owner =
        SurfaceLiquidOwnerEnvelopeV2::from_canonical_bytes(config.parent(), Some(config), bytes)?;
    if owner.v2_state().is_none() {
        return Err(Error::Identity("native snow custody cannot downgrade"));
    }
    Ok(owner)
}

/// Preserve authenticated donor order in the set seal, and established
/// receipt-digest order in binary64 accumulation. Callers separately prove
/// completeness against the accepted donor publication.
pub(crate) fn positive_support_output_summary_v1(
    outputs: &[Stage3AcceptedSnowLiquidOutputV1],
    support_start_ns: u128,
    support_end_ns: u128,
) -> Result<(Digest32, f64, f64), Error> {
    let mut sorted = std::collections::BTreeMap::new();
    let mut lanes = BTreeSet::new();
    for output in outputs {
        output
            .validate()
            .map_err(|_| Error::Identity("positive support donor seal"))?;
        if output.support.start_ns().get() != support_start_ns
            || output.support.end_ns().get() != support_end_ns
            || output.mass_kg_m2_ofe_ground <= 0.0
            || !lanes.insert(output.lane_id)
            || sorted
                .insert(*output.receipt_sha256.as_bytes(), output)
                .is_some()
        {
            return Err(Error::Identity("positive support donor set domain"));
        }
    }
    if outputs.is_empty() {
        return Err(Error::Identity("positive support empty donor set"));
    }
    let mut mass = 0.0;
    let mut energy = 0.0;
    for output in sorted.values() {
        mass =
            crate::direct_runtime::checked_surface_liquid_add(mass, output.mass_kg_m2_ofe_ground)
                .ok_or(Error::Domain("positive support mass sum"))?;
        energy = crate::direct_runtime::checked_surface_liquid_add(
            energy,
            output.sensible_enthalpy_j_m2_ofe_ground,
        )
        .ok_or(Error::Domain("positive support energy sum"))?;
    }
    let fields = outputs
        .iter()
        .map(|output| FramedField {
            tag: "snow_liquid_output",
            value: output.receipt_sha256.as_bytes().as_slice(),
        })
        .collect::<Vec<_>>();
    let set = framed_sha256("stage3-v11-positive-support-liquid-output-set", &fields)
        .map_err(|_| Error::Schema("positive support output set"))?;
    Ok((set, mass, energy))
}

impl NativeSnowCustodyIdentityV1 {
    pub(crate) fn expected_receiver_context(
        &self,
        outputs: &[Stage3AcceptedSnowLiquidOutputV1],
    ) -> Result<Digest32, Error> {
        let (mass, energy) = if self.kind == NativeSnowCustodyKindV1::Drain {
            let (set, mass, energy) = positive_support_output_summary_v1(
                outputs,
                self.support_start_ns,
                self.support_end_ns,
            )?;
            if set != self.output_set_sha256 {
                return Err(Error::Identity("native donor output set"));
            }
            (mass, energy)
        } else {
            (0.0, 0.0)
        };
        framed_sha256(
            if self.kind == NativeSnowCustodyKindV1::Drain {
                "stage3-v11-positive-support-liquid-receiver"
            } else {
                "stage3-v11-native-drain-parent-finalization"
            },
            &[
                FramedField {
                    tag: "parent_transaction",
                    value: self.parent_transaction_sha256.as_bytes(),
                },
                FramedField {
                    tag: "support_start",
                    value: &self.support_start_ns.to_be_bytes(),
                },
                FramedField {
                    tag: "support_end",
                    value: &self.support_end_ns.to_be_bytes(),
                },
                FramedField {
                    tag: "support_ending_owner",
                    value: self.donor_ending_complete_owner_sha256.as_bytes(),
                },
                FramedField {
                    tag: "output_set",
                    value: self.output_set_sha256.as_bytes(),
                },
                FramedField {
                    tag: "mass_kg_m2",
                    value: &mass.to_bits().to_be_bytes(),
                },
                FramedField {
                    tag: "enthalpy_j_m2",
                    value: &energy.to_bits().to_be_bytes(),
                },
            ],
        )
        .map_err(|_| Error::Schema("native custody receiver context"))
    }
    fn ending_marker(
        &self,
        beginning: Option<TransactionId>,
    ) -> Result<Option<TransactionId>, Error> {
        if self.policy_id != 14
            || self.transaction_id.0 == 0
            || self.parent_transaction_sha256 == Digest32::zero()
            || self.donor_ending_complete_owner_sha256 == Digest32::zero()
            || self.receiver_context_sha256 == Digest32::zero()
            || self.parent_start_ns >= self.parent_end_ns
            || self.support_start_ns < self.parent_start_ns
            || self.support_start_ns >= self.support_end_ns
            || self.support_end_ns > self.parent_end_ns
            || self.predecessor_physical_receipt_chain_sha256.len() != 64
            || !self
                .predecessor_physical_receipt_chain_sha256
                .bytes()
                .all(|b| b.is_ascii_hexdigit())
            || self
                .predecessor_transaction_id
                .is_some_and(|p| p.0 > self.transaction_id.0)
        {
            return Err(Error::Identity("native snow custody policy/parent/support"));
        }
        if beginning != self.predecessor_transaction_id
            || (self.kind == NativeSnowCustodyKindV1::ParentFinalization
                && self.support_end_ns != self.parent_end_ns)
        {
            return Err(Error::Identity("native custody retained physical lineage"));
        }
        Ok(beginning)
    }
}

impl NativeSnowLiquidPublicationV1 {
    fn inputs(
        &self,
        configuration: &SurfaceLiquidConfigurationV2,
    ) -> Result<Vec<DirectZeroDurationSnowLiquidInputV1>, Error> {
        let identity = &self.identity;
        if identity.receiver_context_sha256 != identity.expected_receiver_context(&self.outputs)? {
            return Err(Error::Identity(
                "native custody receiver context substitution",
            ));
        }
        if identity.kind == NativeSnowCustodyKindV1::ParentFinalization {
            if !self.outputs.is_empty() || identity.output_set_sha256 != Digest32::zero() {
                return Err(Error::Identity(
                    "native parent finalization has no donor output",
                ));
            }
            return Ok(Vec::new());
        }
        if self.outputs.is_empty() {
            return Err(Error::Identity("native drain missing outputs"));
        }
        let mut seen = BTreeSet::new();
        let mut inputs = Vec::new();
        for output in &self.outputs {
            output
                .validate()
                .map_err(|_| Error::Identity("native drain donor output seal"))?;
            if output.support.start_ns().get() != identity.support_start_ns
                || output.support.end_ns().get() != identity.support_end_ns
                || output.mass_kg_m2_ofe_ground <= 0.0
                || !seen.insert(output.lane_id)
                || !configuration.parent().ofe_bindings.iter().any(|binding| {
                    binding.production_lane_id == output.lane_id && binding.ofe_id == output.ofe_id
                })
            {
                return Err(Error::Identity("native drain donor lane/support"));
            }
            for destination in &output.destinations {
                inputs.push(DirectZeroDurationSnowLiquidInputV1 {
                    output_receipt_sha256: *output.receipt_sha256.as_bytes(),
                    output_set_sha256: *identity.output_set_sha256.as_bytes(),
                    predecessor_owner_set_sha256: *identity
                        .donor_ending_complete_owner_sha256
                        .as_bytes(),
                    receiver_context_sha256: *identity.receiver_context_sha256.as_bytes(),
                    support_start_ns: identity.support_start_ns,
                    support_end_ns: identity.support_end_ns,
                    receiver_ordinal: identity.receiver_ordinal,
                    ofe_id: destination.ofe_id.clone(),
                    tile_id: destination.tile_id.clone(),
                    tile_fraction: destination.tile_fraction,
                    mass_kg_m2_tile_ground: destination.mass_kg_m2_tile_ground,
                    sensible_enthalpy_j_m2_tile_ground: destination
                        .sensible_enthalpy_j_m2_tile_ground,
                });
            }
        }
        let fields = self
            .outputs
            .iter()
            .map(|output| FramedField {
                tag: "snow_liquid_output",
                value: output.receipt_sha256.as_bytes().as_slice(),
            })
            .collect::<Vec<_>>();
        let output_set = framed_sha256("stage3-v11-positive-support-liquid-output-set", &fields)
            .map_err(|_| Error::Schema("native drain output-set seal"))?;
        if output_set != identity.output_set_sha256 {
            return Err(Error::Identity("native drain output-set substitution"));
        }
        Ok(inputs)
    }

    fn reconstruct(
        &self,
        configuration: &SurfaceLiquidConfigurationV2,
        lse_configuration: &LandSurfaceEnergyConfiguration,
    ) -> Result<
        (
            SurfaceLiquidOwnerEnvelopeV2,
            LandSurfaceEnergyV3State,
            LseSurfaceEnthalpyOwnerEnvelopeV1,
            Vec<DirectZeroDurationSnowLiquidReceiptV1>,
        ),
        Error,
    > {
        let beginning = surface(configuration, &self.beginning_surface_bytes)?;
        self.beginning_exact
            .validate_frozen_parent_join(
                lse_configuration,
                &self.beginning_lse,
                configuration,
                &beginning,
            )
            .map_err(|_| Error::Identity("native custody beginning exact/physical join"))?;
        let marker = self.beginning_lse.0.last_accepted_transaction_id;
        if beginning
            .v2_state()
            .ok_or(Error::Identity("native custody V2 beginning"))?
            .records()
            .iter()
            .any(|record| record.last_accepted_transaction_id != marker)
            || self
                .beginning_exact
                .records()
                .iter()
                .any(|record| record.last_accepted_transaction_id != marker)
        {
            return Err(Error::Identity("native custody mixed beginning markers"));
        }
        let ending_marker = self.identity.ending_marker(marker)?;
        let inputs = self.inputs(configuration)?;
        if self.identity.kind == NativeSnowCustodyKindV1::Drain {
            let candidate = prepare_native_snow_liquid_candidate_v1(
                configuration,
                lse_configuration,
                &self.beginning_lse,
                &beginning,
                &self.beginning_exact,
                &inputs,
                self.identity.transaction_id,
                ending_marker,
            )?;
            return Ok((
                candidate.surface_owner,
                candidate.lse_state,
                candidate.exact_owner,
                candidate.allocation.receipts,
            ));
        }
        // The history validator separately proves an earlier accepted partial
        // drain made this parent dirty. No physics or allocation occurs here.
        Ok((
            beginning,
            self.beginning_lse.clone(),
            self.beginning_exact.clone(),
            Vec::new(),
        ))
    }

    fn recomputed_receipt(&self) -> Result<Digest32, Error> {
        let mut value = self.clone();
        value.receipt_sha256 = Digest32::zero();
        value.publication_sha256 = Digest32::zero();
        value.ending_exact.receipt_chain_sha256 = wire_digest(Digest32::zero())?;
        // State digest excludes the receipt chain by existing exact-owner law.
        Ok(digest_bytes(&serde_json::to_vec(&value).map_err(|_| {
            Error::Schema("native custody receipt preimage")
        })?))
    }
    fn recomputed_publication(&self) -> Result<Digest32, Error> {
        let mut value = self.clone();
        value.publication_sha256 = Digest32::zero();
        Ok(digest_bytes(&serde_json::to_vec(&value).map_err(|_| {
            Error::Schema("native custody publication preimage")
        })?))
    }
    pub(crate) fn validate(
        &self,
        configuration: &SurfaceLiquidConfigurationV2,
        lse_configuration: &LandSurfaceEnergyConfiguration,
    ) -> Result<(), Error> {
        if self.schema != NATIVE_SNOW_CUSTODY_SCHEMA
            || self.surface_configuration_sha256 != configuration.configuration_sha256()
            || self.lse_configuration_sha256 != lse_configuration.configuration_sha256
            || self.receipt_sha256 == Digest32::zero()
            || self.receipt_sha256 != self.recomputed_receipt()?
            || self.publication_sha256 == Digest32::zero()
            || self.publication_sha256 != self.recomputed_publication()?
        {
            return Err(Error::Identity(
                "native custody publication seal/configuration",
            ));
        }
        self.lse_owner_bytes(false)?;
        self.lse_owner_bytes(true)?;
        let (expected_surface, expected_lse, mut expected_exact, receipts) =
            self.reconstruct(configuration, lse_configuration)?;
        let beginning_surface = surface(configuration, &self.beginning_surface_bytes)?;
        let liquid_records = |owner: &SurfaceLiquidOwnerEnvelopeV2| -> Result<Vec<_>, Error> {
            Ok(owner
                .v2_state()
                .ok_or(Error::Identity("native liquid projection V2"))?
                .records()
                .iter()
                .map(|record| (record.key.clone(), record.liquid_kg_m2_tile))
                .collect())
        };
        if liquid_records(&beginning_surface)? != self.beginning_liquid_records
            || liquid_records(&expected_surface)? != self.ending_liquid_records
        {
            return Err(Error::Identity("native liquid projection physical join"));
        }
        expected_exact.receipt_chain_sha256 = wire_digest(self.receipt_sha256)?;
        if expected_surface.canonical_bytes(configuration.parent(), Some(configuration))?
            != self.ending_surface_bytes
            || expected_lse != self.ending_lse
            || expected_exact != self.ending_exact
            || receipts != self.allocation_receipts
        {
            return Err(Error::Closure(
                "native custody independently replayed ending",
            ));
        }
        self.ending_exact
            .validate_frozen_parent_join(
                lse_configuration,
                &self.ending_lse,
                configuration,
                &expected_surface,
            )
            .map_err(|_| Error::Identity("native custody ending owner join"))?;
        Ok(())
    }
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn try_new(
        configuration: &SurfaceLiquidConfigurationV2,
        lse_configuration: &LandSurfaceEnergyConfiguration,
        identity: NativeSnowCustodyIdentityV1,
        runtime_authority: openwepp_coupled_time::Policy14RuntimeAuthority,
        active_covered_lse: LandSurfaceEnergyState,
        beginning_lse: LandSurfaceEnergyV3State,
        beginning_surface: &SurfaceLiquidOwnerEnvelopeV2,
        beginning_exact: LseSurfaceEnthalpyOwnerEnvelopeV1,
        outputs: Vec<Stage3AcceptedSnowLiquidOutputV1>,
    ) -> Result<Self, Error> {
        let bytes =
            beginning_surface.canonical_bytes(configuration.parent(), Some(configuration))?;
        let mut value = Self {
            schema: NATIVE_SNOW_CUSTODY_SCHEMA.into(),
            identity,
            runtime_authority,
            active_covered_lse,
            lse_configuration_sha256: lse_configuration.configuration_sha256.clone(),
            surface_configuration_sha256: configuration.configuration_sha256().into(),
            ending_lse: beginning_lse.clone(),
            beginning_lse,
            ending_surface_bytes: bytes.clone(),
            beginning_surface_bytes: bytes,
            beginning_liquid_records: beginning_surface
                .v2_state()
                .ok_or(Error::Identity("native beginning liquid V2"))?
                .records()
                .iter()
                .map(|record| (record.key.clone(), record.liquid_kg_m2_tile))
                .collect(),
            ending_liquid_records: Vec::new(),
            ending_exact: beginning_exact.clone(),
            beginning_exact,
            outputs,
            allocation_receipts: Vec::new(),
            receipt_sha256: Digest32::zero(),
            publication_sha256: Digest32::zero(),
        };
        let (ending, lse, exact, receipts) = value.reconstruct(configuration, lse_configuration)?;
        value.ending_liquid_records = ending
            .v2_state()
            .ok_or(Error::Identity("native ending liquid V2"))?
            .records()
            .iter()
            .map(|record| (record.key.clone(), record.liquid_kg_m2_tile))
            .collect();
        value.ending_surface_bytes =
            ending.canonical_bytes(configuration.parent(), Some(configuration))?;
        value.ending_lse = lse;
        value.ending_exact = exact;
        value.allocation_receipts = receipts;
        value.receipt_sha256 = value.recomputed_receipt()?;
        value.ending_exact.receipt_chain_sha256 = wire_digest(value.receipt_sha256)?;
        value.publication_sha256 = value.recomputed_publication()?;
        value.validate(configuration, lse_configuration)?;
        Ok(value)
    }
    pub(crate) fn canonical_bytes(
        &self,
        configuration: &SurfaceLiquidConfigurationV2,
        lse_configuration: &LandSurfaceEnergyConfiguration,
    ) -> Result<Vec<u8>, Error> {
        self.validate(configuration, lse_configuration)?;
        serde_json::to_vec(self).map_err(|_| Error::Schema("native custody serialization"))
    }
    pub(crate) fn from_canonical_bytes(
        configuration: &SurfaceLiquidConfigurationV2,
        lse_configuration: &LandSurfaceEnergyConfiguration,
        bytes: &[u8],
    ) -> Result<Self, Error> {
        let value: Self =
            serde_json::from_slice(bytes).map_err(|_| Error::Schema("native custody parsing"))?;
        if value.canonical_bytes(configuration, lse_configuration)? != bytes {
            return Err(Error::Schema("native custody noncanonical bytes"));
        }
        Ok(value)
    }
}

impl super::DirectV10RealConsumerShadow {
    /// Build and install both native projections only on an unpublished clone.
    /// The caller supplies the accepted clock identity; donor operands are read
    /// here from the actual retained accepted publication, never supplied.
    pub(crate) fn prepare_native_support_liquid_receiver(
        &self,
        parent_digest: Digest32,
        parent_support: openwepp_coupled_time::TimeSupport,
        support: openwepp_coupled_time::TimeSupport,
        donor_ending: Digest32,
        ordinal: u32,
        terminal_lanes: &BTreeSet<u32>,
    ) -> Result<Option<(Self, NativeSnowLiquidPublicationV1)>, super::DirectV11RealConsumerError>
    {
        use super::DirectV11RealConsumerError as ConsumerError;
        let physical = self
            .frozen_litter_v3
            .as_ref()
            .ok_or(ConsumerError::Identity("native drain physical resident"))?;
        let exact = self
            .frozen_litter_v4
            .as_ref()
            .ok_or(ConsumerError::Identity("native drain exact resident"))?;
        let outputs = self
            .accepted_snow_liquid_outputs_for_support(support)?
            .into_iter()
            .filter(|output| !terminal_lanes.contains(&output.lane_id()))
            .collect::<Vec<_>>();
        let transaction_id = TransactionId(self.vegetation_state.0.last_transaction_id);
        let dirty = physical.native_dirty_parent()
            == Some((
                transaction_id,
                parent_support.start_ns().get(),
                parent_support.end_ns().get(),
                parent_digest,
            ));
        if outputs.is_empty() && !(dirty && support.end_ns() == parent_support.end_ns()) {
            return Ok(None);
        }
        let kind = if outputs.is_empty() {
            NativeSnowCustodyKindV1::ParentFinalization
        } else {
            NativeSnowCustodyKindV1::Drain
        };
        let output_set = if outputs.is_empty() {
            Digest32::zero()
        } else {
            positive_support_output_summary_v1(
                &outputs,
                support.start_ns().get(),
                support.end_ns().get(),
            )
            .map_err(ConsumerError::SurfaceLiquidReplay)?
            .0
        };
        let mut identity = NativeSnowCustodyIdentityV1 {
            policy_id: 14,
            kind,
            parent_transaction_sha256: parent_digest,
            transaction_id,
            predecessor_transaction_id: physical.lse_state().0.last_accepted_transaction_id,
            parent_start_ns: parent_support.start_ns().get(),
            parent_end_ns: parent_support.end_ns().get(),
            support_start_ns: support.start_ns().get(),
            support_end_ns: support.end_ns().get(),
            receiver_ordinal: ordinal,
            donor_ending_complete_owner_sha256: donor_ending,
            receiver_context_sha256: Digest32::zero(),
            output_set_sha256: output_set,
            predecessor_physical_receipt_chain_sha256: physical
                .predecessor_receipt_chain_sha256()
                .into(),
        };
        identity.receiver_context_sha256 = identity
            .expected_receiver_context(&outputs)
            .map_err(ConsumerError::SurfaceLiquidReplay)?;
        let record = NativeSnowLiquidPublicationV1::try_new(
            physical.surface_configuration(),
            physical.lse_configuration(),
            identity,
            super::composite_lse_owner::actual_runtime_authority(self.inner.authority),
            self.inner.lse_state.clone(),
            physical.lse_state().clone(),
            physical.surface_owner(),
            exact.exact_surface_owner().clone(),
            outputs.clone(),
        )
        .map_err(ConsumerError::SurfaceLiquidReplay)?;
        let mut candidate = self.clone();
        let candidate_physical = candidate
            .frozen_litter_v3
            .as_mut()
            .ok_or(ConsumerError::Identity("native drain candidate physical"))?;
        candidate_physical
            .accept_native_snow_publication(record.clone(), &outputs)
            .map_err(ConsumerError::SurfaceLiquidReplay)?;
        candidate
            .frozen_litter_v4
            .as_mut()
            .ok_or(ConsumerError::Identity("native drain candidate exact"))?
            .accept_native_snow_publication(candidate_physical, &record)?;
        Ok(Some((candidate, record)))
    }
}

impl NativeSnowLiquidPublicationV1 {
    /// Transport integrity only. Full configuration-bound semantic replay is
    /// mandatory in the native resident acceptance/restore path.
    pub(crate) fn from_transport_bytes(bytes: &[u8]) -> Result<Self, Error> {
        let value: Self =
            serde_json::from_slice(bytes).map_err(|_| Error::Schema("native transport parsing"))?;
        if serde_json::to_vec(&value).map_err(|_| Error::Schema("native transport encoding"))?
            != bytes
            || value.schema != NATIVE_SNOW_CUSTODY_SCHEMA
            || value.receipt_sha256 == Digest32::zero()
            || value.receipt_sha256 != value.recomputed_receipt()?
            || value.publication_sha256 == Digest32::zero()
            || value.publication_sha256 != value.recomputed_publication()?
            || value.identity.receiver_context_sha256
                != value.identity.expected_receiver_context(&value.outputs)?
        {
            return Err(Error::Identity("native transport seal"));
        }
        value
            .identity
            .ending_marker(value.beginning_lse.0.last_accepted_transaction_id)?;
        value.lse_owner_bytes(false)?;
        value.lse_owner_bytes(true)?;
        if value.identity.kind == NativeSnowCustodyKindV1::ParentFinalization
            && (!value.outputs.is_empty()
                || !value.allocation_receipts.is_empty()
                || value.identity.output_set_sha256 != Digest32::zero())
        {
            return Err(Error::Identity("native finalization transport operands"));
        }
        Ok(value)
    }
}

impl NativeSnowLiquidPublicationV1 {
    pub(crate) fn lse_owner_bytes(&self, ending: bool) -> Result<Vec<u8>, Error> {
        let (lse, exact) = if ending {
            (&self.ending_lse, &self.ending_exact)
        } else {
            (&self.beginning_lse, &self.beginning_exact)
        };
        super::composite_lse_owner::composite_lse_bytes(
            self.runtime_authority,
            &self.active_covered_lse,
            lse,
            exact,
        )
    }
}

impl super::DirectV10RealConsumerShadow {
    pub(crate) fn validate_native_custody_boundary(
        &self,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        allow_open_parent: bool,
        subslabs: &[crate::snow_stage3_v11_attachment::Stage3CoupledSubslabReceiptV1],
    ) -> Result<(), super::DirectV11RealConsumerError> {
        use super::DirectV11RealConsumerError as ConsumerError;
        use super::frozen_litter_v3_publication_retention::FrozenLitterHistoryEntryV1;
        let Some(physical) = self.frozen_litter_v3.as_ref() else {
            if subslabs
                .iter()
                .any(|receipt| receipt.post_support_native_custody.is_some())
            {
                return Err(ConsumerError::Identity(
                    "native packet without native owner",
                ));
            }
            return Ok(());
        };
        if let Some((tx, start, end, digest)) = physical.native_dirty_parent() {
            if !allow_open_parent
                || tx.0 != self.vegetation_state.0.last_transaction_id
                || start != clock.parent_support().start_ns().get()
                || end != clock.parent_support().end_ns().get()
                || digest != clock.parent_transaction_id().digest()
                || clock.accepted_until() <= clock.parent_support().start_ns()
                || clock.accepted_until() >= clock.parent_support().end_ns()
            {
                return Err(ConsumerError::Identity(
                    "native dirty parent enclosing posture",
                ));
            }
        }
        if self.frozen_litter_v4.is_some() {
            let surface = physical
                .surface_owner()
                .canonical_bytes(
                    physical.surface_configuration().parent(),
                    Some(physical.surface_configuration()),
                )
                .map_err(ConsumerError::SurfaceLiquidReplay)?;
            let lse = self.canonical_v11_lse_owner_bytes()?;
            if clock
                .owners()
                .iter()
                .find(|owner| owner.owner_id() == "surface_liquid")
                .is_none_or(|owner| owner.state_bytes() != surface)
                || clock
                    .owners()
                    .iter()
                    .find(|owner| owner.owner_id() == "land_surface_energy")
                    .is_none_or(|owner| owner.state_bytes() != lse)
            {
                return Err(ConsumerError::Identity(
                    "native enclosing clock physical owner bytes",
                ));
            }
        }
        let mut seen = BTreeSet::new();
        for subslab in subslabs {
            let Some(packet) = &subslab.post_support_native_custody else {
                continue;
            };
            subslab
                .validate()
                .map_err(|_| ConsumerError::Identity("native boundary subslab seal"))?;
            let record = packet
                .publication()
                .map_err(|_| ConsumerError::Identity("native boundary packet"))?;
            // The immutable resident history was configuration-validated at
            // acceptance or full durable reconstruction. Exact membership,
            // not a transport self-seal, authenticates its derived projections.
            if !seen.insert(record.publication_sha256)
                || !physical.accepted_history_entries().iter().any(|entry|
                    matches!(entry, FrozenLitterHistoryEntryV1::Custody(accepted) if accepted.as_ref() == &record)) {
                return Err(ConsumerError::Identity("native packet validated history join"));
            }
            let outputs = self
                .accepted_snow_liquid_outputs_for_retained_support(subslab.support)?
                .into_iter()
                .filter(|output| !subslab.terminal_events.contains_key(&output.lane_id()))
                .collect::<Vec<_>>();
            if outputs != record.outputs {
                return Err(ConsumerError::Identity(
                    "native boundary complete donor set",
                ));
            }
        }
        if let (Some(start), Some(end)) = (
            subslabs.iter().map(|s| s.support.start_ns().get()).min(),
            subslabs.iter().map(|s| s.support.end_ns().get()).max(),
        ) {
            for entry in physical.accepted_history_entries() {
                if let FrozenLitterHistoryEntryV1::Custody(record) = entry {
                    if record.identity.support_start_ns >= start
                        && record.identity.support_end_ns <= end
                        && !seen.contains(&record.publication_sha256)
                    {
                        return Err(ConsumerError::Identity(
                            "native boundary omitted custody packet",
                        ));
                    }
                }
            }
        }
        Ok(())
    }
}
