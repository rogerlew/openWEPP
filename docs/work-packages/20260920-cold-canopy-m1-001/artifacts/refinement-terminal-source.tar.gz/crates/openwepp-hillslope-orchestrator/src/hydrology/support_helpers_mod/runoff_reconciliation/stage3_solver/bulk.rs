//! One EXP-B step per real published support; outer refinement retains this model.
use super::terminal_event::{
    TerminalAcceptedMicrostep, TerminalLedger, TerminalState, TerminalTrial,
};
use super::*;

impl Wb11HydrologyKernel {
    pub(super) fn evaluate_bulk_summary(
        inputs: &DirectActiveSnowPartitionInputs,
        supports: &[DirectSnowStage3SupportInput],
        state: &DirectSnowStage3PersistentState,
        support: TimeSupport,
        joint: CoveredTerminalJointTrialStateV1,
        provider: &mut CoveredTerminalTrialProviderV1<'_>,
    ) -> Result<Stage3ShadowSummary, DirectSnowStage3EvaluationError> {
        if supports.len() != 1
            || supports[0].duration_seconds.to_bits() != support.duration_s_bits()
        {
            return Err(DirectSnowStage3EvaluationError::TerminalCustody(
                "bulk support duration",
            ));
        }
        let request = Self::bulk_trial_request(state, support, joint.clone())?;
        crate::snow_accuracy_observer::count("bulk_real_carrier_requests");
        let receipt = provider(request)?;
        Self::bulk_summary_from_transition(inputs, state, support, joint, receipt)
    }

    pub(crate) fn bulk_trial_request(
        state: &DirectSnowStage3PersistentState,
        support: TimeSupport,
        joint: CoveredTerminalJointTrialStateV1,
    ) -> Result<CoveredTerminalTrialRequestV1, DirectSnowStage3EvaluationError> {
        Self::validate_stage3_persistent_state(state)?;
        let fail = || DirectSnowStage3EvaluationError::TerminalCustody("bulk request domain");
        if !stage3_is_bulk_experiment_domain(state)
            || support.duration_ns() < 60_000_000_000
            || support.duration_ns() % 60_000_000_000 != 0
        {
            return Err(fail());
        }
        let ice = 1000.0 * state.layers.iter().map(|l| l.mass_swe_m).sum::<f64>();
        let liquid = 1000.0 * state.layers.iter().map(|l| l.liquid_water_m).sum::<f64>()
            + state.detached_retained_liquid_kg_m2;
        let cold = state
            .layers
            .iter()
            .map(|l| l.cold_content_j_m2)
            .sum::<f64>();
        let depth = state.layers.iter().map(|l| l.thickness_m).sum::<f64>();
        let h = 333_600.0 * liquid - cold;
        let lag = if h < 0.0 {
            h / (2100.0 * (ice + liquid))
        } else {
            0.0
        };
        if ice <= 0.0 || depth <= 0.0 || !lag.is_finite() || lag <= -273.15 {
            return Err(fail());
        }
        let phase_liquid = if h < 0.0 {
            0.0
        } else {
            (h / 333_600.0).min(ice + liquid)
        };
        let phase_ice = ice + liquid - phase_liquid;
        if phase_ice <= 0.0 {
            return Err(fail());
        }
        Ok(CoveredTerminalTrialRequestV1 {
            lane_id: state.lane_id,
            support,
            role: CoveredTerminalTrialRoleV1::Root,
            attempt_ordinal: 0,
            coupling_iteration: 0,
            ice_kg_m2: phase_ice,
            liquid_kg_m2: phase_liquid,
            cold_content_j_m2: (-h).max(0.0),
            surface_temperature_c: lag,
            snow_depth_m: depth,
            snow_density_kg_m3: phase_ice / depth,
            beginning_stage3_state: Box::new(state.clone()),
            ending_snow_hint: None,
            beginning_joint: joint.clone(),
        })
    }

    pub(crate) fn evaluate_bulk_batch_transition(
        inputs: &DirectActiveSnowPartitionInputs,
        state: &DirectSnowStage3PersistentState,
        support_input: DirectSnowStage3SupportInput,
        receipt: CoveredTerminalTrialTransitionV1,
    ) -> Result<DirectSnowStage3PersistentDayResult, DirectSnowStage3EvaluationError> {
        let support = receipt.boundary.support;
        if support_input.duration_seconds.to_bits() != support.duration_s_bits() {
            return Err(DirectSnowStage3EvaluationError::TerminalCustody(
                "bulk batch support",
            ));
        }
        let summary = Self::bulk_summary_from_transition(
            inputs,
            state,
            support,
            receipt.beginning_joint.clone(),
            receipt,
        )?;
        crate::snow_accuracy_observer::count("bulk_batch_receipts_consumed");
        Self::finish_stage3_persistent_summary(
            inputs,
            state,
            state.lane_id,
            state.next_interval_index,
            &[support_input],
            Some(support),
            summary,
        )
    }

    fn bulk_summary_from_transition(
        inputs: &DirectActiveSnowPartitionInputs,
        state: &DirectSnowStage3PersistentState,
        support: TimeSupport,
        joint: CoveredTerminalJointTrialStateV1,
        receipt: CoveredTerminalTrialTransitionV1,
    ) -> Result<Stage3ShadowSummary, DirectSnowStage3EvaluationError> {
        let fail = || DirectSnowStage3EvaluationError::TerminalCustody("bulk receipt custody");
        let request = Self::bulk_trial_request(state, support, joint.clone())?;
        let ice = 1000.0 * state.layers.iter().map(|l| l.mass_swe_m).sum::<f64>();
        let liquid = 1000.0 * state.layers.iter().map(|l| l.liquid_water_m).sum::<f64>()
            + state.detached_retained_liquid_kg_m2;
        let cold = state
            .layers
            .iter()
            .map(|l| l.cold_content_j_m2)
            .sum::<f64>();
        let depth = request.snow_depth_m;
        let h = 333_600.0 * liquid - cold;
        let soil = receipt.trial_snow_soil_receipt.as_ref().ok_or_else(fail)?;
        soil.validate().map_err(|_| fail())?;
        if soil.lane_id != state.lane_id
            || soil.support != support
            || soil.experimental_bulk != receipt.experimental_bulk
        {
            return Err(fail());
        }
        if receipt.beginning_joint != joint
            || receipt.boundary.support != support
            || receipt.probe_child_identity.trial_support != support
        {
            return Err(fail());
        }
        let bulk = receipt.experimental_bulk.ok_or_else(fail)?;
        bulk.canonical_bytes().map_err(|_| fail())?;
        let f = bulk.forcing;
        let o = bulk.outcome;
        if bulk.beginning.water != (ice + liquid)
            || bulk.beginning.enthalpy != h
            || bulk.beginning.depth != depth
            || o.snow_heat.to_bits() != receipt.boundary.snow_soil_heat_j_m2.to_bits()
        {
            return Err(fail());
        }
        let initial_phase_liquid = if h < 0.0 {
            0.0
        } else {
            (h / 333_600.0).min(ice + liquid)
        };
        let conversion_refreeze = liquid - initial_phase_liquid;
        if conversion_refreeze < 0.0 {
            return Err(fail());
        }
        let refreeze = o.refreeze + conversion_refreeze;
        let mut summary = Stage3ShadowSummary::new(Stage3EvaluationTag::new(
            SnowStage3EvaluationOperator::PersistentAccumulationShadowV1,
        ));
        let cold_layers = state
            .layers
            .iter()
            .map(|l| l.cold_content_j_m2)
            .collect::<Vec<_>>();
        Self::stage3_shadow_fingerprints(inputs, &state.layers, &cold_layers, &mut summary);
        summary.complete_arm_non_formulation_fingerprint = summary.non_formulation_fingerprint;
        summary.experimental_bulk_material = Some((f.solid, f.rain));
        summary.requested_seconds = f.seconds;
        summary.evaluated_seconds = f.seconds;
        summary.hourly[0].requested_seconds = f.seconds;
        summary.hourly[0].evaluated_seconds = f.seconds;
        summary.complete_shortwave_j_m2 = f.shortwave;
        summary.complete_longwave_j_m2 = f.longwave;
        summary.complete_sensible_j_m2 = f.sensible;
        summary.complete_latent_j_m2 = f.latent;
        summary.complete_advected_j_m2 = f.precipitation_sensible;
        summary.complete_snow_soil_heat_j_m2 = o.snow_heat;
        summary.complete_energy_j_m2 = f.shortwave
            + f.longwave
            + f.sensible
            + f.latent
            + f.precipitation_sensible
            + o.snow_heat;
        summary.complete_vapor_mass_exchange_kg_m2 = f.vapor;
        summary.cold_content_export_j_m2 = o.vapor_material;
        summary.available_ice_kg_m2 = ice + f.solid + f.vapor.max(0.0) + refreeze;
        summary.cold_energy_change_j_m2 =
            cold + o.ending.enthalpy - o.vapor_material - 333_600.0 * refreeze;
        summary.sublimation_kg_m2 = (-f.vapor).max(0.0);
        summary.melt_kg_m2 = o.melt;
        summary.terminal_deposition_kg_m2 = f.vapor.max(0.0);
        summary.terminal_refrozen_kg_m2 = refreeze;
        summary.unallocated_after_exhaustion_j_m2 = o.sensible_released;
        let hour = &mut summary.hourly[0];
        hour.complete_carrier_evaluated = true;
        hour.complete_energy_j_m2 = summary.complete_energy_j_m2;
        hour.shortwave_energy_j_m2 = f.shortwave;
        hour.longwave_energy_j_m2 = f.longwave;
        hour.sensible_flux_w_m2 = f.sensible / f.seconds;
        hour.latent_flux_w_m2 = f.latent / f.seconds;
        hour.advected_flux_w_m2 = f.precipitation_sensible / f.seconds;
        hour.cold_required_j_m2 = cold;
        hour.cold_energy_change_j_m2 = summary.cold_energy_change_j_m2;
        hour.sublimation_kg_m2 = summary.sublimation_kg_m2;
        hour.melt_kg_m2 = o.melt;
        hour.unallocated_after_exhaustion_j_m2 = o.sensible_released;
        summary.reconciliation.hourly_status[0] = DirectSnowStage3ReconciliationHourStatus {
            evaluated: true,
            reason: "EXP-SNOW-ACCURACY-20260910-B",
        };
        summary.final_layers = if o.ending.water > 0.0 {
            let (swe, density, thickness) =
                crate::snow_accuracy_bulk::layer_geometry(o.ending.water, o.ending.depth)
                    .map_err(|_| fail())?;
            vec![DirectSnowLayerState {
                mass_swe_m: swe,
                liquid_water_m: 0.0,
                thickness_m: thickness,
                density_kg_m3: density,
                settle_day_count: state.layers.first().map_or(0.0, |l| l.settle_day_count),
                temperature_c: o.ending.enthalpy / (2100.0 * o.ending.water),
                cold_content_j_m2: -o.ending.enthalpy,
                refrozen_liquid_m: state
                    .layers
                    .iter()
                    .map(|l| l.refrozen_liquid_m)
                    .sum::<f64>()
                    + refreeze / 1000.0,
            }]
        } else {
            Vec::new()
        };
        let carrier_joint = Some(receipt.ending_joint.clone());
        let ending_joint = Some(receipt.ending_joint.with_terminal_hydrology_state(
            state.lane_id,
            o.ending.water,
            if o.ending.water == 0.0 {
                o.liquid_released
            } else {
                0.0
            },
            -o.ending.enthalpy,
        )?);
        summary.terminal_ending_joint.clone_from(&ending_joint);
        {
            let start = TerminalState {
                ice_kg_m2: ice + f.solid,
                liquid_kg_m2: liquid,
                cold_content_j_m2: cold,
            };
            let end = TerminalState {
                ice_kg_m2: o.ending.water,
                liquid_kg_m2: o.liquid_released,
                cold_content_j_m2: -o.ending.enthalpy,
            };
            let ledger = TerminalLedger {
                complete_energy_j_m2: summary.complete_energy_j_m2,
                cold_energy_change_j_m2: cold + o.ending.enthalpy - o.vapor_material,
                refrozen_kg_m2: refreeze,
                deposition_kg_m2: f.vapor.max(0.0),
                sublimation_kg_m2: (-f.vapor).max(0.0),
                melt_kg_m2: o.melt,
                unallocated_energy_j_m2: o.sensible_released,
                shortwave_energy_j_m2: f.shortwave,
                longwave_energy_j_m2: f.longwave,
                sensible_energy_j_m2: f.sensible,
                latent_energy_j_m2: f.latent,
                advected_energy_j_m2: f.precipitation_sensible,
                snow_soil_heat_energy_j_m2: o.snow_heat,
                external_liquid_kg_m2: f.rain,
            };
            let trial = TerminalTrial { state: end, ledger };
            let mut event = Self::terminal_result_from_trial(
                0,
                0.0,
                f.seconds,
                start,
                end,
                ledger,
                support.duration_ns(),
                support.duration_ns(),
                0,
                support.duration_ns(),
                ice + f.solid,
                o.ending.water,
                trial,
                trial,
                1,
                0,
                0.0,
            )?;
            event.experimental_bulk_policy = Some(bulk.policy);
            event.maximum_scaled_error = None;
            event.lte_coarse_ice_kg_m2 = None;
            event.lte_fine_ice_kg_m2 = None;
            event.lte_coarse_liquid_kg_m2 = None;
            event.lte_fine_liquid_kg_m2 = None;
            event.lte_coarse_cold_content_j_m2 = None;
            event.lte_fine_cold_content_j_m2 = None;
            event.lte_coarse_complete_energy_j_m2 = None;
            event.lte_fine_complete_energy_j_m2 = None;
            event.lte_coarse_unallocated_energy_j_m2 = None;
            event.lte_fine_unallocated_energy_j_m2 = None;
            event.entry_solid_precipitation_kg_m2 = f.solid;
            summary.terminal_event = Some(event);
            summary.terminal_intervals.push(event);
            summary
                .terminal_accepted_microsteps
                .push(TerminalAcceptedMicrostep {
                    relative_start_ns: 0,
                    duration_ns: support.duration_ns(),
                    relative_start_s: 0.0,
                    duration_s: f.seconds,
                    beginning: start,
                    ending: end,
                    ledger,
                    carrier_ending_joint: carrier_joint,
                    hydrology_ending_joint: ending_joint,
                });
        }
        crate::snow_accuracy_observer::count("bulk_steps_produced");
        Ok(summary)
    }
}
