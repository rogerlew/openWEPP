//! Contract-derived, expected-red controls for the private M1 provider.
//!
//! These tests deliberately name the production boundary before its body is
//! introduced.  `admit_fixed_sequence_provider_for_parent` must parse and
//! validate the supplied bytes, authenticate every retained source through
//! `FixedSequenceSourceAdapter`, expand the two frozen cycles, derive the four
//! provider receipt domains, and only then offer an admitted parent to the
//! caller.  It must return `VEG-E-144` before the audit observes owner staging
//! or parent publication for every rejected payload or receipt.
//! Derived GSI support receipts are deliberately outside the payload/run
//! preimage.  `AdmittedFixedSequenceProvider::admit_parent_for_caller` is the
//! separate real parent-admission boundary used to inject receipt poisons.
//!
//! The oracle below does not call the production parser, canonicalizer,
//! expansion helper, source adapter, or receipt helper.  It reads the frozen
//! source artifacts directly and independently checks the contract's segment,
//! record, breakpoint, and binary64 encoding rules.  This is intentionally an
//! expected-red control cut until the named private API exists.

use serde_json::Value;
use sha2::{Digest, Sha256};

use super::m1_fixed_sequence_provider::{
    FixedSequenceAdmissionAudit, FixedSequenceSourceAdapter,
    admit_fixed_sequence_provider_for_parent,
};

const ORIGINAL: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/original-input-reference.json"
));
const CONTINUOUS: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/continuous-fixtures-draft01.json"
));
const ORIGINAL_SHA256: &str = "4b324b0a9c136f2203e8073ca260db5be9e7dd07722a37aec60f2cd528be2d54";
const CONTINUOUS_SHA256: &str = "8cf391055e107ca854f72fb1f70a0e78298575ad0d2ede6fa6c9c760c18191e1";
const PROVIDER_ID: &str = "OPENWEPP_COLD_M1_FIXED_SEQUENCE_PROVIDER_V1";
const GSI_BITS: &str = "3ff0000000000000";
const ORIGINAL_PATH: &str =
    "docs/work-packages/20260920-cold-canopy-m1-001/artifacts/original-input-reference.json";
const CONTINUOUS_PATH: &str =
    "docs/work-packages/20260920-cold-canopy-m1-001/artifacts/continuous-fixtures-draft01.json";
const ENDPOINT_PATH: &str = "crates/openwepp-hillslope-orchestrator/src/land_surface_energy_shadow/strict_v8_endpoint_tests.rs";
const CONTROLLER_PATH: &str = "crates/openwepp-land-surface-energy/src/numerics.rs";
const PROVIDER_PATH: &str = "crates/openwepp-hillslope-orchestrator/src/land_surface_energy_shadow/m1_fixed_sequence_provider.rs";
const ADAPTER_MANIFEST_PATH: &str = "docs/work-packages/20260920-cold-canopy-m1-001/artifacts/m1-fixed-sequence-adapter-dependencies-v1.json";
const ADAPTER_MANIFEST: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/m1-fixed-sequence-adapter-dependencies-v1.json"
));
const SOURCE_JOIN_FIELDS: [&str; 7] = [
    "current_gsi",
    "exposure",
    "destination",
    "co2_pa",
    "reference_height_m",
    "topology",
    "controller_policy",
];

fn sha256_hex(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

fn digest_hex(digest: [u8; 32]) -> String {
    digest.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn canonical_string(value: &str, output: &mut String) {
    output.push('"');
    for character in value.chars() {
        match character {
            '"' => output.push_str("\\\""),
            '\\' => output.push_str("\\\\"),
            '\u{0000}'..='\u{001f}' => {
                use std::fmt::Write as _;
                write!(output, "\\u00{:02x}", character as u32).expect("string write");
            }
            ' '..='\u{007f}' => {
                output.push(character);
            }
            _ => panic!("canonical provider JSON is ASCII only"),
        }
    }
    output.push('"');
}

fn canonical_json(value: &Value, output: &mut String) {
    match value {
        Value::Null => output.push_str("null"),
        Value::Bool(value) => output.push_str(if *value { "true" } else { "false" }),
        Value::Number(value) => output.push_str(&value.to_string()),
        Value::String(value) => canonical_string(value, output),
        Value::Array(values) => {
            output.push('[');
            for (index, value) in values.iter().enumerate() {
                if index != 0 {
                    output.push(',');
                }
                canonical_json(value, output);
            }
            output.push(']');
        }
        Value::Object(values) => {
            output.push('{');
            let mut keys = values.keys().collect::<Vec<_>>();
            keys.sort_unstable();
            for (index, key) in keys.into_iter().enumerate() {
                if index != 0 {
                    output.push(',');
                }
                canonical_string(key, output);
                output.push(':');
                canonical_json(&values[key], output);
            }
            output.push('}');
        }
    }
}

fn canonical_payload_bytes(value: &Value) -> Vec<u8> {
    let mut output = String::new();
    canonical_json(value, &mut output);
    output.push('\n');
    output.into_bytes()
}

fn raw32(hex: &str) -> [u8; 32] {
    let mut bytes = [0_u8; 32];
    for (index, chunk) in hex.as_bytes().chunks_exact(2).enumerate() {
        bytes[index] = u8::from_str_radix(std::str::from_utf8(chunk).expect("hex"), 16)
            .expect("lowercase SHA-256");
    }
    bytes
}

fn framed_sha256(domain: &str, fields: &[(&str, Vec<u8>)]) -> [u8; 32] {
    let mut frame = Vec::new();
    frame.extend_from_slice(b"OPENWEPP\0");
    frame.extend_from_slice(&1_u16.to_be_bytes());
    frame.extend_from_slice(&(domain.len() as u16).to_be_bytes());
    frame.extend_from_slice(domain.as_bytes());
    for (name, value) in fields {
        frame.extend_from_slice(&(name.len() as u16).to_be_bytes());
        frame.extend_from_slice(name.as_bytes());
        frame.extend_from_slice(&(value.len() as u32).to_be_bytes());
        frame.extend_from_slice(value);
    }
    Sha256::digest(frame).into()
}

fn independent_run_identity(payload: &Value, payload_bytes: &[u8]) -> [u8; 32] {
    let sources = payload["sources"].as_array().expect("sources");
    let implementation = &payload["implementation"];
    framed_sha256(
        "openwepp-m1-fixed-sequence-run-v1",
        &[
            ("schema_version", 1_u32.to_be_bytes().to_vec()),
            (
                "provider_id",
                payload["provider_id"]
                    .as_str()
                    .expect("provider id")
                    .as_bytes()
                    .to_vec(),
            ),
            ("calendar", canonical_payload_bytes(&payload["calendar"])),
            (
                "original_source_sha256",
                raw32(sources[0]["sha256"].as_str().expect("original SHA")).to_vec(),
            ),
            (
                "continuous_source_sha256",
                raw32(sources[1]["sha256"].as_str().expect("continuous SHA")).to_vec(),
            ),
            (
                "implementation_version",
                implementation["provider_version"]
                    .as_str()
                    .expect("provider version")
                    .as_bytes()
                    .to_vec(),
            ),
            (
                "implementation_path",
                implementation["repository_relative_path"]
                    .as_str()
                    .expect("implementation path")
                    .as_bytes()
                    .to_vec(),
            ),
            (
                "implementation_sha256",
                raw32(
                    implementation["sha256"]
                        .as_str()
                        .expect("implementation SHA"),
                )
                .to_vec(),
            ),
            (
                "payload_content_sha256",
                Sha256::digest(payload_bytes).to_vec(),
            ),
        ],
    )
}

fn independent_first_gsi_receipt(payload: &Value, run_identity: [u8; 32]) -> [u8; 32] {
    let join = payload["forcing_projection"]["source_joins"]
        .as_array()
        .expect("source joins")
        .iter()
        .find(|join| join["field"] == "current_gsi")
        .expect("current GSI join");
    framed_sha256(
        "openwepp-m1-fixed-sequence-gsi-support-v1",
        &[
            ("run_identity", run_identity.to_vec()),
            ("cycle_ordinal", 0_u32.to_be_bytes().to_vec()),
            (
                "cycle_id",
                b"original_liquid_cold_thaw_refreeze_warm".to_vec(),
            ),
            ("support_ordinal", 0_u32.to_be_bytes().to_vec()),
            ("support_start_ns", 0_u128.to_be_bytes().to_vec()),
            ("support_end_ns", 60_000_000_000_u128.to_be_bytes().to_vec()),
            (
                "gsi_bits",
                u64::from_str_radix(GSI_BITS, 16)
                    .expect("GSI bits")
                    .to_be_bytes()
                    .to_vec(),
            ),
            (
                "gsi_source_join_content_sha256",
                Sha256::digest(canonical_payload_bytes(join)).to_vec(),
            ),
        ],
    )
}

fn independent_calendar_receipt(payload: &Value, run_identity: [u8; 32]) -> [u8; 32] {
    framed_sha256(
        "openwepp-m1-fixed-sequence-calendar-provider-v1",
        &[
            ("run_identity", run_identity.to_vec()),
            (
                "cycle_ordinal",
                u32::try_from(payload["cycle"]["ordinal"].as_u64().expect("ordinal"))
                    .expect("u32 ordinal")
                    .to_be_bytes()
                    .to_vec(),
            ),
            (
                "cycle_id",
                payload["cycle"]["id"]
                    .as_str()
                    .expect("cycle id")
                    .as_bytes()
                    .to_vec(),
            ),
            (
                "initial_phase_records",
                canonical_payload_bytes(&payload["cycle"]["initial_phase_records"]),
            ),
        ],
    )
}

fn independent_parent_forcing_receipt(
    payload: &Value,
    run_identity: [u8; 32],
    parent_ordinal: u32,
) -> [u8; 32] {
    let calendar = independent_calendar_receipt(payload, run_identity);
    let records = payload["forcing_projection"]["records"]
        .as_array()
        .expect("records");
    let first = usize::try_from(parent_ordinal * 30).expect("parent offset");
    let selected = Value::Array(records[first..first + 30].to_vec());
    let gsi_join = payload["forcing_projection"]["source_joins"]
        .as_array()
        .expect("joins")
        .iter()
        .find(|join| join["field"] == "current_gsi")
        .expect("GSI join");
    let gsi_join_digest = Sha256::digest(canonical_payload_bytes(gsi_join));
    let cycle = &payload["cycle"];
    let mut ordered = Vec::with_capacity(4 + 30 * 36);
    ordered.extend_from_slice(&30_u32.to_be_bytes());
    for record_ordinal in parent_ordinal * 30..(parent_ordinal + 1) * 30 {
        let receipt = framed_sha256(
            "openwepp-m1-fixed-sequence-gsi-support-v1",
            &[
                ("run_identity", run_identity.to_vec()),
                (
                    "cycle_ordinal",
                    u32::try_from(cycle["ordinal"].as_u64().expect("ordinal"))
                        .expect("u32 ordinal")
                        .to_be_bytes()
                        .to_vec(),
                ),
                (
                    "cycle_id",
                    cycle["id"].as_str().expect("cycle id").as_bytes().to_vec(),
                ),
                ("support_ordinal", record_ordinal.to_be_bytes().to_vec()),
                (
                    "support_start_ns",
                    (u128::from(record_ordinal) * 60_000_000_000)
                        .to_be_bytes()
                        .to_vec(),
                ),
                (
                    "support_end_ns",
                    (u128::from(record_ordinal + 1) * 60_000_000_000)
                        .to_be_bytes()
                        .to_vec(),
                ),
                (
                    "gsi_bits",
                    u64::from_str_radix(GSI_BITS, 16)
                        .expect("GSI bits")
                        .to_be_bytes()
                        .to_vec(),
                ),
                ("gsi_source_join_content_sha256", gsi_join_digest.to_vec()),
            ],
        );
        ordered.extend_from_slice(&32_u32.to_be_bytes());
        ordered.extend_from_slice(&receipt);
    }
    framed_sha256(
        "openwepp-m1-fixed-sequence-parent-forcing-v1",
        &[
            ("calendar_receipt", calendar.to_vec()),
            (
                "full_projection_content_sha256",
                Sha256::digest(canonical_payload_bytes(&payload["forcing_projection"])).to_vec(),
            ),
            ("parent_ordinal", parent_ordinal.to_be_bytes().to_vec()),
            (
                "support_start_ns",
                (u128::from(parent_ordinal) * 1_800_000_000_000)
                    .to_be_bytes()
                    .to_vec(),
            ),
            (
                "support_end_ns",
                (u128::from(parent_ordinal + 1) * 1_800_000_000_000)
                    .to_be_bytes()
                    .to_vec(),
            ),
            ("record_count", 30_u32.to_be_bytes().to_vec()),
            ("ordered_records", canonical_payload_bytes(&selected)),
            ("ordered_gsi_support_receipts", ordered),
        ],
    )
}

fn fixture_oracle() -> Value {
    assert_eq!(sha256_hex(ORIGINAL.as_bytes()), ORIGINAL_SHA256);
    assert_eq!(sha256_hex(CONTINUOUS.as_bytes()), CONTINUOUS_SHA256);
    independently_validate_adapter_manifest();
    let source: Value = serde_json::from_str(CONTINUOUS).expect("frozen continuous fixture JSON");
    assert_eq!(source["base_input_sha256"], ORIGINAL_SHA256);
    assert_eq!(source["support_s"], 60);
    assert_eq!(source["duration_s"], 259_200);
    source
}

fn provider_source_sha256() -> String {
    // The planned private adapter and selected expansion live in this one
    // source file.  This direct byte read is deliberately an oracle input,
    // never a production-generated answer.
    sha256_hex(include_bytes!("m1_fixed_sequence_provider.rs"))
}

fn retained_dependency_bytes(path: &str) -> &'static [u8] {
    match path {
        ORIGINAL_PATH => ORIGINAL.as_bytes(),
        CONTINUOUS_PATH => CONTINUOUS.as_bytes(),
        ENDPOINT_PATH => include_bytes!("strict_v8_endpoint_tests.rs"),
        "crates/openwepp-hillslope-orchestrator/src/land_surface_energy_shadow/v8_input_projection.rs" =>
        {
            include_bytes!("v8_input_projection.rs")
        }
        "crates/openwepp-hillslope-orchestrator/src/v9_real_consumer_shadow.rs" => {
            include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/src/v9_real_consumer_shadow.rs"
            ))
        }
        "crates/openwepp-hillslope-orchestrator/src/direct_runtime/surface_liquid_owner.rs" => {
            include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/src/direct_runtime/surface_liquid_owner.rs"
            ))
        }
        "crates/openwepp-hillslope-orchestrator/src/vegetation_real_hydrology_shadow.rs" => {
            include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/src/vegetation_real_hydrology_shadow.rs"
            ))
        }
        "crates/openwepp-vegetation/src/transaction.rs" => include_bytes!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../openwepp-vegetation/src/transaction.rs"
        )),
        "crates/openwepp-land-surface-energy/src/lib.rs" => include_bytes!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../openwepp-land-surface-energy/src/lib.rs"
        )),
        CONTROLLER_PATH => include_bytes!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../openwepp-land-surface-energy/src/numerics.rs"
        )),
        _ => panic!("closed retained adapter dependency path"),
    }
}

fn independently_validate_adapter_manifest() {
    let manifest: Value = serde_json::from_str(ADAPTER_MANIFEST).expect("adapter manifest JSON");
    assert_eq!(manifest["schema_version"], 1);
    let dependencies = manifest["dependencies"].as_array().expect("dependencies");
    assert_eq!(dependencies.len(), 10);
    assert_eq!(
        dependencies
            .iter()
            .map(|dependency| dependency["path"].as_str().expect("dependency path"))
            .collect::<std::collections::BTreeSet<_>>()
            .len(),
        10,
    );
    for dependency in dependencies {
        let path = dependency["path"].as_str().expect("dependency path");
        let expected = dependency["sha256"].as_str().expect("dependency SHA");
        assert_eq!(expected, sha256_hex(retained_dependency_bytes(path)));
    }
}

fn adapter_locator(constructor_accessor: &str, output: Value, output_pointer: &str) -> Value {
    serde_json::json!({
        "adapter_path": PROVIDER_PATH,
        "adapter_sha256": provider_source_sha256(),
        "dependency_manifest_path": ADAPTER_MANIFEST_PATH,
        "dependency_manifest_sha256": sha256_hex(ADAPTER_MANIFEST.as_bytes()),
        "constructor_accessor": constructor_accessor,
        "output_canonical_json_sha256": sha256_hex(&canonical_payload_bytes(&output)),
        "output_pointer": output_pointer,
    })
}

fn expected_source_join_rows() -> Vec<Value> {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input JSON");
    let inputs = &original["inputs"];
    let endpoint = super::endpoint_fixture();
    let endpoint_records = serde_json::to_value(&endpoint.surface_configuration.records)
        .expect("endpoint surface records serialize");
    let destination = endpoint_records
        .as_array()
        .expect("endpoint records")
        .iter()
        .find(|row| row["ground_ingress_mode"] == "covered_canopy_release")
        .map(|row| {
            format!(
                "{}/{}",
                row["key"]["ofe_id"].as_str().expect("OFE id"),
                row["key"]["tile_id"].as_str().expect("tile id")
            )
        })
        .expect("retained covered destination");
    let gsi_output = serde_json::json!({
        "gsi": format!("{:016x}", endpoint.receipt.forcing().gsi.to_bits()),
    });
    assert_eq!(gsi_output["gsi"], GSI_BITS);
    let destination_output = serde_json::json!({
        "records": endpoint_records,
        "destination": destination,
    });
    let exposure_output = serde_json::json!({
        "authority": inputs["authority"],
        "stage3_lower_boundary": inputs["stage3_lower_boundary"],
        "stage3_optical": inputs["stage3_optical"],
    });
    let topology_output = serde_json::json!({
        "occupancies": inputs["occupancies"],
        "soil_nodes": inputs["ground"]["soil_nodes"],
    });
    let (max_newton_iterations, max_backtracking_halvings) =
        openwepp_land_surface_energy::m1_fixed_sequence_controller_policy();
    let controller_output = serde_json::json!({
        "max_backtracking_halvings": max_backtracking_halvings,
        "max_newton_iterations": max_newton_iterations,
    });
    vec![
        serde_json::json!({"field":"current_gsi","source_path":ENDPOINT_PATH,"source_sha256":sha256_hex(include_bytes!("strict_v8_endpoint_tests.rs")),"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::endpoint_gsi_for_provider",gsi_output.clone(),"/gsi"),"value_kind":"binary64_bits","value":gsi_output["gsi"]}),
        serde_json::json!({"field":"exposure","source_path":ORIGINAL_PATH,"source_sha256":ORIGINAL_SHA256,"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::original_exposure_for_provider",exposure_output,""),"value_kind":"canonical_json_sha256","value":sha256_hex(&canonical_payload_bytes(&serde_json::json!({"authority":inputs["authority"],"stage3_lower_boundary":inputs["stage3_lower_boundary"],"stage3_optical":inputs["stage3_optical"]})))}),
        serde_json::json!({"field":"destination","source_path":ENDPOINT_PATH,"source_sha256":sha256_hex(include_bytes!("strict_v8_endpoint_tests.rs")),"locator_kind":"source_extraction_adapter","locator":adapter_locator("strict_v8_endpoint_tests::endpoint_fixture/surface_configuration.records",destination_output,"/destination"),"value_kind":"utf8","value":destination}),
        serde_json::json!({"field":"co2_pa","source_path":ORIGINAL_PATH,"source_sha256":ORIGINAL_SHA256,"locator_kind":"json_pointer","locator":"/inputs/ca_pa","value_kind":"binary64_bits","value":format!("{:016x}",inputs["ca_pa"].as_f64().expect("CO2").to_bits())}),
        serde_json::json!({"field":"reference_height_m","source_path":ORIGINAL_PATH,"source_sha256":ORIGINAL_SHA256,"locator_kind":"json_pointer","locator":"/inputs/ground/open_geometry/reference_height_m","value_kind":"binary64_bits","value":format!("{:016x}",inputs["ground"]["open_geometry"]["reference_height_m"].as_f64().expect("reference height").to_bits())}),
        serde_json::json!({"field":"topology","source_path":ORIGINAL_PATH,"source_sha256":ORIGINAL_SHA256,"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::original_topology_for_provider",topology_output,""),"value_kind":"canonical_json_sha256","value":sha256_hex(&canonical_payload_bytes(&serde_json::json!({"occupancies":inputs["occupancies"],"soil_nodes":inputs["ground"]["soil_nodes"]})))}),
        serde_json::json!({"field":"controller_policy","source_path":CONTROLLER_PATH,"source_sha256":sha256_hex(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../openwepp-land-surface-energy/src/numerics.rs"))),"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::controller_policy_for_provider",controller_output,""),"value_kind":"canonical_json_sha256","value":sha256_hex(&canonical_payload_bytes(&serde_json::json!({"max_backtracking_halvings":max_backtracking_halvings,"max_newton_iterations":max_newton_iterations})))}),
    ]
}

fn expected_initial_phase_records(cycle: &Value) -> Vec<Value> {
    cycle["initial_phase_records"]
        .as_array()
        .expect("initial phase records")
        .iter()
        .map(|phase| {
            serde_json::json!({
                "occupancy_id": phase["occupancy_id"].as_str().expect("occupancy id"),
                "mass_kg_m2_tile_ground": format!("{:016x}", phase["mass_kg_m2_tile_ground"].as_f64().expect("mass").to_bits()),
                "enthalpy_j_m2_tile_ground": format!("{:016x}", phase["enthalpy_j_m2_tile_ground"].as_f64().expect("enthalpy").to_bits()),
            })
        })
        .collect()
}

fn expected_payload(cycle_ordinal: usize) -> Value {
    let fixture = fixture_oracle();
    let cycle = &fixture["cycles"][cycle_ordinal];
    let segments = cycle["segments"].as_array().expect("segments").iter().enumerate().map(|(ordinal, segment)| {
        serde_json::json!({"ordinal":ordinal,"start_ns":(segment["start_s"].as_u64().expect("start") as u128 * 1_000_000_000).to_string(),"end_ns":(segment["end_s"].as_u64().expect("end") as u128 * 1_000_000_000).to_string(),"overrides":record_overrides(segment)})
    }).collect::<Vec<_>>();
    let records = expected_cycle_records(cycle).into_iter().map(|(bits, start, end, ordinal)| serde_json::json!({"ordinal":ordinal,"start_ns":start.to_string(),"end_ns":end.to_string(),"overrides":{"air_temperature_k":format!("{:016x}",bits[0]),"air_specific_humidity_kg_kg":format!("{:016x}",bits[1]),"atmospheric_downward_longwave_w_m2":format!("{:016x}",bits[2]),"top_liquid_rate_kg_m2_tile_s":format!("{:016x}",bits[3]),"top_liquid_temperature_k":format!("{:016x}",bits[4])}})).collect::<Vec<_>>();
    serde_json::json!({
        "schema_version":1,
        "provider_id":PROVIDER_ID,
        "calendar":{"system":"proleptic_gregorian","fixed_utc_offset_seconds":0,"day_seconds":86400,"daylight_saving":false,"leap_seconds":false,"origin":"2000-06-20T00:00:00+00:00","tick_unit":"integer_nanoseconds","cycle_clock_resets":true,"day_mapping":[{"day_ordinal":0,"civil_date":"2000-06-20"},{"day_ordinal":1,"civil_date":"2000-06-21"},{"day_ordinal":2,"civil_date":"2000-06-22"}]},
        "cycle":{"ordinal":cycle_ordinal,"id":cycle["id"],"initial_phase_records":expected_initial_phase_records(cycle)},
        "sources":[{"name":"original_input","repository_relative_path":ORIGINAL_PATH,"sha256":ORIGINAL_SHA256},{"name":"continuous_fixture","repository_relative_path":CONTINUOUS_PATH,"sha256":CONTINUOUS_SHA256}],
        "implementation":{"provider_version":PROVIDER_ID,"repository_relative_path":PROVIDER_PATH,"sha256":provider_source_sha256()},
        "forcing_projection":{"projection_id":"OPENWEPP_COLD_M1_PIECEWISE_CONSTANT_V1","support_unit":"s","support_seconds":60,"cycle_id":cycle["id"],"segments":segments,"records":records,"source_joins":expected_source_join_rows()},
    })
}

fn record_overrides(segment: &Value) -> Value {
    let values = &segment["boundary_overrides"];
    serde_json::json!({
        "air_temperature_k":format!("{:016x}",values["air_temperature_k"].as_f64().expect("temperature").to_bits()),
        "air_specific_humidity_kg_kg":format!("{:016x}",values["air_specific_humidity_kg_kg"].as_f64().expect("humidity").to_bits()),
        "atmospheric_downward_longwave_w_m2":format!("{:016x}",values["atmospheric_downward_longwave_w_m2"].as_f64().expect("longwave").to_bits()),
        "top_liquid_rate_kg_m2_tile_s":format!("{:016x}",values["top_liquid_rate_kg_m2_tile_s"].as_f64().expect("rate").to_bits()),
        "top_liquid_temperature_k":format!("{:016x}",values["top_liquid_temperature_k"].as_f64().expect("liquid temperature").to_bits()),
    })
}

fn independently_validate_source_join_rows(payload: &Value) {
    let joins = payload["forcing_projection"]["source_joins"]
        .as_array()
        .expect("seven source joins");
    assert_eq!(joins.len(), SOURCE_JOIN_FIELDS.len());
    assert_eq!(joins, expected_source_join_rows().as_slice());
}

fn independently_validate_projection(source: &Value) {
    let cycles = source["cycles"].as_array().expect("cycles array");
    assert_eq!(cycles.len(), 2);
    for cycle in cycles {
        let segments = cycle["segments"].as_array().expect("segments array");
        assert_eq!(segments.first().expect("first segment")["start_s"], 0);
        assert_eq!(segments.last().expect("last segment")["end_s"], 259_200);
        let mut records = 0_u32;
        for (index, segment) in segments.iter().enumerate() {
            let start = segment["start_s"].as_u64().expect("start seconds");
            let end = segment["end_s"].as_u64().expect("end seconds");
            assert!(end > start);
            assert_eq!((end - start) % 60, 0);
            if let Some(previous) = index.checked_sub(1) {
                assert_eq!(segments[previous]["end_s"], segment["start_s"]);
            }
            records += ((end - start) / 60) as u32;
            for field in [
                "air_temperature_k",
                "air_specific_humidity_kg_kg",
                "atmospheric_downward_longwave_w_m2",
                "top_liquid_rate_kg_m2_tile_s",
                "top_liquid_temperature_k",
            ] {
                let value = segment["boundary_overrides"][field]
                    .as_f64()
                    .expect("frozen binary64 source scalar");
                assert!(value.is_finite());
                assert_eq!(format!("{:016x}", value.to_bits()).len(), 16);
            }
        }
        assert_eq!(records, 4_320);
    }
    assert_eq!(cycles[0]["id"], "original_liquid_cold_thaw_refreeze_warm");
    assert_eq!(cycles[0]["segments"][0]["end_s"], 60);
    assert_eq!(cycles[0]["segments"][1]["start_s"], 60);
}

fn expected_record_bits(
    segment: &Value,
    ordinal: u32,
    start_s: u64,
) -> ([u64; 5], u128, u128, u32) {
    let overrides = &segment["boundary_overrides"];
    let bits = [
        overrides["air_temperature_k"]
            .as_f64()
            .expect("air temperature")
            .to_bits(),
        overrides["air_specific_humidity_kg_kg"]
            .as_f64()
            .expect("humidity")
            .to_bits(),
        overrides["atmospheric_downward_longwave_w_m2"]
            .as_f64()
            .expect("longwave")
            .to_bits(),
        overrides["top_liquid_rate_kg_m2_tile_s"]
            .as_f64()
            .expect("liquid rate")
            .to_bits(),
        overrides["top_liquid_temperature_k"]
            .as_f64()
            .expect("liquid temperature")
            .to_bits(),
    ];
    (
        bits,
        u128::from(start_s) * 1_000_000_000,
        u128::from(start_s + 60) * 1_000_000_000,
        ordinal,
    )
}

fn expected_cycle_records(cycle: &Value) -> Vec<([u64; 5], u128, u128, u32)> {
    let mut expected = Vec::with_capacity(4_320);
    for segment in cycle["segments"].as_array().expect("segments") {
        let start = segment["start_s"].as_u64().expect("segment start");
        let end = segment["end_s"].as_u64().expect("segment end");
        for tick in (start..end).step_by(60) {
            expected.push(expected_record_bits(segment, expected.len() as u32, tick));
        }
    }
    expected
}

fn source_adapter() -> FixedSequenceSourceAdapter {
    // This must invoke the retained endpoint constructor/accessor and inspect
    // `fixture.receipt.forcing().gsi`; it must never read a Rust literal.
    FixedSequenceSourceAdapter::from_retained_endpoint_fixture_with_dependency_manifest(
        ADAPTER_MANIFEST.as_bytes(),
    )
}

fn canonical_payload_from_adapter(
    adapter: &FixedSequenceSourceAdapter,
    cycle_ordinal: u32,
) -> Vec<u8> {
    adapter
        .canonical_payload_bytes(PROVIDER_ID, cycle_ordinal)
        .expect("retained inputs form one canonical provider payload")
}

fn assert_provider_refusal(payload: &[u8], adapter: &FixedSequenceSourceAdapter) {
    let mut audit = FixedSequenceAdmissionAudit::new();
    let error = match admit_fixed_sequence_provider_for_parent(payload, adapter, &mut audit) {
        Ok(_) => panic!(
            "provider mutation admitted; payload_bytes={}",
            payload.len()
        ),
        Err(error) => error,
    };
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(audit.owner_stage_attempts(), 0);
    assert_eq!(audit.parent_publications(), 0);
    let mut caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_controls()
            .expect("real caller beginning");
    let before = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
        .expect("complete caller snapshot");
    let error = super::m1_fixed_sequence_provider::admit_payload_into_actual_caller(
        payload,
        adapter,
        &mut caller,
    )
    .expect_err("payload poison must refuse before caller staging");
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
            .expect("post-refusal caller snapshot"),
        before,
    );
}

fn assert_parent_receipt_refusal(
    admitted: &super::m1_fixed_sequence_provider::AdmittedFixedSequenceProvider,
    receipts: &[[u8; 32]],
) {
    let mut audit = FixedSequenceAdmissionAudit::new();
    let error = admitted
        .admit_parent_for_caller(0, receipts, &mut audit)
        .expect_err("derived GSI receipt mutation must refuse parent admission");
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(audit.owner_stage_attempts(), 0);
    assert_eq!(audit.parent_publications(), 0);
    let mut caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_controls()
            .expect("real caller beginning");
    let before = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
        .expect("complete caller snapshot");
    let error = admitted
        .admit_parent_into_actual_caller(&mut caller, 0, receipts)
        .expect_err("receipt poison must refuse before caller staging");
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
            .expect("post-refusal caller snapshot"),
        before,
    );
}

fn independently_constructed_seven_owner_bytes(
    cycle_ordinal: usize,
) -> std::collections::BTreeMap<String, Vec<u8>> {
    let fixture = super::endpoint_fixture();
    let cycles: Value = serde_json::from_str(CONTINUOUS).expect("frozen continuous fixture");
    let reservoirs = cycles["cycles"][cycle_ordinal]["initial_phase_records"]
        .as_array()
        .expect("cycle initial phase rows")
        .iter()
        .map(|row| {
            (
                row["occupancy_id"].as_str().expect("occupancy").to_owned(),
                row["mass_kg_m2_tile_ground"].as_f64().expect("mass"),
                row["enthalpy_j_m2_tile_ground"].as_f64().expect("enthalpy"),
            )
        })
        .collect::<Vec<_>>();
    let mut configuration = fixture.vegetation_configuration.clone();
    configuration.model_definition_sha256 =
        "60792c5fd1e5e3a09a9e4cfaa08673bd0c61ff3c86fa098155785606ff043328".to_owned();
    configuration.configuration_sha256 =
        configuration.canonical_sha256().expect("M1 configuration");
    let vegetation = openwepp_vegetation::cold_canopy_m1_owner::M1OwnerState::try_new(
        &configuration,
        "OPENWEPP_C3_WOODY_COLD_M1_V1".to_owned(),
        configuration.model_definition_sha256.clone(),
        u64::try_from(fixture.vegetation_state.last_transaction_id).expect("transaction"),
        reservoirs
            .iter()
            .map(|(occupancy, mass, enthalpy)| {
                openwepp_vegetation::cold_canopy_m1_owner::M1OwnerReservoir::try_new(
                    occupancy.clone(),
                    *mass,
                    *enthalpy,
                )
            })
            .collect::<Result<Vec<_>, _>>()
            .expect("M1 reservoirs"),
        fixture.vegetation_state.strata.clone(),
    )
    .expect("M1 owner");
    let surface = fixture
        .frame
        .surface_liquid_shadow
        .as_ref()
        .expect("surface owner");
    let thermal = super::V8SoilThermalPhysicalBeginning::try_from_v1(&fixture.thermal)
        .expect("thermal owner");
    let snow_state =
        crate::hydrology::Wb11HydrologyKernel::initialize_stage3_persistent_state(1, Vec::new())
            .expect("inactive Stage-3 snow");
    let mut snow_lanes = std::collections::BTreeMap::new();
    snow_lanes.insert(1_u32, snow_state);
    std::collections::BTreeMap::from([
        (
            "bgc".to_owned(),
            serde_json::to_vec(&fixture.biogeochemistry).expect("BGC bytes"),
        ),
        (
            "hydrology".to_owned(),
            crate::v9_real_consumer_shadow::canonical_hydrology_owner_bytes_v1(&fixture.frame)
                .expect("hydrology bytes"),
        ),
        (
            "land_surface_energy".to_owned(),
            serde_json::to_vec(&fixture.lse_state).expect("LSE bytes"),
        ),
        (
            "snow".to_owned(),
            crate::v9_real_consumer_shadow::canonical_stage3_snow_owner_bytes_v11(&snow_lanes)
                .expect("snow bytes"),
        ),
        (
            "soil_thermal".to_owned(),
            thermal
                .canonical_active_owner_bytes()
                .expect("thermal bytes"),
        ),
        (
            "surface_liquid".to_owned(),
            crate::v9_real_consumer_shadow::canonical_surface_liquid_complete_owner_projection_v2(
                surface,
                &fixture.surface_configuration,
                None,
            )
            .expect("surface projection bytes"),
        ),
        (
            "vegetation".to_owned(),
            serde_json::to_vec(&vegetation).expect("vegetation bytes"),
        ),
    ])
}

fn mutate_payload(payload: &[u8], mutation: impl FnOnce(&mut Value)) -> Vec<u8> {
    let mut value: Value = serde_json::from_slice(payload).expect("canonical provider payload");
    mutation(&mut value);
    let mutated = canonical_payload_bytes(&value);
    assert_ne!(
        mutated, payload,
        "semantic provider mutation must change canonical payload bytes"
    );
    mutated
}

#[test]
fn m1_provider_real_source_encoding_and_parent_slice_oracle() {
    let fixture = fixture_oracle();
    independently_validate_projection(&fixture);
    let adapter = source_adapter();
    let payload = canonical_payload_from_adapter(&adapter, 0);
    let payload_value: Value = serde_json::from_slice(&payload).expect("provider JSON");
    assert_eq!(payload_value, expected_payload(0));
    assert_eq!(payload, canonical_payload_bytes(&payload_value));
    let expected_run_identity = independent_run_identity(&payload_value, &payload);
    let admitted = admit_fixed_sequence_provider_for_parent(
        &payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("unchanged frozen provider payload admits");

    assert_eq!(admitted.provider_id(), PROVIDER_ID);
    assert_eq!(admitted.record_count(), 4_320);
    assert_eq!(admitted.parent_count(), 144);
    assert_eq!(admitted.run_identity(), expected_run_identity);
    assert_eq!(
        admitted
            .parent_gsi_support_receipts(0)
            .expect("first parent receipts")[0],
        independent_first_gsi_receipt(&payload_value, expected_run_identity),
    );
    assert_eq!(
        admitted.record(0).expect("first record").interval_ns(),
        (0, 60_000_000_000)
    );
    assert_eq!(
        admitted
            .record(29)
            .expect("last first-parent record")
            .interval_ns(),
        (1_740_000_000_000, 1_800_000_000_000)
    );
    assert_eq!(
        admitted.parent(0).expect("first parent").record_ordinals(),
        0..30
    );
    assert_eq!(
        admitted.parent(0).expect("first parent").interval_ns(),
        (0, 1_800_000_000_000)
    );
    assert_eq!(
        admitted.gsi_bits(),
        u64::from_str_radix(GSI_BITS, 16).expect("GSI bits")
    );

    // This independent byte oracle fixes the actual frozen sources, canonical
    // payload encoding, run receipt preimage, and first real GSI receipt.
}

#[test]
fn m1_provider_both_cycles_expand_every_frozen_record_parent_day_and_phase() {
    let fixture = fixture_oracle();
    let adapter = source_adapter();
    let cycles = fixture["cycles"].as_array().expect("two frozen cycles");
    for (cycle_ordinal, cycle) in cycles.iter().enumerate() {
        let payload = canonical_payload_from_adapter(&adapter, cycle_ordinal as u32);
        let payload_value: Value = serde_json::from_slice(&payload).expect("canonical payload");
        assert_eq!(payload_value, expected_payload(cycle_ordinal));
        assert_eq!(payload, canonical_payload_bytes(&payload_value));
        independently_validate_source_join_rows(&payload_value);
        assert_eq!(payload_value["cycle"]["ordinal"], cycle_ordinal as u64);
        assert_eq!(payload_value["cycle"]["id"], cycle["id"]);
        assert_eq!(
            payload_value["cycle"]["initial_phase_records"],
            Value::Array(expected_initial_phase_records(cycle))
        );
        assert_eq!(
            payload_value["calendar"]["day_mapping"],
            serde_json::json!([
                {"day_ordinal": 0, "civil_date": "2000-06-20"},
                {"day_ordinal": 1, "civil_date": "2000-06-21"},
                {"day_ordinal": 2, "civil_date": "2000-06-22"},
            ]),
        );

        let admitted = admit_fixed_sequence_provider_for_parent(
            &payload,
            &adapter,
            &mut FixedSequenceAdmissionAudit::new(),
        )
        .expect("independently frozen cycle admits");
        let expected_run = independent_run_identity(&payload_value, &payload);
        assert_eq!(admitted.run_identity(), expected_run);
        assert_eq!(
            admitted.gsi_bits(),
            super::endpoint_fixture().receipt.forcing().gsi.to_bits(),
            "retained endpoint GSI must be the emitted join and receipt scalar",
        );
        assert_eq!(
            admitted.calendar_receipt(),
            independent_calendar_receipt(&payload_value, expected_run),
        );
        let expected = expected_cycle_records(cycle);
        assert_eq!(expected.len(), 4_320);
        for (bits, start_ns, end_ns, ordinal) in expected {
            let record = admitted.record(ordinal).expect("expanded record");
            assert_eq!(record.interval_ns(), (start_ns, end_ns));
            assert_eq!(record.override_binary64_bits(), bits);
        }
        for parent_ordinal in 0..144_u32 {
            let parent = admitted.parent(parent_ordinal).expect("parent slice");
            assert_eq!(
                parent.record_ordinals(),
                (parent_ordinal * 30)..((parent_ordinal + 1) * 30)
            );
            assert_eq!(
                parent.interval_ns(),
                (
                    u128::from(parent_ordinal) * 1_800_000_000_000,
                    u128::from(parent_ordinal + 1) * 1_800_000_000_000
                ),
            );
            assert_eq!(
                admitted
                    .parent_forcing_receipt(parent_ordinal)
                    .expect("forcing receipt"),
                independent_parent_forcing_receipt(&payload_value, expected_run, parent_ordinal),
            );
        }
        println!(
            "M1_PROVIDER_IDENTITY {}",
            serde_json::json!({
                "cycle_ordinal": cycle_ordinal,
                "payload_sha256": digest_hex(admitted.payload_content_sha256()),
                "implementation_sha256": digest_hex(admitted.implementation_sha256().expect("implementation digest")),
                "adapter_manifest_sha256": digest_hex(adapter.manifest_sha256()),
                "run_identity": digest_hex(admitted.run_identity()),
                "calendar_receipt": digest_hex(admitted.calendar_receipt()),
                "first_parent_forcing_receipt": digest_hex(admitted.parent_forcing_receipt(0).expect("first forcing receipt")),
                "first_gsi_support_receipt": digest_hex(admitted.parent_gsi_support_receipts(0).expect("first GSI receipt")[0]),
                "record_count": admitted.record_count(),
                "parent_count": admitted.parent_count(),
            })
        );
    }
}

#[test]
fn m1_provider_rejects_each_contract_mutation_before_owner_staging() {
    let _fixture = fixture_oracle();
    let adapter = source_adapter();
    let payload = canonical_payload_from_adapter(&adapter, 0);
    let mutations: &[fn(&mut Value)] = &[
        |v| {
            v["provider_id"] = Value::String("foreign".into());
        },
        |v| {
            v["calendar"]["origin"] = Value::String("2000-06-20T00:00:01+00:00".into());
        },
        |v| {
            v["calendar"]["day_mapping"]
                .as_array_mut()
                .expect("days")
                .swap(0, 1);
        },
        |v| {
            v["cycle"]["ordinal"] = Value::from(1_u64);
        },
        |v| {
            v["cycle"]["initial_phase_records"]
                .as_array_mut()
                .expect("phases")
                .swap(0, 1);
        },
        |v| {
            v["sources"][0]["sha256"] = Value::String("00".repeat(32));
        },
        |v| {
            v["implementation"]["repository_relative_path"] = Value::String("forged.rs".into());
        },
        |v| {
            v["forcing_projection"]["segments"]
                .as_array_mut()
                .expect("segments")
                .remove(0);
        },
        |v| {
            v["forcing_projection"]["records"]
                .as_array_mut()
                .expect("records")
                .swap(0, 1);
        },
        |v| {
            v["forcing_projection"]["records"][0]["end_ns"] = Value::String("61000000000".into());
        },
        |v| {
            v["forcing_projection"]["source_joins"]
                .as_array_mut()
                .expect("joins")
                .swap(0, 1);
        },
        |v| {
            v["forcing_projection"]["source_joins"][0]["locator_kind"] =
                Value::String("rust_literal".into());
        },
        |v| {
            v["forcing_projection"]["source_joins"][0]["value_kind"] = Value::String("utf8".into());
        },
        |v| {
            v["forcing_projection"]["source_joins"][0]["value"] =
                Value::String("0000000000000000".into());
        },
        |v| {
            v.as_object_mut()
                .expect("object")
                .insert("unknown".into(), Value::Null);
        },
    ];
    for mutation in mutations {
        assert_provider_refusal(&mutate_payload(&payload, *mutation), &adapter);
    }

    // Every one of the closed seven joins is independently mutable.  These
    // cases cover source/path/locator/kind/value and missing-field refusal,
    // rather than merely observing a changed tuple or digest.
    for join_index in 0..7 {
        for field in [
            "field",
            "source_path",
            "source_sha256",
            "locator_kind",
            "locator",
            "value_kind",
            "value",
        ] {
            assert_provider_refusal(
                &mutate_payload(&payload, |value| {
                    value["forcing_projection"]["source_joins"][join_index][field] =
                        Value::String(format!("forged-{join_index}-{field}"));
                }),
                &adapter,
            );
        }
        for field in [
            "field",
            "source_path",
            "source_sha256",
            "locator_kind",
            "locator",
            "value_kind",
            "value",
        ] {
            assert_provider_refusal(
                &mutate_payload(&payload, |value| {
                    value["forcing_projection"]["source_joins"][join_index]
                        .as_object_mut()
                        .expect("join object")
                        .remove(field);
                }),
                &adapter,
            );
        }
    }

    // Poison every source-extraction adapter's complete dependency/output
    // binding.  The scalar JSON-pointer rows are covered above as closed rows.
    for join_index in [0, 1, 2, 5, 6] {
        for field in [
            "adapter_path",
            "adapter_sha256",
            "dependency_manifest_path",
            "dependency_manifest_sha256",
            "constructor_accessor",
            "output_canonical_json_sha256",
            "output_pointer",
        ] {
            assert_provider_refusal(
                &mutate_payload(&payload, |value| {
                    value["forcing_projection"]["source_joins"][join_index]["locator"]
                        .as_object_mut()
                        .expect("adapter locator")
                        .insert(field.to_owned(), Value::String(format!("forged-{field}")));
                }),
                &adapter,
            );
        }
    }

    // This is deliberately a real source-adapter input poison, not a locator
    // tuple comparison.  The planned private constructor retains raw manifest
    // bytes and admission verifies its closed entries before parsing/minting.
    let mut poisoned_manifest: Value =
        serde_json::from_str(ADAPTER_MANIFEST).expect("frozen dependency manifest");
    poisoned_manifest["dependencies"][0]["sha256"] = Value::String("00".repeat(32));
    let poisoned_manifest_bytes = canonical_payload_bytes(&poisoned_manifest);
    let poisoned_adapter =
        FixedSequenceSourceAdapter::from_retained_endpoint_fixture_with_dependency_manifest(
            &poisoned_manifest_bytes,
        );
    assert_provider_refusal(&payload, &poisoned_adapter);

    for top_level_field in [
        "calendar",
        "cycle",
        "sources",
        "implementation",
        "forcing_projection",
    ] {
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                value
                    .as_object_mut()
                    .expect("payload object")
                    .remove(top_level_field);
            }),
            &adapter,
        );
    }

    for field in [
        "system",
        "fixed_utc_offset_seconds",
        "day_seconds",
        "daylight_saving",
        "leap_seconds",
        "origin",
        "tick_unit",
        "cycle_clock_resets",
        "day_mapping",
    ] {
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                value["calendar"]
                    .as_object_mut()
                    .expect("calendar")
                    .remove(field);
            }),
            &adapter,
        );
    }
    for field in ["provider_version", "repository_relative_path", "sha256"] {
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                value["implementation"]
                    .as_object_mut()
                    .expect("implementation")
                    .remove(field);
            }),
            &adapter,
        );
    }
    for source_index in 0..2 {
        for field in ["name", "repository_relative_path", "sha256"] {
            assert_provider_refusal(
                &mutate_payload(&payload, |value| {
                    value["sources"][source_index]
                        .as_object_mut()
                        .expect("source")
                        .remove(field);
                }),
                &adapter,
            );
        }
    }
    for field in [
        "projection_id",
        "support_unit",
        "support_seconds",
        "cycle_id",
        "segments",
        "records",
        "source_joins",
    ] {
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                value["forcing_projection"]
                    .as_object_mut()
                    .expect("projection")
                    .remove(field);
            }),
            &adapter,
        );
    }
    for field in ["ordinal", "start_ns", "end_ns", "overrides"] {
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                value["forcing_projection"]["segments"][0]
                    .as_object_mut()
                    .expect("segment")
                    .remove(field);
            }),
            &adapter,
        );
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                value["forcing_projection"]["records"][0]
                    .as_object_mut()
                    .expect("record")
                    .remove(field);
            }),
            &adapter,
        );
    }
    for field in [
        "air_temperature_k",
        "air_specific_humidity_kg_kg",
        "atmospheric_downward_longwave_w_m2",
        "top_liquid_rate_kg_m2_tile_s",
        "top_liquid_temperature_k",
    ] {
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                let overrides = value["forcing_projection"]["segments"][0]["overrides"]
                    .as_object_mut()
                    .expect("segment overrides");
                let original =
                    u64::from_str_radix(overrides[field].as_str().expect("binary64 override"), 16)
                        .expect("binary64 override");
                overrides.insert(
                    field.to_owned(),
                    Value::String(format!("{:016x}", original ^ 1)),
                );
            }),
            &adapter,
        );
        assert_provider_refusal(
            &mutate_payload(&payload, |value| {
                value["forcing_projection"]["records"][0]["overrides"]
                    .as_object_mut()
                    .expect("record overrides")
                    .remove(field);
            }),
            &adapter,
        );
    }

    // Parser-level duplicates and noncanonical JSON cannot be represented by
    // serde_json::Value, so preserve them as byte-level mutations.
    let payload_text = std::str::from_utf8(&payload).expect("UTF-8 payload");
    let without_final_object = payload_text
        .strip_suffix("}\n")
        .expect("canonical object with final LF");
    let duplicate = format!("{without_final_object},\"provider_id\":\"{PROVIDER_ID}\"}}\n");
    let leading_whitespace = format!(" {payload_text}");
    let leading_zero = payload_text.replacen("\"schema_version\":1", "\"schema_version\":01", 1);
    let crlf = payload_text
        .strip_suffix('\n')
        .expect("final LF")
        .to_owned()
        + "\r\n";
    let non_ascii = payload_text.replacen(
        PROVIDER_ID,
        "OPENWEPP_COLD_M1_FÍXED_SEQUENCE_PROVIDER_V1",
        1,
    );
    let escaped_slash = payload_text.replacen('/', "\\/", 1);
    let alternate_escape = payload_text.replacen(
        PROVIDER_ID,
        "\\u004fPENWEPP_COLD_M1_FIXED_SEQUENCE_PROVIDER_V1",
        1,
    );
    let nested_duplicate = payload_text.replacen(
        "\"system\":\"proleptic_gregorian\"",
        "\"system\":\"proleptic_gregorian\",\"system\":\"proleptic_gregorian\"",
        1,
    );
    let non_hex_float = payload_text.replacen(GSI_BITS, "3FF000000000000G", 1);
    for bytes in [
        duplicate.into_bytes(),
        leading_whitespace.into_bytes(),
        leading_zero.into_bytes(),
        crlf.into_bytes(),
        non_ascii.into_bytes(),
        escaped_slash.into_bytes(),
        alternate_escape.into_bytes(),
        nested_duplicate.into_bytes(),
        non_hex_float.into_bytes(),
    ] {
        assert_provider_refusal(&bytes, &adapter);
    }
}

#[test]
fn m1_provider_rejects_missing_foreign_reordered_and_stale_gsi_receipts() {
    let adapter = source_adapter();
    let payload = canonical_payload_from_adapter(&adapter, 0);
    let admitted = admit_fixed_sequence_provider_for_parent(
        &payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("sister payload admits before receipt poisons");
    let receipts = admitted
        .parent_gsi_support_receipts(0)
        .expect("first parent receipts");
    assert_eq!(receipts.len(), 30);
    let mut missing = receipts.clone();
    missing.pop();
    assert_parent_receipt_refusal(&admitted, &missing);
    let mut foreign = receipts.clone();
    foreign[0] = [0_u8; 32];
    assert_parent_receipt_refusal(&admitted, &foreign);
    let mut reordered = receipts.clone();
    reordered.swap(0, 1);
    assert_parent_receipt_refusal(&admitted, &reordered);
    let stale = admitted
        .parent_gsi_support_receipts(1)
        .expect("second parent receipts");
    assert_parent_receipt_refusal(&admitted, &stale);
    // The passing sister control uses the exact derived receipt vector at the
    // real parent-admission boundary; acceptance must still occur before any
    // caller-owned staging is permitted.
    let mut audit = FixedSequenceAdmissionAudit::new();
    admitted
        .admit_parent_for_caller(0, &receipts, &mut audit)
        .expect("exact ordered receipts admit the parent");
    assert_eq!(audit.owner_stage_attempts(), 0);
    assert_eq!(audit.parent_publications(), 0);
}

#[test]
fn m1_provider_canonical_ascii_escape_vectors_are_independent() {
    let encoded = canonical_payload_bytes(&serde_json::json!({
        "slash": "/",
        "quote": "\\\"",
        "backslash": "\\\\",
        "controls": "\u{0000}\u{0008}\n\u{001f}",
    }));
    assert_eq!(
        std::str::from_utf8(&encoded).expect("ASCII encoding"),
        "{\"backslash\":\"\\\\\\\\\",\"controls\":\"\\u0000\\u0008\\u000a\\u001f\",\"quote\":\"\\\\\\\"\",\"slash\":\"/\"}\n",
    );
}

#[test]
fn m1_provider_refusal_preserves_real_caller_owners_clock_staging_and_publication() {
    // This test fixture is required to construct `M1CallerState::beginning`
    // from the retained endpoint fixture and real beginning owners only.  It
    // is not a mock owner set, digest-only substitute, or physical execution.
    let mut caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_controls()
            .expect("real caller beginning");
    let adapter = source_adapter();
    let payload = canonical_payload_from_adapter(&adapter, 0);
    let admitted = admit_fixed_sequence_provider_for_parent(
        &payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("sister provider admission");
    let before = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
        .expect("complete owner/clock/staging/publication snapshot");
    let retained_snow = caller
        .beginning_owner_bytes()
        .expect("seven actual beginning owners")
        .remove("snow")
        .expect("actual retained Stage-3 snow bytes");
    let mut poisoned = admitted
        .parent_gsi_support_receipts(0)
        .expect("first parent receipts");
    poisoned.swap(0, 1);
    let error = admitted
        .admit_parent_into_actual_caller(&mut caller, 0, &poisoned)
        .expect_err("reordered derived receipts refuse before caller staging");
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
            .expect("post-refusal snapshot"),
        before,
    );

    admitted
        .admit_parent_into_actual_caller(
            &mut caller,
            0,
            &admitted
                .parent_gsi_support_receipts(0)
                .expect("sister receipts"),
        )
        .expect("unchanged sister request reaches the real caller admission seam");
    assert_eq!(caller.admitted_owner_count(), Some(7));
    assert!(!caller.has_staged_owner());
    assert_eq!(
        caller.active_participants(),
        Some(
            [
                "bgc".to_owned(),
                "hydrology".to_owned(),
                "land_surface_energy".to_owned(),
                "soil_thermal".to_owned(),
                "surface_liquid".to_owned(),
                "vegetation".to_owned(),
            ]
            .as_slice()
        )
    );
    assert_eq!(
        caller
            .beginning_owner_bytes()
            .expect("seven actual owner bytes after admission")
            .remove("snow")
            .expect("retained Stage-3 snow bytes after admission"),
        retained_snow,
    );
    let admitted_snapshot =
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
            .expect("installed clock capability snapshot");
    let error = admitted
        .admit_parent_into_actual_caller(
            &mut caller,
            0,
            &admitted
                .parent_gsi_support_receipts(0)
                .expect("sister receipts"),
        )
        .expect_err("duplicate parent admission rejects");
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
            .expect("duplicate refusal snapshot"),
        admitted_snapshot,
    );
}

#[test]
fn m1_provider_actual_seven_owner_bytes_match_independent_canonical_projections() {
    for cycle_ordinal in 0..2 {
        let caller =
            super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_cycle(
                cycle_ordinal,
            )
            .expect("real cycle-specific caller");
        assert_eq!(
            caller
                .beginning_owner_bytes()
                .expect("actual seven owner bytes"),
            independently_constructed_seven_owner_bytes(cycle_ordinal as usize),
            "every complete owner must use its canonical beginning bytes",
        );
    }
}

#[test]
fn m1_provider_actual_caller_refuses_wrong_cycle_and_out_of_sequence_parent() {
    let adapter = source_adapter();
    let mut cycle_zero_caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_controls()
            .expect("cycle-zero real caller beginning");
    let cycle_one_payload = canonical_payload_from_adapter(&adapter, 1);
    let cycle_one = admit_fixed_sequence_provider_for_parent(
        &cycle_one_payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("cycle-one payload is independently admissible");
    let before =
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&cycle_zero_caller)
            .expect("cycle-zero snapshot");
    let error = cycle_one
        .admit_parent_into_actual_caller(
            &mut cycle_zero_caller,
            0,
            &cycle_one
                .parent_gsi_support_receipts(0)
                .expect("cycle-one receipts"),
        )
        .expect_err("cycle-one initial M/H cannot enter a cycle-zero caller");
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&cycle_zero_caller)
            .expect("wrong-cycle post-refusal snapshot"),
        before,
    );

    let cycle_zero_payload = canonical_payload_from_adapter(&adapter, 0);
    let cycle_zero = admit_fixed_sequence_provider_for_parent(
        &cycle_zero_payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("cycle-zero payload admits");
    let error = cycle_zero
        .admit_parent_into_actual_caller(
            &mut cycle_zero_caller,
            5,
            &cycle_zero
                .parent_gsi_support_receipts(5)
                .expect("parent-five receipts"),
        )
        .expect_err("fresh caller cannot skip parents");
    assert_eq!(error.code(), "VEG-E-144");
    assert_eq!(
        super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&cycle_zero_caller)
            .expect("out-of-sequence post-refusal snapshot"),
        before,
    );

    let mut cycle_one_caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_cycle(1)
            .expect("cycle-one real caller beginning");
    cycle_one
        .admit_parent_into_actual_caller(
            &mut cycle_one_caller,
            0,
            &cycle_one
                .parent_gsi_support_receipts(0)
                .expect("cycle-one sister receipts"),
        )
        .expect("cycle-specific beginning admits its matching sister");
}

#[test]
fn m1_provider_adjacent_supports_retain_actual_soil_and_custody_operands() {
    let adapter = source_adapter();
    let payload = canonical_payload_from_adapter(&adapter, 0);
    let admitted = admit_fixed_sequence_provider_for_parent(
        &payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("admitted provider");
    let mut caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_controls()
            .expect("actual caller");
    admitted
        .admit_parent_into_actual_caller(
            &mut caller,
            0,
            &admitted
                .parent_gsi_support_receipts(0)
                .expect("parent receipts"),
        )
        .expect("parent admission");
    let first = super::m1_fixed_sequence_provider::advance_fixed_sequence_support(
        &mut caller,
        &admitted,
        0,
        None,
    )
    .expect("first actual support");
    let first_staged_thermal = caller
        .staged_soil_temperature_bits()
        .expect("actual first staged thermal owner");
    let second = super::m1_fixed_sequence_provider::advance_fixed_sequence_support(
        &mut caller,
        &admitted,
        1,
        None,
    )
    .expect("second actual support");
    assert_eq!(first.prepared_soil_temperature_bits().len(), 6);
    assert_eq!(second.prepared_soil_temperature_bits().len(), 6);
    assert_eq!(
        second.prepared_soil_temperature_by_layer(),
        &first_staged_thermal
    );
    assert!(!first.resource_debits().is_empty());
    assert!(!first.complete_owner_candidates().is_empty());
    println!(
        "M1_ADJACENT_ACTUAL {}",
        serde_json::json!({
            "first_ordinal": first.record_ordinal(),
            "second_ordinal": second.record_ordinal(),
            "first_soil_input_bits": first.prepared_soil_temperature_bits(),
        "second_soil_input_bits": second.prepared_soil_temperature_bits(),
        "first_staged_thermal_bits": first_staged_thermal,
            "first_debits": first.resource_debits(),
            "first_fluxes": first.admitted_resource_fluxes(),
            "first_transitions": first.shared_resource_owner_transitions(),
            "first_candidates": first.complete_owner_candidates(),
            "first_material_proposals": first.material_transfers(),
            "first_bgc_receipts_debug": format!("{:?}", first.biogeochemistry_candidate().receipts()),
        })
    );
}

fn m1_adjacent_accepted_outcome_json(
    outcome: &super::m1_fixed_sequence_provider::M1AcceptedSupportOutcome,
) -> serde_json::Value {
    serde_json::json!({
        "ordinal": outcome.record_ordinal(), "support": format!("{:?}", outcome.support()),
        "override_bits": outcome.applied_override_bits(), "gsi_bits": outcome.gsi_bits(),
        "gsi_receipt": outcome.gsi_support_receipt(), "parent_forcing_receipt": outcome.parent_forcing_receipt(),
        "checked_support_transaction_id": outcome.checked_support_transaction_id().to_string(),
        "beginning_owner_bytes": outcome.beginning_owner_bytes(), "ending_owner_bytes": outcome.ending_owner_bytes(),
        "reservoir_operands": format!("{:?}", outcome.reservoir_operands()),
        "native_consumed_forcing_bits": outcome.native_consumed_forcing_bits(),
        "prepared_soil_by_layer": outcome.prepared_soil_temperature_by_layer(),
        "prepared_soil_temperature_bits": outcome.prepared_soil_temperature_bits(),
        "staged_bgc_parent_predecessor": outcome.staged_bgc_parent_predecessor().to_string(),
        "thermal_transition": outcome.staged_thermal_transition_sha256(),
        "bgc_beginning": format!("{:?}", outcome.beginning_biogeochemistry()),
        "bgc_ending": format!("{:?}", outcome.ending_biogeochemistry()),
        "material_transfers": format!("{:?}", outcome.material_transfers()),
        "resource_debits": format!("{:?}", outcome.resource_debits()),
        "resource_fluxes": format!("{:?}", outcome.admitted_resource_fluxes()),
        "resource_transitions": format!("{:?}", outcome.shared_resource_owner_transitions()),
        "owner_candidates": format!("{:?}", outcome.complete_owner_candidates()),
        "native_source_operands": format!("{:?}", outcome.native_receiver_source_operands()),
        "native_receiver_is_positive": outcome.native_receiver().is_positive(),
        "native_receiver_receipt": outcome.native_receiver().receipt().map(|receipt| serde_json::json!({
            "support": format!("{:?}", receipt.support()), "transaction_id": receipt.transaction_id().to_string(),
            "mass_bits": receipt.mass_kg_m2_tile().to_bits(), "enthalpy_bits": receipt.enthalpy_j_kg().to_bits(),
        })),
        "accepted_slab_receipt": format!("{:?}", outcome.accepted_slab_receipt()),
        "ending_owner_states": format!("{:?}", outcome.ending_owner_states()),
    })
}

#[test]
fn m1_adjacent_json_identifiers_preserve_u128_max_as_decimal_strings() {
    let value = serde_json::json!({"identifier": u128::MAX.to_string()});
    assert_eq!(
        value["identifier"].as_str(),
        Some("340282366920938463463374607431768211455")
    );
}

#[test]
fn m1_provider_first_refused_support_retains_preparation_and_caller_prefix() {
    let adapter = source_adapter();
    let payload = canonical_payload_from_adapter(&adapter, 0);
    let admitted = admit_fixed_sequence_provider_for_parent(
        &payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("admitted provider");
    let mut caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_controls()
            .expect("actual caller");
    admitted
        .admit_parent_into_actual_caller(
            &mut caller,
            0,
            &admitted
                .parent_gsi_support_receipts(0)
                .expect("parent receipts"),
        )
        .expect("parent admission");
    let accepted = super::m1_fixed_sequence_provider::advance_fixed_sequence_support(
        &mut caller,
        &admitted,
        0,
        None,
    )
    .expect("accepted ordinal zero");
    let before = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
        .expect("pre-refusal caller snapshot");
    let before_owners = caller.staged_owner_bytes().expect("pre-refusal owners");
    let before_cursor = caller.accepted_cursor();
    let before_beginning_owners = caller.beginning_owner_bytes();
    let before_clock = format!("{:?}", caller.active_parent_clock());
    super::m1_fixed_sequence_provider::arm_m1_lse_diagnostic_for_ordinal(1);
    let result = super::m1_fixed_sequence_provider::advance_fixed_sequence_support(
        &mut caller,
        &admitted,
        1,
        None,
    );
    eprintln!("M1_ADJACENT_PHYSICAL_RESULT {:?}", result.as_ref().err());
    let diagnostic = super::m1_fixed_sequence_provider::take_m1_lse_diagnostic_record();
    let after = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller);
    let after_owners = caller.staged_owner_bytes();
    let after_beginning_owners = caller.beginning_owner_bytes();
    let after_clock = format!("{:?}", caller.active_parent_clock());
    eprintln!(
        "M1_ADJACENT_INSTRUMENTED {}",
        serde_json::json!({
            "accepted_ordinal": accepted.record_ordinal(),
            "accepted_support": m1_adjacent_accepted_outcome_json(&accepted),
            "canonical_payload": serde_json::from_slice::<Value>(&payload).ok(),
            "refused_ordinal": 1,
            "solver_attempt": diagnostic,
            "result_error": result.as_ref().err().map(|error| format!("{error:?}")),
            "accepted_cursor_before": before_cursor,
            "accepted_cursor_after": caller.accepted_cursor(),
            "staged_owner_bytes_before": before_owners,
            "staged_owner_bytes_after": format!("{after_owners:?}"),
            "beginning_owner_bytes_before": format!("{before_beginning_owners:?}"),
            "beginning_owner_bytes_after": format!("{after_beginning_owners:?}"),
            "active_parent_clock_before": before_clock,
            "active_parent_clock_after": after_clock,
            "snapshot_before": format!("{before:?}"),
            "snapshot_after": format!("{after:?}"),
        })
    );
    let solver_error = match result.as_ref() {
        Err(super::m1_fixed_sequence_provider::M1ParentExecutionError::Solver(error)) => error,
        _ => panic!("instrumented support must retain the solver refusal"),
    };
    let diagnostic = diagnostic.as_ref().expect("instrumented observer record");
    assert_eq!(
        diagnostic
            .get("observer")
            .and_then(|observer| observer.get("status"))
            .and_then(Value::as_str),
        Some("Complete")
    );
    let observer = diagnostic.get("observer").expect("observer payload");
    assert!(
        observer
            .get("seed_coordinates_bits")
            .is_some_and(|seed| !seed.is_null())
    );
    for key in ["bases", "trials", "linear_solves"] {
        assert!(
            observer
                .get(key)
                .is_some_and(|rows| rows.as_array().is_some_and(|rows| !rows.is_empty()))
        );
    }
    assert_eq!(
        observer.get("terminal_error_code").and_then(Value::as_str),
        Some(solver_error.code())
    );
    assert!(matches!(
        result,
        Err(super::m1_fixed_sequence_provider::M1ParentExecutionError::Solver(_))
    ));
    let after = after.expect("post-refusal caller snapshot");
    let after_owners = after_owners.expect("post-refusal owners");
    assert_eq!(after, before);
    assert_eq!(after_owners, before_owners);
    assert_eq!(caller.accepted_cursor(), before_cursor);
}

#[test]
fn m1_provider_adjacent_observer_disabled_baseline_retains_prefix() {
    let adapter = source_adapter();
    let payload = canonical_payload_from_adapter(&adapter, 0);
    let admitted = admit_fixed_sequence_provider_for_parent(
        &payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("admitted provider");
    let mut caller =
        super::m1_fixed_sequence_provider::actual_m1_caller_beginning_for_provider_controls()
            .expect("actual caller");
    admitted
        .admit_parent_into_actual_caller(
            &mut caller,
            0,
            &admitted
                .parent_gsi_support_receipts(0)
                .expect("parent receipts"),
        )
        .expect("parent admission");
    let accepted = super::m1_fixed_sequence_provider::advance_fixed_sequence_support(
        &mut caller,
        &admitted,
        0,
        None,
    )
    .expect("accepted ordinal zero");
    let before = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
        .expect("baseline pre-refusal snapshot");
    let before_owners = caller.staged_owner_bytes();
    let before_cursor = caller.accepted_cursor();
    let before_beginning_owners = caller.beginning_owner_bytes();
    let before_clock = format!("{:?}", caller.active_parent_clock());
    let result = super::m1_fixed_sequence_provider::advance_fixed_sequence_support(
        &mut caller,
        &admitted,
        1,
        None,
    );
    eprintln!("M1_ADJACENT_PHYSICAL_RESULT {:?}", result.as_ref().err());
    let after = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller);
    let after_owners = caller.staged_owner_bytes();
    let after_beginning_owners = caller.beginning_owner_bytes();
    let after_clock = format!("{:?}", caller.active_parent_clock());
    eprintln!(
        "M1_ADJACENT_BASELINE {}",
        serde_json::json!({
            "accepted_ordinal": accepted.record_ordinal(), "refused_ordinal": 1,
            "accepted_support": m1_adjacent_accepted_outcome_json(&accepted),
            "canonical_payload": serde_json::from_slice::<Value>(&payload).ok(),
            "result_error": result.as_ref().err().map(|error| format!("{error:?}")),
            "snapshot_before": format!("{before:?}"), "snapshot_after": format!("{after:?}"),
            "accepted_cursor_before": before_cursor, "accepted_cursor_after": caller.accepted_cursor(),
            "staged_owner_bytes_before": format!("{before_owners:?}"),
            "staged_owner_bytes_after": format!("{after_owners:?}"),
            "beginning_owner_bytes_before": format!("{before_beginning_owners:?}"),
            "beginning_owner_bytes_after": format!("{after_beginning_owners:?}"),
            "active_parent_clock_before": before_clock,
            "active_parent_clock_after": after_clock,
        })
    );
    assert!(matches!(
        result,
        Err(super::m1_fixed_sequence_provider::M1ParentExecutionError::Solver(_))
    ));
    let after = after.expect("baseline post-refusal snapshot");
    let after_owners = after_owners.expect("baseline post-refusal owners");
    let before_owners = before_owners.expect("baseline pre-refusal owners");
    assert_eq!(after, before);
    assert_eq!(after_owners, before_owners);
    assert_eq!(caller.accepted_cursor(), before_cursor);
}
