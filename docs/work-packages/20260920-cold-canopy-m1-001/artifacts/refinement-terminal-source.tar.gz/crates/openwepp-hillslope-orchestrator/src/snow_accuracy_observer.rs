//! Isolated experiment observation; never installed in primary runtime source.
use serde_json::Value;
use std::collections::BTreeMap;
use std::io::Write as _;
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};
static STARTED: AtomicBool = AtomicBool::new(false);
static PHYSICAL: AtomicBool = AtomicBool::new(false);
static LEDGER_OVERFLOW: AtomicBool = AtomicBool::new(false);
static LEDGERS: Mutex<BTreeMap<String, Value>> = Mutex::new(BTreeMap::new());
static POISONED: AtomicBool = AtomicBool::new(false);
static COUNTS: Mutex<Option<BTreeMap<&'static str, u64>>> = Mutex::new(None);

#[derive(Default)]
struct Capture {
    physical: bool,
    rows: Vec<Value>,
    row_count: usize,
    spool: Option<(std::path::PathBuf, std::io::BufWriter<std::fs::File>)>,
    overflow: bool,
}
static CAPTURE: Mutex<Option<Capture>> = Mutex::new(None);
// Fixed experimental disk-record bound includes charged trial operands; rows
// are spooled and never retained as a complete in-memory array.
const MAX_PHYSICAL_ROWS: usize = 2_000_000;
const MAX_PHYSICAL_LEDGERS: usize = 200_000;

pub fn begin(physical: bool) {
    // This experiment uses one session in each fresh collector process. Never
    // relabel surviving worker records by silently starting another session.
    if STARTED.swap(true, Ordering::SeqCst) {
        POISONED.store(true, Ordering::Relaxed);
        return;
    }
    POISONED.store(false, Ordering::Relaxed);
    PHYSICAL.store(physical, Ordering::Relaxed);
    LEDGER_OVERFLOW.store(false, Ordering::Relaxed);
    if let Ok(mut ledgers) = LEDGERS.lock() {
        ledgers.clear();
    } else {
        POISONED.store(true, Ordering::Relaxed);
    }
    if let Ok(mut counts) = COUNTS.lock() {
        *counts = Some(BTreeMap::new());
    } else {
        POISONED.store(true, Ordering::Relaxed);
    }
    if let Ok(mut capture) = CAPTURE.lock() {
        *capture = Some(Capture {
            physical,
            ..Capture::default()
        });
    } else {
        POISONED.store(true, Ordering::Relaxed);
    }
}
#[must_use]
pub fn physical_enabled() -> bool {
    PHYSICAL.load(Ordering::Relaxed)
}

pub fn count(key: &'static str) {
    if let Ok(mut slot) = COUNTS.lock() {
        if let Some(counts) = slot.as_mut() {
            *counts.entry(key).or_default() += 1;
        }
    } else {
        POISONED.store(true, Ordering::Relaxed);
    }
}
#[must_use]
pub fn physical_global_enabled() -> bool {
    PHYSICAL.load(Ordering::Relaxed)
}
pub fn ledger(key: String, row: Value) {
    if let Ok(mut ledgers) = LEDGERS.lock() {
        if let Some(existing) = ledgers.get(&key) {
            if existing != &row {
                POISONED.store(true, Ordering::Relaxed);
            }
        } else if ledgers.len() < MAX_PHYSICAL_LEDGERS {
            ledgers.insert(key, row);
        } else {
            LEDGER_OVERFLOW.store(true, Ordering::Relaxed);
        }
    } else {
        POISONED.store(true, Ordering::Relaxed);
    }
}
pub fn failure(message: String) {
    POISONED.store(true, Ordering::Relaxed);
    record(serde_json::json!({"kind":"observation_error","message":message}));
}
pub fn record(mut row: Value) {
    if !physical_enabled() {
        return;
    }
    if let Ok(mut capture) = CAPTURE.lock() {
        if let Some(capture) = capture.as_mut() {
            if capture.row_count < MAX_PHYSICAL_ROWS {
                if let Some(object) = row.as_object_mut() {
                    object.insert(
                        "capture".to_owned(),
                        serde_json::json!({
                            "process":std::process::id(), "session":1,
                            "ordinal":capture.row_count,
                            "thread":format!("{:?}",std::thread::current().id())
                        }),
                    );
                } else {
                    POISONED.store(true, Ordering::Relaxed);
                }
                let count = capture.row_count;
                if let Some((_, writer)) = capture.spool.as_mut() {
                    let result = (|| -> Result<(), ObservationWriteError> {
                        if count != 0 {
                            writer.write_all(b",")?;
                        }
                        serde_json::to_writer(writer, &row)?;
                        Ok(())
                    })();
                    if result.is_err() {
                        POISONED.store(true, Ordering::Relaxed);
                    }
                } else {
                    capture.rows.push(row);
                }
                capture.row_count += 1;
            } else {
                capture.overflow = true;
            }
        } else {
            POISONED.store(true, Ordering::Relaxed);
        }
    } else {
        POISONED.store(true, Ordering::Relaxed);
    }
}
pub fn finish() -> Value {
    PHYSICAL.store(false, Ordering::Relaxed);
    let capture = CAPTURE.lock().ok().and_then(|mut slot| slot.take());
    if let Some(capture) = capture {
        if capture.spool.is_some() {
            return serde_json::json!({"schema":"snow_accuracy_observation_v2","counts_poisoned":true,"overflow":true,"error":"spooled capture requires finish_to_file"});
        }
        serde_json::json!({"schema":"snow_accuracy_observation_v2",
            "session":{"process":std::process::id(),"ordinal":1,"one_session_per_process":true},
            "physical_enabled":capture.physical,
            "counts": COUNTS.lock().ok().and_then(|mut slot|slot.take()),
            "physical":capture.rows,
            "overflow":capture.overflow || LEDGER_OVERFLOW.load(Ordering::Relaxed),
            "physical_ledgers":LEDGERS.lock().ok().map(|mut rows|std::mem::take(&mut *rows)),
            "counts_poisoned":POISONED.load(Ordering::Relaxed)})
    } else {
        serde_json::json!({"schema":"snow_accuracy_observation_v2","counts_poisoned":true,"overflow":true})
    }
}

#[test]
#[ignore = "one observation session requires an explicit fresh process"]
fn b01_cycle_observer_captures_joined_workers() {
    begin(true);
    std::thread::scope(|scope| {
        for lane in [1, 2] {
            scope.spawn(move || {
                assert!(physical_enabled());
                record(serde_json::json!({"kind":"worker_probe","lane":lane}));
                count("worker_probe");
            });
        }
    });
    let result = finish();
    assert_eq!(result["physical"].as_array().unwrap().len(), 2);
    assert_eq!(result["counts"]["worker_probe"], 2);
    assert_eq!(result["counts_poisoned"], false);
    assert_eq!(result["overflow"], false);
    begin(true);
    assert!(
        POISONED.load(Ordering::Relaxed),
        "a second session cannot relabel stale work"
    );
    assert!(!physical_enabled());
}

#[derive(Debug, thiserror::Error)]
pub enum ObservationWriteError {
    #[error("observation IO: {0}")]
    Io(#[from] std::io::Error),
    #[error("observation JSON: {0}")]
    Json(#[from] serde_json::Error),
    #[error("observation state: {0}")]
    State(&'static str),
}

/// Select bounded-memory physical recording before any worker starts.
pub fn begin_spooled(physical: bool, path: &std::path::Path) -> Result<(), ObservationWriteError> {
    begin(physical);
    if POISONED.load(Ordering::Relaxed) {
        return Err(ObservationWriteError::State("session start"));
    }
    if physical {
        let file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(path)?;
        let mut slot = CAPTURE
            .lock()
            .map_err(|_| ObservationWriteError::State("capture poisoned"))?;
        let capture = slot
            .as_mut()
            .ok_or(ObservationWriteError::State("capture absent"))?;
        capture.spool = Some((path.to_owned(), std::io::BufWriter::new(file)));
    }
    Ok(())
}

/// Write the same V2 records without materializing the complete physical array.
pub fn finish_to_file(path: &std::path::Path) -> Result<(), ObservationWriteError> {
    PHYSICAL.store(false, Ordering::Relaxed);
    let capture = CAPTURE
        .lock()
        .map_err(|_| ObservationWriteError::State("capture poisoned"))?
        .take()
        .ok_or(ObservationWriteError::State("capture absent"))?;
    let metadata = serde_json::json!({"schema":"snow_accuracy_observation_v2",
        "session":{"process":std::process::id(),"ordinal":1,"one_session_per_process":true},
        "physical_enabled":capture.physical,
        "counts":COUNTS.lock().map_err(|_| ObservationWriteError::State("counts poisoned"))?.take(),
        "overflow":capture.overflow || LEDGER_OVERFLOW.load(Ordering::Relaxed),
        "physical_ledgers":std::mem::take(&mut *LEDGERS.lock().map_err(|_| ObservationWriteError::State("ledgers poisoned"))?),
        "counts_poisoned":POISONED.load(Ordering::Relaxed)});
    let mut header = serde_json::to_vec(&metadata)?;
    if header.pop() != Some(b'}') {
        return Err(ObservationWriteError::State("metadata object"));
    }
    let file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    let mut output = std::io::BufWriter::new(file);
    output.write_all(&header)?;
    output.write_all(b",\"physical\":[")?;
    if let Some((spool_path, mut writer)) = capture.spool {
        writer.flush()?;
        drop(writer);
        let mut input = std::fs::File::open(spool_path)?;
        std::io::copy(&mut input, &mut output)?;
    } else {
        for (i, row) in capture.rows.iter().enumerate() {
            if i != 0 {
                output.write_all(b",")?;
            }
            serde_json::to_writer(&mut output, row)?;
        }
    }
    output.write_all(b"]}")?;
    output.flush()?;
    Ok(())
}

#[test]
#[ignore = "fresh process observer session"]
fn b01_spooled_observer_retains_worker_rows_and_ledgers() {
    let root = std::env::temp_dir().join(format!("b01_spooled_observer_{}", std::process::id()));
    std::fs::create_dir(&root).expect("unique test directory");
    begin_spooled(true, &root.join("rows.jsonpart")).expect("begin");
    std::thread::scope(|scope| {
        for lane in [1, 2] {
            scope.spawn(move || {
                record(serde_json::json!({"kind":"worker","lane":lane}));
                ledger(format!("lane-{lane}"), serde_json::json!({"lane":lane}));
                count("workers");
            });
        }
    });
    assert!(
        CAPTURE
            .lock()
            .expect("capture")
            .as_ref()
            .expect("session")
            .rows
            .is_empty()
    );
    finish_to_file(&root.join("observations.json")).expect("streamed finish");
    let value: Value =
        serde_json::from_slice(&std::fs::read(root.join("observations.json")).expect("bytes"))
            .expect("JSON");
    assert_eq!(value["physical"].as_array().expect("rows").len(), 2);
    assert_eq!(
        value["physical_ledgers"]
            .as_object()
            .expect("ledgers")
            .len(),
        2
    );
    assert_eq!(value["counts"]["workers"], 2);
    assert_eq!(value["overflow"], false);
    assert_eq!(value["counts_poisoned"], false);
    for (i, row) in value["physical"]
        .as_array()
        .expect("rows")
        .iter()
        .enumerate()
    {
        assert_eq!(row["capture"]["ordinal"], i);
    }
}
