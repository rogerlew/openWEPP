#[test]
fn terminal_liquid_canonicalizes_only_the_exact_one_ulp_phase_reference() {
    let reference = 273.15_f64;
    let next_up = f64::from_bits(reference.to_bits() + 1);
    let two_up = f64::from_bits(reference.to_bits() + 2);
    assert_eq!(
        canonical_stage3_terminal_liquid_temperature_k(reference).to_bits(),
        reference.to_bits()
    );
    assert_eq!(
        canonical_stage3_terminal_liquid_temperature_k(next_up).to_bits(),
        reference.to_bits()
    );
    assert_eq!(
        canonical_stage3_terminal_liquid_temperature_k(two_up).to_bits(),
        two_up.to_bits()
    );
    assert_eq!(
        canonical_stage3_terminal_liquid_temperature_k(f64::from_bits(reference.to_bits() - 1))
            .to_bits(),
        reference.to_bits() - 1
    );
}

#[test]
fn mixed_terminal_custody_temperature_does_not_replace_meltwater_phase_reference() {
    let routed_liquid_m = 1.00650874615698643e-2;
    let mixed_temperature_k = 273.16522205099076_f64;
    let temperature_mass = routed_liquid_m * mixed_temperature_k;

    let published = accepted_meltwater_phase_reference_c(routed_liquid_m, temperature_mass)
        .expect("valid mixed terminal custody")
        .expect("active routed-liquid phase reference");

    assert_eq!(published.as_celsius().to_bits(), 0.0_f64.to_bits());
    assert_eq!(
        (temperature_mass / routed_liquid_m).to_bits(),
        mixed_temperature_k.to_bits(),
        "publication must not mutate or discard the independently retained bulk custody temperature",
    );
}

#[test]
fn meltwater_phase_reference_rejects_omitted_or_substituted_custody_temperature() {
    let active = crate::constants::WB11_ZERO_THRESHOLD * 2_000.0;
    assert!(accepted_meltwater_phase_reference_c(active, 0.0).is_err());
    assert!(accepted_meltwater_phase_reference_c(active, f64::NAN).is_err());
    assert!(accepted_meltwater_phase_reference_c(active, active * 199.0).is_err());
    assert!(accepted_meltwater_phase_reference_c(active, active * 351.0).is_err());
    assert!(accepted_meltwater_phase_reference_c(0.0, 273.15).is_err());
}

#[test]
fn meltwater_phase_reference_preserves_wb11_activity_threshold() {
    let subthreshold = crate::constants::WB11_ZERO_THRESHOLD / 4.0;
    assert_eq!(
        accepted_meltwater_phase_reference_c(subthreshold, subthreshold * 273.16)
            .expect("valid subthreshold custody"),
        None,
    );

    let active = f64::from_bits(crate::constants::WB11_ZERO_THRESHOLD.to_bits() + 1);
    let published = accepted_meltwater_phase_reference_c(active, active * 273.16)
        .expect("valid active custody")
        .expect("active phase reference");
    assert_eq!(published.as_celsius().to_bits(), 0.0_f64.to_bits());
}

#[test]
fn wb11_outcome_threshold_does_not_alias_exact_subthreshold_receiver_custody() {
    let subthreshold = crate::constants::WB11_ZERO_THRESHOLD / 4.0;
    let solid = DirectSnowSolidToLiquidLedger {
        raw_signed_melt_m: subthreshold,
        redistributed_positive_melt_m: subthreshold,
        snowpack_swe_loss_m: subthreshold,
        rain_released_m: 0.0,
        liquid_handoff_m: subthreshold,
    };
    let disposition = DirectSnowLiquidDispositionLedger {
        incoming_liquid_m: subthreshold,
        routed_liquid_m: subthreshold,
        retained_liquid_delta_m: 0.0,
        refrozen_liquid_m: 0.0,
        liquid_closure_residual_m: 0.0,
    };
    DirectSnowMassTransitionLedgers::try_from_parts(
        solid,
        disposition,
        DirectSnowStage3Outcome {
            enabled: true,
            meltwater_temperature_c: None,
            sublimation_m: 0.0,
        },
    )
    .expect("exact subthreshold custody is inactive only on the WB11 outcome surface");

    let temperature = TemperatureCelsius::try_new(0.0).expect("freezing temperature");
    assert!(
        DirectSnowMassTransitionLedgers::try_from_parts(
            solid,
            disposition,
            DirectSnowStage3Outcome {
                enabled: true,
                meltwater_temperature_c: Some(temperature),
                sublimation_m: 0.0,
            },
        )
        .is_err(),
        "subthreshold receiver custody cannot be aliased to an active WB11 outcome",
    );

    let active = crate::constants::WB11_ZERO_THRESHOLD * 2_000.0;
    let active_solid = DirectSnowSolidToLiquidLedger {
        raw_signed_melt_m: active,
        redistributed_positive_melt_m: active,
        snowpack_swe_loss_m: active,
        rain_released_m: 0.0,
        liquid_handoff_m: active,
    };
    let active_disposition = DirectSnowLiquidDispositionLedger {
        incoming_liquid_m: active,
        routed_liquid_m: active,
        retained_liquid_delta_m: 0.0,
        refrozen_liquid_m: 0.0,
        liquid_closure_residual_m: 0.0,
    };
    assert!(
        DirectSnowMassTransitionLedgers::try_from_parts(
            active_solid,
            active_disposition,
            DirectSnowStage3Outcome {
                enabled: true,
                meltwater_temperature_c: None,
                sublimation_m: 0.0,
            },
        )
        .is_err(),
        "active routed liquid cannot omit its WB11 outcome temperature",
    );

    let mut double_count = active_disposition;
    double_count.routed_liquid_m *= 2.0;
    assert!(
        DirectSnowMassTransitionLedgers::try_from_parts(
            active_solid,
            double_count,
            DirectSnowStage3Outcome {
                enabled: true,
                meltwater_temperature_c: Some(temperature),
                sublimation_m: 0.0,
            },
        )
        .is_err(),
        "receiver custody cannot be counted twice",
    );
}

#[test]
fn support_liquid_publication_uses_exact_capacity_dispositions_and_rejects_poisons() {
    use crate::direct_runtime::{
        DirectZeroDurationSnowLiquidDispositionV1, DirectZeroDurationSnowLiquidInputV1,
    };
    use openwepp_coupled_time::{ModelTimeNs, TimeSupport};

    let configuration = crate::direct_runtime::surface_liquid_owner::tests::configuration();
    let beginning =
        crate::direct_runtime::surface_liquid_owner::tests::accepted_state(&configuration);
    let output_receipt_sha256 = [11; 32];
    let output_set_sha256 = [12; 32];
    let predecessor_owner_set_sha256 = [13; 32];
    let receiver_context_sha256 = [14; 32];
    let support =
        TimeSupport::new(ModelTimeNs::new(0), ModelTimeNs::new(60_000_000_000)).expect("support");
    let inputs = configuration
        .records
        .iter()
        .map(|record| DirectZeroDurationSnowLiquidInputV1 {
            output_receipt_sha256,
            output_set_sha256,
            predecessor_owner_set_sha256,
            receiver_context_sha256,
            support_start_ns: support.start_ns().get(),
            support_end_ns: support.end_ns().get(),
            receiver_ordinal: 0,
            ofe_id: record.key.ofe_id.clone(),
            tile_id: record.key.tile_id.clone(),
            tile_fraction: record.tile_fraction,
            // Beginning storage is 1 kg/m2 tile and capacity is 2, so this
            // exact input retains half and routes half to the outlet.
            mass_kg_m2_tile_ground: 2.0,
            sensible_enthalpy_j_m2_tile_ground: 200.0,
        })
        .collect::<Vec<_>>();
    let outcome = beginning
        .accept_zero_duration_snow_liquid_outputs_v1(&configuration, &inputs, false)
        .expect("capacity-limited receiver transaction");
    assert!(outcome.receipts.iter().any(|receipt| {
        receipt.disposition == DirectZeroDurationSnowLiquidDispositionV1::RetainedSurface
    }));
    assert!(outcome.receipts.iter().any(|receipt| {
        receipt.disposition == DirectZeroDurationSnowLiquidDispositionV1::OutletRunoff
    }));

    let mut accepted = AcceptedLaneDay::default();
    project_support_liquid_receipts_to_lane_day(
        &mut accepted,
        &outcome.receipts,
        Digest32::from_bytes(outcome.receipt_set_sha256),
        &configuration.ofe_bindings[0],
        &configuration,
        &beginning,
        &outcome.ending_state,
        0,
        support,
    )
    .expect("typed capacity dispositions publish");
    assert!((accepted.ingress_m - 0.002).abs() < 1.0e-15);
    assert!((accepted.retained_surface_liquid_m - 0.001).abs() < 1.0e-15);
    assert!((accepted.runoff_m - 0.001).abs() < 1.0e-15);
    assert_eq!(accepted.runon_m.to_bits(), 0.0_f64.to_bits());
    assert!((accepted.hourly_runoff_m.iter().sum::<f64>() - 0.001).abs() < 1.0e-15);

    let mut omission = outcome.receipts.clone();
    omission.pop();
    assert!(
        project_support_liquid_receipts_to_lane_day(
            &mut AcceptedLaneDay::default(),
            &omission,
            Digest32::from_bytes(outcome.receipt_set_sha256),
            &configuration.ofe_bindings[0],
            &configuration,
            &beginning,
            &outcome.ending_state,
            0,
            support,
        )
        .is_err(),
        "receipt omission must reject",
    );

    let mut order = outcome.receipts.clone();
    order.swap(0, 1);
    assert!(
        project_support_liquid_receipts_to_lane_day(
            &mut AcceptedLaneDay::default(),
            &order,
            Digest32::from_bytes(outcome.receipt_set_sha256),
            &configuration.ofe_bindings[0],
            &configuration,
            &beginning,
            &outcome.ending_state,
            0,
            support,
        )
        .is_err(),
        "receipt order substitution must reject",
    );

    let mut disposition = outcome.receipts.clone();
    disposition[0].disposition = DirectZeroDurationSnowLiquidDispositionV1::OutletRunoff;
    assert!(
        project_support_liquid_receipts_to_lane_day(
            &mut AcceptedLaneDay::default(),
            &disposition,
            Digest32::from_bytes(outcome.receipt_set_sha256),
            &configuration.ofe_bindings[0],
            &configuration,
            &beginning,
            &outcome.ending_state,
            0,
            support,
        )
        .is_err(),
        "disposition substitution must reject",
    );

    assert!(
        project_support_liquid_receipts_to_lane_day(
            &mut AcceptedLaneDay::default(),
            &outcome.receipts,
            Digest32::from_bytes([99; 32]),
            &configuration.ofe_bindings[0],
            &configuration,
            &beginning,
            &outcome.ending_state,
            0,
            support,
        )
        .is_err(),
        "receipt-set substitution must reject",
    );

    assert!(
        project_support_liquid_receipts_to_lane_day(
            &mut AcceptedLaneDay::default(),
            &outcome.receipts,
            Digest32::from_bytes(outcome.receipt_set_sha256),
            &configuration.ofe_bindings[0],
            &configuration,
            &beginning,
            &beginning,
            0,
            support,
        )
        .is_err(),
        "ending surface substitution must reject",
    );
}

#[test]
fn support_liquid_publication_routes_source_runoff_and_destination_runon_once() {
    use crate::direct_runtime::{
        DirectGroundIngressMode, DirectSurfaceLiquidConfiguration,
        DirectSurfaceLiquidConfigurationRecord, DirectSurfaceLiquidOfeBinding,
        DirectSurfaceLiquidStoreKey, DirectZeroDurationSnowLiquidDispositionV1,
        DirectZeroDurationSnowLiquidInputV1,
    };
    use openwepp_coupled_time::{ModelTimeNs, TimeSupport};
    use openwepp_kernel_contract::{ResourceOwnerId, SoilLayerId, TileId};
    use openwepp_land_surface_energy::{SourceId, SurfaceId};

    let make_binding = |name: &str, lane_index: usize| {
        let top = SoilLayerId::try_new(format!("{name}-top")).expect("soil layer");
        DirectSurfaceLiquidOfeBinding {
            ofe_id: OfeId::try_new(name).expect("OFE"),
            production_lane_index: lane_index,
            production_lane_id: u32::try_from(lane_index + 1).expect("lane"),
            ordered_soil_layer_ids: vec![
                top.clone(),
                SoilLayerId::try_new(format!("{name}-bottom")).expect("soil layer"),
            ],
            infiltration_soil_thermal_layer_id: top,
        }
    };
    let make_record = |name: &str, area: f64, capacity: f64, route: Option<(&str, &str)>| {
        DirectSurfaceLiquidConfigurationRecord {
            key: DirectSurfaceLiquidStoreKey {
                run_id: 72,
                ofe_id: OfeId::try_new(name).expect("OFE"),
                tile_id: TileId::try_new(format!("{name}-tile")).expect("tile"),
                surface_id: SurfaceId::try_new(format!("{name}-surface")).expect("surface"),
                surface_class: SurfaceClass::BareMineralSoil,
                source_type: WaterSourceType::SurfaceLiquid,
                source_id: SourceId::try_new(format!("{name}-source")).expect("source"),
            },
            tile_fraction: 1.0,
            capacity_kg_m2_tile: capacity,
            ofe_area_m2: area,
            ground_ingress_mode: DirectGroundIngressMode::OpenRawPrecipitation,
            runon_destination_ofe_id: route.map(|(ofe, _)| OfeId::try_new(ofe).expect("route OFE")),
            runon_destination_tile_id: route
                .map(|(_, tile)| TileId::try_new(tile).expect("route tile")),
        }
    };
    let configuration = DirectSurfaceLiquidConfiguration::new(
        ResourceOwnerId::try_new("hydrology").expect("owner"),
        72,
        vec![
            OfeId::try_new("upper").expect("OFE"),
            OfeId::try_new("lower").expect("OFE"),
        ],
        vec![make_binding("upper", 0), make_binding("lower", 1)],
        vec![
            make_record("upper", 100.0, 1.0, Some(("lower", "lower-tile"))),
            make_record("lower", 200.0, 10.0, None),
        ],
    )
    .expect("routed configuration");
    let upper = &configuration.ofe_bindings[0];
    let lower = &configuration.ofe_bindings[1];
    let initial = configuration
        .records
        .iter()
        .map(|record| {
            let liquid = if record.key.ofe_id == upper.ofe_id {
                record.capacity_kg_m2_tile
            } else {
                0.0
            };
            (record.key.clone(), liquid)
        })
        .collect::<BTreeMap<_, _>>();
    let beginning = DirectSurfaceLiquidOwnedState::new_initial(&configuration, &initial, 0)
        .expect("capacity-pressure routed beginning");
    let support =
        TimeSupport::new(ModelTimeNs::new(0), ModelTimeNs::new(60_000_000_000)).expect("support");
    let inputs = configuration
        .records
        .iter()
        .filter(|record| record.key.ofe_id == upper.ofe_id)
        .map(|record| DirectZeroDurationSnowLiquidInputV1 {
            output_receipt_sha256: [21; 32],
            output_set_sha256: [22; 32],
            predecessor_owner_set_sha256: [23; 32],
            receiver_context_sha256: [24; 32],
            support_start_ns: support.start_ns().get(),
            support_end_ns: support.end_ns().get(),
            receiver_ordinal: 0,
            ofe_id: record.key.ofe_id.clone(),
            tile_id: record.key.tile_id.clone(),
            tile_fraction: record.tile_fraction,
            mass_kg_m2_tile_ground: 1.0,
            sensible_enthalpy_j_m2_tile_ground: 100.0,
        })
        .collect::<Vec<_>>();
    let outcome = beginning
        .accept_zero_duration_snow_liquid_outputs_v1(&configuration, &inputs, false)
        .expect("routed receiver transaction");
    assert!(outcome.receipts.iter().any(|receipt| {
        receipt.basis_ofe_id == upper.ofe_id
            && receipt.disposition == DirectZeroDurationSnowLiquidDispositionV1::RoutedRunoff
    }));
    assert!(outcome.receipts.iter().any(|receipt| {
        receipt.basis_ofe_id == lower.ofe_id
            && receipt.origin_ofe_id == upper.ofe_id
            && matches!(
                receipt.disposition,
                DirectZeroDurationSnowLiquidDispositionV1::RetainedSurface
                    | DirectZeroDurationSnowLiquidDispositionV1::OutletRunoff
            )
    }));

    let receipt_set = Digest32::from_bytes(outcome.receipt_set_sha256);
    let mut upper_day = AcceptedLaneDay::default();
    project_support_liquid_receipts_to_lane_day(
        &mut upper_day,
        &outcome.receipts,
        receipt_set,
        upper,
        &configuration,
        &beginning,
        &outcome.ending_state,
        0,
        support,
    )
    .expect("upper routed publication");
    assert!((upper_day.ingress_m - 0.001).abs() < 1.0e-15);
    assert!((upper_day.runoff_m - 0.001).abs() < 1.0e-15);
    assert_eq!(upper_day.runon_m.to_bits(), 0.0_f64.to_bits());

    let mut lower_day = AcceptedLaneDay::default();
    project_support_liquid_receipts_to_lane_day(
        &mut lower_day,
        &outcome.receipts,
        receipt_set,
        lower,
        &configuration,
        &beginning,
        &outcome.ending_state,
        0,
        support,
    )
    .expect("lower routed publication");
    // The routed fixture has a 100/200 m2 upper/lower area ratio.
    assert!((lower_day.ingress_m - 0.0005).abs() < 1.0e-15);
    assert!((lower_day.runon_m - 0.0005).abs() < 1.0e-15);
    assert!((lower_day.support_liquid_runon_m - 0.0005).abs() < 1.0e-15);
    assert!(
        (lower_day.retained_surface_liquid_m + lower_day.runoff_m - lower_day.ingress_m).abs()
            < 1.0e-15
    );

    let source_enthalpy = outcome
        .receipts
        .iter()
        .filter(|receipt| {
            receipt.basis_ofe_id == upper.ofe_id
                && receipt.disposition == DirectZeroDurationSnowLiquidDispositionV1::RoutedRunoff
        })
        .map(|receipt| receipt.sensible_enthalpy_j_m2_basis_ofe_ground)
        .sum::<f64>();
    let destination_enthalpy = outcome
        .receipts
        .iter()
        .filter(|receipt| receipt.basis_ofe_id == lower.ofe_id)
        .map(|receipt| receipt.sensible_enthalpy_j_m2_basis_ofe_ground)
        .sum::<f64>();
    assert!((destination_enthalpy - source_enthalpy * 0.5).abs() < 1.0e-12);

    let mut enthalpy_substitution = outcome.receipts.clone();
    enthalpy_substitution
        .iter_mut()
        .find(|receipt| receipt.basis_ofe_id == lower.ofe_id)
        .expect("destination receipt")
        .sensible_enthalpy_j_m2_basis_ofe_ground += 1.0;
    assert!(
        project_support_liquid_receipts_to_lane_day(
            &mut AcceptedLaneDay::default(),
            &enthalpy_substitution,
            receipt_set,
            lower,
            &configuration,
            &beginning,
            &outcome.ending_state,
            0,
            support,
        )
        .is_err(),
        "destination enthalpy substitution must reject",
    );
}

#[test]
fn accepted_runon_receipts_close_destination_basis_and_reject_adjacent_aliases() {
    use crate::direct_runtime::{
        DirectGroundIngressMode, DirectSurfaceLiquidConfiguration,
        DirectSurfaceLiquidConfigurationRecord, DirectSurfaceLiquidOfeBinding,
        DirectSurfaceLiquidParcelKind, DirectSurfaceLiquidParcelReceipt,
        DirectSurfaceLiquidReceiptDisposition, DirectSurfaceLiquidReceiptRecipient,
        DirectSurfaceLiquidStoreKey,
    };
    use openwepp_kernel_contract::{ResourceOwnerId, SoilLayerId, TileId, TransactionId};
    use openwepp_land_surface_energy::{SourceId, SurfaceId};

    let upstream_ofe = OfeId::try_new("upstream").expect("upstream OFE");
    let destination_ofe = OfeId::try_new("destination").expect("destination OFE");
    let upstream_tile = TileId::try_new("upstream-tile").expect("upstream tile");
    let destination_tile = TileId::try_new("destination-tile").expect("destination tile");
    let upstream_top = SoilLayerId::try_new("upstream-top").expect("upstream top layer");
    let destination_top = SoilLayerId::try_new("destination-top").expect("destination top layer");
    let store_key = |ofe_id: OfeId, tile_id: TileId, label: &str| DirectSurfaceLiquidStoreKey {
        run_id: 77,
        ofe_id,
        tile_id,
        surface_id: SurfaceId::try_new(format!("{label}-surface")).expect("surface"),
        surface_class: SurfaceClass::BareMineralSoil,
        source_type: WaterSourceType::SurfaceLiquid,
        source_id: SourceId::try_new(format!("{label}-source")).expect("source"),
    };
    let upstream_key = store_key(upstream_ofe.clone(), upstream_tile, "upstream");
    let destination_key = store_key(
        destination_ofe.clone(),
        destination_tile.clone(),
        "destination",
    );
    let configuration = DirectSurfaceLiquidConfiguration::new(
        ResourceOwnerId::try_new("hydrology").expect("owner"),
        77,
        vec![upstream_ofe.clone(), destination_ofe.clone()],
        vec![
            DirectSurfaceLiquidOfeBinding {
                ofe_id: upstream_ofe.clone(),
                production_lane_index: 0,
                production_lane_id: 1,
                ordered_soil_layer_ids: vec![upstream_top.clone()],
                infiltration_soil_thermal_layer_id: upstream_top,
            },
            DirectSurfaceLiquidOfeBinding {
                ofe_id: destination_ofe.clone(),
                production_lane_index: 1,
                production_lane_id: 2,
                ordered_soil_layer_ids: vec![destination_top.clone()],
                infiltration_soil_thermal_layer_id: destination_top,
            },
        ],
        vec![
            DirectSurfaceLiquidConfigurationRecord {
                key: upstream_key.clone(),
                tile_fraction: 1.0,
                capacity_kg_m2_tile: 4.0,
                ofe_area_m2: 100.0,
                ground_ingress_mode: DirectGroundIngressMode::OpenRawPrecipitation,
                runon_destination_ofe_id: Some(destination_ofe.clone()),
                runon_destination_tile_id: Some(destination_tile),
            },
            DirectSurfaceLiquidConfigurationRecord {
                key: destination_key.clone(),
                tile_fraction: 1.0,
                capacity_kg_m2_tile: 4.0,
                ofe_area_m2: 200.0,
                ground_ingress_mode: DirectGroundIngressMode::OpenRawPrecipitation,
                runon_destination_ofe_id: None,
                runon_destination_tile_id: None,
            },
        ],
    )
    .expect("destination configuration");
    let receipt =
        |kind,
         disposition,
         id: &str,
         source_id: &str,
         basis_ofe_id: OfeId,
         origin_store_key: DirectSurfaceLiquidStoreKey,
         recipient: DirectSurfaceLiquidReceiptRecipient,
         mass_kg_m2_basis_ofe_ground| DirectSurfaceLiquidParcelReceipt {
            parcel_id: id.to_owned(),
            source_parcel_id: source_id.to_owned(),
            transaction_id: TransactionId(77),
            origin_store_key,
            recipient_store_key: destination_key.clone(),
            recipient,
            basis_ofe_id,
            kind,
            disposition,
            start_s: 0.0,
            end_s: 60.0,
            mass_kg_m2_basis_ofe_ground,
            temperature_k: 280.0,
            enthalpy_j_m2_basis_ofe_ground: mass_kg_m2_basis_ofe_ground * 28_623.16,
        };
    let receipts = vec![
        receipt(
            DirectSurfaceLiquidParcelKind::RawPrecipitation,
            DirectSurfaceLiquidReceiptDisposition::RoutedRunoff,
            "accepted-sent",
            "accepted-route-source",
            upstream_ofe.clone(),
            upstream_key,
            DirectSurfaceLiquidReceiptRecipient::RoutedOfe {
                source_ofe_id: upstream_ofe,
                destination_ofe_id: destination_ofe.clone(),
                destination_store_key: destination_key.clone(),
            },
            4.0,
        ),
        receipt(
            DirectSurfaceLiquidParcelKind::UpstreamRunon,
            DirectSurfaceLiquidReceiptDisposition::RetainedSurface,
            "accepted-received",
            "accepted-route-source",
            destination_ofe.clone(),
            destination_key.clone(),
            DirectSurfaceLiquidReceiptRecipient::SurfaceStore {
                store_key: destination_key.clone(),
            },
            2.0,
        ),
        receipt(
            DirectSurfaceLiquidParcelKind::RawPrecipitation,
            DirectSurfaceLiquidReceiptDisposition::RetainedSurface,
            "accepted-local",
            "accepted-local-source",
            destination_ofe.clone(),
            destination_key.clone(),
            DirectSurfaceLiquidReceiptRecipient::SurfaceStore {
                store_key: destination_key.clone(),
            },
            3.0,
        ),
    ];
    let projection = accepted_runon_receipt_components(&receipts, &destination_ofe, &configuration)
        .expect("sealed accepted source projection");

    assert!((projection.local_liquid_m - 0.003).abs() < 1.0e-15);
    assert!((projection.upstream_runon_m - 0.002).abs() < 1.0e-15);
    assert!((projection.sent_volume_m3 - 0.4).abs() < 1.0e-15);
    assert!((projection.sent_volume_m3 - projection.received_volume_m3).abs() < 1.0e-15,);
    assert_ne!(
        projection.upstream_runon_m.to_bits(),
        (projection.local_liquid_m + projection.upstream_runon_m).to_bits(),
        "total accepted ingress must not be mislabeled UpStrmQ",
    );
    assert_ne!(
        projection.upstream_runon_m.to_bits(),
        projection.local_liquid_m.to_bits(),
        "local liquid must not substitute for accepted UpStrmQ",
    );
}

#[test]
fn accepted_wat5_hyetograph_preserves_overlapping_segment_shape_and_magnitude() {
    let segments = [
        AcceptedWat5RainSegmentV1 {
            start_s: 0.0,
            end_s: 600.0,
            depth_m: 0.003,
        },
        AcceptedWat5RainSegmentV1 {
            start_s: 300.0,
            end_s: 600.0,
            depth_m: 0.001,
        },
    ];
    let hyetograph =
        accepted_wat5_piecewise_hyetograph(&segments).expect("accepted WAT5 source shape");
    assert_eq!(hyetograph.len(), 2);
    assert!(hyetograph[1].intensity_m_s > hyetograph[0].intensity_m_s);
    let reconstructed_m = hyetograph
        .iter()
        .map(|interval| interval.intensity_m_s * (interval.end_s - interval.start_s))
        .sum::<f64>();
    assert!((reconstructed_m - 0.004).abs() < 1.0e-15);
    assert_ne!(
        hyetograph[0].intensity_m_s.to_bits(),
        (0.004_f64 / 600.0).to_bits(),
        "uniform daily-depth timing is a rejected WAT5 alias",
    );
}

fn accepted_wat5_test_receipt_source(
    kind: DirectSurfaceLiquidParcelKind,
    receipt_byte: u8,
    depth_m: f64,
    infiltration_m: f64,
    retained_surface_m: f64,
    runoff_m: f64,
) -> AcceptedWat5ReceiptSourceV1 {
    AcceptedWat5ReceiptSourceV1 {
        support_receipt_sha256: Digest32::from_bytes([receipt_byte; 32]),
        kind: AcceptedWat5ReceiptSourceKindV1::Ordinary(kind),
        source_parcel_id: format!("wat5-v5-source-{receipt_byte}"),
        transaction_id: openwepp_kernel_contract::TransactionId(u128::from(receipt_byte)),
        start_s: 0.0,
        end_s: 300.0,
        depth_m,
        infiltration_m,
        retained_surface_m,
        runoff_m,
    }
}

#[test]
fn accepted_wat5_receipt_profile_preserves_source_and_disposition_ledgers_without_second_solve() {
    let ofe_id = wat5_segment_test_ofe();
    let sources = vec![
        accepted_wat5_test_receipt_source(
            DirectSurfaceLiquidParcelKind::RawPrecipitation,
            1,
            0.002,
            0.001,
            0.000_5,
            0.000_5,
        ),
        accepted_wat5_test_receipt_source(
            DirectSurfaceLiquidParcelKind::CondensationOverflow,
            2,
            0.001,
            0.000_25,
            0.000_25,
            0.000_5,
        ),
    ];
    let hyetograph = accepted_wat5_hyetograph(&sources).expect("accepted precipitation lineage");
    let segments = accepted_wat5_additional_supply_segments(&sources, &ofe_id)
        .expect("accepted non-rain lineage");
    let inputs = wat5_test_producer(hyetograph, &segments);
    let profile = accepted_wat5_receipt_profile(&inputs, &segments, &sources, &ofe_id)
        .expect("sealed receipt disposition profile");

    assert!((profile.rainfall_m.iter().sum::<f64>() - 0.002).abs() < 1.0e-15);
    assert!((profile.additional_supply_m.iter().sum::<f64>() - 0.001).abs() < 1.0e-15);
    assert!((profile.infiltration_m.iter().sum::<f64>() - 0.001_25).abs() < 1.0e-15);
    assert!(
        (profile.depression_storage_retention_m.iter().sum::<f64>() - 0.000_75).abs()
            < 1.0e-15
    );
    assert!((profile.post_depression_excess_m.iter().sum::<f64>() - 0.001).abs() < 1.0e-15);
    assert_eq!(profile.depression_storage_delta_m.to_bits(), 0.000_75_f64.to_bits());
}

#[test]
fn accepted_wat5_receipt_profile_rejects_source_disposition_omission_or_duplication() {
    let ofe_id = wat5_segment_test_ofe();
    let mut sources = vec![accepted_wat5_test_receipt_source(
        DirectSurfaceLiquidParcelKind::RawPrecipitation,
        3,
        0.002,
        0.001,
        0.000_5,
        0.000_5,
    )];
    let hyetograph = accepted_wat5_hyetograph(&sources).expect("accepted precipitation lineage");
    let segments = accepted_wat5_additional_supply_segments(&sources, &ofe_id)
        .expect("empty accepted non-rain lineage");
    let inputs = wat5_test_producer(hyetograph, &segments);

    sources[0].runoff_m += 1.0e-6;
    assert!(
        accepted_wat5_receipt_profile(&inputs, &segments, &sources, &ofe_id).is_err(),
        "a duplicated disposition must not create source mass",
    );
    sources[0].runoff_m -= 2.0e-6;
    assert!(
        accepted_wat5_receipt_profile(&inputs, &segments, &sources, &ofe_id).is_err(),
        "an omitted disposition must not disappear source mass",
    );
}

fn wat5_segment_test_ofe() -> OfeId {
    OfeId::try_new("wat5-test-ofe").expect("WAT5 test OFE")
}

fn wat5_test_segment(
    source_kind: runoff::Wat5AdditionalSupplySourceKindV1,
    receipt_digit: char,
    start_s: f64,
    end_s: f64,
    depth_m_ofe_ground: f64,
) -> runoff::Wat5AdditionalSupplySegmentV1 {
    let source_identity = format!("accepted-source-{receipt_digit}");
    let transaction_id = format!("transaction-{receipt_digit}");
    let destination_ofe_id = wat5_segment_test_ofe();
    let source_receipt_sha256 = runoff::wat5_additional_supply_source_receipt_sha256(
        source_kind,
        &source_identity,
        &transaction_id,
        &destination_ofe_id,
        start_s,
        end_s,
        depth_m_ofe_ground,
    )
    .expect("exact WAT5 source receipt");
    runoff::Wat5AdditionalSupplySegmentV1 {
        source_kind,
        source_identity,
        source_receipt_sha256,
        transaction_id,
        destination_ofe_id,
        start_s,
        end_s,
        depth_m_ofe_ground,
    }
}

fn wat5_test_producer(
    hyetograph: Vec<DirectWb14HyetographInterval>,
    segments: &[runoff::Wat5AdditionalSupplySegmentV1],
) -> DirectWb14InfiltrationProducerInputs {
    DirectWb14InfiltrationProducerInputs {
        hyetograph,
        hourly_additional_supply_m: runoff::wat5_hourly_additional_supply_from_segments(
            segments,
            Some(&wat5_segment_test_ofe()),
        )
        .expect("exact WAT5 hourly source"),
        effective_conductivity_m_s: 1.0e-8,
        matric_potential_m: 0.1,
        storage_capacity_m: 1.0,
        depression_storage_capacity_m: 0.0,
    }
}

#[test]
fn wat5_exact_segments_keep_rain_and_snow_terminal_distinct() {
    let snow = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::SnowTerminalReceiver,
        'a',
        150.0,
        450.0,
        0.003,
    );
    let inputs = wat5_test_producer(
        vec![DirectWb14HyetographInterval {
            start_s: 0.0,
            end_s: 300.0,
            intensity_m_s: 1.0e-5,
        }],
        std::slice::from_ref(&snow),
    );
    let profile = runoff::compute_wb14_subhourly_profile_with_exact_segments(
        &inputs,
        &[snow],
        Some(&wat5_segment_test_ofe()),
    )
    .expect("rain plus exact snow-terminal replay");

    assert_eq!(profile.rainfall_m[0].to_bits(), 0.003_f64.to_bits());
    assert_eq!(
        profile.additional_supply_m.iter().sum::<f64>().to_bits(),
        0.003_f64.to_bits()
    );
    assert!(profile.additional_supply_m[0] > 0.0);
    assert!(profile.additional_supply_m[1] > 0.0);
}

#[test]
fn wat5_exact_segments_preserve_routed_runon_receipt_support() {
    let runon = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::RoutedRunon,
        'b',
        3_500.0,
        3_700.0,
        0.002,
    );
    let inputs = wat5_test_producer(
        vec![DirectWb14HyetographInterval {
            start_s: 0.0,
            end_s: 0.0,
            intensity_m_s: 0.0,
        }],
        std::slice::from_ref(&runon),
    );
    let profile = runoff::compute_wb14_subhourly_profile_with_exact_segments(
        &inputs,
        &[runon],
        Some(&wat5_segment_test_ofe()),
    )
    .expect("exact routed-runon support");

    assert_eq!(
        profile.additional_supply_m[11].to_bits(),
        0.001_f64.to_bits()
    );
    assert_eq!(
        profile.additional_supply_m[12].to_bits(),
        0.001_f64.to_bits()
    );
    assert!(profile.rainfall_m.iter().all(|depth_m| *depth_m == 0.0));
}

#[test]
fn wat5_exact_segments_preserve_litter_overflow_phase_receipt_support() {
    let litter = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::LitterPhaseOverflow,
        'c',
        290.0,
        310.0,
        0.001,
    );
    let inputs = wat5_test_producer(
        vec![DirectWb14HyetographInterval {
            start_s: 0.0,
            end_s: 0.0,
            intensity_m_s: 0.0,
        }],
        std::slice::from_ref(&litter),
    );
    let profile = runoff::compute_wb14_subhourly_profile_with_exact_segments(
        &inputs,
        &[litter],
        Some(&wat5_segment_test_ofe()),
    )
    .expect("phase-receipt-bound litter overflow");

    assert_eq!(
        profile.additional_supply_m[0].to_bits(),
        0.0005_f64.to_bits()
    );
    assert_eq!(
        profile.additional_supply_m[1].to_bits(),
        0.0005_f64.to_bits()
    );
}

#[test]
fn wat5_overlapping_sources_advance_piecewise_wb14_once() {
    let snow = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::SnowTerminalReceiver,
        'd',
        100.0,
        500.0,
        0.004,
    );
    let runon = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::RoutedRunon,
        'e',
        250.0,
        650.0,
        0.002,
    );
    let segments = vec![runon, snow];
    let inputs = wat5_test_producer(
        vec![DirectWb14HyetographInterval {
            start_s: 0.0,
            end_s: 600.0,
            intensity_m_s: 1.0e-5,
        }],
        &segments,
    );
    let profile = runoff::compute_wb14_subhourly_profile_with_exact_segments(
        &inputs,
        &segments,
        Some(&wat5_segment_test_ofe()),
    )
    .expect("one combined piecewise WB14 replay");
    let supplied_m =
        profile.rainfall_m.iter().sum::<f64>() + profile.additional_supply_m.iter().sum::<f64>();
    let partitioned_m = profile.infiltration_m.iter().sum::<f64>()
        + profile.depression_storage_retention_m.iter().sum::<f64>()
        + profile.post_depression_excess_m.iter().sum::<f64>();

    assert!((supplied_m - 0.012).abs() <= 1.0e-15);
    assert!((supplied_m - partitioned_m).abs() <= 1.0e-12);
}

#[test]
fn wat5_exact_segments_reconstruct_hourly_additional_supply_without_double_count() {
    let snow = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::SnowTerminalReceiver,
        'f',
        0.0,
        3_600.0,
        0.003,
    );
    let runon = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::RoutedRunon,
        '1',
        3_600.0,
        7_200.0,
        0.002,
    );
    let segments = vec![runon, snow];
    let hourly = runoff::wat5_hourly_additional_supply_from_segments(
        &segments,
        Some(&wat5_segment_test_ofe()),
    )
    .expect("canonical exact hourly reconstruction");

    assert_eq!(hourly[0].to_bits(), 0.003_f64.to_bits());
    assert_eq!(hourly[1].to_bits(), 0.002_f64.to_bits());
    assert_eq!(hourly.iter().sum::<f64>().to_bits(), 0.005_f64.to_bits());
    let mut aggregate_only = wat5_test_producer(
        vec![DirectWb14HyetographInterval {
            start_s: 0.0,
            end_s: 0.0,
            intensity_m_s: 0.0,
        }],
        &segments,
    );
    aggregate_only.hourly_additional_supply_m = hourly;
    assert!(
        runoff::compute_wb14_subhourly_profile_with_exact_segments(
            &aggregate_only,
            &[],
            Some(&wat5_segment_test_ofe()),
        )
        .is_err()
    );
}

#[test]
fn wat5_exact_segments_reject_unknown_retimed_or_substituted_source() {
    let segment = wat5_test_segment(
        runoff::Wat5AdditionalSupplySourceKindV1::LitterPhaseOverflow,
        '2',
        100.0,
        400.0,
        0.001,
    );
    let inputs = wat5_test_producer(
        vec![DirectWb14HyetographInterval {
            start_s: 0.0,
            end_s: 0.0,
            intensity_m_s: 0.0,
        }],
        std::slice::from_ref(&segment),
    );

    let mut retimed = segment.clone();
    retimed.start_s = 101.0;
    assert!(
        runoff::compute_wb14_subhourly_profile_with_exact_segments(
            &inputs,
            &[retimed],
            Some(&wat5_segment_test_ofe()),
        )
        .is_err()
    );
    let mut substituted = segment.clone();
    substituted.source_receipt_sha256 = "not-a-receipt".to_owned();
    assert!(
        runoff::compute_wb14_subhourly_profile_with_exact_segments(
            &inputs,
            &[substituted],
            Some(&wat5_segment_test_ofe()),
        )
        .is_err()
    );
    let foreign = OfeId::try_new("foreign-ofe").expect("foreign OFE");
    assert!(
        runoff::compute_wb14_subhourly_profile_with_exact_segments(
            &inputs,
            &[segment],
            Some(&foreign),
        )
        .is_err()
    );
}


#[test]
fn native_wat5_source_dispositions_are_not_a_closing_residual() {
    let ofe_id = wat5_segment_test_ofe();
    let mut source = accepted_wat5_test_receipt_source(DirectSurfaceLiquidParcelKind::CondensationOverflow,
        19, 0.006, 0.0, 0.001, 0.005);
    source.kind = AcceptedWat5ReceiptSourceKindV1::NativeSnowDrain;
    source.start_s = 3_570.0;
    source.end_s = 3_630.0;
    let sources = vec![source];
    let segments = accepted_wat5_additional_supply_segments(&sources, &ofe_id).unwrap();
    assert_eq!(segments[0].source_kind, runoff::Wat5AdditionalSupplySourceKindV1::NativeSnowDrain);
    let inputs = wat5_test_producer(accepted_wat5_hyetograph(&sources).unwrap(), &segments);
    let full = accepted_wat5_receipt_profile(&inputs, &segments, &sources, &ofe_id).unwrap();
    assert_eq!(full.rainfall_m.iter().sum::<f64>(), 0.0);
    assert_eq!(full.infiltration_m.iter().sum::<f64>(), 0.0);
    for bin in [11,12] {
        assert_eq!(full.additional_supply_m[bin], 0.003);
        assert_eq!(full.depression_storage_retention_m[bin], 0.0005);
        assert_eq!(full.post_depression_excess_m[bin], 0.0025);
    }
    let empty = wat5_test_producer(accepted_wat5_hyetograph(&[]).unwrap(), &[]);
    let omitted = accepted_wat5_receipt_profile(&empty, &[], &[], &ofe_id).unwrap();
    assert_eq!(omitted.post_depression_excess_m.iter().sum::<f64>(), 0.0);
    assert_eq!(full.post_depression_excess_m.iter().sum::<f64>(), 0.005);
}
