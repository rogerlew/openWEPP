/// Exact selected position of a private native restart candidate.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeSoilRestartPositionV1 {
    Committed, PendingCandidate, InProgressDayCandidate, InProgressSupportCurrent,
}

/// Process-local proof; private fields and no serde/Clone construction path.
/// It is borrowed only across one private position restoration, never retained by a host.
pub struct NativeSoilRestartAdmissionV1 {
    inactive_scheduler: Option<NativeInactiveSchedulerCustodyV1>,
    resident: Vec<u8>,
    clock: openwepp_coupled_time::CoupledClockStateV1,
    position: NativeSoilRestartPositionV1,
    logical_revision: u128,
    next_day: usize,
    run_id: u64,
    lse_configuration_sha256: openwepp_land_surface_energy::Sha256Digest,
}

impl NativeSoilRestartAdmissionV1 {
    #[allow(clippy::too_many_arguments)]
    pub fn authenticate(
        resident: &DirectV10SoilThermalResidentV2,
        bootstrap: &DirectV10SoilThermalResidentV2,
        lse_configuration: &LandSurfaceEnergyConfiguration,
        expected_owner: &ResourceOwnerId,
        expected_configuration: &openwepp_land_surface_energy::Sha256Digest,
        expected_soil_run_id: &str,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        position: NativeSoilRestartPositionV1,
        logical_revision: u128,
        next_day: usize,
        run_id: u64,
    ) -> Result<Self, DirectV9RealConsumerError> {
        if openwepp_land_surface_energy::snow_accuracy_policy::Policy::current().identity()
            != Some(14)
        {
            return Err(DirectV9RealConsumerError::Identity(
                "native soil proof policy",
            ));
        }
        resident.diagnostic_validate_against_authority_v1(
            lse_configuration,
            expected_owner,
            expected_configuration,
        )?;
        bootstrap.diagnostic_validate_against_authority_v1(
            lse_configuration,
            expected_owner,
            expected_configuration,
        )?;
        let actual =
            DirectSoilThermalResident::V2(resident.clone()).canonical_active_owner_bytes()?;
        let mut views = clock
            .owners()
            .iter()
            .filter(|owner| owner.owner_id() == "soil_thermal");
        let view = views.next().ok_or(DirectV9RealConsumerError::Identity(
            "native soil proof missing clock owner",
        ))?;
        if views.next().is_some() || view.state_bytes() != actual {
            return Err(DirectV9RealConsumerError::Identity(
                "native soil proof exact unique clock owner",
            ));
        }
        let owner = resident.owner();
        if owner.run_id != expected_soil_run_id || bootstrap.owner().run_id != expected_soil_run_id
        {
            return Err(DirectV9RealConsumerError::Identity(
                "native soil proof independent run identity",
            ));
        }
        let initial = clock.accepted_until().get() == 0
            && next_day == 0
            && owner.support_start_ns == 0
            && resident.latest_accepted().is_none()
            && resident.receipt_free_seals().is_some()
            && bootstrap.latest_accepted().is_none()
            && bootstrap.receipt_free_seals().is_some()
            && serde_json::to_vec(resident)
                .map_err(|error| DirectV9RealConsumerError::Serialization(error.to_string()))?
                == serde_json::to_vec(bootstrap)
                    .map_err(|error| DirectV9RealConsumerError::Serialization(error.to_string()))?;
        if !initial
            && (resident.latest_accepted().is_none()
                || owner.support_end_ns != clock.accepted_until().get())
        {
            return Err(DirectV9RealConsumerError::Identity(
                "native soil proof accepted support or exact bootstrap",
            ));
        }
        Ok(Self {
            inactive_scheduler: None,
            resident: actual,
            clock: clock.clone(),
            position,
            logical_revision,
            next_day,
            run_id,
            lse_configuration_sha256: lse_configuration.configuration_sha256.clone(),
        })
    }

    /// Minted only by the complete deferred-context diagnostic admission.  The
    /// ordinary admission above remains the sole route for an already-accepted
    /// resident; this route deliberately retains the original resident while
    /// its separately authenticated unpublished successor stays deferred.
    #[cfg(all(test, feature = "persisted-restart-v1"))]
    #[allow(clippy::too_many_arguments)]
    fn authenticate_deferred_original_v1(
        resident: &DirectV10SoilThermalResidentV2,
        bootstrap: &DirectV10SoilThermalResidentV2,
        lse_configuration: &LandSurfaceEnergyConfiguration,
        expected_owner: &ResourceOwnerId,
        expected_configuration: &openwepp_land_surface_energy::Sha256Digest,
        expected_soil_run_id: &str,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        position: NativeSoilRestartPositionV1,
        logical_revision: u128,
        next_day: usize,
        run_id: u64,
    ) -> Result<Self, DirectV9RealConsumerError> {
        if openwepp_land_surface_energy::snow_accuracy_policy::Policy::current().identity()
            != Some(14)
        {
            return Err(DirectV9RealConsumerError::Identity(
                "native deferred proof policy",
            ));
        }
        resident.diagnostic_validate_against_authority_v1(
            lse_configuration,
            expected_owner,
            expected_configuration,
        )?;
        bootstrap.diagnostic_validate_against_authority_v1(
            lse_configuration,
            expected_owner,
            expected_configuration,
        )?;
        let actual =
            DirectSoilThermalResident::V2(resident.clone()).canonical_active_owner_bytes()?;
        let mut views = clock
            .owners()
            .iter()
            .filter(|owner| owner.owner_id() == "soil_thermal");
        let view = views.next().ok_or(DirectV9RealConsumerError::Identity(
            "native deferred proof missing clock owner",
        ))?;
        if views.next().is_some() || view.state_bytes() != actual {
            return Err(DirectV9RealConsumerError::Identity(
                "native deferred proof exact unique clock owner",
            ));
        }
        let owner = resident.owner();
        if owner.run_id != expected_soil_run_id || bootstrap.owner().run_id != expected_soil_run_id
        {
            return Err(DirectV9RealConsumerError::Identity(
                "native deferred proof independent run identity",
            ));
        }
        // A deferred admission is never an initial/bootstrap admission.  Its
        // candidate is separately replayed by the enclosing phase custody.
        if clock.accepted_until().get() == 0 || next_day == 0 {
            return Err(DirectV9RealConsumerError::Identity("native deferred proof original accepted resident"));
        }
        Ok(Self { inactive_scheduler: None, resident: actual, clock: clock.clone(), position, logical_revision,
            next_day, run_id, lse_configuration_sha256: lse_configuration.configuration_sha256.clone() })
    }

    /// Bind the original receipt-free physical counter before private calendar admission.
    /// Native envelope validation precedes this binding; full retained history replay
    /// remains mandatory before the enclosing restored resident becomes usable.
    pub fn bind_inactive_scheduler(mut self, count: u64,
        configuration: &crate::DirectSurfaceLiquidConfiguration, surface_bytes: &[u8],
        wb14_bytes: Option<&[u8]>, validated_native_surface_bytes: Option<&[u8]>,
        native_configuration: Option<&crate::SurfaceLiquidConfigurationV2>, native_wb14_bytes: Option<&[u8]>,
    ) -> Result<Self, DirectV9RealConsumerError> {
        if self.inactive_scheduler.is_some() {
            return Err(DirectV9RealConsumerError::Identity("native inactive scheduler count or WB14"));
        }
        self.inactive_scheduler = Some(Self::validate_inactive_scheduler_v1(count, configuration,
            surface_bytes, wb14_bytes, validated_native_surface_bytes, native_configuration,
            native_wb14_bytes, &self.clock, self.run_id)?);
        Ok(self)
    }

    #[allow(clippy::too_many_arguments)]
    #[cfg(test)]
    pub(crate) fn diagnostic_validate_inactive_scheduler_v1(count: u64,
        configuration: &crate::DirectSurfaceLiquidConfiguration, surface_bytes: &[u8],
        wb14_bytes: Option<&[u8]>, validated_native_surface_bytes: Option<&[u8]>,
        native_configuration: Option<&crate::SurfaceLiquidConfigurationV2>, native_wb14_bytes: Option<&[u8]>,
        clock: &openwepp_coupled_time::CoupledClockStateV1, expected_run_id: u64,
    ) -> Result<(), DirectV9RealConsumerError> {
        Self::validate_inactive_scheduler_v1(count, configuration, surface_bytes, wb14_bytes,
            validated_native_surface_bytes, native_configuration, native_wb14_bytes, clock,
            expected_run_id).map(|_| ())
    }

    #[allow(clippy::too_many_arguments)]
    fn validate_inactive_scheduler_v1(count: u64,
        configuration: &crate::DirectSurfaceLiquidConfiguration, surface_bytes: &[u8],
        wb14_bytes: Option<&[u8]>, validated_native_surface_bytes: Option<&[u8]>,
        native_configuration: Option<&crate::SurfaceLiquidConfigurationV2>, native_wb14_bytes: Option<&[u8]>,
        clock: &openwepp_coupled_time::CoupledClockStateV1, expected_run_id: u64,
    ) -> Result<NativeInactiveSchedulerCustodyV1, DirectV9RealConsumerError> {
        if count != 0 || wb14_bytes.is_some() || native_wb14_bytes.is_some()
            || configuration.run_id != expected_run_id {
            return Err(DirectV9RealConsumerError::Identity("native inactive scheduler count or WB14"));
        }
        let surface = crate::DirectSurfaceLiquidOwnedState::from_canonical_bytes(configuration,surface_bytes)
            .map_err(|_| DirectV9RealConsumerError::Identity("native inactive scheduler surface"))?;
        if surface.canonical_bytes(configuration).map_err(|_| DirectV9RealConsumerError::Identity("native inactive scheduler canonical surface"))? != surface_bytes
            || surface.continuations.is_empty()
            || surface.continuations.len() != configuration.ofe_topology.len()
            || surface.continuations.iter().zip(&configuration.ofe_topology).any(|(value,ofe)|
                &value.ofe_id != ofe || value.day_index != 0 || value.next_interval_index != 0
                || value.last_accepted_transaction_id.is_some()
                || value.cumulative_supply_m.to_bits() != 0
                || value.cumulative_infiltration_m.to_bits() != 0) {
            return Err(DirectV9RealConsumerError::Identity("native inactive scheduler exact continuation"));
        }
        let mut clock_surfaces = clock.owners().iter().filter(|value| value.owner_id()=="surface_liquid");
        let clock_surface = clock_surfaces.next().ok_or(DirectV9RealConsumerError::Identity("native inactive scheduler missing surface clock"))?;
        if clock_surfaces.next().is_some() {
            return Err(DirectV9RealConsumerError::Identity("native inactive scheduler duplicate surface clock"));
        }
        let clock_value: serde_json::Value = serde_json::from_slice(clock_surface.state_bytes())
            .map_err(|error| DirectV9RealConsumerError::Serialization(error.to_string()))?;
        let native_configuration = native_configuration.ok_or(DirectV9RealConsumerError::Identity("native inactive scheduler native configuration absent"))?;
        if native_configuration.parent() != configuration {
            return Err(DirectV9RealConsumerError::Identity("native inactive scheduler native parent configuration"));
        }
        let native_bytes = validated_native_surface_bytes.ok_or(DirectV9RealConsumerError::Identity("native inactive scheduler native surface absent"))?;
        let native = crate::SurfaceLiquidOwnerEnvelopeV2::from_canonical_bytes(configuration,Some(native_configuration),native_bytes)
            .map_err(|_| DirectV9RealConsumerError::Identity("native inactive scheduler native envelope"))?;
        let state = native.v2_state().ok_or(DirectV9RealConsumerError::Identity("native inactive scheduler surface downgrade"))?;
        if native.canonical_bytes(configuration,Some(native_configuration))
            .map_err(|_| DirectV9RealConsumerError::Identity("native inactive scheduler native canonical bytes"))? != native_bytes
            || state.continuations() != surface.continuations.as_slice() {
            return Err(DirectV9RealConsumerError::Identity("native inactive scheduler native continuation correspondence"));
        }
        let matches = if clock_value.get("version").and_then(serde_json::Value::as_str)==Some("v2") {
            native_bytes == clock_surface.state_bytes()
        } else {
            let persistent: serde_json::Value = serde_json::from_slice(surface_bytes)
                .map_err(|error| DirectV9RealConsumerError::Serialization(error.to_string()))?;
            clock_value == serde_json::json!({"schema":"OPENWEPP_SURFACE_LIQUID_COMPLETE_OWNER_PROJECTION_V2",
                "persistent_owner":persistent,"wb14_parent_working_state":serde_json::Value::Null})
        };
        if !matches { return Err(DirectV9RealConsumerError::Identity("native inactive scheduler exact clock custody")); }
        Ok(NativeInactiveSchedulerCustodyV1 {
            count, surface_bytes: surface_bytes.to_vec(), configuration_sha256: configuration.configuration_sha256.clone(),
        })
    }

    fn validate_constructor_context(&self, resident: &DirectSoilThermalResident,
        lse_configuration: &LandSurfaceEnergyConfiguration,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        position: NativeSoilRestartPositionV1,
        logical_revision: u128, next_day: usize, run_id: u64,
    ) -> Result<(), DirectV9RealConsumerError> {
        if self.clock != *clock || self.position != position
            || self.lse_configuration_sha256 != lse_configuration.configuration_sha256 {
            return Err(DirectV9RealConsumerError::Identity("native soil proof foreign constructor context"));
        }
        self.validate_private_owner(resident, logical_revision, next_day, run_id)
    }

    fn validate_private_owner(&self, resident: &DirectSoilThermalResident,
        logical_revision: u128, next_day: usize, run_id: u64,
    ) -> Result<(), DirectV9RealConsumerError> {
        if !matches!(resident, DirectSoilThermalResident::V2(_))
            || self.resident != resident.canonical_active_owner_bytes()?
            || self.logical_revision != logical_revision || self.next_day != next_day || self.run_id != run_id {
            return Err(DirectV9RealConsumerError::Identity("native soil proof substituted private owner"));
        }
        Ok(())
    }
}

/// Exact executing canonical allowance for native restart method identity.
pub fn restart_authority_canonical_map_allowance_v1() -> u8 {
    v11_covered::canonical_covered_max_authentic_maps_v1()
}

/// Private-admission projection only: callers validate original and resulting
/// owners and retain every physical coordinate. Never publish this projection.
pub fn restart_authority_vegetation_for_predecessor_admission(value: &V10CoupledOwnedState,
    predecessor: u128) -> V10CoupledOwnedState {
    let mut normalized = value.clone();
    normalized.0.last_transaction_id = predecessor;
    for stratum in normalized.0.strata.values_mut() { stratum.last_transaction_id = predecessor; }
    for occupancy in normalized.0.occupancies.values_mut() {
        occupancy.last_accepted_transaction_id = (predecessor != 0).then_some(predecessor);
    }
    normalized.0.state_sha256 = normalized.0.canonical_sha256();
    normalized
}

// Process-local only; no serde or independent public construction.
struct NativeInactiveSchedulerCustodyV1 {
    count: u64,
    surface_bytes: Vec<u8>,
    configuration_sha256: String,
}

impl DirectV10RealConsumerShadow {
    #[cfg(any(feature="restart-authority-evidence",feature="persisted-restart-v1"))]
    pub fn restart_authority_install_native_inactive_scheduler_position(&mut self,
        proof: &NativeSoilRestartAdmissionV1,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        position: NativeSoilRestartPositionV1,
    ) -> Result<(), DirectV10RealConsumerError> {
        proof.validate_constructor_context(&self.inner.soil_thermal,&self.lse_configuration,
            clock,position,self.vegetation_state.0.last_transaction_id,self.inner.next_day_index,
            self.inner.hydrology_frame.identity.run_id)?;
        let custody = proof.inactive_scheduler.as_ref().ok_or(DirectV9RealConsumerError::Identity("native inactive scheduler proof absent"))?;
        let surface = self.inner.hydrology_frame.surface_liquid_shadow.as_ref()
            .ok_or(DirectV9RealConsumerError::Identity("native inactive scheduler installed surface absent"))?;
        if custody.count != 0 || custody.count > u64::from(u32::MAX) * INTERVALS_PER_DAY as u64
            || self.inner.surface_configuration.configuration_sha256 != custody.configuration_sha256
            || surface.canonical_bytes(&self.inner.surface_configuration)
                .map_err(|_| DirectV9RealConsumerError::Identity("native inactive scheduler installed surface"))? != custody.surface_bytes
            || self.inner.wb14_parent_working_state.is_some() {
            return Err(DirectV9RealConsumerError::Identity("native inactive scheduler installed custody mismatch").into());
        }
        self.inner.accepted_interval_count = custody.count;
        Ok(())
    }
}
