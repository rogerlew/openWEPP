//! B01 diagnostic pre-child capture. This module never affects a model result.

use crate::{
    snow_stage3_v11_attachment::DirectSnowStage3V11StaticContext,
    v9_real_consumer_shadow::DirectV10RealConsumerShadow,
};
use openwepp_coupled_time::{
    AcceptedSlabReceiptV1, ConstraintReductionReceiptV1, CoupledClockStateV1, CoupledTimeRestartV2,
    DiagnosticReductionV1, LedgerEntryV1, TimeSupport, digest_bytes,
};
#[cfg(test)]
use openwepp_coupled_time::{
    ConstraintClass, CoupledSlabCandidateV1, StepConstraintV1, accept_slab,
    complete_owner_set_digest, reduce_constraints,
};
use openwepp_vegetation::V11ParentTransaction;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

#[path = "snow_stage3_v11_constructor_encoder.rs"]
mod constructor_encoder;
#[cfg(feature = "persisted-restart-v1")]
#[path = "snow_stage3_v11_constructor_inverse.rs"]
mod constructor_inverse;
#[cfg(feature = "persisted-restart-v1")]
#[path = "snow_stage3_v11_member_restoration.rs"]
pub(crate) mod member_restoration;

const CLOCK_MODEL_DOMAIN: &[u8] = b"OPENWEPP_STAGE3_V11_COUPLED_CLOCK_RESTART_MODEL_V1";
const CLOCK_AUTHORITY_DOMAIN: &[u8] = b"SC-SNOWENERGY-001@22+SC-COUPLEDTIME-001";
const CLOCK_REDUCTION_ID: &str = "stage3-v11-restart-no-publication";
const B01_DAY_INDEX: usize = 4;
const B01_INTERVAL_INDEX: usize = 22;
const B01_CHILD_START_NS: u128 = 385_920_000_000_000;
const B01_CHILD_END_NS: u128 = 385_980_000_000_000;

#[derive(Clone, Debug, Deserialize, Serialize)]
struct ActiveSnowPartitionCaptureV1 {
    scalars: [f64; 17],
    snow_melt_model: String,
    snow_density_model: String,
    liquid_routing_model: String,
    surface_energy: SurfaceEnergyCaptureV1,
    sturm_climate_class: Option<String>,
    sturm_day_of_year: Option<f64>,
    snow_albedo_model: Option<String>,
    snow_albedo_state: Option<SnowAlbedoCaptureV1>,
    snow_layers: Vec<crate::winter_column::DirectSnowLayerState>,
    underlying_surface_albedo: f64,
    hourly: Vec<SnowHourlyCaptureV1>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct SnowHourlyCaptureV1 {
    values: [f64; 8],
    phase_model: String,
    hydrometeor_temperature_c: Option<f64>,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
struct SnowAlbedoCaptureV1 {
    model: String,
    albedo: f64,
    accumulated_positive_temperature_c_day: f64,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
struct SurfaceEnergyCaptureV1 {
    longwave: String,
    sublimation: String,
    values: [f64; 7],
    daylight: bool,
    complete_carrier_shadow: bool,
}

/// Private, file-safe dynamic portion of the native consumer's hydrology
/// frame. Immutable lane/day configuration is supplied independently through
/// `DirectRunConstructorInputs`; this payload contains only state which the
/// canonical constructor deliberately resets.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub(crate) struct DirectRunFrameDynamicCaptureV1 {
    publication: [f64; 5],
    lanes: Vec<DirectLaneDynamicCaptureV1>,
    lane_transfer_ledger: Vec<DirectLaneTransferLedgerCaptureV1>,
    lane_transfer_downstream_operands: DirectRunTransferOperandsCaptureV1,
    lane_transfer_shadow_projection: Option<DirectRunTransferOperandsCaptureV1>,
    groundwater: DirectGroundwaterCaptureV1,
    surface_liquid_canonical_bytes: Option<Vec<u8>>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct DirectSubsurfaceLayerCaptureV1 {
    theta_m: f64,
    field_capacity_m: f64,
    upper_limit_m: f64,
    conductivity_m_s: f64,
    depth_m: f64,
    residual_theta: f64,
    frozen_depth_m: f64,
    frozen_water_m: f64,
    porosity: f64,
    field_capacity_theta: f64,
    coca: f64,
    lateral_conductivity_m_s: f64,
}

impl From<&crate::DirectSubsurfaceLayerState> for DirectSubsurfaceLayerCaptureV1 {
    fn from(value: &crate::DirectSubsurfaceLayerState) -> Self {
        Self {
            theta_m: value.theta_m,
            field_capacity_m: value.field_capacity_m,
            upper_limit_m: value.upper_limit_m,
            conductivity_m_s: value.conductivity_m_s,
            depth_m: value.depth_m,
            residual_theta: value.residual_theta,
            frozen_depth_m: value.frozen_depth_m,
            frozen_water_m: value.frozen_water_m,
            porosity: value.porosity,
            field_capacity_theta: value.field_capacity_theta,
            coca: value.coca,
            lateral_conductivity_m_s: value.lateral_conductivity_m_s,
        }
    }
}

impl From<DirectSubsurfaceLayerCaptureV1> for crate::DirectSubsurfaceLayerState {
    fn from(value: DirectSubsurfaceLayerCaptureV1) -> Self {
        Self {
            theta_m: value.theta_m,
            field_capacity_m: value.field_capacity_m,
            upper_limit_m: value.upper_limit_m,
            conductivity_m_s: value.conductivity_m_s,
            depth_m: value.depth_m,
            residual_theta: value.residual_theta,
            frozen_depth_m: value.frozen_depth_m,
            frozen_water_m: value.frozen_water_m,
            porosity: value.porosity,
            field_capacity_theta: value.field_capacity_theta,
            coca: value.coca,
            lateral_conductivity_m_s: value.lateral_conductivity_m_s,
        }
    }
}

fn capture_subsurface_layers(
    layers: &[crate::DirectSubsurfaceLayerState],
) -> Vec<DirectSubsurfaceLayerCaptureV1> {
    layers
        .iter()
        .map(DirectSubsurfaceLayerCaptureV1::from)
        .collect()
}

fn restore_subsurface_layers(
    layers: &[DirectSubsurfaceLayerCaptureV1],
) -> Vec<crate::DirectSubsurfaceLayerState> {
    layers
        .iter()
        .cloned()
        .map(crate::DirectSubsurfaceLayerState::from)
        .collect()
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct DirectLaneDynamicCaptureV1 {
    water: [f64; 6],
    subsurface_layers: Vec<DirectSubsurfaceLayerCaptureV1>,
    transfer_surface_carry_m: [f64; 24],
    transfer_surface_hourly_weights: [f64; 24],
    transfer_lateral_carry_m: [f64; 24],
    transfer_scalars: [f64; 2],
    publication: [f64; 5],
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct DirectLaneTransferLedgerCaptureV1 {
    lane_id: u32,
    upstream_lane_id: u32,
    downstream_lane_id: u32,
    values: [f64; 7],
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct DirectRunTransferOperandsCaptureV1 {
    lane_count: usize,
    outlet_lane_id: u32,
    values: [f64; 5],
}

#[derive(Clone, Debug, Deserialize, Serialize)]
enum DirectGroundwaterCaptureV1 {
    Disabled,
    LinearReservoir {
        authority: [f64; 4],
        state: [f64; 3],
        initialized_area_m2: Option<f64>,
    },
}

pub(crate) fn capture_direct_run_frame_dynamic(
    frame: &crate::DirectRunFrame,
    pinned: &crate::DirectRunConstructorInputs,
    surface_configuration: &crate::DirectSurfaceLiquidConfiguration,
) -> Result<DirectRunFrameDynamicCaptureV1, String> {
    // Reconstruct first and require that every field outside this narrowly
    // transportable dynamic surface is identical to its independently pinned
    // constructor authority.  This prevents a new frame field from becoming
    // a silent reset during diagnostic import.
    let base = crate::DirectRunFrame::from_constructor_inputs(pinned.clone())
        .map_err(|error| error.to_string())?;
    if frame.identity != base.identity
        || frame.phase_plan != base.phase_plan
        || frame.snow_stage3_v11_attachment.is_some()
        || frame.laned_active.is_some()
        || frame.laned_active_summary.is_some()
        || frame.lanes.len() != base.lanes.len()
        || frame
            .lanes
            .iter()
            .zip(&base.lanes)
            .any(|(actual, expected)| {
                actual.lane_id != expected.lane_id
                    || actual.upstream_lane_id != expected.upstream_lane_id
                    || actual.downstream_lane_id != expected.downstream_lane_id
                    || actual.upstream_area_ratio.to_bits()
                        != expected.upstream_area_ratio.to_bits()
                    || actual.area_m2.to_bits() != expected.area_m2.to_bits()
                    || actual.runoff_publication_q_scale.to_bits()
                        != expected.runoff_publication_q_scale.to_bits()
                    || actual.runoff_publication_qofe_scale.to_bits()
                        != expected.runoff_publication_qofe_scale.to_bits()
                    || actual.runoff_publication_efflen_m.to_bits()
                        != expected.runoff_publication_efflen_m.to_bits()
                    || actual.runoff_publication_cumulative_length_m.to_bits()
                        != expected.runoff_publication_cumulative_length_m.to_bits()
                    || actual.runoff_publication_ofe_length_m.to_bits()
                        != expected.runoff_publication_ofe_length_m.to_bits()
                    || actual.erosion_downstream_operands != expected.erosion_downstream_operands
                    || actual.erosion_inflow_intake != expected.erosion_inflow_intake
                    || actual.evapotranspiration_stage_state
                        != expected.evapotranspiration_stage_state
                    || actual.plant_growth_state != expected.plant_growth_state
                    || actual.plant_water_stress.to_bits() != expected.plant_water_stress.to_bits()
                    || actual.winter_column != expected.winter_column
                    || actual.snow_runtime_carry != expected.snow_runtime_carry
                    || actual.frost_runtime_carry != expected.frost_runtime_carry
                    || actual.erosion_runtime_carry != expected.erosion_runtime_carry
                    || actual.day_inputs != expected.day_inputs
            })
    {
        return Err("unsupported dynamic native hydrology frame state".into());
    }
    let capture = DirectRunFrameDynamicCaptureV1 {
        publication: [
            frame.publication.runoff_m,
            frame.publication.infiltration_m,
            frame.publication.evapotranspiration_m,
            frame.publication.drainage_m,
            frame.publication.lateral_flow_m,
        ],
        lanes: frame
            .lanes
            .iter()
            .map(|lane| DirectLaneDynamicCaptureV1 {
                water: [
                    lane.water.soil_water_m,
                    lane.water.infiltration_m,
                    lane.water.runoff_m,
                    lane.water.evapotranspiration_m,
                    lane.water.drainage_m,
                    lane.water.lateral_flow_m,
                ],
                subsurface_layers: capture_subsurface_layers(&lane.subsurface_layers),
                transfer_surface_carry_m: lane.transfer.surface_carry_m,
                transfer_surface_hourly_weights: lane.transfer.surface_hourly_weights,
                transfer_lateral_carry_m: lane.transfer.lateral_carry_m,
                transfer_scalars: [
                    lane.transfer.upstream_flow_m,
                    lane.transfer.subsurface_input_m,
                ],
                publication: [
                    lane.publication.runoff_m,
                    lane.publication.infiltration_m,
                    lane.publication.evapotranspiration_m,
                    lane.publication.drainage_m,
                    lane.publication.lateral_flow_m,
                ],
            })
            .collect(),
        lane_transfer_ledger: frame
            .lane_transfer_ledger
            .iter()
            .map(|entry| DirectLaneTransferLedgerCaptureV1 {
                lane_id: entry.lane_id,
                upstream_lane_id: entry.upstream_lane_id,
                downstream_lane_id: entry.downstream_lane_id,
                values: [
                    entry.upstream_area_ratio,
                    entry.area_m2,
                    entry.outgoing_surface_m,
                    entry.outgoing_lateral_m,
                    entry.received_surface_m,
                    entry.received_lateral_m,
                    entry.net_transfer_m,
                ],
            })
            .collect(),
        lane_transfer_downstream_operands: capture_run_transfer_operands(
            frame.lane_transfer_downstream_operands,
        ),
        lane_transfer_shadow_projection: frame
            .lane_transfer_shadow_projection
            .map(capture_run_transfer_projection),
        groundwater: capture_groundwater(frame.groundwater),
        surface_liquid_canonical_bytes: frame
            .surface_liquid_shadow
            .as_deref()
            .map(|state| {
                state
                    .canonical_bytes(surface_configuration)
                    .map_err(|error| error.to_string())
            })
            .transpose()?,
    };
    let restored =
        restore_direct_run_frame_dynamic(capture.clone(), pinned.clone(), surface_configuration)?;
    if restored != *frame {
        return Err("captured dynamic hydrology frame exact reconstruction".into());
    }
    Ok(capture)
}

fn capture_run_transfer_operands(
    value: crate::DirectRunTransferDownstreamOperands,
) -> DirectRunTransferOperandsCaptureV1 {
    DirectRunTransferOperandsCaptureV1 {
        lane_count: value.lane_count,
        outlet_lane_id: value.outlet_lane_id,
        values: [
            value.total_outgoing_surface_m,
            value.total_outgoing_lateral_m,
            value.total_received_surface_m,
            value.total_received_lateral_m,
            value.total_net_transfer_m,
        ],
    }
}
fn capture_run_transfer_projection(
    value: crate::DirectRunTransferShadowProjection,
) -> DirectRunTransferOperandsCaptureV1 {
    DirectRunTransferOperandsCaptureV1 {
        lane_count: value.lane_count,
        outlet_lane_id: value.outlet_lane_id,
        values: [
            value.total_outgoing_surface_m,
            value.total_outgoing_lateral_m,
            value.total_received_surface_m,
            value.total_received_lateral_m,
            value.total_net_transfer_m,
        ],
    }
}
fn capture_groundwater(value: crate::DirectGroundwaterRunState) -> DirectGroundwaterCaptureV1 {
    match value.authority {
        crate::DirectGroundwaterAuthority::Disabled => DirectGroundwaterCaptureV1::Disabled,
        crate::DirectGroundwaterAuthority::LinearReservoir {
            initial_storage_depth_m,
            baseflow_coeff_per_day,
            deep_seepage_coeff_per_day,
            baseflow_threshold_area_ha,
        } => DirectGroundwaterCaptureV1::LinearReservoir {
            authority: [
                initial_storage_depth_m,
                baseflow_coeff_per_day,
                deep_seepage_coeff_per_day,
                baseflow_threshold_area_ha,
            ],
            state: [
                value.storage_m3,
                value.previous_baseflow_m3,
                value.previous_deep_seepage_m3,
            ],
            initialized_area_m2: value.initialized_area_m2,
        },
    }
}

pub(crate) fn restore_direct_run_frame_dynamic(
    capture: DirectRunFrameDynamicCaptureV1,
    mut pinned: crate::DirectRunConstructorInputs,
    surface_configuration: &crate::DirectSurfaceLiquidConfiguration,
) -> Result<crate::DirectRunFrame, String> {
    if capture.lanes.len() != pinned.lanes.len()
        || capture.lane_transfer_ledger.len() != pinned.lanes.len()
    {
        return Err("captured dynamic hydrology frame lane cardinality".into());
    }
    for (lane, captured) in pinned.lanes.iter_mut().zip(&capture.lanes) {
        lane.water = crate::DirectWaterState {
            soil_water_m: captured.water[0],
            infiltration_m: captured.water[1],
            runoff_m: captured.water[2],
            evapotranspiration_m: captured.water[3],
            drainage_m: captured.water[4],
            lateral_flow_m: captured.water[5],
        };
        lane.subsurface_layers = restore_subsurface_layers(&captured.subsurface_layers);
        lane.transfer = crate::DirectTransferBuffers {
            surface_carry_m: captured.transfer_surface_carry_m,
            surface_hourly_weights: captured.transfer_surface_hourly_weights,
            lateral_carry_m: captured.transfer_lateral_carry_m,
            upstream_flow_m: captured.transfer_scalars[0],
            subsurface_input_m: captured.transfer_scalars[1],
        };
        lane.publication = crate::DirectPublicationFrame {
            runoff_m: captured.publication[0],
            infiltration_m: captured.publication[1],
            evapotranspiration_m: captured.publication[2],
            drainage_m: captured.publication[3],
            lateral_flow_m: captured.publication[4],
        };
    }
    let mut frame = crate::DirectRunFrame::from_constructor_inputs(pinned)
        .map_err(|error| error.to_string())?;
    frame.publication = crate::DirectPublicationFrame {
        runoff_m: capture.publication[0],
        infiltration_m: capture.publication[1],
        evapotranspiration_m: capture.publication[2],
        drainage_m: capture.publication[3],
        lateral_flow_m: capture.publication[4],
    };
    for (lane, captured) in frame.lanes.iter_mut().zip(capture.lanes) {
        lane.water = crate::DirectWaterState {
            soil_water_m: captured.water[0],
            infiltration_m: captured.water[1],
            runoff_m: captured.water[2],
            evapotranspiration_m: captured.water[3],
            drainage_m: captured.water[4],
            lateral_flow_m: captured.water[5],
        };
        lane.transfer = crate::DirectTransferBuffers {
            surface_carry_m: captured.transfer_surface_carry_m,
            surface_hourly_weights: captured.transfer_surface_hourly_weights,
            lateral_carry_m: captured.transfer_lateral_carry_m,
            upstream_flow_m: captured.transfer_scalars[0],
            subsurface_input_m: captured.transfer_scalars[1],
        };
        lane.publication = crate::DirectPublicationFrame {
            runoff_m: captured.publication[0],
            infiltration_m: captured.publication[1],
            evapotranspiration_m: captured.publication[2],
            drainage_m: captured.publication[3],
            lateral_flow_m: captured.publication[4],
        };
    }
    frame.lane_transfer_ledger = capture
        .lane_transfer_ledger
        .into_iter()
        .map(|entry| crate::DirectLaneTransferLedger {
            lane_id: entry.lane_id,
            upstream_lane_id: entry.upstream_lane_id,
            downstream_lane_id: entry.downstream_lane_id,
            upstream_area_ratio: entry.values[0],
            area_m2: entry.values[1],
            outgoing_surface_m: entry.values[2],
            outgoing_lateral_m: entry.values[3],
            received_surface_m: entry.values[4],
            received_lateral_m: entry.values[5],
            net_transfer_m: entry.values[6],
        })
        .collect();
    frame.lane_transfer_downstream_operands =
        restore_run_transfer_operands(capture.lane_transfer_downstream_operands);
    frame.lane_transfer_shadow_projection = capture
        .lane_transfer_shadow_projection
        .map(restore_run_transfer_projection);
    frame.groundwater = restore_groundwater(capture.groundwater)?;
    if let Some(bytes) = capture.surface_liquid_canonical_bytes {
        let state = crate::DirectSurfaceLiquidOwnedState::from_canonical_bytes(
            surface_configuration,
            &bytes,
        )
        .map_err(|error| error.to_string())?;
        frame
            .configure_surface_liquid_shadow(surface_configuration, state)
            .map_err(|error| error.to_string())?;
    }
    Ok(frame)
}

fn restore_run_transfer_operands(
    value: DirectRunTransferOperandsCaptureV1,
) -> crate::DirectRunTransferDownstreamOperands {
    crate::DirectRunTransferDownstreamOperands {
        lane_count: value.lane_count,
        outlet_lane_id: value.outlet_lane_id,
        total_outgoing_surface_m: value.values[0],
        total_outgoing_lateral_m: value.values[1],
        total_received_surface_m: value.values[2],
        total_received_lateral_m: value.values[3],
        total_net_transfer_m: value.values[4],
    }
}
fn restore_run_transfer_projection(
    value: DirectRunTransferOperandsCaptureV1,
) -> crate::DirectRunTransferShadowProjection {
    crate::DirectRunTransferShadowProjection {
        lane_count: value.lane_count,
        outlet_lane_id: value.outlet_lane_id,
        total_outgoing_surface_m: value.values[0],
        total_outgoing_lateral_m: value.values[1],
        total_received_surface_m: value.values[2],
        total_received_lateral_m: value.values[3],
        total_net_transfer_m: value.values[4],
    }
}
fn restore_groundwater(
    value: DirectGroundwaterCaptureV1,
) -> Result<crate::DirectGroundwaterRunState, String> {
    match value {
        DirectGroundwaterCaptureV1::Disabled => Ok(crate::DirectGroundwaterRunState::disabled()),
        DirectGroundwaterCaptureV1::LinearReservoir {
            authority,
            state,
            initialized_area_m2,
        } => {
            let authority = crate::DirectGroundwaterAuthority::linear_reservoir(
                authority[0],
                authority[1],
                authority[2],
                authority[3],
            )
            .map_err(|error| error.to_string())?;
            Ok(crate::DirectGroundwaterRunState {
                authority,
                storage_m3: state[0],
                previous_baseflow_m3: state[1],
                previous_deep_seepage_m3: state[2],
                initialized_area_m2,
            })
        }
    }
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct PreparedSupportCaptureV1 {
    support: TimeSupport,
    active_snow_by_lane: BTreeMap<u32, ActiveSnowPartitionCaptureV1>,
    support_forcing_by_lane: BTreeMap<u32, SupportForcingCaptureV1>,
    snow_free_interval: crate::v9_real_consumer_shadow::DirectV9ShadowIntervalInput,
    covered_interval: CoveredIntervalCaptureV1,
    hard_boundaries: Vec<openwepp_coupled_time::ModelTimeNs>,
    identities_by_lane: BTreeMap<u32, Vec<u8>>,
    destination_capabilities: Vec<DestinationCapabilityCaptureV1>,
    open_snow_destinations: Vec<DestinationCaptureV1>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct DestinationCaptureV1 {
    ofe_id: String,
    tile_id: String,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
enum DestinationCapabilityCaptureV1 {
    Covered {
        destination: DestinationCaptureV1,
        rho_air_kg_m3: f64,
        cp_air_j_kg_k: f64,
        effective_canopy_cover: f64,
    },
    Open {
        destination: DestinationCaptureV1,
    },
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct SupportForcingCaptureV1 {
    hourly: SnowHourlyCaptureV1,
    duration_seconds: f64,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct CoveredIntervalCaptureV1 {
    source: crate::v9_real_consumer_shadow::DirectV9ShadowIntervalInput,
}

fn capture_prepared_support(
    support: &crate::DirectSnowStage3V11PreparedSupport,
) -> Result<PreparedSupportCaptureV1, String> {
    let (
        active,
        forcing,
        snow_free,
        covered,
        hard_boundaries,
        identities,
        capabilities,
        open_requests,
    ) = support.diagnostic_capture_parts_v1()?;
    Ok(PreparedSupportCaptureV1 {
        support: support.support(),
        active_snow_by_lane: active
            .iter()
            .map(|(lane, value)| (*lane, active_snow_capture(value)))
            .collect(),
        support_forcing_by_lane: forcing.iter().map(|(lane, value)| (*lane, SupportForcingCaptureV1 { hourly: SnowHourlyCaptureV1 { values:[value.forcing.active_precipitation_m,value.forcing.rain_m,value.forcing.snowfall_m,value.forcing.radiation_mj_m2,value.forcing.air_temperature_c,value.forcing.cloud_fraction,value.forcing.rain_fraction,value.forcing.snow_fraction],phase_model:value.forcing.phase_model.id().into(),hydrometeor_temperature_c:value.forcing.hydrometeor_temperature_c }, duration_seconds:value.duration_seconds })).collect(),
        snow_free_interval: snow_free.clone(),
        covered_interval: CoveredIntervalCaptureV1 { source: crate::v9_real_consumer_shadow::DirectV9ShadowIntervalInput { lse_forcing:covered.lse_forcing.clone(), vegetation_forcing:covered.vegetation_forcing.clone(), wb14_parameters:covered.wb14_parameters.clone() } },
        hard_boundaries: hard_boundaries.to_vec(),
        identities_by_lane: identities.iter().map(|(lane, values)| serde_json::to_vec(values).map(|bytes| (*lane, bytes))).collect::<Result<_,_>>().map_err(|error| error.to_string())?,
        destination_capabilities: capabilities.iter().map(|((ofe, tile), capability)| { let destination=DestinationCaptureV1 { ofe_id:ofe.as_str().to_owned(), tile_id:tile.as_str().to_owned() }; match capability { crate::snow_stage3_open_boundary::SealedStage3TileBoundaryForcingV1::V11CanopyCovered(value) => DestinationCapabilityCaptureV1::Covered { destination, rho_air_kg_m3:value.rho_air_kg_m3, cp_air_j_kg_k:value.cp_air_j_kg_k, effective_canopy_cover:value.effective_canopy_cover }, crate::snow_stage3_open_boundary::SealedStage3TileBoundaryForcingV1::OpenSnow(_) => DestinationCapabilityCaptureV1::Open { destination } } }).collect(),
        open_snow_destinations: open_requests.iter().map(|(ofe,tile)| DestinationCaptureV1 { ofe_id:ofe.as_str().to_owned(), tile_id:tile.as_str().to_owned() }).collect(),
    })
}

fn capture_snow_free_prepared_support(
    support: &crate::DirectSnowStage3V11PreparedSupport,
) -> Result<serde_json::Value, String> {
    let (active, forcing, snow_free, hard_boundaries, identities, represented, open_requests) =
        support.diagnostic_snow_free_capture_parts_v1()?;
    let active = active
        .iter()
        .map(|(lane, value)| (*lane, active_snow_capture(value)))
        .collect::<BTreeMap<_, _>>();
    let forcing = forcing
        .iter()
        .map(|(lane, value)| {
            (
                *lane,
                SupportForcingCaptureV1 {
                    hourly: SnowHourlyCaptureV1 {
                        values: [
                            value.forcing.active_precipitation_m,
                            value.forcing.rain_m,
                            value.forcing.snowfall_m,
                            value.forcing.radiation_mj_m2,
                            value.forcing.air_temperature_c,
                            value.forcing.cloud_fraction,
                            value.forcing.rain_fraction,
                            value.forcing.snow_fraction,
                        ],
                        phase_model: value.forcing.phase_model.id().into(),
                        hydrometeor_temperature_c: value.forcing.hydrometeor_temperature_c,
                    },
                    duration_seconds: value.duration_seconds,
                },
            )
        })
        .collect::<BTreeMap<_, _>>();
    let identities = identities
        .iter()
        .map(|(lane, values)| {
            serde_json::to_vec(values)
                .map(|bytes| (*lane, bytes))
                .map_err(|error| error.to_string())
        })
        .collect::<Result<BTreeMap<_, _>, _>>()?;
    Ok(serde_json::json!({
        "support": support.support(),
        "active_snow_by_lane": active,
        "support_forcing_by_lane": forcing,
        "snow_free_interval": snow_free,
        "covered_projection": null,
        "hard_boundaries": hard_boundaries,
        "identities_by_lane": identities,
        "destination_capabilities": [],
        "destination_capability_count": represented.len(),
        "open_snow_destinations": [],
        "open_snow_destination_count": open_requests.len(),
    }))
}

fn restore_covered_interval(
    value: CoveredIntervalCaptureV1,
) -> Result<crate::v9_real_consumer_shadow::DirectV11SnowCoveredSegmentInput, String> {
    crate::v9_real_consumer_shadow::DirectV11SnowCoveredSegmentInput::try_new(
        value.source.lse_forcing,
        value.source.vegetation_forcing,
        value.source.wb14_parameters,
    )
    .map_err(|error| error.to_string())
}

/// Re-seal one recorded destination through the restored provider receipt.
///
/// The row records only the three canopy producer operands.  Repository
/// custody, exposure, and participant receipts are deliberately regenerated
/// by the canonical carrier constructor from the admitted interval.
fn restore_destination_capability(
    captured: &DestinationCapabilityCaptureV1,
    interval: &crate::runtime_inputs::SnowFreeHalfHourIntervalReceipt,
) -> Result<
    (
        (
            openwepp_land_surface_energy::OfeId,
            openwepp_kernel_contract::TileId,
        ),
        crate::snow_stage3_v11_attachment::DirectSnowStage3V11DestinationCapabilityV1,
    ),
    String,
> {
    let destination = match captured {
        DestinationCapabilityCaptureV1::Covered { destination, .. }
        | DestinationCapabilityCaptureV1::Open { destination } => destination,
    };
    if interval.ofe_id != destination.ofe_id || interval.tile_id != destination.tile_id {
        return Err("captured destination/provider interval join".into());
    }
    let typed_destination = (
        openwepp_land_surface_energy::OfeId::try_new(destination.ofe_id.clone())
            .map_err(|_| "captured destination OFE")?,
        openwepp_kernel_contract::TileId::try_new(destination.tile_id.clone())
            .map_err(|_| "captured destination tile")?,
    );
    let capability = match captured {
        DestinationCapabilityCaptureV1::Covered {
            rho_air_kg_m3,
            cp_air_j_kg_k,
            effective_canopy_cover,
            ..
        } => crate::snow_stage3_v11_attachment::DirectSnowStage3V11DestinationCapabilityV1::CanopyCovered(
            crate::snow_stage3_terminal_handoff::SealedCoveredCarrierForcing::try_from_repository_interval(
                interval,
                *rho_air_kg_m3,
                *cp_air_j_kg_k,
                *effective_canopy_cover,
            )
            .map_err(|error| error.to_string())?,
        ),
        DestinationCapabilityCaptureV1::Open { .. } => {
            crate::snow_stage3_v11_attachment::DirectSnowStage3V11DestinationCapabilityV1::OpenProviderProjection
        }
    };
    Ok((typed_destination, capability))
}

fn provider_interval_for_destination<'a>(
    provider: &'a crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
    support: TimeSupport,
    destination: &(
        openwepp_land_surface_energy::OfeId,
        openwepp_kernel_contract::TileId,
    ),
) -> Result<&'a crate::runtime_inputs::SnowFreeHalfHourIntervalReceipt, String> {
    let matches = provider
        .forcing_receipts()
        .receipts()
        .iter()
        .flat_map(|receipt| receipt.intervals.iter())
        .filter(|interval| {
            interval.ofe_id == destination.0.as_str()
                && interval.tile_id == destination.1.as_str()
                && u128::try_from(interval.day_index)
                    .ok()
                    .and_then(|day| day.checked_mul(86_400_000_000_000))
                    .and_then(|day_start| {
                        u128::try_from(interval.start_s)
                            .ok()
                            .and_then(|start| start.checked_mul(1_000_000_000))
                            .and_then(|offset| day_start.checked_add(offset))
                    })
                    == Some(support.start_ns().get())
        })
        .collect::<Vec<_>>();
    match matches.as_slice() {
        [interval] => Ok(*interval),
        [] => Err("captured destination/provider interval missing".into()),
        _ => Err("captured destination/provider interval duplicate".into()),
    }
}

/// Restore a sealed support only from captured constructor operands and the
/// canonically restored provider day.  Captured identity bytes are comparison
/// evidence: they never become constructor authority.
fn restore_prepared_support(
    capture: PreparedSupportCaptureV1,
    provider: &crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
) -> Result<crate::DirectSnowStage3V11PreparedSupport, String> {
    let support = capture.support;
    let snow_inputs_by_lane = capture
        .active_snow_by_lane
        .into_iter()
        .map(|(lane, value)| active_snow_restore(value).map(|restored| (lane, restored)))
        .collect::<Result<BTreeMap<_, _>, _>>()?;
    let support_forcing_by_lane = capture
        .support_forcing_by_lane
        .into_iter()
        .map(|(lane, value)| restore_support_forcing(value).map(|restored| (lane, restored)))
        .collect::<Result<BTreeMap<_, _>, _>>()?;
    if snow_inputs_by_lane
        .keys()
        .ne(support_forcing_by_lane.keys())
    {
        return Err("captured support lane input/forcing join".into());
    }

    let mut destination_capabilities = BTreeMap::new();
    for captured in &capture.destination_capabilities {
        let destination = match captured {
            DestinationCapabilityCaptureV1::Covered { destination, .. }
            | DestinationCapabilityCaptureV1::Open { destination } => destination,
        };
        let typed = (
            openwepp_land_surface_energy::OfeId::try_new(destination.ofe_id.clone())
                .map_err(|_| "captured destination OFE")?,
            openwepp_kernel_contract::TileId::try_new(destination.tile_id.clone())
                .map_err(|_| "captured destination tile")?,
        );
        let interval = provider_interval_for_destination(provider, support, &typed)?;
        let (restored_destination, capability) =
            restore_destination_capability(captured, interval)?;
        if restored_destination != typed
            || destination_capabilities
                .insert(restored_destination, capability)
                .is_some()
        {
            return Err("captured destination capability duplicate".into());
        }
    }
    let expected_open = capture
        .open_snow_destinations
        .iter()
        .map(|destination| {
            Ok((
                openwepp_land_surface_energy::OfeId::try_new(destination.ofe_id.clone())
                    .map_err(|_| "captured open destination OFE")?,
                openwepp_kernel_contract::TileId::try_new(destination.tile_id.clone())
                    .map_err(|_| "captured open destination tile")?,
            ))
        })
        .collect::<Result<BTreeSet<_>, String>>()?;
    let actual_open = destination_capabilities
        .iter()
        .filter_map(|(destination, capability)| matches!(capability, crate::snow_stage3_v11_attachment::DirectSnowStage3V11DestinationCapabilityV1::OpenProviderProjection).then_some(destination.clone()))
        .collect::<BTreeSet<_>>();
    if expected_open != actual_open || expected_open.len() != capture.open_snow_destinations.len() {
        return Err("captured open destination membership".into());
    }

    let mut candidates = Vec::new();
    for (destination, capability) in &destination_capabilities {
        let interval = provider_interval_for_destination(provider, support, destination)?;
        let identity = match capability {
            crate::snow_stage3_v11_attachment::DirectSnowStage3V11DestinationCapabilityV1::CanopyCovered(carrier) => crate::PreparedStage3V11SupportIdentityV1::from_provider_covered_interval(interval, carrier),
            crate::snow_stage3_v11_attachment::DirectSnowStage3V11DestinationCapabilityV1::OpenProviderProjection => crate::PreparedStage3V11SupportIdentityV1::from_provider_open_interval(support, interval),
        }
        .map_err(|error| error.to_string())?;
        candidates.push((destination.clone(), identity));
    }
    let mut support_identity_by_lane = BTreeMap::new();
    let mut consumed_destinations = BTreeSet::new();
    for (lane, captured_bytes) in capture.identities_by_lane {
        let expected = serde_json::from_slice::<Vec<serde_json::Value>>(&captured_bytes)
            .map_err(|error| error.to_string())?;
        let mut restored = Vec::with_capacity(expected.len());
        for expected_identity in expected {
            let (destination, identity) = candidates
                .iter()
                .find(|(destination, candidate)| {
                    !consumed_destinations.contains(destination)
                        && serde_json::to_value(candidate).ok().as_ref() == Some(&expected_identity)
                })
                .cloned()
                .ok_or_else(|| "captured support identity/provider projection join".to_owned())?;
            consumed_destinations.insert(destination);
            restored.push(identity);
        }
        let restored_bytes = serde_json::to_vec(&restored).map_err(|error| error.to_string())?;
        if restored_bytes != captured_bytes
            || support_identity_by_lane.insert(lane, restored).is_some()
        {
            return Err("captured support identity bytes".into());
        }
    }
    if consumed_destinations.len() != destination_capabilities.len() {
        return Err("captured support identity destination coverage".into());
    }
    crate::DirectSnowStage3V11PreparedSupport::from_dual_regime_production_inputs(
        support,
        crate::snow_stage3_v11_attachment::DirectSnowStage3V11DualRegimeSupportInputsV1 {
            snow_inputs_by_lane,
            support_forcing_by_lane,
            snow_free_v11_interval: capture.snow_free_interval,
            snow_surface_v11_interval: restore_covered_interval(capture.covered_interval)?,
            support_identity_by_lane,
            destination_capabilities,
            hard_boundaries: capture.hard_boundaries,
        },
    )
    .map_err(|error| error.to_string())
}

fn restore_support_forcing(
    value: SupportForcingCaptureV1,
) -> Result<crate::hydrology::DirectSnowStage3SupportInput, String> {
    let phase_model = match value.hourly.phase_model.as_str() {
        "legacy_rst" => crate::runtime_inputs::SnowPhasePartitionModel::LegacyRst,
        "harder_pomeroy_hourly" => {
            crate::runtime_inputs::SnowPhasePartitionModel::HarderPomeroyHourly
        }
        _ => return Err("captured support forcing phase model".into()),
    };
    Ok(crate::hydrology::DirectSnowStage3SupportInput {
        forcing: crate::hydrology::DirectSnowHourlyForcing {
            active_precipitation_m: value.hourly.values[0],
            rain_m: value.hourly.values[1],
            snowfall_m: value.hourly.values[2],
            radiation_mj_m2: value.hourly.values[3],
            air_temperature_c: value.hourly.values[4],
            cloud_fraction: value.hourly.values[5],
            phase_model,
            rain_fraction: value.hourly.values[6],
            snow_fraction: value.hourly.values[7],
            hydrometeor_temperature_c: value.hourly.hydrometeor_temperature_c,
        },
        duration_seconds: value.duration_seconds,
    })
}

fn active_snow_capture(
    value: &crate::hydrology::DirectActiveSnowPartitionInputs,
) -> ActiveSnowPartitionCaptureV1 {
    ActiveSnowPartitionCaptureV1 {
        scalars: [
            value.hyetograph_rainfall_m,
            value.rst_c,
            value.newsnw_kg_m3,
            value.ssd_kg_m3,
            value.runtime_swe_m,
            value.runtime_depth_m,
            value.runtime_density_kg_m3,
            value.runtime_settle_day_count,
            value.liquid_water_retained_m,
            value.tmax_c,
            value.tmin_c,
            value.canopy_cover_fraction,
            value.wind_m_s,
            value.dewpoint_c,
            value.coe_boundary_depth_m,
            value.coe_boundary_density_kg_m3,
            value.coe_boundary_settle_day_count,
        ],
        snow_melt_model: value.snow_melt_model.id().into(),
        snow_density_model: value.snow_density_model.id().into(),
        liquid_routing_model: value.stage3_liquid_routing_model.id().into(),
        surface_energy: SurfaceEnergyCaptureV1 {
            longwave: value.surface_energy_options.longwave_model.id().into(),
            sublimation: value.surface_energy_options.sublimation_model.id().into(),
            values: [
                value.surface_energy_options.daily_solar_radiation_mj_m2,
                value
                    .surface_energy_options
                    .daily_extraterrestrial_radiation_mj_m2,
                value.surface_energy_options.atmospheric_pressure_pa,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .air_temperature_height_m,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .vapor_pressure_height_m,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .wind_speed_height_m,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .aerodynamic_roughness_length_m,
            ],
            daylight: value.surface_energy_options.daylight,
            complete_carrier_shadow: value.surface_energy_options.complete_carrier_shadow,
        },
        sturm_climate_class: value.sturm_climate_class.map(|x| x.id().into()),
        sturm_day_of_year: value.sturm_day_of_year,
        snow_albedo_model: value.snow_albedo_model.map(|x| x.id().into()),
        snow_albedo_state: value.snow_albedo_state.map(|x| SnowAlbedoCaptureV1 {
            model: x.model.id().into(),
            albedo: x.albedo,
            accumulated_positive_temperature_c_day: x.accumulated_positive_temperature_c_day,
        }),
        snow_layers: value.snow_layers.clone(),
        underlying_surface_albedo: value.underlying_surface_albedo,
        hourly: value
            .hourly
            .iter()
            .map(|x| SnowHourlyCaptureV1 {
                values: [
                    x.active_precipitation_m,
                    x.rain_m,
                    x.snowfall_m,
                    x.radiation_mj_m2,
                    x.air_temperature_c,
                    x.cloud_fraction,
                    x.rain_fraction,
                    x.snow_fraction,
                ],
                phase_model: x.phase_model.id().into(),
                hydrometeor_temperature_c: x.hydrometeor_temperature_c,
            })
            .collect(),
    }
}

fn active_snow_restore(
    value: ActiveSnowPartitionCaptureV1,
) -> Result<crate::hydrology::DirectActiveSnowPartitionInputs, String> {
    use crate::hydrology::{
        SnowClimateClass, SnowDensityModel, SnowMeltModel, SnowStage3LiquidRoutingModel,
        SnowSurfaceLongwaveModel, SnowSurfaceSublimationModel,
    };
    let melt = match value.snow_melt_model.as_str() {
        "adaptive_compositional_stage3_v1" => SnowMeltModel::AdaptiveCompositionalStage3V1,
        "legacy_coe" => SnowMeltModel::LegacyCoe,
        "coe_shortwave_albedo_v1" => SnowMeltModel::CoeShortwaveAlbedoV1,
        "coe_winter_thaw_state_loss_v1" => SnowMeltModel::CoeWinterThawStateLossV1,
        "coe_liquid_holding_capacity_v1" => SnowMeltModel::CoeLiquidHoldingCapacityV1,
        "coe_open_sublimation_stage_a_v1" => SnowMeltModel::CoeOpenSublimationStageAV1,
        "coe_open_sublimation_stage_b_v1" => SnowMeltModel::CoeOpenSublimationStageBV1,
        _ => return Err("active-snow melt model".into()),
    };
    let density = match value.snow_density_model.as_str() {
        "legacy_wepp" => SnowDensityModel::LegacyWepp,
        "physics_bulk_density_compaction_v1" => SnowDensityModel::PhysicsBulkDensityCompactionV1,
        "physics_bulk_spring_densification_v1" => {
            SnowDensityModel::PhysicsBulkSpringDensificationV1
        }
        "physics_bulk_shallow_guard_v1" => SnowDensityModel::PhysicsBulkShallowGuardV1,
        "physics_bulk_climate_class_density_v1" => {
            SnowDensityModel::PhysicsBulkClimateClassDensityV1
        }
        "physics_bulk_multilayer_density_v1" => SnowDensityModel::PhysicsBulkMultilayerDensityV1,
        _ => return Err("active-snow density model".into()),
    };
    let routing = match value.liquid_routing_model.as_str() {
        "disabled" => SnowStage3LiquidRoutingModel::Disabled,
        "layered_thermal_liquid_v1" => SnowStage3LiquidRoutingModel::LayeredThermalLiquidV1,
        _ => return Err("active-snow liquid routing model".into()),
    };
    let phase = |tag: &str| match tag {
        "legacy_rst" => Ok(crate::runtime_inputs::SnowPhasePartitionModel::LegacyRst),
        "harder_pomeroy_hourly" => {
            Ok(crate::runtime_inputs::SnowPhasePartitionModel::HarderPomeroyHourly)
        }
        _ => Err("active-snow hourly phase model".to_owned()),
    };
    let hourly = value
        .hourly
        .into_iter()
        .map(|x| {
            Ok(crate::hydrology::DirectSnowHourlyForcing {
                active_precipitation_m: x.values[0],
                rain_m: x.values[1],
                snowfall_m: x.values[2],
                radiation_mj_m2: x.values[3],
                air_temperature_c: x.values[4],
                cloud_fraction: x.values[5],
                phase_model: phase(&x.phase_model)?,
                rain_fraction: x.values[6],
                snow_fraction: x.values[7],
                hydrometeor_temperature_c: x.hydrometeor_temperature_c,
            })
        })
        .collect::<Result<Vec<_>, String>>()?
        .try_into()
        .map_err(|_| "active-snow hourly cardinality".to_owned())?;
    let climate = value
        .sturm_climate_class
        .map(|tag| match tag.as_str() {
            "tundra" => Ok(SnowClimateClass::Tundra),
            "taiga" => Ok(SnowClimateClass::Taiga),
            "alpine" => Ok(SnowClimateClass::Alpine),
            "maritime" => Ok(SnowClimateClass::Maritime),
            "prairie" => Ok(SnowClimateClass::Prairie),
            "ephemeral" => Ok(SnowClimateClass::Ephemeral),
            _ => Err("active-snow climate class".to_owned()),
        })
        .transpose()?;
    let albedo_model = value
        .snow_albedo_model
        .map(|tag| {
            if tag == "brock2000_temperature_age_v1" {
                Ok(crate::hydrology::SnowAlbedoModel::Brock2000TemperatureAgeV1)
            } else {
                Err("active-snow albedo model".to_owned())
            }
        })
        .transpose()?;
    let albedo_state = value
        .snow_albedo_state
        .map(|state| {
            if state.model != "brock2000_temperature_age_v1" {
                return Err("active-snow albedo state model".to_owned());
            }
            let state = crate::hydrology::SnowAlbedoState {
                model: crate::hydrology::SnowAlbedoModel::Brock2000TemperatureAgeV1,
                albedo: state.albedo,
                accumulated_positive_temperature_c_day: state
                    .accumulated_positive_temperature_c_day,
            };
            state.validate().map_err(|e| e.to_string())?;
            Ok(state)
        })
        .transpose()?;
    let longwave = match value.surface_energy.longwave.as_str() {
        "disabled" => SnowSurfaceLongwaveModel::Disabled,
        "dilley_unsworth_subcanopy_v1" => SnowSurfaceLongwaveModel::DilleyUnsworthSubcanopyV1,
        _ => return Err("active-snow longwave model".into()),
    };
    let sublimation = match value.surface_energy.sublimation.as_str() {
        "disabled" => SnowSurfaceSublimationModel::Disabled,
        "neutral_bulk_stage3_v1" => SnowSurfaceSublimationModel::NeutralBulkStage3V1,
        _ => return Err("active-snow sublimation model".into()),
    };
    let e = value.surface_energy;
    Ok(crate::hydrology::DirectActiveSnowPartitionInputs {
        hyetograph_rainfall_m: value.scalars[0],
        rst_c: value.scalars[1],
        newsnw_kg_m3: value.scalars[2],
        ssd_kg_m3: value.scalars[3],
        runtime_swe_m: value.scalars[4],
        runtime_depth_m: value.scalars[5],
        runtime_density_kg_m3: value.scalars[6],
        runtime_settle_day_count: value.scalars[7],
        liquid_water_retained_m: value.scalars[8],
        tmax_c: value.scalars[9],
        tmin_c: value.scalars[10],
        canopy_cover_fraction: value.scalars[11],
        wind_m_s: value.scalars[12],
        dewpoint_c: value.scalars[13],
        snow_melt_model: melt,
        snow_density_model: density,
        stage3_liquid_routing_model: routing,
        surface_energy_options: crate::hydrology::DirectSnowSurfaceEnergyOptions {
            longwave_model: longwave,
            sublimation_model: sublimation,
            daily_solar_radiation_mj_m2: e.values[0],
            daily_extraterrestrial_radiation_mj_m2: e.values[1],
            daylight: e.daylight,
            atmospheric_pressure_pa: e.values[2],
            turbulent_geometry: crate::hydrology::DirectSnowTurbulentGeometry {
                air_temperature_height_m: e.values[3],
                vapor_pressure_height_m: e.values[4],
                wind_speed_height_m: e.values[5],
                aerodynamic_roughness_length_m: e.values[6],
            },
            complete_carrier_shadow: e.complete_carrier_shadow,
        },
        sturm_climate_class: climate,
        sturm_day_of_year: value.sturm_day_of_year,
        coe_boundary_depth_m: value.scalars[14],
        coe_boundary_density_kg_m3: value.scalars[15],
        coe_boundary_settle_day_count: value.scalars[16],
        snow_albedo_model: albedo_model,
        snow_albedo_state: albedo_state,
        snow_layers: value.snow_layers,
        underlying_surface_albedo: value.underlying_surface_albedo,
        hourly,
    })
}

/// Private diagnostic transport for the actual provider day.  It is deliberately
/// composed from the existing restart-authority values rather than a new wire
/// schema or a provider recomputation.
#[derive(Clone, Debug, Deserialize, Serialize)]
struct ProviderCaptureV1 {
    gsi_receipt: crate::runtime_inputs::DirectGsiDailyReceiptV1,
    ending_gsi_state: crate::runtime_inputs::DirectGsiOwnerStateV1,
    forcing_receipts: Vec<crate::runtime_inputs::SnowFreeHalfHourDayReceipt>,
    beginning_cursor_canonical_json: Vec<u8>,
    ending_cursor_canonical_json: Vec<u8>,
    static_configuration: ProviderStaticConfigurationCaptureV1,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub(crate) struct ProviderStaticConfigurationCaptureV1 {
    run_id: String,
    co2_pa: f64,
    reference_height_m: f64,
    gsi_owner_configuration_sha256: String,
    destinations: Vec<ProviderDestinationCaptureV1>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
struct ProviderDestinationCaptureV1 {
    ofe_id: String,
    tile_id: String,
    wb14_configuration_sha256: String,
}

impl ProviderStaticConfigurationCaptureV1 {
    pub(crate) fn capture(
        configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    ) -> Result<Self, crate::runtime_inputs::SnowFreeHalfHourForcingError> {
        configuration.validate()?;
        Ok(Self {
            run_id: configuration.run_id.clone(),
            co2_pa: configuration.co2_pa,
            reference_height_m: configuration.reference_height_m,
            gsi_owner_configuration_sha256: configuration.gsi_owner_configuration_sha256.clone(),
            destinations: configuration
                .destinations
                .iter()
                .map(|destination| ProviderDestinationCaptureV1 {
                    ofe_id: destination.ofe_id.clone(),
                    tile_id: destination.tile_id.clone(),
                    wb14_configuration_sha256: destination.wb14_configuration_sha256.clone(),
                })
                .collect(),
        })
    }

    pub(crate) fn validate_against(
        &self,
        pinned: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    ) -> Result<(), crate::runtime_inputs::SnowFreeHalfHourForcingError> {
        pinned.validate()?;
        if self.run_id != pinned.run_id
            || self.co2_pa.to_bits() != pinned.co2_pa.to_bits()
            || self.reference_height_m.to_bits() != pinned.reference_height_m.to_bits()
            || self.gsi_owner_configuration_sha256 != pinned.gsi_owner_configuration_sha256
            || self.destinations.len() != pinned.destinations.len()
            || self
                .destinations
                .iter()
                .zip(&pinned.destinations)
                .any(|(captured, expected)| {
                    captured.ofe_id != expected.ofe_id
                        || captured.tile_id != expected.tile_id
                        || captured.wb14_configuration_sha256 != expected.wb14_configuration_sha256
                })
        {
            return Err(
                crate::runtime_inputs::SnowFreeHalfHourForcingError::Identity(
                    "diagnostic static provider configuration join",
                ),
            );
        }
        Ok(())
    }
}

/// Whole-day diagnostic identity for the provider-bound support graph.  The
/// importer validates every projected support against a reconstructed day; it
/// never treats this projection as an inverse or as a replacement for inputs.
#[derive(Clone, Debug, Deserialize, Serialize)]
struct PreparedDayCaptureV1 {
    supports: Vec<crate::snow_stage3_v11_attachment::DirectSnowStage3V11PreparedSupportRestartV2>,
}

#[cfg(any(
    feature = "persisted-restart-v1",
    feature = "restart-authority-evidence"
))]
fn capture_prepared_day(
    prepared: &crate::ValidatedPreparedStage3V11DayV1,
) -> Result<PreparedDayCaptureV1, String> {
    let supports = (0..prepared.supports().len())
        .map(|index| prepared.diagnostic_support_checkpoint_v2(index))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|error| error.to_string())?;
    if supports.len() != 48 {
        return Err("capture prepared support cardinality".into());
    }
    Ok(PreparedDayCaptureV1 { supports })
}

#[cfg(any(
    feature = "persisted-restart-v1",
    feature = "restart-authority-evidence"
))]
fn validate_prepared_day(
    capture: &PreparedDayCaptureV1,
    prepared: &crate::ValidatedPreparedStage3V11DayV1,
) -> Result<(), String> {
    if capture.supports.len() != 48 {
        return Err("captured prepared support cardinality".into());
    }
    for checkpoint in &capture.supports {
        prepared
            .diagnostic_validate_support_checkpoint_v2(checkpoint)
            .map_err(|error| error.to_string())?;
    }
    Ok(())
}

#[cfg(any(
    feature = "persisted-restart-v1",
    feature = "restart-authority-evidence"
))]
fn capture_provider_day(
    prepared: &crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
    configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
) -> Result<ProviderCaptureV1, String> {
    Ok(ProviderCaptureV1 {
        gsi_receipt: prepared.gsi_receipt().clone(),
        ending_gsi_state: prepared.gsi_receipt().ending_state.clone(),
        forcing_receipts: prepared.forcing_receipts().receipts().to_vec(),
        beginning_cursor_canonical_json: prepared
            .forcing_receipts()
            .beginning_cursor()
            .to_json_bytes()
            .map_err(|error| error.to_string())?,
        ending_cursor_canonical_json: prepared
            .forcing_receipts()
            .ending_cursor()
            .to_json_bytes()
            .map_err(|error| error.to_string())?,
        static_configuration: ProviderStaticConfigurationCaptureV1::capture(configuration)
            .map_err(|error| error.to_string())?,
    })
}

#[cfg(any(
    feature = "persisted-restart-v1",
    feature = "restart-authority-evidence"
))]
fn restore_provider_day(
    capture: ProviderCaptureV1,
    pinned_configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
) -> Result<crate::runtime_inputs::PreparedSnowFreeGsiDayV1, String> {
    capture
        .static_configuration
        .validate_against(pinned_configuration)
        .map_err(|error| error.to_string())?;
    let ending_gsi =
        crate::runtime_inputs::restart_authority_restore_gsi_state(&capture.ending_gsi_state)
            .map_err(|error| error.to_string())?;
    let beginning_day_index = usize::try_from(capture.gsi_receipt.day_index)
        .map_err(|_| "captured provider day index width")?;
    let beginning_cursor = crate::runtime_inputs::SnowFreeHalfHourProviderCursor::restore_json(
        &capture.beginning_cursor_canonical_json,
        pinned_configuration,
        beginning_day_index,
    )
    .map_err(|error| error.to_string())?;
    let ending_cursor = crate::runtime_inputs::SnowFreeHalfHourProviderCursor::restore_json(
        &capture.ending_cursor_canonical_json,
        pinned_configuration,
        beginning_day_index
            .checked_add(1)
            .ok_or("captured provider ending day overflow")?,
    )
    .map_err(|error| error.to_string())?;
    crate::runtime_inputs::restart_authority_prepare_from_restored_receipts(
        capture.gsi_receipt,
        ending_gsi,
        capture.forcing_receipts,
        beginning_cursor,
        ending_cursor,
        pinned_configuration,
    )
    .map_err(|error| error.to_string())
}

fn is_target(day: usize, interval: usize, support: openwepp_coupled_time::TimeSupport) -> bool {
    day == B01_DAY_INDEX
        && interval == B01_INTERVAL_INDEX
        && support.start_ns().get() == B01_CHILD_START_NS
        && support.end_ns().get() == B01_CHILD_END_NS
}

#[cfg(test)]
#[test]
fn b01_pre_child_selector_requires_every_exact_coordinate() {
    let target = TimeSupport::new(
        openwepp_coupled_time::ModelTimeNs::new(B01_CHILD_START_NS),
        openwepp_coupled_time::ModelTimeNs::new(B01_CHILD_END_NS),
    )
    .expect("target support");
    assert!(is_target(B01_DAY_INDEX, B01_INTERVAL_INDEX, target));
    assert!(!is_target(B01_DAY_INDEX - 1, B01_INTERVAL_INDEX, target));
    assert!(!is_target(B01_DAY_INDEX, B01_INTERVAL_INDEX - 1, target));
    assert!(!is_target(
        B01_DAY_INDEX,
        B01_INTERVAL_INDEX,
        TimeSupport::new(
            openwepp_coupled_time::ModelTimeNs::new(B01_CHILD_START_NS - 1),
            openwepp_coupled_time::ModelTimeNs::new(B01_CHILD_END_NS),
        )
        .expect("wrong-start support"),
    ));
    assert!(!is_target(
        B01_DAY_INDEX,
        B01_INTERVAL_INDEX,
        TimeSupport::new(
            openwepp_coupled_time::ModelTimeNs::new(B01_CHILD_START_NS),
            openwepp_coupled_time::ModelTimeNs::new(B01_CHILD_END_NS + 1),
        )
        .expect("wrong-end support"),
    ));
}

#[derive(Clone, Copy)]
pub(crate) struct SnowFreePreChildHistoryV1<'a> {
    pub owner_joins: &'a [crate::snow_stage3_v11_attachment::Stage3CoupledSubslabReceiptV1],
    pub event_groups: &'a [crate::snow_stage3_v11_attachment::Stage3V11TerminalEventGroupV1],
    pub current_stage3: &'a BTreeMap<u32, crate::DirectSnowStage3PersistentState>,
    pub current_snow_enthalpy_material_owner: Option<
        &'a crate::snow_stage3_v11_snow_enthalpy_carry::AuthenticatedCoveredSnowMaterialOwnerV1,
    >,
    pub pending_terminal_parcels:
        &'a BTreeMap<openwepp_coupled_time::Digest32, crate::DirectSnowStage3V11TerminalParcel>,
}

#[derive(Clone, Copy)]
pub(crate) enum PreChildCapturePhaseV1<'a> {
    Covered,
    SnowFree {
        history: SnowFreePreChildHistoryV1<'a>,
        validated_native_inactive_wb14_prefix:
            Option<&'a crate::direct_runtime::ValidatedNativeInactiveWb14PrefixV1>,
        ending_snow_owner_bytes: &'a [u8],
        deferred_native_v2_soil_custody:
            Option<&'a crate::v9_real_consumer_shadow::DeferredNativeV2SoilCustodyV1>,
    },
}

pub(crate) struct PreChildContext<'a> {
    pub phase: PreChildCapturePhaseV1<'a>,
    pub context: &'a DirectSnowStage3V11StaticContext,
    pub parent: &'a V11ParentTransaction,
    pub consumer: &'a DirectV10RealConsumerShadow,
    pub clock: &'a CoupledClockStateV1,
    /// The exact provider-bound support selected by the production day loop.
    /// It is captured as constructor operands; import re-seals it against an
    /// independently restored provider day and never trusts these bytes alone.
    pub prepared_support: Option<&'a crate::DirectSnowStage3V11PreparedSupport>,
    pub beginning_stage3: &'a BTreeMap<u32, crate::DirectSnowStage3PersistentState>,
    pub beginning_snow_enthalpy_material_owner: Option<
        &'a crate::snow_stage3_v11_snow_enthalpy_carry::AuthenticatedCoveredSnowMaterialOwnerV1,
    >,
    pub support: TimeSupport,
    pub reduction: &'a ConstraintReductionReceiptV1,
    pub ledger: &'a LedgerEntryV1,
    pub receipt: &'a AcceptedSlabReceiptV1,
    pub binding: &'a crate::direct_runtime::DirectWb14CoupledChildBindingV1,
    pub pending_terminal_parcels:
        &'a BTreeMap<openwepp_coupled_time::Digest32, crate::DirectSnowStage3V11TerminalParcel>,
    pub forcing_receipt: openwepp_coupled_time::Digest32,
    pub day: usize,
    pub interval: usize,
}

/// Producer-local test oracle inputs, populated before the recorder context is
/// constructed so a recorder wiring mistake cannot define its own expectation.
#[cfg(test)]
pub(crate) struct PreChildProducerSnapshotInputsV1<'a> {
    pub phase: PreChildCapturePhaseV1<'a>,
    pub context: &'a DirectSnowStage3V11StaticContext,
    pub parent: &'a V11ParentTransaction,
    pub consumer: &'a DirectV10RealConsumerShadow,
    pub clock: &'a CoupledClockStateV1,
    pub prepared_support: Option<&'a crate::DirectSnowStage3V11PreparedSupport>,
    pub beginning_stage3: &'a BTreeMap<u32, crate::DirectSnowStage3PersistentState>,
    pub beginning_snow_enthalpy_material_owner: Option<
        &'a crate::snow_stage3_v11_snow_enthalpy_carry::AuthenticatedCoveredSnowMaterialOwnerV1,
    >,
    pub support: TimeSupport,
    pub reduction: &'a ConstraintReductionReceiptV1,
    pub ledger: &'a LedgerEntryV1,
    pub receipt: &'a AcceptedSlabReceiptV1,
    pub binding: &'a crate::direct_runtime::DirectWb14CoupledChildBindingV1,
    pub pending_terminal_parcels:
        &'a BTreeMap<openwepp_coupled_time::Digest32, crate::DirectSnowStage3V11TerminalParcel>,
    pub forcing_receipt: openwepp_coupled_time::Digest32,
}

fn capture_soil_trial_v2(
    trial: &openwepp_land_surface_energy::SoilThermalTrialStateV2,
) -> serde_json::Value {
    serde_json::json!({
        "transaction_id": trial.transaction_id(),
        "predecessor_transaction_id": trial.predecessor_transaction_id(),
        "support_start_ns": trial.support_start_ns(),
        "support_end_ns": trial.support_end_ns(),
        "beginning_state_sha256": trial.beginning_state_sha256(),
        "accepted_predecessor_receipt_chain_sha256": trial.accepted_predecessor_receipt_chain_sha256(),
        "unpublished_predecessor_trial_sha256": trial.unpublished_predecessor_trial_sha256(),
        "numerical_coordinate_set_sha256": trial.numerical_coordinate_set_sha256(),
        "numerical_coordinate_authority_sha256": trial.numerical_coordinate_authority_sha256(),
        "ending_state": trial.ending_state(),
        "layer_credits": trial.layer_credits(),
        "unpublished_trial_sha256": trial.unpublished_trial_sha256(),
    })
}

fn capture_deferred_native_v2_soil_custody(
    custody: Option<&crate::v9_real_consumer_shadow::DeferredNativeV2SoilCustodyV1>,
) -> Result<Option<serde_json::Value>, String> {
    custody
        .map(|custody| {
            let candidate = custody
                .candidate()
                .v2()
                .map_err(|error| error.to_string())?;
            let continuation = custody.continuation().map(|continuation| {
                serde_json::json!({
                    "original_beginning_owner": continuation.original_prepared().beginning_owner(),
                    "physical_trial": capture_soil_trial_v2(continuation.physical_trial()),
                    "accumulated_operands": continuation.accumulated_operands(),
                    "ordered_layer_credit_chain": continuation.diagnostic_layer_credit_chain(),
                })
            });
            Ok(serde_json::json!({
                "posture": "reconstructible_operands_not_installable_capability",
                "candidate": capture_soil_trial_v2(candidate),
                "continuation": continuation,
            }))
        })
        .transpose()
}

/// Immutable configuration and identity authority recovered from the pinned
/// original seed.  This is deliberately private to the diagnostic reader:
/// it does not create a restart wire or an alternative production bootstrap.
#[cfg(all(test, feature = "persisted-restart-v1"))]
#[derive(Clone, Debug)]
struct PinnedSeedConfigurationV1 {
    vegetation: openwepp_vegetation::VegetationConfiguration,
    lse: openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    calendar: openwepp_coupled_time::Digest32,
    controller_policy: openwepp_coupled_time::Digest32,
    run_identity: openwepp_coupled_time::Digest32,
    topology_identity: openwepp_coupled_time::Digest32,
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn extract_pinned_seed_configuration_v1(
    seed_path: &std::path::Path,
) -> Result<PinnedSeedConfigurationV1, String> {
    let seed: serde_json::Value =
        serde_json::from_slice(&std::fs::read(seed_path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    let required = |key: &str| {
        seed.get(key)
            .cloned()
            .ok_or_else(|| format!("pinned seed missing {key}"))
    };
    let checkpoint = required("checkpoint")?;
    let checkpoint_field = |key: &str| {
        checkpoint
            .get(key)
            .cloned()
            .ok_or_else(|| format!("pinned seed checkpoint missing {key}"))
    };
    Ok(PinnedSeedConfigurationV1 {
        vegetation: serde_json::from_value(required("vegetation_configuration")?)
            .map_err(|error| error.to_string())?,
        lse: serde_json::from_value(required("lse_configuration")?)
            .map_err(|error| error.to_string())?,
        calendar: serde_json::from_value(required("calendar_receipt")?)
            .map_err(|error| error.to_string())?,
        controller_policy: serde_json::from_value(required("controller_policy")?)
            .map_err(|error| error.to_string())?,
        run_identity: serde_json::from_value(checkpoint_field("run_identity_sha256")?)
            .map_err(|error| error.to_string())?,
        topology_identity: serde_json::from_value(checkpoint_field("topology_sha256")?)
            .map_err(|error| error.to_string())?,
    })
}

fn capture_direct_run_constructor_inputs(
    inputs: &crate::DirectRunConstructorInputs,
) -> serde_json::Value {
    let lanes = inputs
        .lanes
        .iter()
        .map(|lane| {
            serde_json::json!({
                "lane_id": lane.lane_id, "upstream_lane_id": lane.upstream_lane_id,
                "downstream_lane_id": lane.downstream_lane_id,
                "upstream_area_ratio": lane.upstream_area_ratio, "area_m2": lane.area_m2,
                "runoff_publication_q_scale": lane.runoff_publication_q_scale,
                "runoff_publication_qofe_scale": lane.runoff_publication_qofe_scale,
                "runoff_publication_efflen_m": lane.runoff_publication_efflen_m,
                "runoff_publication_cumulative_length_m": lane.runoff_publication_cumulative_length_m,
                "runoff_publication_ofe_length_m": lane.runoff_publication_ofe_length_m,
                "water": [lane.water.soil_water_m, lane.water.infiltration_m, lane.water.runoff_m, lane.water.evapotranspiration_m, lane.water.drainage_m, lane.water.lateral_flow_m],
                "transfer": { "surface_carry_m": lane.transfer.surface_carry_m, "surface_hourly_weights": lane.transfer.surface_hourly_weights, "lateral_carry_m": lane.transfer.lateral_carry_m, "upstream_flow_m": lane.transfer.upstream_flow_m, "subsurface_input_m": lane.transfer.subsurface_input_m },
                "publication": constructor_encoder::Encode::encode(&lane.publication), "subsurface_layers": constructor_encoder::Encode::encode(&lane.subsurface_layers),
                "evapotranspiration_stage_state": constructor_encoder::Encode::encode(&lane.evapotranspiration_stage_state),
                "plant_growth_state": constructor_encoder::Encode::encode(&lane.plant_growth_state), "plant_water_stress": lane.plant_water_stress,
                "winter_snow": constructor_encoder::Encode::encode(&crate::DirectSnowRuntimeCarry::from(lane.winter_column.snow.clone())),
                "winter_frost": constructor_encoder::Encode::encode(&crate::DirectFrostRuntimeCarry::from(lane.winter_column.frost.clone())),
                "snow_runtime_carry": constructor_encoder::Encode::encode(&lane.snow_runtime_carry), "frost_runtime_carry": constructor_encoder::Encode::encode(&lane.frost_runtime_carry),
                "day_inputs": constructor_encoder::Encode::encode(&lane.day_inputs),
            })
        })
        .collect::<Vec<_>>();
    serde_json::json!({
        "identity": { "run_id": inputs.identity.run_id, "hillslope_id": inputs.identity.hillslope_id, "lane_count": inputs.identity.lane_count, "day_count": inputs.identity.day_count },
        "phase_plan_ranks": inputs.phase_plan.phases().iter().map(|phase| phase.rank()).collect::<Vec<_>>(),
        "lanes": lanes,
    })
}

struct CapturedPreChildPhaseV1 {
    kind: &'static str,
    phase_name: &'static str,
    constraint_source_owner_id: &'static str,
    prepared_support: Option<serde_json::Value>,
    diagnostics: serde_json::Value,
}

fn capture_pre_child_phase(
    phase: PreChildCapturePhaseV1<'_>,
    prepared_support: Option<&crate::DirectSnowStage3V11PreparedSupport>,
    parent_support: TimeSupport,
    surface_configuration: &[u8],
) -> Result<CapturedPreChildPhaseV1, String> {
    match phase {
        PreChildCapturePhaseV1::Covered => Ok(CapturedPreChildPhaseV1 {
            kind: "b01_wb14_pre_child_current_context_v1",
            phase_name: "covered",
            constraint_source_owner_id: "v11-snow-covered-real-consumer",
            prepared_support: prepared_support
                .map(capture_prepared_support)
                .transpose()?
                .map(serde_json::to_value)
                .transpose()
                .map_err(|error| error.to_string())?,
            diagnostics: serde_json::Value::Null,
        }),
        PreChildCapturePhaseV1::SnowFree {
            history,
            validated_native_inactive_wb14_prefix,
            ending_snow_owner_bytes,
            deferred_native_v2_soil_custody,
        } => {
            let prepared_support =
                prepared_support.ok_or("snow-free capture missing transformed prepared support")?;
            let deferred_native_v2_soil_custody =
                capture_deferred_native_v2_soil_custody(deferred_native_v2_soil_custody)?;
            let owner_joins =
                crate::snow_stage3_v11_attachment::diagnostic_coupled_subslab_receipts_value_v2(
                    history.owner_joins,
                )?;
            Ok(CapturedPreChildPhaseV1 {
                kind: "b01_wb14_snow_free_pre_child_current_context_v1",
                phase_name: "snow_free",
                constraint_source_owner_id: "v11-real-consumer",
                prepared_support: Some(capture_snow_free_prepared_support(prepared_support)?),
                diagnostics: serde_json::json!({
                    "ordered_owner_joins": owner_joins,
                    "ordered_owner_join_support_liquid_custody_v2": history.owner_joins.iter().map(|receipt| receipt.support_liquid_custody_v2()).collect::<Vec<_>>(),
                    "ordered_event_groups": history.event_groups,
                    "ordered_event_group_terminal_liquid_custody_v2": history.event_groups.iter().map(|group| group.terminal_receiver_custody_v2()).collect::<Vec<_>>(),
                    "prefix_validation_parent_support": parent_support,
                    "prefix_validation_surface_configuration_canonical_json": surface_configuration,
                    "validated_native_inactive_wb14_prefix": validated_native_inactive_wb14_prefix,
                    "current_stage3": history.current_stage3,
                    "current_snow_enthalpy_material_owner": history.current_snow_enthalpy_material_owner,
                    "pending_terminal_parcels": history.pending_terminal_parcels,
                    "ending_snow_owner_canonical_bytes": ending_snow_owner_bytes,
                    "deferred_native_v2_soil_custody": deferred_native_v2_soil_custody,
                    "history_posture": "actual_ordered_prefix_inputs_and_result; no fabricated receipts or installable capability",
                }),
            })
        }
    }
}

fn capture_coupled_clock_restart(clock: &CoupledClockStateV1) -> Result<Vec<u8>, String> {
    CoupledTimeRestartV2::new(
        digest_bytes(CLOCK_MODEL_DOMAIN),
        digest_bytes(CLOCK_AUTHORITY_DOMAIN),
        clock.clone(),
        DiagnosticReductionV1::new(CLOCK_REDUCTION_ID.into(), "dimensionless".into())
            .map_err(|error| error.to_string())?,
        None,
        Vec::new(),
    )
    .map_err(|error| error.to_string())?
    .to_canonical_json()
    .map_err(|error| error.to_string())
}

fn capture_row(input: &PreChildContext<'_>) -> Result<serde_json::Value, String> {
    let PreChildContext {
        phase,
        context,
        parent,
        consumer,
        clock,
        prepared_support,
        beginning_stage3,
        beginning_snow_enthalpy_material_owner,
        support,
        reduction,
        ledger,
        receipt,
        binding,
        pending_terminal_parcels,
        forcing_receipt,
        day,
        interval,
    } = input;
    let restart = capture_coupled_clock_restart(clock)?;
    let owners = consumer
        .canonical_v11_parent_owner_state_bytes()
        .map_err(|e| e.to_string())?;
    let clock_owners = clock
        .owners()
        .iter()
        .map(|owner| (owner.owner_id().to_owned(), owner.state_bytes().to_vec()))
        .collect::<BTreeMap<_, _>>();
    let parent_checkpoint = serde_json::to_vec(&parent.checkpoint()).map_err(|e| e.to_string())?;
    let receipt = serde_json::to_vec(receipt).map_err(|e| e.to_string())?;
    let reduction = serde_json::to_vec(reduction).map_err(|e| e.to_string())?;
    let ledger = serde_json::to_vec(ledger).map_err(|e| e.to_string())?;
    let provider = serde_json::to_vec(consumer.provider_cursor()).map_err(|e| e.to_string())?;
    let vegetation =
        serde_json::to_vec(&context.vegetation_configuration).map_err(|e| e.to_string())?;
    let lse = serde_json::to_vec(consumer.lse_configuration()).map_err(|e| e.to_string())?;
    let terminal_custody =
        serde_json::to_vec(pending_terminal_parcels).map_err(|e| e.to_string())?;
    let native_lane_maps = consumer.diagnostic_native_lane_maps_v1();
    let native_soil = consumer
        .diagnostic_native_soil_v2()
        .map_err(|error| error.to_string())?;
    let surface_configuration = context
        .surface_liquid_configuration
        .canonical_bytes()
        .map_err(|error| error.to_string())?;
    let native_hydrology_constructor_inputs = consumer
        .diagnostic_hydrology_constructor_inputs_v1()
        .ok_or("captured native hydrology constructor pin missing")?;
    let hydrology_frame_dynamic = capture_direct_run_frame_dynamic(
        consumer.diagnostic_hydrology_frame_v1(),
        native_hydrology_constructor_inputs.as_ref(),
        &context.surface_liquid_configuration,
    )?;
    let native_consumer_constructor_operands = consumer
        .diagnostic_native_consumer_constructor_operands_v1()
        .map_err(|error| error.to_string())?;
    let phase = capture_pre_child_phase(
        *phase,
        *prepared_support,
        clock.parent_support(),
        &surface_configuration,
    )?;
    let beginning_stage3 = serde_json::to_vec(beginning_stage3).map_err(|e| e.to_string())?;
    if let Some(owner) = beginning_snow_enthalpy_material_owner {
        owner.validate().map_err(|error| error.to_string())?;
    }
    Ok(serde_json::json!({
        "kind":phase.kind, "capture_phase":phase.phase_name, "day_index":day, "interval_index":interval,
        "support":support, "parent_support":clock.parent_support(), "accepted_until":clock.accepted_until(),
        "parent_checkpoint_canonical_json":parent_checkpoint, "complete_owner_canonical_bytes":owners,
        "clock_complete_owner_canonical_bytes":clock_owners,
        "coupled_clock_restart_canonical_json":restart, "coupled_clock_restart_model_sha256":digest_bytes(CLOCK_MODEL_DOMAIN), "coupled_clock_restart_authority_sha256":digest_bytes(CLOCK_AUTHORITY_DOMAIN), "coupled_clock_restart_policy_sha256":context.controller_policy,
        "vegetation_configuration_canonical_json":vegetation, "lse_configuration_canonical_json":lse,
        "surface_liquid_configuration_canonical_json":surface_configuration,
        "constraint_reduction_canonical_json":reduction, "complete_owner_ledger_canonical_json":ledger, "provisional_receipt_canonical_json":receipt,
        "provisional_constructor_inputs":{"constraint_source_owner_id":phase.constraint_source_owner_id,"constraint_class":"hard_boundary","forcing_receipt":forcing_receipt,"calendar_receipt":context.calendar_receipt,"controller_policy":context.controller_policy,"ledger_flux_id":"complete-owner-custody","ledger_units":"canonical-owner-state","ledger_child_support_start_ns":support.start_ns().get(),"ledger_child_support_end_ns":support.end_ns().get()},
        "coupled_binding":{"proposed_upper_bound_s_bits":binding.proposed_upper_bound_s_bits,"coupled_parent_transaction_sha256":binding.coupled_parent_transaction_sha256,"accepted_slab_sha256":binding.accepted_slab_sha256,"parent_beginning_complete_owner_set_sha256":binding.parent_beginning_complete_owner_set_sha256,"parent_support_start_ns":binding.parent_support_start_ns,"parent_support_end_ns":binding.parent_support_end_ns,"child_support_start_ns":binding.child_support_start_ns,"child_support_end_ns":binding.child_support_end_ns},
        "provider_cursor_canonical_json":provider, "terminal_parcels_produced_unconsumed_canonical_json":terminal_custody, "static_run_identity":context.run_identity, "static_topology_identity":context.topology_identity,
        "prepared_support_constructor_operands":phase.prepared_support,
        "native_lane_map_constructor_operands":native_lane_maps,
        "native_soil_v2_constructor_operands":native_soil,
        "native_hydrology_frame_dynamic_constructor_operands":hydrology_frame_dynamic,
        "native_hydrology_constructor_inputs":capture_direct_run_constructor_inputs(native_hydrology_constructor_inputs.as_ref()),
        "native_consumer_constructor_operands":native_consumer_constructor_operands,
        "beginning_stage3_canonical_json":beginning_stage3,
        "beginning_snow_enthalpy_material_owner":beginning_snow_enthalpy_material_owner,
        "phase_diagnostics":phase.diagnostics,
        "capture_posture":"before physical ingress; diagnostic no-publication wrapper"
    }))
}

/// Record the actual provider-bound day once, before its supports enter the
/// executor.  The pre-child row later selects one support from this complete
/// ordered producer bundle; neither row is construction authority by itself.
#[cfg(any(
    feature = "persisted-restart-v1",
    feature = "restart-authority-evidence"
))]
pub(crate) fn record_prepared_day_context(
    day: &crate::ValidatedPreparedStage3V11DayV1,
    attachment: &crate::DirectSnowStage3V11ShadowAttachment,
) {
    if !crate::snow_accuracy_observer::physical_global_enabled() || day.day_index() != B01_DAY_INDEX
    {
        return;
    }
    let context = &attachment.static_context;
    let recorded = capture_prepared_day_row(day, attachment);
    match recorded {
        Ok(row) => crate::snow_accuracy_observer::record(row),
        Err(detail) => crate::snow_accuracy_observer::record(serde_json::json!({
            "kind":"b01_wb14_prepared_day_current_context_capture_error_v1",
            "day_index":day.day_index(),
            "static_run_identity":context.run_identity,
            "static_topology_identity":context.topology_identity,
            "detail":detail
        })),
    }
}

#[cfg(any(
    feature = "persisted-restart-v1",
    feature = "restart-authority-evidence"
))]
fn capture_prepared_day_row(
    day: &crate::ValidatedPreparedStage3V11DayV1,
    attachment: &crate::DirectSnowStage3V11ShadowAttachment,
) -> Result<serde_json::Value, String> {
    let context = &attachment.static_context;
    let committed_bootstrap = &attachment.committed.real_consumer;
    let (provider, supports) = day.diagnostic_capture_parts_v1();
    if supports.len() != 48 {
        return Err("captured prepared day support cardinality".to_owned());
    }
    let provider = capture_provider_day(
        provider,
        committed_bootstrap.provider_static_configuration(),
    )?;
    attachment
        .archived_receipt_prefix_v1()
        .validate()
        .map_err(|error| error.to_string())?;
    let snow_enthalpy_material_residents = attachment
        .restart_authority_snow_enthalpy_material_residents_v1()
        .map_err(|error| error.to_string())?;
    let committed_clock_restart = CoupledTimeRestartV2::new(
        digest_bytes(CLOCK_MODEL_DOMAIN),
        digest_bytes(CLOCK_AUTHORITY_DOMAIN),
        attachment.committed.coupled_clock.clone(),
        DiagnosticReductionV1::new(CLOCK_REDUCTION_ID.into(), "dimensionless".into())
            .map_err(|error| error.to_string())?,
        None,
        Vec::new(),
    )
    .map_err(|error| error.to_string())?
    .to_canonical_json()
    .map_err(|error| error.to_string())?;
    let native_bootstrap_lane_maps = committed_bootstrap.diagnostic_native_lane_maps_v1();
    let native_bootstrap_soil = committed_bootstrap
        .diagnostic_native_soil_v2()
        .map_err(|error| error.to_string())?;
    let supports = supports
        .iter()
        .map(capture_prepared_support)
        .collect::<Result<Vec<_>, _>>()?;
    Ok(serde_json::json!({
        "kind":"b01_wb14_prepared_day_current_context_v1",
        "day_index":day.day_index(),
        "static_run_identity":context.run_identity,
        "static_topology_identity":context.topology_identity,
        "provider_constructor_operands":provider,
        "ordered_support_constructor_operands":supports,
        "native_committed_bootstrap_lane_map_constructor_operands":native_bootstrap_lane_maps,
        "native_committed_bootstrap_soil_v2_constructor_operands":native_bootstrap_soil,
        "committed_next_parent_sequence":attachment.committed.next_parent_sequence,
        "committed_clock_restart_canonical_json":committed_clock_restart,
        "committed_receipt_tail_count":attachment.committed.receipt_chain.len(),
        "archived_receipt_prefix":attachment.archived_receipt_prefix_v1(),
        "snow_enthalpy_material_residents":snow_enthalpy_material_residents,
        "capture_posture":"before physical ingress; diagnostic no-publication wrapper"
    }))
}

#[cfg(test)]
pub(crate) fn capture_row_for_test(
    input: &PreChildContext<'_>,
) -> Result<serde_json::Value, String> {
    capture_row(input)
}

#[cfg(all(
    test,
    any(
        feature = "persisted-restart-v1",
        feature = "restart-authority-evidence"
    )
))]
pub(crate) fn capture_prepared_day_row_for_test(
    day: &crate::ValidatedPreparedStage3V11DayV1,
    attachment: &crate::DirectSnowStage3V11ShadowAttachment,
) -> Result<serde_json::Value, String> {
    capture_prepared_day_row(day, attachment)
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum PreChildRecorderTestModeV1 {
    Disabled,
    ProductionNonTargetObserverEnabled,
    EnabledCovered,
    ForcedCoveredCaptureFailure,
    EnabledSnowFree,
    ForcedSnowFreeCaptureFailure,
    ForcedSnowFreeWrongPhaseFailure,
    ForcedSnowFreeRequiredOmissionFailure,
}

#[cfg(test)]
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct PreChildRecorderTestAuditV1 {
    pub producer_calls: usize,
    pub live_inputs: Vec<serde_json::Value>,
    pub recorded_rows: Vec<serde_json::Value>,
}

#[cfg(test)]
struct PreChildRecorderTestStateV1 {
    mode: PreChildRecorderTestModeV1,
    producer_recorded: bool,
    selected_once: bool,
    audit: PreChildRecorderTestAuditV1,
}

#[cfg(test)]
std::thread_local! {
    static PRE_CHILD_RECORDER_TEST_STATE_V1: std::cell::RefCell<Option<PreChildRecorderTestStateV1>> = const { std::cell::RefCell::new(None) };
}

#[cfg(test)]
pub(crate) fn begin_pre_child_recorder_test_audit_v1(mode: PreChildRecorderTestModeV1) {
    PRE_CHILD_RECORDER_TEST_STATE_V1.with(|slot| {
        *slot.borrow_mut() = Some(PreChildRecorderTestStateV1 {
            mode,
            producer_recorded: false,
            selected_once: false,
            audit: PreChildRecorderTestAuditV1::default(),
        });
    });
}

#[cfg(test)]
pub(crate) fn pre_child_recorder_test_observer_active_v1() -> bool {
    PRE_CHILD_RECORDER_TEST_STATE_V1.with(|slot| slot.borrow().is_some())
}

#[cfg(test)]
pub(crate) fn take_pre_child_recorder_test_audit_v1() -> PreChildRecorderTestAuditV1 {
    PRE_CHILD_RECORDER_TEST_STATE_V1
        .with(|slot| slot.borrow_mut().take())
        .map_or_else(PreChildRecorderTestAuditV1::default, |state| state.audit)
}

#[cfg(test)]
fn test_recorder_selection_v1(
    phase: PreChildCapturePhaseV1<'_>,
) -> Option<PreChildRecorderTestModeV1> {
    PRE_CHILD_RECORDER_TEST_STATE_V1.with(|slot| {
        let mut slot = slot.borrow_mut();
        let state = slot.as_mut()?;
        let phase_matches = matches!(
            (state.mode, phase),
            (
                PreChildRecorderTestModeV1::EnabledCovered
                    | PreChildRecorderTestModeV1::ForcedCoveredCaptureFailure,
                PreChildCapturePhaseV1::Covered,
            ) | (
                PreChildRecorderTestModeV1::EnabledSnowFree
                    | PreChildRecorderTestModeV1::ForcedSnowFreeCaptureFailure
                    | PreChildRecorderTestModeV1::ForcedSnowFreeWrongPhaseFailure
                    | PreChildRecorderTestModeV1::ForcedSnowFreeRequiredOmissionFailure,
                PreChildCapturePhaseV1::SnowFree { .. }
            )
        );
        if !phase_matches || state.selected_once {
            return None;
        }
        state.selected_once = true;
        Some(state.mode)
    })
}

#[cfg(not(test))]
fn test_recorder_selection_v1(_: PreChildCapturePhaseV1<'_>) -> Option<()> {
    None
}

#[cfg(test)]
fn record_test_recorder_result_v1(_input: &PreChildContext<'_>, row: &serde_json::Value) {
    PRE_CHILD_RECORDER_TEST_STATE_V1.with(|slot| {
        if let Some(state) = slot.borrow_mut().as_mut() {
            state.audit.recorded_rows.push(row.clone());
        }
    });
}

#[cfg(test)]
fn capture_test_direct_run_constructor_inputs_raw(
    inputs: &crate::DirectRunConstructorInputs,
) -> serde_json::Value {
    let lanes = inputs
        .lanes
        .iter()
        .map(|lane| {
            serde_json::json!({
                "lane_id": lane.lane_id, "upstream_lane_id": lane.upstream_lane_id,
                "downstream_lane_id": lane.downstream_lane_id,
                "upstream_area_ratio": lane.upstream_area_ratio, "area_m2": lane.area_m2,
                "runoff_publication_q_scale": lane.runoff_publication_q_scale,
                "runoff_publication_qofe_scale": lane.runoff_publication_qofe_scale,
                "runoff_publication_efflen_m": lane.runoff_publication_efflen_m,
                "runoff_publication_cumulative_length_m": lane.runoff_publication_cumulative_length_m,
                "runoff_publication_ofe_length_m": lane.runoff_publication_ofe_length_m,
                "water": [lane.water.soil_water_m, lane.water.infiltration_m, lane.water.runoff_m, lane.water.evapotranspiration_m, lane.water.drainage_m, lane.water.lateral_flow_m],
                "transfer": { "surface_carry_m": lane.transfer.surface_carry_m, "surface_hourly_weights": lane.transfer.surface_hourly_weights, "lateral_carry_m": lane.transfer.lateral_carry_m, "upstream_flow_m": lane.transfer.upstream_flow_m, "subsurface_input_m": lane.transfer.subsurface_input_m },
                "publication": lane.publication, "subsurface_layers": lane.subsurface_layers,
                "evapotranspiration_stage_state": lane.evapotranspiration_stage_state,
                "plant_growth_state": lane.plant_growth_state, "plant_water_stress": lane.plant_water_stress,
                "winter_snow": crate::DirectSnowRuntimeCarry::from(lane.winter_column.snow.clone()),
                "winter_frost": crate::DirectFrostRuntimeCarry::from(lane.winter_column.frost.clone()),
                "snow_runtime_carry": lane.snow_runtime_carry, "frost_runtime_carry": lane.frost_runtime_carry,
                "day_inputs": lane.day_inputs,
            })
        })
        .collect::<Vec<_>>();
    serde_json::json!({
        "identity": { "run_id": inputs.identity.run_id, "hillslope_id": inputs.identity.hillslope_id, "lane_count": inputs.identity.lane_count, "day_count": inputs.identity.day_count },
        "phase_plan_ranks": inputs.phase_plan.phases().iter().map(|phase| phase.rank()).collect::<Vec<_>>(),
        "lanes": lanes,
    })
}

#[cfg(test)]
fn assert_constructor_encoder_fixture_representation_v1() {
    let identity = crate::DirectRunIdentity::new(41, 7, 1, 1).expect("identity");
    let mut inputs = crate::DirectRunConstructorInputs::new(
        identity,
        vec![crate::DirectLaneConstructorInputs::from_topology(0, 1, 1).expect("lane")],
    );
    let day = &mut inputs.lanes[0].day_inputs[0];
    day.annual_growth_inputs.active_action = crate::DirectGrowthAction::PlantingReset;
    day.decomposition_inputs.active_action = crate::DirectDecompositionAction::Herbicide;
    let encoded = capture_direct_run_constructor_inputs(&inputs);
    let independent = capture_test_direct_run_constructor_inputs_raw(&inputs);
    assert_eq!(
        encoded, independent,
        "private encoder must match Serde's existing wire representation"
    );
    let day = &encoded["lanes"][0]["day_inputs"][0];
    assert_eq!(
        day["annual_growth_inputs"]["active_action"],
        serde_json::json!("planting_reset")
    );
    assert_eq!(
        day["decomposition_inputs"]["active_action"],
        serde_json::json!("herbicide")
    );
    assert_eq!(
        constructor_encoder::Encode::encode(
            &crate::hydrology::SnowAlbedoModel::Brock2000TemperatureAgeV1
        ),
        serde_json::json!("brock2000_temperature_age_v1")
    );
}

#[cfg(test)]
fn assert_growth_encoder_representation_v1() {
    for action in [
        crate::DirectGrowthAction::None,
        crate::DirectGrowthAction::PrePlantSkip,
        crate::DirectGrowthAction::PlantingReset,
        crate::DirectGrowthAction::HarvestReset,
        crate::DirectGrowthAction::StopReset,
        crate::DirectGrowthAction::Cut,
        crate::DirectGrowthAction::Grazing,
        crate::DirectGrowthAction::TypedStateOverride,
    ] {
        assert_eq!(
            constructor_encoder::Encode::encode(&action),
            serde_json::to_value(action).expect("growth serde")
        );
    }
    for context in [
        crate::DirectGrowthActiveContext::Inactive,
        crate::DirectGrowthActiveContext::AnnualOrFallow {
            active_slot_index: 2,
            active_crop_slot_index: 3,
            runtime_day_of_year: 141,
        },
        crate::DirectGrowthActiveContext::Perennial {
            active_slot_index: 5,
            active_crop_slot_index: 7,
            runtime_day_of_year: 241,
        },
        crate::DirectGrowthActiveContext::Missing,
        crate::DirectGrowthActiveContext::Ambiguous,
    ] {
        assert_eq!(
            constructor_encoder::Encode::encode(&context),
            serde_json::to_value(context).expect("growth active context serde")
        );
    }
}

#[cfg(test)]
fn assert_decomposition_encoder_representation_v1() {
    for action in [
        crate::DirectDecompositionAction::None,
        crate::DirectDecompositionAction::Herbicide,
        crate::DirectDecompositionAction::Burn,
        crate::DirectDecompositionAction::Silage,
        crate::DirectDecompositionAction::Cut,
        crate::DirectDecompositionAction::Remove,
        crate::DirectDecompositionAction::Grazing,
    ] {
        assert_eq!(
            constructor_encoder::Encode::encode(&action),
            serde_json::to_value(action).expect("decomposition serde")
        );
    }
    for context in [
        crate::DirectDecompositionActiveContext::Inactive,
        crate::DirectDecompositionActiveContext::AnnualOrFallow {
            active_slot_index: 11,
            active_crop_slot_index: 13,
            runtime_day_of_year: 151,
        },
        crate::DirectDecompositionActiveContext::Perennial {
            active_slot_index: 17,
            active_crop_slot_index: 19,
            runtime_day_of_year: 251,
        },
        crate::DirectDecompositionActiveContext::Missing,
        crate::DirectDecompositionActiveContext::Ambiguous,
    ] {
        assert_eq!(
            constructor_encoder::Encode::encode(&context),
            serde_json::to_value(context).expect("decomposition active context serde")
        );
    }
}

#[cfg(test)]
fn assert_erosion_and_stage3_encoder_representation_v1() {
    for authority in [
        crate::DirectErosionHydrographShapeAuthority::Dc01SourceShape,
        crate::DirectErosionHydrographShapeAuthority::RoutedHydrograph,
    ] {
        assert_eq!(
            constructor_encoder::Encode::encode(&authority),
            serde_json::to_value(authority).expect("erosion hydrograph authority serde")
        );
    }
    let populated_stage3_outcome = crate::hydrology::DirectSnowStage3Outcome {
        enabled: true,
        meltwater_temperature_c: Some(
            openwepp_unit_boundary::TemperatureCelsius::try_new(-1.25)
                .expect("finite subfreezing temperature"),
        ),
        sublimation_m: 0.002,
    };
    assert_eq!(
        constructor_encoder::Encode::encode(&populated_stage3_outcome),
        serde_json::to_value(populated_stage3_outcome).expect("stage3 outcome serde")
    );
}

#[cfg(test)]
#[test]
fn constructor_encoder_matches_independent_serde_and_literal_enum_names_v1() {
    assert_constructor_encoder_fixture_representation_v1();
    assert_growth_encoder_representation_v1();
    assert_decomposition_encoder_representation_v1();
    assert_erosion_and_stage3_encoder_representation_v1();
}

#[cfg(test)]
fn capture_test_direct_run_frame_dynamic_raw(
    frame: &crate::DirectRunFrame,
    surface_configuration: &crate::DirectSurfaceLiquidConfiguration,
) -> Result<serde_json::Value, String> {
    let transfer_operands = |value: crate::DirectRunTransferDownstreamOperands| {
        serde_json::json!({
            "lane_count": value.lane_count,
            "outlet_lane_id": value.outlet_lane_id,
            "values": [value.total_outgoing_surface_m, value.total_outgoing_lateral_m,
                value.total_received_surface_m, value.total_received_lateral_m,
                value.total_net_transfer_m],
        })
    };
    let lanes = frame
        .lanes
        .iter()
        .map(|lane| serde_json::json!({
            "water": [lane.water.soil_water_m, lane.water.infiltration_m, lane.water.runoff_m,
                lane.water.evapotranspiration_m, lane.water.drainage_m, lane.water.lateral_flow_m],
            "subsurface_layers": lane.subsurface_layers,
            "transfer_surface_carry_m": lane.transfer.surface_carry_m,
            "transfer_surface_hourly_weights": lane.transfer.surface_hourly_weights,
            "transfer_lateral_carry_m": lane.transfer.lateral_carry_m,
            "transfer_scalars": [lane.transfer.upstream_flow_m, lane.transfer.subsurface_input_m],
            "publication": [lane.publication.runoff_m, lane.publication.infiltration_m,
                lane.publication.evapotranspiration_m, lane.publication.drainage_m,
                lane.publication.lateral_flow_m],
        }))
        .collect::<Vec<_>>();
    let lane_transfer_ledger = frame
        .lane_transfer_ledger
        .iter()
        .map(|entry| {
            serde_json::json!({
                "lane_id": entry.lane_id,
                "upstream_lane_id": entry.upstream_lane_id,
                "downstream_lane_id": entry.downstream_lane_id,
                "values": [entry.upstream_area_ratio, entry.area_m2, entry.outgoing_surface_m,
                    entry.outgoing_lateral_m, entry.received_surface_m, entry.received_lateral_m,
                    entry.net_transfer_m],
            })
        })
        .collect::<Vec<_>>();
    let groundwater = match frame.groundwater.authority {
        crate::DirectGroundwaterAuthority::Disabled => serde_json::json!("Disabled"),
        crate::DirectGroundwaterAuthority::LinearReservoir {
            initial_storage_depth_m,
            baseflow_coeff_per_day,
            deep_seepage_coeff_per_day,
            baseflow_threshold_area_ha,
        } => serde_json::json!({"LinearReservoir": {
            "authority": [initial_storage_depth_m, baseflow_coeff_per_day,
                deep_seepage_coeff_per_day, baseflow_threshold_area_ha],
            "state": [frame.groundwater.storage_m3, frame.groundwater.previous_baseflow_m3,
                frame.groundwater.previous_deep_seepage_m3],
            "initialized_area_m2": frame.groundwater.initialized_area_m2,
        }}),
    };
    let surface_liquid_canonical_bytes = frame
        .surface_liquid_shadow
        .as_deref()
        .map(|state| {
            state
                .canonical_bytes(surface_configuration)
                .map_err(|error| error.to_string())
        })
        .transpose()?;
    Ok(serde_json::json!({
        "publication": [frame.publication.runoff_m, frame.publication.infiltration_m,
            frame.publication.evapotranspiration_m, frame.publication.drainage_m,
            frame.publication.lateral_flow_m],
        "lanes": lanes,
        "lane_transfer_ledger": lane_transfer_ledger,
        "lane_transfer_downstream_operands": transfer_operands(
            frame.lane_transfer_downstream_operands),
        "lane_transfer_shadow_projection": frame.lane_transfer_shadow_projection.map(|value| {
            serde_json::json!({
                "lane_count": value.lane_count,
                "outlet_lane_id": value.outlet_lane_id,
                "values": [value.total_outgoing_surface_m, value.total_outgoing_lateral_m,
                    value.total_received_surface_m, value.total_received_lateral_m,
                    value.total_net_transfer_m],
            })
        }),
        "groundwater": groundwater,
        "surface_liquid_canonical_bytes": surface_liquid_canonical_bytes,
    }))
}

#[cfg(test)]
fn capture_test_active_snow_raw(
    value: &crate::hydrology::DirectActiveSnowPartitionInputs,
) -> ActiveSnowPartitionCaptureV1 {
    ActiveSnowPartitionCaptureV1 {
        scalars: [
            value.hyetograph_rainfall_m,
            value.rst_c,
            value.newsnw_kg_m3,
            value.ssd_kg_m3,
            value.runtime_swe_m,
            value.runtime_depth_m,
            value.runtime_density_kg_m3,
            value.runtime_settle_day_count,
            value.liquid_water_retained_m,
            value.tmax_c,
            value.tmin_c,
            value.canopy_cover_fraction,
            value.wind_m_s,
            value.dewpoint_c,
            value.coe_boundary_depth_m,
            value.coe_boundary_density_kg_m3,
            value.coe_boundary_settle_day_count,
        ],
        snow_melt_model: value.snow_melt_model.id().into(),
        snow_density_model: value.snow_density_model.id().into(),
        liquid_routing_model: value.stage3_liquid_routing_model.id().into(),
        surface_energy: SurfaceEnergyCaptureV1 {
            longwave: value.surface_energy_options.longwave_model.id().into(),
            sublimation: value.surface_energy_options.sublimation_model.id().into(),
            values: [
                value.surface_energy_options.daily_solar_radiation_mj_m2,
                value
                    .surface_energy_options
                    .daily_extraterrestrial_radiation_mj_m2,
                value.surface_energy_options.atmospheric_pressure_pa,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .air_temperature_height_m,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .vapor_pressure_height_m,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .wind_speed_height_m,
                value
                    .surface_energy_options
                    .turbulent_geometry
                    .aerodynamic_roughness_length_m,
            ],
            daylight: value.surface_energy_options.daylight,
            complete_carrier_shadow: value.surface_energy_options.complete_carrier_shadow,
        },
        sturm_climate_class: value.sturm_climate_class.map(|x| x.id().into()),
        sturm_day_of_year: value.sturm_day_of_year,
        snow_albedo_model: value.snow_albedo_model.map(|x| x.id().into()),
        snow_albedo_state: value.snow_albedo_state.map(|x| SnowAlbedoCaptureV1 {
            model: x.model.id().into(),
            albedo: x.albedo,
            accumulated_positive_temperature_c_day: x.accumulated_positive_temperature_c_day,
        }),
        snow_layers: value.snow_layers.clone(),
        underlying_surface_albedo: value.underlying_surface_albedo,
        hourly: value
            .hourly
            .iter()
            .map(|x| SnowHourlyCaptureV1 {
                values: [
                    x.active_precipitation_m,
                    x.rain_m,
                    x.snowfall_m,
                    x.radiation_mj_m2,
                    x.air_temperature_c,
                    x.cloud_fraction,
                    x.rain_fraction,
                    x.snow_fraction,
                ],
                phase_model: x.phase_model.id().into(),
                hydrometeor_temperature_c: x.hydrometeor_temperature_c,
            })
            .collect(),
    }
}

#[cfg(test)]
fn capture_test_prepared_support_raw(
    support: &crate::DirectSnowStage3V11PreparedSupport,
) -> Result<PreparedSupportCaptureV1, String> {
    let (
        active,
        forcing,
        snow_free,
        covered,
        hard_boundaries,
        identities,
        capabilities,
        open_requests,
    ) = support.diagnostic_capture_parts_v1()?;
    Ok(PreparedSupportCaptureV1 {
        support: support.support(),
        active_snow_by_lane: active
            .iter()
            .map(|(lane, value)| (*lane, capture_test_active_snow_raw(value)))
            .collect(),
        support_forcing_by_lane: forcing.iter().map(|(lane, value)| (*lane, SupportForcingCaptureV1 { hourly: SnowHourlyCaptureV1 { values:[value.forcing.active_precipitation_m,value.forcing.rain_m,value.forcing.snowfall_m,value.forcing.radiation_mj_m2,value.forcing.air_temperature_c,value.forcing.cloud_fraction,value.forcing.rain_fraction,value.forcing.snow_fraction],phase_model:value.forcing.phase_model.id().into(),hydrometeor_temperature_c:value.forcing.hydrometeor_temperature_c }, duration_seconds:value.duration_seconds })).collect(),
        snow_free_interval: snow_free.clone(),
        covered_interval: CoveredIntervalCaptureV1 { source: crate::v9_real_consumer_shadow::DirectV9ShadowIntervalInput { lse_forcing:covered.lse_forcing.clone(), vegetation_forcing:covered.vegetation_forcing.clone(), wb14_parameters:covered.wb14_parameters.clone() } },
        hard_boundaries: hard_boundaries.to_vec(),
        identities_by_lane: identities.iter().map(|(lane, values)| serde_json::to_vec(values).map(|bytes| (*lane, bytes))).collect::<Result<_,_>>().map_err(|error| error.to_string())?,
        destination_capabilities: capabilities.iter().map(|((ofe, tile), capability)| { let destination=DestinationCaptureV1 { ofe_id:ofe.as_str().to_owned(), tile_id:tile.as_str().to_owned() }; match capability { crate::snow_stage3_open_boundary::SealedStage3TileBoundaryForcingV1::V11CanopyCovered(value) => DestinationCapabilityCaptureV1::Covered { destination, rho_air_kg_m3:value.rho_air_kg_m3, cp_air_j_kg_k:value.cp_air_j_kg_k, effective_canopy_cover:value.effective_canopy_cover }, crate::snow_stage3_open_boundary::SealedStage3TileBoundaryForcingV1::OpenSnow(_) => DestinationCapabilityCaptureV1::Open { destination } } }).collect(),
        open_snow_destinations: open_requests.iter().map(|(ofe,tile)| DestinationCaptureV1 { ofe_id:ofe.as_str().to_owned(), tile_id:tile.as_str().to_owned() }).collect(),
    })
}

#[cfg(test)]
fn capture_test_snow_free_prepared_support_raw(
    support: &crate::DirectSnowStage3V11PreparedSupport,
) -> Result<serde_json::Value, String> {
    let (active, forcing, snow_free, hard_boundaries, identities, represented, open_requests) =
        support.diagnostic_snow_free_capture_parts_v1()?;
    let active = active
        .iter()
        .map(|(lane, value)| (*lane, capture_test_active_snow_raw(value)))
        .collect::<BTreeMap<_, _>>();
    let forcing = forcing
        .iter()
        .map(|(lane, value)| {
            (
                *lane,
                SupportForcingCaptureV1 {
                    hourly: SnowHourlyCaptureV1 {
                        values: [
                            value.forcing.active_precipitation_m,
                            value.forcing.rain_m,
                            value.forcing.snowfall_m,
                            value.forcing.radiation_mj_m2,
                            value.forcing.air_temperature_c,
                            value.forcing.cloud_fraction,
                            value.forcing.rain_fraction,
                            value.forcing.snow_fraction,
                        ],
                        phase_model: value.forcing.phase_model.id().into(),
                        hydrometeor_temperature_c: value.forcing.hydrometeor_temperature_c,
                    },
                    duration_seconds: value.duration_seconds,
                },
            )
        })
        .collect::<BTreeMap<_, _>>();
    let identities = identities
        .iter()
        .map(|(lane, values)| {
            serde_json::to_vec(values)
                .map(|bytes| (*lane, bytes))
                .map_err(|error| error.to_string())
        })
        .collect::<Result<BTreeMap<_, _>, _>>()?;
    Ok(serde_json::json!({
        "support": support.support(),
        "active_snow_by_lane": active,
        "support_forcing_by_lane": forcing,
        "snow_free_interval": snow_free,
        "covered_projection": null,
        "hard_boundaries": hard_boundaries,
        "identities_by_lane": identities,
        "destination_capabilities": [],
        "destination_capability_count": represented.len(),
        "open_snow_destinations": [],
        "open_snow_destination_count": open_requests.len(),
    }))
}

#[cfg(test)]
fn capture_test_soil_trial_raw(
    trial: &openwepp_land_surface_energy::SoilThermalTrialStateV2,
) -> serde_json::Value {
    serde_json::json!({
        "transaction_id": trial.transaction_id(), "predecessor_transaction_id": trial.predecessor_transaction_id(),
        "support_start_ns": trial.support_start_ns(), "support_end_ns": trial.support_end_ns(),
        "beginning_state_sha256": trial.beginning_state_sha256(),
        "accepted_predecessor_receipt_chain_sha256": trial.accepted_predecessor_receipt_chain_sha256(),
        "unpublished_predecessor_trial_sha256": trial.unpublished_predecessor_trial_sha256(),
        "numerical_coordinate_set_sha256": trial.numerical_coordinate_set_sha256(),
        "numerical_coordinate_authority_sha256": trial.numerical_coordinate_authority_sha256(),
        "ending_state": trial.ending_state(), "layer_credits": trial.layer_credits(),
        "unpublished_trial_sha256": trial.unpublished_trial_sha256(),
    })
}

#[cfg(test)]
fn capture_test_ordered_owner_joins(
    receipts: &[crate::snow_stage3_v11_attachment::Stage3CoupledSubslabReceiptV1],
) -> serde_json::Value {
    let rows = receipts
        .iter()
        .map(|receipt| {
            let destination_receipts = receipt
                .destination_receipts
                .iter()
                .map(|((ofe_id, tile_id), boundary_receipt)| {
                    serde_json::json!({
                        "ofe_id": ofe_id,
                        "tile_id": tile_id,
                        "receipt": boundary_receipt,
                    })
                })
                .collect::<Vec<_>>();
            let mut row = serde_json::json!({
                "parent_support": receipt.parent_support,
                "support": receipt.support,
                "selected_upper_bound_s_bits": receipt.selected_upper_bound_s_bits,
                "accepted_slab_sha256": receipt.accepted_slab_sha256,
                "wb14_replay_trial_sha256": receipt.wb14_replay_trial_sha256,
                "wb14_replay_beginning_owner_set_sha256": receipt.wb14_replay_beginning_owner_set_sha256,
                "wb14_child_receipt_set_sha256": receipt.wb14_child_receipt_set_sha256,
                "wb14_parent_receipt_set_sha256": receipt.wb14_parent_receipt_set_sha256,
                "wb14_ofe_topology": receipt.wb14_ofe_topology,
                "wb14_child_replay_bytes": receipt.wb14_child_replay_bytes,
                "wb14_parent_replay_bytes": receipt.wb14_parent_replay_bytes,
                "destination_receipts": destination_receipts,
                "lane_receipts": receipt.lane_receipts,
                "physical_outcome_ledger_set_sha256": receipt.physical_outcome_ledger_set_sha256,
                "terminal_events": receipt.terminal_events,
                "post_support_liquid_receiver_event": receipt.post_support_liquid_receiver_event,
                "post_support_liquid_output_set_sha256": receipt.post_support_liquid_output_set_sha256,
                "post_support_liquid_mass_kg_m2_bits": receipt.post_support_liquid_mass_kg_m2_bits,
                "post_support_liquid_enthalpy_j_m2_bits": receipt.post_support_liquid_enthalpy_j_m2_bits,
                "post_support_liquid_surface_beginning_state": receipt.post_support_liquid_surface_beginning_state,
                "post_support_liquid_surface_ending_state": receipt.post_support_liquid_surface_ending_state,
                "owner_join": receipt.owner_join,
                "receipt_sha256": receipt.receipt_sha256,
            });
            if let Some(custody) = &receipt.post_support_native_custody {
                row.as_object_mut()
                    .expect("test owner-join row object")
                    .insert(
                        "post_support_native_custody".to_owned(),
                        serde_json::to_value(custody)
                            .expect("test live post-support native custody serialization"),
                    );
            }
            row
        })
        .collect();
    serde_json::Value::Array(rows)
}

#[cfg(test)]
fn capture_test_phase_live(
    input: &PreChildProducerSnapshotInputsV1<'_>,
) -> (&'static str, serde_json::Value) {
    match input.phase {
        PreChildCapturePhaseV1::Covered => ("covered", serde_json::Value::Null),
        PreChildCapturePhaseV1::SnowFree {
            history,
            validated_native_inactive_wb14_prefix,
            ending_snow_owner_bytes,
            deferred_native_v2_soil_custody,
        } => (
            "snow_free",
            serde_json::json!({
                "ordered_owner_joins": capture_test_ordered_owner_joins(history.owner_joins),
                "ordered_owner_join_support_liquid_custody_v2": history.owner_joins.iter().map(|receipt| receipt.support_liquid_custody_v2()).collect::<Vec<_>>(),
                "ordered_event_groups": history.event_groups,
                "ordered_event_group_terminal_liquid_custody_v2": history.event_groups.iter().map(|group| group.terminal_receiver_custody_v2()).collect::<Vec<_>>(),
                "validated_native_inactive_wb14_prefix": validated_native_inactive_wb14_prefix,
                "current_stage3": history.current_stage3,
                "current_snow_enthalpy_material_owner": history.current_snow_enthalpy_material_owner,
                "pending_terminal_parcels": history.pending_terminal_parcels,
                "ending_snow_owner_canonical_bytes": ending_snow_owner_bytes,
                "deferred_native_v2_soil_custody": deferred_native_v2_soil_custody.map(|custody| {
                    let candidate = custody.candidate().v2().expect("test live deferred soil candidate");
                    let continuation = custody.continuation().map(|continuation| serde_json::json!({
                        "original_beginning_owner": continuation.original_prepared().beginning_owner(),
                        "physical_trial": capture_test_soil_trial_raw(continuation.physical_trial()),
                        "accumulated_operands": continuation.accumulated_operands(),
                        "ordered_layer_credit_chain": continuation.diagnostic_layer_credit_chain(),
                    }));
                    serde_json::json!({
                        "posture": "reconstructible_operands_not_installable_capability",
                        "candidate": capture_test_soil_trial_raw(candidate),
                        "continuation": continuation,
                    })
                }),
            }),
        ),
    }
}

#[cfg(test)]
fn capture_test_producer_live_row(
    input: &PreChildProducerSnapshotInputsV1<'_>,
) -> serde_json::Value {
    let prepared_support = input.prepared_support.map(|prepared| match input.phase {
        PreChildCapturePhaseV1::Covered => serde_json::to_value(
            capture_test_prepared_support_raw(prepared)
                .expect("test live covered support operands"),
        )
        .expect("test live covered support serialization"),
        PreChildCapturePhaseV1::SnowFree { .. } => {
            capture_test_snow_free_prepared_support_raw(prepared)
                .expect("test live snow-free support operands")
        }
    });
    let (phase, phase_live) = capture_test_phase_live(input);
    serde_json::json!({
        "capture_phase": phase, "support": input.support,
        "receipt_canonical_json": serde_json::to_vec(input.receipt).expect("test live receipt serialization"),
        "binding": { "proposed_upper_bound_s_bits": input.binding.proposed_upper_bound_s_bits, "coupled_parent_transaction_sha256": input.binding.coupled_parent_transaction_sha256, "accepted_slab_sha256": input.binding.accepted_slab_sha256, "parent_beginning_complete_owner_set_sha256": input.binding.parent_beginning_complete_owner_set_sha256, "parent_support_start_ns": input.binding.parent_support_start_ns, "parent_support_end_ns": input.binding.parent_support_end_ns, "child_support_start_ns": input.binding.child_support_start_ns, "child_support_end_ns": input.binding.child_support_end_ns },
        "prepared_support_constructor_operands": prepared_support,
        "parent_checkpoint_canonical_json": serde_json::to_vec(&input.parent.checkpoint()).expect("test live parent checkpoint serialization"),
        "clock_complete_owner_canonical_bytes": input.clock.owners().iter().map(|owner| (owner.owner_id().to_owned(), owner.state_bytes().to_vec())).collect::<BTreeMap<_, _>>(),
        "complete_owner_canonical_bytes": input.consumer.canonical_v11_parent_owner_state_bytes().expect("test live complete owner bytes"),
        "native_consumer_constructor_operands": input.consumer.diagnostic_native_consumer_constructor_operands_v1().expect("test live native consumer operands"),
        "parent_support": input.clock.parent_support(), "accepted_until": input.clock.accepted_until(),
        "beginning_stage3_canonical_json": serde_json::to_vec(input.beginning_stage3).expect("test live stage3 serialization"),
        "beginning_snow_enthalpy_material_owner": input.beginning_snow_enthalpy_material_owner,
        "pending_terminal_parcels": input.pending_terminal_parcels,
        "terminal_parcels_produced_unconsumed_canonical_json": serde_json::to_vec(input.pending_terminal_parcels).expect("test live terminal parcel serialization"),
        "constraint_reduction_canonical_json": serde_json::to_vec(input.reduction).expect("test live reduction serialization"),
        "complete_owner_ledger_canonical_json": serde_json::to_vec(input.ledger).expect("test live ledger serialization"),
        "forcing_receipt": input.forcing_receipt,
        "surface_liquid_configuration_canonical_json": input.context.surface_liquid_configuration.canonical_bytes().expect("test live surface configuration canonical bytes"),
        "vegetation_configuration_canonical_json": serde_json::to_vec(&input.context.vegetation_configuration).expect("test live vegetation configuration serialization"),
        "lse_configuration_canonical_json": serde_json::to_vec(input.consumer.lse_configuration()).expect("test live LSE configuration serialization"),
        "provider_cursor_canonical_json": serde_json::to_vec(input.consumer.provider_cursor()).expect("test live provider cursor serialization"),
        "native_lane_map_constructor_operands": input.consumer.diagnostic_native_lane_maps_v1(),
        "native_soil_v2_constructor_operands": input.consumer.diagnostic_native_soil_v2().expect("test live native soil diagnostics"),
        "native_hydrology_frame_dynamic_constructor_operands": capture_test_direct_run_frame_dynamic_raw(input.consumer.diagnostic_hydrology_frame_v1(), &input.context.surface_liquid_configuration).expect("test live hydrology frame dynamic operands"),
        "native_hydrology_constructor_inputs": capture_test_direct_run_constructor_inputs_raw(input.consumer.diagnostic_hydrology_constructor_inputs_v1().expect("test live hydrology constructor pin").as_ref()),
        "phase_live": phase_live,
    })
}

#[cfg(test)]
pub(crate) fn record_pre_child_producer_live_inputs_v1(
    input: &PreChildProducerSnapshotInputsV1<'_>,
) {
    PRE_CHILD_RECORDER_TEST_STATE_V1.with(|slot| {
        let mut slot = slot.borrow_mut();
        let Some(state) = slot.as_mut() else {
            return;
        };
        state.audit.producer_calls += 1;
        let selected = matches!(
            (state.mode, input.phase),
            (
                PreChildRecorderTestModeV1::EnabledCovered
                    | PreChildRecorderTestModeV1::ForcedCoveredCaptureFailure,
                PreChildCapturePhaseV1::Covered
            ) | (
                PreChildRecorderTestModeV1::EnabledSnowFree
                    | PreChildRecorderTestModeV1::ForcedSnowFreeCaptureFailure
                    | PreChildRecorderTestModeV1::ForcedSnowFreeWrongPhaseFailure
                    | PreChildRecorderTestModeV1::ForcedSnowFreeRequiredOmissionFailure,
                PreChildCapturePhaseV1::SnowFree { .. }
            )
        );
        if selected && !state.producer_recorded {
            state.producer_recorded = true;
            state
                .audit
                .live_inputs
                .push(capture_test_producer_live_row(input));
        }
    });
}

#[cfg(not(test))]
fn record_test_recorder_result_v1(_: &PreChildContext<'_>, _: &serde_json::Value) {}

pub(crate) fn record_pre_child_context(input: PreChildContext<'_>) {
    #[cfg(test)]
    let mut input = input;
    #[cfg(test)]
    let test_physical_observer_enabled = PRE_CHILD_RECORDER_TEST_STATE_V1.with(|slot| {
        slot.borrow().as_ref().is_some_and(|state| {
            state.mode == PreChildRecorderTestModeV1::ProductionNonTargetObserverEnabled
        })
    });
    #[cfg(not(test))]
    let test_physical_observer_enabled = false;
    let production_selected = (crate::snow_accuracy_observer::physical_global_enabled()
        || test_physical_observer_enabled)
        && is_target(input.day, input.interval, input.support);
    let test_mode = test_recorder_selection_v1(input.phase);
    if !production_selected && test_mode.is_none() {
        return;
    }
    let reported_phase = match input.phase {
        PreChildCapturePhaseV1::Covered => "covered",
        PreChildCapturePhaseV1::SnowFree { .. } => "snow_free",
    };
    #[cfg(test)]
    match test_mode {
        Some(PreChildRecorderTestModeV1::ForcedSnowFreeWrongPhaseFailure) => {
            input.phase = PreChildCapturePhaseV1::Covered;
        }
        Some(PreChildRecorderTestModeV1::ForcedSnowFreeRequiredOmissionFailure) => {
            input.prepared_support = None;
        }
        _ => {}
    }
    #[cfg(test)]
    let forced_failure = matches!(
        test_mode,
        Some(
            PreChildRecorderTestModeV1::ForcedCoveredCaptureFailure
                | PreChildRecorderTestModeV1::ForcedSnowFreeCaptureFailure
        )
    );
    #[cfg(not(test))]
    let forced_failure = false;
    let captured = if forced_failure {
        Err("forced capture-only recorder failure".to_owned())
    } else {
        capture_row(&input)
    };
    let row = match captured {
        Ok(row) => row,
        Err(detail) => serde_json::json!({
            "kind":"b01_wb14_pre_child_current_context_capture_error_v1",
            "capture_phase":reported_phase,
            "detail":detail,"day_index":input.day,"interval_index":input.interval,"support":input.support
        }),
    };
    record_test_recorder_result_v1(&input, &row);
    if crate::snow_accuracy_observer::physical_global_enabled() {
        crate::snow_accuracy_observer::record(row);
    }
}

#[cfg(test)]
pub(crate) fn restore_coupled_clock(
    bytes: &[u8],
    model: openwepp_coupled_time::Digest32,
    authority: openwepp_coupled_time::Digest32,
    policy: openwepp_coupled_time::Digest32,
) -> Result<CoupledTimeRestartV2, String> {
    CoupledTimeRestartV2::from_canonical_json(bytes, model, authority, policy)
        .map_err(|e| e.to_string())
}

/// Restores the enclosing parent through its existing configured BGC scope.
/// The configuration is supplied independently by the real runner fixture.
#[cfg(test)]
pub(crate) fn restore_parent_with_configured_bgc_scope(
    bytes: &[u8],
    vegetation: &openwepp_vegetation::VegetationConfigurationV11,
    lse: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
) -> Result<V11ParentTransaction, String> {
    let checkpoint: openwepp_vegetation::V11ParentTransactionCheckpoint =
        serde_json::from_slice(bytes).map_err(|error| error.to_string())?;
    let scope =
        crate::v9_real_consumer_shadow::direct_v11_bgc_debit_scope(&vegetation.imported_v10, lse)
            .map_err(|error| error.to_string())?;
    V11ParentTransaction::restore_with_bgc_scope(vegetation, checkpoint, Some(&scope))
        .map_err(|error| error.to_string())
}

/// Replays the existing provisional constructor on a clone only. Callers retain
/// the beginning clock and can compare it byte-for-byte after this returns.
#[cfg(test)]
pub(crate) fn reconstruct_provisional_on_clone(
    clock: &CoupledClockStateV1,
    support: TimeSupport,
    context: &DirectSnowStage3V11StaticContext,
    forcing_receipt: openwepp_coupled_time::Digest32,
) -> Result<
    (
        CoupledClockStateV1,
        ConstraintReductionReceiptV1,
        LedgerEntryV1,
        AcceptedSlabReceiptV1,
    ),
    String,
> {
    reconstruct_provisional_on_clone_for_constraint_owner(
        clock,
        support,
        context,
        forcing_receipt,
        "v11-snow-covered-real-consumer",
    )
}

/// Reconstruct a provisional receipt for the recorded phase only.  The source
/// owner is part of the receipt preimage, so a covered recorder receipt cannot
/// be used to validate the snow-free native restoration (or conversely).
#[cfg(test)]
fn reconstruct_provisional_on_clone_for_constraint_owner(
    clock: &CoupledClockStateV1,
    support: TimeSupport,
    context: &DirectSnowStage3V11StaticContext,
    forcing_receipt: openwepp_coupled_time::Digest32,
    constraint_source_owner_id: &str,
) -> Result<
    (
        CoupledClockStateV1,
        ConstraintReductionReceiptV1,
        LedgerEntryV1,
        AcceptedSlabReceiptV1,
    ),
    String,
> {
    reconstruct_provisional_on_clone_with_authorities(
        clock,
        support,
        context.calendar_receipt,
        context.controller_policy,
        forcing_receipt,
        constraint_source_owner_id,
    )
}

/// Diagnostic-only minimal authority form for a captured provisional receipt.
/// It deliberately has no physical configuration or consumer dependency.
#[cfg(test)]
fn reconstruct_provisional_on_clone_with_authorities(
    clock: &CoupledClockStateV1,
    support: TimeSupport,
    calendar_receipt: openwepp_coupled_time::Digest32,
    controller_policy: openwepp_coupled_time::Digest32,
    forcing_receipt: openwepp_coupled_time::Digest32,
    constraint_source_owner_id: &str,
) -> Result<
    (
        CoupledClockStateV1,
        ConstraintReductionReceiptV1,
        LedgerEntryV1,
        AcceptedSlabReceiptV1,
    ),
    String,
> {
    let parent = clock.parent_transaction_id();
    let constraint = StepConstraintV1::new(
        parent,
        support.start_ns(),
        support.end_ns(),
        constraint_source_owner_id.into(),
        ConstraintClass::HardBoundary,
        controller_policy,
        calendar_receipt,
        forcing_receipt,
    )
    .map_err(|e| e.to_string())?;
    let reduction = reduce_constraints(
        &[constraint],
        parent,
        support.start_ns(),
        support.end_ns(),
        None,
    )
    .map_err(|e| e.to_string())?;
    let owner_digest = complete_owner_set_digest(clock.owners()).map_err(|e| e.to_string())?;
    let mut preimage = Vec::new();
    preimage.extend_from_slice(parent.digest().as_bytes());
    preimage.extend_from_slice(&support.start_ns().get().to_be_bytes());
    preimage.extend_from_slice(&support.end_ns().get().to_be_bytes());
    let ledger = LedgerEntryV1::new(
        "complete-owner-custody".into(),
        "canonical-owner-state".into(),
        owner_digest,
        owner_digest,
        digest_bytes(&preimage),
    )
    .map_err(|e| e.to_string())?;
    let candidate = CoupledSlabCandidateV1::new(
        clock,
        clock.active_segment_id(),
        support,
        &reduction,
        clock.owners().to_vec(),
        // The candidate owns its ledger while the diagnostic caller retains the
        // same canonical evidence for its receipt comparison.
        vec![ledger.clone()],
    )
    .map_err(|e| e.to_string())?;
    let mut cloned = clock.clone();
    let receipt = accept_slab(&mut cloned, candidate).map_err(|e| e.to_string())?;
    Ok((cloned, reduction, ledger, receipt))
}

/// Consume the captured diagnostic row in a fresh process. It performs only
/// canonical restoration and provisional construction; no consumer, ingress,
/// WB14, or constitutive operation is called here.
#[cfg(test)]
pub(crate) fn import_and_reconstruct_pre_child_context(
    row: &serde_json::Value,
    context: &DirectSnowStage3V11StaticContext,
    consumer: &DirectV10RealConsumerShadow,
) -> Result<(), String> {
    let inputs = restore_pre_child_provisional_inputs(row, context)?;
    let before = inputs
        .restored
        .to_canonical_json()
        .map_err(|e| e.to_string())?;
    let (_, reduction, ledger, receipt) = reconstruct_provisional_on_clone_for_constraint_owner(
        &inputs.beginning_clock,
        inputs.support,
        context,
        inputs.forcing,
        inputs.expected_owner,
    )?;
    if inputs
        .restored
        .to_canonical_json()
        .map_err(|e| e.to_string())?
        != before
    {
        return Err("provisional clone mutated restored beginning clock".into());
    }
    validate_pre_child_provisional_evidence(row, &reduction, &ledger, &receipt)?;
    validate_pre_child_binding_and_owners(
        row,
        &inputs.parent,
        &inputs.beginning_clock,
        inputs.support,
        inputs.parent_support,
        &receipt,
        consumer,
    )
}

#[cfg(test)]
struct PreChildProvisionalInputsV1 {
    restored: CoupledTimeRestartV2,
    beginning_clock: CoupledClockStateV1,
    parent: V11ParentTransaction,
    support: TimeSupport,
    parent_support: TimeSupport,
    expected_owner: &'static str,
    forcing: openwepp_coupled_time::Digest32,
}

#[cfg(test)]
fn restore_pre_child_provisional_inputs(
    row: &serde_json::Value,
    context: &DirectSnowStage3V11StaticContext,
) -> Result<PreChildProvisionalInputsV1, String> {
    let get = |name: &str| {
        row.get(name)
            .ok_or_else(|| format!("capture missing {name}"))
    };
    let clock_bytes: Vec<u8> =
        serde_json::from_value(get("coupled_clock_restart_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    let model: openwepp_coupled_time::Digest32 =
        serde_json::from_value(get("coupled_clock_restart_model_sha256")?.clone())
            .map_err(|e| e.to_string())?;
    let authority: openwepp_coupled_time::Digest32 =
        serde_json::from_value(get("coupled_clock_restart_authority_sha256")?.clone())
            .map_err(|e| e.to_string())?;
    let policy: openwepp_coupled_time::Digest32 =
        serde_json::from_value(get("coupled_clock_restart_policy_sha256")?.clone())
            .map_err(|e| e.to_string())?;
    if model != digest_bytes(CLOCK_MODEL_DOMAIN)
        || authority != digest_bytes(CLOCK_AUTHORITY_DOMAIN)
        || policy != context.controller_policy
    {
        return Err("captured clock restart authority join".into());
    }
    let restored = restore_coupled_clock(&clock_bytes, model, authority, policy)?;
    let beginning_clock = restored.clock().clone();
    if get("static_run_identity")? != &serde_json::json!(context.run_identity)
        || get("static_topology_identity")? != &serde_json::json!(context.topology_identity)
    {
        return Err("captured static run/topology identity".into());
    }
    if restored.to_canonical_json().map_err(|e| e.to_string())? != clock_bytes {
        return Err("captured clock canonical round trip".into());
    }
    let parent_bytes: Vec<u8> =
        serde_json::from_value(get("parent_checkpoint_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    let vegetation_bytes: Vec<u8> =
        serde_json::from_value(get("vegetation_configuration_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    let vegetation = serde_json::from_slice(&vegetation_bytes).map_err(|e| e.to_string())?;
    if vegetation != context.vegetation_configuration {
        return Err("captured V11 vegetation configuration/context join".into());
    }
    let lse_bytes: Vec<u8> =
        serde_json::from_value(get("lse_configuration_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    let lse = serde_json::from_slice(&lse_bytes).map_err(|e| e.to_string())?;
    let parent = restore_parent_with_configured_bgc_scope(&parent_bytes, &vegetation, &lse)?;
    if parent.parent_transaction_id() != beginning_clock.parent_transaction_id() {
        return Err("restored parent/clock identity".into());
    }
    let support: TimeSupport =
        serde_json::from_value(get("support")?.clone()).map_err(|e| e.to_string())?;
    let parent_support: TimeSupport =
        serde_json::from_value(get("parent_support")?.clone()).map_err(|e| e.to_string())?;
    if parent_support != beginning_clock.parent_support()
        || get("accepted_until")? != &serde_json::json!(beginning_clock.accepted_until())
        || support.start_ns() < parent_support.start_ns()
        || support.end_ns() > parent_support.end_ns()
    {
        return Err("captured clock/support parent join".into());
    }
    let constructor = get("provisional_constructor_inputs")?;
    let snow_free =
        get("kind")? == &serde_json::json!("b01_wb14_snow_free_pre_child_current_context_v1");
    let expected_phase = if snow_free { "snow_free" } else { "covered" };
    let expected_owner = if snow_free {
        "v11-real-consumer"
    } else {
        "v11-snow-covered-real-consumer"
    };
    if get("capture_phase")? != &serde_json::json!(expected_phase)
        || constructor.get("constraint_source_owner_id") != Some(&serde_json::json!(expected_owner))
        || constructor.get("constraint_class") != Some(&serde_json::json!("hard_boundary"))
        || constructor.get("calendar_receipt") != Some(&serde_json::json!(context.calendar_receipt))
        || constructor.get("controller_policy")
            != Some(&serde_json::json!(context.controller_policy))
        || constructor.get("ledger_child_support_start_ns")
            != Some(&serde_json::json!(support.start_ns().get()))
        || constructor.get("ledger_child_support_end_ns")
            != Some(&serde_json::json!(support.end_ns().get()))
    {
        return Err("captured provisional constructor operands".into());
    }
    let forcing = serde_json::from_value(
        constructor
            .get("forcing_receipt")
            .ok_or("capture missing forcing receipt")?
            .clone(),
    )
    .map_err(|e| e.to_string())?;
    Ok(PreChildProvisionalInputsV1 {
        restored,
        beginning_clock,
        parent,
        support,
        parent_support,
        expected_owner,
        forcing,
    })
}

#[cfg(test)]
fn validate_pre_child_provisional_evidence(
    row: &serde_json::Value,
    reduction: &ConstraintReductionReceiptV1,
    ledger: &LedgerEntryV1,
    receipt: &AcceptedSlabReceiptV1,
) -> Result<(), String> {
    let get = |name: &str| {
        row.get(name)
            .ok_or_else(|| format!("capture missing {name}"))
    };
    let expected: Vec<u8> =
        serde_json::from_value(get("provisional_receipt_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    let expected_reduction: Vec<u8> =
        serde_json::from_value(get("constraint_reduction_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    if serde_json::to_vec(&reduction).map_err(|e| e.to_string())? != expected_reduction {
        return Err("constraint reduction durable operands".into());
    }
    let expected_ledger: Vec<u8> =
        serde_json::from_value(get("complete_owner_ledger_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    if serde_json::to_vec(&ledger).map_err(|e| e.to_string())? != expected_ledger {
        return Err("complete owner ledger durable operands".into());
    }
    if serde_json::to_vec(&receipt).map_err(|e| e.to_string())? != expected {
        return Err("provisional receipt durable coordinates".into());
    }
    Ok(())
}

#[cfg(test)]
fn validate_pre_child_binding_and_owners(
    row: &serde_json::Value,
    parent: &V11ParentTransaction,
    beginning_clock: &CoupledClockStateV1,
    support: TimeSupport,
    parent_support: TimeSupport,
    receipt: &AcceptedSlabReceiptV1,
    consumer: &DirectV10RealConsumerShadow,
) -> Result<(), String> {
    let get = |name: &str| {
        row.get(name)
            .ok_or_else(|| format!("capture missing {name}"))
    };
    let beginning_owner_digest =
        complete_owner_set_digest(beginning_clock.owners()).map_err(|e| e.to_string())?;
    let binding = get("coupled_binding")?;
    if binding.get("coupled_parent_transaction_sha256")
        != Some(&serde_json::json!(
            *parent.parent_transaction_id().digest().as_bytes()
        ))
        || binding.get("accepted_slab_sha256")
            != Some(&serde_json::json!(*receipt.slab_id().digest().as_bytes()))
        || binding.get("parent_beginning_complete_owner_set_sha256")
            != Some(&serde_json::json!(*beginning_owner_digest.as_bytes()))
        || binding.get("parent_support_start_ns")
            != Some(&serde_json::json!(parent_support.start_ns().get()))
        || binding.get("parent_support_end_ns")
            != Some(&serde_json::json!(parent_support.end_ns().get()))
        || binding.get("child_support_start_ns")
            != Some(&serde_json::json!(support.start_ns().get()))
        || binding.get("child_support_end_ns") != Some(&serde_json::json!(support.end_ns().get()))
    {
        return Err("captured coupled binding parent/prefix join".into());
    }
    let expected_clock_owners: BTreeMap<String, Vec<u8>> =
        serde_json::from_value(get("clock_complete_owner_canonical_bytes")?.clone())
            .map_err(|e| e.to_string())?;
    let restored_clock_owners = beginning_clock
        .owners()
        .iter()
        .map(|owner| (owner.owner_id().to_owned(), owner.state_bytes().to_vec()))
        .collect::<BTreeMap<_, _>>();
    if restored_clock_owners != expected_clock_owners {
        return Err("clock complete-owner canonical bytes".into());
    }
    let consumer_owners: BTreeMap<String, Vec<u8>> =
        serde_json::from_value(get("complete_owner_canonical_bytes")?.clone())
            .map_err(|e| e.to_string())?;
    let actual_consumer_owners = consumer
        .canonical_v11_parent_owner_state_bytes()
        .map_err(|e| e.to_string())?;
    if consumer_owners != actual_consumer_owners {
        return Err("consumer complete-owner canonical byte manifest".into());
    }
    let captured_provider: Vec<u8> =
        serde_json::from_value(get("provider_cursor_canonical_json")?.clone())
            .map_err(|e| e.to_string())?;
    if captured_provider
        != serde_json::to_vec(consumer.provider_cursor()).map_err(|e| e.to_string())?
    {
        return Err("captured provider cursor/consumer join".into());
    }
    Ok(())
}

/// Owned, provider-bound portion of the file consumer.  It takes only capture
/// rows and the independently pinned static authority; callers cannot smuggle
/// a live provider or prepared support across the diagnostic boundary.
#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
pub(crate) struct RestoredProviderBoundContextV1 {
    /// The complete, authenticated 48-support day.  Keeping this capability
    /// is essential: a selected child alone cannot carry the provider cursor
    /// or establish the parent support from which its forcing was derived.
    pub prepared_day: crate::ValidatedPreparedStage3V11DayV1,
    pub prepared_support: crate::DirectSnowStage3V11PreparedSupport,
    pub forcing_receipt: openwepp_coupled_time::Digest32,
    pub consumer: DirectV10RealConsumerShadow,
    pub archived_receipt_prefix: crate::Stage3ArchivedReceiptPrefixV1,
    pub snow_enthalpy_material_resident:
        crate::snow_stage3_v11_attachment::SnowStage3V11SnowEnthalpyMaterialResidentV1,
    /// Every predecessor day retained as its original canonical frame plus
    /// the source-decoded parent, publication, and qualification owners.
    pub authenticated_archived_days: Vec<AuthenticatedArchivedDayV1>,
    /// The non-provider owners reconstructed from the same target row.  This
    /// remains separate from the provider/day capability so neither is used
    /// as a substitute for the other at the native consumer admission edge.
    pub captured: RestoredCapturedPreChildContextV1,
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
pub(crate) struct AuthenticatedArchivedDayV1 {
    pub entry: crate::Stage3CommittedDayArchiveEntryV1,
    pub parent_receipt: crate::DirectSnowStage3V11ParentReceipt,
    pub publication: crate::v9_real_consumer_shadow::RestoredStage3PublicationDayEvidenceV1,
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
struct CommittedDayFrameReaderV1<'a> {
    bytes: &'a [u8],
    cursor: usize,
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
impl<'a> CommittedDayFrameReaderV1<'a> {
    fn take(&mut self, length: usize) -> Result<&'a [u8], String> {
        let end = self
            .cursor
            .checked_add(length)
            .ok_or("archive framing width")?;
        let value = self
            .bytes
            .get(self.cursor..end)
            .ok_or("archive truncated framing")?;
        self.cursor = end;
        Ok(value)
    }

    fn exact(&mut self, expected: &[u8]) -> Result<(), String> {
        if self.take(expected.len())? != expected {
            return Err("archive frame identity".into());
        }
        Ok(())
    }

    fn blob(&mut self) -> Result<&'a [u8], String> {
        let raw: [u8; 8] = self
            .take(8)?
            .try_into()
            .map_err(|_| "archive length width")?;
        let length =
            usize::try_from(u64::from_be_bytes(raw)).map_err(|_| "archive host length width")?;
        self.take(length)
    }
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
fn authenticate_archived_day_v1(
    entry: crate::Stage3CommittedDayArchiveEntryV1,
    canonical_record: &[u8],
    context: &DirectSnowStage3V11StaticContext,
    pinned_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
) -> Result<AuthenticatedArchivedDayV1, String> {
    authenticate_archived_day_with_configuration_v1(
        entry,
        canonical_record,
        context.run_identity,
        context.topology_identity,
        &context.vegetation_configuration,
        pinned_lse_configuration,
    )
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn validate_archive_first_positive_join(
    parent_receipt: &crate::DirectSnowStage3V11ParentReceipt,
    publication: &crate::v9_real_consumer_shadow::RestoredStage3PublicationDayEvidenceV1,
) -> Result<(), String> {
    let mut positive = parent_receipt
        .coupled_subslabs
        .iter()
        .map(|receipt| {
            (
                receipt.support,
                receipt.owner_join.beginning_complete_owner_set_sha256,
            )
        })
        .chain(
            parent_receipt
                .snow_free_successor_receipts
                .iter()
                .map(|receipt| (receipt.support, receipt.beginning_complete_owner_set_sha256)),
        )
        .collect::<Vec<_>>();
    positive.sort_by_key(|(support, _)| support.start_ns());
    let (first_support, first_beginning) = positive
        .first()
        .ok_or("archive parent positive support missing")?;
    if positive
        .get(1)
        .is_some_and(|(support, _)| support.start_ns() == first_support.start_ns())
        || *first_support != publication.first_positive_support
        || *first_beginning != publication.first_positive_beginning_owner
    {
        return Err("archive parent first-positive beginning/publication join".into());
    }
    Ok(())
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn authenticate_archived_day_with_configuration_v1(
    entry: crate::Stage3CommittedDayArchiveEntryV1,
    canonical_record: &[u8],
    run_identity: openwepp_coupled_time::Digest32,
    topology_identity: openwepp_coupled_time::Digest32,
    vegetation_configuration: &openwepp_vegetation::VegetationConfigurationV11,
    pinned_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
) -> Result<AuthenticatedArchivedDayV1, String> {
    entry.validate().map_err(|error| error.to_string())?;
    if u64::try_from(canonical_record.len()).ok() != Some(entry.canonical_uncompressed_len)
        || digest_bytes(canonical_record) != entry.content_sha256
    {
        return Err("captured canonical archive record content identity".into());
    }
    let mut reader = CommittedDayFrameReaderV1 {
        bytes: canonical_record,
        cursor: 0,
    };
    reader.exact(b"OPENWEPP_STAGE3_COMMITTED_DAY_EVIDENCE_V1\0")?;
    reader.exact(&entry.schema_version.to_be_bytes())?;
    reader.exact(run_identity.as_bytes())?;
    reader.exact(topology_identity.as_bytes())?;
    reader.exact(
        &u64::try_from(entry.day_index)
            .map_err(|_| "archive day width")?
            .to_be_bytes(),
    )?;
    reader.exact(entry.previous_archive_content_root_sha256.as_bytes())?;
    let parent_bytes = reader.blob()?;
    if digest_bytes(parent_bytes) != entry.parent_receipt_sha256 {
        return Err("archive parent receipt content identity".into());
    }
    let parent_receipt = crate::snow_stage3_v11_attachment::
        diagnostic_restore_parent_receipt_archive_with_configured_scope_v3(
            parent_bytes,
            vegetation_configuration,
            pinned_lse_configuration,
        )
        .map_err(|error| error.to_string())?;
    let publication_bytes = reader.blob()?;
    if digest_bytes(publication_bytes) != entry.publication_evidence_sha256 {
        return Err("archive publication content identity".into());
    }
    let publication =
        crate::v9_real_consumer_shadow::restart_authority_restore_archived_publication_day_v1(
            publication_bytes,
        )
        .map_err(|error| error.to_string())?;
    validate_archive_first_positive_join(&parent_receipt, &publication)?;
    reader.exact(entry.committed_publication_receipt_sha256.as_bytes())?;
    reader.exact(publication.ordered_support_receipt_set_sha256.as_bytes())?;
    reader.exact(entry.beginning_owner_set_sha256.as_bytes())?;
    reader.exact(entry.ending_owner_set_sha256.as_bytes())?;
    reader.exact(&entry.ending_accepted_until_ns.to_be_bytes())?;
    reader.exact(&entry.ending_next_parent_sequence.to_be_bytes())?;
    let qualification_bytes = reader.blob()?;
    let qualification_delta: crate::SnowStage3V11QualificationDayDeltaV1 =
        serde_json::from_slice(qualification_bytes).map_err(|error| error.to_string())?;
    if serde_json::to_vec(&qualification_delta).map_err(|error| error.to_string())?
        != qualification_bytes
        || qualification_delta.receipt_sha256() != entry.qualification_day_delta_sha256
    {
        return Err("archive qualification canonical identity".into());
    }
    qualification_delta
        .validate()
        .map_err(|error| error.to_string())?;
    if reader.cursor != canonical_record.len()
        || parent_receipt.day_index != entry.day_index
        || parent_receipt.support_count
            != crate::snow_stage3_v11_attachment::STAGE3_V11_PARENT_SUPPORT_COUNT
        || parent_receipt.ending_coupled_owner_set_sha256 != entry.ending_owner_set_sha256
        || parent_receipt.ending_coupled_accepted_until_ns.get() != entry.ending_accepted_until_ns
        || parent_receipt.ending_next_parent_sequence != entry.ending_next_parent_sequence
        || publication.day_index != entry.day_index
        || publication.beginning_owner_set_sha256 != entry.beginning_owner_set_sha256
        || publication.ending_owner_set_sha256 != entry.ending_owner_set_sha256
        || qualification_delta.day_index != entry.day_index
        || qualification_delta.beginning_owner.coupled_owner_set_sha256
            != entry.beginning_owner_set_sha256
        || qualification_delta.ending_owner.coupled_owner_set_sha256
            != entry.ending_owner_set_sha256
    {
        return Err("archive parent/publication/qualification semantic join".into());
    }
    Ok(AuthenticatedArchivedDayV1 {
        entry,
        parent_receipt,
        publication,
    })
}

/// Owned diagnostic reconstruction of every serializable pre-child owner.
/// `DirectRunFrame` and the native consumer deliberately remain outside this
/// DTO: neither implements serde and each must be admitted through its
/// private native constructor rather than reconstructed by a generic wire
/// deserializer.
#[cfg(test)]
pub(crate) struct RestoredCapturedPreChildContextV1 {
    pub parent: V11ParentTransaction,
    pub clock: CoupledClockStateV1,
    pub beginning_stage3: BTreeMap<u32, crate::DirectSnowStage3PersistentState>,
    pub pending_terminal_parcels:
        BTreeMap<openwepp_coupled_time::Digest32, crate::DirectSnowStage3V11TerminalParcel>,
    pub beginning_snow_enthalpy_material_owner:
        Option<crate::snow_stage3_v11_snow_enthalpy_carry::AuthenticatedCoveredSnowMaterialOwnerV1>,
    pub reduction: ConstraintReductionReceiptV1,
    pub ledger: LedgerEntryV1,
    pub receipt: AcceptedSlabReceiptV1,
    pub binding: serde_json::Value,
}

#[cfg(test)]
fn restore_captured_clock_parent(
    row: &serde_json::Value,
    context: &DirectSnowStage3V11StaticContext,
) -> Result<(CoupledClockStateV1, V11ParentTransaction), String> {
    let get = |name: &str| {
        row.get(name)
            .ok_or_else(|| format!("capture missing {name}"))
    };
    let clock_bytes: Vec<u8> =
        serde_json::from_value(get("coupled_clock_restart_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let model = serde_json::from_value(get("coupled_clock_restart_model_sha256")?.clone())
        .map_err(|error| error.to_string())?;
    let authority = serde_json::from_value(get("coupled_clock_restart_authority_sha256")?.clone())
        .map_err(|error| error.to_string())?;
    let policy = serde_json::from_value(get("coupled_clock_restart_policy_sha256")?.clone())
        .map_err(|error| error.to_string())?;
    if model != digest_bytes(CLOCK_MODEL_DOMAIN)
        || authority != digest_bytes(CLOCK_AUTHORITY_DOMAIN)
        || policy != context.controller_policy
    {
        return Err("captured clock restart authority join".into());
    }
    let clock = restore_coupled_clock(&clock_bytes, model, authority, policy)?
        .clock()
        .clone();
    let vegetation_bytes: Vec<u8> =
        serde_json::from_value(get("vegetation_configuration_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let vegetation =
        serde_json::from_slice(&vegetation_bytes).map_err(|error| error.to_string())?;
    if vegetation != context.vegetation_configuration {
        return Err("captured V11 vegetation configuration/context join".into());
    }
    let lse_bytes: Vec<u8> =
        serde_json::from_value(get("lse_configuration_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let lse = serde_json::from_slice(&lse_bytes).map_err(|error| error.to_string())?;
    let parent_bytes: Vec<u8> =
        serde_json::from_value(get("parent_checkpoint_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let mut parent = restore_parent_with_configured_bgc_scope(&parent_bytes, &vegetation, &lse)?;
    if parent.parent_transaction_id() != clock.parent_transaction_id() {
        return Err("restored parent/clock identity".into());
    }
    parent
        .restore_evaluator_cache_from_accepted_slabs(clock.accepted_slab_receipts())
        .map_err(|error| error.to_string())?;
    Ok((clock, parent))
}

#[cfg(test)]
fn restore_captured_pre_child_context(
    row: &serde_json::Value,
    context: &DirectSnowStage3V11StaticContext,
) -> Result<RestoredCapturedPreChildContextV1, String> {
    let get = |name: &str| {
        row.get(name)
            .ok_or_else(|| format!("capture missing {name}"))
    };
    let (clock, parent) = restore_captured_clock_parent(row, context)?;
    let beginning_stage3_bytes: Vec<u8> =
        serde_json::from_value(get("beginning_stage3_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let beginning_stage3 =
        serde_json::from_slice(&beginning_stage3_bytes).map_err(|error| error.to_string())?;
    let beginning_snow_enthalpy_material_owner = serde_json::from_value::<
        Option<crate::snow_stage3_v11_snow_enthalpy_carry::AuthenticatedCoveredSnowMaterialOwnerV1>,
    >(
        get("beginning_snow_enthalpy_material_owner")?.clone(),
    )
    .map_err(|error| error.to_string())?;
    if let Some(owner) = beginning_snow_enthalpy_material_owner.as_ref() {
        owner.validate().map_err(|error| error.to_string())?;
        if owner.base_material_owner() != &beginning_stage3 {
            return Err("captured snow-enthalpy/base material owner join".into());
        }
    }
    let parcel_bytes: Vec<u8> =
        serde_json::from_value(get("terminal_parcels_produced_unconsumed_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let pending_terminal_parcels = serde_json::from_slice::<
        BTreeMap<openwepp_coupled_time::Digest32, crate::DirectSnowStage3V11TerminalParcel>,
    >(&parcel_bytes)
    .map_err(|error| error.to_string())?;
    if pending_terminal_parcels.iter().any(|(digest, parcel)| {
        parcel.posture != crate::DirectSnowStage3V11TerminalParcelPosture::ProducedUnconsumed
            || parcel.parent_transaction_id != clock.parent_transaction_id().digest()
            || parcel.support.start_ns() < clock.parent_support().start_ns()
            || parcel.support.end_ns() > clock.parent_support().end_ns()
            || crate::snow_owner_v4::canonical_terminal_parcel_digest(parcel)
                .map_or(true, |actual| {
                    actual != *digest || actual != parcel.parcel_digest
                })
    }) {
        return Err("captured terminal parcel custody posture".into());
    }
    let reduction_bytes: Vec<u8> =
        serde_json::from_value(get("constraint_reduction_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let ledger_bytes: Vec<u8> =
        serde_json::from_value(get("complete_owner_ledger_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let receipt_bytes: Vec<u8> =
        serde_json::from_value(get("provisional_receipt_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let support: TimeSupport =
        serde_json::from_value(get("support")?.clone()).map_err(|error| error.to_string())?;
    let forcing = serde_json::from_value(
        get("provisional_constructor_inputs")?
            .get("forcing_receipt")
            .ok_or("capture missing provisional forcing receipt")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let expected_owner = match row.get("kind") {
        Some(kind)
            if kind == &serde_json::json!("b01_wb14_snow_free_pre_child_current_context_v1") =>
        {
            "v11-real-consumer"
        }
        Some(kind) if kind == &serde_json::json!("b01_wb14_pre_child_current_context_v1") => {
            "v11-snow-covered-real-consumer"
        }
        _ => return Err("captured pre-child phase kind".into()),
    };
    let (_, reduction, ledger, receipt) = reconstruct_provisional_on_clone_for_constraint_owner(
        &clock,
        support,
        context,
        forcing,
        expected_owner,
    )?;
    if serde_json::to_vec(&reduction).map_err(|error| error.to_string())? != reduction_bytes
        || serde_json::to_vec(&ledger).map_err(|error| error.to_string())? != ledger_bytes
        || serde_json::to_vec(&receipt).map_err(|error| error.to_string())? != receipt_bytes
    {
        return Err("captured provisional durable operands".into());
    }
    Ok(RestoredCapturedPreChildContextV1 {
        parent,
        clock,
        beginning_stage3,
        pending_terminal_parcels,
        beginning_snow_enthalpy_material_owner,
        reduction,
        ledger,
        receipt,
        binding: get("coupled_binding")?.clone(),
    })
}

/// A native inactive-prefix proof authenticates its supplied receipt graph but
/// cannot establish that the graph came from this restored clock.  Bind every
/// recorded join and terminal event back to the accepted history before the
/// proof is compared with the recorded result.
#[cfg(all(test, feature = "persisted-restart-v1"))]
fn validate_snow_free_prefix_membership_v1(
    row: &serde_json::Value,
    clock: &CoupledClockStateV1,
    surface_configuration: &crate::DirectSurfaceLiquidConfiguration,
) -> Result<(), String> {
    let diagnostics = row
        .get("phase_diagnostics")
        .ok_or("snow-free phase diagnostics")?;
    let joins =
        crate::snow_stage3_v11_attachment::diagnostic_restore_coupled_subslab_receipts_value_v2(
            diagnostics
                .get("ordered_owner_joins")
                .ok_or("snow-free ordered owner joins")?
                .clone(),
        )?;
    let groups: Vec<crate::snow_stage3_v11_attachment::Stage3V11TerminalEventGroupV1> =
        serde_json::from_value(
            diagnostics
                .get("ordered_event_groups")
                .ok_or("snow-free ordered event groups")?
                .clone(),
        )
        .map_err(|error| error.to_string())?;
    let parent_support: TimeSupport = serde_json::from_value(
        diagnostics
            .get("prefix_validation_parent_support")
            .ok_or("snow-free prefix parent support")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    if joins.len() != 8 || groups.len() != 1 {
        return Err("snow-free prefix cardinality".into());
    }
    for join in &joins {
        let matches = clock
            .accepted_slab_receipts()
            .iter()
            .filter(|slab| {
                if slab.support() != join.owner_join.support
                    || slab.slab_id().digest() != join.owner_join.accepted_slab_sha256
                    || slab.parent_transaction_id().digest()
                        != join.owner_join.parent_transaction_sha256
                {
                    return false;
                }
                let value = serde_json::to_value(slab).ok();
                value
                    .as_ref()
                    .and_then(|value| value.get("begin_owner_set"))
                    == Some(&serde_json::json!(
                        join.owner_join.beginning_complete_owner_set_sha256
                    ))
                    && value.as_ref().and_then(|value| value.get("end_owner_set"))
                        == Some(&serde_json::json!(
                            join.owner_join.ending_complete_owner_set_sha256
                        ))
            })
            .count();
        if matches != 1 {
            return Err("snow-free prefix accepted-slab membership".into());
        }
    }
    for group in &groups {
        let accepted = group
            .accepted_event_receipt
            .as_ref()
            .ok_or("snow-free terminal accepted event")?;
        let matches = clock
            .accepted_event_receipts()
            .iter()
            .filter(|event| {
                event.id() == accepted.id()
                    && event.tick() == accepted.tick()
                    && event.ordinal() == accepted.ordinal()
                    && event.parent_transaction_id() == accepted.parent_transaction_id()
                    && event.beginning_owner_set_digest() == accepted.beginning_owner_set_digest()
                    && event.ending_owner_set_digest() == accepted.ending_owner_set_digest()
            })
            .count();
        if matches != 1 {
            return Err("snow-free prefix accepted-event membership".into());
        }
    }
    let validated = crate::direct_runtime::validate_native_inactive_wb14_prefix_v1(
        &joins,
        &groups,
        parent_support,
        surface_configuration,
    )
    .map_err(|error| error.to_string())?;
    if serde_json::to_value(validated).map_err(|error| error.to_string())?
        != *diagnostics
            .get("validated_native_inactive_wb14_prefix")
            .ok_or("snow-free recorded prefix proof")?
    {
        return Err("snow-free recomputed prefix proof comparison".into());
    }
    Ok(())
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
pub(crate) fn restore_provider_bound_context_from_rows(
    rows: &[serde_json::Value],
    context: &DirectSnowStage3V11StaticContext,
    pinned_provider_configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    pinned_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    pinned_frozen_litter_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    pinned_hydrology_constructor_inputs: crate::DirectRunConstructorInputs,
) -> Result<RestoredProviderBoundContextV1, String> {
    let (target, day) = select_provider_capture_rows(rows, context)?;
    let prepared = restore_provider_prepared_parts(target, day, pinned_provider_configuration)?;
    let parent_support = prepared
        .restored_day
        .supports()
        .get(B01_INTERVAL_INDEX)
        .ok_or("captured parent support index missing")?;
    let (captured, forcing_receipt) = restore_provider_current_child(
        target,
        context,
        &prepared.provider,
        &prepared.prepared_support,
        parent_support,
        prepared.target_support,
    )?;
    let consumer = restore_provider_native_consumer(
        target,
        day,
        context,
        &captured,
        ReaderNativePinsV1 {
            provider: pinned_provider_configuration,
            lse: pinned_lse_configuration,
            frozen_lse: pinned_frozen_litter_lse_configuration,
            hydrology: pinned_hydrology_constructor_inputs,
        },
    )?;
    let snow_enthalpy_material_resident = restore_provider_snow_material(day, &captured)?;
    let (archived_receipt_prefix, authenticated_archived_days) =
        restore_provider_archive_context(rows, day, context, pinned_lse_configuration)?;
    Ok(RestoredProviderBoundContextV1 {
        prepared_day: prepared.restored_day,
        prepared_support: prepared.prepared_support,
        forcing_receipt,
        consumer,
        archived_receipt_prefix,
        snow_enthalpy_material_resident,
        authenticated_archived_days,
        captured,
    })
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn select_provider_capture_rows<'a>(
    rows: &'a [serde_json::Value],
    context: &DirectSnowStage3V11StaticContext,
) -> Result<(&'a serde_json::Value, &'a serde_json::Value), String> {
    let target = rows
        .iter()
        .filter(|row| {
            (row.get("kind") == Some(&serde_json::json!("b01_wb14_pre_child_current_context_v1"))
                || row.get("kind")
                    == Some(&serde_json::json!(
                        "b01_wb14_snow_free_pre_child_current_context_v1"
                    )))
                && row.get("day_index") == Some(&serde_json::json!(B01_DAY_INDEX))
                && row.get("interval_index") == Some(&serde_json::json!(B01_INTERVAL_INDEX))
                && row.get("static_run_identity") == Some(&serde_json::json!(context.run_identity))
                && row.get("static_topology_identity")
                    == Some(&serde_json::json!(context.topology_identity))
        })
        .collect::<Vec<_>>();
    let [target] = target.as_slice() else {
        return Err("captured pre-child target row missing or duplicate".into());
    };
    let day = rows
        .iter()
        .filter(|row| {
            row.get("kind")
                == Some(&serde_json::json!(
                    "b01_wb14_prepared_day_current_context_v1"
                ))
                && row.get("day_index") == Some(&serde_json::json!(B01_DAY_INDEX))
                && row.get("static_run_identity") == Some(&serde_json::json!(context.run_identity))
                && row.get("static_topology_identity")
                    == Some(&serde_json::json!(context.topology_identity))
        })
        .collect::<Vec<_>>();
    let [day] = day.as_slice() else {
        return Err("captured prepared-day row missing or duplicate".into());
    };
    Ok((target, day))
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
struct ProviderPreparedPartsV1 {
    provider: crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
    restored_day: crate::ValidatedPreparedStage3V11DayV1,
    prepared_support: crate::DirectSnowStage3V11PreparedSupport,
    target_support: TimeSupport,
}
#[cfg(all(test, feature = "persisted-restart-v1"))]
fn restore_provider_prepared_parts(
    target: &serde_json::Value,
    day: &serde_json::Value,
    pinned_provider_configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
) -> Result<ProviderPreparedPartsV1, String> {
    let provider: ProviderCaptureV1 = serde_json::from_value(
        day.get("provider_constructor_operands")
            .ok_or("captured provider operands missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let provider = restore_provider_day(provider, pinned_provider_configuration)?;
    let captures: Vec<PreparedSupportCaptureV1> = serde_json::from_value(
        day.get("ordered_support_constructor_operands")
            .ok_or("captured ordered supports missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    if captures.len() != 48 {
        return Err("captured prepared-day support cardinality".into());
    }
    let target_support: TimeSupport = serde_json::from_value(
        target
            .get("support")
            .ok_or("captured target support missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    if target_support.start_ns().get() != B01_CHILD_START_NS
        || target_support.end_ns().get() != B01_CHILD_END_NS
    {
        return Err("captured target child support selector".into());
    }
    let restored_supports = captures
        .into_iter()
        .map(|capture| restore_prepared_support(capture, &provider))
        .collect::<Result<Vec<_>, _>>()?;
    let restored_day = crate::PreparedStage3V11DayV1::bind_production_provider_day(
        &provider,
        B01_DAY_INDEX,
        restored_supports,
    )
    .map_err(|error| error.to_string())?;
    let target_capture: PreparedSupportCaptureV1 = serde_json::from_value(
        target
            .get("prepared_support_constructor_operands")
            .ok_or("captured target support operands missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let prepared_support = restore_prepared_support(target_capture, &provider)?;
    let parent_support = restored_day
        .supports()
        .get(B01_INTERVAL_INDEX)
        .ok_or("captured parent support index missing")?;
    let recorded_parent_support: TimeSupport = serde_json::from_value(
        target
            .get("parent_support")
            .ok_or("captured target parent support missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    if prepared_support.support() != target_support
        || recorded_parent_support != parent_support.support()
        || target_support.start_ns() < parent_support.support().start_ns()
        || target_support.end_ns() > parent_support.support().end_ns()
    {
        return Err("captured child/parent support projection join".into());
    }
    Ok(ProviderPreparedPartsV1 {
        provider,
        restored_day,
        prepared_support,
        target_support,
    })
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn restore_provider_current_child(
    target: &serde_json::Value,
    context: &DirectSnowStage3V11StaticContext,
    provider: &crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
    prepared_support: &crate::DirectSnowStage3V11PreparedSupport,
    parent_support: &crate::DirectSnowStage3V11PreparedSupport,
    target_support: TimeSupport,
) -> Result<
    (
        RestoredCapturedPreChildContextV1,
        openwepp_coupled_time::Digest32,
    ),
    String,
> {
    let beginning_stage3_bytes: Vec<u8> = serde_json::from_value(
        target
            .get("beginning_stage3_canonical_json")
            .ok_or("captured beginning Stage3 owners missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let beginning_stage3: BTreeMap<u32, crate::DirectSnowStage3PersistentState> =
        serde_json::from_slice(&beginning_stage3_bytes).map_err(|error| error.to_string())?;
    let captured = restore_captured_pre_child_context(target, context)?;
    let pending_terminal_parcels: BTreeMap<
        openwepp_coupled_time::Digest32,
        crate::DirectSnowStage3V11TerminalParcel,
    > = serde_json::from_slice(
        &serde_json::from_value::<Vec<u8>>(
            target
                .get("terminal_parcels_produced_unconsumed_canonical_json")
                .ok_or("captured terminal parcels missing")?
                .clone(),
        )
        .map_err(|error| error.to_string())?,
    )
    .map_err(|error| error.to_string())?;
    let active_lanes = parent_support
        .restart_authority_state_derived_active_snow_lanes_v1(
            &beginning_stage3,
            &pending_terminal_parcels,
        )
        .map_err(|error| error.to_string())?;
    // `coupled_subslab` accepts the adaptive ordinal for receipt construction;
    // its support projection is ordinal-independent (the source deliberately
    // discards that argument).  Validate the child against that canonical
    // projection rather than comparing it to the unlike 30-minute parent.
    let projected_child = parent_support
        .coupled_subslab(target_support, 0)
        .map_err(|error| error.to_string())?
        .retain_active_snow_lanes(&active_lanes)
        .map_err(|error| error.to_string())?;
    if &projected_child != prepared_support {
        return Err("captured child canonical adaptive projection".into());
    }
    let forcing_receipt = crate::snow_stage3_v11_attachment::canonical_parent_forcing_digest(
        B01_DAY_INDEX,
        B01_INTERVAL_INDEX,
        provider
            .gsi_receipt_digest()
            .map_err(|error| error.to_string())?,
        parent_support,
    )
    .map_err(|error| error.to_string())?;
    if target
        .get("provisional_constructor_inputs")
        .and_then(|inputs| inputs.get("forcing_receipt"))
        != Some(&serde_json::json!(forcing_receipt))
    {
        return Err("captured provider-derived forcing receipt".into());
    }
    Ok((captured, forcing_receipt))
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
struct ReaderNativePinsV1<'a> {
    provider: &'a crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    lse: &'a openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    frozen_lse: &'a openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    hydrology: crate::DirectRunConstructorInputs,
}
#[cfg(all(test, feature = "persisted-restart-v1"))]
fn restore_provider_native_consumer(
    target: &serde_json::Value,
    day: &serde_json::Value,
    context: &DirectSnowStage3V11StaticContext,
    captured: &RestoredCapturedPreChildContextV1,
    pins: ReaderNativePinsV1<'_>,
) -> Result<DirectV10RealConsumerShadow, String> {
    let hydrology_capture: DirectRunFrameDynamicCaptureV1 = serde_json::from_value(
        target
            .get("native_hydrology_frame_dynamic_constructor_operands")
            .ok_or("captured native hydrology dynamic frame missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let hydrology_frame = restore_direct_run_frame_dynamic(
        hydrology_capture,
        pins.hydrology.clone(),
        &context.surface_liquid_configuration,
    )?;
    let target_soil = serde_json::from_value(
        target
            .get("native_soil_v2_constructor_operands")
            .ok_or("captured native target soil missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let committed_bootstrap = serde_json::from_value(
        day.get("native_committed_bootstrap_soil_v2_constructor_operands")
            .ok_or("captured native bootstrap soil missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let lane_maps = serde_json::from_value(
        target
            .get("native_lane_map_constructor_operands")
            .ok_or("captured native lane maps missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let consumer = DirectV10RealConsumerShadow::diagnostic_restore_native_consumer_v1(
        target
            .get("native_consumer_constructor_operands")
            .ok_or("captured native consumer operands missing")?,
        target_soil,
        committed_bootstrap,
        lane_maps,
        &captured.clock,
        hydrology_frame.clone(),
        &context.surface_liquid_configuration,
        pins.lse,
        pins.frozen_lse,
        pins.provider,
        std::sync::Arc::new(pins.hydrology),
    )
    .map_err(|error| error.to_string())?;
    import_and_reconstruct_pre_child_context(target, context, &consumer)?;
    Ok(consumer)
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn restore_provider_snow_material(
    day: &serde_json::Value,
    captured: &RestoredCapturedPreChildContextV1,
) -> Result<crate::snow_stage3_v11_attachment::SnowStage3V11SnowEnthalpyMaterialResidentV1, String>
{
    let day_material_residents: crate::snow_stage3_v11_attachment::
        SnowStage3V11SnowEnthalpyMaterialResidentSetV1 =
        serde_json::from_value(
            day.get("snow_enthalpy_material_residents")
                .ok_or("captured snow-enthalpy material residents missing")?
                .clone(),
        )
        .map_err(|error| error.to_string())?;
    if day_material_residents.pending_candidate.is_some()
        || day_material_residents.in_progress_day_candidate.is_some()
        || day_material_residents.in_progress_support_current.is_some()
    {
        return Err("captured prepared-day material resident posture".into());
    }
    let mut snow_chronology = day_material_residents.committed.accepted_owner_chronology;
    if day_material_residents.committed.current_owner.as_ref() != snow_chronology.last()
        || snow_chronology
            .iter()
            .any(|owner| owner.validate().is_err())
        || snow_chronology
            .windows(2)
            .any(|pair| pair[1].receipt().validate_successor_of(&pair[0]).is_err())
    {
        return Err("captured snow-enthalpy prefix resident chronology".into());
    }
    let current = captured
        .beginning_snow_enthalpy_material_owner
        .clone()
        .ok_or("captured native target requires snow-enthalpy material owner")?;
    if snow_chronology.last() != Some(&current) {
        let previous = snow_chronology
            .last()
            .ok_or("captured snow-enthalpy prefix chronology missing")?;
        current
            .receipt()
            .validate_successor_of(previous)
            .map_err(|error| error.to_string())?;
        snow_chronology.push(current);
    }
    let current_snow_owner = snow_chronology.last().cloned();
    if current_snow_owner
        .as_ref()
        .is_none_or(|owner| owner.base_material_owner() != &captured.beginning_stage3)
    {
        return Err("captured snow-enthalpy current/base material owner join".into());
    }
    Ok(
        crate::snow_stage3_v11_attachment::SnowStage3V11SnowEnthalpyMaterialResidentV1 {
            current_owner: current_snow_owner,
            accepted_owner_chronology: snow_chronology,
        },
    )
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn restore_provider_archive_context(
    rows: &[serde_json::Value],
    day: &serde_json::Value,
    context: &DirectSnowStage3V11StaticContext,
    pinned_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
) -> Result<
    (
        crate::Stage3ArchivedReceiptPrefixV1,
        Vec<AuthenticatedArchivedDayV1>,
    ),
    String,
> {
    let archived_next_parent_sequence = serde_json::from_value(
        day.get("committed_next_parent_sequence")
            .ok_or("captured next parent sequence missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    if day.get("committed_receipt_tail_count") != Some(&serde_json::json!(0)) {
        return Err("captured B01 committed receipt tail must be archived".into());
    }
    let archived_receipt_prefix: crate::Stage3ArchivedReceiptPrefixV1 = serde_json::from_value(
        day.get("archived_receipt_prefix")
            .ok_or("captured archived receipt prefix missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let (archive_manifest, authenticated_archived_days) =
        restore_provider_archived_rows(rows, context, pinned_lse_configuration)?;
    let committed_clock_restart_bytes: Vec<u8> = serde_json::from_value(
        day.get("committed_clock_restart_canonical_json")
            .ok_or("captured committed clock restart missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    let committed_clock = restore_coupled_clock(
        &committed_clock_restart_bytes,
        digest_bytes(CLOCK_MODEL_DOMAIN),
        digest_bytes(CLOCK_AUTHORITY_DOMAIN),
        context.controller_policy,
    )?
    .clock()
    .clone();
    let committed_owner_set =
        complete_owner_set_digest(committed_clock.owners()).map_err(|error| error.to_string())?;
    archived_receipt_prefix
        .validate()
        .map_err(|error| error.to_string())?;
    if archived_receipt_prefix.run_identity != context.run_identity
        || archived_receipt_prefix.topology_identity != context.topology_identity
        || archived_receipt_prefix.accepted_until_ns != committed_clock.accepted_until().get()
        || archived_receipt_prefix.next_parent_sequence != archived_next_parent_sequence
        || archived_receipt_prefix.ending_owner_set_sha256 != Some(committed_owner_set)
        || archive_manifest.committed_day_count != archived_receipt_prefix.archived_day_count
        || archive_manifest.ordered_day_chain_sha256
            != archived_receipt_prefix.ordered_day_chain_sha256
        || archive_manifest.archive_content_root_sha256
            != archived_receipt_prefix.archive_content_root_sha256
    {
        return Err("captured archive prefix/day-start owner-clock join".into());
    }
    Ok((archived_receipt_prefix, authenticated_archived_days))
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn restore_provider_archived_rows(
    rows: &[serde_json::Value],
    context: &DirectSnowStage3V11StaticContext,
    pinned_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
) -> Result<
    (
        crate::Stage3CommittedDayArchiveManifestV1,
        Vec<AuthenticatedArchivedDayV1>,
    ),
    String,
> {
    let archived_rows = rows
        .iter()
        .filter(|row| {
            row.get("kind")
                == Some(&serde_json::json!(
                    "b01_wb14_committed_day_archive_record_v1"
                ))
                && row.get("static_run_identity") == Some(&serde_json::json!(context.run_identity))
                && row.get("static_topology_identity")
                    == Some(&serde_json::json!(context.topology_identity))
        })
        .collect::<Vec<_>>();
    if archived_rows.len() != B01_DAY_INDEX {
        return Err("captured committed-day archive record cardinality".into());
    }
    let mut archive_manifest = crate::Stage3CommittedDayArchiveManifestV1::empty(
        context.run_identity,
        context.topology_identity,
    )
    .map_err(|error| error.to_string())?;
    let mut authenticated_archived_days: Vec<AuthenticatedArchivedDayV1> =
        Vec::with_capacity(B01_DAY_INDEX);
    for expected_day in 0..B01_DAY_INDEX {
        let matches = archived_rows
            .iter()
            .filter(|row| row.get("day_index") == Some(&serde_json::json!(expected_day)))
            .collect::<Vec<_>>();
        let [row] = matches.as_slice() else {
            return Err("captured committed-day archive record missing or duplicate".into());
        };
        let entry: crate::Stage3CommittedDayArchiveEntryV1 = serde_json::from_value(
            row.get("archive_entry")
                .ok_or("captured archive entry missing")?
                .clone(),
        )
        .map_err(|error| error.to_string())?;
        let canonical_record: Vec<u8> = serde_json::from_value(
            row.get("canonical_record")
                .ok_or("captured canonical archive record missing")?
                .clone(),
        )
        .map_err(|error| error.to_string())?;
        let authenticated = authenticate_archived_day_v1(
            entry.clone(),
            &canonical_record,
            context,
            pinned_lse_configuration,
        )?;
        validate_provider_publication_prefix(authenticated_archived_days.last(), &authenticated)?;
        archive_manifest
            .append(entry)
            .map_err(|error| error.to_string())?;
        authenticated_archived_days.push(authenticated);
    }
    Ok((archive_manifest, authenticated_archived_days))
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
fn validate_provider_publication_prefix(
    previous: Option<&AuthenticatedArchivedDayV1>,
    authenticated: &AuthenticatedArchivedDayV1,
) -> Result<(), String> {
    if let Some(previous) = previous {
        if authenticated.publication.prefix_support_count
            != previous.publication.cumulative_support_count
            || authenticated.publication.prefix_event_count
                != previous.publication.cumulative_event_count
            || authenticated.publication.prefix_authority_sha256
                != previous.publication.cumulative_authority_sha256
            || authenticated.publication.prefix_ending_owner_set_sha256
                != Some(previous.publication.ending_owner_set_sha256)
        {
            return Err("captured archived publication prefix chronology".into());
        }
    } else if authenticated.publication.prefix_support_count != 0
        || authenticated.publication.prefix_event_count != 0
        || authenticated.publication.prefix_authority_sha256
            != digest_bytes(b"OPENWEPP_ACCEPTED_PUBLICATION_INCREMENTAL_AUTHORITY_V1\0")
        || authenticated
            .publication
            .prefix_ending_owner_set_sha256
            .is_some()
    {
        return Err("captured archived publication genesis prefix".into());
    }
    Ok(())
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
pub(crate) fn restore_provider_bound_context_from_file(
    path: &std::path::Path,
    context: &DirectSnowStage3V11StaticContext,
    pinned_provider_configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    pinned_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    pinned_frozen_litter_lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    pinned_hydrology_constructor_inputs: crate::DirectRunConstructorInputs,
) -> Result<RestoredProviderBoundContextV1, String> {
    let bundle: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    if bundle.get("schema") != Some(&serde_json::json!("snow_accuracy_observation_v2"))
        || bundle.get("physical_enabled") != Some(&serde_json::json!(true))
        || bundle.get("overflow") != Some(&serde_json::json!(false))
        || bundle.get("counts_poisoned") != Some(&serde_json::json!(false))
    {
        return Err("captured observation bundle authority".into());
    }
    let rows: Vec<serde_json::Value> = serde_json::from_value(
        bundle
            .get("physical")
            .ok_or("captured observation rows missing")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    restore_provider_bound_context_from_rows(
        &rows,
        context,
        pinned_provider_configuration,
        pinned_lse_configuration,
        pinned_frozen_litter_lse_configuration,
        pinned_hydrology_constructor_inputs,
    )
}

/// Decode one member-backed exported row without rebuilding the original
/// observation stream.  The exporter retains map-key events so duplicate keys
/// are refused instead of silently becoming last-key-wins JSON.  Callers name
/// the large members they deliberately do not need; this keeps chronology and
/// parent validation usable before native-consumer decoding.
#[cfg(test)]
fn attach_member_backed_value_v1(
    stack: &mut [serde_json::Value],
    keys: &mut [Option<String>],
    root: &mut Option<serde_json::Value>,
    value: serde_json::Value,
) -> Result<(), String> {
    let Some(parent) = stack.last_mut() else {
        if root.replace(value).is_some() {
            return Err("member-backed row has multiple roots".into());
        }
        return Ok(());
    };
    match parent {
        serde_json::Value::Array(values) => values.push(value),
        serde_json::Value::Object(values) => {
            let key = keys
                .last_mut()
                .and_then(Option::take)
                .ok_or("member-backed object value lacks key")?;
            if values.insert(key, value).is_some() {
                return Err("member-backed row duplicate object member".into());
            }
        }
        _ => return Err("member-backed row scalar container".into()),
    }
    Ok(())
}

#[cfg(test)]
fn validate_member_backed_external_end_v1(
    item: &serde_json::Value,
    pending_external: &mut Option<(String, usize, openwepp_coupled_time::Digest32)>,
) -> Result<(), String> {
    let (file, bytes, digest) = pending_external
        .take()
        .ok_or("member-backed unexpected external JSON end")?;
    let expected_file = item
        .get("file")
        .and_then(serde_json::Value::as_str)
        .ok_or("member-backed external end file")?;
    let expected_bytes = item
        .get("bytes")
        .and_then(serde_json::Value::as_u64)
        .and_then(|value| usize::try_from(value).ok())
        .ok_or("member-backed external end bytes")?;
    let expected_digest: openwepp_coupled_time::Digest32 = serde_json::from_value(
        item.get("sha256")
            .ok_or("member-backed external end digest")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    if file != expected_file || bytes != expected_bytes || digest != expected_digest {
        return Err("member-backed external payload identity".into());
    }
    Ok(())
}

#[cfg(test)]
fn decode_member_backed_scalar_event_v1(
    item: &serde_json::Value,
    event: &str,
) -> Result<serde_json::Value, String> {
    Ok(match event {
        "start_map" => serde_json::Value::Object(serde_json::Map::new()),
        "start_array" => serde_json::Value::Array(Vec::new()),
        "string" | "boolean" => item.get("value").cloned().ok_or("member-backed scalar")?,
        "null" => serde_json::Value::Null,
        "number" => {
            let lexeme = item
                .get("value")
                .and_then(|value| value.get("number_lexeme"))
                .and_then(serde_json::Value::as_str)
                .ok_or("member-backed number lexeme")?;
            serde_json::from_str(lexeme).map_err(|error| error.to_string())?
        }
        _ => return Err("member-backed unsupported event".into()),
    })
}

#[cfg(test)]
fn decode_member_backed_row_v1(
    export_root: &std::path::Path,
    event_path: &std::path::Path,
    omitted_members: &BTreeSet<&str>,
) -> Result<serde_json::Value, String> {
    let raw = std::fs::File::open(event_path).map_err(|error| error.to_string())?;
    let reader = std::io::BufReader::new(raw);
    let mut stack = Vec::<serde_json::Value>::new();
    let mut keys = Vec::<Option<String>>::new();
    let mut root = None;
    let mut pending_external = None::<(String, usize, openwepp_coupled_time::Digest32)>;
    let mut skipped_external = false;
    for line in std::io::BufRead::lines(reader) {
        let item: serde_json::Value =
            serde_json::from_str(&line.map_err(|error| error.to_string())?)
                .map_err(|error| error.to_string())?;
        let event = item
            .get("event")
            .and_then(serde_json::Value::as_str)
            .ok_or("member-backed event kind")?;
        if event == "map_key" {
            let key = item
                .get("value")
                .and_then(serde_json::Value::as_str)
                .ok_or("member-backed map key")?;
            if !matches!(stack.last(), Some(serde_json::Value::Object(_))) {
                return Err("member-backed map key outside object".into());
            }
            *keys.last_mut().ok_or("member-backed key stack")? = Some(key.into());
            continue;
        }
        if event == "external_json_start" {
            let member = item
                .get("path")
                .and_then(serde_json::Value::as_array)
                .and_then(|path| path.first())
                .and_then(|entry| entry.get("member"))
                .and_then(serde_json::Value::as_str)
                .ok_or("member-backed external member path")?;
            if omitted_members.contains(member) {
                skipped_external = true;
                continue;
            }
            let file = item
                .get("file")
                .and_then(serde_json::Value::as_str)
                .ok_or("member-backed external file")?;
            let payload =
                std::fs::read(export_root.join(file)).map_err(|error| error.to_string())?;
            let value = serde_json::from_slice(&payload).map_err(|error| error.to_string())?;
            pending_external = Some((file.into(), payload.len(), digest_bytes(&payload)));
            attach_member_backed_value_v1(&mut stack, &mut keys, &mut root, value)?;
            continue;
        }
        if event == "external_json_end" {
            if skipped_external {
                skipped_external = false;
                continue;
            }
            validate_member_backed_external_end_v1(&item, &mut pending_external)?;
            continue;
        }
        if event == "external_byte_array_start" || event == "external_byte_array_end" {
            continue;
        }
        if event == "end_map" || event == "end_array" {
            let value = stack
                .pop()
                .ok_or("member-backed unexpected container end")?;
            keys.pop().ok_or("member-backed key stack end")?;
            attach_member_backed_value_v1(&mut stack, &mut keys, &mut root, value)?;
            continue;
        }
        let value = decode_member_backed_scalar_event_v1(&item, event)?;
        if event == "start_map" || event == "start_array" {
            stack.push(value);
            keys.push(None);
        } else {
            attach_member_backed_value_v1(&mut stack, &mut keys, &mut root, value)?;
        }
    }
    if !stack.is_empty() {
        return Err("member-backed truncated event stream".into());
    }
    if pending_external.is_some() || skipped_external {
        return Err("member-backed missing external JSON end".into());
    }
    root.ok_or("member-backed row missing root".into())
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
pub(crate) struct RestoredSnowFreeClockParentV1 {
    pub clock: CoupledClockStateV1,
    pub parent: V11ParentTransaction,
    recorded_row: serde_json::Value,
}

/// Small, independent first component for a member-backed export.  It opens
/// neither the native consumer operand nor archive records and is therefore
/// suitable for reporting a parent/clock refusal before any large decode.
#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
pub(crate) fn restore_snow_free_clock_parent_from_member_export(
    export_root: &std::path::Path,
) -> Result<RestoredSnowFreeClockParentV1, String> {
    let summary: serde_json::Value = serde_json::from_slice(
        &std::fs::read(export_root.join("summary.json")).map_err(|error| error.to_string())?,
    )
    .map_err(|error| error.to_string())?;
    if summary.get("status") != Some(&serde_json::json!("COMPLETE")) {
        return Err("member-backed export is not complete".into());
    }
    let rows = summary
        .get("rows")
        .and_then(serde_json::Value::as_array)
        .ok_or("member-backed export rows")?;
    let matches = rows
        .iter()
        .filter(|entry| {
            entry
                .get("kinds")
                .and_then(serde_json::Value::as_array)
                .is_some_and(|kinds| {
                    kinds
                        .iter()
                        .any(|kind| kind == "b01_wb14_snow_free_pre_child_current_context_v1")
                })
        })
        .collect::<Vec<_>>();
    let [target] = matches.as_slice() else {
        return Err("member-backed snow-free target missing or duplicate".into());
    };
    let event_file = target
        .get("event_file")
        .and_then(serde_json::Value::as_str)
        .ok_or("member-backed target event path")?;
    let event_bytes =
        std::fs::read(export_root.join(event_file)).map_err(|error| error.to_string())?;
    let expected_event_digest: openwepp_coupled_time::Digest32 = serde_json::from_value(
        target
            .get("event_file_sha256")
            .ok_or("member-backed target event digest")?
            .clone(),
    )
    .map_err(|error| error.to_string())?;
    if target
        .get("event_file_bytes")
        .and_then(serde_json::Value::as_u64)
        .and_then(|value| usize::try_from(value).ok())
        != Some(event_bytes.len())
        || digest_bytes(&event_bytes) != expected_event_digest
    {
        return Err("member-backed target event identity".into());
    }
    let omitted = BTreeSet::from(["native_consumer_constructor_operands"]);
    let row = decode_member_backed_row_v1(export_root, &export_root.join(event_file), &omitted)?;
    if row.get("kind")
        != Some(&serde_json::json!(
            "b01_wb14_snow_free_pre_child_current_context_v1"
        ))
        || row.get("capture_phase") != Some(&serde_json::json!("snow_free"))
    {
        return Err("member-backed snow-free target phase".into());
    }
    let get = |name| {
        row.get(name)
            .ok_or_else(|| format!("capture missing {name}"))
    };
    let model = serde_json::from_value(get("coupled_clock_restart_model_sha256")?.clone())
        .map_err(|error| error.to_string())?;
    let authority = serde_json::from_value(get("coupled_clock_restart_authority_sha256")?.clone())
        .map_err(|error| error.to_string())?;
    let policy = serde_json::from_value(get("coupled_clock_restart_policy_sha256")?.clone())
        .map_err(|error| error.to_string())?;
    let clock_bytes: Vec<u8> =
        serde_json::from_value(get("coupled_clock_restart_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let clock = restore_coupled_clock(&clock_bytes, model, authority, policy)?
        .clock()
        .clone();
    let vegetation_bytes: Vec<u8> =
        serde_json::from_value(get("vegetation_configuration_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let vegetation =
        serde_json::from_slice(&vegetation_bytes).map_err(|error| error.to_string())?;
    let lse_bytes: Vec<u8> =
        serde_json::from_value(get("lse_configuration_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let lse = serde_json::from_slice(&lse_bytes).map_err(|error| error.to_string())?;
    let parent_bytes: Vec<u8> =
        serde_json::from_value(get("parent_checkpoint_canonical_json")?.clone())
            .map_err(|error| error.to_string())?;
    let parent = restore_parent_with_configured_bgc_scope(&parent_bytes, &vegetation, &lse)?;
    if parent.parent_transaction_id() != clock.parent_transaction_id() {
        return Err("member-backed restored parent/clock identity".into());
    }
    Ok(RestoredSnowFreeClockParentV1 {
        clock,
        parent,
        recorded_row: row,
    })
}

/// Localize a `ChildIdentity` refusal without changing the canonical prefix
/// validator or turning any failed prerequisite into acceptance.
#[cfg(all(test, feature = "persisted-restart-v1"))]
fn diagnose_snow_free_prefix_receipt_gates_v1(
    row: &serde_json::Value,
    surface_configuration: &crate::DirectSurfaceLiquidConfiguration,
) -> Result<(), String> {
    let diagnostics = row
        .get("phase_diagnostics")
        .ok_or("snow-free phase diagnostics")?;
    let receipts =
        crate::snow_stage3_v11_attachment::diagnostic_restore_coupled_subslab_receipts_value_v2(
            diagnostics
                .get("ordered_owner_joins")
                .ok_or("snow-free ordered owner joins")?
                .clone(),
        )?;
    for (index, receipt) in receipts.iter().enumerate() {
        for ((ofe_id, tile_id), boundary) in &receipt.destination_receipts {
            boundary.validate().map_err(|error| {
                format!("gate boundary.validate[{index},{ofe_id},{tile_id:?}]: {error}")
            })?;
        }
        for (lane_id, lane) in &receipt.lane_receipts {
            lane.validate()
                .map_err(|error| format!("gate lane.validate[{index},{lane_id}]: {error}"))?;
        }
        receipt
            .validate()
            .map_err(|error| format!("gate receipt.validate[{index}]: {error}"))?;
        if receipt.wb14_ofe_topology != surface_configuration.ofe_topology {
            return Err(format!("gate WB14 topology[{index}]"));
        }
        crate::direct_runtime::stage3_covered_native_inactive_child_custody_binding(
            &receipt.wb14_child_replay_bytes,
            &surface_configuration.ofe_topology,
        )
        .map_err(|error| format!("gate WB14 child binding[{index}]: {error}"))?
        .ok_or_else(|| format!("gate WB14 child binding absent[{index}]"))?;
    }
    Ok(())
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
pub(crate) mod member_backed_restore_tests {
    use super::*;

    pub(crate) struct ProbeAudit(
        Option<openwepp_land_surface_energy::solver_mechanism_audit::Session>,
    );

    impl ProbeAudit {
        pub(crate) fn begin() -> Self {
            crate::direct_runtime::reset_direct_runtime_audit_counters();
            crate::runtime_inputs::reset_gsi_receipt_advance_audit_v1();
            Self(Some(
                openwepp_land_surface_energy::solver_mechanism_audit::begin_mechanism_audit(
                    false, 0,
                )
                .expect("begin diagnostic mechanism audit"),
            ))
        }
    }

    impl Drop for ProbeAudit {
        fn drop(&mut self) {
            let mechanism = self.0.take().expect("audit session").finish();
            let direct = crate::direct_runtime::direct_runtime_audit_snapshot();
            let gsi = crate::runtime_inputs::gsi_receipt_advance_audit_v1();
            let native =
                crate::v9_real_consumer_shadow::take_covered_native_physical_path_audit_v1();
            println!("probe-mechanism-audit: {mechanism:?}");
            println!("probe-direct-audit: {direct:?}");
            println!("probe-gsi-receipt-advance-audit: {gsi:?}");
            println!("probe-native-physics-audit: {native:?}");
            if !std::thread::panicking() {
                let mechanism = mechanism.expect("complete diagnostic mechanism audit");
                assert_eq!(mechanism.maps.starts, 0);
                assert_eq!(mechanism.solves.starts, 0);
                assert_eq!(mechanism.sweeps.starts, 0);
                assert_eq!(mechanism.probes.starts, 0);
                assert_eq!(mechanism.evaluations.starts, 0);
                assert_eq!(mechanism.leaf_calls, 0);
                assert_eq!(direct.day_frame_commits, 0);
                assert_eq!(direct.publication_capture_runs, 0);
                assert_eq!(direct.direct_compute_operations, 0);
                assert_eq!(direct.phase_span_runs, 0);
                assert_eq!(native.snow_free_litter_physics_call_count, 0);
                assert_eq!(native.snow_free_surface_physics_call_count, 0);
                assert_eq!(native.snow_free_wb14_physics_call_count, 0);
            }
        }
    }

    #[test]
    fn recorded_archive_manifest_rejects_semantic_order_and_namespace_changes() {
        let export = std::path::PathBuf::from(
            std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("export"),
        );
        let seed = std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("seed");
        let pin = extract_pinned_seed_configuration_v1(std::path::Path::new(&seed)).expect("pin");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        let summary: serde_json::Value =
            serde_json::from_slice(&std::fs::read(export.join("summary.json")).expect("summary"))
                .expect("summary JSON");
        let mut entries = Vec::new();
        for entry in summary["rows"].as_array().expect("rows") {
            if entry["kinds"] != serde_json::json!(["b01_wb14_committed_day_archive_record_v1"]) {
                continue;
            }
            let row = decode_member_backed_row_v1(
                &export,
                &export.join(entry["event_file"].as_str().expect("event file")),
                &BTreeSet::new(),
            )
            .expect("archive row");
            let archive: crate::Stage3CommittedDayArchiveEntryV1 =
                serde_json::from_value(row["archive_entry"].clone()).expect("entry");
            archive
                .validate()
                .expect("each original entry is independently sealed");
            entries.push(archive);
        }
        assert_eq!(entries.len(), 4);
        let empty = crate::Stage3CommittedDayArchiveManifestV1::empty(
            pin.run_identity,
            pin.topology_identity,
        )
        .expect("empty manifest");
        let mut positive = empty.clone();
        for entry in &entries {
            positive.append(entry.clone()).expect("recorded order");
        }
        positive.validate().expect("complete canonical manifest");
        let day = decode_member_backed_row_v1(
            &export,
            &export.join("rows/108033.events.jsonl"),
            &BTreeSet::new(),
        )
        .expect("day");
        let prefix: crate::Stage3ArchivedReceiptPrefixV1 =
            serde_json::from_value(day["archived_receipt_prefix"].clone()).expect("prefix");
        assert_eq!(
            positive.ordered_day_chain_sha256,
            prefix.ordered_day_chain_sha256
        );
        assert_eq!(
            positive.archive_content_root_sha256,
            prefix.archive_content_root_sha256
        );
        assert_eq!(positive.committed_day_count, prefix.archived_day_count);
        for (name, sequence) in [
            ("omitted first", vec![1]),
            ("duplicate", vec![0, 0]),
            ("reordered", vec![0, 2, 1]),
            ("omitted middle", vec![0, 1, 3]),
        ] {
            let mut candidate = empty.clone();
            let result = sequence.into_iter().try_for_each(|index| {
                candidate
                    .append(entries[index].clone())
                    .map_err(|error| error.to_string())
            });
            println!("manifest poison {name}: {result:?}");
            assert!(
                result.as_ref().is_err_and(
                    |error| error.contains("archive manifest append order or prior root")
                )
            );
            candidate
                .validate()
                .expect("failed append preserves admitted prefix");
        }
        check_foreign_manifest_namespaces(&pin, &entries[0]);
    }

    fn check_foreign_manifest_namespaces(
        pin: &PinnedSeedConfigurationV1,
        entry: &crate::Stage3CommittedDayArchiveEntryV1,
    ) {
        for (name, run, topology) in [
            (
                "run namespace",
                digest_bytes(b"foreign-run"),
                pin.topology_identity,
            ),
            (
                "topology namespace",
                pin.run_identity,
                digest_bytes(b"foreign-topology"),
            ),
        ] {
            let mut foreign = crate::Stage3CommittedDayArchiveManifestV1::empty(run, topology)
                .expect("valid foreign namespace");
            let result = foreign.append(entry.clone());
            println!("manifest poison {name}: {result:?}");
            assert!(matches!(
                result,
                Err(crate::DirectSnowStage3V11AttachmentError::Identity(
                    "archive manifest append order or prior root"
                ))
            ));
        }
    }

    #[test]
    fn archive_first_positive_beginning_rejects_pre_event_owner_substitution() {
        let export = std::path::PathBuf::from(
            std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("export"),
        );
        let seed = std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("seed");
        let pin = extract_pinned_seed_configuration_v1(std::path::Path::new(&seed)).expect("pin");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let target = restore_snow_free_clock_parent_from_member_export(&export).expect("target");
        let bytes: Vec<u8> = serde_json::from_value(
            target.recorded_row["vegetation_configuration_canonical_json"].clone(),
        )
        .expect("vegetation bytes");
        let vegetation: openwepp_vegetation::VegetationConfigurationV11 =
            serde_json::from_slice(&bytes).expect("vegetation");
        assert_eq!(vegetation.imported_v10, pin.vegetation);
        let row = decode_member_backed_row_v1(
            &export,
            &export.join("rows/27431.events.jsonl"),
            &BTreeSet::new(),
        )
        .expect("archive row");
        let entry = serde_json::from_value(row["archive_entry"].clone()).expect("entry");
        let raw =
            std::fs::read(export.join("rows/27431.canonical_record.bin")).expect("actual archive");
        let restored = authenticate_archived_day_with_configuration_v1(
            entry,
            &raw,
            pin.run_identity,
            pin.topology_identity,
            &vegetation,
            &pin.lse,
        )
        .expect("fully authenticated archive zero");
        validate_archive_first_positive_join(&restored.parent_receipt, &restored.publication)
            .expect("positive cross-object join");
        assert_ne!(
            restored.entry.beginning_owner_set_sha256,
            restored.publication.first_positive_beginning_owner,
            "day zero has an admitted event before its first support"
        );
        let mut substituted = restored.publication.clone();
        substituted.first_positive_beginning_owner = restored.entry.beginning_owner_set_sha256;
        let result = validate_archive_first_positive_join(&restored.parent_receipt, &substituted);
        println!("archive beginning semantic substitution: {result:?}");
        assert_eq!(
            result.as_ref().map_err(String::as_str),
            Err("archive parent first-positive beginning/publication join")
        );
    }

    #[test]
    fn provider_authority_scalars_reject_semantic_substitutions_without_installation() {
        let export = std::path::PathBuf::from(
            std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("export"),
        );
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let day = decode_member_backed_row_v1(
            &export,
            &export.join("rows/108033.events.jsonl"),
            &BTreeSet::new(),
        )
        .expect("day");
        let prefix: crate::Stage3ArchivedReceiptPrefixV1 =
            serde_json::from_value(day["archived_receipt_prefix"].clone()).expect("prefix");
        prefix.validate().expect("prefix validates");
        let target = restore_snow_free_clock_parent_from_member_export(&export).expect("target");
        let interval: u128 = serde_json::from_value(target.recorded_row["interval_index"].clone())
            .expect("interval");
        let position = prefix
            .next_parent_sequence
            .checked_add(interval)
            .expect("derived position");
        assert_ne!(
            position, 0,
            "outer current position remains distinct from the native physical counter"
        );
        println!(
            "outer position is nonzero; full native physical-counter custody is checked only from retained frame and native owners"
        );
    }

    #[test]
    fn current_phase_members_validate_without_physics() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let export = std::path::Path::new(&export);
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let target =
            restore_snow_free_clock_parent_from_member_export(export).expect("clock parent");
        let day = decode_member_backed_row_v1(
            export,
            &export.join("rows/108033.events.jsonl"),
            &BTreeSet::new(),
        )
        .expect("prepared day");
        let base: u128 = serde_json::from_value(day["committed_next_parent_sequence"].clone())
            .expect("sequence");
        let interval: u128 = serde_json::from_value(target.recorded_row["interval_index"].clone())
            .expect("interval");
        member_restoration::validate_current_phase(
            &target.recorded_row,
            &target.clock,
            base + interval,
        )
        .expect("phase current/deferred joins");
    }

    #[test]
    fn current_phase_semantic_substitutions_refuse_without_physics() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let export = std::path::Path::new(&export);
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let target =
            restore_snow_free_clock_parent_from_member_export(export).expect("clock parent");
        let day = decode_member_backed_row_v1(
            export,
            &export.join("rows/108033.events.jsonl"),
            &BTreeSet::new(),
        )
        .expect("prepared day");
        let base: u128 = serde_json::from_value(day["committed_next_parent_sequence"].clone())
            .expect("sequence");
        let interval: u128 = serde_json::from_value(target.recorded_row["interval_index"].clone())
            .expect("interval");
        let position = base + interval;
        let original = &target.recorded_row;
        member_restoration::validate_current_phase(original, &target.clock, position)
            .expect("positive phase control");
        let parcel = original["phase_diagnostics"]["pending_terminal_parcels"]
            .as_object()
            .expect("parcel map")
            .keys()
            .next()
            .expect("parcel");
        let cases = [
            ("current position", "/phase_diagnostics/current_stage3/1/next_interval_index".to_owned(), serde_json::json!(position+1), "current Stage3 accepted position"),
            ("current state", "/phase_diagnostics/current_stage3/1/cumulative_melt_kg_m2".to_owned(), serde_json::json!(14.0), "current Stage3 ending snow projection"),
            ("parcel custody", format!("/phase_diagnostics/pending_terminal_parcels/{parcel}/mass_kg_m2_tile_ground"), serde_json::json!(2.0), "current terminal parcel custody posture"),
            ("trial transaction", "/phase_diagnostics/deferred_native_v2_soil_custody/candidate/transaction_id".to_owned(), serde_json::json!(5775), "deferred trial transaction/support"),
            ("trial predecessor", "/phase_diagnostics/deferred_native_v2_soil_custody/candidate/predecessor_transaction_id".to_owned(), serde_json::json!(5772), "deferred unpublished trial seal"),
            ("trial custody variant", "/phase_diagnostics/deferred_native_v2_soil_custody/candidate/accepted_predecessor_receipt_chain_sha256".to_owned(), serde_json::json!("1".repeat(64)), "deferred trial predecessor custody"),
            ("trial exponential credit", "/phase_diagnostics/deferred_native_v2_soil_custody/candidate/layer_credits/0/ending_temperature_k".to_owned(), serde_json::json!(1e-7), "deferred unpublished trial seal"),
            ("deferred trial seal", "/phase_diagnostics/deferred_native_v2_soil_custody/candidate/unpublished_trial_sha256".to_owned(), serde_json::json!("0".repeat(64)), "deferred unpublished trial seal"),
            ("committed/current substitution", "/phase_diagnostics/deferred_native_v2_soil_custody/continuation/original_beginning_owner".to_owned(), day["native_committed_bootstrap_soil_v2_constructor_operands"]["owner"].clone(), "deferred/current resident separation and support join"),
            ("ordered credit state", "/phase_diagnostics/deferred_native_v2_soil_custody/continuation/ordered_layer_credit_chain/0/0/ending_temperature_k".to_owned(), serde_json::json!(271.0), "deferred ordered layer beginning"),
            ("accumulated custody", "/phase_diagnostics/deferred_native_v2_soil_custody/continuation/accumulated_operands/0/energy_j_m2_ofe_ground".to_owned(), serde_json::json!(1.0), "deferred canonical accumulated operand chain"),
        ];
        for (name, pointer, replacement, expected) in cases {
            let mut poisoned = original.clone();
            *poisoned
                .pointer_mut(&pointer)
                .expect("existing semantic field") = replacement;
            let result =
                member_restoration::validate_current_phase(&poisoned, &target.clock, position);
            println!("phase poison {name}: {result:?}");
            assert_eq!(result.as_ref().map_err(String::as_str), Err(expected));
        }
        let original_bytes = serde_json::to_vec(original).expect("original phase bytes");
        for (case, expected) in [
            (0, "deferred ordered transaction lineage"),
            (1, "deferred ordered transaction lineage"),
            (2, "deferred ordered layer beginning"),
            (3, "deferred ordered layer beginning"),
        ] {
            let mut poisoned = original.clone();
            let chain = poisoned["phase_diagnostics"]["deferred_native_v2_soil_custody"]["continuation"]["ordered_layer_credit_chain"].as_array_mut().expect("credit chain");
            match case {
                0 => {
                    chain.remove(0);
                }
                1 => {
                    chain.insert(1, chain[0].clone());
                }
                2 => {
                    chain.swap(0, 1);
                }
                _ => {
                    chain[0][0]["ofe_id"] = serde_json::json!("foreign-ofe");
                }
            }
            let result =
                member_restoration::validate_current_phase(&poisoned, &target.clock, position);
            println!("ordered deferred credit poison {case}: {result:?}");
            assert_eq!(result.as_ref().map_err(String::as_str), Err(expected));
            assert_eq!(
                serde_json::to_vec(original).expect("unchanged phase bytes"),
                original_bytes
            );
        }
        let bytes: Vec<u8> =
            serde_json::from_value(original["surface_liquid_configuration_canonical_json"].clone())
                .expect("surface bytes");
        let surface =
            crate::DirectSurfaceLiquidConfiguration::from_canonical_bytes(&bytes).expect("surface");
        validate_snow_free_prefix_membership_v1(original, &target.clock, &surface)
            .expect("positive prefix");
        for (name, pointer, replacement, expected) in [
            (
                "prefix proof",
                "/phase_diagnostics/validated_native_inactive_wb14_prefix/prefix_end_ns",
                serde_json::json!(1),
                "snow-free recomputed prefix proof comparison",
            ),
            (
                "event membership",
                "/phase_diagnostics/ordered_event_groups/0/accepted_event_receipt/ordinal",
                serde_json::json!(1),
                "snow-free prefix accepted-event membership",
            ),
        ] {
            let mut poisoned = original.clone();
            *poisoned
                .pointer_mut(pointer)
                .expect("existing prefix field") = replacement;
            let result =
                validate_snow_free_prefix_membership_v1(&poisoned, &target.clock, &surface);
            println!("prefix poison {name}: {result:?}");
            assert_eq!(result.as_ref().map_err(String::as_str), Err(expected));
        }
    }

    #[test]
    fn composed_member_native_restoration_from_pinned_seed() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let seed = std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("bound pinned seed");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let result =
            member_restoration::restore(std::path::Path::new(&export), std::path::Path::new(&seed));
        println!("composed-native-result: {result:?}");
        result.expect("composed native restoration");
    }

    #[test]
    fn composed_member_native_restoration_accepts_complete_deferred_admission() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let seed = std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("bound pinned seed");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let result =
            member_restoration::restore(std::path::Path::new(&export), std::path::Path::new(&seed));
        println!("composed-native-result: {result:?}");
        result.expect("complete deferred admission restores original resident without promotion");
    }

    #[test]
    #[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
    fn deferred_credit_capture_represents_no_per_credit_clock_provenance() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let restored =
            restore_snow_free_clock_parent_from_member_export(std::path::Path::new(&export))
                .expect("member clock and parent");
        let continuation = &restored.recorded_row["phase_diagnostics"]["deferred_native_v2_soil_custody"]
            ["continuation"];
        let credits = continuation["ordered_layer_credit_chain"]
            .as_array()
            .expect("recorded ordered layer credit groups");
        assert!(!credits.is_empty(), "retained deferred credit groups");
        for group in credits {
            let group = group.as_array().expect("recorded credit group");
            assert!(!group.is_empty(), "recorded credit-group operands");
            for credit in group {
                for absent_key in [
                    "child_support",
                    "support_start_ns",
                    "support_end_ns",
                    "child_transaction_id",
                    "accepted_event_ordinal",
                ] {
                    assert!(
                        credit.get(absent_key).is_none(),
                        "serialized deferred credit unexpectedly supplies {absent_key}"
                    );
                }
            }
        }
        assert!(
            continuation.get("accumulated_operands").is_some(),
            "this is a provenance absence, not a claim that deferred custody is absent"
        );
    }

    /// Test-only raw-record correspondence validator for the B01 deferred
    /// custody specimen.  It is deliberately JSON/carry/state validation: it
    /// neither calls a physical map nor advances, installs, or promotes a
    /// native soil child.
    pub(super) fn validate_b01_retained_soil_trial_correspondence_v1(
        export: &std::path::Path,
        primitives: &serde_json::Value,
        subslabs: &serde_json::Value,
    ) -> Result<(), String> {
        let records = primitives["records"]
            .as_array()
            .ok_or("retained primitive records")?;
        let restored = restore_snow_free_clock_parent_from_member_export(export)?;
        let phase = &restored.recorded_row["phase_diagnostics"];
        let continuation = &phase["deferred_native_v2_soil_custody"]["continuation"];
        let chain = continuation["ordered_layer_credit_chain"]
            .as_array()
            .ok_or("retained ordered credit chain")?;
        if chain.len() != 12 || records.len() != 24 {
            return Err("retained primitive/credit group cardinality".into());
        }

        // The observer captured every selected primitive twice.  Duplicates
        // are permitted only when all semantic fields agree; capture metadata
        // itself is intentionally not correspondence authority.
        let mut unique = BTreeMap::<String, serde_json::Value>::new();
        for extracted in records {
            let mut semantic = extracted["record"].clone();
            semantic
                .as_object_mut()
                .ok_or("primitive semantic record")?
                .remove("capture");
            let receipt = semantic["receipt"]["receipt_sha256"]
                .as_str()
                .ok_or("primitive receipt identity")?
                .to_owned();
            if let Some(prior) = unique.insert(receipt, semantic.clone()) {
                if prior != semantic {
                    return Err("conflicting duplicate primitive record".into());
                }
            }
        }
        if unique.len() != chain.len() {
            return Err("primitive credit group coverage".into());
        }
        for primitive in unique.values() {
            terminal_trial_receipt_from_raw_v1(&primitive["receipt"])?
                .validate()
                .map_err(|_| "raw trial receipt seal")?;
        }

        let slab_records = subslabs["records"]
            .as_array()
            .ok_or("retained subslab primitive records")?;
        if slab_records.len() != 8 {
            return Err("retained subslab primitive cardinality".into());
        }
        let mut slabs = BTreeMap::<String, &serde_json::Value>::new();
        for extracted in slab_records {
            let record = &extracted["record"];
            let Some(receipt) =
                record["adaptive_terminal_snow_soil_trial_receipts"]["1"]["receipt_sha256"]
                    .as_str()
            else {
                continue;
            };
            let receipt = receipt.to_owned();
            if slabs.insert(receipt, record).is_some() {
                return Err("duplicate subslab trial receipt".into());
            }
        }
        if slabs.len() != 7 {
            return Err("subslab trial receipt cardinality".into());
        }

        let mut raw_by_support = BTreeMap::<(u128, u128), String>::new();
        let mut raw_heat = 0.0;
        for (receipt_id, primitive) in &unique {
            let receipt = &primitive["receipt"];
            let start = receipt["support"]["start_ns"]
                .as_str()
                .ok_or("primitive support start")?
                .parse::<u128>()
                .map_err(|_| "primitive support start integer")?;
            let end = receipt["support"]["end_ns"]
                .as_str()
                .ok_or("primitive support end")?
                .parse::<u128>()
                .map_err(|_| "primitive support end integer")?;
            if raw_by_support
                .insert((start, end), receipt_id.clone())
                .is_some()
            {
                return Err("duplicate raw receipt support".into());
            }
            raw_heat += receipt["soil_heat_j_m2"]
                .as_f64()
                .ok_or("primitive soil heat")?;
        }
        if !raw_heat.is_finite() {
            return Err("raw trial heat total".into());
        }

        let mut prior_end = None;
        let mut child_width = None;
        let mut supports = Vec::with_capacity(chain.len());
        for credit_group in chain {
            let layers = credit_group.as_array().ok_or("credit group layers")?;
            let matching = unique
                .iter()
                .filter(|(_, primitive)| {
                    let receipt = &primitive["receipt"];
                    layers
                        .iter()
                        .filter(|layer| {
                            layer["accepted_operands"]
                                .as_array()
                                .is_some_and(|operands| {
                                    operands.iter().any(|operand| {
                                        operand["source_kind"] == "top_boundary"
                                            && operand["source_owner_id"] == "snow"
                                            && operand["debit_credit_identity_sha256"]
                                                == receipt["receipt_sha256"]
                                            && operand["ofe_id"] == receipt["ofe_id"]
                                            && operand["energy_j_m2_ofe_ground"]
                                                == receipt["soil_heat_j_m2"]
                                    })
                                })
                        })
                        .count()
                        == 1
                })
                .collect::<Vec<_>>();
            if matching.len() != 1 {
                return Err("raw receipt to one credit-layer correspondence".into());
            }
            let (receipt_id, primitive) = matching[0];
            let receipt = &primitive["receipt"];
            let beginning_owner: String =
                serde_json::from_value(primitive["beginning_soil_owner_id"].clone())
                    .map_err(|_| "raw candidate beginning owner")?;
            let beginning_state: openwepp_coupled_time::Digest32 =
                serde_json::from_value(primitive["beginning_soil_state_sha256"].clone())
                    .map_err(|_| "raw candidate beginning state")?;
            let physical_transaction: openwepp_kernel_contract::TransactionId =
                serde_json::from_value(primitive["transaction_id"].clone())
                    .map_err(|_| "raw candidate physical transaction")?;
            let ending_candidate: openwepp_land_surface_energy::SoilThermalLayerStateV2 =
                serde_json::from_value(primitive["ending_soil"]["v2"].clone())
                    .map_err(|_| "raw candidate ending state")?;
            let candidate_sha256 = digest_bytes(
                &serde_json::to_vec(&(
                    "OPENWEPP_TERMINAL_FIRST_SOIL_CANDIDATE_V2",
                    beginning_owner,
                    beginning_state,
                    physical_transaction,
                    &ending_candidate,
                ))
                .map_err(|_| "raw candidate-state serialization")?,
            );
            if ending_candidate.last_accepted_transaction_id != Some(physical_transaction)
                || serde_json::to_value(candidate_sha256).map_err(|_| "raw candidate-state JSON")?
                    != receipt["ending_soil_candidate_sha256"]
            {
                return Err("raw candidate-state hash".into());
            }
            if primitive["kind"] != "soil_trial_primitive"
                || primitive["disposition"] != "trial_only_select_by_committed_final_receipt"
                || receipt["lane_id"] != 1
                || receipt["ofe_id"] != "ofe-1"
                || receipt["snow_heat_j_m2"].as_f64()
                    != receipt["soil_heat_j_m2"].as_f64().map(|value| -value)
            {
                return Err("primitive receipt identity or heat custody".into());
            }
            let start = receipt["support"]["start_ns"]
                .as_str()
                .ok_or("primitive support start")?
                .parse::<u128>()
                .map_err(|_| "primitive support start integer")?;
            let end = receipt["support"]["end_ns"]
                .as_str()
                .ok_or("primitive support end")?
                .parse::<u128>()
                .map_err(|_| "primitive support end integer")?;
            let width = end.checked_sub(start).ok_or("primitive support ordering")?;
            if width < openwepp_land_surface_energy::MINIMUM_SUPPORT_NS
                || child_width.is_some_and(|prior| prior != width)
                || prior_end.is_some_and(|prior| prior != start)
            {
                return Err("primitive support contiguous minimum-width coverage".into());
            }
            child_width = Some(width);
            prior_end = Some(end);
            supports.push((start, end));
            let layer = layers
                .iter()
                .find(|layer| {
                    layer["accepted_operands"]
                        .as_array()
                        .is_some_and(|operands| {
                            operands.iter().any(|operand| {
                                operand["debit_credit_identity_sha256"] == receipt["receipt_sha256"]
                            })
                        })
                })
                .ok_or("raw receipt layer lookup")?;
            let beginning = &primitive["beginning_soil"]["v2"];
            let ending = &primitive["ending_soil"]["v2"];
            if layer["layer_id"] != beginning["layer_id"]
                || layer["layer_id"] != ending["layer_id"]
                || layer["beginning_enthalpy_hi_j_m2_ofe_ground"]
                    != beginning["enthalpy_hi_j_m2_ofe_ground"]
                || layer["beginning_enthalpy_carry"] != beginning["enthalpy_carry"]
                || layer["beginning_temperature_k"] != beginning["temperature_k"]
                || layer["ending_enthalpy_hi_j_m2_ofe_ground"]
                    != ending["enthalpy_hi_j_m2_ofe_ground"]
                || layer["ending_enthalpy_carry"] != ending["enthalpy_carry"]
                || layer["ending_temperature_k"] != ending["temperature_k"]
            {
                return Err("primitive exact carry/state correspondence".into());
            }
            let slab = slabs
                .get(receipt_id)
                .copied()
                .or_else(|| {
                    slab_records.iter().map(|v| &v["record"]).find(|slab| {
                        let slab_start = slab["support"]["start_ns"]
                            .as_str()
                            .and_then(|v| v.parse::<u128>().ok());
                        let slab_end = slab["support"]["end_ns"]
                            .as_str()
                            .and_then(|v| v.parse::<u128>().ok());
                        slab_start
                            .zip(slab_end)
                            .is_some_and(|(slab_start, slab_end)| {
                                start >= slab_start && end <= slab_end
                            })
                    })
                })
                .ok_or("raw receipt missing subslab support")?;
            let trial = &slab["adaptive_terminal_snow_soil_trial_receipts"]["1"];
            if !trial.is_null() && trial != receipt {
                return Err("raw receipt/subslab identity correspondence".into());
            }
        }
        if prior_end != Some(385_920_000_000_000) {
            return Err("primitive terminal support end".into());
        }
        let phase_joins = phase["ordered_owner_joins"]
            .as_array()
            .ok_or("phase ordered owner joins")?;
        if phase_joins.len() != slab_records.len() {
            return Err("phase/subslab cardinality".into());
        }
        let mut consumed_children = Vec::new();
        for (index, slab) in slab_records
            .iter()
            .map(|value| &value["record"])
            .enumerate()
        {
            let trial_value = &slab["adaptive_terminal_snow_soil_trial_receipts"]["1"];
            let support: openwepp_coupled_time::TimeSupport =
                serde_json::from_value(slab["support"].clone()).map_err(|_| "subslab support")?;
            let accepted = restored
                .clock
                .accepted_slab_receipts()
                .iter()
                .filter(|accepted| {
                    accepted.support() == support
                        && serde_json::to_value(accepted.slab_id().digest())
                            .ok()
                            .as_ref()
                            == Some(&slab["accepted_slab_sha256"])
                })
                .count();
            let phase_join = &phase_joins[index];
            let accepted_value = restored
                .clock
                .accepted_slab_receipts()
                .iter()
                .find(|accepted| {
                    accepted.support() == support
                        && serde_json::to_value(accepted.slab_id().digest())
                            .ok()
                            .as_ref()
                            == Some(&slab["accepted_slab_sha256"])
                })
                .map(serde_json::to_value)
                .transpose()
                .map_err(|_| "accepted slab JSON")?
                .ok_or("accepted subslab lookup")?;
            if accepted != 1
                || slab["owner_join"]["accepted_slab_sha256"] != slab["accepted_slab_sha256"]
                || slab["accepted_slab_sha256"] != phase_join["accepted_slab_sha256"]
                || slab["support"] != phase_join["support"]
                || slab["owner_join"] != phase_join["owner_join"]
                || slab["owner_join"]["parent_transaction_sha256"]
                    != phase_join["owner_join"]["parent_transaction_sha256"]
                || slab["parent_transaction_id"] != accepted_value["parent_transaction_id"]
                || slab["parent_transaction_id"]
                    != serde_json::to_value(restored.clock.parent_transaction_id().digest())
                        .map_err(|_| "clock parent transaction JSON")?
                || accepted_value["begin_owner_set"]
                    != slab["owner_join"]["beginning_complete_owner_set_sha256"]
                || accepted_value["end_owner_set"]
                    != slab["owner_join"]["ending_complete_owner_set_sha256"]
            {
                return Err("subslab phase/accepted clock owner join".into());
            }
            let mut owned_fields = Vec::new();
            if !trial_value.is_null() {
                let trial = terminal_trial_receipt_from_raw_v1(trial_value)?;
                trial.validate().map_err(|_| "raw trial receipt seal")?;
                let selected = supports
                    .iter()
                    .enumerate()
                    .filter(|(_, child)| {
                        **child == (support.start_ns().get(), support.end_ns().get())
                    })
                    .collect::<Vec<_>>();
                if selected.len() != 1 {
                    return Err("trial raw child support coverage".into());
                }
                consumed_children.push(selected[0].0);
                owned_fields.push((
                    "adaptive_terminal_snow_soil_trial_receipt",
                    trial.receipt_sha256,
                ));
            }
            if let Some(final_value) = slab["terminal_snow_soil_heat_receipts"]["1"].as_object() {
                let final_receipt =
                    terminal_receipt_from_raw_v1(&serde_json::Value::Object(final_value.clone()))?;
                final_receipt
                    .validate()
                    .map_err(|_| "raw terminal receipt seal")?;
                if final_receipt.snow_heat_j_m2.to_bits() != (-427.759_947_125_143_3_f64).to_bits()
                    || final_receipt.receipt_sha256
                        != serde_json::from_value(serde_json::json!(
                            "6e92cc24a0d1c96c4d83e287dcab3ee9bd45ad80700936e991b2855fc66f05b2"
                        ))
                        .map_err(|_| "raw terminal receipt pin")?
                {
                    return Err("raw terminal event receipt identity".into());
                }
                let selected = supports
                    .iter()
                    .enumerate()
                    .filter(|(_, (start, end))| {
                        *start >= support.start_ns().get() && *end <= support.end_ns().get()
                    })
                    .collect::<Vec<_>>();
                if selected.len() != 5
                    || selected
                        .first()
                        .is_none_or(|(_, (start, _))| *start != support.start_ns().get())
                    || selected
                        .last()
                        .is_none_or(|(_, (_, end))| *end != support.end_ns().get())
                {
                    return Err("terminal raw child support coverage".into());
                }
                let last_receipt = raw_by_support
                    .get(selected.last().expect("selected raw child").1)
                    .ok_or("terminal limiting raw receipt")?;
                if serde_json::to_value(final_receipt.limiting_boundary_receipt_sha256)
                    .map_err(|_| "terminal limiting receipt JSON")?
                    != serde_json::json!(last_receipt)
                {
                    return Err("terminal limiting raw receipt join".into());
                }
                let snow_heat: f64 = selected.iter().try_fold(0.0_f64, |sum, (_, support)| {
                    let receipt = raw_by_support
                        .get(support)
                        .ok_or("terminal raw child lookup")?;
                    let value = unique
                        .get(receipt)
                        .ok_or("terminal raw receipt lookup")?["receipt"]["snow_heat_j_m2"]
                        .as_f64()
                        .ok_or("terminal raw child heat")?;
                    Ok::<f64, String>(sum + value)
                })?;
                let event = phase["ordered_event_groups"]
                    .as_array()
                    .and_then(|groups| groups.first())
                    .ok_or("terminal event group")?;
                let candidate = event["candidates"]
                    .as_array()
                    .and_then(|candidates| candidates.first())
                    .ok_or("terminal event candidate")?;
                if restored.clock.accepted_event_receipts().len() != 1 {
                    return Err("terminal accepted event cardinality".into());
                }
                let clock_event =
                    serde_json::to_value(&restored.clock.accepted_event_receipts()[0])
                        .map_err(|_| "accepted event JSON")?;
                if final_receipt.support != support
                    || final_receipt.snow_heat_j_m2.to_bits() != snow_heat.to_bits()
                    || candidate["support"] != slab["support"]
                    || candidate["terminal_snow_soil_trial_receipt_sha256"]
                        != serde_json::to_value(final_receipt.limiting_boundary_receipt_sha256)
                            .map_err(|_| "terminal candidate receipt JSON")?
                    || candidate["terminal_state_sha256"]
                        != serde_json::to_value(final_receipt.ending_dormant_snow_owner_sha256)
                            .map_err(|_| "terminal candidate state JSON")?
                    || candidate["event"]["accepted_trials"] != 5
                    || candidate["event"]["snow_soil_heat_energy_j_m2"]
                        != serde_json::json!(snow_heat)
                    || event["accepted_event_receipt"]["begin_owner_set"]
                        != accepted_value["end_owner_set"]
                    || event["accepted_event_receipt"]["receipt_id"] != clock_event["receipt_id"]
                    || event["receipt_sha256"] != clock_event["event_context_digest"]
                {
                    return Err("terminal event/candidate raw correspondence".into());
                }
                consumed_children.extend(selected.into_iter().map(|(index, _)| index));
                owned_fields.push((
                    "terminal_snow_soil_heat_receipt",
                    final_receipt.receipt_sha256,
                ));
            }
            let fields = owned_fields
                .iter()
                .map(|(tag, digest)| openwepp_coupled_time::FramedField {
                    tag,
                    value: digest.as_bytes(),
                })
                .collect::<Vec<_>>();
            let set = openwepp_coupled_time::framed_sha256(
                "covered-terminal-snow-soil-heat-receipt-set-v1",
                &fields,
            )
            .map_err(|_| "terminal receipt framing")?;
            if serde_json::to_value(set).map_err(|_| "terminal receipt framing JSON")?
                != slab["owner_join"]["terminal_snow_soil_heat_receipt_set_sha256"]
            {
                return Err("subslab terminal receipt set join".into());
            }
        }
        if consumed_children != (0..12).collect::<Vec<_>>() {
            return Err("complete raw child/subslab coverage".into());
        }
        let candidate = &phase["deferred_native_v2_soil_custody"]["candidate"];
        if candidate["support_start_ns"].as_u64() != Some(385_860_000_000_000)
            || candidate["support_end_ns"].as_u64() != Some(385_920_000_000_000)
            || candidate["unpublished_predecessor_trial_sha256"] == serde_json::Value::Null
            || candidate["accepted_predecessor_receipt_chain_sha256"] != serde_json::Value::Null
        {
            return Err("captured final unpublished trial lineage".into());
        }
        let final_subslab = slab_records.last().ok_or("final raw subslab")?["record"].clone();
        let final_ending: openwepp_land_surface_energy::SoilThermalOwnedStateV2 =
            serde_json::from_value(final_subslab["ending_soil"]["v2"].clone())
                .map_err(|_| "final raw subslab ending soil")?;
        let candidate_ending: openwepp_land_surface_energy::SoilThermalOwnedStateV2 =
            serde_json::from_value(candidate["ending_state"].clone())
                .map_err(|_| "authenticated phase candidate ending state")?;
        let final_terminal =
            terminal_receipt_from_raw_v1(&final_subslab["terminal_snow_soil_heat_receipts"]["1"])?;
        if final_ending != candidate_ending {
            return Err("final raw subslab ending soil".into());
        }
        let final_ofe = final_ending
            .ofes
            .iter()
            .filter(|ofe| ofe.ofe_id.as_str() == final_terminal.ofe_id.as_str())
            .collect::<Vec<_>>();
        let [final_ofe] = final_ofe.as_slice() else {
            return Err("final ending OFE selection".into());
        };
        let final_ending_sha256 = digest_bytes(
            &serde_json::to_vec(final_ofe).map_err(|_| "final ending OFE serialization")?,
        );
        if final_terminal.ending_soil_owner_sha256 != final_ending_sha256 {
            return Err("final ending OFE hash".into());
        }
        let original: openwepp_land_surface_energy::SoilThermalOwnerEnvelopeV2 =
            serde_json::from_value(continuation["original_beginning_owner"].clone())
                .map_err(|_| "deferred original owner")?;
        let typed_chain: Vec<Vec<openwepp_land_surface_energy::SoilThermalLayerEnergyCreditV2>> =
            serde_json::from_value(continuation["ordered_layer_credit_chain"].clone())
                .map_err(|_| "deferred typed credit chain")?;
        let seals = member_restoration::replay_deferred_unpublished_trial_seals_v1(
            &original,
            &typed_chain,
            &supports,
        )?;
        if seals.len() != 12
            || serde_json::to_value(seals.last().ok_or("deferred final seal")?)
                .map_err(|_| "deferred final seal JSON")?
                != candidate["unpublished_trial_sha256"]
            || serde_json::to_value(
                seals
                    .get(seals.len() - 2)
                    .ok_or("deferred penultimate seal")?,
            )
            .map_err(|_| "deferred penultimate seal JSON")?
                != candidate["unpublished_predecessor_trial_sha256"]
        {
            return Err("deferred reconstructed unpublished seal chain".into());
        }
        let day = decode_member_backed_row_v1(
            export,
            &export.join("rows/108033.events.jsonl"),
            &BTreeSet::new(),
        )?;
        let base: u128 = serde_json::from_value(day["committed_next_parent_sequence"].clone())
            .map_err(|_| "committed parent sequence")?;
        let interval: u128 =
            serde_json::from_value(restored.recorded_row["interval_index"].clone())
                .map_err(|_| "captured interval index")?;
        member_restoration::validate_current_phase(
            &restored.recorded_row,
            &restored.clock,
            base.checked_add(interval)
                .ok_or("current phase position overflow")?,
        )?;
        Ok(())
    }

    fn terminal_trial_receipt_from_raw_v1(
        value: &serde_json::Value,
    ) -> Result<crate::v9_real_consumer_shadow::TerminalSnowSoilTrialReceiptV1, String> {
        if !value["experimental_bulk"].is_null() {
            return Err("raw trial experimental bulk".into());
        }
        Ok(
            crate::v9_real_consumer_shadow::TerminalSnowSoilTrialReceiptV1 {
                experimental_bulk: None,
                support: serde_json::from_value(value["support"].clone())
                    .map_err(|_| "raw trial support")?,
                lane_id: serde_json::from_value(value["lane_id"].clone())
                    .map_err(|_| "raw trial lane")?,
                ofe_id: serde_json::from_value(value["ofe_id"].clone())
                    .map_err(|_| "raw trial ofe")?,
                canonical_source_sha256: serde_json::from_value(
                    value["canonical_source_sha256"].clone(),
                )
                .map_err(|_| "raw trial source")?,
                beginning_snow_temperature_k: value["beginning_snow_temperature_k"]
                    .as_f64()
                    .ok_or("raw trial beginning snow")?,
                ending_snow_temperature_k: value["ending_snow_temperature_k"]
                    .as_f64()
                    .ok_or("raw trial ending snow")?,
                beginning_soil_temperature_k: value["beginning_soil_temperature_k"]
                    .as_f64()
                    .ok_or("raw trial beginning soil")?,
                ending_soil_temperature_k: value["ending_soil_temperature_k"]
                    .as_f64()
                    .ok_or("raw trial ending soil")?,
                snow_heat_j_m2: value["snow_heat_j_m2"]
                    .as_f64()
                    .ok_or("raw trial snow heat")?,
                soil_heat_j_m2: value["soil_heat_j_m2"]
                    .as_f64()
                    .ok_or("raw trial soil heat")?,
                ending_soil_candidate_sha256: serde_json::from_value(
                    value["ending_soil_candidate_sha256"].clone(),
                )
                .map_err(|_| "raw trial ending candidate")?,
                receipt_sha256: serde_json::from_value(value["receipt_sha256"].clone())
                    .map_err(|_| "raw trial receipt")?,
            },
        )
    }

    fn terminal_receipt_from_raw_v1(
        value: &serde_json::Value,
    ) -> Result<crate::v9_real_consumer_shadow::TerminalSnowSoilHeatReceiptV1, String> {
        Ok(
            crate::v9_real_consumer_shadow::TerminalSnowSoilHeatReceiptV1 {
                support: serde_json::from_value(value["support"].clone())
                    .map_err(|_| "raw terminal support")?,
                lane_id: serde_json::from_value(value["lane_id"].clone())
                    .map_err(|_| "raw terminal lane")?,
                ofe_id: serde_json::from_value(value["ofe_id"].clone())
                    .map_err(|_| "raw terminal ofe")?,
                beginning_snow_owner_sha256: serde_json::from_value(
                    value["beginning_snow_owner_sha256"].clone(),
                )
                .map_err(|_| "raw terminal beginning")?,
                ending_dormant_snow_owner_sha256: serde_json::from_value(
                    value["ending_dormant_snow_owner_sha256"].clone(),
                )
                .map_err(|_| "raw terminal dormant")?,
                ending_soil_owner_sha256: serde_json::from_value(
                    value["ending_soil_owner_sha256"].clone(),
                )
                .map_err(|_| "raw terminal soil")?,
                limiting_boundary_receipt_sha256: serde_json::from_value(
                    value["limiting_boundary_receipt_sha256"].clone(),
                )
                .map_err(|_| "raw terminal boundary")?,
                snow_heat_j_m2: value["snow_heat_j_m2"]
                    .as_f64()
                    .ok_or("raw terminal snow heat")?,
                soil_heat_j_m2: value["soil_heat_j_m2"]
                    .as_f64()
                    .ok_or("raw terminal soil heat")?,
                receipt_sha256: serde_json::from_value(value["receipt_sha256"].clone())
                    .map_err(|_| "raw terminal receipt")?,
            },
        )
    }

    #[test]
    #[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
    fn deferred_context_raw_primitives_authenticate_credit_correspondence_before_admission() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let primitives = std::env::var_os("OPENWEPP_B01_RETAINED_SOIL_TRIAL_PRIMITIVES")
            .expect("bound retained soil primitive artifact");
        let subslabs = std::env::var_os("OPENWEPP_B01_RETAINED_SUBSLAB_PRIMITIVES")
            .expect("bound retained subslab primitive artifact");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let primitives: serde_json::Value = serde_json::from_slice(
            &std::fs::read(primitives).expect("retained primitive artifact bytes"),
        )
        .expect("retained primitive artifact JSON");
        let subslabs: serde_json::Value = serde_json::from_slice(
            &std::fs::read(subslabs).expect("retained subslab primitive artifact bytes"),
        )
        .expect("retained subslab primitive artifact JSON");
        assert_eq!(
            primitives["source_sha256"],
            "1555efe1b592081a3dd67639d71a18e4e67f518e24b93a95ddfe18de2023d87c",
            "raw primitive source pin"
        );
        validate_b01_retained_soil_trial_correspondence_v1(
            std::path::Path::new(&export),
            &primitives,
            &subslabs,
        )
        .expect("complete raw receipt/credit/carry correspondence");
    }

    #[test]
    #[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
    fn deferred_context_raw_correspondence_refuses_semantic_poison() {
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let primitives: serde_json::Value = serde_json::from_slice(
            &std::fs::read(
                std::env::var_os("OPENWEPP_B01_RETAINED_SOIL_TRIAL_PRIMITIVES")
                    .expect("raw primitives"),
            )
            .expect("raw primitive bytes"),
        )
        .expect("raw primitive JSON");
        let subslabs: serde_json::Value = serde_json::from_slice(
            &std::fs::read(
                std::env::var_os("OPENWEPP_B01_RETAINED_SUBSLAB_PRIMITIVES").expect("raw subslabs"),
            )
            .expect("raw subslab bytes"),
        )
        .expect("raw subslab JSON");
        let export = std::path::Path::new(&export);
        let mut missing = primitives.clone();
        missing["records"].as_array_mut().expect("records").pop();
        assert_eq!(
            validate_b01_retained_soil_trial_correspondence_v1(export, &missing, &subslabs)
                .as_ref()
                .map_err(String::as_str),
            Err("retained primitive/credit group cardinality")
        );
        let mut foreign = primitives.clone();
        for record in foreign["records"].as_array_mut().expect("records") {
            record["record"]["receipt"]["canonical_source_sha256"] =
                serde_json::json!("00".repeat(32));
        }
        assert_eq!(
            validate_b01_retained_soil_trial_correspondence_v1(export, &foreign, &subslabs)
                .as_ref()
                .map_err(String::as_str),
            Err("raw trial receipt seal")
        );
        let mut support = primitives.clone();
        for record in support["records"]
            .as_array_mut()
            .expect("records")
            .iter_mut()
            .take(2)
        {
            record["record"]["receipt"]["support"]["end_ns"] = serde_json::json!("385260000000001");
        }
        assert_eq!(
            validate_b01_retained_soil_trial_correspondence_v1(export, &support, &subslabs)
                .as_ref()
                .map_err(String::as_str),
            Err("raw trial receipt seal")
        );
        let mut carry = primitives.clone();
        for record in carry["records"]
            .as_array_mut()
            .expect("records")
            .iter_mut()
            .take(2)
        {
            record["record"]["ending_soil"]["v2"]["enthalpy_carry"]["coefficient_hex"] =
                serde_json::json!("1");
        }
        assert_eq!(
            validate_b01_retained_soil_trial_correspondence_v1(export, &carry, &subslabs)
                .as_ref()
                .map_err(String::as_str),
            Err("raw candidate-state hash")
        );
        let mut candidate_transaction = primitives.clone();
        for record in candidate_transaction["records"]
            .as_array_mut()
            .expect("records")
            .iter_mut()
            .take(2)
        {
            record["record"]["transaction_id"] = serde_json::json!(256);
        }
        assert_eq!(
            validate_b01_retained_soil_trial_correspondence_v1(
                export,
                &candidate_transaction,
                &subslabs,
            )
            .as_ref()
            .map_err(String::as_str),
            Err("raw candidate-state hash")
        );
        let mut event = subslabs.clone();
        event["records"]
            .as_array_mut()
            .expect("subslabs")
            .last_mut()
            .expect("final subslab")["record"]["terminal_snow_soil_heat_receipts"]["1"]["receipt_sha256"] =
            serde_json::json!("00".repeat(32));
        assert_eq!(
            validate_b01_retained_soil_trial_correspondence_v1(export, &primitives, &event)
                .as_ref()
                .map_err(String::as_str),
            Err("raw terminal receipt seal")
        );
        let mut final_ending = subslabs.clone();
        final_ending["records"]
            .as_array_mut()
            .expect("subslabs")
            .last_mut()
            .expect("final subslab")["record"]["ending_soil"]["v2"]["ofes"][0]["ordered_layers"]
            [0]["temperature_k"] = serde_json::json!(271.0);
        assert_eq!(
            validate_b01_retained_soil_trial_correspondence_v1(export, &primitives, &final_ending)
                .as_ref()
                .map_err(String::as_str),
            Err("final raw subslab ending soil")
        );
        let mut reordered = primitives.clone();
        reordered["records"]
            .as_array_mut()
            .expect("records")
            .reverse();
        validate_b01_retained_soil_trial_correspondence_v1(export, &reordered, &subslabs)
            .expect("raw record order is not correspondence authority");
    }

    /// Private diagnostic composition after the retained contract-derived RED.
    /// Authenticates original operands and checks complete restoration bytes.
    /// A pass is neither canonical promotion nor physical/restart qualification.
    #[test]
    #[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
    fn deferred_context_complete_bundle_private_diagnostic_restoration() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let seed = std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("bound pinned seed");
        let primitives = std::env::var_os("OPENWEPP_B01_RETAINED_SOIL_TRIAL_PRIMITIVES")
            .expect("bound retained soil primitive artifact");
        let subslabs = std::env::var_os("OPENWEPP_B01_RETAINED_SUBSLAB_PRIMITIVES")
            .expect("bound retained subslab primitive artifact");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let primitives: serde_json::Value = serde_json::from_slice(
            &std::fs::read(primitives).expect("retained primitive artifact bytes"),
        )
        .expect("retained primitive artifact JSON");
        let subslabs: serde_json::Value = serde_json::from_slice(
            &std::fs::read(subslabs).expect("retained subslab primitive artifact bytes"),
        )
        .expect("retained subslab primitive artifact JSON");
        validate_b01_retained_soil_trial_correspondence_v1(
            std::path::Path::new(&export),
            &primitives,
            &subslabs,
        )
        .expect("complete component bundle before private diagnostic");
        member_restoration::restore(std::path::Path::new(&export), std::path::Path::new(&seed))
            .expect("private deferred composite admission after complete component bundle");
    }

    #[test]
    fn member_constructor_inverse_roundtrips_actual_operands() {
        let path = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("policy");
        let restored =
            restore_snow_free_clock_parent_from_member_export(std::path::Path::new(&path))
                .expect("member clock and parent");
        let raw = &restored.recorded_row["native_hydrology_constructor_inputs"];
        let typed = constructor_inverse::restore(raw).expect("field-complete constructor inverse");
        assert_eq!(capture_direct_run_constructor_inputs(&typed), *raw);
        let seed = std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("seed");
        let seed: serde_json::Value =
            serde_json::from_slice(&std::fs::read(seed).expect("seed bytes")).expect("seed JSON");
        member_restoration::pin_hydrology(&seed, &typed)
            .expect("independent immutable hydrology authority");
        for (pointer, expected) in [
            (
                "/checkpoint/phase/committed/scientific/direct_hydrology/phase_plan_sha256",
                "seed phase plan digest",
            ),
            (
                "/checkpoint/phase/committed/scientific/direct_hydrology/lanes/0/day_inputs_sha256",
                "seed lane immutable day inputs digest",
            ),
        ] {
            let mut substituted_seed = seed.clone();
            *substituted_seed
                .pointer_mut(pointer)
                .expect("pinned digest field") =
                serde_json::json!(digest_bytes(b"foreign-immutable-operand"));
            assert_eq!(
                member_restoration::pin_hydrology(&substituted_seed, &typed)
                    .as_ref()
                    .map_err(String::as_str),
                Err(expected)
            );
        }
        let mut poisoned = typed.clone();
        poisoned.lanes[0].area_m2 += 1.0;
        assert_eq!(
            member_restoration::pin_hydrology(&seed, &poisoned)
                .as_ref()
                .map_err(String::as_str),
            Err("seed immutable lane area_m2")
        );
        member_restoration::restore_pinned_surface(&seed, &restored.recorded_row, &restored.clock)
            .expect("seed surface and prefix configuration join");
        let mut wrong_surface = restored.recorded_row.clone();
        wrong_surface["phase_diagnostics"]["prefix_validation_surface_configuration_canonical_json"] =
            serde_json::json!([]);
        assert_eq!(
            member_restoration::restore_pinned_surface(&seed, &wrong_surface, &restored.clock)
                .err()
                .as_deref(),
            Some("prefix surface configuration authority join")
        );

        println!(
            "constructor inverse: {} lanes; exact capture roundtrip",
            typed.lanes.len()
        );
    }

    #[test]
    fn snow_free_member_export_restores_clock_and_parent_without_native_decode() {
        let path = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT")
            .expect("bound member export; run through the event-restoration recorder");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("pinned B01 policy context");
        let restored =
            restore_snow_free_clock_parent_from_member_export(std::path::Path::new(&path))
                .expect("exact member-backed snow-free clock and parent restoration");
        assert_eq!(restored.clock.accepted_until().get(), B01_CHILD_START_NS);
        assert_eq!(restored.clock.accepted_slab_receipts().len(), 8);
        assert_eq!(restored.clock.accepted_event_receipts().len(), 1);
        assert_eq!(
            restored.parent.parent_transaction_id(),
            restored.clock.parent_transaction_id()
        );
        let surface_bytes: Vec<u8> = serde_json::from_value(
            restored.recorded_row["surface_liquid_configuration_canonical_json"].clone(),
        )
        .expect("captured surface configuration bytes");
        let surface =
            crate::direct_runtime::DirectSurfaceLiquidConfiguration::from_canonical_bytes(
                &surface_bytes,
            )
            .expect("captured surface configuration");
        diagnose_snow_free_prefix_receipt_gates_v1(&restored.recorded_row, &surface)
            .expect("native prefix receipt-gate localization");
        validate_snow_free_prefix_membership_v1(&restored.recorded_row, &restored.clock, &surface)
            .expect("clock-bound native inactive-prefix validation");
    }

    #[test]
    fn snow_free_member_export_reconstructs_provisional_on_clone_from_pinned_seed() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT")
            .expect("bound member export; run through the event-restoration recorder");
        let seed = std::env::var_os("OPENWEPP_B01_PINNED_SEED")
            .expect("bound pinned seed; run through the event-restoration recorder");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("pinned B01 policy context");
        let restored =
            restore_snow_free_clock_parent_from_member_export(std::path::Path::new(&export))
                .expect("member-backed clock and parent restoration");
        let seed = extract_pinned_seed_configuration_v1(std::path::Path::new(&seed))
            .expect("pinned seed configuration and identities");
        let calendar = seed.calendar;
        let policy = seed.controller_policy;
        let row = &restored.recorded_row;
        let constructor = &row["provisional_constructor_inputs"];
        assert_eq!(row["capture_phase"], "snow_free");
        assert_eq!(
            constructor["constraint_source_owner_id"],
            "v11-real-consumer"
        );
        assert_eq!(constructor["calendar_receipt"], serde_json::json!(calendar));
        assert_eq!(constructor["controller_policy"], serde_json::json!(policy));
        let support: TimeSupport =
            serde_json::from_value(row["support"].clone()).expect("captured support");
        let forcing = serde_json::from_value(constructor["forcing_receipt"].clone())
            .expect("captured forcing receipt");
        let before =
            capture_coupled_clock_restart(&restored.clock).expect("clock bytes before clone");
        let (clone, reduction, ledger, receipt) =
            reconstruct_provisional_on_clone_with_authorities(
                &restored.clock,
                support,
                calendar,
                policy,
                forcing,
                "v11-real-consumer",
            )
            .expect("phase-correct provisional clone");
        assert_eq!(
            capture_coupled_clock_restart(&restored.clock).expect("clock bytes after clone"),
            before
        );
        assert!(clone.accepted_until() > restored.clock.accepted_until());
        let expected_reduction: Vec<u8> =
            serde_json::from_value(row["constraint_reduction_canonical_json"].clone())
                .expect("recorded reduction bytes");
        let expected_ledger: Vec<u8> =
            serde_json::from_value(row["complete_owner_ledger_canonical_json"].clone())
                .expect("recorded ledger bytes");
        let expected_receipt: Vec<u8> =
            serde_json::from_value(row["provisional_receipt_canonical_json"].clone())
                .expect("recorded provisional receipt bytes");
        assert_eq!(
            serde_json::to_vec(&reduction).expect("reduction bytes"),
            expected_reduction
        );
        assert_eq!(
            serde_json::to_vec(&ledger).expect("ledger bytes"),
            expected_ledger
        );
        assert_eq!(
            serde_json::to_vec(&receipt).expect("receipt bytes"),
            expected_receipt
        );
    }

    #[test]
    fn archive_records_authenticate_sequentially_from_pinned_seed() {
        let export = std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT")
            .expect("bound member export; run through the event-restoration recorder");
        let seed_path = std::env::var_os("OPENWEPP_B01_PINNED_SEED")
            .expect("bound pinned seed; run through the event-restoration recorder");
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("pinned B01 policy context");
        let export = std::path::PathBuf::from(export);
        let target =
            restore_snow_free_clock_parent_from_member_export(&export).expect("target row");
        let vegetation_bytes: Vec<u8> = serde_json::from_value(
            target.recorded_row["vegetation_configuration_canonical_json"].clone(),
        )
        .expect("V11 configuration bytes");
        let vegetation: openwepp_vegetation::VegetationConfigurationV11 =
            serde_json::from_slice(&vegetation_bytes).expect("V11 configuration");
        let seed = extract_pinned_seed_configuration_v1(std::path::Path::new(&seed_path))
            .expect("pinned seed configuration and identities");
        assert_eq!(vegetation.imported_v10, seed.vegetation);
        let lse = seed.lse;
        let run = seed.run_identity;
        let topology = seed.topology_identity;
        let summary: serde_json::Value = serde_json::from_slice(
            &std::fs::read(export.join("summary.json")).expect("summary read"),
        )
        .expect("summary JSON");
        let archive_ordinals = [27_431_u64, 54_078, 79_222, 107_936];
        let selected = summary["rows"]
            .as_array()
            .expect("summary rows")
            .iter()
            .filter_map(|row| row["ordinal"].as_u64())
            .filter(|ordinal| archive_ordinals.contains(ordinal))
            .collect::<Vec<_>>();
        assert_eq!(selected.len(), B01_DAY_INDEX);
        let mut days = Vec::new();
        for ordinal in selected {
            let path = export.join("rows").join(format!("{ordinal}.events.jsonl"));
            let row =
                decode_member_backed_row_v1(&export, &path, &BTreeSet::new()).expect("member row");
            if row["kind"] != "b01_wb14_committed_day_archive_record_v1" {
                continue;
            }
            let entry: crate::Stage3CommittedDayArchiveEntryV1 =
                serde_json::from_value(row["archive_entry"].clone()).expect("archive entry");
            assert_eq!(row["capture"]["ordinal"].as_u64(), Some(ordinal));
            let bytes = std::fs::read(
                export
                    .join("rows")
                    .join(format!("{ordinal}.canonical_record.bin")),
            )
            .expect("raw archive member");
            assert_eq!(
                u64::try_from(bytes.len()).ok(),
                Some(entry.canonical_uncompressed_len)
            );
            assert_eq!(digest_bytes(&bytes), entry.content_sha256);
            let day = row["day_index"].as_u64().expect("day index");
            let result = authenticate_archived_day_with_configuration_v1(
                entry,
                &bytes,
                run,
                topology,
                &vegetation,
                &lse,
            );
            println!(
                "archive-day-{day}: {}",
                if result.is_ok() { "PASS" } else { "REFUSAL" }
            );
            days.push((day, result.err()));
        }
        days.sort_by_key(|(day, _)| *day);
        assert_eq!(days.len(), B01_DAY_INDEX);
        assert!(
            days.iter().all(|(_, error)| error.is_none()),
            "archive canonical refusals: {days:?}"
        );
    }

    #[test]
    fn prepared_day_member_restores_provider_and_forcing_component() {
        let export = std::path::PathBuf::from(
            std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export"),
        );
        let _native_audit =
            crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
        let _probe_audit = ProbeAudit::begin();
        openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
            .install()
            .expect("pinned B01 policy context");
        let day = decode_member_backed_row_v1(
            &export,
            &export.join("rows/108033.events.jsonl"),
            &BTreeSet::new(),
        )
        .expect("bound prepared day member");
        assert_eq!(day["kind"], "b01_wb14_prepared_day_current_context_v1");
        assert_eq!(day["day_index"], B01_DAY_INDEX);
        let seed: serde_json::Value = serde_json::from_slice(
            &std::fs::read(std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("pinned seed path"))
                .expect("pinned seed read"),
        )
        .expect("pinned seed JSON");
        assert_eq!(
            day["static_run_identity"],
            seed["checkpoint"]["run_identity_sha256"]
        );
        assert_eq!(
            day["static_topology_identity"],
            seed["checkpoint"]["topology_sha256"]
        );
        let capture: ProviderCaptureV1 =
            serde_json::from_value(day["provider_constructor_operands"].clone())
                .expect("provider operands");
        // The configuration is bound to this immutable member, not independent
        // seed configuration authority. This test qualifies only the component.
        let c = &capture.static_configuration;
        let configuration = crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration {
            run_id: c.run_id.clone(),
            co2_pa: c.co2_pa,
            reference_height_m: c.reference_height_m,
            gsi_owner_configuration_sha256: c.gsi_owner_configuration_sha256.clone(),
            destinations: c
                .destinations
                .iter()
                .map(|d| crate::runtime_inputs::SnowFreeHalfHourDestination {
                    ofe_id: d.ofe_id.clone(),
                    tile_id: d.tile_id.clone(),
                    wb14_configuration_sha256: d.wb14_configuration_sha256.clone(),
                })
                .collect(),
        };
        configuration
            .validate()
            .expect("provider configuration validation");
        let provider =
            restore_provider_day(capture, &configuration).expect("native provider restore");
        let captures: Vec<PreparedSupportCaptureV1> =
            serde_json::from_value(day["ordered_support_constructor_operands"].clone())
                .expect("ordered support operands");
        assert_eq!(captures.len(), 48);
        let supports = captures
            .into_iter()
            .map(|c| restore_prepared_support(c, &provider))
            .collect::<Result<Vec<_>, _>>()
            .expect("native support restore");
        let prepared = crate::PreparedStage3V11DayV1::bind_production_provider_day(
            &provider,
            B01_DAY_INDEX,
            supports,
        )
        .expect("native complete prepared day binding");
        let restored =
            restore_snow_free_clock_parent_from_member_export(&export).expect("target member");
        let row = &restored.recorded_row;
        assert_eq!(row["static_run_identity"], day["static_run_identity"]);
        assert_eq!(
            row["static_topology_identity"],
            day["static_topology_identity"]
        );
        let parent = &prepared.supports()[B01_INTERVAL_INDEX];
        assert_eq!(serde_json::json!(parent.support()), row["parent_support"]);
        let forcing = crate::snow_stage3_v11_attachment::canonical_parent_forcing_digest(
            B01_DAY_INDEX,
            B01_INTERVAL_INDEX,
            provider.gsi_receipt_digest().expect("GSI receipt digest"),
            parent,
        )
        .expect("native parent forcing identity");
        assert_eq!(
            serde_json::json!(forcing),
            row["provisional_constructor_inputs"]["forcing_receipt"]
        );
        println!(
            "provider component: 48 supports, day 4 interval 22 parent and captured forcing match"
        );
    }
}
