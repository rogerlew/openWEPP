//! Private, fixed-sequence source adapter for the two COLD-CANOPY-M1 cycles.
//!
//! This module deliberately owns only custody, canonical decoding, schedule
//! expansion and receipt identities.  It is not a weather provider and never
//! supplies endpoint weather in place of retained frozen forcing.

use super::m1_receiver::{
    M1AcceptedSupportEvidence, M1ReceiverContribution, M1ReceiverDiagnosticError,
};
use openwepp_coupled_time::{
    AcceptedSlabReceiptV1, ConstraintClass, CoupledClockStateV1, CoupledSlabCandidateV1, Digest32,
    LedgerEntryV1, ModelTimeNs, OwnerState, ParentAuthorityV1, StepConstraintV1, TimeSupport,
    accept_slab, complete_owner_set_digest, reduce_constraints,
};
use openwepp_land_surface_energy::{
    M1CoupledColumnInput, M1PhaseReservoirInput, solve_m1_coupled_column,
};
use serde_json::Value;
use sha2::{Digest, Sha256};
#[cfg(test)]
use std::cell::{Cell, RefCell};

#[cfg(test)]
thread_local! {
    static M1_RAW_WATER_ORACLE: RefCell<Vec<M1RawWaterOracle>> = const { RefCell::new(Vec::new()) };
    static M1_LSE_DIAGNOSTIC_ORDINAL: Cell<Option<u32>> = const { Cell::new(None) };
    static M1_LSE_DIAGNOSTIC_RECORD: RefCell<Option<serde_json::Value>> = const { RefCell::new(None) };
}

#[cfg(test)]
pub(super) fn arm_m1_lse_diagnostic_for_ordinal(ordinal: u32) {
    M1_LSE_DIAGNOSTIC_ORDINAL.with(|armed| armed.set(Some(ordinal)));
    M1_LSE_DIAGNOSTIC_RECORD.with(|record| *record.borrow_mut() = None);
}

#[cfg(test)]
pub(super) fn take_m1_lse_diagnostic_record() -> Option<serde_json::Value> {
    M1_LSE_DIAGNOSTIC_RECORD.with(|record| record.borrow_mut().take())
}

#[cfg(test)]
#[derive(Clone, Debug)]
pub(super) struct M1RawWaterOracle {
    pub(super) key: openwepp_vegetation::v11::V11SharedResourceKey,
    pub(super) lane_index: usize,
    pub(super) lane_id: u32,
    pub(super) layer_index: usize,
    pub(super) beginning_layer_ids: Vec<String>,
    pub(super) receiver_layer_ids: Vec<String>,
    pub(super) beginning_lane: Vec<crate::DirectSubsurfaceLayerState>,
    pub(super) receiver_beginning_lane_depth_bits: Vec<u64>,
    pub(super) ending_lane_depth_bits: Vec<u64>,
    pub(super) beginning_supply_kg_m2_bits: u64,
    pub(super) native_uses:
        std::collections::BTreeMap<openwepp_land_surface_energy::GroundWaterKey, f64>,
    pub(super) ordered_ingress: Vec<crate::DirectSurfaceLiquidParcelReceipt>,
    pub(super) tillage_depth_m_bits: u64,
    pub(super) infiltration_m_bits: u64,
    pub(super) receiver_beginning_depth_bits: u64,
    pub(super) ending_depth_bits: u64,
}

#[cfg(test)]
pub(super) fn take_m1_raw_water_oracle() -> Vec<M1RawWaterOracle> {
    M1_RAW_WATER_ORACLE.with(|values| std::mem::take(&mut *values.borrow_mut()))
}

const ORIGINAL: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/original-input-reference.json"
));
const CONTINUOUS: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/continuous-fixtures-draft01.json"
));
const MANIFEST: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/m1-fixed-sequence-adapter-dependencies-v1.json"
));
const ORIGINAL_PATH: &str =
    "docs/work-packages/20260920-cold-canopy-m1-001/artifacts/original-input-reference.json";
const CONTINUOUS_PATH: &str =
    "docs/work-packages/20260920-cold-canopy-m1-001/artifacts/continuous-fixtures-draft01.json";
const ENDPOINT_PATH: &str = "crates/openwepp-hillslope-orchestrator/src/land_surface_energy_shadow/strict_v8_endpoint_tests.rs";
const CONTROLLER_PATH: &str = "crates/openwepp-land-surface-energy/src/numerics.rs";
const PROVIDER_PATH: &str = "crates/openwepp-hillslope-orchestrator/src/land_surface_energy_shadow/m1_fixed_sequence_provider.rs";
const MANIFEST_PATH: &str = "docs/work-packages/20260920-cold-canopy-m1-001/artifacts/m1-fixed-sequence-adapter-dependencies-v1.json";
const PROVIDER_ID: &str = "OPENWEPP_COLD_M1_FIXED_SEQUENCE_PROVIDER_V1";

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) struct ProviderError;
impl ProviderError {
    pub(super) fn code(&self) -> &'static str {
        "VEG-E-144"
    }
}

#[cfg(test)]
mod native_water_custody_tests {
    use super::{
        canonical_native_root_ending_depth, native_water_custody_bits_match, retain_native_root_use,
    };
    use std::collections::BTreeMap;

    #[test]
    fn run05_native_root_depth_reconstruction_retains_the_real_ending_bit() {
        let uses = BTreeMap::from([
            (0_u8, f64::from_bits(4_488_721_396_023_810_867)),
            (1_u8, f64::from_bits(4_488_787_752_102_678_548)),
        ]);
        let mut layer = crate::DirectSubsurfaceLayerState::neutral();
        layer.theta_m = 0.02;
        let (debit, ending) = canonical_native_root_ending_depth(&layer, 20.0, &uses)
            .expect("run05 native root reconstruction");
        assert_eq!(debit.to_bits(), 4_493_258_173_690_615_204);
        assert_eq!(ending.to_bits(), 4_581_421_828_924_140_681);
        // The former kg-space subtraction lands one ULP below this native
        // theta update and must remain a rejection, not a tolerance case.
        assert_ne!(ending.to_bits(), 4_581_421_828_924_140_680,);
    }

    #[test]
    fn native_root_depth_reconstruction_uses_the_whole_layer_branch() {
        let uses = BTreeMap::from([(0_u8, 20.0)]);
        let mut layer = crate::DirectSubsurfaceLayerState::neutral();
        layer.theta_m = 0.02;
        let (debit, ending) = canonical_native_root_ending_depth(&layer, 20.0, &uses)
            .expect("whole layer native root reconstruction");
        assert_eq!(debit.to_bits(), 20.0_f64.to_bits());
        assert_eq!(ending.to_bits(), 0.0_f64.to_bits());
    }

    #[test]
    fn native_root_use_order_bijection_rejects_a_duplicate_source_key() {
        let mut uses = BTreeMap::new();
        retain_native_root_use(&mut uses, 7_u8, 1.0).expect("first source use");
        assert!(retain_native_root_use(&mut uses, 7_u8, 1.0).is_err());
    }

    #[test]
    fn native_root_depth_reconstruction_rejects_aggregate_over_supply() {
        let mut layer = crate::DirectSubsurfaceLayerState::neutral();
        layer.theta_m = 0.02;
        let uses = BTreeMap::from([(0_u8, 20.000_000_000_000_004)]);
        assert!(canonical_native_root_ending_depth(&layer, 20.0, &uses).is_err());
    }

    #[test]
    fn run05_wrong_ending_one_ulp_is_rejected_by_the_custody_predicate() {
        let beginning_kg_m2 = 20.0;
        let native_ending_kg_m2 = f64::from_bits(4_626_322_717_209_196_030);
        let post_root_depth_m = f64::from_bits(4_581_421_828_924_140_681);
        assert!(native_water_custody_bits_match(
            post_root_depth_m,
            post_root_depth_m,
            native_ending_kg_m2 / 1_000.0,
            post_root_depth_m,
            beginning_kg_m2,
            beginning_kg_m2,
            native_ending_kg_m2,
            native_ending_kg_m2,
            true,
        ));
        let poisoned_ending_kg_m2 = f64::from_bits(4_626_322_717_209_196_029);
        assert!(!native_water_custody_bits_match(
            post_root_depth_m,
            post_root_depth_m,
            poisoned_ending_kg_m2 / 1_000.0,
            post_root_depth_m,
            beginning_kg_m2,
            beginning_kg_m2,
            poisoned_ending_kg_m2,
            native_ending_kg_m2,
            true,
        ));
    }
}

#[derive(Debug)]
pub(super) enum M1ParentExecutionError {
    Provider(ProviderError),
    /// An error returned by a canonical V11 constructor or validator.
    Resource(openwepp_vegetation::v11::V11Error),
    /// Private M1 adapter failure before canonical V11 validation.  The
    /// retained stage and V11 class distinguish local construction guards
    /// from the final canonical custody verdict without changing any wire.
    ResourceConstruction {
        stage: &'static str,
        source: openwepp_vegetation::v11::V11Error,
    },
    /// Exact, private operands retained when the M1 water endpoint identity
    /// does not close.  Bits preserve the native arithmetic order for the
    /// next diagnostic without adding a persisted receipt field.
    WaterClosure {
        source: openwepp_vegetation::v11::V11Error,
        ofe_id: String,
        layer_id: String,
        beginning_amount_bits: u64,
        ending_amount_bits: u64,
        beginning_liquid_depth_bits: u64,
        post_root_liquid_depth_bits: u64,
        ending_liquid_depth_bits: u64,
        canonical_root_debit_kg_m2_bits: u64,
        ordered_debit_amount_bits: Vec<u64>,
        ordered_ingress_amount_bits: Vec<u64>,
    },
    Solver(openwepp_land_surface_energy::M1CoupledError),
    Receiver(M1ReceiverDiagnosticError),
    Coupled(openwepp_coupled_time::CoupledTimeError),
    NoLiveParent(openwepp_coupled_time::CoupledTimeError),
    LateOwningReceiver(M1ReceiverDiagnosticError),
}

fn resource_construction_error(
    stage: &'static str,
    source: openwepp_vegetation::v11::V11Error,
) -> M1ParentExecutionError {
    M1ParentExecutionError::ResourceConstruction { stage, source }
}

/// Reconstruct the native root update in its production arithmetic order:
/// canonical keyed kg sum, one kg-to-m conversion, then one theta subtraction.
/// This is a validator-only calculation over retained operands, never a second
/// physical map or a replacement for a receipt amount.
fn canonical_native_root_ending_depth<K: Ord>(
    beginning_layer: &crate::DirectSubsurfaceLayerState,
    beginning_supply_kg_m2: f64,
    finalized_uses_kg_m2: &std::collections::BTreeMap<K, f64>,
) -> Result<(f64, f64), openwepp_vegetation::v11::V11Error> {
    let debit_kg_m2 = openwepp_kernel_contract::canonical_resource_amount_sum(finalized_uses_kg_m2)
        .map_err(|_| openwepp_vegetation::v11::V11Error::ResourceCustody)?;
    if debit_kg_m2 > beginning_supply_kg_m2 {
        return Err(openwepp_vegetation::v11::V11Error::ResourceCustody);
    }
    let debit_m = if debit_kg_m2.to_bits() == beginning_supply_kg_m2.to_bits() {
        beginning_layer.theta_m
    } else {
        debit_kg_m2 / 1_000.0
    };
    let mut reconstructed = beginning_layer.clone();
    crate::direct_runtime::apply_direct_finalized_layer_liquid_debit(&mut reconstructed, debit_m)
        .map_err(|_| openwepp_vegetation::v11::V11Error::ResourceCustody)?;
    Ok((debit_kg_m2, reconstructed.theta_m))
}

fn retain_native_root_use<K: Ord>(
    uses: &mut std::collections::BTreeMap<K, f64>,
    key: K,
    amount_kg_m2: f64,
) -> Result<(), openwepp_vegetation::v11::V11Error> {
    if uses.insert(key, amount_kg_m2).is_some() {
        return Err(openwepp_vegetation::v11::V11Error::ResourceDebit);
    }
    Ok(())
}

fn native_water_custody_bits_match(
    post_root_liquid_depth_m: f64,
    closure_beginning_liquid_depth_m: f64,
    ending_liquid_depth_m: f64,
    closure_ending_liquid_depth_m: f64,
    transition_beginning_kg_m2: f64,
    beginning_supply_kg_m2: f64,
    transition_ending_kg_m2: f64,
    ending_supply_kg_m2: f64,
    zero_ingress: bool,
) -> bool {
    post_root_liquid_depth_m.to_bits() == closure_beginning_liquid_depth_m.to_bits()
        && ending_liquid_depth_m.to_bits() == closure_ending_liquid_depth_m.to_bits()
        && transition_beginning_kg_m2.to_bits() == beginning_supply_kg_m2.to_bits()
        && transition_ending_kg_m2.to_bits() == ending_supply_kg_m2.to_bits()
        && (!zero_ingress
            || closure_ending_liquid_depth_m.to_bits() == post_root_liquid_depth_m.to_bits())
}

#[derive(Clone, Debug, Default)]
pub(super) struct FixedSequenceAdmissionAudit {
    owner_stage_attempts: u32,
    parent_publications: u32,
}
impl FixedSequenceAdmissionAudit {
    pub(super) fn new() -> Self {
        Self::default()
    }
    pub(super) fn owner_stage_attempts(&self) -> u32 {
        self.owner_stage_attempts
    }
    pub(super) fn parent_publications(&self) -> u32 {
        self.parent_publications
    }
}

#[derive(Clone, Debug)]
pub(super) struct FixedSequenceSourceAdapter {
    manifest: Vec<u8>,
}
impl FixedSequenceSourceAdapter {
    pub(super) fn from_retained_endpoint_fixture_with_dependency_manifest(manifest: &[u8]) -> Self {
        Self {
            manifest: manifest.to_vec(),
        }
    }
    pub(super) fn canonical_payload_bytes(
        &self,
        provider_id: &str,
        cycle: u32,
    ) -> Result<Vec<u8>, ProviderError> {
        if provider_id != PROVIDER_ID || !self.valid_manifest() || cycle > 1 {
            return Err(ProviderError);
        }
        Ok(canonical_bytes(&payload(cycle as usize)?))
    }
    fn valid_manifest(&self) -> bool {
        if self.manifest != MANIFEST.as_bytes() {
            return false;
        }
        let Ok(v) = serde_json::from_slice::<Value>(&self.manifest) else {
            return false;
        };
        let Some(rows) = v["dependencies"].as_array() else {
            return false;
        };
        v["schema_version"] == 1
            && rows.len() == 10
            && rows
                .iter()
                .filter_map(|row| row["path"].as_str())
                .collect::<std::collections::BTreeSet<_>>()
                .len()
                == 10
            && rows.iter().all(|row| {
                row["path"]
                    .as_str()
                    .and_then(retained_bytes)
                    .is_some_and(|bytes| row["sha256"].as_str() == Some(&sha(bytes)))
            })
    }
    pub(super) fn manifest_sha256(&self) -> [u8; 32] {
        Sha256::digest(&self.manifest).into()
    }
    fn endpoint_gsi_for_provider() -> Result<Value, ProviderError> {
        let endpoint = super::endpoint_fixture();
        Ok(serde_json::json!({
            "gsi": format!("{:016x}", endpoint.receipt.forcing().gsi.to_bits())
        }))
    }
    fn original_exposure_for_provider(original: &Value) -> Result<Value, ProviderError> {
        let inputs = &original["inputs"];
        Ok(serde_json::json!({
            "authority": inputs["authority"],
            "stage3_lower_boundary": inputs["stage3_lower_boundary"],
            "stage3_optical": inputs["stage3_optical"],
        }))
    }
    fn original_topology_for_provider(original: &Value) -> Result<Value, ProviderError> {
        let inputs = &original["inputs"];
        Ok(serde_json::json!({
            "occupancies": inputs["occupancies"],
            "soil_nodes": inputs["ground"]["soil_nodes"],
        }))
    }
    fn controller_policy_for_provider() -> Result<Value, ProviderError> {
        let (max_newton_iterations, max_backtracking_halvings) =
            openwepp_land_surface_energy::m1_fixed_sequence_controller_policy();
        Ok(serde_json::json!({
            "max_backtracking_halvings": max_backtracking_halvings,
            "max_newton_iterations": max_newton_iterations,
        }))
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Record {
    ordinal: u32,
    start_ns: u128,
    end_ns: u128,
    bits: [u64; 5],
}
#[derive(Clone, Debug)]
pub(super) struct AdmittedFixedSequenceProvider {
    payload: Value,
    run: [u8; 32],
    records: Vec<Record>,
    calendar: [u8; 32],
    gsi: Vec<[u8; 32]>,
    gsi_bits: u64,
    projection_sha256: [u8; 32],
    payload_content_sha256: [u8; 32],
}

pub(super) fn admit_fixed_sequence_provider_for_parent(
    bytes: &[u8],
    adapter: &FixedSequenceSourceAdapter,
    _: &mut FixedSequenceAdmissionAudit,
) -> Result<AdmittedFixedSequenceProvider, ProviderError> {
    if !adapter.valid_manifest()
        || !bytes.ends_with(b"\n")
        || bytes[..bytes.len().saturating_sub(1)]
            .iter()
            .any(|byte| !byte.is_ascii())
    {
        return Err(ProviderError);
    }
    let value: Value = serde_json::from_slice(bytes).map_err(|_| ProviderError)?;
    if !ascii_json(&value) {
        return Err(ProviderError);
    }
    if canonical_bytes(&value) != bytes {
        return Err(ProviderError);
    }
    let ordinal = value["cycle"]["ordinal"].as_u64().ok_or(ProviderError)?;
    if ordinal > 1 || payload(ordinal as usize)? != value {
        return Err(ProviderError);
    }
    let run = run_identity(&value, bytes)?;
    let records = parsed_records(&value)?;
    let calendar = calendar_receipt(&value, run)?;
    let gsi_bits = u64::from_str_radix(
        value["forcing_projection"]["source_joins"][0]["value"]
            .as_str()
            .ok_or(ProviderError)?,
        16,
    )
    .map_err(|_| ProviderError)?;
    let gsi = (0..records.len())
        .map(|ordinal| gsi_receipt(&value, run, ordinal as u32, gsi_bits))
        .collect::<Result<Vec<_>, _>>()?;
    let projection_sha256: [u8; 32] =
        Sha256::digest(canonical_bytes(&value["forcing_projection"])).into();
    Ok(AdmittedFixedSequenceProvider {
        payload: value,
        run,
        records,
        calendar,
        gsi,
        gsi_bits,
        projection_sha256,
        payload_content_sha256: Sha256::digest(bytes).into(),
    })
}

impl AdmittedFixedSequenceProvider {
    pub(super) fn provider_id(&self) -> &str {
        PROVIDER_ID
    }
    pub(super) fn record_count(&self) -> usize {
        self.records.len()
    }
    pub(super) fn parent_count(&self) -> usize {
        self.records.len() / 30
    }
    pub(super) fn run_identity(&self) -> [u8; 32] {
        self.run
    }
    pub(super) fn calendar_receipt(&self) -> [u8; 32] {
        self.calendar
    }
    pub(super) fn gsi_bits(&self) -> u64 {
        self.gsi_bits
    }
    pub(super) fn payload_content_sha256(&self) -> [u8; 32] {
        self.payload_content_sha256
    }
    pub(super) fn implementation_sha256(&self) -> Result<[u8; 32], ProviderError> {
        raw32(
            self.payload["implementation"]["sha256"]
                .as_str()
                .ok_or(ProviderError)?,
        )
    }
    pub(super) fn record(&self, ordinal: u32) -> Option<ProviderRecord<'_>> {
        self.records.get(ordinal as usize).map(ProviderRecord)
    }
    pub(super) fn parent(&self, ordinal: u32) -> Option<ProviderParent> {
        (ordinal < 144).then_some(ProviderParent { ordinal })
    }
    pub(super) fn parent_gsi_support_receipts(
        &self,
        parent: u32,
    ) -> Result<Vec<[u8; 32]>, ProviderError> {
        if parent >= 144 {
            return Err(ProviderError);
        }
        Ok(self.gsi[(parent as usize) * 30..(parent as usize + 1) * 30].to_vec())
    }
    pub(super) fn parent_forcing_receipt(&self, parent: u32) -> Result<[u8; 32], ProviderError> {
        let receipts = self.parent_gsi_support_receipts(parent)?;
        let selected = Value::Array(
            self.payload["forcing_projection"]["records"]
                .as_array()
                .ok_or(ProviderError)?[(parent as usize) * 30..(parent as usize + 1) * 30]
                .to_vec(),
        );
        let mut ordered = Vec::new();
        ordered.extend_from_slice(&30_u32.to_be_bytes());
        for receipt in receipts {
            ordered.extend_from_slice(&32_u32.to_be_bytes());
            ordered.extend_from_slice(&receipt);
        }
        Ok(frame(
            "openwepp-m1-fixed-sequence-parent-forcing-v1",
            &[
                ("calendar_receipt", self.calendar.to_vec()),
                (
                    "full_projection_content_sha256",
                    self.projection_sha256.to_vec(),
                ),
                ("parent_ordinal", parent.to_be_bytes().to_vec()),
                (
                    "support_start_ns",
                    (u128::from(parent) * 1_800_000_000_000)
                        .to_be_bytes()
                        .to_vec(),
                ),
                (
                    "support_end_ns",
                    (u128::from(parent + 1) * 1_800_000_000_000)
                        .to_be_bytes()
                        .to_vec(),
                ),
                ("record_count", 30_u32.to_be_bytes().to_vec()),
                ("ordered_records", canonical_bytes(&selected)),
                ("ordered_gsi_support_receipts", ordered),
            ],
        ))
    }
    pub(super) fn admit_parent_for_caller(
        &self,
        parent: u32,
        receipts: &[[u8; 32]],
        _: &mut FixedSequenceAdmissionAudit,
    ) -> Result<(), ProviderError> {
        if self.parent_gsi_support_receipts(parent)? != receipts {
            return Err(ProviderError);
        }
        Ok(())
    }
}
pub(super) struct ProviderRecord<'a>(&'a Record);
impl ProviderRecord<'_> {
    pub(super) const fn ordinal(&self) -> u32 {
        self.0.ordinal
    }
    pub(super) fn interval_ns(&self) -> (u128, u128) {
        (self.0.start_ns, self.0.end_ns)
    }
    pub(super) fn override_binary64_bits(&self) -> [u64; 5] {
        self.0.bits
    }
}
pub(super) struct ProviderParent {
    ordinal: u32,
}
impl ProviderParent {
    pub(super) fn record_ordinals(&self) -> std::ops::Range<u32> {
        self.ordinal * 30..(self.ordinal + 1) * 30
    }
    pub(super) fn interval_ns(&self) -> (u128, u128) {
        (
            u128::from(self.ordinal) * 1_800_000_000_000,
            u128::from(self.ordinal + 1) * 1_800_000_000_000,
        )
    }
}

fn sha(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn ascii_json(value: &Value) -> bool {
    match value {
        Value::String(value) => value.is_ascii(),
        Value::Array(values) => values.iter().all(ascii_json),
        Value::Object(values) => values
            .iter()
            .all(|(key, value)| key.is_ascii() && ascii_json(value)),
        _ => true,
    }
}
fn retained_bytes(path: &str) -> Option<&'static [u8]> {
    Some(match path {
        ORIGINAL_PATH => ORIGINAL.as_bytes(),
        CONTINUOUS_PATH => CONTINUOUS.as_bytes(),
        ENDPOINT_PATH => include_bytes!("strict_v8_endpoint_tests.rs"),
        "crates/openwepp-hillslope-orchestrator/src/land_surface_energy_shadow/v8_input_projection.rs" =>
        {
            include_bytes!("v8_input_projection.rs")
        }
        "crates/openwepp-hillslope-orchestrator/src/v9_real_consumer_shadow.rs" => {
            include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/src/v9_real_consumer_shadow.rs"
            ))
        }
        "crates/openwepp-hillslope-orchestrator/src/direct_runtime/surface_liquid_owner.rs" => {
            include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/src/direct_runtime/surface_liquid_owner.rs"
            ))
        }
        "crates/openwepp-hillslope-orchestrator/src/vegetation_real_hydrology_shadow.rs" => {
            include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/src/vegetation_real_hydrology_shadow.rs"
            ))
        }
        "crates/openwepp-vegetation/src/transaction.rs" => include_bytes!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../openwepp-vegetation/src/transaction.rs"
        )),
        "crates/openwepp-land-surface-energy/src/lib.rs" => include_bytes!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../openwepp-land-surface-energy/src/lib.rs"
        )),
        CONTROLLER_PATH => include_bytes!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../openwepp-land-surface-energy/src/numerics.rs"
        )),
        _ => return None,
    })
}
fn canonical_string(s: &str, out: &mut String) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\0'..='\u{1f}' => {
                use std::fmt::Write as _;
                write!(out, "\\u00{:02x}", c as u32).expect("write")
            }
            ' '..='\u{7f}' => out.push(c),
            _ => panic!("ASCII"),
        }
    }
    out.push('"')
}
fn canonical(value: &Value, out: &mut String) {
    match value {
        Value::Null => out.push_str("null"),
        Value::Bool(v) => out.push_str(if *v { "true" } else { "false" }),
        Value::Number(v) => out.push_str(&v.to_string()),
        Value::String(v) => canonical_string(v, out),
        Value::Array(v) => {
            out.push('[');
            for (i, x) in v.iter().enumerate() {
                if i > 0 {
                    out.push(',')
                }
                canonical(x, out)
            }
            out.push(']')
        }
        Value::Object(v) => {
            out.push('{');
            let mut k = v.keys().collect::<Vec<_>>();
            k.sort_unstable();
            for (i, key) in k.into_iter().enumerate() {
                if i > 0 {
                    out.push(',')
                }
                canonical_string(key, out);
                out.push(':');
                canonical(&v[key], out)
            }
            out.push('}')
        }
    }
}
fn canonical_bytes(value: &Value) -> Vec<u8> {
    let mut s = String::new();
    canonical(value, &mut s);
    s.push('\n');
    s.into_bytes()
}
fn raw32(s: &str) -> Result<[u8; 32], ProviderError> {
    if s.len() != 64 {
        return Err(ProviderError);
    }
    let mut out = [0; 32];
    for (i, p) in s.as_bytes().chunks_exact(2).enumerate() {
        out[i] = u8::from_str_radix(std::str::from_utf8(p).map_err(|_| ProviderError)?, 16)
            .map_err(|_| ProviderError)?
    }
    Ok(out)
}
fn frame(domain: &str, fields: &[(&str, Vec<u8>)]) -> [u8; 32] {
    let mut b = b"OPENWEPP\0".to_vec();
    b.extend_from_slice(&1_u16.to_be_bytes());
    b.extend_from_slice(&(domain.len() as u16).to_be_bytes());
    b.extend_from_slice(domain.as_bytes());
    for (n, v) in fields {
        b.extend_from_slice(&(n.len() as u16).to_be_bytes());
        b.extend_from_slice(n.as_bytes());
        b.extend_from_slice(&(v.len() as u32).to_be_bytes());
        b.extend_from_slice(v)
    }
    Sha256::digest(b).into()
}

fn bits(value: &Value) -> Result<String, ProviderError> {
    Ok(format!(
        "{:016x}",
        value.as_f64().ok_or(ProviderError)?.to_bits()
    ))
}
fn overrides(source: &Value) -> Result<Value, ProviderError> {
    let b = &source["boundary_overrides"];
    Ok(
        serde_json::json!({"air_temperature_k":bits(&b["air_temperature_k"])? ,"air_specific_humidity_kg_kg":bits(&b["air_specific_humidity_kg_kg"])? ,"atmospheric_downward_longwave_w_m2":bits(&b["atmospheric_downward_longwave_w_m2"])? ,"top_liquid_rate_kg_m2_tile_s":bits(&b["top_liquid_rate_kg_m2_tile_s"])? ,"top_liquid_temperature_k":bits(&b["top_liquid_temperature_k"])?}),
    )
}
fn adapter_locator(accessor: &str, output: &Value, pointer: &str) -> Value {
    serde_json::json!({"adapter_path":PROVIDER_PATH,"adapter_sha256":sha(include_bytes!("m1_fixed_sequence_provider.rs")),"dependency_manifest_path":MANIFEST_PATH,"dependency_manifest_sha256":sha(MANIFEST.as_bytes()),"constructor_accessor":accessor,"output_canonical_json_sha256":sha(&canonical_bytes(output)),"output_pointer":pointer})
}
fn joins(original: &Value) -> Result<Vec<Value>, ProviderError> {
    let inputs = &original["inputs"];
    let records = serde_json::to_value(&super::endpoint_fixture().surface_configuration.records)
        .map_err(|_| ProviderError)?;
    let destination = records
        .as_array()
        .ok_or(ProviderError)?
        .iter()
        .find(|r| r["ground_ingress_mode"] == "covered_canopy_release")
        .ok_or(ProviderError)?;
    let destination = format!(
        "{}/{}",
        destination["key"]["ofe_id"].as_str().ok_or(ProviderError)?,
        destination["key"]["tile_id"]
            .as_str()
            .ok_or(ProviderError)?
    );
    let gsi = FixedSequenceSourceAdapter::endpoint_gsi_for_provider()?;
    let destination_output = serde_json::json!({"records":records,"destination":destination});
    let exposure = FixedSequenceSourceAdapter::original_exposure_for_provider(original)?;
    let topology = FixedSequenceSourceAdapter::original_topology_for_provider(original)?;
    let controller = FixedSequenceSourceAdapter::controller_policy_for_provider()?;
    Ok(vec![
        serde_json::json!({"field":"current_gsi","source_path":ENDPOINT_PATH,"source_sha256":sha(include_bytes!("strict_v8_endpoint_tests.rs")),"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::endpoint_gsi_for_provider",&gsi,"/gsi"),"value_kind":"binary64_bits","value":gsi["gsi"].as_str().ok_or(ProviderError)?}),
        serde_json::json!({"field":"exposure","source_path":ORIGINAL_PATH,"source_sha256":sha(ORIGINAL.as_bytes()),"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::original_exposure_for_provider",&exposure,""),"value_kind":"canonical_json_sha256","value":sha(&canonical_bytes(&exposure))}),
        serde_json::json!({"field":"destination","source_path":ENDPOINT_PATH,"source_sha256":sha(include_bytes!("strict_v8_endpoint_tests.rs")),"locator_kind":"source_extraction_adapter","locator":adapter_locator("strict_v8_endpoint_tests::endpoint_fixture/surface_configuration.records",&destination_output,"/destination"),"value_kind":"utf8","value":destination}),
        serde_json::json!({"field":"co2_pa","source_path":ORIGINAL_PATH,"source_sha256":sha(ORIGINAL.as_bytes()),"locator_kind":"json_pointer","locator":"/inputs/ca_pa","value_kind":"binary64_bits","value":bits(&inputs["ca_pa"])?}),
        serde_json::json!({"field":"reference_height_m","source_path":ORIGINAL_PATH,"source_sha256":sha(ORIGINAL.as_bytes()),"locator_kind":"json_pointer","locator":"/inputs/ground/open_geometry/reference_height_m","value_kind":"binary64_bits","value":bits(&inputs["ground"]["open_geometry"]["reference_height_m"])?}),
        serde_json::json!({"field":"topology","source_path":ORIGINAL_PATH,"source_sha256":sha(ORIGINAL.as_bytes()),"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::original_topology_for_provider",&topology,""),"value_kind":"canonical_json_sha256","value":sha(&canonical_bytes(&topology))}),
        serde_json::json!({"field":"controller_policy","source_path":CONTROLLER_PATH,"source_sha256":sha(retained_bytes(CONTROLLER_PATH).ok_or(ProviderError)?),"locator_kind":"source_extraction_adapter","locator":adapter_locator("FixedSequenceSourceAdapter::controller_policy_for_provider",&controller,""),"value_kind":"canonical_json_sha256","value":sha(&canonical_bytes(&controller))}),
    ])
}
fn phases(cycle: &Value) -> Result<Vec<Value>, ProviderError> {
    cycle["initial_phase_records"].as_array().ok_or(ProviderError)?.iter().map(|p|Ok(serde_json::json!({"occupancy_id":p["occupancy_id"].as_str().ok_or(ProviderError)?,"mass_kg_m2_tile_ground":bits(&p["mass_kg_m2_tile_ground"])? ,"enthalpy_j_m2_tile_ground":bits(&p["enthalpy_j_m2_tile_ground"])?}))).collect()
}
fn payload(index: usize) -> Result<Value, ProviderError> {
    if sha(ORIGINAL.as_bytes())
        != "4b324b0a9c136f2203e8073ca260db5be9e7dd07722a37aec60f2cd528be2d54"
        || sha(CONTINUOUS.as_bytes())
            != "8cf391055e107ca854f72fb1f70a0e78298575ad0d2ede6fa6c9c760c18191e1"
    {
        return Err(ProviderError);
    }
    // Source custody precedes JSON parsing: a changed retained file never
    // gets interpreted while building a diagnostic provider payload.
    let original: Value = serde_json::from_str(ORIGINAL).map_err(|_| ProviderError)?;
    let continuous: Value = serde_json::from_str(CONTINUOUS).map_err(|_| ProviderError)?;
    let cycle = &continuous["cycles"][index];
    let source_segments = cycle["segments"].as_array().ok_or(ProviderError)?;
    let segments=source_segments.iter().enumerate().map(|(i,s)|Ok(serde_json::json!({"ordinal":i,"start_ns":(s["start_s"].as_u64().ok_or(ProviderError)? as u128*1_000_000_000).to_string(),"end_ns":(s["end_s"].as_u64().ok_or(ProviderError)? as u128*1_000_000_000).to_string(),"overrides":overrides(s)?}))).collect::<Result<Vec<_>,ProviderError>>()?;
    let mut records = Vec::new();
    for s in source_segments {
        let start = s["start_s"].as_u64().ok_or(ProviderError)?;
        let end = s["end_s"].as_u64().ok_or(ProviderError)?;
        for t in (start..end).step_by(60) {
            records.push(serde_json::json!({"ordinal":records.len(),"start_ns":(u128::from(t)*1_000_000_000).to_string(),"end_ns":(u128::from(t+60)*1_000_000_000).to_string(),"overrides":overrides(s)?}));
        }
    }
    if records.len() != 4320 {
        return Err(ProviderError);
    }
    Ok(
        serde_json::json!({"schema_version":1,"provider_id":PROVIDER_ID,"calendar":{"system":"proleptic_gregorian","fixed_utc_offset_seconds":0,"day_seconds":86400,"daylight_saving":false,"leap_seconds":false,"origin":"2000-06-20T00:00:00+00:00","tick_unit":"integer_nanoseconds","cycle_clock_resets":true,"day_mapping":[{"day_ordinal":0,"civil_date":"2000-06-20"},{"day_ordinal":1,"civil_date":"2000-06-21"},{"day_ordinal":2,"civil_date":"2000-06-22"}]},"cycle":{"ordinal":index,"id":cycle["id"],"initial_phase_records":phases(cycle)?},"sources":[{"name":"original_input","repository_relative_path":ORIGINAL_PATH,"sha256":sha(ORIGINAL.as_bytes())},{"name":"continuous_fixture","repository_relative_path":CONTINUOUS_PATH,"sha256":sha(CONTINUOUS.as_bytes())}],"implementation":{"provider_version":PROVIDER_ID,"repository_relative_path":PROVIDER_PATH,"sha256":sha(include_bytes!("m1_fixed_sequence_provider.rs"))},"forcing_projection":{"projection_id":"OPENWEPP_COLD_M1_PIECEWISE_CONSTANT_V1","support_unit":"s","support_seconds":60,"cycle_id":cycle["id"],"segments":segments,"records":records,"source_joins":joins(&original)?}}),
    )
}
fn run_identity(value: &Value, bytes: &[u8]) -> Result<[u8; 32], ProviderError> {
    let s = value["sources"].as_array().ok_or(ProviderError)?;
    let i = &value["implementation"];
    Ok(frame(
        "openwepp-m1-fixed-sequence-run-v1",
        &[
            ("schema_version", 1_u32.to_be_bytes().to_vec()),
            ("provider_id", PROVIDER_ID.as_bytes().to_vec()),
            ("calendar", canonical_bytes(&value["calendar"])),
            (
                "original_source_sha256",
                raw32(s[0]["sha256"].as_str().ok_or(ProviderError)?)?.to_vec(),
            ),
            (
                "continuous_source_sha256",
                raw32(s[1]["sha256"].as_str().ok_or(ProviderError)?)?.to_vec(),
            ),
            (
                "implementation_version",
                i["provider_version"]
                    .as_str()
                    .ok_or(ProviderError)?
                    .as_bytes()
                    .to_vec(),
            ),
            (
                "implementation_path",
                i["repository_relative_path"]
                    .as_str()
                    .ok_or(ProviderError)?
                    .as_bytes()
                    .to_vec(),
            ),
            (
                "implementation_sha256",
                raw32(i["sha256"].as_str().ok_or(ProviderError)?)?.to_vec(),
            ),
            ("payload_content_sha256", Sha256::digest(bytes).to_vec()),
        ],
    ))
}
fn calendar_receipt(value: &Value, run: [u8; 32]) -> Result<[u8; 32], ProviderError> {
    Ok(frame(
        "openwepp-m1-fixed-sequence-calendar-provider-v1",
        &[
            ("run_identity", run.to_vec()),
            (
                "cycle_ordinal",
                u32::try_from(value["cycle"]["ordinal"].as_u64().ok_or(ProviderError)?)
                    .map_err(|_| ProviderError)?
                    .to_be_bytes()
                    .to_vec(),
            ),
            (
                "cycle_id",
                value["cycle"]["id"]
                    .as_str()
                    .ok_or(ProviderError)?
                    .as_bytes()
                    .to_vec(),
            ),
            (
                "initial_phase_records",
                canonical_bytes(&value["cycle"]["initial_phase_records"]),
            ),
        ],
    ))
}
fn gsi_receipt(
    value: &Value,
    run: [u8; 32],
    ordinal: u32,
    gsi_bits: u64,
) -> Result<[u8; 32], ProviderError> {
    let join = value["forcing_projection"]["source_joins"]
        .as_array()
        .ok_or(ProviderError)?
        .first()
        .ok_or(ProviderError)?;
    Ok(frame(
        "openwepp-m1-fixed-sequence-gsi-support-v1",
        &[
            ("run_identity", run.to_vec()),
            (
                "cycle_ordinal",
                u32::try_from(value["cycle"]["ordinal"].as_u64().ok_or(ProviderError)?)
                    .map_err(|_| ProviderError)?
                    .to_be_bytes()
                    .to_vec(),
            ),
            (
                "cycle_id",
                value["cycle"]["id"]
                    .as_str()
                    .ok_or(ProviderError)?
                    .as_bytes()
                    .to_vec(),
            ),
            ("support_ordinal", ordinal.to_be_bytes().to_vec()),
            (
                "support_start_ns",
                (u128::from(ordinal) * 60_000_000_000)
                    .to_be_bytes()
                    .to_vec(),
            ),
            (
                "support_end_ns",
                (u128::from(ordinal + 1) * 60_000_000_000)
                    .to_be_bytes()
                    .to_vec(),
            ),
            ("gsi_bits", gsi_bits.to_be_bytes().to_vec()),
            (
                "gsi_source_join_content_sha256",
                Sha256::digest(canonical_bytes(join)).to_vec(),
            ),
        ],
    ))
}
fn parsed_records(value: &Value) -> Result<Vec<Record>, ProviderError> {
    value["forcing_projection"]["records"]
        .as_array()
        .ok_or(ProviderError)?
        .iter()
        .map(|r| {
            let o = u32::try_from(r["ordinal"].as_u64().ok_or(ProviderError)?)
                .map_err(|_| ProviderError)?;
            let parse = |key: &str| {
                r[key]
                    .as_str()
                    .ok_or(ProviderError)?
                    .parse::<u128>()
                    .map_err(|_| ProviderError)
            };
            let x = &r["overrides"];
            let names = [
                "air_temperature_k",
                "air_specific_humidity_kg_kg",
                "atmospheric_downward_longwave_w_m2",
                "top_liquid_rate_kg_m2_tile_s",
                "top_liquid_temperature_k",
            ];
            let mut bits = [0; 5];
            for (i, n) in names.into_iter().enumerate() {
                bits[i] = u64::from_str_radix(x[n].as_str().ok_or(ProviderError)?, 16)
                    .map_err(|_| ProviderError)?
            }
            Ok(Record {
                ordinal: o,
                start_ns: parse("start_ns")?,
                end_ns: parse("end_ns")?,
                bits,
            })
        })
        .collect()
}

#[derive(Clone, Debug, PartialEq)]
pub(super) struct RealM1CallerSnapshot(super::M1CallerState, Option<String>, Option<String>);
pub(super) struct RealM1ProviderCaller(
    super::M1CallerState,
    Option<M1NativeCapabilityReceipt>,
    Option<M1ParentReceipt>,
);
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) struct M1ParentOnlyCounters {
    pub(super) parent_revision: u64,
    pub(super) publication_count: u64,
}
#[derive(Clone, Debug, PartialEq)]
pub(super) struct M1ParentReceipt {
    accepted_slab_receipt_ids: Vec<openwepp_coupled_time::ReceiptId>,
    /// Accepted support proposals in their real parent order.
    material_transfers: Vec<openwepp_vegetation::carbon_nitrogen::MaterialTransfer>,
}
impl M1ParentReceipt {
    pub(super) fn accepted_slab_ids(&self) -> Vec<openwepp_coupled_time::ReceiptId> {
        self.accepted_slab_receipt_ids.clone()
    }
    pub(super) fn material_transfers(
        &self,
    ) -> &[openwepp_vegetation::carbon_nitrogen::MaterialTransfer] {
        &self.material_transfers
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(super) struct M1NativeCapabilityReceipt {
    support: TimeSupport,
    transaction_id: openwepp_kernel_contract::TransactionId,
    mass_kg_m2_tile: f64,
    enthalpy_j_kg: f64,
    capability: super::m1_receiver::M1NativeCapability,
}
trait M1NativeReplayCapability {
    fn consume_replay(&self) -> Result<(), M1ReceiverDiagnosticError>;
}
impl M1NativeReplayCapability for &M1NativeCapabilityReceipt {
    fn consume_replay(&self) -> Result<(), M1ReceiverDiagnosticError> {
        self.capability.consume()
    }
}
impl M1NativeReplayCapability for &super::M1ReceiverDiagnosticResult {
    fn consume_replay(&self) -> Result<(), M1ReceiverDiagnosticError> {
        self.replay_capability()
    }
}
impl M1NativeReplayCapability for &M1ReceiverDiagnosticError {
    fn consume_replay(&self) -> Result<(), M1ReceiverDiagnosticError> {
        self.replay_consumed_capability()
    }
}

impl M1NativeCapabilityReceipt {
    pub(super) const fn support(&self) -> TimeSupport {
        self.support
    }
    pub(super) const fn transaction_id(&self) -> u128 {
        self.transaction_id.0
    }
    pub(super) const fn mass_kg_m2_tile(&self) -> f64 {
        self.mass_kg_m2_tile
    }
    pub(super) const fn enthalpy_j_kg(&self) -> f64 {
        self.enthalpy_j_kg
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(super) struct M1NativeReceiverOutcome {
    receipt: Option<M1NativeCapabilityReceipt>,
    source_operands: Vec<M1ReceiverContribution>,
}
impl M1NativeReceiverOutcome {
    pub(super) fn is_positive(&self) -> bool {
        self.receipt.is_some()
    }
    pub(super) fn receipt(&self) -> Option<&M1NativeCapabilityReceipt> {
        self.receipt.as_ref()
    }
    fn source_operands(&self) -> &[M1ReceiverContribution] {
        &self.source_operands
    }
}
/// Immutable accepted-support handoff.  The fields are copied only from the
/// accepted solver/receiver/clock seam and are the sole input to the private
/// M1→V11 custody adapter.
#[derive(Clone, Debug, PartialEq)]
pub(super) struct M1AcceptedSupportOutcome {
    record_ordinal: u32,
    support: TimeSupport,
    applied_override_bits: [u64; 5],
    gsi_bits: u64,
    gsi_support_receipt: [u8; 32],
    parent_forcing_receipt: [u8; 32],
    beginning_owner_bytes: std::collections::BTreeMap<String, Vec<u8>>,
    ending_owner_bytes: std::collections::BTreeMap<String, Vec<u8>>,
    accepted_slab_receipt: AcceptedSlabReceiptV1,
    producer: M1AcceptedSupportEvidence,
    native_receiver: M1NativeReceiverOutcome,
    resource_debits: Vec<openwepp_vegetation::v11::V11ResourceDebit>,
    admitted_resource_fluxes: Vec<openwepp_vegetation::v11::V11AdmittedResourceFlux>,
    shared_resource_owner_transitions:
        Vec<openwepp_vegetation::v11::V11SharedResourceOwnerTransition>,
    complete_owner_candidates: Vec<openwepp_vegetation::v11::V11CompleteOwnerCandidate>,
    ending_owner_states: Vec<OwnerState>,
}
impl M1AcceptedSupportOutcome {
    pub(super) const fn record_ordinal(&self) -> u32 {
        self.record_ordinal
    }
    pub(super) const fn support(&self) -> TimeSupport {
        self.support
    }
    pub(super) const fn applied_override_bits(&self) -> [u64; 5] {
        self.applied_override_bits
    }
    pub(super) const fn gsi_bits(&self) -> u64 {
        self.gsi_bits
    }
    pub(super) const fn gsi_support_receipt(&self) -> [u8; 32] {
        self.gsi_support_receipt
    }
    pub(super) const fn parent_forcing_receipt(&self) -> [u8; 32] {
        self.parent_forcing_receipt
    }
    pub(super) fn beginning_owner_bytes(&self) -> std::collections::BTreeMap<String, Vec<u8>> {
        self.beginning_owner_bytes.clone()
    }
    pub(super) fn ending_owner_bytes(&self) -> std::collections::BTreeMap<String, Vec<u8>> {
        self.ending_owner_bytes.clone()
    }
    pub(super) fn reservoir_operands(
        &self,
    ) -> &[openwepp_land_surface_energy::M1ReservoirOperands] {
        &self.producer.reservoir_operands
    }
    pub(super) fn material_transfers(
        &self,
    ) -> &[openwepp_vegetation::carbon_nitrogen::MaterialTransfer] {
        self.producer.m1_candidate.material_proposals()
    }
    pub(super) fn resource_debits(&self) -> &[openwepp_vegetation::v11::V11ResourceDebit] {
        &self.resource_debits
    }
    pub(super) fn admitted_resource_fluxes(
        &self,
    ) -> &[openwepp_vegetation::v11::V11AdmittedResourceFlux] {
        &self.admitted_resource_fluxes
    }
    pub(super) fn shared_resource_owner_transitions(
        &self,
    ) -> &[openwepp_vegetation::v11::V11SharedResourceOwnerTransition] {
        &self.shared_resource_owner_transitions
    }
    pub(super) fn complete_owner_candidates(
        &self,
    ) -> &[openwepp_vegetation::v11::V11CompleteOwnerCandidate] {
        &self.complete_owner_candidates
    }
    pub(super) fn biogeochemistry_candidate(
        &self,
    ) -> &openwepp_biogeochemistry::BiogeochemistryOwnerCandidate {
        &self.producer.bgc_candidate
    }
    pub(super) fn beginning_biogeochemistry(
        &self,
    ) -> &openwepp_biogeochemistry::BiogeochemistryState {
        self.producer.bgc_candidate.beginning()
    }
    pub(super) fn ending_biogeochemistry(&self) -> &openwepp_biogeochemistry::BiogeochemistryState {
        self.producer.bgc_candidate.ending()
    }
    pub(super) const fn checked_support_transaction_id(&self) -> u128 {
        self.producer.support_transaction_id.0
    }
    pub(super) const fn native_consumed_forcing_bits(&self) -> [u64; 10] {
        self.producer.native_consumed_forcing_bits
    }
    pub(super) fn staged_thermal_transition_sha256(&self) -> (&str, &str) {
        (
            self.producer.beginning_thermal_sha256.as_str(),
            self.producer.ending_thermal_sha256.as_str(),
        )
    }
    pub(super) fn prepared_soil_temperature_bits(&self) -> &[u64] {
        &self.producer.prepared_soil_temperature_bits
    }
    pub(super) fn prepared_soil_temperature_by_layer(
        &self,
    ) -> &std::collections::BTreeMap<String, u64> {
        &self.producer.prepared_soil_temperature_by_layer
    }
    pub(super) const fn staged_bgc_parent_predecessor(&self) -> u128 {
        self.producer.bgc_parent_predecessor
    }
    pub(super) fn accepted_slab_receipt(&self) -> &AcceptedSlabReceiptV1 {
        &self.accepted_slab_receipt
    }
    pub(super) fn ending_owner_states(&self) -> &[OwnerState] {
        &self.ending_owner_states
    }
    pub(super) fn native_receiver(&self) -> &M1NativeReceiverOutcome {
        &self.native_receiver
    }
    pub(super) fn native_receiver_source_operands(&self) -> &[M1ReceiverContribution] {
        self.native_receiver.source_operands()
    }
    pub(super) fn raw_resource_candidate_debits(
        &self,
    ) -> &[openwepp_vegetation::v11::V11ResourceDebit] {
        &self.resource_debits
    }
    pub(super) fn raw_resource_candidate_fluxes(
        &self,
    ) -> &[openwepp_vegetation::v11::V11AdmittedResourceFlux] {
        &self.admitted_resource_fluxes
    }
}
impl RealM1ProviderCaller {
    pub(super) fn parent_only_counters(&self) -> M1ParentOnlyCounters {
        M1ParentOnlyCounters {
            parent_revision: self.0.provider_parent_revision(),
            publication_count: self.0.provider_parent_publication_count(),
        }
    }
    pub(super) fn admitted_owner_count(&self) -> Option<usize> {
        self.0.provider_admitted_owner_count()
    }
    pub(super) fn has_staged_owner(&self) -> bool {
        self.0.provider_has_staged_owner()
    }
    pub(super) fn active_participants(&self) -> Option<&[String]> {
        self.0.provider_active_participants()
    }
    pub(super) fn beginning_owner_bytes(
        &self,
    ) -> Result<std::collections::BTreeMap<String, Vec<u8>>, ProviderError> {
        self.0
            .provider_seven_beginning_owner_bytes()
            .map_err(|_| ProviderError)
    }
    pub(super) fn staged_soil_temperature_bits(
        &self,
    ) -> Result<std::collections::BTreeMap<String, u64>, ProviderError> {
        self.0
            .provider_current_soil_temperatures()
            .map(|values| {
                values
                    .into_iter()
                    .map(|(id, value)| (id, value.to_bits()))
                    .collect()
            })
            .map_err(|_| ProviderError)
    }

    /// Materialize one fixed support from the retained original column, the
    /// prescribed five binary64 overrides, and the caller's true current M/H.
    /// The returned preparation owns an evaluation minted by the canonical
    /// M1 solver; it is not a replayed endpoint result.
    fn prepare_fixed_sequence_support(
        &self,
        record: &ProviderRecord<'_>,
        gsi_bits: u64,
    ) -> Result<(super::M1PreparedCallerContext, f64), M1ParentExecutionError> {
        let gsi = f64::from_bits(gsi_bits);
        if !gsi.is_finite() || !(0.0..=1.0).contains(&gsi) {
            return Err(M1ParentExecutionError::Provider(ProviderError));
        }
        let [
            air_temperature,
            specific_humidity,
            longwave,
            liquid_rate,
            liquid_temperature,
        ] = record.override_binary64_bits().map(f64::from_bits);
        if !air_temperature.is_finite()
            || !specific_humidity.is_finite()
            || !longwave.is_finite()
            || !liquid_rate.is_finite()
            || !liquid_temperature.is_finite()
        {
            return Err(M1ParentExecutionError::Provider(ProviderError));
        }
        let reservoirs = self
            .0
            .provider_current_reservoirs()
            .iter()
            .map(|(occupancy, mass, enthalpy)| {
                M1PhaseReservoirInput::new(occupancy.clone(), *mass, *enthalpy)
            })
            .collect::<Vec<_>>();
        let [upper, lower]: [M1PhaseReservoirInput; 2] = reservoirs
            .try_into()
            .map_err(|_| M1ParentExecutionError::Provider(ProviderError))?;
        let mut column = super::m1_coupled_expected_red::provider_covered_input();
        let current_soil_temperatures = self
            .0
            .provider_current_soil_temperatures()
            .map_err(M1ParentExecutionError::Receiver)?;
        for node in &mut column.ground.soil_nodes {
            node.beginning_temperature_k = *current_soil_temperatures
                .get(&node.layer_id)
                .ok_or(M1ParentExecutionError::Provider(ProviderError))?;
        }
        column.air_temperature_k = air_temperature;
        column.air_specific_humidity_kg_kg = specific_humidity;
        column.atmospheric_downward_longwave_w_m2 = longwave;
        column.top_rain_kg_m2_tile = liquid_rate * column.interval_s;
        let input = M1CoupledColumnInput::from_covered_column(
            column,
            [upper, lower],
            super::m1_coupled_expected_red::provider_conditions(),
            super::m1_coupled_expected_red::provider_topology_binding(),
        )
        .with_top_liquid_specific_enthalpy(
            openwepp_land_surface_energy::physics::liquid_enthalpy_j_kg(liquid_temperature),
        );
        #[cfg(test)]
        let diagnostic_armed = M1_LSE_DIAGNOSTIC_ORDINAL.with(|armed| {
            if armed.get() == Some(record.ordinal()) {
                armed.set(None);
                true
            } else {
                false
            }
        });
        #[cfg(test)]
        if diagnostic_armed {
            let guard = input.enable_one_m1_diagnostic_observation();
            let result = solve_m1_coupled_column(&input);
            let observation = input.take_m1_diagnostic_observation();
            M1_LSE_DIAGNOSTIC_RECORD.with(|capture| {
                if let Ok(mut capture) = capture.try_borrow_mut() {
                *capture = Some(serde_json::json!({
                    "record_ordinal": record.ordinal(),
                    "override_bits": record.override_binary64_bits(),
                    "gsi_bits": gsi_bits,
                    "duration_s_bits": input.column.interval_s.to_bits(),
                    "top_liquid_rate_bits": liquid_rate.to_bits(),
                    "top_liquid_amount_bits": input.column.top_rain_kg_m2_tile.to_bits(),
                    "top_liquid_specific_enthalpy_bits": input.top_liquid_specific_enthalpy_j_kg.map(f64::to_bits),
                    "actual_solver_input_debug": format!("{input:?}"),
                    "native_execution_status": "prepared_solver_input_only_native_receiver_not_reached_on_solver_error",
                    "prepared_solver_column_inputs": {
                        "air_temperature_bits": input.column.air_temperature_k.to_bits(),
                        "specific_humidity_bits": input.column.air_specific_humidity_kg_kg.to_bits(),
                        "longwave_bits": input.column.atmospheric_downward_longwave_w_m2.to_bits(),
                        "pressure_bits": input.column.pressure_pa.to_bits(),
                        "reference_wind_bits": input.column.reference_wind_m_s.to_bits(),
                        "shortwave_bits": [
                            input.column.shortwave.incident_w_m2_tile.direct_vis.to_bits(),
                            input.column.shortwave.incident_w_m2_tile.diffuse_vis.to_bits(),
                            input.column.shortwave.incident_w_m2_tile.direct_nir.to_bits(),
                            input.column.shortwave.incident_w_m2_tile.diffuse_nir.to_bits(),
                        ],
                    },
                    "reservoirs": input.reservoirs.iter().map(|value| serde_json::json!({
                        "occupancy_id": value.occupancy_id,
                        "mass_bits": value.mass_kg_m2.to_bits(),
                        "enthalpy_bits": value.enthalpy_j_m2.to_bits(),
                    })).collect::<Vec<_>>(),
                    "soil_nodes": input.column.ground.soil_nodes.iter().map(|node| serde_json::json!({
                        "layer_id": node.layer_id,
                        "temperature_bits": node.beginning_temperature_k.to_bits(),
                        "depth_bits": node.depth_m.to_bits(),
                        "conductivity_bits": node.conductivity_w_m_k.to_bits(),
                        "heat_capacity_bits": node.heat_capacity_j_m2_k.to_bits(),
                    })).collect::<Vec<_>>(),
                    "solver_error": result.as_ref().err().map(|error| error.code()),
                    "observer": observation.as_ref().map(|value| serde_json::json!({
                        "seed_coordinates_bits": value.seed_coordinates.map(|seed| seed.map(f64::to_bits)),
                        "status": format!("{:?}", value.status),
                        "terminal_error_code": value.terminal_error_code,
                        "bases": value.bases.iter().map(|base| serde_json::json!({
                            "iteration": base.iteration,
                            "coordinates_bits": base.coordinates.map(f64::to_bits),
                            "raw_residual_bits": base.raw_residuals.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                            "normalized_residual_bits": base.normalized_residuals.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                            "normalizer_bits": base.normalizers.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                            "row_identities": base.row_identities,
                            "row_units": base.row_units.iter().map(|unit| format!("{unit:?}")).collect::<Vec<_>>(),
                            "normalized_jacobian_bits": base.normalized_jacobian.iter().map(|row| row.iter().map(|value| value.to_bits()).collect::<Vec<_>>()).collect::<Vec<_>>(),
                            "rhs_bits": base.rhs.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                            "direction_bits": base.direction.map(f64::to_bits),
                            "natural_selections": format!("{:?}", base.natural_selections),
                            "predictor_selections": format!("{:?}", base.predictor_selections),
                            "final_selections": format!("{:?}", base.final_selections),
                            "corrected_assembly": base.corrected_assembly,
                            "full_linear_dimension": base.full_linear_dimension,
                            "reduced_linear_dimension": base.reduced_linear_dimension,
                        })).collect::<Vec<_>>(),
                        "trials": value.trials.iter().map(|trial| serde_json::json!({
                            "iteration": trial.iteration, "exponent": trial.exponent,
                            "factor_bits": trial.factor.to_bits(), "coordinates_bits": trial.coordinates.map(f64::to_bits),
                            "reason": trial.reason,
                            "raw_residual_bits": trial.raw_residuals.as_ref().map(|rows| rows.iter().map(|value| value.to_bits()).collect::<Vec<_>>()),
                            "normalized_residual_bits": trial.normalized_residuals.as_ref().map(|rows| rows.iter().map(|value| value.to_bits()).collect::<Vec<_>>()),
                        })).collect::<Vec<_>>(),
                        "linear_solves": value.linear_solves.iter().map(|solve| serde_json::json!({
                            "iteration": solve.iteration, "corrected_assembly": solve.corrected_assembly,
                            "full_matrix_bits": solve.full_matrix.iter().map(|row| row.iter().map(|value| value.to_bits()).collect::<Vec<_>>()).collect::<Vec<_>>(),
                            "full_rhs_bits": solve.full_rhs.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                            "reduced_matrix_bits": solve.reduced_matrix.iter().map(|row| row.iter().map(|value| value.to_bits()).collect::<Vec<_>>()).collect::<Vec<_>>(),
                            "reduced_rhs_bits": solve.reduced_rhs.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                            "retained_indices": solve.retained_indices, "eliminated_indices": solve.eliminated_indices,
                            "reduced_direction_bits": solve.reduced_direction.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                            "full_direction_bits": solve.full_direction.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
                        })).collect::<Vec<_>>(),
                    })),
                }));
                }
            });
            drop(guard);
            let evaluation = result.map_err(M1ParentExecutionError::Solver)?;
            let prepared = super::M1PreparedCallerContext::new(input, evaluation)
                .map_err(M1ParentExecutionError::Solver)?;
            return Ok((prepared, gsi));
        }
        let evaluation = solve_m1_coupled_column(&input).map_err(M1ParentExecutionError::Solver)?;
        let prepared = super::M1PreparedCallerContext::new(input, evaluation)
            .map_err(M1ParentExecutionError::Solver)?;
        Ok((prepared, gsi))
    }
    pub(super) fn accepted_cursor(&self) -> u64 {
        self.0.accepted_cursor()
    }
    pub(super) fn staged_owner_bytes(
        &self,
    ) -> Result<std::collections::BTreeMap<String, Vec<u8>>, ProviderError> {
        self.0
            .provider_current_owner_bytes()
            .map_err(|_| ProviderError)
    }
    pub(super) fn staged_owner_is_none(&self) -> bool {
        !self.0.provider_has_staged_owner()
    }
    pub(super) fn parent_clock_is_none(&self) -> bool {
        self.0.provider_parent_clock().is_none()
    }
    pub(super) fn active_parent_clock(&self) -> Option<&CoupledClockStateV1> {
        self.0.provider_parent_clock()
    }
    pub(super) fn parent_only_transaction_id(&self) -> u128 {
        self.0
            .provider_parent_transaction_namespace()
            .unwrap_or_default()
    }
    pub(super) fn current_support_transaction_id(
        &self,
    ) -> Option<openwepp_kernel_contract::TransactionId> {
        self.0.provider_next_support_transaction_id()
    }
    pub(super) fn complete_parent(&mut self) -> Result<(), M1ParentExecutionError> {
        let clock =
            self.0
                .provider_parent_clock()
                .cloned()
                .ok_or(M1ParentExecutionError::NoLiveParent(
                    openwepp_coupled_time::CoupledTimeError::ParentNotFinalizable,
                ))?;
        let receipt = M1ParentReceipt {
            material_transfers: self
                .0
                .provider_parent_material_transfers()
                .map_err(M1ParentExecutionError::Receiver)?,
            accepted_slab_receipt_ids: clock
                .accepted_slab_receipts()
                .iter()
                .map(|value| value.id())
                .collect(),
        };
        self.0
            .complete_parent()
            .map_err(M1ParentExecutionError::Receiver)?;
        self.2 = Some(receipt);
        Ok(())
    }
    pub(super) fn sealed_finalized_complete_owner_states(&self) -> Option<Vec<OwnerState>> {
        self.0
            .provider_sealed_finalized_owners()
            .map(ToOwned::to_owned)
    }
    pub(super) fn native_capability_consumption_receipt(
        &self,
    ) -> Option<&M1NativeCapabilityReceipt> {
        self.1.as_ref()
    }
    pub(super) fn last_parent_receipt(&self) -> Result<&M1ParentReceipt, M1ParentExecutionError> {
        self.2.as_ref().ok_or(M1ParentExecutionError::NoLiveParent(
            openwepp_coupled_time::CoupledTimeError::ParentNotFinalizable,
        ))
    }
    pub(super) fn replay_native_capability<T: M1NativeReplayCapability>(
        &self,
        capability: T,
    ) -> Result<(), M1ReceiverDiagnosticError> {
        capability.consume_replay()
    }
}
impl RealM1CallerSnapshot {
    pub(super) fn capture(caller: &RealM1ProviderCaller) -> Result<Self, ProviderError> {
        Ok(Self(
            caller.0.clone(),
            caller.1.as_ref().map(|receipt| format!("{receipt:?}")),
            caller.2.as_ref().map(|receipt| format!("{receipt:?}")),
        ))
    }
}

/// Advance one fixed provider support through the real M1/native receiver and
/// admit its seven actual ending owners into the live coupled clock.  The
/// caller is replaced only after both native staging and `accept_slab` succeed.
pub(super) fn advance_fixed_sequence_support(
    caller: &mut RealM1ProviderCaller,
    admitted: &AdmittedFixedSequenceProvider,
    ordinal: u32,
    injection: Option<super::M1ReceiverFailureInjection>,
) -> Result<M1AcceptedSupportOutcome, M1ParentExecutionError> {
    #[cfg(test)]
    M1_RAW_WATER_ORACLE.with(|values| values.borrow_mut().clear());
    let result = advance_fixed_sequence_support_inner(caller, admitted, ordinal, injection);
    #[cfg(test)]
    if result.is_err() {
        // A failed attempt has no accepted observation.  Dropping it prevents
        // a caller from mistaking a partial row for the next support's facts.
        M1_RAW_WATER_ORACLE.with(|values| values.borrow_mut().clear());
    }
    result
}

fn advance_fixed_sequence_support_inner(
    caller: &mut RealM1ProviderCaller,
    admitted: &AdmittedFixedSequenceProvider,
    ordinal: u32,
    injection: Option<super::M1ReceiverFailureInjection>,
) -> Result<M1AcceptedSupportOutcome, M1ParentExecutionError> {
    let record = admitted
        .record(ordinal)
        .ok_or(M1ParentExecutionError::Provider(ProviderError))?;
    let (start_ns, end_ns) = record.interval_ns();
    let parent_ordinal = ordinal / 30;
    if !caller.0.provider_matches_admitted_support(
        admitted.run_identity(),
        admitted
            .cycle_ordinal()
            .map_err(M1ParentExecutionError::Provider)?,
        parent_ordinal,
        ordinal,
        start_ns,
        end_ns,
    ) {
        return Err(M1ParentExecutionError::Provider(ProviderError));
    }
    let beginning_owner_bytes = caller
        .0
        .provider_current_owner_bytes()
        .map_err(M1ParentExecutionError::Receiver)?;
    let (prepared, authenticated_gsi) =
        caller.prepare_fixed_sequence_support(&record, admitted.gsi_bits())?;
    let mut next = caller.0.clone();
    let mut fixture = caller.0.provider_native_bootstrap().clone();
    let result = super::m1_receiver::advance_m1_caller_support_with_gsi(
        &mut next,
        &mut fixture,
        prepared,
        u64::from(ordinal),
        authenticated_gsi,
        injection,
    )
    .map_err(|error| {
        if error.is_genuine_late_owning_receiver_failure() {
            M1ParentExecutionError::LateOwningReceiver(error)
        } else {
            M1ParentExecutionError::Receiver(error)
        }
    })?;
    let clock = next
        .provider_parent_clock()
        .cloned()
        .ok_or(M1ParentExecutionError::Provider(ProviderError))?;
    let support = TimeSupport::new(ModelTimeNs::new(start_ns), ModelTimeNs::new(end_ns))
        .map_err(M1ParentExecutionError::Coupled)?;
    let constraint = StepConstraintV1::new(
        clock.parent_transaction_id(),
        support.start_ns(),
        support.end_ns(),
        "m1-fixed-sequence".to_owned(),
        ConstraintClass::HardBoundary,
        Digest32::from_bytes(admitted.payload_content_sha256()),
        Digest32::from_bytes(admitted.calendar_receipt()),
        Digest32::from_bytes(
            admitted
                .parent_forcing_receipt(ordinal / 30)
                .map_err(M1ParentExecutionError::Provider)?,
        ),
    )
    .map_err(M1ParentExecutionError::Coupled)?;
    let reduction = reduce_constraints(
        &[constraint],
        clock.parent_transaction_id(),
        support.start_ns(),
        support.end_ns(),
        None,
    )
    .map_err(M1ParentExecutionError::Coupled)?;
    let owners = next
        .provider_current_owner_bytes()
        .map_err(M1ParentExecutionError::Receiver)?
        .into_iter()
        .map(|(id, bytes)| OwnerState::new(id, bytes))
        .collect::<Result<Vec<_>, _>>()
        .map_err(M1ParentExecutionError::Coupled)?;
    let owner_digest =
        complete_owner_set_digest(clock.owners()).map_err(M1ParentExecutionError::Coupled)?;
    let mut custody_preimage = Vec::new();
    custody_preimage.extend_from_slice(clock.parent_transaction_id().digest().as_bytes());
    custody_preimage.extend_from_slice(&support.start_ns().get().to_be_bytes());
    custody_preimage.extend_from_slice(&support.end_ns().get().to_be_bytes());
    let custody_digest: [u8; 32] = Sha256::digest(&custody_preimage).into();
    let ledger = LedgerEntryV1::new(
        "m1-complete-owner-custody".to_owned(),
        "canonical-owner-state".to_owned(),
        owner_digest,
        owner_digest,
        Digest32::from_bytes(custody_digest),
    )
    .map_err(M1ParentExecutionError::Coupled)?;
    let slab = CoupledSlabCandidateV1::new(
        &clock,
        clock.active_segment_id(),
        support,
        &reduction,
        owners,
        vec![ledger],
    )
    .map_err(M1ParentExecutionError::Coupled)?;
    let mut accepted_clock = clock;
    accept_slab(&mut accepted_clock, slab).map_err(M1ParentExecutionError::Coupled)?;
    let accepted_slab_receipt = accepted_clock
        .accepted_slab_receipts()
        .last()
        .cloned()
        .ok_or(M1ParentExecutionError::Provider(ProviderError))?;
    next.provider_replace_parent_clock(accepted_clock);
    let ending_owner_bytes = next
        .provider_current_owner_bytes()
        .map_err(M1ParentExecutionError::Receiver)?;
    let producer = next
        .provider_last_accepted_support_evidence()
        .cloned()
        .ok_or(M1ParentExecutionError::Provider(ProviderError))?;
    let predecessors = next.provider_previous_resource_transitions().to_vec();
    let (
        resource_debits,
        admitted_resource_fluxes,
        shared_resource_owner_transitions,
        complete_owner_candidates,
    ) = m1_v11_resource_custody(
        &producer,
        &accepted_slab_receipt,
        &beginning_owner_bytes,
        &ending_owner_bytes,
        &predecessors,
    )?;
    let ending_owner_states = ending_owner_bytes
        .iter()
        .map(|(id, bytes)| OwnerState::new(id.clone(), bytes.clone()))
        .collect::<Result<Vec<_>, _>>()
        .map_err(M1ParentExecutionError::Coupled)?;
    next.provider_record_resource_custody_bundle(super::m1_receiver::M1ResourceCustodyBundle {
        slab: accepted_slab_receipt.clone(),
        debits: resource_debits.clone(),
        fluxes: admitted_resource_fluxes.clone(),
        transitions: shared_resource_owner_transitions.clone(),
        candidates: complete_owner_candidates.clone(),
        ending_owner_states: ending_owner_states.clone(),
    });
    let native_receiver = match result {
        super::M1CallerSupportResult::ZeroTransfer => M1NativeReceiverOutcome {
            receipt: None,
            source_operands: Vec::new(),
        },
        super::M1CallerSupportResult::PositiveTransfer(value) => {
            let source_operands = value.contribution_join().contributors().to_vec();
            let mass_kg_m2_tile = source_operands
                .iter()
                .map(M1ReceiverContribution::tile_mass_kg_m2)
                .sum();
            let enthalpy_j_kg = source_operands
                .first()
                .ok_or(M1ParentExecutionError::Provider(ProviderError))?
                .specific_enthalpy_j_kg();
            M1NativeReceiverOutcome {
                receipt: Some(M1NativeCapabilityReceipt {
                    support,
                    transaction_id: value.actual_candidate().transaction_id(),
                    mass_kg_m2_tile,
                    enthalpy_j_kg,
                    capability: value.capability(),
                }),
                source_operands,
            }
        }
    };
    caller.0 = next;
    caller.1 = native_receiver.receipt.clone();
    Ok(M1AcceptedSupportOutcome {
        record_ordinal: ordinal,
        support,
        applied_override_bits: record.override_binary64_bits(),
        gsi_bits: admitted.gsi_bits(),
        gsi_support_receipt: admitted
            .parent_gsi_support_receipts(parent_ordinal)
            .map_err(M1ParentExecutionError::Provider)?[usize::try_from(ordinal % 30)
            .map_err(|_| M1ParentExecutionError::Provider(ProviderError))?],
        parent_forcing_receipt: admitted
            .parent_forcing_receipt(parent_ordinal)
            .map_err(M1ParentExecutionError::Provider)?,
        beginning_owner_bytes,
        ending_owner_bytes,
        accepted_slab_receipt,
        producer,
        native_receiver,
        resource_debits,
        admitted_resource_fluxes,
        shared_resource_owner_transitions,
        complete_owner_candidates,
        ending_owner_states,
    })
}

/// Translate the actual native M1 withdrawal protocol into the generic V11
/// custody wire.  Every debit comes from a finalized native root-use row; the
/// transition inventories come from the native receiver's retained beginning
/// and ending production-soil operands. Terminal ingress remains its own
/// M1-specific typed flux, never a synthetic generic runon row.
fn m1_v11_resource_custody(
    producer: &M1AcceptedSupportEvidence,
    receipt: &AcceptedSlabReceiptV1,
    beginning_owner_bytes: &std::collections::BTreeMap<String, Vec<u8>>,
    ending_owner_bytes: &std::collections::BTreeMap<String, Vec<u8>>,
    predecessors: &[openwepp_vegetation::v11::V11SharedResourceOwnerTransition],
) -> Result<
    (
        Vec<openwepp_vegetation::v11::V11ResourceDebit>,
        Vec<openwepp_vegetation::v11::V11AdmittedResourceFlux>,
        Vec<openwepp_vegetation::v11::V11SharedResourceOwnerTransition>,
        Vec<openwepp_vegetation::v11::V11CompleteOwnerCandidate>,
    ),
    M1ParentExecutionError,
> {
    use openwepp_vegetation::v11::{
        V11AdmittedResourceFlux, V11OwnerEnvelope, V11ResourceDebit, V11ResourceKey,
        V11SharedResourceKey, V11SharedResourceKind, V11SharedResourceOwnerTransition,
    };
    let native = producer
        .native_receiver
        .as_ref()
        .ok_or(resource_construction_error(
            "missing-native-receiver",
            openwepp_vegetation::v11::V11Error::ResourceFlux,
        ))?;
    let recomputed_native_receipt_proof = serde_json::to_vec(native.surface_ingress().receipts())
        .map(|bytes| Digest32::from_bytes(Sha256::digest(bytes).into()))
        .map_err(|_| {
            resource_construction_error(
                "native-receipt-proof-serialization",
                openwepp_vegetation::v11::V11Error::ResourceFlux,
            )
        })?;
    if recomputed_native_receipt_proof != producer.native_receipt_proof {
        return Err(resource_construction_error(
            "native-receipt-proof-mismatch",
            openwepp_vegetation::v11::V11Error::ResourceFlux,
        ));
    }
    // Both endpoint owner sets are part of the staged physical handoff.  Do
    // not accept a transition assembled against a substituted owner manifest.
    let manifest = [
        "vegetation",
        "snow",
        "land_surface_energy",
        "surface_liquid",
        "hydrology",
        "bgc",
        "soil_thermal",
    ];
    if beginning_owner_bytes
        .keys()
        .map(String::as_str)
        .collect::<std::collections::BTreeSet<_>>()
        != manifest.into_iter().collect()
        || ending_owner_bytes
            .keys()
            .map(String::as_str)
            .collect::<std::collections::BTreeSet<_>>()
            != manifest.into_iter().collect()
        || beginning_owner_bytes.values().any(Vec::is_empty)
        || ending_owner_bytes.values().any(Vec::is_empty)
    {
        return Err(resource_construction_error(
            "owner-manifest",
            openwepp_vegetation::v11::V11Error::ResourceOwnerCandidate,
        ));
    }
    let actual_lse_owner = serde_json::from_slice::<
        openwepp_land_surface_energy::LandSurfaceEnergyState,
    >(beginning_owner_bytes.get("land_surface_energy").ok_or(
        resource_construction_error(
            "lse-owner-bytes",
            openwepp_vegetation::v11::V11Error::ResourceOwnerCandidate,
        ),
    )?)
    .map_err(|_| {
        resource_construction_error(
            "lse-owner-deserialize",
            openwepp_vegetation::v11::V11Error::ResourceOwnerCandidate,
        )
    })?
    .owner_id;
    let occupancy = producer
        .m1_candidate
        .beginning()
        .reservoirs()
        .iter()
        .map(|(occupancy_id, _)| occupancy_id.clone())
        .collect::<std::collections::BTreeSet<_>>();
    let mut requests = native
        .arbitration()
        .requests
        .iter()
        .map(|value| (&value.key, value))
        .collect::<std::collections::BTreeMap<_, _>>();
    let mut authorizations = native
        .arbitration()
        .authorizations
        .iter()
        .map(|value| (&value.key, value))
        .collect::<std::collections::BTreeMap<_, _>>();
    if requests.len() != native.arbitration().requests.len()
        || authorizations.len() != native.arbitration().authorizations.len()
        || requests.len() != authorizations.len()
        || requests.len() != native.finalized_uses().len()
    {
        return Err(resource_construction_error(
            "native-request-authorization-shape",
            openwepp_vegetation::v11::V11Error::ResourceDebit,
        ));
    }

    // The receiver closure begins after root debits.  Bind each exact OFE/layer
    // to the preserved real-hydrology adapters instead, including their lane ID.
    let mut water_inventory = std::collections::BTreeMap::new();
    for ofe in &native.receiver_closure_operands().production_soil {
        for layer in &ofe.ordered_layers {
            let amount =
                |owner: &crate::vegetation_real_hydrology_shadow::RealHydrologyShadowAdapter| {
                    owner
                        .layer_facts()
                        .values()
                        .find(|fact| {
                            fact.source.ofe_lane.lane_index == ofe.production_lane_index
                                && fact.source.ofe_lane.lane_id == ofe.production_lane_id
                                && fact.source.layer_id == layer.layer_id
                        })
                        .map(|fact| fact.liquid_supply_kg_m2)
                };
            if water_inventory
                .insert(
                    (
                        ofe.ofe_id.as_str().to_owned(),
                        layer.layer_id.as_str().to_owned(),
                    ),
                    (
                        amount(&producer.beginning_hydrology).ok_or(
                            resource_construction_error(
                                "water-beginning-inventory",
                                openwepp_vegetation::v11::V11Error::ResourceDebit,
                            ),
                        )?,
                        amount(&producer.ending_hydrology).ok_or(resource_construction_error(
                            "water-ending-inventory",
                            openwepp_vegetation::v11::V11Error::ResourceDebit,
                        ))?,
                    ),
                )
                .is_some()
            {
                return Err(resource_construction_error(
                    "water-inventory-source-bijection",
                    openwepp_vegetation::v11::V11Error::ResourceDebit,
                ));
            }
        }
    }
    let mut debits = Vec::new();
    // Preserve the native, keyed finalized-use ordering used by the real
    // hydrology owner to aggregate each source before its one depth update.
    let mut native_root_uses = std::collections::BTreeMap::<
        crate::vegetation_real_hydrology_shadow::RealHydrologySourceKey,
        std::collections::BTreeMap<openwepp_land_surface_energy::GroundWaterKey, f64>,
    >::new();
    for used in native.finalized_uses() {
        let request = requests
            .remove(&used.key)
            .ok_or(resource_construction_error(
                "native-request-missing",
                openwepp_vegetation::v11::V11Error::ResourceDebit,
            ))?;
        let authorization = authorizations
            .remove(&used.key)
            .ok_or(resource_construction_error(
                "native-authorization-missing",
                openwepp_vegetation::v11::V11Error::ResourceDebit,
            ))?;
        let (Some(component), Some(layer)) = (
            used.key.occupancy_id.as_ref(),
            used.key.soil_layer_id.as_ref(),
        ) else {
            // Native ground-surface rows are genuine zero protocol rows. They
            // are authenticated and consumed here, but never become a root
            // debit because they have no root/layer resource identity.
            if used.key.requesting_component
                != openwepp_land_surface_energy::RequestingComponent::GroundSurface
                || used.key.requesting_owner_id != actual_lse_owner
                || used.key.occupancy_id.is_some()
                || used.key.soil_layer_id.is_some()
                || used.key.surface_id.is_none()
                || used.key.surface_class.is_none()
                || used.key.source_tile_id.as_ref() != Some(&used.key.requesting_tile_id)
                || used.key.source_id.as_str().is_empty()
                || used.key.source_type
                    == openwepp_land_surface_energy::WaterSourceType::SoilLayerLiquid
                || used.key.validate(native.transaction_id()).is_err()
                || request.amount_kg_m2_stand_ground.to_bits() != 0.0_f64.to_bits()
                || authorization.amount_kg_m2_stand_ground.to_bits() != 0.0_f64.to_bits()
                || authorization.reason
                    != openwepp_land_surface_energy::WaterAuthorizationReason::ZeroSupply
                || used.amount_kg_m2_stand_ground.to_bits() != 0.0_f64.to_bits()
            {
                return Err(resource_construction_error(
                    "zero-ground-shape-identity-bijection-authorization",
                    openwepp_vegetation::v11::V11Error::ResourceDebit,
                ));
            }
            continue;
        };
        if used.key.requesting_component
            != openwepp_land_surface_energy::RequestingComponent::VegetationRoot
            || used.key.validate(native.transaction_id()).is_err()
            || !occupancy.contains(component.as_str())
            || !water_inventory.contains_key(&(
                used.key.ofe_id.as_str().to_owned(),
                layer.as_str().to_owned(),
            ))
        {
            return Err(resource_construction_error(
                "root-use-identity-and-water-inventory",
                openwepp_vegetation::v11::V11Error::ResourceDebit,
            ));
        }
        let (stratum, tile) =
            component
                .as_str()
                .split_once("::")
                .ok_or(resource_construction_error(
                    "root-occupancy-identity",
                    openwepp_vegetation::v11::V11Error::ResourceDebit,
                ))?;
        let water_key = openwepp_kernel_contract::WaterResourceKey {
            occupancy_id: openwepp_kernel_contract::OccupancyId {
                stratum_id: openwepp_kernel_contract::StratumId::try_new(stratum.to_owned())
                    .map_err(|_| {
                        resource_construction_error(
                            "root-stratum-identity",
                            openwepp_vegetation::v11::V11Error::ResourceDebit,
                        )
                    })?,
                tile_id: openwepp_kernel_contract::TileId::try_new(tile.to_owned()).map_err(
                    |_| {
                        resource_construction_error(
                            "root-tile-identity",
                            openwepp_vegetation::v11::V11Error::ResourceDebit,
                        )
                    },
                )?,
            },
            layer_id: layer.clone(),
        };
        let mut source_lanes = native
            .receiver_closure_operands()
            .production_soil
            .iter()
            .filter(|ofe| ofe.ofe_id == used.key.ofe_id);
        let source_lane = source_lanes.next().ok_or(resource_construction_error(
            "native-root-use-source-lane",
            openwepp_vegetation::v11::V11Error::ResourceDebit,
        ))?;
        if source_lanes.next().is_some() {
            return Err(resource_construction_error(
                "native-root-use-source-bijection",
                openwepp_vegetation::v11::V11Error::ResourceDebit,
            ));
        }
        retain_native_root_use(
            native_root_uses
                .entry(
                    crate::vegetation_real_hydrology_shadow::RealHydrologySourceKey {
                        ofe_lane: crate::vegetation_real_hydrology_shadow::RealHydrologyOfeLaneId {
                            lane_index: source_lane.production_lane_index,
                            lane_id: source_lane.production_lane_id,
                        },
                        layer_id: layer.clone(),
                    },
                )
                .or_default(),
            used.key.clone(),
            used.amount_kg_m2_stand_ground,
        )
        .map_err(|error| resource_construction_error("native-root-use-order-bijection", error))?;
        debits.push(
            V11ResourceDebit::new(V11ResourceDebit {
                receipt_id: Digest32::zero(),
                parent_transaction_id: receipt.parent_transaction_id(),
                segment_id: receipt.segment_id(),
                accepted_slab_id: receipt.slab_id(),
                support: receipt.support(),
                owner_id: "hydrology".to_owned(),
                resource_key: V11ResourceKey::Water(water_key),
                ofe_id: used.key.ofe_id.as_str().to_owned(),
                tile_id: tile.to_owned(),
                occupancy_id: component.as_str().to_owned(),
                layer_id: layer.as_str().to_owned(),
                // This is the canonical source label for the exact RealHydrologySourceKey
                // above; no source is inferred from closure liquid depths.
                source_id: "soil_water".to_owned(),
                amount_basis: "kg_m2_stand_ground".to_owned(),
                request: request.amount_kg_m2_stand_ground,
                authorization: authorization.amount_kg_m2_stand_ground,
                final_use: used.amount_kg_m2_stand_ground,
            })
            .map_err(M1ParentExecutionError::Resource)?,
        );
    }
    if !requests.is_empty() || !authorizations.is_empty() {
        return Err(resource_construction_error(
            "native-request-authorization-bijection",
            openwepp_vegetation::v11::V11Error::ResourceDebit,
        ));
    }

    let (nitrogen_requests, nitrogen_authorizations, nitrogen_uses) =
        producer.m1_candidate.nitrogen_protocol();
    let bgc_ofe_id = native
        .receiver_closure_operands()
        .production_soil
        .first()
        .filter(|first| {
            native
                .receiver_closure_operands()
                .production_soil
                .iter()
                .all(|value| value.ofe_id == first.ofe_id)
        })
        .map(|value| value.ofe_id.as_str().to_owned())
        .ok_or(resource_construction_error(
            "nitrogen-scope-ofe-identity",
            openwepp_vegetation::v11::V11Error::ResourceDebit,
        ))?;
    for used in nitrogen_uses {
        let request = nitrogen_requests
            .iter()
            .find(|value| value.owner_id == used.owner_id && value.key == used.key)
            .ok_or(resource_construction_error(
                "strict-nitrogen-request-identity",
                openwepp_vegetation::v11::V11Error::ResourceDebit,
            ))?;
        let authorization = nitrogen_authorizations
            .iter()
            .find(|value| value.owner_id == used.owner_id && value.key == used.key)
            .ok_or(resource_construction_error(
                "strict-nitrogen-authorization-identity",
                openwepp_vegetation::v11::V11Error::ResourceDebit,
            ))?;
        let layer = used.key.layer_id.as_str();
        if producer
            .bgc_candidate
            .beginning()
            .layers
            .get(layer)
            .is_none()
            || producer.bgc_candidate.ending().layers.get(layer).is_none()
        {
            return Err(resource_construction_error(
                "bgc-beginning-ending-inventory",
                openwepp_vegetation::v11::V11Error::ResourceDebit,
            ));
        }
        let source_id = match used.key.species {
            openwepp_kernel_contract::MineralNitrogenSpecies::Ammonium => "nh4",
            openwepp_kernel_contract::MineralNitrogenSpecies::Nitrate => "no3",
        };
        debits.push(
            V11ResourceDebit::new(V11ResourceDebit {
                receipt_id: Digest32::zero(),
                parent_transaction_id: receipt.parent_transaction_id(),
                segment_id: receipt.segment_id(),
                accepted_slab_id: receipt.slab_id(),
                support: receipt.support(),
                owner_id: "bgc".to_owned(),
                resource_key: V11ResourceKey::MineralNitrogen(used.key.clone()),
                ofe_id: bgc_ofe_id.clone(),
                tile_id: "stratum_scoped".to_owned(),
                occupancy_id: used.owner_id.as_str().to_owned(),
                layer_id: layer.to_owned(),
                source_id: source_id.to_owned(),
                amount_basis: "kg_n_m2".to_owned(),
                request: request.amount,
                authorization: authorization.amount,
                final_use: used.amount,
            })
            .map_err(M1ParentExecutionError::Resource)?,
        );
    }
    debits.sort_by(
        |left, right| match (&left.resource_key, &right.resource_key) {
            (V11ResourceKey::MineralNitrogen(_), V11ResourceKey::MineralNitrogen(_)) => left
                .occupancy_id
                .cmp(&right.occupancy_id)
                .then_with(|| left.layer_id.cmp(&right.layer_id))
                .then_with(|| left.resource_key.cmp(&right.resource_key)),
            (V11ResourceKey::MineralNitrogen(_), _) => std::cmp::Ordering::Greater,
            (_, V11ResourceKey::MineralNitrogen(_)) => std::cmp::Ordering::Less,
            _ => left.receipt_id.cmp(&right.receipt_id),
        },
    );

    let shared_key = |debit: &V11ResourceDebit| V11SharedResourceKey {
        resource: match &debit.resource_key {
            V11ResourceKey::Water(_) => V11SharedResourceKind::Water,
            V11ResourceKey::MineralNitrogen(value) => match value.species {
                openwepp_kernel_contract::MineralNitrogenSpecies::Ammonium => {
                    V11SharedResourceKind::Ammonium
                }
                openwepp_kernel_contract::MineralNitrogenSpecies::Nitrate => {
                    V11SharedResourceKind::Nitrate
                }
            },
        },
        owner_id: debit.owner_id.clone(),
        ofe_id: debit.ofe_id.clone(),
        layer_id: debit.layer_id.clone(),
        source_id: debit.source_id.clone(),
        amount_basis: debit.amount_basis.clone(),
    };
    let debit_keys = debits
        .iter()
        .map(|d| (shared_key(d), d.receipt_id))
        .collect::<std::collections::BTreeMap<_, _>>();
    // Each closure layer retains the actual post-root/pre-ingress and ending
    // liquid depths. That is the native per-layer ingress observation; using
    // it avoids allocating a parcel receipt across layers by a balancing rule.
    let mut fluxes = Vec::new();
    let mut observed_infiltration = 0.0;
    let mut observed_infiltration_by_lane = std::collections::BTreeMap::new();
    for ofe in &native.receiver_closure_operands().production_soil {
        for layer in &ofe.ordered_layers {
            let amount = (layer.ending_liquid_m - layer.beginning_liquid_m) * 1_000.0;
            if amount < 0.0 || !amount.is_finite() {
                return Err(resource_construction_error(
                    "terminal-ingress-amount",
                    openwepp_vegetation::v11::V11Error::ResourceFlux,
                ));
            }
            if amount.to_bits() == 0.0_f64.to_bits() {
                continue;
            }
            let key = V11SharedResourceKey {
                resource: V11SharedResourceKind::Water,
                owner_id: "hydrology".to_owned(),
                ofe_id: ofe.ofe_id.as_str().to_owned(),
                layer_id: layer.layer_id.as_str().to_owned(),
                source_id: "soil_water".to_owned(),
                amount_basis: "kg_m2_stand_ground".to_owned(),
            };
            if !debit_keys.contains_key(&key) {
                return Err(resource_construction_error(
                    "terminal-ingress-missing-debit-key",
                    openwepp_vegetation::v11::V11Error::ResourceFlux,
                ));
            }
            observed_infiltration += amount;
            *observed_infiltration_by_lane
                .entry((
                    ofe.ofe_id.as_str().to_owned(),
                    ofe.production_lane_index,
                    ofe.production_lane_id,
                ))
                .or_insert(0.0) += amount;
            fluxes.push(
                V11AdmittedResourceFlux::new_m1_terminal_receiver(
                    V11AdmittedResourceFlux {
                        receipt_id: Digest32::zero(),
                        parent_transaction_id: receipt.parent_transaction_id(),
                        segment_id: receipt.segment_id(),
                        accepted_slab_id: receipt.slab_id(),
                        support: receipt.support(),
                        // Native terminal ingress is not generic V11 runon.
                        flux_class: "terminal_receiver".to_owned(),
                        direction: "source_to_receiver".to_owned(),
                        source_owner_id: "surface_liquid".to_owned(),
                        receiver_owner_id: "hydrology".to_owned(),
                        shared_resource_key: key,
                        amount,
                    },
                    producer.native_receipt_proof,
                )
                .map_err(M1ParentExecutionError::Resource)?,
            );
        }
    }
    // Prove every admitted M1 flux comes from the concrete native terminal
    // receipt, including recipient lane and ordered soil lineage. The V11
    // flux itself deliberately remains schema-compatible and does not invent
    // an extra persisted receipt field.
    for row in native.surface_ingress().receipts() {
        if row.kind != crate::DirectSurfaceLiquidParcelKind::TerminalReceiver
            || row.transaction_id != native.transaction_id()
        {
            continue;
        }
        let crate::DirectSurfaceLiquidReceiptRecipient::SoilInfiltration {
            ofe_id,
            production_lane_index,
            production_lane_id,
            ordered_soil_layer_ids,
            soil_thermal_layer_id,
        } = &row.recipient
        else {
            continue;
        };
        let closure = native
            .receiver_closure_operands()
            .production_soil
            .iter()
            .find(|value| {
                value.ofe_id == *ofe_id
                    && value.production_lane_index == *production_lane_index
                    && value.production_lane_id == *production_lane_id
            })
            .ok_or(resource_construction_error(
                "terminal-receipt-lane-closure",
                openwepp_vegetation::v11::V11Error::ResourceFlux,
            ))?;
        if row.basis_ofe_id != *ofe_id
            || row.parcel_id.is_empty()
            || row.source_parcel_id.is_empty()
            || row.disposition != crate::DirectSurfaceLiquidReceiptDisposition::Infiltration
            || ordered_soil_layer_ids
                != &closure
                    .ordered_layers
                    .iter()
                    .map(|layer| layer.layer_id.clone())
                    .collect::<Vec<_>>()
            || !ordered_soil_layer_ids.contains(soil_thermal_layer_id)
        {
            return Err(resource_construction_error(
                "terminal-receipt-shape-identity",
                openwepp_vegetation::v11::V11Error::ResourceFlux,
            ));
        }
    }
    let mut admitted_infiltration_by_lane = std::collections::BTreeMap::new();
    let admitted_infiltration = native
        .surface_ingress()
        .receipts()
        .iter()
        .filter_map(|row| {
            let crate::DirectSurfaceLiquidReceiptRecipient::SoilInfiltration {
                ofe_id,
                production_lane_index,
                production_lane_id,
                ..
            } = &row.recipient
            else {
                return None;
            };
            (row.kind == crate::DirectSurfaceLiquidParcelKind::TerminalReceiver
                && row.transaction_id == native.transaction_id())
            .then(|| {
                *admitted_infiltration_by_lane
                    .entry((
                        ofe_id.as_str().to_owned(),
                        *production_lane_index,
                        *production_lane_id,
                    ))
                    .or_insert(0.0) += row.mass_kg_m2_basis_ofe_ground;
                row.mass_kg_m2_basis_ofe_ground
            })
        })
        .try_fold(0.0, |sum, amount| {
            let next = sum + amount;
            next.is_finite().then_some(next)
        })
        .ok_or(resource_construction_error(
            "terminal-receipt-amount",
            openwepp_vegetation::v11::V11Error::ResourceFlux,
        ))?;
    if observed_infiltration.to_bits() != admitted_infiltration.to_bits() {
        return Err(resource_construction_error(
            "terminal-receipt-total-amount",
            openwepp_vegetation::v11::V11Error::ResourceFlux,
        ));
    }
    if observed_infiltration_by_lane.len() != admitted_infiltration_by_lane.len()
        || observed_infiltration_by_lane
            .iter()
            .any(|(lane, observed)| {
                admitted_infiltration_by_lane
                    .get(lane)
                    .map_or(true, |admitted| observed.to_bits() != admitted.to_bits())
            })
    {
        return Err(resource_construction_error(
            "terminal-receipt-lane-amount",
            openwepp_vegetation::v11::V11Error::ResourceFlux,
        ));
    }
    fluxes.sort_by_key(|value| value.receipt_id);
    let owners = ending_owner_bytes
        .iter()
        .map(|(id, bytes)| {
            V11OwnerEnvelope::try_new(id.clone(), bytes.clone()).map(|value| (id.clone(), value))
        })
        .collect::<Result<std::collections::BTreeMap<_, _>, _>>()
        .map_err(M1ParentExecutionError::Resource)?;
    let mut debit_ids = std::collections::BTreeMap::<V11SharedResourceKey, Vec<Digest32>>::new();
    for debit in &debits {
        debit_ids
            .entry(shared_key(debit))
            .or_default()
            .push(debit.receipt_id);
    }
    let mut flux_ids = std::collections::BTreeMap::<V11SharedResourceKey, Vec<Digest32>>::new();
    for flux in &fluxes {
        flux_ids
            .entry(flux.shared_resource_key.clone())
            .or_default()
            .push(flux.receipt_id);
    }
    let mut transitions = Vec::new();
    for (key, mut ids) in debit_ids {
        if key.owner_id != "bgc" {
            ids.sort();
        }
        let (beginning_amount, ending_amount) = match key.resource {
            V11SharedResourceKind::Water => water_inventory
                .get(&(key.ofe_id.clone(), key.layer_id.clone()))
                .copied()
                .ok_or(resource_construction_error(
                    "water-beginning-ending-inventory",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ))?,
            V11SharedResourceKind::Ammonium | V11SharedResourceKind::Nitrate => {
                let beginning = producer
                    .bgc_candidate
                    .beginning()
                    .layers
                    .get(&key.layer_id)
                    .ok_or(resource_construction_error(
                        "bgc-beginning-inventory",
                        openwepp_vegetation::v11::V11Error::ResourceCustody,
                    ))?;
                let ending = producer
                    .bgc_candidate
                    .ending()
                    .layers
                    .get(&key.layer_id)
                    .ok_or(resource_construction_error(
                        "bgc-ending-inventory",
                        openwepp_vegetation::v11::V11Error::ResourceCustody,
                    ))?;
                match key.resource {
                    V11SharedResourceKind::Ammonium => (beginning.ammonium_n, ending.ammonium_n),
                    V11SharedResourceKind::Nitrate => (beginning.nitrate_n, ending.nitrate_n),
                    V11SharedResourceKind::Water => unreachable!(),
                }
            }
        };
        transitions.push(
            V11SharedResourceOwnerTransition::new(V11SharedResourceOwnerTransition {
                transition_id: Digest32::zero(),
                parent_transaction_id: receipt.parent_transaction_id(),
                segment_id: receipt.segment_id(),
                accepted_slab_id: receipt.slab_id(),
                support: receipt.support(),
                owner_candidate_sha256: owners
                    .get(&key.owner_id)
                    .ok_or(resource_construction_error(
                        "transition-owner-candidate",
                        openwepp_vegetation::v11::V11Error::ResourceOwnerCandidate,
                    ))?
                    .state_sha256,
                shared_resource_key: key.clone(),
                beginning_amount,
                ending_amount,
                debit_receipt_ids: ids,
                admitted_flux_receipt_ids: flux_ids.remove(&key).unwrap_or_default(),
            })
            .map_err(M1ParentExecutionError::Resource)?,
        );
    }
    if !flux_ids.is_empty() {
        return Err(resource_construction_error(
            "unmatched-flux-key",
            openwepp_vegetation::v11::V11Error::ResourceCustody,
        ));
    }
    // M1 strengthens generic V11 custody: every physical water ending is
    // reconstructed from the native owner's keyed debit aggregate and raw
    // depth operands.  Do not subtract individually rounded kg wire values.
    for transition in &transitions {
        if transition.shared_resource_key.resource == V11SharedResourceKind::Water {
            let ordered_debit_amount_bits = transition
                .debit_receipt_ids
                .iter()
                .map(|id| {
                    debits
                        .iter()
                        .find(|debit| debit.receipt_id == *id)
                        .map(|debit| debit.final_use.to_bits())
                        .ok_or(resource_construction_error(
                            "water-closure-missing-debit-id",
                            openwepp_vegetation::v11::V11Error::ResourceCustody,
                        ))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let ordered_ingress_amount_bits = transition
                .admitted_flux_receipt_ids
                .iter()
                .map(|id| {
                    fluxes
                        .iter()
                        .find(|flux| flux.receipt_id == *id)
                        .map(|flux| flux.amount.to_bits())
                        .ok_or(resource_construction_error(
                            "water-closure-missing-flux-id",
                            openwepp_vegetation::v11::V11Error::ResourceCustody,
                        ))
                })
                .collect::<Result<Vec<_>, _>>()?;
            let mut closure_lanes = native
                .receiver_closure_operands()
                .production_soil
                .iter()
                .filter(|lane| lane.ofe_id.as_str() == transition.shared_resource_key.ofe_id);
            let closure_lane = closure_lanes.next().ok_or(resource_construction_error(
                "water-closure-native-lane",
                openwepp_vegetation::v11::V11Error::ResourceCustody,
            ))?;
            if closure_lanes.next().is_some() {
                return Err(resource_construction_error(
                    "water-closure-native-source-bijection",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ));
            }
            let closure_layer = closure_lane
                .ordered_layers
                .iter()
                .find(|layer| layer.layer_id.as_str() == transition.shared_resource_key.layer_id)
                .ok_or(resource_construction_error(
                    "water-closure-native-layer",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ))?;
            let source_fact =
                |owner: &crate::vegetation_real_hydrology_shadow::RealHydrologyShadowAdapter| {
                    owner
                        .layer_facts()
                        .values()
                        .find(|fact| {
                            fact.source.ofe_lane.lane_index == closure_lane.production_lane_index
                                && fact.source.ofe_lane.lane_id == closure_lane.production_lane_id
                                && fact.source.layer_id == closure_layer.layer_id
                        })
                        .cloned()
                };
            let beginning_fact =
                source_fact(&producer.beginning_hydrology).ok_or(resource_construction_error(
                    "water-closure-beginning-source",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ))?;
            let ending_fact =
                source_fact(&producer.ending_hydrology).ok_or(resource_construction_error(
                    "water-closure-ending-source",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ))?;
            let beginning_lane = producer
                .beginning_hydrology
                .beginning_frame()
                .lanes
                .get(beginning_fact.source.ofe_lane.lane_index)
                .ok_or(resource_construction_error(
                    "water-closure-beginning-lane",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ))?;
            if beginning_lane.lane_id != beginning_fact.source.ofe_lane.lane_id {
                return Err(resource_construction_error(
                    "water-closure-beginning-source-identity",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ));
            }
            #[cfg(test)]
            let beginning_layer_ids = producer
                .beginning_hydrology
                .layer_maps()
                .iter()
                .find(|mapping| {
                    mapping.ofe_lane.lane_index == beginning_fact.source.ofe_lane.lane_index
                        && mapping.ofe_lane.lane_id == beginning_fact.source.ofe_lane.lane_id
                })
                .ok_or(resource_construction_error(
                    "water-closure-beginning-layer-map",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ))?
                .layer_ids
                .iter()
                .map(|layer_id| layer_id.as_str().to_owned())
                .collect::<Vec<_>>();
            let beginning_layer_index = producer
                .beginning_hydrology
                .layer_index_for_source(&beginning_fact.source)
                .map_err(|_| {
                    resource_construction_error(
                        "water-closure-beginning-layer-index",
                        openwepp_vegetation::v11::V11Error::ResourceCustody,
                    )
                })?;
            let beginning_layer = beginning_lane
                .subsurface_layers
                .get(beginning_layer_index)
                .ok_or(resource_construction_error(
                    "water-closure-beginning-layer",
                    openwepp_vegetation::v11::V11Error::ResourceCustody,
                ))?;
            let native_uses =
                native_root_uses
                    .get(&beginning_fact.source)
                    .ok_or(resource_construction_error(
                        "water-closure-native-use-bijection",
                        openwepp_vegetation::v11::V11Error::ResourceCustody,
                    ))?;
            let (canonical_debit_kg_m2, post_root_liquid_depth_m) =
                canonical_native_root_ending_depth(
                    beginning_layer,
                    beginning_fact.liquid_supply_kg_m2,
                    native_uses,
                )
                .map_err(|error| {
                    resource_construction_error("water-closure-native-root-update", error)
                })?;
            // Retain raw operands for the test-owned replay before the
            // custody predicate below.  This observer must never receive its
            // expected post-root state from that predicate.
            let zero_ingress = transition.admitted_flux_receipt_ids.is_empty();
            #[cfg(test)]
            M1_RAW_WATER_ORACLE.with(|values| {
                let ordered_ingress = native
                    .surface_ingress()
                    .receipts()
                    .iter()
                    .filter_map(|row| match &row.recipient {
                        crate::DirectSurfaceLiquidReceiptRecipient::SoilInfiltration {
                            ofe_id,
                            production_lane_index,
                            production_lane_id,
                            ..
                        } if *ofe_id == closure_lane.ofe_id
                            && *production_lane_index == closure_lane.production_lane_index
                            && *production_lane_id == closure_lane.production_lane_id
                            && row.kind
                                == crate::DirectSurfaceLiquidParcelKind::TerminalReceiver
                            && row.transaction_id == native.transaction_id() =>
                        {
                            Some(row.clone())
                        }
                        _ => None,
                    })
                    .collect();
                values.borrow_mut().push(M1RawWaterOracle {
                    key: transition.shared_resource_key.clone(),
                    lane_index: closure_lane.production_lane_index,
                    lane_id: closure_lane.production_lane_id,
                    layer_index: beginning_layer_index,
                    beginning_layer_ids: beginning_layer_ids.clone(),
                    receiver_layer_ids: closure_lane
                        .ordered_layers
                        .iter()
                        .map(|layer| layer.layer_id.as_str().to_owned())
                        .collect(),
                    beginning_lane: beginning_lane.subsurface_layers.clone(),
                    receiver_beginning_lane_depth_bits: closure_lane
                        .ordered_layers
                        .iter()
                        .map(|layer| layer.beginning_liquid_m.to_bits())
                        .collect(),
                    ending_lane_depth_bits: closure_lane
                        .ordered_layers
                        .iter()
                        .map(|layer| layer.ending_liquid_m.to_bits())
                        .collect(),
                    beginning_supply_kg_m2_bits: beginning_fact.liquid_supply_kg_m2.to_bits(),
                    native_uses: native_uses.clone(),
                    ordered_ingress,
                    tillage_depth_m_bits: closure_lane.tillage_depth_m.to_bits(),
                    infiltration_m_bits: closure_lane.infiltration_m.to_bits(),
                    receiver_beginning_depth_bits: closure_layer.beginning_liquid_m.to_bits(),
                    ending_depth_bits: ending_fact.liquid_water_depth_m.to_bits(),
                });
            });
            if !native_water_custody_bits_match(
                post_root_liquid_depth_m,
                closure_layer.beginning_liquid_m,
                ending_fact.liquid_water_depth_m,
                closure_layer.ending_liquid_m,
                transition.beginning_amount,
                beginning_fact.liquid_supply_kg_m2,
                transition.ending_amount,
                ending_fact.liquid_supply_kg_m2,
                zero_ingress,
            ) {
                return Err(M1ParentExecutionError::WaterClosure {
                    source: openwepp_vegetation::v11::V11Error::ResourceCustody,
                    ofe_id: transition.shared_resource_key.ofe_id.clone(),
                    layer_id: transition.shared_resource_key.layer_id.clone(),
                    beginning_amount_bits: transition.beginning_amount.to_bits(),
                    ending_amount_bits: transition.ending_amount.to_bits(),
                    beginning_liquid_depth_bits: beginning_fact.liquid_water_depth_m.to_bits(),
                    post_root_liquid_depth_bits: post_root_liquid_depth_m.to_bits(),
                    ending_liquid_depth_bits: ending_fact.liquid_water_depth_m.to_bits(),
                    canonical_root_debit_kg_m2_bits: canonical_debit_kg_m2.to_bits(),
                    ordered_debit_amount_bits,
                    ordered_ingress_amount_bits,
                });
            }
        }
    }
    if receipt.slab_ordinal() == 0 {
        if !predecessors.is_empty() {
            return Err(resource_construction_error(
                "initial-predecessor-presence",
                openwepp_vegetation::v11::V11Error::ResourceCustody,
            ));
        }
    } else if predecessors.len() != transitions.len()
        || predecessors
            .iter()
            .map(|t| &t.shared_resource_key)
            .collect::<std::collections::BTreeSet<_>>()
            != transitions
                .iter()
                .map(|t| &t.shared_resource_key)
                .collect::<std::collections::BTreeSet<_>>()
    {
        return Err(resource_construction_error(
            "predecessor-keyset-or-count",
            openwepp_vegetation::v11::V11Error::ResourceCustody,
        ));
    }
    let candidates =
        openwepp_vegetation::v11::build_complete_owner_candidates(receipt, &owners, &transitions)
            .map_err(M1ParentExecutionError::Resource)?;
    let configured_strata = producer
        .m1_configuration
        .strata
        .iter()
        .map(|s| s.stratum_id.as_str().to_owned())
        .collect();
    let expected_identities = producer
        .m1_configuration
        .strata
        .iter()
        .flat_map(|s| {
            s.root_layers.iter().flat_map(move |root| {
                [
                    openwepp_kernel_contract::MineralNitrogenSpecies::Ammonium,
                    openwepp_kernel_contract::MineralNitrogenSpecies::Nitrate,
                ]
                .into_iter()
                .map(move |species| {
                    (
                        s.stratum_id.as_str().to_owned(),
                        root.layer_id.as_str().to_owned(),
                        species,
                    )
                })
            })
        })
        .collect();
    let stratum_ofe_ids = producer
        .m1_configuration
        .strata
        .iter()
        .map(|s| (s.stratum_id.as_str().to_owned(), bgc_ofe_id.clone()))
        .collect();
    let nitrogen_scope = openwepp_vegetation::v11::V11ResourceCustodyNitrogenScope::try_new(
        configured_strata,
        expected_identities,
        stratum_ofe_ids,
    )
    .map_err(|error| resource_construction_error("nitrogen-scope", error))?;
    openwepp_vegetation::v11::validate_m1_terminal_receiver_resource_custody_with_nitrogen_scope(
        &nitrogen_scope,
        receipt.parent_transaction_id(),
        receipt.segment_id(),
        receipt.slab_id(),
        receipt.slab_ordinal(),
        receipt.support(),
        &debits,
        &fluxes,
        &transitions,
        &candidates,
        (!predecessors.is_empty()).then_some(predecessors),
        producer.native_receipt_proof,
    )
    .map_err(M1ParentExecutionError::Resource)?;
    Ok((debits, fluxes, transitions, candidates))
}

pub(super) fn actual_m1_caller_beginning_for_provider_controls()
-> Result<RealM1ProviderCaller, ProviderError> {
    actual_m1_caller_beginning_for_provider_cycle(0)
}
pub(super) fn actual_m1_caller_beginning_for_provider_cycle(
    cycle_ordinal: u32,
) -> Result<RealM1ProviderCaller, ProviderError> {
    let p = payload(usize::try_from(cycle_ordinal).map_err(|_| ProviderError)?)?;
    let rows = p["cycle"]["initial_phase_records"]
        .as_array()
        .ok_or(ProviderError)?;
    let reservoirs = rows
        .iter()
        .map(|r| {
            Ok((
                r["occupancy_id"].as_str().ok_or(ProviderError)?.to_owned(),
                f64::from_bits(
                    u64::from_str_radix(
                        r["mass_kg_m2_tile_ground"].as_str().ok_or(ProviderError)?,
                        16,
                    )
                    .map_err(|_| ProviderError)?,
                ),
                f64::from_bits(
                    u64::from_str_radix(
                        r["enthalpy_j_m2_tile_ground"]
                            .as_str()
                            .ok_or(ProviderError)?,
                        16,
                    )
                    .map_err(|_| ProviderError)?,
                ),
            ))
        })
        .collect::<Result<Vec<_>, ProviderError>>()?;
    Ok(RealM1ProviderCaller(
        super::M1CallerState::beginning_from_provider_reservoirs(
            &super::endpoint_fixture(),
            reservoirs,
        )
        .map_err(|_| ProviderError)?,
        None,
        None,
    ))
}
pub(super) fn admit_payload_into_actual_caller(
    bytes: &[u8],
    adapter: &FixedSequenceSourceAdapter,
    caller: &mut RealM1ProviderCaller,
) -> Result<(), ProviderError> {
    let admitted = admit_fixed_sequence_provider_for_parent(
        bytes,
        adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )?;
    admitted.validate_actual_caller_initial(&caller.0)?;
    Ok(())
}
impl AdmittedFixedSequenceProvider {
    fn cycle_ordinal(&self) -> Result<u32, ProviderError> {
        u32::try_from(
            self.payload["cycle"]["ordinal"]
                .as_u64()
                .ok_or(ProviderError)?,
        )
        .map_err(|_| ProviderError)
    }
    fn expected_initial_phase(
        &self,
    ) -> Result<std::collections::BTreeMap<String, (u64, u64)>, ProviderError> {
        self.payload["cycle"]["initial_phase_records"]
            .as_array()
            .ok_or(ProviderError)?
            .iter()
            .map(|row| {
                Ok((
                    row["occupancy_id"]
                        .as_str()
                        .ok_or(ProviderError)?
                        .to_owned(),
                    (
                        u64::from_str_radix(
                            row["mass_kg_m2_tile_ground"]
                                .as_str()
                                .ok_or(ProviderError)?,
                            16,
                        )
                        .map_err(|_| ProviderError)?,
                        u64::from_str_radix(
                            row["enthalpy_j_m2_tile_ground"]
                                .as_str()
                                .ok_or(ProviderError)?,
                            16,
                        )
                        .map_err(|_| ProviderError)?,
                    ),
                ))
            })
            .collect()
    }
    fn validate_actual_caller_initial(
        &self,
        caller: &super::M1CallerState,
    ) -> Result<(), ProviderError> {
        // This deliberately uses the real caller's M1 owner reservoirs.  It
        // is a non-mutating early admission check; parent admission repeats
        // the check atomically at the clock installation seam.
        let expected = self.expected_initial_phase()?;
        // The receiver owns this comparison over its typed, actual M1
        // reservoirs; provider payload admission does not manufacture a
        // digest-only owner substitute.
        caller
            .provider_matches_initial_phase(&expected)
            .then_some(())
            .ok_or(ProviderError)
    }
    pub(super) fn admit_parent_into_actual_caller(
        &self,
        caller: &mut RealM1ProviderCaller,
        parent: u32,
        receipts: &[[u8; 32]],
    ) -> Result<(), ProviderError> {
        self.admit_parent_for_caller(parent, receipts, &mut FixedSequenceAdmissionAudit::new())?;
        let bytes = caller
            .0
            .provider_seven_beginning_owner_bytes()
            .map_err(|_| ProviderError)?;
        const OWNER_IDS: [&str; 7] = [
            "bgc",
            "hydrology",
            "land_surface_energy",
            "snow",
            "soil_thermal",
            "surface_liquid",
            "vegetation",
        ];
        if bytes.len() != OWNER_IDS.len() || bytes.keys().map(String::as_str).ne(OWNER_IDS) {
            return Err(ProviderError);
        }
        let owners = bytes
            .into_iter()
            .map(|(id, state)| OwnerState::new(id, state).map_err(|_| ProviderError))
            .collect::<Result<Vec<_>, _>>()?;
        let digest = complete_owner_set_digest(&owners).map_err(|_| ProviderError)?;
        let support = TimeSupport::new(
            ModelTimeNs::new(u128::from(parent) * 1_800_000_000_000),
            ModelTimeNs::new(u128::from(parent + 1) * 1_800_000_000_000),
        )
        .map_err(|_| ProviderError)?;
        let authority = ParentAuthorityV1::new(
            Digest32::from_bytes(self.run),
            Digest32::from_bytes(self.calendar),
            Digest32::from_bytes(self.parent_forcing_receipt(parent)?),
            u128::from(parent),
            support,
            digest,
        )
        .map_err(|_| ProviderError)?;
        let clock = CoupledClockStateV1::new(
            authority,
            owners,
            "OPENWEPP_COLD_M1_FIXED_SEQUENCE_PROVIDER_V1".to_owned(),
            vec![
                "bgc".to_owned(),
                "hydrology".to_owned(),
                "land_surface_energy".to_owned(),
                "soil_thermal".to_owned(),
                "surface_liquid".to_owned(),
                "vegetation".to_owned(),
            ],
            Digest32::from_bytes(self.payload_content_sha256),
            self.run.to_vec(),
        )
        .map_err(|_| ProviderError)?;
        caller
            .0
            .admit_fixed_sequence_parent_clock(
                clock,
                self.run,
                self.cycle_ordinal()?,
                parent,
                &self.expected_initial_phase()?,
            )
            .map_err(|_| ProviderError)
    }
}
