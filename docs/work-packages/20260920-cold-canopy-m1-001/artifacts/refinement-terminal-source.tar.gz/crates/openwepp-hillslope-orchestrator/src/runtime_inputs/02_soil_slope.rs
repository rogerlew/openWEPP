#[derive(Clone, Copy, Debug)]
struct Wb13ProfileSymbols {
    depth: f64,
    porosity_cap: f64,
    fc_store: f64,
    wp_store: f64,
}

#[derive(Clone, Copy, Debug)]
struct CorrectedLayerRuntimeSymbols {
    porosity: f64,
    cpm: f64,
    coca: f64,
    bulk_density_kg_m3: f64,
    thetfc: f64,
    thetdr: f64,
}

#[derive(Clone, Copy, Debug)]
struct PrimaryWb11LayerRuntimeSymbols {
    solthk_m: f64,
    dg_m: f64,
    porosity: f64,
    cpm: f64,
    coca: f64,
    bulk_density_kg_m3: f64,
    thetfc: f64,
    thetdr: f64,
    ssc_m_s: f64,
    lateral_ssh_m_s: f64,
}

/// Typed parsed-soil projection for the primary WB11/WB18/WB19 runtime
/// layer seed. This is the non-symbol authority used by direct setup; the
/// legacy runtime-surface writer is an adapter over the same projection.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TypedSoilWb11LayerRuntimeProjection {
    pub solthk_m: f64,
    pub dg_m: f64,
    pub porosity: f64,
    pub cpm: f64,
    pub coca: f64,
    pub bulk_density_kg_m3: f64,
    pub thetfc: f64,
    pub thetdr: f64,
    pub ssc_m_s: f64,
    pub lateral_ssh_m_s: f64,
}

/// Typed parser-layer profile publication lineage used by WB13/profile
/// authority guards. This is separate from the WB11 seed grid because the
/// legacy profile surface exposed parser-layer corrected `dg`/`thetfc`
/// symbols, while WB11/WB18/WB19 consume the normalized seed grid.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TypedSoilProfilePublicationLayerProjection {
    pub dg_m: f64,
    pub thetfc: f64,
}

/// Typed parser-layer profile publication projection.
#[derive(Clone, Debug, PartialEq)]
pub struct TypedSoilProfilePublicationProjection {
    pub nsl: usize,
    pub layers: Vec<TypedSoilProfilePublicationLayerProjection>,
}

/// Typed parsed-soil projection for the static WB11 seed authority.
#[derive(Clone, Debug, PartialEq)]
pub struct TypedSoilWb11RuntimeProjection {
    pub nsl: usize,
    pub sat: f64,
    pub solwpv: f64,
    pub salb: f64,
    pub solthk_m: f64,
    pub lateral_anisotropy_ratio: f64,
    pub ksatadj: bool,
    pub ksatfac_mm_h: Option<f64>,
    pub ksatrec_per_day: Option<f64>,
    pub lkeff_mm_h: Option<f64>,
    pub restrictive_layer: Option<TypedSoilRestrictiveLayerProjection>,
    pub profile_depth_mm: Option<f64>,
    pub profile_porosity_cap_mm: Option<f64>,
    pub profile_fc_store_mm: Option<f64>,
    pub profile_wp_store_mm: Option<f64>,
    pub profile_fc_tail_mm: Option<f64>,
    pub layers: Vec<TypedSoilWb11LayerRuntimeProjection>,
}

/// Typed parsed-soil projection for an optional restrictive layer.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TypedSoilRestrictiveLayerProjection {
    pub slflag: bool,
    pub ui_bdrkth_m: f64,
    pub kslast_m_s: f64,
}

impl From<PrimaryWb11LayerRuntimeSymbols> for TypedSoilWb11LayerRuntimeProjection {
    fn from(layer: PrimaryWb11LayerRuntimeSymbols) -> Self {
        Self {
            solthk_m: layer.solthk_m,
            dg_m: layer.dg_m,
            porosity: layer.porosity,
            cpm: layer.cpm,
            coca: layer.coca,
            bulk_density_kg_m3: layer.bulk_density_kg_m3,
            thetfc: layer.thetfc,
            thetdr: layer.thetdr,
            ssc_m_s: layer.ssc_m_s,
            lateral_ssh_m_s: layer.lateral_ssh_m_s,
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct LegacySoilLayerSeed {
    depth_mm: f64,
    bulk_density_g_cm3: f64,
    fc_measured: f64,
    wp_measured: f64,
    sand_pct: f64,
    clay_pct: f64,
    orgmat_pct: f64,
    cec_meq_100g: f64,
    rock_frag_pct: f64,
    fc_wp_rock_multiplier_policy: FcWpRockMultiplierPolicy,
}

#[derive(Clone, Copy, Debug)]
struct LegacySoilLayerExpanded {
    thickness_m: f64,
    bulk_density_kg_m3: f64,
    thetfc: f64,
    thetdr: f64,
    sand: f64,
    clay: f64,
    orgmat: f64,
    cec: f64,
    rfg: f64,
    fc_wp_rock_multiplier_policy: FcWpRockMultiplierPolicy,
}

#[derive(Clone, Copy, Debug)]
struct LegacyConductivityLayer {
    thickness_m: f64,
    ksat_mm_h: f64,
    lateral_ksat_mm_h: f64,
}

#[derive(Clone, Copy, Debug)]
struct NormalizedConductivityRuntimeSymbols {
    ssc_m_s: f64,
    lateral_ssh_m_s: f64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum FcWpRockMultiplierPolicy {
    ApplyToMeasuredFcWp,
    SkipForMeasuredFcWp,
}

const WB13_PROFILE_LAYER_THICKNESS_M: f64 = 0.2;
const LEGACY_INPUT_DELTA_EPS_M: f64 = 0.001;
const PROFILE_FC_TAIL_TOLERANCE_MM: f64 = 1.0e-9;

/// Project typed static WB11/WB18/WB19 soil seed values from parsed soil input.
///
/// # Errors
///
/// Returns `HillslopeRuntimeInputError` when the parsed soil profile is
/// missing required fields or violates the same normalization/domain rules
/// used by the runtime-surface adapter.
#[allow(clippy::too_many_lines)]
pub fn project_typed_soil_wb11_runtime(
    soil: &SoilProfile,
) -> Result<TypedSoilWb11RuntimeProjection, HillslopeRuntimeInputError> {
    let primary_ofe = soil
        .ofes
        .first()
        .ok_or(HillslopeRuntimeInputError::MissingSoilOfe)?;
    let primary_top_layer = primary_ofe
        .layers
        .first()
        .ok_or(HillslopeRuntimeInputError::MissingSoilLayer)?;

    if soil.ntemp != soil.ofes.len() {
        return Err(HillslopeRuntimeInputError::SoilOfeCountMismatch {
            declared_ofe_count: soil.ntemp,
            observed_ofes: soil.ofes.len(),
        });
    }
    if primary_ofe.nsl != primary_ofe.layers.len() {
        return Err(HillslopeRuntimeInputError::SoilLayerCountMismatch {
            ofe_index: 1,
            declared_nsl: primary_ofe.nsl,
            observed_layers: primary_ofe.layers.len(),
        });
    }

    let primary_profile_depth_mm = primary_ofe
        .layers
        .last()
        .ok_or(HillslopeRuntimeInputError::MissingSoilLayer)?
        .depth_mm;
    if !primary_profile_depth_mm.is_finite() {
        return Err(HillslopeRuntimeInputError::NonFiniteProfileDepth {
            value_mm: primary_profile_depth_mm,
        });
    }
    if primary_profile_depth_mm <= 0.0 {
        return Err(HillslopeRuntimeInputError::NonPositiveProfileDepth {
            value_mm: primary_profile_depth_mm,
        });
    }

    let profile_symbols = compute_wb13_profile_symbols(primary_ofe, soil.datver);
    let primary_wb11_layers =
        compute_normalized_wb11_primary_layer_runtime_symbols(primary_ofe, 1, soil.datver)?;
    let profile_fc_tail_mm = if let Some(profile_symbols) = profile_symbols {
        let layer_fc_store_mm = aggregate_profile_fc_store_mm_from_primary_wb11_layers(
            &primary_wb11_layers,
        );
        let mut tail_mm = profile_symbols.fc_store - layer_fc_store_mm;
        if !tail_mm.is_finite() {
            return Err(HillslopeRuntimeInputError::NonFiniteProfileFcTailContribution {
                ofe_index: 1,
                value_mm: tail_mm,
            });
        }
        if tail_mm < 0.0 {
            if tail_mm >= -PROFILE_FC_TAIL_TOLERANCE_MM {
                tail_mm = 0.0;
            } else {
                return Err(HillslopeRuntimeInputError::NegativeProfileFcTailContribution {
                    ofe_index: 1,
                    value_mm: tail_mm,
                });
            }
        }
        Some(tail_mm)
    } else {
        None
    };

    let (ksatadj, ksatfac_mm_h, ksatrec_per_day, lkeff_mm_h) = match &primary_ofe.policy {
        Some(DisturbedPolicy::V9002 {
            ksatadj,
            ksatfac_mm_h,
            ksatrec_per_day,
            ..
        }) => (*ksatadj, Some(*ksatfac_mm_h), Some(*ksatrec_per_day), None),
        Some(
            DisturbedPolicy::V9003 {
                ksatadj,
                lkeff_mm_h,
                ..
            }
            | DisturbedPolicy::V9005 {
                ksatadj,
                lkeff_mm_h,
                ..
            },
        ) => (*ksatadj, None, None, Some(*lkeff_mm_h)),
        None => (false, None, None, None),
    };

    let lateral_anisotropy_ratio = match soil.datver {
        SoilDatver::V7778 | SoilDatver::V9002 | SoilDatver::V9003 | SoilDatver::V9005 => 1.0,
        SoilDatver::V97_5 | SoilDatver::V2006_2 | SoilDatver::V7777 => {
            primary_top_layer.anisotropy_ratio.unwrap_or(1.0)
        }
    };
    let restrictive_layer =
        soil.restrictive_layer
            .as_ref()
            .map(|restrictive| TypedSoilRestrictiveLayerProjection {
                slflag: restrictive.slflag,
                ui_bdrkth_m: restrictive.ui_bdrkth_mm / 1_000.0,
                kslast_m_s: restrictive.kslast_mm_h / 3.6e6,
            });
    let layers: Vec<TypedSoilWb11LayerRuntimeProjection> = primary_wb11_layers
        .into_iter()
        .map(Into::into)
        .collect::<Vec<_>>();
    let nsl = layers.len();
    Ok(TypedSoilWb11RuntimeProjection {
        nsl,
        sat: primary_ofe.sat,
        solwpv: soil.datver_raw,
        salb: primary_ofe.salb,
        solthk_m: layers
            .last()
            .map_or(primary_profile_depth_mm / 1_000.0, |layer| layer.solthk_m),
        lateral_anisotropy_ratio,
        ksatadj,
        ksatfac_mm_h,
        ksatrec_per_day,
        lkeff_mm_h,
        restrictive_layer,
        profile_depth_mm: profile_symbols.map(|profile| profile.depth),
        profile_porosity_cap_mm: profile_symbols.map(|profile| profile.porosity_cap),
        profile_fc_store_mm: profile_symbols.map(|profile| profile.fc_store),
        profile_wp_store_mm: profile_symbols.map(|profile| profile.wp_store),
        profile_fc_tail_mm,
        layers,
    })
}

/// Project typed parser-layer WB13/profile publication lineage from parsed soil.
///
/// This mirrors the former `nsl`/`dg_####`/`thetfc_####` runtime-surface
/// authority without constructing a symbol map.
pub fn project_typed_soil_profile_publication(
    soil: &SoilProfile,
) -> Result<TypedSoilProfilePublicationProjection, HillslopeRuntimeInputError> {
    let primary_ofe = soil
        .ofes
        .first()
        .ok_or(HillslopeRuntimeInputError::MissingSoilOfe)?;
    if soil.ntemp != soil.ofes.len() {
        return Err(HillslopeRuntimeInputError::SoilOfeCountMismatch {
            declared_ofe_count: soil.ntemp,
            observed_ofes: soil.ofes.len(),
        });
    }
    if primary_ofe.nsl != primary_ofe.layers.len() {
        return Err(HillslopeRuntimeInputError::SoilLayerCountMismatch {
            ofe_index: 1,
            declared_nsl: primary_ofe.nsl,
            observed_layers: primary_ofe.layers.len(),
        });
    }
    let corrected_layers = compute_corrected_layer_runtime_symbols(primary_ofe, 1, soil.datver)?;
    if corrected_layers.len() != primary_ofe.layers.len() {
        return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
            ofe_index: 1,
        });
    }

    let mut previous_depth_mm = 0.0_f64;
    let mut layers = Vec::with_capacity(primary_ofe.layers.len());
    for (layer_position, (layer, corrected)) in primary_ofe
        .layers
        .iter()
        .zip(corrected_layers.iter())
        .enumerate()
    {
        let layer_index = layer_position + 1;
        let layer_depth_mm = layer.depth_mm;
        if !layer_depth_mm.is_finite() {
            return Err(HillslopeRuntimeInputError::NonFiniteLayerDepth {
                ofe_index: 1,
                layer_index,
                value_mm: layer_depth_mm,
            });
        }
        if layer_depth_mm <= 0.0 {
            return Err(HillslopeRuntimeInputError::NonPositiveLayerDepth {
                ofe_index: 1,
                layer_index,
                value_mm: layer_depth_mm,
            });
        }
        if layer_depth_mm <= previous_depth_mm {
            return Err(HillslopeRuntimeInputError::NonMonotoneLayerDepth {
                ofe_index: 1,
                upper_layer_index: layer_index.saturating_sub(1),
                upper_depth_mm: previous_depth_mm,
                lower_layer_index: layer_index,
                lower_depth_mm: layer_depth_mm,
            });
        }
        if !corrected.thetfc.is_finite() {
            return Err(HillslopeRuntimeInputError::NonFiniteThetaFieldCapacity {
                value: corrected.thetfc,
            });
        }
        layers.push(TypedSoilProfilePublicationLayerProjection {
            dg_m: (layer_depth_mm - previous_depth_mm) / 1_000.0,
            thetfc: corrected.thetfc,
        });
        previous_depth_mm = layer_depth_mm;
    }

    Ok(TypedSoilProfilePublicationProjection {
        nsl: layers.len(),
        layers,
    })
}

fn fc_wp_rock_multiplier_policy(soil_datver: SoilDatver) -> FcWpRockMultiplierPolicy {
    match soil_datver {
        SoilDatver::V7777
        | SoilDatver::V7778
        | SoilDatver::V9002
        | SoilDatver::V9003
        | SoilDatver::V9005 => FcWpRockMultiplierPolicy::ApplyToMeasuredFcWp,
        SoilDatver::V97_5 | SoilDatver::V2006_2 => FcWpRockMultiplierPolicy::SkipForMeasuredFcWp,
    }
}

fn compute_wb13_profile_symbols(
    ofe: &openwepp_input_contract::parsers::soil::SoilOfe,
    soil_datver: SoilDatver,
) -> Option<Wb13ProfileSymbols> {
    let fc_wp_policy = fc_wp_rock_multiplier_policy(soil_datver);
    let mut seeds = Vec::with_capacity(ofe.layers.len());
    for layer in &ofe.layers {
        let bulk_density = layer.bulk_density_g_cm3?;
        let fc_measured = layer.fc_measured?;
        let wp_measured = layer.wp_measured?;
        let seed = LegacySoilLayerSeed {
            depth_mm: layer.depth_mm,
            bulk_density_g_cm3: bulk_density,
            fc_measured,
            wp_measured,
            sand_pct: layer.sand_pct,
            clay_pct: layer.clay_pct,
            orgmat_pct: layer.orgmat_pct,
            cec_meq_100g: layer.cec_meq_100g,
            rock_frag_pct: layer.rock_frag_pct,
            fc_wp_rock_multiplier_policy: fc_wp_policy,
        };
        if !legacy_seed_is_finite(seed) {
            return None;
        }
        seeds.push(seed);
    }
    compute_wb13_profile_symbols_from_legacy_seed(&seeds)
}

fn legacy_seed_is_finite(seed: LegacySoilLayerSeed) -> bool {
    seed.depth_mm.is_finite()
        && seed.bulk_density_g_cm3.is_finite()
        && seed.fc_measured.is_finite()
        && seed.wp_measured.is_finite()
        && seed.sand_pct.is_finite()
        && seed.clay_pct.is_finite()
        && seed.orgmat_pct.is_finite()
        && seed.cec_meq_100g.is_finite()
        && seed.rock_frag_pct.is_finite()
}

fn compute_wb13_profile_symbols_from_legacy_seed(
    seeds: &[LegacySoilLayerSeed],
) -> Option<Wb13ProfileSymbols> {
    let expanded_layers = legacy_expand_soil_layers_to_200mm(seeds)?;
    if expanded_layers.is_empty() {
        return None;
    }

    let mut profile_depth_mm = 0.0_f64;
    let mut profile_porosity_cap_mm = 0.0_f64;
    let mut profile_fc_store_mm = 0.0_f64;
    let mut profile_wp_store_mm = 0.0_f64;

    for layer in expanded_layers {
        let corrected = legacy_correct_layer_moisture(layer)?;
        let thickness_mm = corrected.thickness_m * 1000.0;
        profile_depth_mm += thickness_mm;
        profile_porosity_cap_mm += corrected.porosity * thickness_mm;
        profile_fc_store_mm += corrected.thetfc * thickness_mm;
        profile_wp_store_mm += corrected.thetdr * thickness_mm;
    }

    Some(Wb13ProfileSymbols {
        depth: profile_depth_mm,
        porosity_cap: profile_porosity_cap_mm,
        fc_store: profile_fc_store_mm,
        wp_store: profile_wp_store_mm,
    })
}


fn compute_normalized_wb11_primary_layer_runtime_symbols(
    ofe: &openwepp_input_contract::parsers::soil::SoilOfe,
    ofe_index: usize,
    soil_datver: SoilDatver,
) -> Result<Vec<PrimaryWb11LayerRuntimeSymbols>, HillslopeRuntimeInputError> {
    let seeds = collect_legacy_soil_layer_seeds(ofe, ofe_index, soil_datver)?;
    let normalized_corrected_layers =
        compute_normalized_corrected_layer_runtime_symbols_from_legacy_seed(&seeds).ok_or(
            HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable { ofe_index },
        )?;
    let normalized_conductivity_values =
        compute_normalized_conductivity_runtime_symbols(ofe, &seeds, ofe_index)?;
    if normalized_corrected_layers.len() != normalized_conductivity_values.len() {
        return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
            ofe_index,
        });
    }

    let mut layers = Vec::with_capacity(normalized_corrected_layers.len());
    let mut solthk_m = 0.0_f64;
    for (layer_index, corrected_layer) in normalized_corrected_layers.into_iter().enumerate() {
        solthk_m += WB13_PROFILE_LAYER_THICKNESS_M;
        layers.push(PrimaryWb11LayerRuntimeSymbols {
            solthk_m,
            dg_m: WB13_PROFILE_LAYER_THICKNESS_M,
            porosity: corrected_layer.porosity,
            cpm: corrected_layer.cpm,
            coca: corrected_layer.coca,
            bulk_density_kg_m3: corrected_layer.bulk_density_kg_m3,
            thetfc: corrected_layer.thetfc,
            thetdr: corrected_layer.thetdr,
            ssc_m_s: normalized_conductivity_values[layer_index].ssc_m_s,
            lateral_ssh_m_s: normalized_conductivity_values[layer_index].lateral_ssh_m_s,
        });
    }
    if layers.is_empty() {
        return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
            ofe_index,
        });
    }
    Ok(layers)
}

fn compute_normalized_conductivity_runtime_symbols(
    ofe: &openwepp_input_contract::parsers::soil::SoilOfe,
    seeds: &[LegacySoilLayerSeed],
    ofe_index: usize,
) -> Result<Vec<NormalizedConductivityRuntimeSymbols>, HillslopeRuntimeInputError> {
    let cumulative_depths_mm = legacy_cumulative_depths_mm(seeds).ok_or(
        HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable { ofe_index },
    )?;
    let source_layers =
        legacy_conductivity_source_layers_from_seed_depths(ofe, &cumulative_depths_mm, ofe_index)?;
    let total_depth_m = source_layers
        .iter()
        .map(|layer| layer.thickness_m)
        .sum::<f64>();
    let normalized_layer_count = legacy_normalized_layer_count(total_depth_m).ok_or(
        HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable { ofe_index },
    )?;
    legacy_normalize_conductivity_layers_to_200mm(
        &source_layers,
        normalized_layer_count,
        ofe_index,
    )
}

fn aggregate_profile_fc_store_mm_from_primary_wb11_layers(
    layers: &[PrimaryWb11LayerRuntimeSymbols],
) -> f64 {
    layers
        .iter()
        .map(|layer| layer.thetfc * layer.dg_m * 1_000.0)
        .sum()
}


fn collect_legacy_soil_layer_seeds(
    ofe: &openwepp_input_contract::parsers::soil::SoilOfe,
    ofe_index: usize,
    soil_datver: SoilDatver,
) -> Result<Vec<LegacySoilLayerSeed>, HillslopeRuntimeInputError> {
    let fc_wp_policy = fc_wp_rock_multiplier_policy(soil_datver);
    let mut seeds = Vec::with_capacity(ofe.layers.len());
    for (layer_position, layer) in ofe.layers.iter().enumerate() {
        let layer_index = layer_position + 1;
        let bulk_density =
            layer
                .bulk_density_g_cm3
                .ok_or(HillslopeRuntimeInputError::MissingCorrectedLayerNormalizationInput {
                    ofe_index,
                    layer_index,
                    field: "bulk_density_g_cm3",
                })?;
        let fc_measured =
            layer
                .fc_measured
                .ok_or(HillslopeRuntimeInputError::MissingCorrectedLayerNormalizationInput {
                    ofe_index,
                    layer_index,
                    field: "fc_measured",
                })?;
        let wp_measured =
            layer
                .wp_measured
                .ok_or(HillslopeRuntimeInputError::MissingCorrectedLayerNormalizationInput {
                    ofe_index,
                    layer_index,
                    field: "wp_measured",
                })?;
        let seed = LegacySoilLayerSeed {
            depth_mm: layer.depth_mm,
            bulk_density_g_cm3: bulk_density,
            fc_measured,
            wp_measured,
            sand_pct: layer.sand_pct,
            clay_pct: layer.clay_pct,
            orgmat_pct: layer.orgmat_pct,
            cec_meq_100g: layer.cec_meq_100g,
            rock_frag_pct: layer.rock_frag_pct,
            fc_wp_rock_multiplier_policy: fc_wp_policy,
        };
        if !legacy_seed_is_finite(seed) {
            return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
                ofe_index,
            });
        }
        seeds.push(seed);
    }
    Ok(seeds)
}

fn compute_normalized_corrected_layer_runtime_symbols_from_legacy_seed(
    seeds: &[LegacySoilLayerSeed],
) -> Option<Vec<CorrectedLayerRuntimeSymbols>> {
    let expanded_layers = legacy_expand_soil_layers_to_200mm(seeds)?;
    if expanded_layers.is_empty() {
        return None;
    }
    let mut corrected_layers = Vec::with_capacity(expanded_layers.len());
    for layer in expanded_layers {
        let corrected = legacy_correct_layer_moisture(layer)?;
        corrected_layers.push(CorrectedLayerRuntimeSymbols {
            porosity: corrected.porosity,
            cpm: corrected.cpm,
            coca: corrected.coca,
            bulk_density_kg_m3: corrected.bulk_density_kg_m3,
            thetfc: corrected.thetfc,
            thetdr: corrected.thetdr,
        });
    }
    if corrected_layers.is_empty() {
        return None;
    }
    Some(corrected_layers)
}

fn compute_corrected_layer_runtime_symbols(
    ofe: &openwepp_input_contract::parsers::soil::SoilOfe,
    ofe_index: usize,
    soil_datver: SoilDatver,
) -> Result<Vec<CorrectedLayerRuntimeSymbols>, HillslopeRuntimeInputError> {
    let seeds = collect_legacy_soil_layer_seeds(ofe, ofe_index, soil_datver)?;
    let normalized_corrected_layers =
        compute_normalized_corrected_layer_runtime_symbols_from_legacy_seed(&seeds).ok_or(
            HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable { ofe_index },
        )?;
    map_corrected_layer_runtime_symbols_to_parser_layers(
        ofe,
        &normalized_corrected_layers,
        ofe_index,
    )
}

fn map_corrected_layer_runtime_symbols_to_parser_layers(
    ofe: &openwepp_input_contract::parsers::soil::SoilOfe,
    normalized_corrected_layers: &[CorrectedLayerRuntimeSymbols],
    ofe_index: usize,
) -> Result<Vec<CorrectedLayerRuntimeSymbols>, HillslopeRuntimeInputError> {
    if normalized_corrected_layers.is_empty() {
        return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
            ofe_index,
        });
    }

    let mut normalized_intervals = Vec::with_capacity(normalized_corrected_layers.len());
    let mut normalized_top_mm = 0.0_f64;
    let parser_profile_depth_mm = ofe
        .layers
        .last()
        .map_or(0.0_f64, |layer| layer.depth_mm);
    for (layer_position, corrected_layer) in normalized_corrected_layers.iter().enumerate() {
        let normalized_bottom_mm = normalized_top_mm + WB13_PROFILE_LAYER_THICKNESS_M * 1_000.0;
        let mapped_bottom_mm = if layer_position + 1 == normalized_corrected_layers.len()
            && parser_profile_depth_mm.is_finite()
            && parser_profile_depth_mm > normalized_bottom_mm
        {
            parser_profile_depth_mm
        } else {
            normalized_bottom_mm
        };
        normalized_intervals.push((normalized_top_mm, mapped_bottom_mm, *corrected_layer));
        normalized_top_mm = normalized_bottom_mm;
    }

    let mut mapped_layers = Vec::with_capacity(ofe.layers.len());
    let mut layer_top_depth_mm = 0.0_f64;
    for (layer_position, layer) in ofe.layers.iter().enumerate() {
        let layer_index = layer_position + 1;
        let layer_bottom_depth_mm = layer.depth_mm;
        let layer_thickness_mm = layer_bottom_depth_mm - layer_top_depth_mm;
        if !layer_thickness_mm.is_finite() || layer_thickness_mm <= 0.0 {
            return Err(HillslopeRuntimeInputError::CorrectedLayerMappingIncomplete {
                ofe_index,
                layer_index,
                layer_top_depth_mm,
                layer_bottom_depth_mm,
                covered_depth_mm: 0.0,
            });
        }

        let mut weighted_thetfc = 0.0_f64;
        let mut weighted_thetdr = 0.0_f64;
        let mut weighted_porosity = 0.0_f64;
        let mut weighted_cpm = 0.0_f64;
        let mut weighted_coca = 0.0_f64;
        let mut weighted_bulk_density_kg_m3 = 0.0_f64;
        let mut covered_depth_mm = 0.0_f64;

        for (normalized_top_mm, normalized_bottom_mm, corrected_layer) in &normalized_intervals {
            let overlap_top_mm = layer_top_depth_mm.max(*normalized_top_mm);
            let overlap_bottom_mm = layer_bottom_depth_mm.min(*normalized_bottom_mm);
            let overlap_depth_mm = (overlap_bottom_mm - overlap_top_mm).max(0.0);
            if overlap_depth_mm <= 0.0 {
                continue;
            }
            weighted_thetfc += corrected_layer.thetfc * overlap_depth_mm;
            weighted_thetdr += corrected_layer.thetdr * overlap_depth_mm;
            weighted_porosity += corrected_layer.porosity * overlap_depth_mm;
            weighted_cpm += corrected_layer.cpm * overlap_depth_mm;
            weighted_coca += corrected_layer.coca * overlap_depth_mm;
            weighted_bulk_density_kg_m3 += corrected_layer.bulk_density_kg_m3 * overlap_depth_mm;
            covered_depth_mm += overlap_depth_mm;
        }

        if covered_depth_mm <= 0.0 || (covered_depth_mm - layer_thickness_mm).abs() > 1.0e-9 {
            return Err(HillslopeRuntimeInputError::CorrectedLayerMappingIncomplete {
                ofe_index,
                layer_index,
                layer_top_depth_mm,
                layer_bottom_depth_mm,
                covered_depth_mm,
            });
        }

        mapped_layers.push(CorrectedLayerRuntimeSymbols {
            porosity: weighted_porosity / covered_depth_mm,
            cpm: weighted_cpm / covered_depth_mm,
            coca: weighted_coca / covered_depth_mm,
            bulk_density_kg_m3: weighted_bulk_density_kg_m3 / covered_depth_mm,
            thetfc: weighted_thetfc / covered_depth_mm,
            thetdr: weighted_thetdr / covered_depth_mm,
        });
        layer_top_depth_mm = layer_bottom_depth_mm;
    }
    Ok(mapped_layers)
}

#[derive(Clone, Copy, Debug)]
struct LegacyCorrectedLayerMoisture {
    thickness_m: f64,
    porosity: f64,
    cpm: f64,
    coca: f64,
    bulk_density_kg_m3: f64,
    thetfc: f64,
    thetdr: f64,
}

fn legacy_correct_layer_moisture(
    layer: LegacySoilLayerExpanded,
) -> Option<LegacyCorrectedLayerMoisture> {
    let dg = layer.thickness_m;
    if !dg.is_finite() || dg <= 0.0 {
        return None;
    }
    let solcon = legacy_solcon(layer.clay, layer.cec, layer.orgmat, dg);
    let oca = 3.80
        + 1.9 * layer.clay.powi(2)
        - (3.365 * layer.sand)
        + (12.6 * solcon * layer.clay)
        + (100.0 * layer.orgmat * (layer.sand / 2.0).powi(2));
    let coca = 1.0 - (oca / 100.0);
    if !coca.is_finite() || coca <= 0.0 || coca > 1.0 {
        return None;
    }
    let cpm = 1.0
        - ((layer.rfg * layer.bulk_density_kg_m3)
            / ((layer.rfg * layer.bulk_density_kg_m3) + 2650.0 * (1.0 - layer.rfg)));
    if !cpm.is_finite() || cpm <= 0.0 || cpm > 1.0 {
        return None;
    }

    let mut por = (2650.0 - layer.bulk_density_kg_m3) / 2650.0;
    por *= coca;
    if !por.is_finite() || por <= 0.0 {
        return None;
    }

    let apply_fc_wp_rock_multiplier = matches!(
        layer.fc_wp_rock_multiplier_policy,
        FcWpRockMultiplierPolicy::ApplyToMeasuredFcWp
    );
    let mut thetfc = layer.thetfc.max(0.0);
    let mut thetdr = layer.thetdr.max(0.0);
    if apply_fc_wp_rock_multiplier {
        thetfc *= cpm;
        thetdr *= cpm;
    }
    if !thetfc.is_finite() || !thetdr.is_finite() {
        return None;
    }
    if thetfc <= 0.0 || thetdr <= 0.0 {
        return None;
    }

    let log10 = 10_f64.ln();
    let t33 = 333.3_f64.ln() / log10;
    let t15 = 15_300.0_f64.ln() / log10;
    let s33 = thetfc.ln() / log10;
    let s15 = thetdr.ln() / log10;
    let slope = ((s15 - s33) / (t15 - t33)).abs();
    if !slope.is_finite() {
        return None;
    }
    let mut sm20c = 10.0_f64.powf(slope * (t15 - (10.0_f64.ln() / log10)) + s15);
    if apply_fc_wp_rock_multiplier {
        sm20c *= cpm;
    }
    if sm20c >= por {
        sm20c = por * 0.95;
    }
    if thetfc >= sm20c {
        let delta = thetfc - thetdr;
        thetfc = sm20c * 0.99;
        thetdr = (thetfc - delta).max(0.01);
        thetfc = thetfc.max(0.01);
    }
    if (thetfc / por) > 0.83 {
        let scale = thetfc / (por * 0.83);
        thetfc = por * 0.83;
        thetdr /= scale;
    }
    thetdr = thetdr.max(0.01);
    thetfc = thetfc.max(0.01);
    if !thetfc.is_finite() || !thetdr.is_finite() {
        return None;
    }
    if thetdr > thetfc {
        return None;
    }
    if thetfc > por {
        return None;
    }

    Some(LegacyCorrectedLayerMoisture {
        thickness_m: dg,
        porosity: por,
        cpm,
        coca,
        bulk_density_kg_m3: layer.bulk_density_kg_m3,
        thetfc,
        thetdr,
    })
}

fn legacy_solcon(clay: f64, cec: f64, orgmat: f64, dg: f64) -> f64 {
    if clay <= 0.0 {
        return 0.0;
    }
    let cecc = cec - orgmat * (142.0 + 170.0 * dg);
    (cecc / (100.0 * clay)).clamp(0.15, 0.65)
}

fn legacy_expand_soil_layers_to_200mm(
    seeds: &[LegacySoilLayerSeed],
) -> Option<Vec<LegacySoilLayerExpanded>> {
    let cumulative_depths_mm = legacy_cumulative_depths_mm(seeds)?;
    let source_layers = legacy_source_layers_from_seed_depths(seeds, &cumulative_depths_mm)?;
    let total_depth_m = source_layers.iter().map(|layer| layer.thickness_m).sum::<f64>();
    let normalized_layer_count = legacy_normalized_layer_count(total_depth_m)?;
    Some(legacy_normalize_layers_to_200mm(
        &source_layers,
        normalized_layer_count,
    ))
}

fn legacy_cumulative_depths_mm(seeds: &[LegacySoilLayerSeed]) -> Option<Vec<f64>> {
    if seeds.is_empty() {
        return None;
    }
    let mut cumulative_depths_mm = seeds
        .iter()
        .map(|seed| seed.depth_mm)
        .collect::<Vec<f64>>();
    let total_thickness_mm = *cumulative_depths_mm.last()?;
    if total_thickness_mm < 200.0 {
        let deficit = 200.0 - total_thickness_mm;
        if let Some(last_depth) = cumulative_depths_mm.last_mut() {
            *last_depth += deficit;
        }
    }
    if let Some(last_depth) = cumulative_depths_mm.last_mut() {
        *last_depth += 200.0;
    }
    for depth in &mut cumulative_depths_mm {
        if *depth > 1800.0 {
            *depth = 1800.0;
        }
    }
    Some(cumulative_depths_mm)
}

fn legacy_source_layers_from_seed_depths(
    seeds: &[LegacySoilLayerSeed],
    cumulative_depths_mm: &[f64],
) -> Option<Vec<LegacySoilLayerExpanded>> {
    let mut source_layers = Vec::with_capacity(seeds.len());
    let mut previous_depth_m = 0.0_f64;
    for (seed, depth_mm) in seeds.iter().zip(cumulative_depths_mm.iter().copied()) {
        let mut bulk_density = seed.bulk_density_g_cm3;
        if bulk_density > 0.0 && bulk_density < 0.8 {
            bulk_density = 0.8;
        }
        if bulk_density > 2.0 {
            bulk_density = 2.0;
        }

        let mut orgmat_pct = seed.orgmat_pct;
        if orgmat_pct > 10.0 {
            orgmat_pct = 10.0;
        }
        let mut rock_frag_pct = seed.rock_frag_pct;
        if rock_frag_pct > 85.0 {
            rock_frag_pct = 85.0;
        }

        let depth_m = depth_mm * 0.001;
        let thickness_m = depth_m - previous_depth_m;
        previous_depth_m = depth_m;
        if thickness_m <= 0.0 {
            continue;
        }

        source_layers.push(LegacySoilLayerExpanded {
            thickness_m,
            bulk_density_kg_m3: bulk_density * 1000.0,
            thetfc: seed.fc_measured,
            thetdr: seed.wp_measured,
            sand: seed.sand_pct / 100.0,
            clay: seed.clay_pct / 100.0,
            orgmat: orgmat_pct / 100.0,
            cec: seed.cec_meq_100g,
            rfg: rock_frag_pct / 100.0,
            fc_wp_rock_multiplier_policy: seed.fc_wp_rock_multiplier_policy,
        });
    }
    if source_layers.is_empty() {
        return None;
    }
    Some(source_layers)
}

fn legacy_conductivity_source_layers_from_seed_depths(
    ofe: &openwepp_input_contract::parsers::soil::SoilOfe,
    cumulative_depths_mm: &[f64],
    ofe_index: usize,
) -> Result<Vec<LegacyConductivityLayer>, HillslopeRuntimeInputError> {
    let mut source_layers = Vec::with_capacity(ofe.layers.len());
    let mut previous_depth_m = 0.0_f64;
    for (layer_position, (layer, depth_mm)) in ofe
        .layers
        .iter()
        .zip(cumulative_depths_mm.iter().copied())
        .enumerate()
    {
        let layer_index = layer_position + 1;
        let layer_ksat_mm_h = layer.ksat_mm_h.ok_or(
            HillslopeRuntimeInputError::MissingSaturatedConductivity {
                ofe_index,
                layer_index,
            },
        )?;
        if !layer_ksat_mm_h.is_finite() {
            return Err(HillslopeRuntimeInputError::NonFiniteSaturatedConductivity {
                ofe_index,
                layer_index,
                value_mm_h: layer_ksat_mm_h,
            });
        }
        if layer_ksat_mm_h <= 0.0 {
            return Err(HillslopeRuntimeInputError::NonPositiveSaturatedConductivity {
                ofe_index,
                layer_index,
                value_mm_h: layer_ksat_mm_h,
            });
        }
        let layer_lateral_anisotropy_ratio = layer.anisotropy_ratio.unwrap_or(1.0);
        if !layer_lateral_anisotropy_ratio.is_finite() || layer_lateral_anisotropy_ratio <= 0.0 {
            return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
                ofe_index,
            });
        }

        let depth_m = depth_mm * 0.001;
        let thickness_m = depth_m - previous_depth_m;
        previous_depth_m = depth_m;
        if thickness_m <= 0.0 {
            continue;
        }
        source_layers.push(LegacyConductivityLayer {
            thickness_m,
            ksat_mm_h: layer_ksat_mm_h,
            lateral_ksat_mm_h: layer_ksat_mm_h * layer_lateral_anisotropy_ratio,
        });
    }
    if source_layers.is_empty() {
        return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
            ofe_index,
        });
    }
    Ok(source_layers)
}

fn legacy_normalized_layer_count(total_depth_m: f64) -> Option<usize> {
    let rounded_total_mm = (total_depth_m * 1000.0).round();
    if !rounded_total_mm.is_finite() || rounded_total_mm <= 0.0 {
        return None;
    }

    let mut remaining_mm = rounded_total_mm;
    let mut normalized_layer_count = 0usize;
    while remaining_mm >= 200.0 {
        normalized_layer_count = normalized_layer_count.checked_add(1)?;
        remaining_mm -= 200.0;
    }
    if normalized_layer_count == 0 {
        return None;
    }
    Some(normalized_layer_count)
}

fn legacy_normalize_layers_to_200mm(
    source_layers: &[LegacySoilLayerExpanded],
    normalized_layer_count: usize,
) -> Vec<LegacySoilLayerExpanded> {
    let mut remaining_thicknesses = source_layers
        .iter()
        .map(|layer| layer.thickness_m)
        .collect::<Vec<f64>>();
    let mut source_index = 0usize;
    let mut normalized_layers = Vec::with_capacity(normalized_layer_count);
    for _normalized_index in 0..normalized_layer_count {
        let mut layer = LegacySoilLayerExpanded {
            thickness_m: WB13_PROFILE_LAYER_THICKNESS_M,
            bulk_density_kg_m3: 0.0,
            thetfc: 0.0,
            thetdr: 0.0,
            sand: 0.0,
            clay: 0.0,
            orgmat: 0.0,
            cec: 0.0,
            rfg: 0.0,
            fc_wp_rock_multiplier_policy: source_layers
                .first()
                .map_or(FcWpRockMultiplierPolicy::ApplyToMeasuredFcWp, |source| {
                    source.fc_wp_rock_multiplier_policy
                }),
        };
        let mut remaining = WB13_PROFILE_LAYER_THICKNESS_M;
        while remaining > 0.0 && source_index < source_layers.len() {
            let source_thickness = remaining_thicknesses[source_index];
            if source_thickness <= 0.0 {
                source_index += 1;
                continue;
            }
            if source_thickness <= remaining {
                let fraction = source_thickness / WB13_PROFILE_LAYER_THICKNESS_M;
                legacy_accumulate_weighted_layer(&mut layer, source_layers[source_index], fraction);
                remaining -= source_thickness;
                source_index += 1;
                if remaining.abs() <= LEGACY_INPUT_DELTA_EPS_M {
                    remaining = 0.0;
                }
            } else {
                let fraction = remaining / WB13_PROFILE_LAYER_THICKNESS_M;
                legacy_accumulate_weighted_layer(&mut layer, source_layers[source_index], fraction);
                remaining_thicknesses[source_index] -= remaining;
                if remaining_thicknesses[source_index].abs() <= LEGACY_INPUT_DELTA_EPS_M {
                    source_index += 1;
                }
                remaining = 0.0;
            }
        }
        normalized_layers.push(layer);
    }
    normalized_layers
}

fn legacy_normalize_conductivity_layers_to_200mm(
    source_layers: &[LegacyConductivityLayer],
    normalized_layer_count: usize,
    ofe_index: usize,
) -> Result<Vec<NormalizedConductivityRuntimeSymbols>, HillslopeRuntimeInputError> {
    let mut remaining_thicknesses = source_layers
        .iter()
        .map(|layer| layer.thickness_m)
        .collect::<Vec<f64>>();
    let mut source_index = 0usize;
    let mut normalized_layer_bottom_m = WB13_PROFILE_LAYER_THICKNESS_M;
    let mut normalized_conductivity_values = Vec::with_capacity(normalized_layer_count);
    for _normalized_index in 0..normalized_layer_count {
        let use_top_source_ksat =
            normalized_layer_bottom_m <= WB13_PROFILE_LAYER_THICKNESS_M + LEGACY_INPUT_DELTA_EPS_M;
        let top_source_ksat_mm_h = source_layers[0].ksat_mm_h;
        let mut inverse_weighted_ksat_h_per_mm = 0.0_f64;
        let mut weighted_lateral_ksat_mm_h = 0.0_f64;
        let mut remaining = WB13_PROFILE_LAYER_THICKNESS_M;
        while remaining > 0.0 && source_index < source_layers.len() {
            let source_thickness = remaining_thicknesses[source_index];
            if source_thickness <= 0.0 {
                source_index += 1;
                continue;
            }
            if source_thickness <= remaining {
                let fraction = source_thickness / WB13_PROFILE_LAYER_THICKNESS_M;
                let source = source_layers[source_index];
                let source_ksat_mm_h = if use_top_source_ksat {
                    top_source_ksat_mm_h
                } else {
                    source.ksat_mm_h
                };
                let source_anisotropy_ratio = source.lateral_ksat_mm_h / source.ksat_mm_h;
                inverse_weighted_ksat_h_per_mm += source_thickness / source_ksat_mm_h;
                weighted_lateral_ksat_mm_h +=
                    source_ksat_mm_h * source_anisotropy_ratio * fraction;
                remaining -= source_thickness;
                source_index += 1;
                if remaining.abs() <= LEGACY_INPUT_DELTA_EPS_M {
                    remaining = 0.0;
                }
            } else {
                let fraction = remaining / WB13_PROFILE_LAYER_THICKNESS_M;
                let source = source_layers[source_index];
                let source_ksat_mm_h = if use_top_source_ksat {
                    top_source_ksat_mm_h
                } else {
                    source.ksat_mm_h
                };
                let source_anisotropy_ratio = source.lateral_ksat_mm_h / source.ksat_mm_h;
                inverse_weighted_ksat_h_per_mm += remaining / source_ksat_mm_h;
                weighted_lateral_ksat_mm_h +=
                    source_ksat_mm_h * source_anisotropy_ratio * fraction;
                remaining_thicknesses[source_index] -= remaining;
                if remaining_thicknesses[source_index].abs() <= LEGACY_INPUT_DELTA_EPS_M {
                    source_index += 1;
                }
                remaining = 0.0;
            }
        }
        if inverse_weighted_ksat_h_per_mm <= 0.0 {
            return Err(HillslopeRuntimeInputError::CorrectedLayerNormalizationUnavailable {
                ofe_index,
            });
        }
        let vertical_ksat_mm_h = WB13_PROFILE_LAYER_THICKNESS_M / inverse_weighted_ksat_h_per_mm;
        normalized_conductivity_values.push(NormalizedConductivityRuntimeSymbols {
            ssc_m_s: vertical_ksat_mm_h / 3.6e6,
            lateral_ssh_m_s: weighted_lateral_ksat_mm_h / 3.6e6,
        });
        normalized_layer_bottom_m += WB13_PROFILE_LAYER_THICKNESS_M;
    }
    Ok(normalized_conductivity_values)
}

fn legacy_accumulate_weighted_layer(
    target: &mut LegacySoilLayerExpanded,
    source: LegacySoilLayerExpanded,
    weight: f64,
) {
    target.bulk_density_kg_m3 += source.bulk_density_kg_m3 * weight;
    target.thetfc += source.thetfc * weight;
    target.thetdr += source.thetdr * weight;
    target.sand += source.sand * weight;
    target.clay += source.clay * weight;
    target.orgmat += source.orgmat * weight;
    target.cec += source.cec * weight;
    target.rfg += source.rfg * weight;
}

#[cfg(test)]
mod fq1_soil_corrected_layer_coverage_tests {
    use super::*;
    use openwepp_input_contract::parsers::soil::{SoilLayer, SoilOfe};

    fn test_corrected_layer(value: f64) -> CorrectedLayerRuntimeSymbols {
        CorrectedLayerRuntimeSymbols {
            porosity: value,
            cpm: value + 0.01,
            coca: value + 0.02,
            bulk_density_kg_m3: value + 0.03,
            thetfc: value + 0.04,
            thetdr: value + 0.05,
        }
    }

    fn test_soil_layer(depth_mm: f64) -> SoilLayer {
        SoilLayer {
            depth_mm,
            sand_pct: 0.0,
            clay_pct: 0.0,
            orgmat_pct: 0.0,
            cec_meq_100g: 0.0,
            rock_frag_pct: 0.0,
            bulk_density_g_cm3: None,
            ksat_mm_h: None,
            anisotropy_ratio: None,
            fc_measured: None,
            wp_measured: None,
            theta_r_rosetta: None,
            theta_s_rosetta: None,
            alpha_vg: None,
            npar_vg: None,
            ks_rosetta_cm_d: None,
            wp_rosetta: None,
            fc_rosetta: None,
        }
    }

    fn test_soil_ofe(depths_mm: &[f64]) -> SoilOfe {
        SoilOfe {
            slid: "test".to_string(),
            texid: "SIL".to_string(),
            nsl: depths_mm.len(),
            salb: 0.0,
            sat: 0.0,
            ki: 0.0,
            kr: 0.0,
            shcrit: 0.0,
            avke: 0.0,
            policy: None,
            layers: depths_mm
                .iter()
                .copied()
                .map(test_soil_layer)
                .collect(),
        }
    }

    fn test_normalized_layers(count: usize) -> Vec<CorrectedLayerRuntimeSymbols> {
        let mut value = 0.01_f64;
        (0..count)
            .map(|_| {
                let layer = test_corrected_layer(value);
                value += 0.01;
                layer
            })
            .collect()
    }

    #[test]
    fn fq1_maps_valid_parser_tail_below_legacy_normalized_cap_from_deepest_corrected_layer() {
        let ofe = test_soil_ofe(&[200.0, 280.0, 580.0, 800.0, 1100.0, 2000.0]);
        let normalized_layers = test_normalized_layers(9);

        let mapped =
            map_corrected_layer_runtime_symbols_to_parser_layers(&ofe, &normalized_layers, 1)
                .expect("valid p1-shaped parser profile should map through 2000 mm");

        assert_eq!(mapped.len(), 6);
        assert!(
            (mapped[5].porosity - 0.08).abs() < 1.0e-12,
            "1100..2000 mm parser tail should include 1800..2000 mm extension from deepest normalized corrected layer"
        );
    }

    #[test]
    fn fq1_runnable_control_mapping_within_normalized_depth_is_unchanged() {
        let ofe = test_soil_ofe(&[200.0, 430.0, 990.0, 1600.0]);
        let normalized_layers = test_normalized_layers(9);

        let mapped =
            map_corrected_layer_runtime_symbols_to_parser_layers(&ofe, &normalized_layers, 1)
                .expect("valid p8-shaped parser profile should map within normalized depth");

        assert_eq!(mapped.len(), 4);
        assert!(
            (mapped[3].porosity - 0.069_672_131_147_541).abs() < 1.0e-12,
            "990..1600 mm control layer should remain the same depth-weighted overlap mapping"
        );
    }

    #[test]
    fn fq1_mapping_still_fails_closed_for_nonmonotone_parser_layer() {
        let ofe = test_soil_ofe(&[200.0, 150.0]);
        let normalized_layers = test_normalized_layers(9);

        let error =
            map_corrected_layer_runtime_symbols_to_parser_layers(&ofe, &normalized_layers, 1)
                .expect_err("nonmonotone parser profile must remain fail-closed");

        assert!(matches!(
            error,
            HillslopeRuntimeInputError::CorrectedLayerMappingIncomplete {
                layer_index: 2,
                ..
            }
        ));
    }
}

/// Runtime-surface options for slope parser projection.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SlopeRuntimeSurfaceOptions {
    /// Optional floor to apply when derived average slope is non-positive.
    pub non_positive_avgslp_floor: Option<f64>,
}

impl SlopeRuntimeSurfaceOptions {
    #[must_use]
    pub const fn strict() -> Self {
        Self {
            non_positive_avgslp_floor: None,
        }
    }

    #[must_use]
    pub const fn compatibility() -> Self {
        Self {
            non_positive_avgslp_floor: Some(0.000_001),
        }
    }
}

impl Default for SlopeRuntimeSurfaceOptions {
    fn default() -> Self {
        Self::strict()
    }
}

/// Typed parsed slope runtime projection.
#[derive(Debug, Clone, PartialEq)]
pub struct TypedSlopeRuntimeProjection {
    pub ofe_count: usize,
    pub ofes: Vec<TypedSlopeOfeRuntimeProjection>,
}

/// Typed parsed slope OFE runtime projection.
#[derive(Debug, Clone, PartialEq)]
pub struct TypedSlopeOfeRuntimeProjection {
    pub nslpts: usize,
    pub slplen_m: f64,
    pub avgslp: f64,
    pub avgslp_floor_applied: bool,
    pub azimuth_deg: f64,
    /// Representative profile width `fwidth` (m) from the slope file —
    /// denormalizes per-unit-width sediment surfaces to total mass
    /// (legacy `sedseg.for` `tdet = sum2*fwidth*filoss` lineage).
    pub fwidth_m: f64,
    pub points: Vec<TypedSlopePointRuntimeProjection>,
}

/// Typed parsed slope point runtime projection.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TypedSlopePointRuntimeProjection {
    pub xinput: f64,
    pub slpinp: f64,
}

/// Project typed slope runtime geometry from parsed slope input.
///
/// # Errors
///
/// Returns `HillslopeRuntimeInputError` when slope parser output violates
/// runtime guard policy.
#[allow(clippy::too_many_lines)]
pub fn project_typed_slope_runtime_with_options(
    slope: &SlopeProfile,
    options: SlopeRuntimeSurfaceOptions,
) -> Result<TypedSlopeRuntimeProjection, HillslopeRuntimeInputError> {
    validate_slope_profile_shape(slope)?;

    let _ofe_count =
        u32::try_from(slope.ofe_count).map_err(|_| {
            HillslopeRuntimeInputError::SlopeOfeCountOutOfRange {
                value: slope.ofe_count,
            }
        })?;
    let mut ofes = Vec::with_capacity(slope.ofe_count);
    for (ofe_position, ofe) in slope.ofes.iter().enumerate() {
        let ofe_index = ofe_position + 1;
        validate_slope_ofe_shape(ofe_index, ofe.nslpts, ofe.points.len())?;
        validate_slope_points(ofe_index, &ofe.points)?;

        let _nslpts = u32::try_from(ofe.nslpts).map_err(|_| {
            HillslopeRuntimeInputError::SlopePointCountOutOfRange {
                ofe_index,
                value: ofe.nslpts,
            }
        })?;

        let slplen_m = ofe.slplen;
        if !slplen_m.is_finite() {
            return Err(HillslopeRuntimeInputError::NonFiniteSlopeLength {
                ofe_index,
                value_m: slplen_m,
            });
        }
        if slplen_m <= 0.0 {
            return Err(HillslopeRuntimeInputError::NonPositiveSlopeLength {
                ofe_index,
                value_m: slplen_m,
            });
        }

        let fwidth_m = ofe.fwidth;
        if !fwidth_m.is_finite() {
            return Err(HillslopeRuntimeInputError::NonFiniteProfileWidth {
                ofe_index,
                value_m: fwidth_m,
            });
        }
        if fwidth_m <= 0.0 {
            return Err(HillslopeRuntimeInputError::NonPositiveProfileWidth {
                ofe_index,
                value_m: fwidth_m,
            });
        }

        let (avgslp, avgslp_floor_applied) =
            derive_avgslp(ofe_index, &ofe.points, options.non_positive_avgslp_floor)?;
        ofes.push(TypedSlopeOfeRuntimeProjection {
            nslpts: ofe.nslpts,
            slplen_m,
            avgslp,
            avgslp_floor_applied,
            azimuth_deg: ofe.azm,
            fwidth_m,
            points: ofe
                .points
                .iter()
                .map(|point| TypedSlopePointRuntimeProjection {
                    xinput: point.xinput,
                    slpinp: point.slpinp,
                })
                .collect(),
        });
    }

    Ok(TypedSlopeRuntimeProjection {
        ofe_count: slope.ofe_count,
        ofes,
    })
}

/// Project typed slope runtime geometry from parsed slope input using strict
/// nonpositive-average-slope guard semantics.
///
/// # Errors
///
/// Returns `HillslopeRuntimeInputError` when slope parser output violates
/// runtime guard policy.
pub fn project_typed_slope_runtime(
    slope: &SlopeProfile,
) -> Result<TypedSlopeRuntimeProjection, HillslopeRuntimeInputError> {
    project_typed_slope_runtime_with_options(slope, SlopeRuntimeSurfaceOptions::strict())
}
