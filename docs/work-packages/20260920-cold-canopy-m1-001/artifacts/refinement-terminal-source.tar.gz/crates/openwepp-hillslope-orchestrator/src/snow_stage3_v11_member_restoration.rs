#![cfg(test)]
//! File-only composition of the retained diagnostic members. No process step.
use super::{
    B01_DAY_INDEX, B01_INTERVAL_INDEX, CLOCK_AUTHORITY_DOMAIN, CLOCK_MODEL_DOMAIN,
    CoupledClockStateV1, DirectV10RealConsumerShadow, PreparedSupportCaptureV1, TimeSupport,
    authenticate_archived_day_with_configuration_v1, capture_direct_run_constructor_inputs,
    capture_direct_run_frame_dynamic, capture_snow_free_prepared_support,
    complete_owner_set_digest, constructor_inverse, decode_member_backed_row_v1, digest_bytes,
    extract_pinned_seed_configuration_v1, reconstruct_provisional_on_clone_with_authorities,
    restore_coupled_clock, restore_direct_run_frame_dynamic, restore_prepared_support,
    restore_provider_day, restore_snow_free_clock_parent_from_member_export,
    validate_snow_free_prefix_membership_v1,
};
use openwepp_input_contract::parsers::climate::{ParserMode, parse_climate_file};
use serde::{Serialize, de::DeserializeOwned};
use serde_json::Value;
use std::{
    collections::{BTreeMap, BTreeSet},
    path::Path,
};

fn required<'a>(value: &'a Value, name: &str) -> Result<&'a Value, String> {
    value.get(name).ok_or_else(|| format!("missing {name}"))
}
fn decode<T: DeserializeOwned>(value: &Value) -> Result<T, String> {
    serde_json::from_value(value.clone()).map_err(|error| error.to_string())
}
fn hex_float(value: &Value) -> Result<f64, String> {
    let text = value.as_str().ok_or("seed hex float string")?;
    let hex = text
        .strip_prefix("0x")
        .filter(|s| s.len() == 16)
        .ok_or("seed hex float width")?;
    let value = f64::from_bits(u64::from_str_radix(hex, 16).map_err(|error| error.to_string())?);
    if !value.is_finite() {
        return Err("seed nonfinite float".into());
    }
    Ok(value)
}
fn pinned_provider(
    seed: &Value,
) -> Result<crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration, String> {
    let value = &seed["checkpoint"]["phase"]["committed"]["static_forcing_configuration"];
    let destinations = required(value, "destinations")?
        .as_array()
        .ok_or("seed destinations")?
        .iter()
        .map(|d| {
            Ok(crate::runtime_inputs::SnowFreeHalfHourDestination {
                ofe_id: decode(required(d, "ofe_id")?)?,
                tile_id: decode(required(d, "tile_id")?)?,
                wb14_configuration_sha256: decode(required(d, "wb14_configuration_sha256")?)?,
            })
        })
        .collect::<Result<Vec<_>, String>>()?;
    let result = crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration {
        run_id: decode(required(value, "run_id")?)?,
        co2_pa: hex_float(required(value, "co2_pa")?)?,
        reference_height_m: hex_float(required(value, "reference_height_m")?)?,
        gsi_owner_configuration_sha256: decode(required(value, "gsi_owner_configuration_sha256")?)?,
        destinations,
    };
    result.validate().map_err(|error| error.to_string())?;
    if value["configuration_sha256"] != result.configuration_sha256() {
        return Err("seed provider configuration digest".into());
    }
    Ok(result)
}

fn pinned_gsi(
    seed: &Value,
) -> Result<
    (
        crate::runtime_inputs::DirectGsiOwnerConfigurationV1,
        crate::runtime_inputs::DirectGsiOwnerStateV1,
    ),
    String,
> {
    let committed = &seed["checkpoint"]["phase"]["committed"];
    let configuration = &committed["gsi_configuration"];
    let parameters = &configuration["parameters"];
    let configuration = crate::runtime_inputs::DirectGsiOwnerConfigurationV1 {
        schema_version: decode(required(configuration, "schema_version")?)?,
        owner_id: decode(required(configuration, "owner_id")?)?,
        parameters: crate::runtime_inputs::DirectGsiParametersV1 {
            minimum_temperature_inactive_c: hex_float(required(
                parameters,
                "minimum_temperature_inactive_c",
            )?)?,
            minimum_temperature_unconstrained_c: hex_float(required(
                parameters,
                "minimum_temperature_unconstrained_c",
            )?)?,
            vapor_pressure_deficit_unconstrained_pa: hex_float(required(
                parameters,
                "vapor_pressure_deficit_unconstrained_pa",
            )?)?,
            vapor_pressure_deficit_inactive_pa: hex_float(required(
                parameters,
                "vapor_pressure_deficit_inactive_pa",
            )?)?,
            photoperiod_inactive_hours: hex_float(required(
                parameters,
                "photoperiod_inactive_hours",
            )?)?,
            photoperiod_unconstrained_hours: hex_float(required(
                parameters,
                "photoperiod_unconstrained_hours",
            )?)?,
        },
        latitude_degrees: hex_float(required(configuration, "latitude_degrees")?)?,
        configuration_sha256: decode(required(configuration, "configuration_sha256")?)?,
    };
    configuration
        .validate()
        .map_err(|error| error.to_string())?;
    let state: crate::runtime_inputs::DirectGsiOwnerStateV1 =
        decode(required(committed, "gsi_state")?)?;
    crate::runtime_inputs::restart_authority_restore_gsi_state(&state)
        .map_err(|error| error.to_string())?;
    Ok((configuration, state))
}

fn pinned_frozen_litter_lse(
    pinned_lse: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
) -> Result<openwepp_land_surface_energy::LandSurfaceEnergyConfiguration, String> {
    openwepp_land_surface_energy::migrate_v2_configuration_to_v3(pinned_lse)
        .map_err(|error| error.to_string())
}
// Same private operand projection as persisted-restart-v1/hydrology_restart.rs:
// float bits are strings before serializing the (domain, sorted Value) tuple.
fn operand_digest(domain: &str, value: &impl Serialize) -> Result<Value, String> {
    fn hexify(value: &mut Value) {
        match value {
            Value::Number(n) if n.is_f64() => {
                if let Some(f) = n.as_f64() {
                    *value = Value::String(format!("0x{:016x}", f.to_bits()));
                }
            }
            Value::Array(a) => a.iter_mut().for_each(hexify),
            Value::Object(o) => o.values_mut().for_each(hexify),
            _ => {}
        }
    }
    let mut projected = serde_json::to_value(value).map_err(|error| error.to_string())?;
    hexify(&mut projected);
    serde_json::to_value(digest_bytes(
        &serde_json::to_vec(&(domain, projected)).map_err(|error| error.to_string())?,
    ))
    .map_err(|error| error.to_string())
}
pub(super) fn pin_hydrology(
    seed: &Value,
    inputs: &crate::DirectRunConstructorInputs,
) -> Result<(), String> {
    let committed = &seed["checkpoint"]["phase"]["committed"]["scientific"]["direct_hydrology"];
    let captured = capture_direct_run_constructor_inputs(inputs);
    for name in ["run_id", "hillslope_id", "lane_count", "day_count"] {
        if required(committed, name)? != required(&captured["identity"], name)? {
            return Err(format!("seed hydrology {name}"));
        }
    }
    let phases = inputs
        .phase_plan
        .phases()
        .iter()
        .map(|phase| match phase {
            crate::DirectPhaseKind::Normalization => "normalization",
            crate::DirectPhaseKind::StorageBounds => "storage_bounds",
            crate::DirectPhaseKind::DecompositionTransition => "decomposition_transition",
            crate::DirectPhaseKind::ResiduePartitionTransition => "residue_partition_transition",
            crate::DirectPhaseKind::AnnualGrowthTransition => "annual_growth_transition",
            crate::DirectPhaseKind::PerennialGrowthTransition => "perennial_growth_transition",
            crate::DirectPhaseKind::PercolationDeepSeepage => "percolation_deep_seepage",
            crate::DirectPhaseKind::Evapotranspiration => "evapotranspiration",
            crate::DirectPhaseKind::Drainage => "drainage",
            crate::DirectPhaseKind::LateralTransfer => "lateral_transfer",
            crate::DirectPhaseKind::PlantRootUptake => "plant_root_uptake",
            crate::DirectPhaseKind::RunoffReconciliation => "runoff_reconciliation",
            crate::DirectPhaseKind::StorageReconciliation => "storage_reconciliation",
            crate::DirectPhaseKind::ClosureDiagnostics => "closure_diagnostics",
        })
        .collect::<Vec<_>>();
    if operand_digest("DirectPhasePlanV1", &phases)? != committed["phase_plan_sha256"] {
        return Err("seed phase plan digest".into());
    }
    let lanes = required(committed, "lanes")?
        .as_array()
        .ok_or("seed lanes")?;
    if lanes.len() != inputs.lanes.len() {
        return Err("seed lane cardinality".into());
    }
    for (lane, pinned) in inputs.lanes.iter().zip(lanes) {
        pin_lane_geometry(lane, pinned)?;
        if pinned["lane_id"] != lane.lane_id
            || operand_digest("DirectDayConstructorInputsV1", &lane.day_inputs)?
                != pinned["day_inputs_sha256"]
        {
            return Err("seed lane immutable day inputs digest".into());
        }
    }
    Ok(())
}
fn pin_lane_geometry(
    lane: &crate::DirectLaneConstructorInputs,
    pinned: &Value,
) -> Result<(), String> {
    for (name, actual) in [
        ("upstream_area_ratio", lane.upstream_area_ratio),
        ("area_m2", lane.area_m2),
        (
            "runoff_publication_q_scale",
            lane.runoff_publication_q_scale,
        ),
        (
            "runoff_publication_qofe_scale",
            lane.runoff_publication_qofe_scale,
        ),
        (
            "runoff_publication_efflen_m",
            lane.runoff_publication_efflen_m,
        ),
        (
            "runoff_publication_cumulative_length_m",
            lane.runoff_publication_cumulative_length_m,
        ),
        (
            "runoff_publication_ofe_length_m",
            lane.runoff_publication_ofe_length_m,
        ),
    ] {
        if actual.to_bits() != hex_float(required(pinned, name)?)?.to_bits() {
            return Err(format!("seed immutable lane {name}"));
        }
    }
    if pinned["upstream_lane_id"] != lane.upstream_lane_id
        || pinned["downstream_lane_id"] != lane.downstream_lane_id
    {
        return Err("seed immutable lane topology".into());
    }
    Ok(())
}

pub(super) fn native_authority_joins(
    native: &Value,
    surface: &crate::DirectSurfaceLiquidConfiguration,
    frame: &crate::DirectRunFrame,
    clock: &CoupledClockStateV1,
) -> Result<(), String> {
    DirectV10RealConsumerShadow::diagnostic_validate_inactive_scheduler_from_frozen_litter_v1(
        native, surface, frame, clock,
    )
    .map_err(|error| error.to_string())
}

/// Typed, non-serialized GSI preimages retained only until the consuming
/// deferred native admission is minted.  Receipt hashes alone are insufficient
/// to initialize that admission's exact prior phase.
/// Reader-minted one-use context.  Its fields are private to this member
/// reader; no decoded capture can construct a substitute capability.
pub(crate) struct ValidatedDeferredContextV1 {
    surface_configuration: crate::DirectSurfaceLiquidConfiguration,
    native_digest: openwepp_coupled_time::Digest32,
    soil_digest: openwepp_coupled_time::Digest32,
    clock_digest: openwepp_coupled_time::Digest32,
    phase_digest: openwepp_coupled_time::Digest32,
    lane_maps_digest: openwepp_coupled_time::Digest32,
    bootstrap_digest: openwepp_coupled_time::Digest32,
    frame_digest: openwepp_coupled_time::Digest32,
    constructor_inputs_digest: openwepp_coupled_time::Digest32,
    prior_receipt: crate::runtime_inputs::DirectGsiDailyReceiptV1,
    prepared_receipt: crate::runtime_inputs::DirectGsiDailyReceiptV1,
    prior_state: crate::runtime_inputs::DirectGsiOwnerStateV1,
    prior_cursor: crate::runtime_inputs::SnowFreeHalfHourProviderCursor,
}

/// Borrowed operands only: this record carries no admission authority.
#[derive(Clone, Copy)]
pub(crate) struct DeferredContextOperandsV1<'a> {
    pub native: &'a Value,
    pub soil: &'a crate::v9_real_consumer_shadow::DirectV10SoilThermalResidentV2,
    pub clock: &'a CoupledClockStateV1,
    pub phase: &'a Value,
    pub lane_maps: &'a Value,
    pub bootstrap: &'a crate::v9_real_consumer_shadow::DirectV10SoilThermalResidentV2,
    pub frame: &'a crate::DirectRunFrame,
    pub inputs: &'a crate::DirectRunConstructorInputs,
}

impl ValidatedDeferredContextV1 {
    fn mint(
        operands: &DeferredContextOperandsV1<'_>,
        evidence: AuthenticatedGsiPreimagesV1,
        surface: &crate::DirectSurfaceLiquidConfiguration,
    ) -> Result<Self, String> {
        let DeferredContextOperandsV1 {
            native,
            soil,
            clock,
            phase,
            lane_maps,
            bootstrap,
            frame,
            inputs,
        } = *operands;
        Ok(Self {
            surface_configuration: surface.clone(),
            native_digest: digest_bytes(
                &serde_json::to_vec(native).map_err(|error| error.to_string())?,
            ),
            soil_digest: digest_bytes(
                &serde_json::to_vec(soil).map_err(|error| error.to_string())?,
            ),
            clock_digest: digest_bytes(
                &serde_json::to_vec(clock).map_err(|error| error.to_string())?,
            ),
            phase_digest: digest_bytes(
                &serde_json::to_vec(phase).map_err(|error| error.to_string())?,
            ),
            lane_maps_digest: digest_bytes(
                &serde_json::to_vec(lane_maps).map_err(|error| error.to_string())?,
            ),
            bootstrap_digest: digest_bytes(
                &serde_json::to_vec(bootstrap).map_err(|error| error.to_string())?,
            ),
            frame_digest: digest_bytes(
                &serde_json::to_vec(&capture_direct_run_frame_dynamic(frame, inputs, surface)?)
                    .map_err(|error| error.to_string())?,
            ),
            constructor_inputs_digest: digest_bytes(
                &serde_json::to_vec(&capture_direct_run_constructor_inputs(inputs))
                    .map_err(|error| error.to_string())?,
            ),
            prior_receipt: evidence.prior_receipt,
            prepared_receipt: evidence.prepared_receipt,
            prior_state: evidence.prior_state,
            prior_cursor: evidence.prior_cursor,
        })
    }

    pub(crate) fn validate_bound_v1(
        &self,
        operands: &DeferredContextOperandsV1<'_>,
    ) -> Result<(), String> {
        let DeferredContextOperandsV1 {
            native,
            soil,
            clock,
            phase,
            lane_maps,
            bootstrap,
            frame,
            inputs,
        } = *operands;
        if self.native_digest
            != digest_bytes(&serde_json::to_vec(native).map_err(|error| error.to_string())?)
            || self.soil_digest
                != digest_bytes(&serde_json::to_vec(soil).map_err(|error| error.to_string())?)
            || self.clock_digest
                != digest_bytes(&serde_json::to_vec(clock).map_err(|error| error.to_string())?)
            || self.phase_digest
                != digest_bytes(&serde_json::to_vec(phase).map_err(|error| error.to_string())?)
            || self.lane_maps_digest
                != digest_bytes(&serde_json::to_vec(lane_maps).map_err(|error| error.to_string())?)
            || self.bootstrap_digest
                != digest_bytes(&serde_json::to_vec(bootstrap).map_err(|error| error.to_string())?)
            || self.frame_digest
                != digest_bytes(
                    &serde_json::to_vec(&capture_direct_run_frame_dynamic(
                        frame,
                        inputs,
                        &self.surface_configuration,
                    )?)
                    .map_err(|error| error.to_string())?,
                )
            || self.constructor_inputs_digest
                != digest_bytes(
                    &serde_json::to_vec(&capture_direct_run_constructor_inputs(inputs))
                        .map_err(|error| error.to_string())?,
                )
        {
            return Err("deferred composite source-bound use".into());
        }
        Ok(())
    }

    pub(crate) fn consume_gsi_v1(
        self,
        operands: &DeferredContextOperandsV1<'_>,
        surface: &crate::DirectSurfaceLiquidConfiguration,
    ) -> Result<
        (
            crate::runtime_inputs::DirectGsiDailyReceiptV1,
            crate::runtime_inputs::DirectGsiDailyReceiptV1,
            crate::runtime_inputs::DirectGsiOwnerStateV1,
            crate::runtime_inputs::SnowFreeHalfHourProviderCursor,
        ),
        String,
    > {
        if self
            .surface_configuration
            .canonical_bytes()
            .map_err(|error| error.to_string())?
            != surface
                .canonical_bytes()
                .map_err(|error| error.to_string())?
        {
            return Err("deferred composite source-bound use".into());
        }
        self.validate_bound_v1(operands)?;
        Ok((
            self.prior_receipt,
            self.prepared_receipt,
            self.prior_state,
            self.prior_cursor,
        ))
    }
}

#[derive(Clone, Debug, PartialEq)]
struct AuthenticatedGsiPreimagesV1 {
    prior_receipt: crate::runtime_inputs::DirectGsiDailyReceiptV1,
    prepared_receipt: crate::runtime_inputs::DirectGsiDailyReceiptV1,
    prior_state: crate::runtime_inputs::DirectGsiOwnerStateV1,
    prior_cursor: crate::runtime_inputs::SnowFreeHalfHourProviderCursor,
}
fn validate_authenticated_gsi_preimages(
    seed: &Value,
    native: &Value,
    outer_cursor_canonical_json: &Value,
    provider: &crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
    provider_configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
) -> Result<AuthenticatedGsiPreimagesV1, String> {
    let path = std::env::var_os("OPENWEPP_B01_AUTHENTICATED_GSI_PREIMAGES")
        .ok_or("authenticated GSI preimages path")?;
    let evidence: Value =
        serde_json::from_slice(&std::fs::read(path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    let climate_path = std::env::var_os("OPENWEPP_B01_ORIGINAL_CLIMATE")
        .ok_or("authenticated original climate path")?;
    let climate = parse_climate_file(climate_path, ParserMode::SnowFreeHalfHourProvider)
        .map_err(|_| "authenticated original climate parse")?;
    let climate = crate::runtime_inputs::build_hillslope_climate_runtime_request(&climate)
        .map_err(|_| "authenticated original climate runtime")?;
    validate_authenticated_gsi_preimages_with_evidence(
        seed,
        native,
        outer_cursor_canonical_json,
        provider,
        provider_configuration,
        &evidence,
        &climate,
    )
}

fn validate_authenticated_gsi_preimages_with_evidence(
    seed: &Value,
    native: &Value,
    outer_cursor_canonical_json: &Value,
    provider: &crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
    provider_configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    evidence: &Value,
    climate: &crate::runtime_inputs::HillslopeClimateRuntimeRequest,
) -> Result<AuthenticatedGsiPreimagesV1, String> {
    let receipts: Vec<crate::runtime_inputs::DirectGsiDailyReceiptV1> =
        decode(required(evidence, "committed_prefix")?)?;
    let prepared: crate::runtime_inputs::DirectGsiDailyReceiptV1 =
        decode(required(evidence, "prepared_day4")?)?;
    let (seed_configuration, seed_state) = pinned_gsi(seed)?;
    let native_configuration: crate::runtime_inputs::DirectGsiOwnerConfigurationV1 =
        decode(required(native, "gsi_owner_configuration")?)?;
    let native_state: crate::runtime_inputs::DirectGsiOwnerStateV1 =
        decode(required(native, "gsi_owner_state")?)?;
    crate::runtime_inputs::restart_authority_restore_gsi_state(&native_state)
        .map_err(|error| error.to_string())?;
    let native_cursor_bytes: Vec<u8> = decode(required(native, "provider_cursor_canonical_json")?)?;
    let native_cursor = crate::runtime_inputs::SnowFreeHalfHourProviderCursor::restore_json(
        &native_cursor_bytes,
        provider_configuration,
        B01_DAY_INDEX,
    )
    .map_err(|_| "authenticated native provider cursor")?;
    let outer_cursor_bytes: Vec<u8> = decode(outer_cursor_canonical_json)?;
    let outer_cursor = crate::runtime_inputs::SnowFreeHalfHourProviderCursor::restore_json(
        &outer_cursor_bytes,
        provider_configuration,
        B01_DAY_INDEX,
    )
    .map_err(|_| "authenticated outer provider cursor")?;
    if receipts.len() != B01_DAY_INDEX || prepared.day_index != B01_DAY_INDEX as u64 {
        return Err("authenticated GSI receipt chronology".into());
    }
    for (index, receipt) in receipts.iter().enumerate() {
        receipt
            .validate()
            .map_err(|_| "authenticated committed GSI receipt")?;
        if receipt.day_index != index as u64
            || index > 0 && receipt.beginning_state != receipts[index - 1].ending_state
            || receipt.owner_id != seed_configuration.owner_id
            || receipt.run_id != provider_configuration.run_id
            || receipt.configuration_sha256 != seed_configuration.configuration_sha256
            || receipt.parameters != seed_configuration.parameters
            || receipt.forcing.latitude_degrees.to_bits()
                != seed_configuration.latitude_degrees.to_bits()
        {
            return Err("authenticated committed GSI chain".into());
        }
        if receipt.source_climate_sha256
            != climate
                .diagnostic_source_climate_sha256_v1(index)
                .map_err(|_| "authenticated original climate source")?
        {
            return Err("authenticated original climate source".into());
        }
    }
    prepared
        .validate()
        .map_err(|_| "authenticated prepared GSI receipt")?;
    let prior = receipts.last().ok_or("authenticated committed GSI tail")?;
    if receipts
        .first()
        .is_none_or(|receipt| receipt.beginning_state != seed_state)
    {
        return Err("authenticated GSI bootstrap state".into());
    }
    if native_configuration != seed_configuration
        || provider_configuration.gsi_owner_configuration_sha256
            != seed_configuration.configuration_sha256
    {
        return Err("authenticated native GSI configuration".into());
    }
    if prepared.owner_id != seed_configuration.owner_id
        || prepared.run_id != provider_configuration.run_id
        || prepared.configuration_sha256 != seed_configuration.configuration_sha256
        || prepared.parameters != seed_configuration.parameters
        || prepared.forcing.latitude_degrees.to_bits()
            != seed_configuration.latitude_degrees.to_bits()
        || provider.gsi_receipt() != &prepared
    {
        return Err("authenticated prepared GSI receipt identity".into());
    }
    if provider
        .forcing_receipts()
        .receipts()
        .iter()
        .any(|receipt| {
            receipt.source_climate_sha256 != prepared.source_climate_sha256
                || receipt.run_id != prepared.run_id
        })
    {
        return Err("authenticated prepared GSI climate source".into());
    }
    if prepared.source_climate_sha256
        != climate
            .diagnostic_source_climate_sha256_v1(B01_DAY_INDEX)
            .map_err(|_| "authenticated original climate source")?
    {
        return Err("authenticated original climate source".into());
    }
    if prior.ending_state != prepared.beginning_state {
        return Err("authenticated committed/prepared GSI phase join".into());
    }
    if native_state != prior.ending_state || native_state != provider.gsi_receipt().beginning_state
    {
        return Err("authenticated native GSI state".into());
    }
    if native_cursor != *provider.forcing_receipts().beginning_cursor() {
        return Err("authenticated native provider cursor".into());
    }
    if outer_cursor != native_cursor
        || outer_cursor != *provider.forcing_receipts().beginning_cursor()
    {
        return Err("authenticated outer provider cursor".into());
    }
    if native["provider_gsi_receipt_sha256"] != serde_json::json!(prior.receipt_sha256) {
        return Err("authenticated committed/prepared GSI phase join".into());
    }
    Ok(AuthenticatedGsiPreimagesV1 {
        prior_receipt: prior.clone(),
        prepared_receipt: prepared,
        prior_state: native_state,
        prior_cursor: native_cursor,
    })
}

fn load_row(export: &Path, entry: &Value, omitted: &BTreeSet<&str>) -> Result<Value, String> {
    let path = required(entry, "event_file")?
        .as_str()
        .ok_or("member event path")?;
    let bytes = std::fs::read(export.join(path)).map_err(|error| error.to_string())?;
    if serde_json::to_value(digest_bytes(&bytes)).map_err(|error| error.to_string())?
        != entry["event_file_sha256"]
        || entry["event_file_bytes"].as_u64() != u64::try_from(bytes.len()).ok()
    {
        return Err("member event manifest identity".into());
    }
    decode_member_backed_row_v1(export, &export.join(path), omitted)
}
fn kind(entry: &Value, name: &str) -> bool {
    entry["kinds"] == serde_json::json!([name])
}

#[derive(Serialize)]
struct SnowProjection<'a> {
    schema: &'static str,
    lanes: Vec<(&'a u32, &'a crate::DirectSnowStage3PersistentState)>,
}

fn restore_authenticated_archive_manifest(
    export: &Path,
    entries: &[Value],
    pin: &super::PinnedSeedConfigurationV1,
    vegetation: &openwepp_vegetation::VegetationConfigurationV11,
) -> Result<crate::Stage3CommittedDayArchiveManifestV1, String> {
    let mut manifest =
        crate::Stage3CommittedDayArchiveManifestV1::empty(pin.run_identity, pin.topology_identity)
            .map_err(|error| error.to_string())?;
    let mut previous = None;
    let archives = entries
        .iter()
        .filter(|r| kind(r, "b01_wb14_committed_day_archive_record_v1"))
        .collect::<Vec<_>>();
    if archives.len() != B01_DAY_INDEX {
        return Err("archive member cardinality".into());
    }
    for (index, item) in archives.iter().enumerate() {
        let row = load_row(export, item, &BTreeSet::from(["canonical_record"]))?;
        let entry: crate::Stage3CommittedDayArchiveEntryV1 =
            decode(required(&row, "archive_entry")?)?;
        if entry.day_index != index || row["day_index"] != index {
            return Err("archive recorded order".into());
        }
        let ordinal = required(item, "ordinal")?
            .as_u64()
            .ok_or("archive ordinal")?;
        let bytes = std::fs::read(export.join(format!("rows/{ordinal}.canonical_record.bin")))
            .map_err(|error| error.to_string())?;
        let authenticated = authenticate_archived_day_with_configuration_v1(
            entry.clone(),
            &bytes,
            pin.run_identity,
            pin.topology_identity,
            vegetation,
            &pin.lse,
        )?;
        let publication = &authenticated.publication;
        if let Some((support_count, event_count, authority, ending)) = previous {
            if publication.prefix_support_count != support_count
                || publication.prefix_event_count != event_count
                || publication.prefix_authority_sha256 != authority
                || publication.prefix_ending_owner_set_sha256 != Some(ending)
                || entry.beginning_owner_set_sha256 != ending
            {
                return Err("archive full publication prefix join".into());
            }
        } else if publication.prefix_support_count != 0
            || publication.prefix_event_count != 0
            || publication.prefix_authority_sha256
                != digest_bytes(b"OPENWEPP_ACCEPTED_PUBLICATION_INCREMENTAL_AUTHORITY_V1\0")
            || publication.prefix_ending_owner_set_sha256.is_some()
        {
            return Err("archive genesis publication prefix".into());
        }
        previous = Some((
            publication.cumulative_support_count,
            publication.cumulative_event_count,
            publication.cumulative_authority_sha256,
            publication.ending_owner_set_sha256,
        ));
        manifest.append(entry).map_err(|error| error.to_string())?;
        println!(
            "composed archive day {index}: canonical authentication and ordered manifest PASS"
        );
        // The canonical blob and restored day are dropped before reading the next.
    }
    Ok(manifest)
}

#[cfg(test)]
#[derive(Clone, Copy)]
enum DeferredLifecycleControlV1 {
    None,
    AuditBoundLifecycle,
    #[cfg(feature = "persisted-restart-v1")]
    AuditLateLifecycle,
}

struct NativeRestorationContext<'a> {
    export: &'a Path,
    seed: &'a Value,
    pin: &'a super::PinnedSeedConfigurationV1,
    provider_configuration: &'a crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    day: &'a Value,
    prefix: &'a crate::Stage3ArchivedReceiptPrefixV1,
    clock_parent: &'a super::RestoredSnowFreeClockParentV1,
    lifecycle_control: DeferredLifecycleControlV1,
}

pub(super) fn restore_pinned_surface(
    seed: &Value,
    target: &Value,
    clock: &CoupledClockStateV1,
) -> Result<crate::DirectSurfaceLiquidConfiguration, String> {
    let surface_bytes: Vec<u8> = decode(required(
        target,
        "surface_liquid_configuration_canonical_json",
    )?)?;
    let surface = crate::DirectSurfaceLiquidConfiguration::from_canonical_bytes(&surface_bytes)
        .map_err(|error| error.to_string())?;
    if seed["checkpoint"]["phase"]["committed"]["surface_liquid_configuration"]["configuration_sha256"]
        != surface.configuration_sha256
    {
        return Err("seed surface configuration digest".into());
    }
    let phase = required(target, "phase_diagnostics")?;
    let prefix_surface: Vec<u8> = decode(required(
        phase,
        "prefix_validation_surface_configuration_canonical_json",
    )?)?;
    if prefix_surface != surface_bytes {
        return Err("prefix surface configuration authority join".into());
    }
    validate_snow_free_prefix_membership_v1(target, clock, &surface)?;
    Ok(surface)
}

fn restore_bound_provider(
    day: &Value,
    provider_configuration: &crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
) -> Result<
    (
        crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
        crate::ValidatedPreparedStage3V11DayV1,
    ),
    String,
> {
    let provider = restore_provider_day(
        decode(required(day, "provider_constructor_operands")?)?,
        provider_configuration,
    )?;
    let captures: Vec<PreparedSupportCaptureV1> =
        decode(required(day, "ordered_support_constructor_operands")?)?;
    let supports = captures
        .into_iter()
        .map(|c| restore_prepared_support(c, &provider))
        .collect::<Result<Vec<_>, _>>()?;
    let prepared_day = crate::PreparedStage3V11DayV1::bind_production_provider_day(
        &provider,
        B01_DAY_INDEX,
        supports,
    )
    .map_err(|error| error.to_string())?;
    Ok((provider, prepared_day))
}

fn validate_selected_support(
    target: &Value,
    parent: &crate::DirectSnowStage3V11PreparedSupport,
    clock: &CoupledClockStateV1,
) -> Result<(), String> {
    let parent_support: TimeSupport = decode(required(target, "parent_support")?)?;
    let support: TimeSupport = decode(required(target, "support")?)?;
    let pending = decode(required(
        required(target, "phase_diagnostics")?,
        "pending_terminal_parcels",
    )?)?;
    let ordinal =
        u32::try_from(clock.accepted_slab_receipts().len()).map_err(|error| error.to_string())?;
    let prepared = parent.diagnostic_snow_free_successor_v1(support, ordinal, &pending)?;
    if capture_snow_free_prepared_support(&prepared)?
        != *required(target, "prepared_support_constructor_operands")?
    {
        return Err("snow-free successor provider projection".into());
    }
    if parent.support() != parent_support
        || prepared.support() != support
        || support.start_ns().get() != clock.accepted_until().get()
        || support.start_ns() < parent_support.start_ns()
        || support.end_ns() > parent_support.end_ns()
    {
        return Err("provider selected support/clock position".into());
    }
    Ok(())
}

fn validate_provisional(
    target: &Value,
    parent: &crate::DirectSnowStage3V11PreparedSupport,
    provider: &crate::runtime_inputs::PreparedSnowFreeGsiDayV1,
    clock: &CoupledClockStateV1,
    pin: &super::PinnedSeedConfigurationV1,
) -> Result<(), String> {
    let support: TimeSupport = decode(required(target, "support")?)?;
    let forcing = crate::snow_stage3_v11_attachment::canonical_parent_forcing_digest(
        B01_DAY_INDEX,
        B01_INTERVAL_INDEX,
        provider
            .gsi_receipt_digest()
            .map_err(|error| error.to_string())?,
        parent,
    )
    .map_err(|error| error.to_string())?;
    if target["provisional_constructor_inputs"]["forcing_receipt"] != serde_json::json!(forcing) {
        return Err("native provider forcing join".into());
    }
    let (_, reduction, ledger, receipt) = reconstruct_provisional_on_clone_with_authorities(
        clock,
        support,
        pin.calendar,
        pin.controller_policy,
        forcing,
        "v11-real-consumer",
    )?;
    for (name, actual) in [
        (
            "constraint_reduction_canonical_json",
            serde_json::to_vec(&reduction),
        ),
        (
            "complete_owner_ledger_canonical_json",
            serde_json::to_vec(&ledger),
        ),
        (
            "provisional_receipt_canonical_json",
            serde_json::to_vec(&receipt),
        ),
    ] {
        let expected: Vec<u8> = decode(required(target, name)?)?;
        if actual.map_err(|error| error.to_string())? != expected {
            return Err(format!("native provisional {name}"));
        }
    }
    Ok(())
}

fn restore_native_context(
    entries: &[Value],
    context: &NativeRestorationContext<'_>,
) -> Result<(), String> {
    let export = context.export;
    let seed = context.seed;
    let pin = context.pin;
    let provider_configuration = context.provider_configuration;
    let day = context.day;
    let prefix = context.prefix;
    let clock_parent = context.clock_parent;
    let target_entries = entries
        .iter()
        .filter(|r| kind(r, "b01_wb14_snow_free_pre_child_current_context_v1"))
        .collect::<Vec<_>>();
    let [target_entry] = target_entries.as_slice() else {
        return Err("native target missing or duplicate".into());
    };
    let target = load_row(export, target_entry, &BTreeSet::new())?;
    println!("composed actual native member decoded");
    let inputs =
        constructor_inverse::restore(required(&target, "native_hydrology_constructor_inputs")?)?;
    pin_hydrology(seed, &inputs)?;
    let surface = restore_pinned_surface(seed, &target, &clock_parent.clock)?;
    let (provider, prepared_day) = restore_bound_provider(day, provider_configuration)?;
    let parent = prepared_day
        .supports()
        .get(B01_INTERVAL_INDEX)
        .ok_or("selected parent missing")?;
    validate_selected_support(&target, parent, &clock_parent.clock)?;
    let native = required(&target, "native_consumer_constructor_operands")?;
    let position = prefix
        .next_parent_sequence
        .checked_add(u128::try_from(B01_INTERVAL_INDEX).map_err(|error| error.to_string())?)
        .ok_or("position overflow")?;
    if native["next_day_index"] != B01_DAY_INDEX
        || target["day_index"] != B01_DAY_INDEX
        || target["interval_index"] != B01_INTERVAL_INDEX
    {
        return Err("native outer day/interval join".into());
    }
    let authenticated_gsi = validate_authenticated_gsi_preimages(
        seed,
        native,
        required(&target, "provider_cursor_canonical_json")?,
        &provider,
        provider_configuration,
    )?;
    println!(
        "provider/GSI computation: canonical prepared receipt and original climate-source custody validated; no LSE, soil, or WB14 operation"
    );
    validate_current_phase(&target, &clock_parent.clock, position)?;
    validate_provisional(&target, parent, &provider, &clock_parent.clock, pin)?;
    restore_native_result(
        &target,
        context,
        inputs,
        &surface,
        position,
        authenticated_gsi,
        context.lifecycle_control,
    )
}

fn restore_native_result(
    target: &Value,
    context: &NativeRestorationContext<'_>,
    inputs: crate::DirectRunConstructorInputs,
    surface: &crate::DirectSurfaceLiquidConfiguration,
    position: u128,
    authenticated_gsi: AuthenticatedGsiPreimagesV1,
    lifecycle_control: DeferredLifecycleControlV1,
) -> Result<(), String> {
    let native = required(target, "native_consumer_constructor_operands")?;
    let pin = context.pin;
    let day = context.day;
    let clock_parent = context.clock_parent;
    let provider_configuration = context.provider_configuration;
    let frame = restore_direct_run_frame_dynamic(
        decode(required(
            target,
            "native_hydrology_frame_dynamic_constructor_operands",
        )?)?,
        inputs.clone(),
        surface,
    )?;
    let frozen_lse = pinned_frozen_litter_lse(&pin.lse)?;
    native_authority_joins(native, surface, &frame, &clock_parent.clock)?;
    println!(
        "native inactive physical-counter custody: outer={position}; captured={}; exact frame/native/clock custody PASS; no scalar installation",
        native["accepted_interval_count"]
    );
    println!(
        "native GSI validation: captured={}; authenticated before native custody; no receipt installation",
        native["provider_gsi_receipt_sha256"]
    );
    println!(
        "composed immutable operands, current/deferred phase and provisional checks PASS; invoking canonical native constructor with original unadmitted position/GSI operands"
    );
    let target_soil = decode(required(target, "native_soil_v2_constructor_operands")?)?;
    let committed_bootstrap = decode(required(
        day,
        "native_committed_bootstrap_soil_v2_constructor_operands",
    )?)?;
    let lane_maps_value = required(target, "native_lane_map_constructor_operands")?;
    #[cfg(feature = "persisted-restart-v1")]
    if matches!(
        lifecycle_control,
        DeferredLifecycleControlV1::AuditLateLifecycle
    ) {
        return late_controls::run(&late_controls::Context {
            native,
            soil: &target_soil,
            bootstrap: &committed_bootstrap,
            phase: required(target, "phase_diagnostics")?,
            lane_maps: lane_maps_value,
            clock: &clock_parent.clock,
            frame: &frame,
            inputs: &inputs,
            surface,
            lse: &pin.lse,
            frozen_lse: &frozen_lse,
            provider: provider_configuration,
            gsi: &authenticated_gsi,
        });
    }
    let original_phase = required(target, "phase_diagnostics")?;
    let operands = DeferredContextOperandsV1 {
        native,
        soil: &target_soil,
        clock: &clock_parent.clock,
        phase: original_phase,
        lane_maps: lane_maps_value,
        bootstrap: &committed_bootstrap,
        frame: &frame,
        inputs: &inputs,
    };
    let admission = ValidatedDeferredContextV1::mint(&operands, authenticated_gsi, surface)?;
    let native_before = serde_json::to_vec(native).map_err(|error| error.to_string())?;
    let soil_before = serde_json::to_vec(&target_soil).map_err(|error| error.to_string())?;
    let frame_before =
        serde_json::to_vec(&capture_direct_run_frame_dynamic(&frame, &inputs, surface)?)
            .map_err(|error| error.to_string())?;
    let mut admission_slot = Some(admission);
    if matches!(
        lifecycle_control,
        DeferredLifecycleControlV1::AuditBoundLifecycle
    ) {
        admission_slot
            .as_ref()
            .ok_or("deferred composite capability missing")?
            .validate_bound_v1(&operands)?;
        let bound = admission_slot
            .as_ref()
            .ok_or("deferred composite capability missing")?;
        let mut changed_stage = original_phase.clone();
        changed_stage["current_stage3"] = serde_json::Value::Null;
        assert!(
            bound
                .validate_bound_v1(&DeferredContextOperandsV1 {
                    phase: &changed_stage,
                    ..operands
                })
                .is_err()
        );
        let foreign_native = serde_json::json!({"gsi_owner_state": native["gsi_owner_state"]});
        assert!(
            bound
                .validate_bound_v1(&DeferredContextOperandsV1 {
                    native: &foreign_native,
                    ..operands
                })
                .is_err()
        );
        assert!(
            bound
                .validate_bound_v1(&DeferredContextOperandsV1 {
                    bootstrap: &target_soil,
                    ..operands
                })
                .is_err(),
            "another valid resident cannot replace the committed bootstrap"
        );
        let mut foreign_lanes = lane_maps_value.clone();
        foreign_lanes[0]["lane_id"] = serde_json::json!(u32::MAX);
        assert!(
            bound
                .validate_bound_v1(&DeferredContextOperandsV1 {
                    lane_maps: &foreign_lanes,
                    ..operands
                })
                .is_err()
        );
        let mut changed_frame = frame.clone();
        changed_frame.lanes[0].transfer.surface_carry_m[0] += 0.000_001;
        assert!(
            bound
                .validate_bound_v1(&DeferredContextOperandsV1 {
                    frame: &changed_frame,
                    ..operands
                })
                .is_err(),
            "full dynamic transfer carry is use-bound"
        );
        let mut changed_inputs = inputs.clone();
        changed_inputs.identity.run_id ^= 1;
        assert!(
            bound
                .validate_bound_v1(&DeferredContextOperandsV1 {
                    inputs: &changed_inputs,
                    ..operands
                })
                .is_err()
        );
        let mut altered_phase = original_phase.clone();
        altered_phase["deferred_native_v2_soil_custody"]["posture"] =
            serde_json::json!("installable_capability");
        // A wire posture cannot promote the retained non-owner continuation.
        let refusal = DirectV10RealConsumerShadow::diagnostic_restore_native_consumer_with_deferred_composite_v1(
            native, target_soil.clone(), committed_bootstrap.clone(), &altered_phase,
            lane_maps_value, &clock_parent.clock, frame.clone(), surface,
            &pin.lse, &frozen_lse, provider_configuration, std::sync::Arc::new(inputs.clone()),
            &mut admission_slot,
        );
        assert!(
            matches!(
                refusal,
                Err(
                    crate::v9_real_consumer_shadow::DirectV10RealConsumerError::Runtime(
                        crate::v9_real_consumer_shadow::DirectV9RealConsumerError::Identity(
                            "deferred composite source-bound use"
                        )
                    )
                )
            ),
            "altered phase real-entry refusal"
        );
        assert!(
            admission_slot.is_none(),
            "failed real entry consumes capability"
        );
        let consumed = DirectV10RealConsumerShadow::diagnostic_restore_native_consumer_with_deferred_composite_v1(
            native, target_soil.clone(), committed_bootstrap.clone(), original_phase,
            lane_maps_value, &clock_parent.clock, frame.clone(), surface,
            &pin.lse, &frozen_lse, provider_configuration, std::sync::Arc::new(inputs.clone()),
            &mut admission_slot,
        );
        assert!(
            matches!(
                consumed,
                Err(
                    crate::v9_real_consumer_shadow::DirectV10RealConsumerError::Runtime(
                        crate::v9_real_consumer_shadow::DirectV9RealConsumerError::Identity(
                            "deferred composite capability consumed"
                        )
                    )
                )
            ),
            "consumed real-entry refusal"
        );
        assert_eq!(
            serde_json::to_vec(native).map_err(|error| error.to_string())?,
            native_before
        );
        assert_eq!(
            serde_json::to_vec(&target_soil).map_err(|error| error.to_string())?,
            soil_before
        );
        assert_eq!(
            serde_json::to_vec(&capture_direct_run_frame_dynamic(&frame, &inputs, surface)?)
                .map_err(|error| error.to_string())?,
            frame_before
        );
        return Ok(());
    }
    let native_result =
        DirectV10RealConsumerShadow::diagnostic_restore_native_consumer_with_deferred_composite_v1(
            native,
            target_soil,
            committed_bootstrap,
            required(target, "phase_diagnostics")?,
            lane_maps_value,
            &clock_parent.clock,
            frame,
            surface,
            &pin.lse,
            &frozen_lse,
            provider_configuration,
            std::sync::Arc::new(inputs),
            &mut admission_slot,
        )
        .map_err(|error| format!("private deferred native constructor refusal: {error}"));
    println!(
        "canonical native constructor: {}",
        match &native_result {
            Ok(_) => "accepted original operands".to_owned(),
            Err(error) => error.clone(),
        }
    );
    let consumer = native_result?;
    let expected: BTreeMap<String, Vec<u8>> =
        decode(required(target, "complete_owner_canonical_bytes")?)?;
    let actual = consumer
        .canonical_v11_parent_owner_state_bytes()
        .map_err(|error| error.to_string())?;
    let output =
        std::env::var_os("OPENWEPP_B01_OWNER_COMPARISON_DIR").map(std::path::PathBuf::from);
    owner_comparison::compare(&expected, &actual, output.as_deref())?;
    let restored_inputs = consumer
        .diagnostic_hydrology_constructor_inputs_v1()
        .ok_or("restored native constructor inputs missing")?;
    if serde_json::to_vec(&capture_direct_run_frame_dynamic(
        consumer.restart_authority_hydrology_frame(),
        restored_inputs,
        surface,
    )?)
    .map_err(|error| error.to_string())?
        != frame_before
    {
        return Err("restored native complete dynamic frame".into());
    }
    let expected_cursor: Vec<u8> = decode(required(target, "provider_cursor_canonical_json")?)?;
    if consumer
        .provider_cursor()
        .to_json_bytes()
        .map_err(|error| error.to_string())?
        != expected_cursor
    {
        return Err("restored native provider cursor".into());
    }
    if admission_slot.is_some() {
        return Err("restored native capability not consumed".into());
    }
    println!(
        "restored native: six-owner exact equality, complete LSE clock mode/owner, full dynamic frame, provider cursor and consumed capability PASS; current/deferred and seven-owner clock checks retained"
    );
    Ok(())
}

#[test]
#[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
fn authenticated_gsi_joins_refuse_semantic_substitutions_without_mutating_capture() {
    let _native_audit =
        crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
    let _probe_audit = super::member_backed_restore_tests::ProbeAudit::begin();
    openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
        .install()
        .expect("pinned B01 policy");
    let export = std::path::PathBuf::from(
        std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export"),
    );
    let seed_path = std::path::PathBuf::from(
        std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("bound pinned seed"),
    );
    let seed: Value =
        serde_json::from_slice(&std::fs::read(seed_path).expect("seed bytes")).expect("seed JSON");
    let configuration = pinned_provider(&seed).expect("pinned provider");
    let summary: Value =
        serde_json::from_slice(&std::fs::read(export.join("summary.json")).expect("summary bytes"))
            .expect("summary JSON");
    let day_entry = summary["rows"]
        .as_array()
        .expect("summary rows")
        .iter()
        .find(|entry| kind(entry, "b01_wb14_prepared_day_current_context_v1"))
        .expect("prepared day entry");
    let day = load_row(&export, day_entry, &BTreeSet::new()).expect("prepared day");
    let (provider, _) = restore_bound_provider(&day, &configuration).expect("prepared provider");
    let target_entry = summary["rows"]
        .as_array()
        .expect("summary rows")
        .iter()
        .find(|entry| kind(entry, "b01_wb14_snow_free_pre_child_current_context_v1"))
        .expect("native target entry");
    let target = load_row(&export, target_entry, &BTreeSet::new()).expect("native target");
    let captured_native =
        required(&target, "native_consumer_constructor_operands").expect("native operands");
    let native = serde_json::json!({
        "gsi_owner_configuration": captured_native["gsi_owner_configuration"].clone(),
        "gsi_owner_state": captured_native["gsi_owner_state"].clone(),
        "provider_cursor_canonical_json": captured_native["provider_cursor_canonical_json"].clone(),
        "provider_gsi_receipt_sha256": captured_native["provider_gsi_receipt_sha256"].clone(),
    });
    let outer_cursor = required(&target, "provider_cursor_canonical_json")
        .expect("outer provider cursor")
        .clone();
    drop(target);
    let before = serde_json::to_vec(&native).expect("native capture bytes");
    validate_authenticated_gsi_preimages(&seed, &native, &outer_cursor, &provider, &configuration)
        .expect("authentic GSI joins");

    let mut wrong_state = native.clone();
    wrong_state["gsi_owner_state"] =
        serde_json::to_value(provider.gsi_receipt().ending_state.clone())
            .expect("valid alternate GSI state");
    assert_eq!(
        validate_authenticated_gsi_preimages(
            &seed,
            &wrong_state,
            &outer_cursor,
            &provider,
            &configuration
        ),
        Err("authenticated native GSI state".into())
    );

    let mut wrong_configuration = native.clone();
    let captured_configuration: crate::runtime_inputs::DirectGsiOwnerConfigurationV1 = decode(
        required(&wrong_configuration, "gsi_owner_configuration").expect("GSI configuration"),
    )
    .expect("typed GSI configuration");
    let foreign_configuration = crate::runtime_inputs::DirectGsiOwnerConfigurationV1::try_new(
        "foreign-gsi-owner".into(),
        captured_configuration.parameters(),
        captured_configuration.latitude_degrees,
    )
    .expect("valid foreign GSI configuration");
    wrong_configuration["gsi_owner_configuration"] =
        serde_json::to_value(foreign_configuration).expect("foreign configuration JSON");
    assert_eq!(
        validate_authenticated_gsi_preimages(
            &seed,
            &wrong_configuration,
            &outer_cursor,
            &provider,
            &configuration
        ),
        Err("authenticated native GSI configuration".into())
    );

    let mut wrong_cursor = native.clone();
    wrong_cursor["provider_cursor_canonical_json"] = serde_json::to_value(
        provider
            .forcing_receipts()
            .ending_cursor()
            .to_json_bytes()
            .expect("valid ending cursor"),
    )
    .expect("ending cursor JSON");
    assert_eq!(
        validate_authenticated_gsi_preimages(
            &seed,
            &wrong_cursor,
            &outer_cursor,
            &provider,
            &configuration
        ),
        Err("authenticated native provider cursor".into())
    );

    let wrong_outer_cursor = serde_json::to_value(
        provider
            .forcing_receipts()
            .ending_cursor()
            .to_json_bytes()
            .expect("valid ending cursor"),
    )
    .expect("ending cursor JSON");
    assert_eq!(
        validate_authenticated_gsi_preimages(
            &seed,
            &native,
            &wrong_outer_cursor,
            &provider,
            &configuration
        ),
        Err("authenticated outer provider cursor".into())
    );

    let mut swapped_phase = native.clone();
    swapped_phase["provider_gsi_receipt_sha256"] =
        serde_json::json!(provider.gsi_receipt().receipt_sha256);
    assert_eq!(
        validate_authenticated_gsi_preimages(
            &seed,
            &swapped_phase,
            &outer_cursor,
            &provider,
            &configuration
        ),
        Err("authenticated committed/prepared GSI phase join".into())
    );
    let mut wrong_bootstrap = seed.clone();
    wrong_bootstrap["checkpoint"]["phase"]["committed"]["gsi_state"] =
        serde_json::to_value(provider.gsi_receipt().ending_state.clone())
            .expect("valid alternate bootstrap state");
    assert_eq!(
        validate_authenticated_gsi_preimages(
            &wrong_bootstrap,
            &native,
            &outer_cursor,
            &provider,
            &configuration,
        ),
        Err("authenticated GSI bootstrap state".into())
    );
    let evidence_path = std::env::var_os("OPENWEPP_B01_AUTHENTICATED_GSI_PREIMAGES")
        .expect("authenticated GSI preimages");
    let evidence: Value = serde_json::from_slice(
        &std::fs::read(evidence_path).expect("authenticated GSI preimage bytes"),
    )
    .expect("authenticated GSI preimage JSON");
    let climate_path = std::env::var_os("OPENWEPP_B01_ORIGINAL_CLIMATE").expect("original climate");
    let mut foreign_climate =
        parse_climate_file(climate_path, ParserMode::SnowFreeHalfHourProvider)
            .expect("original climate parse");
    foreign_climate.metadata.elev += 1.0;
    let foreign_climate =
        crate::runtime_inputs::build_hillslope_climate_runtime_request(&foreign_climate)
            .expect("foreign climate runtime");
    assert_eq!(
        validate_authenticated_gsi_preimages_with_evidence(
            &seed,
            &native,
            &outer_cursor,
            &provider,
            &configuration,
            &evidence,
            &foreign_climate,
        ),
        Err("authenticated original climate source".into())
    );
    assert_eq!(
        serde_json::to_vec(&native).expect("native capture bytes"),
        before
    );
    let gsi_work = crate::runtime_inputs::gsi_receipt_advance_audit_v1();
    assert_eq!(
        gsi_work.prepare_advances, 0,
        "receipt validation does not prepare another day"
    );
    assert!(
        gsi_work.validator_advances > 0,
        "canonical GSI validation is measured computation"
    );
}

#[test]
#[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
fn ordinary_native_soil_admission_refuses_actual_deferred_context_without_mutation() {
    let _native_audit =
        crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
    let _probe_audit = super::member_backed_restore_tests::ProbeAudit::begin();
    openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
        .install()
        .expect("pinned B01 policy");
    let export = std::path::PathBuf::from(
        std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("bound member export"),
    );
    let seed_path = std::path::PathBuf::from(
        std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("bound pinned seed"),
    );
    let restored =
        restore_snow_free_clock_parent_from_member_export(&export).expect("actual member clock");
    let summary: Value =
        serde_json::from_slice(&std::fs::read(export.join("summary.json")).expect("summary bytes"))
            .expect("summary JSON");
    let target_entry = summary["rows"]
        .as_array()
        .expect("summary rows")
        .iter()
        .find(|entry| kind(entry, "b01_wb14_snow_free_pre_child_current_context_v1"))
        .expect("native target entry");
    let target = load_row(&export, target_entry, &BTreeSet::new()).expect("actual native target");
    let day = decode_member_backed_row_v1(
        &export,
        &export.join("rows/108033.events.jsonl"),
        &BTreeSet::new(),
    )
    .expect("actual bootstrap day");
    let pin = extract_pinned_seed_configuration_v1(&seed_path).expect("pinned seed configuration");
    let native =
        required(&target, "native_consumer_constructor_operands").expect("native operands");
    let vegetation: openwepp_vegetation::V10CoupledOwnedState =
        decode(required(native, "vegetation_state").expect("vegetation state"))
            .expect("typed vegetation state");
    let next_day: usize =
        decode(required(native, "next_day_index").expect("next day")).expect("typed next day");
    let inputs = constructor_inverse::restore(
        required(&target, "native_hydrology_constructor_inputs").expect("native inputs"),
    )
    .expect("typed native inputs");
    let resident: crate::v9_real_consumer_shadow::DirectV10SoilThermalResidentV2 =
        decode(required(&target, "native_soil_v2_constructor_operands").expect("resident"))
            .expect("typed resident");
    let bootstrap: crate::v9_real_consumer_shadow::DirectV10SoilThermalResidentV2 = decode(
        required(
            &day,
            "native_committed_bootstrap_soil_v2_constructor_operands",
        )
        .expect("bootstrap"),
    )
    .expect("typed bootstrap");
    let resident_before = serde_json::to_vec(&resident).expect("resident bytes");
    let bootstrap_before = serde_json::to_vec(&bootstrap).expect("bootstrap bytes");
    let clock_before = serde_json::to_vec(&restored.clock).expect("clock bytes");
    assert!(matches!(
        crate::v9_real_consumer_shadow::NativeSoilRestartAdmissionV1::authenticate(
            &resident,
            &bootstrap,
            &pin.lse,
            &pin.lse.soil_thermal_configuration.owner_id,
            &pin.lse.soil_thermal_configuration.configuration_sha256,
            &resident.owner().run_id,
            &restored.clock,
            crate::v9_real_consumer_shadow::NativeSoilRestartPositionV1::InProgressSupportCurrent,
            vegetation.0.last_transaction_id,
            next_day,
            inputs.identity.run_id,
        ),
        Err(
            crate::v9_real_consumer_shadow::DirectV9RealConsumerError::Identity(
                "native soil proof accepted support or exact bootstrap"
            )
        )
    ));
    assert_eq!(
        serde_json::to_vec(&resident).expect("resident bytes"),
        resident_before
    );
    assert_eq!(
        serde_json::to_vec(&bootstrap).expect("bootstrap bytes"),
        bootstrap_before
    );
    assert_eq!(
        serde_json::to_vec(&restored.clock).expect("clock bytes"),
        clock_before
    );
}

#[test]
#[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
fn inactive_counter_custody_refuses_actual_member_substitutions_without_installation() {
    let _native_audit =
        crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
    let _probe_audit = super::member_backed_restore_tests::ProbeAudit::begin();
    openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
        .install()
        .expect("B01 policy");
    let export =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("export"));
    let seed =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("seed"));
    let restored =
        restore_snow_free_clock_parent_from_member_export(&export).expect("actual clock");
    let summary: Value =
        serde_json::from_slice(&std::fs::read(export.join("summary.json")).expect("summary bytes"))
            .expect("summary JSON");
    let target_entry = summary["rows"]
        .as_array()
        .expect("summary rows")
        .iter()
        .find(|entry| kind(entry, "b01_wb14_snow_free_pre_child_current_context_v1"))
        .expect("native target entry");
    let target = load_row(&export, target_entry, &BTreeSet::new()).expect("actual native target");
    let seed_value: Value =
        serde_json::from_slice(&std::fs::read(&seed).expect("seed bytes")).expect("seed JSON");
    let inputs = constructor_inverse::restore(
        required(&target, "native_hydrology_constructor_inputs").expect("inputs"),
    )
    .expect("typed inputs");
    pin_hydrology(&seed_value, &inputs).expect("pinned hydrology");
    let surface =
        restore_pinned_surface(&seed_value, &target, &restored.clock).expect("pinned surface");
    let frame = restore_direct_run_frame_dynamic(
        decode(
            required(
                &target,
                "native_hydrology_frame_dynamic_constructor_operands",
            )
            .expect("frame"),
        )
        .expect("typed dynamic frame"),
        inputs,
        &surface,
    )
    .expect("restored frame");
    let captured = required(&target, "native_consumer_constructor_operands").expect("native");
    let mut native = serde_json::json!({
        "frozen_litter_residents": captured["frozen_litter_residents"].clone(),
        "accepted_interval_count": captured["accepted_interval_count"].clone(),
        "wb14_parent": captured["wb14_parent"].clone(),
    });
    drop(target);
    let frame_before = frame
        .surface_liquid_shadow
        .as_ref()
        .expect("surface")
        .canonical_bytes(&surface)
        .expect("frame bytes");
    let before = serde_json::to_vec(&native).expect("native bytes");
    DirectV10RealConsumerShadow::diagnostic_validate_inactive_scheduler_from_frozen_litter_v1(
        &native,
        &surface,
        &frame,
        &restored.clock,
    )
    .expect("actual counter zero at outer position retains inactive custody");
    assert_eq!(native["accepted_interval_count"], serde_json::json!(0));
    native["accepted_interval_count"] = serde_json::json!(1);
    assert!(matches!(
        DirectV10RealConsumerShadow::diagnostic_validate_inactive_scheduler_from_frozen_litter_v1(
            &native,
            &surface,
            &frame,
            &restored.clock,
        ),
        Err(
            crate::v9_real_consumer_shadow::DirectV10RealConsumerError::Runtime(
                crate::v9_real_consumer_shadow::DirectV9RealConsumerError::Identity(
                    "native inactive scheduler count or WB14"
                )
            )
        )
    ));
    native["accepted_interval_count"] = serde_json::json!(0);
    native["wb14_parent"] = serde_json::json!([1_u8]);
    assert!(matches!(
        DirectV10RealConsumerShadow::diagnostic_validate_inactive_scheduler_from_frozen_litter_v1(
            &native,
            &surface,
            &frame,
            &restored.clock,
        ),
        Err(
            crate::v9_real_consumer_shadow::DirectV10RealConsumerError::Runtime(
                crate::v9_real_consumer_shadow::DirectV9RealConsumerError::Identity(
                    "native inactive scheduler count or WB14"
                )
            )
        )
    ));
    native["wb14_parent"] = serde_json::Value::Null;
    for (case, expected) in [
        (0, "native inactive scheduler exact continuation"),
        (1, "native inactive scheduler frame surface"),
        (2, "native inactive scheduler count or WB14"),
    ] {
        let mut foreign_frame = frame.clone();
        match case {
            0 => {
                foreign_frame
                    .surface_liquid_shadow
                    .as_mut()
                    .expect("surface")
                    .continuations[0]
                    .day_index = 1;
            }
            1 => {
                foreign_frame
                    .surface_liquid_shadow
                    .as_mut()
                    .expect("surface")
                    .continuations[0]
                    .cumulative_supply_m = -0.0;
            }
            _ => foreign_frame.identity.run_id += 1,
        }
        if case == 0 {
            let state = foreign_frame
                .surface_liquid_shadow
                .as_mut()
                .expect("surface");
            state.state_sha256 = state
                .recomputed_sha256()
                .expect("canonical foreign history seal");
            state
                .validate(&surface)
                .expect("self-validating foreign day history");
        }
        let result = DirectV10RealConsumerShadow::diagnostic_validate_inactive_scheduler_from_frozen_litter_v1(
            &native, &surface, &foreign_frame, &restored.clock,
        );
        assert!(
            matches!(result, Err(crate::v9_real_consumer_shadow::DirectV10RealConsumerError::Runtime(
            crate::v9_real_consumer_shadow::DirectV9RealConsumerError::Identity(actual)
        )) if actual == expected),
            "counter poison {case}: {result:?}"
        );
    }
    assert_eq!(
        frame
            .surface_liquid_shadow
            .as_ref()
            .expect("surface")
            .canonical_bytes(&surface)
            .expect("frame bytes"),
        frame_before
    );
    assert_eq!(serde_json::to_vec(&native).expect("native bytes"), before);
}

#[test]
#[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
fn actual_member_frozen_litter_history_preflight_is_pure() {
    let _native_audit =
        crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
    let _probe_audit = super::member_backed_restore_tests::ProbeAudit::begin();
    openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
        .install()
        .expect("B01 policy");
    let export =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("export"));
    let seed_path =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("seed"));
    let restored =
        restore_snow_free_clock_parent_from_member_export(&export).expect("actual clock");
    let summary: Value =
        serde_json::from_slice(&std::fs::read(export.join("summary.json")).expect("summary bytes"))
            .expect("summary JSON");
    let target_entry = summary["rows"]
        .as_array()
        .expect("summary rows")
        .iter()
        .find(|entry| kind(entry, "b01_wb14_snow_free_pre_child_current_context_v1"))
        .expect("native target entry");
    let target = load_row(&export, target_entry, &BTreeSet::new()).expect("actual native target");
    let seed: Value =
        serde_json::from_slice(&std::fs::read(&seed_path).expect("seed bytes")).expect("seed JSON");
    let pin = extract_pinned_seed_configuration_v1(&seed_path).expect("pinned seed");
    let surface = restore_pinned_surface(&seed, &target, &restored.clock).expect("pinned surface");
    let native = serde_json::json!({
        "frozen_litter_residents": target["native_consumer_constructor_operands"]["frozen_litter_residents"].clone(),
    });
    drop(target);
    let before = serde_json::to_vec(&native).expect("native projection bytes");
    assert!(matches!(
        DirectV10RealConsumerShadow::diagnostic_preflight_frozen_litter_residents_v1(
            &native, &pin.lse, &surface,
        ),
        Err(
            crate::v9_real_consumer_shadow::DirectV10RealConsumerError::Runtime(
                crate::v9_real_consumer_shadow::DirectV9RealConsumerError::Identity(
                    "diagnostic frozen-litter LSE configuration/pinned authority join"
                )
            )
        )
    ));
    let frozen_lse = pinned_frozen_litter_lse(&pin.lse).expect("canonical V3 frozen pin");
    DirectV10RealConsumerShadow::diagnostic_preflight_frozen_litter_residents_v1(
        &native,
        &frozen_lse,
        &surface,
    )
    .expect("complete retained frozen-litter history preflight");
    assert_eq!(
        serde_json::to_vec(&native).expect("native projection bytes"),
        before
    );
}

#[test]
#[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
fn deferred_context_lifecycle_controls_refuse_without_publication() {
    let _native_audit =
        crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
    let _probe_audit = super::member_backed_restore_tests::ProbeAudit::begin();
    openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
        .install()
        .expect("B01 policy");
    let export =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("export"));
    let seed =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("seed"));
    restore_with_control(
        &export,
        &seed,
        DeferredLifecycleControlV1::AuditBoundLifecycle,
    )
    .expect("real reader lifecycle refusals complete without publication");
}

pub(super) fn restore(export: &Path, seed_path: &Path) -> Result<(), String> {
    restore_with_control(export, seed_path, DeferredLifecycleControlV1::None)
}

#[cfg(test)]
fn restore_with_control(
    export: &Path,
    seed_path: &Path,
    lifecycle_control: DeferredLifecycleControlV1,
) -> Result<(), String> {
    let primitives_path = std::env::var_os("OPENWEPP_B01_RETAINED_SOIL_TRIAL_PRIMITIVES")
        .ok_or("retained soil primitive artifact path")?;
    let subslabs_path = std::env::var_os("OPENWEPP_B01_RETAINED_SUBSLAB_PRIMITIVES")
        .ok_or("retained subslab artifact path")?;
    let primitives: Value =
        serde_json::from_slice(&std::fs::read(primitives_path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    let subslabs: Value =
        serde_json::from_slice(&std::fs::read(subslabs_path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    super::member_backed_restore_tests::validate_b01_retained_soil_trial_correspondence_v1(
        export,
        &primitives,
        &subslabs,
    )?;
    let seed: Value =
        serde_json::from_slice(&std::fs::read(seed_path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    let pin = extract_pinned_seed_configuration_v1(seed_path)?;
    let provider_configuration = pinned_provider(&seed)?;
    let summary: Value = serde_json::from_slice(
        &std::fs::read(export.join("summary.json")).map_err(|error| error.to_string())?,
    )
    .map_err(|error| error.to_string())?;
    if summary["status"] != "COMPLETE" {
        return Err("member export incomplete".into());
    }
    let entries = required(&summary, "rows")?
        .as_array()
        .ok_or("member rows")?;
    let day_entries = entries
        .iter()
        .filter(|r| kind(r, "b01_wb14_prepared_day_current_context_v1"))
        .collect::<Vec<_>>();
    let [day_entry] = day_entries.as_slice() else {
        return Err("prepared day missing or duplicate".into());
    };
    let day = load_row(export, day_entry, &BTreeSet::new())?;
    if day["day_index"] != B01_DAY_INDEX
        || day["static_run_identity"] != serde_json::json!(pin.run_identity)
        || day["static_topology_identity"] != serde_json::json!(pin.topology_identity)
    {
        return Err("prepared day seed identity".into());
    }
    let clock_parent = restore_snow_free_clock_parent_from_member_export(export)?;
    let vegetation_bytes: Vec<u8> = decode(required(
        &clock_parent.recorded_row,
        "vegetation_configuration_canonical_json",
    )?)?;
    let vegetation: openwepp_vegetation::VegetationConfigurationV11 =
        serde_json::from_slice(&vegetation_bytes).map_err(|error| error.to_string())?;
    if vegetation.imported_v10 != pin.vegetation {
        return Err("seed vegetation configuration".into());
    }
    vegetation.validate().map_err(|error| error.to_string())?;
    let manifest = restore_authenticated_archive_manifest(export, entries, &pin, &vegetation)?;
    let prefix: crate::Stage3ArchivedReceiptPrefixV1 =
        decode(required(&day, "archived_receipt_prefix")?)?;
    prefix.validate().map_err(|error| error.to_string())?;
    let committed_bytes: Vec<u8> =
        decode(required(&day, "committed_clock_restart_canonical_json")?)?;
    let committed = restore_coupled_clock(
        &committed_bytes,
        digest_bytes(CLOCK_MODEL_DOMAIN),
        digest_bytes(CLOCK_AUTHORITY_DOMAIN),
        pin.controller_policy,
    )?
    .clock()
    .clone();
    if prefix.run_identity != pin.run_identity
        || prefix.topology_identity != pin.topology_identity
        || prefix.archived_day_count != manifest.committed_day_count
        || prefix.ordered_day_chain_sha256 != manifest.ordered_day_chain_sha256
        || prefix.archive_content_root_sha256 != manifest.archive_content_root_sha256
        || prefix.accepted_until_ns != committed.accepted_until().get()
        || prefix.ending_owner_set_sha256
            != Some(
                complete_owner_set_digest(committed.owners()).map_err(|error| error.to_string())?,
            )
        || day["committed_next_parent_sequence"] != serde_json::json!(prefix.next_parent_sequence)
        || day["committed_receipt_tail_count"] != 0
    {
        return Err("archive prepared-day prefix join".into());
    }
    println!("composed archive/provider prefix PASS");
    restore_native_context(
        entries,
        &NativeRestorationContext {
            export,
            seed: &seed,
            pin: &pin,
            provider_configuration: &provider_configuration,
            day: &day,
            prefix: &prefix,
            clock_parent: &clock_parent,
            lifecycle_control,
        },
    )?;
    Ok(())
}

pub(super) fn validate_current_phase(
    target: &Value,
    clock: &CoupledClockStateV1,
    position: u128,
) -> Result<(), String> {
    let phase = required(target, "phase_diagnostics")?;
    let current: BTreeMap<u32, crate::DirectSnowStage3PersistentState> =
        decode(required(phase, "current_stage3")?)?;
    if current.is_empty()
        || current
            .values()
            .any(|state| u128::from(state.next_interval_index) != position)
    {
        return Err("current Stage3 accepted position".into());
    }
    let material: Option<
        crate::snow_stage3_v11_snow_enthalpy_carry::AuthenticatedCoveredSnowMaterialOwnerV1,
    > = decode(required(phase, "current_snow_enthalpy_material_owner")?)?;
    if let Some(owner) = material {
        owner.validate().map_err(|error| error.to_string())?;
        if owner.base_material_owner() != &current {
            return Err("current snow material/base state".into());
        }
    }
    let ending_bytes: Vec<u8> = decode(required(phase, "ending_snow_owner_canonical_bytes")?)?;
    let projected = serde_json::to_vec(&SnowProjection {
        schema: "OPENWEPP_STAGE3_CANONICAL_SNOW_OWNER_V1",
        lanes: current.iter().collect(),
    })
    .map_err(|error| error.to_string())?;
    if projected != ending_bytes {
        return Err("current Stage3 ending snow projection".into());
    }
    validate_current_snow_custody(target, phase, clock, &current)?;
    let expected_clock: BTreeMap<String, Vec<u8>> =
        decode(required(target, "clock_complete_owner_canonical_bytes")?)?;
    let actual_clock = clock
        .owners()
        .iter()
        .map(|o| (o.owner_id().to_owned(), o.state_bytes().to_vec()))
        .collect::<BTreeMap<_, _>>();
    if expected_clock != actual_clock {
        return Err("current seven-owner clock projection".into());
    }
    validate_deferred_custody(target, clock)?;
    Ok(())
}

fn validate_current_snow_custody(
    target: &Value,
    phase: &Value,
    clock: &CoupledClockStateV1,
    current: &BTreeMap<u32, crate::DirectSnowStage3PersistentState>,
) -> Result<(), String> {
    let parcels: BTreeMap<
        openwepp_coupled_time::Digest32,
        crate::DirectSnowStage3V11TerminalParcel,
    > = decode(required(phase, "pending_terminal_parcels")?)?;
    let captured_bytes: Vec<u8> = decode(required(
        target,
        "terminal_parcels_produced_unconsumed_canonical_json",
    )?)?;
    let captured_parcels: BTreeMap<
        openwepp_coupled_time::Digest32,
        crate::DirectSnowStage3V11TerminalParcel,
    > = serde_json::from_slice(&captured_bytes).map_err(|error| error.to_string())?;
    if parcels != captured_parcels
        || parcels.iter().any(|(digest, parcel)| {
            parcel.posture != crate::DirectSnowStage3V11TerminalParcelPosture::ProducedUnconsumed
                || parcel.parent_transaction_id != clock.parent_transaction_id().digest()
                || parcel.support.start_ns() < clock.parent_support().start_ns()
                || parcel.support.end_ns() > clock.accepted_until()
                || crate::snow_owner_v4::canonical_terminal_parcel_digest(parcel)
                    .map_or(true, |actual| {
                        actual != *digest || actual != parcel.parcel_digest
                    })
        })
    {
        return Err("current terminal parcel custody posture".into());
    }
    let joins =
        crate::snow_stage3_v11_attachment::diagnostic_restore_coupled_subslab_receipts_value_v2(
            required(phase, "ordered_owner_joins")?.clone(),
        )?;
    let last = joins.last().ok_or("current snow prefix tail")?;
    let lanes = last
        .lane_receipts
        .iter()
        .map(|(lane, receipt)| (*lane, receipt.receipt_sha256))
        .collect();
    let tiles = last
        .destination_receipts
        .iter()
        .map(|((ofe, tile), receipt)| {
            (
                (ofe.as_str().to_owned(), tile.as_str().to_owned()),
                *receipt.receipt_sha256(),
            )
        })
        .collect();
    let expected = crate::snow_owner_v4::canonical_stage3_snow_owner_v4_bytes(
        current, &parcels, &lanes, &tiles,
    )
    .map_err(|error| error.0.to_owned())?;
    let snow = clock
        .owners()
        .iter()
        .find(|owner| owner.owner_id() == "snow")
        .ok_or("clock snow owner")?;
    if expected != snow.state_bytes() {
        return Err("current Stage3 clock snow owner projection".into());
    }
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "snake_case")]
enum TrialPredecessor {
    AcceptedReceiptChain(openwepp_land_surface_energy::Sha256Digest),
    UnpublishedTrial(openwepp_land_surface_energy::Sha256Digest),
    NumericalCoordinateProjection {
        authority_sha256: openwepp_land_surface_energy::Sha256Digest,
        accepted_receipt_chain_sha256: openwepp_land_surface_energy::Sha256Digest,
        coordinate_set_sha256: openwepp_land_surface_energy::Sha256Digest,
    },
}
// Representation inverse only: no numerical evolution or install capability.
fn validate_trial(
    value: &Value,
) -> Result<openwepp_land_surface_energy::SoilThermalOwnedStateV2, String> {
    use openwepp_kernel_contract::TransactionId;
    use openwepp_land_surface_energy::{
        Sha256Digest, SoilThermalLayerEnergyCreditV2, SoilThermalOwnedStateV2,
    };
    let accepted: Option<Sha256Digest> = decode(required(
        value,
        "accepted_predecessor_receipt_chain_sha256",
    )?)?;
    let unpublished: Option<Sha256Digest> =
        decode(required(value, "unpublished_predecessor_trial_sha256")?)?;
    let authority: Option<Sha256Digest> =
        decode(required(value, "numerical_coordinate_authority_sha256")?)?;
    let coordinate: Option<Sha256Digest> =
        decode(required(value, "numerical_coordinate_set_sha256")?)?;
    let custody = match (accepted, unpublished, authority, coordinate) {
        (Some(a), None, None, None) => TrialPredecessor::AcceptedReceiptChain(a),
        (None, Some(u), None, None) => TrialPredecessor::UnpublishedTrial(u),
        (Some(a), None, Some(authority), Some(coordinate)) => {
            TrialPredecessor::NumericalCoordinateProjection {
                authority_sha256: authority,
                accepted_receipt_chain_sha256: a,
                coordinate_set_sha256: coordinate,
            }
        }
        _ => return Err("deferred trial predecessor custody".into()),
    };
    let transaction: TransactionId = decode(required(value, "transaction_id")?)?;
    let predecessor: Option<TransactionId> =
        decode(required(value, "predecessor_transaction_id")?)?;
    let start: u128 = decode(required(value, "support_start_ns")?)?;
    let end: u128 = decode(required(value, "support_end_ns")?)?;
    let beginning: Sha256Digest = decode(required(value, "beginning_state_sha256")?)?;
    let ending: SoilThermalOwnedStateV2 = decode(required(value, "ending_state")?)?;
    let credits: Vec<SoilThermalLayerEnergyCreditV2> = decode(required(value, "layer_credits")?)?;
    ending.validate().map_err(|error| error.to_string())?;
    if start >= end || ending.last_accepted_transaction_id != Some(transaction) {
        return Err("deferred trial transaction/support".into());
    }
    let bytes = serde_json::to_vec(&(
        "OPENWEPP_SOIL_THERMAL_UNPUBLISHED_TRIAL_V2",
        transaction,
        predecessor,
        start,
        end,
        beginning,
        custody,
        &ending,
        credits,
    ))
    .map_err(|error| error.to_string())?;
    if serde_json::to_value(digest_bytes(&python_exponents(&bytes)))
        .map_err(|error| error.to_string())?
        != value["unpublished_trial_sha256"]
    {
        return Err("deferred unpublished trial seal".into());
    }
    Ok(ending)
}
// Exact digest representation rule from land_surface_energy::identity.
fn python_exponents(bytes: &[u8]) -> Vec<u8> {
    let mut output = Vec::with_capacity(bytes.len());
    let (mut quoted, mut escaped, mut index) = (false, false, 0);
    while index < bytes.len() {
        let byte = bytes[index];
        if quoted {
            output.push(byte);
            if escaped {
                escaped = false;
            } else if byte == b'\\' {
                escaped = true;
            } else if byte == b'"' {
                quoted = false;
            }
            index += 1;
            continue;
        }
        if byte == b'"' {
            quoted = true;
            output.push(byte);
            index += 1;
            continue;
        }
        if byte == b'e'
            && index + 3 < bytes.len()
            && matches!(bytes[index + 1], b'+' | b'-')
            && bytes[index + 2].is_ascii_digit()
            && !bytes[index + 3].is_ascii_digit()
        {
            output.extend_from_slice(&[byte, bytes[index + 1], b'0', bytes[index + 2]]);
            index += 3;
            continue;
        }
        output.push(byte);
        index += 1;
    }
    output
}
fn replay_deferred_ordered_state_chain(
    original: &openwepp_land_surface_energy::SoilThermalOwnerEnvelopeV2,
    chain: &[Vec<openwepp_land_surface_energy::SoilThermalLayerEnergyCreditV2>],
    trial: &Value,
) -> Result<openwepp_land_surface_energy::SoilThermalOwnedStateV2, String> {
    let mut state = original.state.clone();
    for (index, credits) in chain.iter().enumerate() {
        if index + 1 == chain.len()
            && serde_json::to_value(&state.state_sha256).map_err(|error| error.to_string())?
                != trial["beginning_state_sha256"]
        {
            return Err("deferred final trial beginning state".into());
        }
        let layer_count = state
            .ofes
            .iter()
            .map(|ofe| ofe.ordered_layers.len())
            .sum::<usize>();
        if credits.len() != layer_count {
            return Err("deferred layer chain cardinality".into());
        }
        for ((ofe_id, layer), credit) in state
            .ofes
            .iter_mut()
            .flat_map(|ofe| {
                ofe.ordered_layers
                    .iter_mut()
                    .map(|layer| (&ofe.ofe_id, layer))
            })
            .zip(credits)
        {
            if ofe_id != &credit.ofe_id
                || layer.layer_id != credit.layer_id
                || layer.enthalpy_hi_j_m2_ofe_ground.to_bits()
                    != credit.beginning_enthalpy_hi_j_m2_ofe_ground.to_bits()
                || layer.enthalpy_carry != credit.beginning_enthalpy_carry
                || layer.temperature_k.to_bits() != credit.beginning_temperature_k.to_bits()
            {
                return Err("deferred ordered layer beginning".into());
            }
            layer.enthalpy_hi_j_m2_ofe_ground = credit.ending_enthalpy_hi_j_m2_ofe_ground;
            layer.enthalpy_carry = credit.ending_enthalpy_carry.clone();
            layer.temperature_k = credit.ending_temperature_k;
            layer.last_accepted_transaction_id = Some(openwepp_kernel_contract::TransactionId(
                original
                    .transaction_id
                    .0
                    .checked_add(u128::try_from(index).map_err(|error| error.to_string())?)
                    .ok_or("deferred transaction overflow")?,
            ));
        }
        state.last_accepted_transaction_id = Some(openwepp_kernel_contract::TransactionId(
            original
                .transaction_id
                .0
                .checked_add(u128::try_from(index).map_err(|error| error.to_string())?)
                .ok_or("deferred transaction overflow")?,
        ));
        state.reseal().map_err(|error| error.to_string())?;
        state.validate().map_err(|error| error.to_string())?;
    }
    Ok(state)
}

/// Test-only inverse of the private unpublished-trial seal chain.  This
/// reconstructs typed state and canonical tuple bytes only; it never invokes
/// a physical map, an accepted-child advance, or an owner installation.
#[cfg(test)]
pub(super) fn replay_deferred_unpublished_trial_seals_v1(
    original: &openwepp_land_surface_energy::SoilThermalOwnerEnvelopeV2,
    chain: &[Vec<openwepp_land_surface_energy::SoilThermalLayerEnergyCreditV2>],
    supports: &[(u128, u128)],
) -> Result<Vec<openwepp_land_surface_energy::Sha256Digest>, String> {
    use openwepp_kernel_contract::TransactionId;
    use openwepp_land_surface_energy::Sha256Digest;

    if chain.is_empty() || chain.len() != supports.len() {
        return Err("deferred seal replay cardinality".into());
    }
    let mut state = original.state.clone();
    let mut seals: Vec<Sha256Digest> = Vec::with_capacity(chain.len());
    for (index, (credits, (start, end))) in chain.iter().zip(supports).enumerate() {
        if start >= end || end - start < openwepp_land_surface_energy::MINIMUM_SUPPORT_NS {
            return Err("deferred seal replay support".into());
        }
        if index > 0 && supports[index - 1].1 != *start {
            return Err("deferred seal replay support continuity".into());
        }
        let layer_count = state
            .ofes
            .iter()
            .map(|ofe| ofe.ordered_layers.len())
            .sum::<usize>();
        if credits.len() != layer_count {
            return Err("deferred seal replay layer cardinality".into());
        }
        let beginning = state.state_sha256.clone();
        let transaction = TransactionId(
            original
                .transaction_id
                .0
                .checked_add(u128::try_from(index).map_err(|error| error.to_string())?)
                .ok_or("deferred seal replay transaction overflow")?,
        );
        for ((ofe_id, layer), credit) in state
            .ofes
            .iter_mut()
            .flat_map(|ofe| {
                ofe.ordered_layers
                    .iter_mut()
                    .map(|layer| (&ofe.ofe_id, layer))
            })
            .zip(credits)
        {
            if ofe_id != &credit.ofe_id
                || layer.layer_id != credit.layer_id
                || layer.enthalpy_hi_j_m2_ofe_ground.to_bits()
                    != credit.beginning_enthalpy_hi_j_m2_ofe_ground.to_bits()
                || layer.enthalpy_carry != credit.beginning_enthalpy_carry
                || layer.temperature_k.to_bits() != credit.beginning_temperature_k.to_bits()
            {
                return Err("deferred seal replay ordered layer beginning".into());
            }
            layer.enthalpy_hi_j_m2_ofe_ground = credit.ending_enthalpy_hi_j_m2_ofe_ground;
            layer.enthalpy_carry = credit.ending_enthalpy_carry.clone();
            layer.temperature_k = credit.ending_temperature_k;
            layer.last_accepted_transaction_id = Some(transaction);
        }
        state.last_accepted_transaction_id = Some(transaction);
        state.reseal().map_err(|error| error.to_string())?;
        state.validate().map_err(|error| error.to_string())?;
        let predecessor = if index == 0 {
            TrialPredecessor::AcceptedReceiptChain(original.receipt_chain_sha256.clone())
        } else {
            TrialPredecessor::UnpublishedTrial(seals[index - 1].clone())
        };
        let previous_transaction = if index == 0 {
            original.expected_predecessor_transaction_id
        } else {
            Some(TransactionId(
                transaction
                    .0
                    .checked_sub(1)
                    .ok_or("deferred seal replay predecessor underflow")?,
            ))
        };
        let bytes = serde_json::to_vec(&(
            "OPENWEPP_SOIL_THERMAL_UNPUBLISHED_TRIAL_V2",
            transaction,
            previous_transaction,
            *start,
            *end,
            beginning,
            predecessor,
            &state,
            credits,
        ))
        .map_err(|error| error.to_string())?;
        let seal: Sha256Digest = serde_json::from_value(
            serde_json::to_value(digest_bytes(&python_exponents(&bytes)))
                .map_err(|error| error.to_string())?,
        )
        .map_err(|error| error.to_string())?;
        seals.push(seal);
    }
    Ok(seals)
}

fn validate_deferred_custody(target: &Value, clock: &CoupledClockStateV1) -> Result<(), String> {
    let custody = required(
        &target["phase_diagnostics"],
        "deferred_native_v2_soil_custody",
    )?;
    if custody["posture"] != "reconstructible_operands_not_installable_capability" {
        return Err("deferred custody posture".into());
    }
    let trial = required(custody, "candidate")?;
    let ending = validate_trial(trial)?;
    let continuation = required(custody, "continuation")?;
    if required(continuation, "physical_trial")? != trial {
        return Err("deferred candidate/physical trial join".into());
    }
    let original: openwepp_land_surface_energy::SoilThermalOwnerEnvelopeV2 =
        decode(required(continuation, "original_beginning_owner")?)?;
    original.validate().map_err(|error| error.to_string())?;
    let resident: crate::v9_real_consumer_shadow::DirectV10SoilThermalResidentV2 =
        decode(required(target, "native_soil_v2_constructor_operands")?)?;
    if original.state != resident.owner().state
        || original.receipt_chain_sha256 != resident.owner().receipt_chain_sha256
        || trial["support_end_ns"] != serde_json::json!(clock.accepted_until().get())
        || ending == resident.owner().state
    {
        return Err("deferred/current resident separation and support join".into());
    }
    let chain: Vec<Vec<openwepp_land_surface_energy::SoilThermalLayerEnergyCreditV2>> =
        decode(required(continuation, "ordered_layer_credit_chain")?)?;
    let transaction: openwepp_kernel_contract::TransactionId =
        decode(required(trial, "transaction_id")?)?;
    let predecessor: Option<openwepp_kernel_contract::TransactionId> =
        decode(required(trial, "predecessor_transaction_id")?)?;
    let expected_last = original
        .transaction_id
        .0
        .checked_add(
            u128::try_from(chain.len().checked_sub(1).ok_or("empty deferred chain")?)
                .map_err(|error| error.to_string())?,
        )
        .ok_or("deferred transaction overflow")?;
    if transaction.0 != expected_last
        || predecessor.map(|id| id.0) != expected_last.checked_sub(1)
        || original.expected_predecessor_transaction_id != Some(resident.owner().transaction_id)
        || original.transaction_id.0
            != resident
                .owner()
                .transaction_id
                .0
                .checked_add(1)
                .ok_or("resident transaction overflow")?
    {
        return Err("deferred ordered transaction lineage".into());
    }
    let state = replay_deferred_ordered_state_chain(&original, &chain, trial)?;
    if state != ending {
        return Err("deferred complete ordered ending state".into());
    }
    let last = chain.last().ok_or("deferred credit chain missing")?;
    if serde_json::to_value(last).map_err(|error| error.to_string())? != trial["layer_credits"] {
        return Err("deferred credit chain tail".into());
    }
    let operands: Vec<openwepp_land_surface_energy::SoilThermalAcceptedEnergyOperandV2> =
        decode(required(continuation, "accumulated_operands")?)?;
    let mut flattened = chain
        .iter()
        .flat_map(|layers| {
            layers
                .iter()
                .flat_map(|layer| layer.accepted_operands.clone())
        })
        .collect::<Vec<_>>();
    crate::v9_real_consumer_shadow::diagnostic_canonicalize_soil_operand_chain_v1(
        &original,
        &mut flattened,
    )
    .map_err(|error| error.to_string())?;
    if operands != flattened {
        return Err("deferred canonical accumulated operand chain".into());
    }
    Ok(())
}

#[path = "snow_stage3_v11_owner_comparison.rs"]
mod owner_comparison;

#[cfg(feature = "persisted-restart-v1")]
#[path = "snow_stage3_v11_late_controls.rs"]
mod late_controls;

#[test]
#[cfg(feature = "persisted-restart-v1")]
#[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
fn deferred_context_late_actual_entry_rollback_and_receipt_precedence() {
    let _native_audit =
        crate::v9_real_consumer_shadow::begin_covered_native_physical_path_audit_v1();
    let _probe_audit = super::member_backed_restore_tests::ProbeAudit::begin();
    openwepp_land_surface_energy::snow_accuracy_policy::Policy::B01
        .install()
        .expect("B01 policy");
    let export =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_MEMBER_EXPORT").expect("export"));
    let seed =
        std::path::PathBuf::from(std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("seed"));
    restore_with_control(
        &export,
        &seed,
        DeferredLifecycleControlV1::AuditLateLifecycle,
    )
    .expect("late actual-entry controls without physical work/publication");
}
