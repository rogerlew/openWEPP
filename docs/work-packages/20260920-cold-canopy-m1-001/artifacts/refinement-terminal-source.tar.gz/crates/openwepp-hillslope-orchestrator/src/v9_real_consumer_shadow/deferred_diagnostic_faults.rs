//! Test-only faults at actual private restoration boundaries; never a production path.
use super::{DirectV9RealConsumerError, DirectV10RealConsumerError};
use std::cell::Cell;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) enum Point {
    #[default]
    Disabled,
    FullProof,
    PrivateCandidate,
    LseProjection,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct Progress {
    pub full_proof: bool,
    pub private_candidate: bool,
    pub lse_projection: bool,
}

thread_local! {
    static FAULT: Cell<Point> = const { Cell::new(Point::Disabled) };
    static PROGRESS: Cell<Progress> = const { Cell::new(Progress {
        full_proof: false, private_candidate: false, lse_projection: false,
    }) };
}

pub(crate) struct Scope;
impl Scope {
    pub(crate) fn begin(point: Point) -> Self {
        FAULT.set(point);
        PROGRESS.set(Progress::default());
        Self
    }
}
impl Drop for Scope {
    fn drop(&mut self) {
        FAULT.set(Point::Disabled);
    }
}

pub(crate) fn progress() -> Progress {
    PROGRESS.get()
}

pub(crate) fn reached(point: Point) -> Result<(), DirectV10RealConsumerError> {
    let mut progress = PROGRESS.get();
    match point {
        Point::Disabled => {}
        Point::FullProof => progress.full_proof = true,
        Point::PrivateCandidate => progress.private_candidate = true,
        Point::LseProjection => progress.lse_projection = true,
    }
    PROGRESS.set(progress);
    if point != Point::Disabled && FAULT.get() == point {
        let boundary = match point {
            Point::FullProof => "injected after complete deferred proof",
            Point::PrivateCandidate => "injected after private native construction",
            Point::LseProjection => "injected after complete native LSE projection",
            Point::Disabled => unreachable!("disabled is not an injected fault"),
        };
        return Err(DirectV9RealConsumerError::Identity(boundary).into());
    }
    Ok(())
}
