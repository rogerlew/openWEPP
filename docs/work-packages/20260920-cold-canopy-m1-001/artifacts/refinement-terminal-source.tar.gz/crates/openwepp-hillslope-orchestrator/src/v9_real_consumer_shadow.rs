//! Explicit default-off V9/LSE consumer over the real direct scheduler owner.
//!
//! This module owns only isolated shadow state. It has no production commit,
//! selector, publication, or output API.

#[cfg(test)]
use crate::v11_vegetation_consumer::{accept_direct_v11_segment, execute_direct_v11_segment};
use openwepp_biogeochemistry::{BiogeochemistryError, BiogeochemistryState, available_by_key};
use openwepp_coupled_time::{
    AcceptedEventReceiptV1, Digest32, FramedField, ParentTransactionId, TimeSupport,
    complete_owner_set_digest, digest_bytes, framed_sha256,
};
use openwepp_kernel_contract::{
    MineralNitrogenKey, MineralNitrogenSpecies, ResourceAmountBasis, ResourceOwnerId, SoilLayerId,
    StratumId, TileId, TransactionId, authorize_proportionally,
};
use openwepp_land_surface_energy::{
    CoveredColumnAuthority, LandSurfaceEnergyConfiguration, LandSurfaceEnergyError,
    LandSurfaceEnergyState, LandSurfaceEnergyV2State, LandSurfaceForcing, LiquidParcel,
    LiquidParcelKind, LiquidTemperatureProvider, LseSupportAdmissibilityReceiptV1, LseV2StateError,
    OfeId, ParcelId, Sha256Digest, SoilThermalLayerSnapshot, SoilThermalOfeSnapshot,
    SoilThermalSnapshot, SoilThermalTileCandidate, Stage3SnowCoveredLowerBoundary,
    build_lse_ending_state, project_v2_runtime_to_v1, project_validated_v1_runtime_to_v2,
};
use openwepp_meteorology::snow_free_forcing::{
    celsius_to_kelvin, kilopascals_to_pascals, liquid_specific_enthalpy_j_kg,
};
use openwepp_plant_phenology::{GsiParameters, GsiState};
use openwepp_unit_boundary::TemperatureCelsius;
use openwepp_vegetation::energy::{
    canopy_surface_friction_velocity, leaf_boundary_conductance, neutral_resistance,
};
use openwepp_vegetation::v11::{
    V11AdmittedResourceFlux, V11BgcDebitScope, V11CoupledOwnedState, V11ImportedV10SegmentInput,
    V11ImportedV10SegmentOutput, V11LseSupportReceiptEnvelope, V11OwnerEnvelope, V11ResourceDebit,
    V11ResourceKey, V11SharedResourceKey, V11SharedResourceKind, V11SharedResourceOwnerTransition,
    ValidatedV11ParentFinalizationV1, VegetationConfigurationV11,
    project_v11_parent_finalization_to_v10,
};
use openwepp_vegetation::{
    NitrogenArbiter, NitrogenAuthorization, NitrogenRequest, SnowFreeForcing, V8CoupledOwnedState,
    V9CoupledOwnedState, V9StateError, V10CoupledOwnedState, V10StateError,
    VegetationConfiguration, VegetationError, project_v8_runtime_to_v9, project_v9_runtime_to_v8,
    project_v9_runtime_to_v10, project_v10_runtime_to_v9,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use std::fmt::Write as _;
use thiserror::Error;

use crate::hydrology::{
    DirectActiveSnowPartitionInputs, DirectSnowStage3EvaluationError,
    DirectSnowStage3PersistentState, DirectSnowStage3SupportInput, DirectSnowTerminalEventResult,
    STAGE3_DEFAULT_SNOW_ALBEDO, Wb11HydrologyKernel,
};
use crate::land_surface_energy_shadow::{
    CoveredCarrierComponentState, CoveredLseIterationState, CoveredV8OwnerEnvelopeError,
    ExecuteV8LseRuntimeShadowError, LandSurfaceEnergyRealHydrologyAdapter,
    LandSurfaceEnergyShadowError, ProvisionalCoveredV8PhysicalEvaluationV1,
    UncommittedCoveredV8OwnerEnvelope, V8CanopyForcingReceipt, V8InputProjectionError,
    V10RootZoneLayerReceipt, V10RootZoneReceiptKey, V10RootZoneReceiptSet,
    execute_v8_lse_runtime_shadow_internal,
    execute_v8_lse_runtime_shadow_v11_physical_with_carriers,
    execute_v8_lse_runtime_shadow_v11_with_native_soil_beginning,
    unified_beginning_hydrology_snapshot_sha256,
};
use crate::runtime_inputs::{
    DirectGsiDailyReceiptV1, DirectGsiOwnerConfigurationV1, PreparedSnowFreeGsiDayV1,
    SnowFreeHalfHourDestination, SnowFreeHalfHourForcingError, SnowFreeHalfHourIntervalReceipt,
    SnowFreeHalfHourProviderConfiguration, SnowFreeHalfHourProviderCursor,
    SnowFreeHalfHourStaticConfiguration, SnowFreePrecipitationParcelReceipt,
    ValidatedSnowFreeHalfHourForcingReceipts,
};
use crate::snow_stage3_open_boundary::{
    FinalStage3OpenSnowBoundaryReceiptV1, FinalStage3TileBoundaryReceiptV1,
    OpenSnowTileBoundaryCandidateV1, SealedStage3TileBoundaryForcingV1,
    evaluate_open_snow_tile_boundary,
};
use crate::snow_stage3_terminal_handoff::{
    CanopyLongwaveComponent, CarrierSurface, FinalStage3CanopyBoundaryReceiptInputs,
    FinalStage3CanopyBoundaryReceiptV1, LaneBoundaryContributionV1,
    LaneBoundaryTopologyExpectationV1, LaneStage3BoundaryReceiptV1,
    STAGE3_OFE_TILE_FRACTION_CLOSURE_TOLERANCE, SealedCoveredCarrierForcing,
    SnowStage3HandoffError, Stage3BoundaryIdentity, Stage3LaneAreaBasisV1,
    Stage3SnowSurfaceBoundaryReceiptInputs, Stage3SnowSurfaceBoundaryReceiptV1,
    Stage3TileBoundaryClassV1, outward_snow_fluxes_to_stage3,
};
use crate::snow_stage3_v11_attachment::{
    DirectSnowStage3V11AttachmentError, DirectSnowStage3V11TerminalParcel,
    DirectSnowStage3V11TerminalParcelPosture, SnowSoilHeatReceiptV1,
    Stage3PrecipitationDestinationV1, Stage3PrecipitationEnthalpyProviderV1,
    Stage3PrecipitationPhaseParcelSetV1, Stage3PrecipitationPhaseParcelV1,
    Stage3PrecipitationPhaseV1, Stage3PrecipitationSourceV1,
    begin_adaptive_parent_fixed_point_phase_v1 as profile_start,
    reconstruct_precipitation_mass_and_advected_heat,
    record_adaptive_parent_profile_detail_v1 as profile_record,
    validate_precipitation_phase_parcel_set,
};
use crate::vegetation_real_hydrology_shadow::{
    RealHydrologyLaneLayerMap, RealHydrologyShadowAdapter, RealHydrologyShadowError,
};
use crate::{
    DirectDayFrame, DirectOfeWb14Parameters, DirectPublicationDayInput, DirectRunFrame,
    DirectSurfaceLiquidConfiguration,
};

#[cfg(test)]
use crate::{DirectRunConstructorInputs, vegetation_real_hydrology_shadow::RealHydrologyOfeLaneId};
use std::sync::Arc;

#[path = "canonical_owner_bytes.rs"]
mod canonical_owner_bytes;
pub use canonical_owner_bytes::canonical_soil_thermal_v2_bundle_bytes;
pub(crate) use canonical_owner_bytes::{
    AdaptiveCompleteOwnerComparisonV1, AdaptiveDiscreteSurfaceKindV1, AdaptiveOwnerDimensionV1,
    adaptive_scalar_policy, canonical_hydrology_owner_bytes_v1,
    canonical_surface_liquid_complete_owner_projection_v2,
};
#[path = "v11_covered/mod.rs"]
mod v11_covered;
#[cfg(test)]
pub(crate) use frozen_litter_v4_adoption::{
    CoveredNativePhysicalPathAuditV1, begin_covered_native_physical_path_audit_v1,
    record_native_surface_ingress_entry_v1, record_native_surface_resource_entry_v1,
    record_native_wb14_physics_entry_v1, take_covered_native_physical_path_audit_v1,
};
#[cfg(test)]
pub(crate) use v11_covered::audit_covered_carrier_support;
pub(crate) use v11_covered::normalize_v11_staged_parent_lineage;
#[cfg(test)]
pub(crate) use v11_covered::physical_outcome_ledger::TerminalSnowSoilHeatReceiptV1;
pub(crate) use v11_covered::physical_outcome_ledger::TerminalSnowSoilTrialReceiptV1;
pub(crate) use v11_covered::physical_outcome_ledger::ledger_set_digest as stage3_physical_outcome_ledger_set_digest;
pub use v11_covered::physical_outcome_ledger::{
    Stage3PhysicalOutcomeClosureAuditV1, begin_stage3_physical_outcome_closure_audit_v1,
    take_stage3_physical_outcome_closure_audit_v1,
};
#[cfg(test)]
pub(crate) use v11_covered::{
    CanonicalCoveredFinalConstructorStageV1, CanonicalCoveredPhysicalParityPoisonV1,
    canonical_covered_final_constructor_boundary_v1,
    canonical_covered_final_validation_boundary_v1, canonical_covered_parity_poison_v1,
    record_canonical_covered_accepted_parent_adoption_v1,
    record_canonical_covered_successful_history_append_v1,
};
#[cfg(test)]
pub(crate) use v11_covered::{
    CoveredProvisionalPhysicalAuditV1, begin_covered_provisional_physical_audit_v1,
    begin_v50_outer_owner_transition_evidence_v1, force_covered_full_provisional_envelope_for_test,
    take_covered_provisional_physical_audit_v1, take_v50_outer_owner_transition_evidence_v1,
};

pub(crate) use v11_covered::CoveredCarrierEphemeralCandidatesV1;
pub(crate) use v11_covered::CoveredCarrierPhaseResultV1;
pub(crate) use v11_covered::CoveredPhysicalCustodyJoinInputs;
pub(crate) use v11_covered::DeferredNativeV2SoilCustodyV1;
pub(crate) use v11_covered::covered_carrier_initial_owner_bytes_with_deferred_native_v2_soil_custody_v1;
pub(crate) use v11_covered::stage3_support_forcing_digest;
use v11_covered::*;
pub use v11_covered::{
    CoveredParentOwnerJoinReceiptV1, DirectV11RealConsumerStack,
    DirectV11SnowCoveredRealConsumerStack, DirectV11SnowCoveredStackInputs,
};
pub(crate) use v11_covered::{
    PrecomputedTerminalAcceptedEndpointV1, precomputed_terminal_pre_event_authority_sha256_v1,
};

const INTERVALS_PER_DAY: usize = 48;
const INTERVAL_S: f64 = 1_800.0;

/// Test-only reachability counters for the complete deferred-native-V2 to V4
/// promotion path. They observe only existing production seams and never
/// retain, clone, or alter capability-bearing values.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, serde::Serialize)]
pub(crate) struct IntegratedPromotionBoundaryAuditV1 {
    pub deferred_completion_count: u32,
    pub v4_runtime_entry_count: u32,
    pub v4_runtime_success_count: u32,
    pub final_replay_entry_count: u32,
    pub final_replay_success_count: u32,
    pub projection_promotion_entry_count: u32,
    pub projection_promotion_success_count: u32,
    pub promotion_attempt_count: u32,
    pub promotion_entry_count: u32,
    pub promotion_success_count: u32,
    pub candidate_only_promotion_entry_count: u32,
    pub snow_free_litter_low_level_count: u32,
    pub snow_free_surface_low_level_count: u32,
    pub snow_free_wb14_low_level_count: u32,
    pub accepted_parent_replay_observation_count: u32,
    pub accepted_parent_replay_observation_error_count: u32,
    pub accepted_parent_replay_observation_inside_trusted_append_count: u32,
}

#[cfg(test)]
std::thread_local! {
    static INTEGRATED_PROMOTION_BOUNDARY_AUDIT: std::cell::RefCell<IntegratedPromotionBoundaryAuditV1> = const {
        std::cell::RefCell::new(IntegratedPromotionBoundaryAuditV1 {
            deferred_completion_count: 0,
            v4_runtime_entry_count: 0,
            v4_runtime_success_count: 0,
            final_replay_entry_count: 0,
            final_replay_success_count: 0,
            projection_promotion_entry_count: 0,
            projection_promotion_success_count: 0,
            promotion_attempt_count: 0,
            promotion_entry_count: 0,
            promotion_success_count: 0,
            candidate_only_promotion_entry_count: 0,
            snow_free_litter_low_level_count: 0,
            snow_free_surface_low_level_count: 0,
            snow_free_wb14_low_level_count: 0,
            accepted_parent_replay_observation_count: 0,
            accepted_parent_replay_observation_error_count: 0,
            accepted_parent_replay_observation_inside_trusted_append_count: 0,
        })
    };
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum B01IntegratedOriginalCustodyControlV1 {
    WholeOriginalOwnerN2,
    SupportStart,
    ExpectedPredecessor,
    ReceiptChain,
}

#[cfg(test)]
std::thread_local! {
    static B01_INTEGRATED_ORIGINAL_CUSTODY_CONTROL: std::cell::Cell<Option<B01IntegratedOriginalCustodyControlV1>> = const { std::cell::Cell::new(None) };
}

#[cfg(test)]
std::thread_local! {
    static B01_INTEGRATED_MISSING_REPLAY_N3: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum B01IntegratedPublishableControlV1 {
    SecondPromotion,
    SecondPromotionWrongOriginal,
}

#[cfg(test)]
std::thread_local! {
    static B01_INTEGRATED_WRONG_ACCEPTED_RESTART: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
    static B01_INTEGRATED_PUBLISHABLE_CONTROL: std::cell::Cell<Option<B01IntegratedPublishableControlV1>> = const { std::cell::Cell::new(None) };
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
pub(crate) enum B01IntegratedFinalReplayControlV1 {
    SelectedEnding,
    CreditReceiptLineage,
    AccumulatedSourceIdentity,
}
#[cfg(test)]
std::thread_local! { static B01_INTEGRATED_FINAL_REPLAY_CONTROL: std::cell::Cell<Option<B01IntegratedFinalReplayControlV1>> = const { std::cell::Cell::new(None) }; }

#[cfg(test)]
std::thread_local! {
    static B01_INTEGRATED_LATE_V4_RECEIPT: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

#[cfg(test)]
std::thread_local! { static B01_INTEGRATED_FINAL_OWNER_JOIN_FAULT: std::cell::Cell<bool> = const { std::cell::Cell::new(false) }; }

#[cfg(test)]
std::thread_local! { static B01_INTEGRATED_ACCEPTED_PARENT_REPLAY_WRITE_FAILURE: std::cell::Cell<bool> = const { std::cell::Cell::new(false) }; }

#[cfg(test)]
std::thread_local! {
    static B01_INTEGRATED_PROMOTION_AUDIT_ENABLED: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedWrongOriginalN2Sentinel;

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedMissingReplayN3Sentinel;

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedOriginalCustodyN4Sentinel;

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedWrongAcceptedRestartN5Sentinel;

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedPublishableN6Sentinel;

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedFinalReplayN8Sentinel;

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedLateV4N11Sentinel;

#[cfg(test)]
#[derive(Debug)]
pub(crate) struct B01IntegratedFinalOwnerJoinN12Sentinel;

#[cfg(test)]
pub(crate) fn enable_integrated_wrong_original_n2_v1() {
    enable_integrated_original_custody_control_v1(
        B01IntegratedOriginalCustodyControlV1::WholeOriginalOwnerN2,
    );
}

#[cfg(test)]
pub(crate) fn enable_integrated_original_custody_control_v1(
    control: B01IntegratedOriginalCustodyControlV1,
) {
    B01_INTEGRATED_ORIGINAL_CUSTODY_CONTROL.with(|slot| slot.set(Some(control)));
}

#[cfg(test)]
pub(crate) fn enable_integrated_missing_replay_n3_v1() {
    B01_INTEGRATED_MISSING_REPLAY_N3.with(|enabled| enabled.set(true));
}

#[cfg(test)]
pub(crate) fn enable_integrated_wrong_accepted_restart_n5_v1() {
    B01_INTEGRATED_WRONG_ACCEPTED_RESTART.with(|enabled| enabled.set(true));
}

#[cfg(test)]
pub(crate) fn enable_integrated_final_owner_join_fault_n12_v1() {
    B01_INTEGRATED_FINAL_OWNER_JOIN_FAULT.with(|slot| slot.set(true));
}

#[cfg(test)]
pub(crate) fn enable_integrated_accepted_parent_replay_write_failure_v1() {
    B01_INTEGRATED_ACCEPTED_PARENT_REPLAY_WRITE_FAILURE.with(|slot| slot.set(true));
}

#[cfg(test)]
pub(crate) fn take_integrated_final_owner_join_fault_n12_v1() -> bool {
    B01_INTEGRATED_FINAL_OWNER_JOIN_FAULT.with(|slot| slot.replace(false))
}

#[cfg(test)]
pub(crate) fn enable_integrated_late_v4_receipt_n11_v1() {
    B01_INTEGRATED_LATE_V4_RECEIPT.with(|slot| slot.set(true));
}

#[cfg(test)]
pub(crate) fn enable_integrated_final_replay_control_v1(
    control: B01IntegratedFinalReplayControlV1,
) {
    B01_INTEGRATED_FINAL_REPLAY_CONTROL.with(|slot| slot.set(Some(control)));
}

#[cfg(test)]
fn take_integrated_late_v4_receipt_n11_v1() -> bool {
    B01_INTEGRATED_LATE_V4_RECEIPT.with(|slot| slot.replace(false))
}

#[cfg(test)]
fn take_integrated_final_replay_control_v1() -> Option<B01IntegratedFinalReplayControlV1> {
    B01_INTEGRATED_FINAL_REPLAY_CONTROL.with(std::cell::Cell::take)
}

#[cfg(test)]
pub(crate) fn enable_integrated_publishable_control_v1(control: B01IntegratedPublishableControlV1) {
    B01_INTEGRATED_PUBLISHABLE_CONTROL.with(|slot| slot.set(Some(control)));
}

#[cfg(test)]
fn take_integrated_original_custody_control_v1() -> Option<B01IntegratedOriginalCustodyControlV1> {
    B01_INTEGRATED_ORIGINAL_CUSTODY_CONTROL.with(std::cell::Cell::take)
}

#[cfg(test)]
fn take_integrated_missing_replay_n3_v1() -> bool {
    B01_INTEGRATED_MISSING_REPLAY_N3.with(|enabled| enabled.replace(false))
}

#[cfg(test)]
pub(super) fn take_integrated_wrong_accepted_restart_n5_v1() -> bool {
    B01_INTEGRATED_WRONG_ACCEPTED_RESTART.with(|enabled| enabled.replace(false))
}

#[cfg(test)]
fn take_integrated_publishable_control_v1() -> Option<B01IntegratedPublishableControlV1> {
    B01_INTEGRATED_PUBLISHABLE_CONTROL.with(std::cell::Cell::take)
}

#[cfg(test)]
pub(crate) fn begin_integrated_promotion_boundary_audit_v1() {
    B01_INTEGRATED_PROMOTION_AUDIT_ENABLED.with(|enabled| enabled.set(true));
    INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| {
        *audit.borrow_mut() = IntegratedPromotionBoundaryAuditV1::default();
    });
}

#[cfg(test)]
pub(crate) fn take_integrated_promotion_boundary_audit_v1() -> IntegratedPromotionBoundaryAuditV1 {
    B01_INTEGRATED_PROMOTION_AUDIT_ENABLED.with(|enabled| enabled.set(false));
    B01_INTEGRATED_ORIGINAL_CUSTODY_CONTROL.with(|slot| slot.set(None));
    B01_INTEGRATED_MISSING_REPLAY_N3.with(|slot| slot.set(false));
    B01_INTEGRATED_WRONG_ACCEPTED_RESTART.with(|slot| slot.set(false));
    B01_INTEGRATED_PUBLISHABLE_CONTROL.with(|slot| slot.set(None));
    B01_INTEGRATED_FINAL_REPLAY_CONTROL.with(|slot| slot.set(None));
    B01_INTEGRATED_LATE_V4_RECEIPT.with(|slot| slot.set(false));
    B01_INTEGRATED_FINAL_OWNER_JOIN_FAULT.with(|slot| slot.set(false));
    B01_INTEGRATED_ACCEPTED_PARENT_REPLAY_WRITE_FAILURE.with(|slot| slot.set(false));
    INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| std::mem::take(&mut *audit.borrow_mut()))
}

#[cfg(test)]
pub(crate) fn integrated_promotion_boundary_audit_enabled_v1() -> bool {
    B01_INTEGRATED_PROMOTION_AUDIT_ENABLED.with(std::cell::Cell::get)
}

#[cfg(test)]
pub(crate) fn record_integrated_promotion_boundary_v1(stage: &'static str, candidate_only: bool) {
    if !integrated_promotion_boundary_audit_enabled_v1() {
        return;
    }
    INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| {
        let mut audit = audit.borrow_mut();
        match stage {
            "deferred-completion" => audit.deferred_completion_count += 1,
            "v4-runtime-entry" => audit.v4_runtime_entry_count += 1,
            "v4-runtime-success" => audit.v4_runtime_success_count += 1,
            "final-replay-entry" => audit.final_replay_entry_count += 1,
            "final-replay-success" => audit.final_replay_success_count += 1,
            "projection-promotion-entry" => audit.projection_promotion_entry_count += 1,
            "projection-promotion-success" => audit.projection_promotion_success_count += 1,
            "promotion-attempt" => audit.promotion_attempt_count += 1,
            "promotion-entry" => {
                audit.promotion_entry_count += 1;
                audit.candidate_only_promotion_entry_count += u32::from(candidate_only);
            }
            "promotion-success" => audit.promotion_success_count += 1,
            "snow-free-litter-low-level" => audit.snow_free_litter_low_level_count += 1,
            "snow-free-surface-low-level" => audit.snow_free_surface_low_level_count += 1,
            "snow-free-wb14-low-level" => audit.snow_free_wb14_low_level_count += 1,
            _ => unreachable!("known integrated-promotion test boundary"),
        }
    });
}
include!("v9_real_consumer_shadow_v11_error.rs");
include!("v9_real_consumer_shadow_physical_custody_error.rs");
include!("v9_real_consumer_shadow_serialization.rs");

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectV9ShadowIntervalInput {
    pub lse_forcing: LandSurfaceForcing,
    pub vegetation_forcing: SnowFreeForcing,
    pub wb14_parameters: Vec<DirectOfeWb14Parameters>,
}

/// Sealed atmospheric and receiver projection for a snow-covered V11
/// segment. This is deliberately distinct from [`DirectV9ShadowIntervalInput`]:
/// the covered adopter owns the snow/carrier boundary and may not silently
/// enter the snow-free interval path.
#[derive(Clone, Debug, PartialEq)]
pub struct DirectV11SnowCoveredSegmentInput {
    pub(crate) lse_forcing: LandSurfaceForcing,
    pub(crate) vegetation_forcing: SnowFreeForcing,
    pub(crate) wb14_parameters: Vec<DirectOfeWb14Parameters>,
}

impl DirectV11SnowCoveredSegmentInput {
    pub fn try_new(
        lse_forcing: LandSurfaceForcing,
        vegetation_forcing: SnowFreeForcing,
        wb14_parameters: Vec<DirectOfeWb14Parameters>,
    ) -> Result<Self, DirectV11RealConsumerError> {
        // A support that begins snow-free and receives authorized solid
        // precipitation is a covered reappearance support. Its lower
        // boundary is constructed from the sealed precipitation custody, so
        // only the ending covered posture is mandatory here.
        if !lse_forcing.snow_present_at_end || lse_forcing.snow_terminal_payload_present {
            return Err(DirectV11RealConsumerError::Identity(
                "covered input requires persistent snow operands",
            ));
        }
        Ok(Self {
            lse_forcing,
            vegetation_forcing,
            wb14_parameters,
        })
    }

    #[cfg(test)]
    #[must_use]
    pub(crate) fn from_snow_free(input: &DirectV9ShadowIntervalInput) -> Self {
        Self {
            lse_forcing: input.lse_forcing.clone(),
            vegetation_forcing: input.vegetation_forcing.clone(),
            wb14_parameters: input.wb14_parameters.clone(),
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct DirectV9ShadowDayInput {
    pub day_index: usize,
    pub intervals: Vec<DirectV9ShadowIntervalInput>,
    precipitation_custody: Option<DirectV9PrecipitationCustody>,
}

impl DirectV9ShadowDayInput {
    /// Construct a caller template. Repository precipitation custody remains
    /// absent until a sealed provider projection is applied.
    #[allow(clippy::too_many_lines)]
    pub fn try_new(
        day_index: usize,
        intervals: Vec<DirectV9ShadowIntervalInput>,
    ) -> Result<Self, DirectV9RealConsumerError> {
        if intervals.len() != INTERVALS_PER_DAY {
            return Err(DirectV9RealConsumerError::Unsupported(
                "a shadow day requires exactly 48 intervals",
            ));
        }
        Ok(Self {
            day_index,
            intervals,
            precipitation_custody: None,
        })
    }
}

#[derive(Clone, Debug, PartialEq)]
struct DirectV9PrecipitationCustody {
    current_source_and_outgoing_mass: BTreeMap<(String, String), (String, f64)>,
}

/// Replace atmospheric and precipitation template operands with a sealed
/// repository-provider receipt. The consumer subsequently reprojects every
/// nonmeteorological operand from its live owners and treats remaining
/// template values only as checked expectations, never as physics authority.
fn project_repository_forcing_receipts_to_v9_day(
    provider: &ValidatedSnowFreeHalfHourForcingReceipts,
    mut template: DirectV9ShadowDayInput,
    expected_run_id: u64,
    expected_gsi_receipt_sha256: &str,
    expected_destinations: &BTreeSet<(String, String)>,
) -> Result<DirectV9ShadowDayInput, DirectV9RealConsumerError> {
    let receipts = provider.receipts();
    let first = receipts.first().ok_or(DirectV9RealConsumerError::Identity(
        "repository forcing receipt set",
    ))?;
    if first.day_index != template.day_index
        || first.run_id != expected_run_id.to_string()
        || template.intervals.len() != INTERVALS_PER_DAY
        || receipts.iter().any(|receipt| {
            receipt.day_index != template.day_index || receipt.intervals.len() != INTERVALS_PER_DAY
        })
    {
        return Err(DirectV9RealConsumerError::Identity(
            "repository forcing day projection",
        ));
    }
    let found_destinations = receipts
        .iter()
        .map(|receipt| {
            (
                receipt.intervals[0].ofe_id.clone(),
                receipt.intervals[0].tile_id.clone(),
            )
        })
        .collect::<BTreeSet<_>>();
    if &found_destinations != expected_destinations {
        return Err(DirectV9RealConsumerError::Identity(
            "repository forcing destination topology",
        ));
    }
    let mut current_source_and_outgoing_mass = BTreeMap::new();
    for receipt in receipts {
        let identity = (
            receipt.intervals[0].ofe_id.clone(),
            receipt.intervals[0].tile_id.clone(),
        );
        let outgoing_mass = receipt
            .next_day_precipitation_carry
            .iter()
            .map(|parcel| parcel.mass_kg_m2)
            .sum();
        current_source_and_outgoing_mass.insert(
            identity,
            (receipt.source_climate_sha256.clone(), outgoing_mass),
        );
    }
    for interval_index in 0..INTERVALS_PER_DAY {
        let atmospheric = &first.intervals[interval_index];
        if atmospheric.gsi_receipt_sha256 != expected_gsi_receipt_sha256 {
            return Err(DirectV9RealConsumerError::Identity(
                "repository GSI owner receipt",
            ));
        }
        let live = &template.intervals[interval_index].vegetation_forcing;
        if atmospheric.co2_pa.to_bits() != live.co2_pa.to_bits()
            || atmospheric.reference_height_m.to_bits() != live.reference_height_m.to_bits()
            || atmospheric.gsi.to_bits() != live.gsi.to_bits()
        {
            return Err(DirectV9RealConsumerError::Identity(
                "repository forcing live-owner scalar join",
            ));
        }
        validate_wb14_provider_bindings(
            receipts,
            interval_index,
            &template.intervals[interval_index],
        )?;
        validate_global_provider_interval(receipts, interval_index, atmospheric)?;
        let interval = &mut template.intervals[interval_index];
        project_lse_atmosphere(
            receipts,
            interval_index,
            atmospheric,
            &mut interval.lse_forcing,
        )?;
        project_vegetation_atmosphere(atmospheric, &mut interval.vegetation_forcing);
    }
    template.precipitation_custody = Some(DirectV9PrecipitationCustody {
        current_source_and_outgoing_mass,
    });
    Ok(template)
}

include!("v9_real_consumer_shadow_forcing.rs");
include!("v9_real_consumer_shadow/v10_soil_thermal_v2.rs");

#[cfg(any(
    test,
    feature = "restart-authority-evidence",
    feature = "persisted-restart-v1"
))]
#[cfg(test)]
fn diagnostic_native_field<T: serde::de::DeserializeOwned>(
    captured: &serde_json::Value,
    name: &str,
) -> Result<T, DirectV10RealConsumerError> {
    let value = captured
        .get(name)
        .cloned()
        .ok_or(DirectV10RealConsumerError::Runtime(
            DirectV9RealConsumerError::Identity("diagnostic native constructor operand"),
        ))?;
    serde_json::from_value(value).map_err(|error| {
        DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Serialization(
            error.to_string(),
        ))
    })
}

#[cfg(feature = "persisted-restart-v1")]
#[cfg(test)]
pub(crate) fn diagnostic_canonicalize_soil_operand_chain_v1(
    topology: &openwepp_land_surface_energy::SoilThermalOwnerEnvelopeV2,
    operands: &mut [openwepp_land_surface_energy::SoilThermalAcceptedEnergyOperandV2],
) -> Result<(), DirectV9RealConsumerError> {
    reordinal_and_canonicalize_v2_operands(topology, operands)
}

include!("v9_real_consumer_shadow/native_soil_restart_admission.rs");
#[derive(Clone, Debug, PartialEq)]
pub struct DirectV9RealConsumerShadow {
    authority: CoveredColumnAuthority,
    provider_gsi_receipt_sha256: String,
    vegetation_configuration: VegetationConfiguration,
    vegetation_state: V9CoupledOwnedState,
    vegetation_owner_id: ResourceOwnerId,
    lse_configuration: LandSurfaceEnergyConfiguration,
    lse_state: LandSurfaceEnergyState,
    surface_configuration: DirectSurfaceLiquidConfiguration,
    layer_maps: Vec<RealHydrologyLaneLayerMap>,
    soil_thermal: DirectSoilThermalResident,
    biogeochemistry: BiogeochemistryState,
    hydrology_frame: DirectRunFrame,
    hydrology_constructor_inputs: Option<Arc<crate::DirectRunConstructorInputs>>,
    next_day_index: usize,
    accepted_interval_count: u64,
    wb14_parent_working_state: Option<crate::direct_runtime::DirectWb14ParentWorkingState>,
    root_zone_hydraulic_configuration: Option<DirectRootZoneHydraulicConfiguration>,
}

/// Complete typed restart owner for the default-off V9 real-consumer shadow.
#[derive(Clone, Debug, PartialEq)]
pub struct DirectV9RealConsumerCheckpoint {
    shadow: DirectV9RealConsumerShadow,
}

enum CanopySoilEvaluationV1 {
    Complete(UncommittedCoveredV8OwnerEnvelope),
    PhysicalOnly(ProvisionalCoveredV8PhysicalEvaluationV1),
}

struct PreparedCoveredCanopySoilInputV1(DirectV9ShadowIntervalInput);

impl CanopySoilEvaluationV1 {
    fn into_complete(self) -> Result<UncommittedCoveredV8OwnerEnvelope, DirectV9RealConsumerError> {
        match self {
            Self::Complete(value) => Ok(value),
            Self::PhysicalOnly(_) => Err(DirectV9RealConsumerError::Identity(
                "complete canopy/soil construction returned physical-only evaluation",
            )),
        }
    }

    fn into_physical(
        self,
    ) -> Result<ProvisionalCoveredV8PhysicalEvaluationV1, DirectV9RealConsumerError> {
        match self {
            Self::PhysicalOnly(value) => Ok(value),
            Self::Complete(_) => Err(DirectV9RealConsumerError::Identity(
                "physical-only canopy/soil construction returned complete evaluation",
            )),
        }
    }
}

/// Explicit default-off V10/LSE-V2 owner. It retains successor identities at
/// the public boundary and uses transient V9/V1 projections only to reuse the
/// unchanged positive-PAR and owner plumbing.
#[derive(Clone, Debug, PartialEq)]
pub struct DirectV10RealConsumerShadow {
    inner: DirectV9RealConsumerShadow,
    vegetation_configuration: VegetationConfiguration,
    vegetation_state: V10CoupledOwnedState,
    lse_configuration: LandSurfaceEnergyConfiguration,
    lse_state: LandSurfaceEnergyV2State,
    gsi_owner_configuration: DirectGsiOwnerConfigurationV1,
    gsi_state: GsiState,
    provider_static_configuration: SnowFreeHalfHourStaticConfiguration,
    provider_cursor: SnowFreeHalfHourProviderCursor,
    root_zone_hydraulic_configuration: DirectRootZoneHydraulicConfiguration,
    /// Unpublished accepted support operands retained verbatim for the
    /// complete-day publication candidate. Trial shadows own independent
    /// clones, so rejected adaptive paths discard these with their owner set.
    /// Accepted zero-duration events remain distinct from the positive support
    /// receipts they follow. They are the only authority that may bridge a
    /// pre-event publication owner set to a post-event receiver support.
    accepted_publication_history: AcceptedPublicationHistoryV1,
    /// Native successor owner set for snow-free forest litter. Retained V1/V2
    /// checkpoints leave this absent; the V3 execution path requires it.
    frozen_litter_v3: Option<FrozenLitterV3Resident>,
    /// Mandatory exact surface-enthalpy successor. When present, the parallel
    /// V3 resident is a nonauthoritative physical/high-mirror owner only.
    frozen_litter_v4: Option<FrozenLitterV4Resident>,
}

/// Private diagnostic DTO for the non-serde hydrology lane mapping.  It is
/// confined to the current-context recorder and restores the exact configured
/// lane/index/layer relation before native construction.
#[derive(Clone, Debug, serde::Deserialize, serde::Serialize)]
pub(crate) struct DiagnosticNativeLaneMapV1 {
    pub lane_index: usize,
    pub lane_id: u32,
    pub layer_ids: Vec<openwepp_kernel_contract::SoilLayerId>,
}

/// One-use, process-local authority for the deferred B01 diagnostic route.
/// It deliberately has no serde or Clone implementation.  It is consumed by
/// the private constructor after every captured owner join has been checked.
#[cfg(all(test, feature = "persisted-restart-v1"))]
struct DeferredNativeCompositeAdmissionV1 {
    native: NativeSoilRestartAdmissionV1,
    prior_gsi_receipt: DirectGsiDailyReceiptV1,
    prepared_gsi_receipt: DirectGsiDailyReceiptV1,
    prior_gsi_state: crate::runtime_inputs::DirectGsiOwnerStateV1,
    prior_cursor: SnowFreeHalfHourProviderCursor,
    frozen_residents: (FrozenLitterV3Resident, FrozenLitterV4Resident),
}

#[derive(Clone, Debug, serde::Deserialize, serde::Serialize)]
#[serde(deny_unknown_fields)]
struct DiagnosticFrozenLitterResidentsV1 {
    lse_configuration: LandSurfaceEnergyConfiguration,
    lse_state: openwepp_land_surface_energy::LandSurfaceEnergyV3State,
    surface_parent_configuration_canonical_bytes: Vec<u8>,
    surface_model_definition_canonical_bytes: Vec<u8>,
    surface_configuration_canonical_bytes: Vec<u8>,
    surface_owner_canonical_bytes: Vec<u8>,
    physical_publication_history: Vec<Vec<u8>>,
    physical_wb14_parent: Option<Vec<u8>>,
    physical_predecessor_receipt_chain_sha256: String,
    exact_surface_owner_canonical_bytes: Vec<u8>,
    exact_publication_history: Vec<Vec<u8>>,
    exact_publication_beginning_lse_v3_state_sha256: Sha256Digest,
}

impl DirectV10RealConsumerShadow {
    /// Private constructor-owner projection for the diagnostic file reader.
    /// The hydrology frame itself is deliberately excluded: it is transported
    /// by the exact dynamic-frame DTO and reconstructed from its pinned base.
    pub(crate) fn diagnostic_native_consumer_constructor_operands_v1(
        &self,
    ) -> Result<serde_json::Value, DirectV10RealConsumerError> {
        let surface_configuration_canonical_json =
            self.inner.surface_configuration.canonical_bytes()?;
        let gsi_owner_state = crate::runtime_inputs::direct_gsi_state(&self.gsi_state)?;
        let provider_static_configuration = crate::snow_stage3_v11_current_context_capture::
            ProviderStaticConfigurationCaptureV1::capture(&self.provider_static_configuration)?;
        let provider_cursor_canonical_json = self.provider_cursor.to_json_bytes()?;
        let frozen_litter_residents = match (
            self.frozen_litter_v3_resident(),
            self.frozen_litter_v4_resident(),
        ) {
            (None, None) => None,
            (Some(physical), Some(exact)) => Some(DiagnosticFrozenLitterResidentsV1 {
                lse_configuration: physical.lse_configuration().clone(),
                lse_state: physical.lse_state().clone(),
                surface_parent_configuration_canonical_bytes: physical
                    .surface_configuration()
                    .parent()
                    .canonical_bytes()?,
                surface_model_definition_canonical_bytes: physical
                    .surface_configuration()
                    .model_definition()
                    .canonical_bytes()?,
                surface_configuration_canonical_bytes: physical
                    .surface_configuration()
                    .canonical_bytes()?,
                surface_owner_canonical_bytes: physical.surface_owner().canonical_bytes(
                    physical.surface_configuration().parent(),
                    Some(physical.surface_configuration()),
                )?,
                physical_publication_history: physical
                    .accepted_publication_supports_canonical_bytes()?,
                physical_wb14_parent: physical.restart_wb14_parent_working_state_bytes()?,
                physical_predecessor_receipt_chain_sha256: physical
                    .predecessor_receipt_chain_sha256()
                    .to_owned(),
                exact_surface_owner_canonical_bytes: exact
                    .exact_surface_owner()
                    .canonical_bytes()?,
                exact_publication_history: exact
                    .accepted_publication_supports_canonical_bytes()
                    .to_vec(),
                exact_publication_beginning_lse_v3_state_sha256: exact
                    .diagnostic_publication_history_beginning_lse_v3_state_sha256()
                    .clone(),
            }),
            _ => {
                return Err(DirectV9RealConsumerError::OwnerClosure(
                    "diagnostic frozen-litter resident pair",
                )
                .into());
            }
        };
        Ok(serde_json::json!({
            "vegetation_configuration": self.vegetation_configuration,
            "vegetation_state": self.vegetation_state,
            "vegetation_owner_id": self.inner.vegetation_owner_id,
            "lse_configuration": self.lse_configuration,
            "lse_state": self.lse_state,
            "surface_configuration_canonical_json": surface_configuration_canonical_json,
            "biogeochemistry": self.inner.biogeochemistry,
            "next_day_index": self.inner.next_day_index,
            "gsi_owner_configuration": self.gsi_owner_configuration,
            "gsi_owner_state": gsi_owner_state,
            "provider_static_configuration": provider_static_configuration,
            "provider_cursor_canonical_json": provider_cursor_canonical_json,
            "root_zone_hydraulic_configuration": self.root_zone_hydraulic_configuration,
            "accepted_interval_count": self.inner.accepted_interval_count,
            "provider_gsi_receipt_sha256": self.inner.provider_gsi_receipt_sha256,
            "accepted_publication_rotation": self.diagnostic_accepted_publication_rotation_canonical_bytes_v3()?,
            "wb14_parent": self.diagnostic_wb14_parent_canonical_bytes_v1()?,
            "frozen_litter_residents": frozen_litter_residents,
        }))
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[allow(clippy::too_many_arguments)]
    #[cfg(test)]
    pub(crate) fn diagnostic_restore_native_consumer_v1(
        captured: &serde_json::Value,
        target_soil: DirectV10SoilThermalResidentV2,
        committed_bootstrap: DirectV10SoilThermalResidentV2,
        lane_maps: Vec<DiagnosticNativeLaneMapV1>,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        hydrology_frame: DirectRunFrame,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
        pinned_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_provider_static_configuration: &SnowFreeHalfHourStaticConfiguration,
        pinned_hydrology_constructor_inputs: std::sync::Arc<DirectRunConstructorInputs>,
    ) -> Result<Self, DirectV10RealConsumerError> {
        let vegetation_configuration =
            diagnostic_native_field(captured, "vegetation_configuration")?;
        let vegetation_state: V10CoupledOwnedState =
            diagnostic_native_field(captured, "vegetation_state")?;
        let vegetation_owner_id = diagnostic_native_field(captured, "vegetation_owner_id")?;
        let captured_lse_configuration: LandSurfaceEnergyConfiguration =
            diagnostic_native_field(captured, "lse_configuration")?;
        if &captured_lse_configuration != pinned_lse_configuration {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic main LSE configuration/pinned authority join",
            )
            .into());
        }
        let lse_configuration = pinned_lse_configuration.clone();
        let lse_state: LandSurfaceEnergyV2State = diagnostic_native_field(captured, "lse_state")?;
        Self::diagnostic_validate_surface_configuration_v1(captured, pinned_surface_configuration)?;
        let surface_configuration = pinned_surface_configuration.clone();
        let biogeochemistry = diagnostic_native_field(captured, "biogeochemistry")?;
        let next_day_index = diagnostic_native_field(captured, "next_day_index")?;
        let gsi_owner_configuration = diagnostic_native_field(captured, "gsi_owner_configuration")?;
        let gsi_owner_state: crate::runtime_inputs::DirectGsiOwnerStateV1 =
            diagnostic_native_field(captured, "gsi_owner_state")?;
        let gsi_state =
            crate::runtime_inputs::restart_authority_restore_gsi_state(&gsi_owner_state)?;
        let provider_static_configuration: crate::snow_stage3_v11_current_context_capture::
            ProviderStaticConfigurationCaptureV1 = diagnostic_native_field(captured, "provider_static_configuration")?;
        provider_static_configuration.validate_against(pinned_provider_static_configuration)?;
        let provider_static_configuration = pinned_provider_static_configuration.clone();
        let provider_cursor_canonical_json: Vec<u8> =
            diagnostic_native_field(captured, "provider_cursor_canonical_json")?;
        let provider_cursor = SnowFreeHalfHourProviderCursor::restore_json(
            &provider_cursor_canonical_json,
            &provider_static_configuration,
            next_day_index,
        )?;
        let root_zone_hydraulic_configuration =
            diagnostic_native_field(captured, "root_zone_hydraulic_configuration")?;
        let proof = NativeSoilRestartAdmissionV1::authenticate(
            &target_soil,
            &committed_bootstrap,
            &lse_configuration,
            &lse_configuration.soil_thermal_configuration.owner_id,
            &lse_configuration
                .soil_thermal_configuration
                .configuration_sha256,
            &target_soil.owner().run_id,
            clock,
            NativeSoilRestartPositionV1::InProgressSupportCurrent,
            vegetation_state.0.last_transaction_id,
            next_day_index,
            hydrology_frame.identity.run_id,
        )?;
        let mut restored = Self::restart_authority_try_new_with_native_soil(
            vegetation_configuration,
            vegetation_state,
            vegetation_owner_id,
            lse_configuration,
            lse_state,
            surface_configuration,
            Self::diagnostic_restore_native_lane_maps_v1(lane_maps)?,
            DirectSoilThermalResident::V2(target_soil),
            biogeochemistry,
            hydrology_frame,
            next_day_index,
            gsi_owner_configuration,
            gsi_state,
            provider_static_configuration,
            provider_cursor,
            root_zone_hydraulic_configuration,
            &proof,
            clock,
            NativeSoilRestartPositionV1::InProgressSupportCurrent,
        )?;
        let history: Vec<u8> = diagnostic_native_field(captured, "accepted_publication_rotation")?;
        restored
            .restart_authority_restore_accepted_publication_rotation_canonical_bytes_v3(&history)?;
        let wb14: Option<Vec<u8>> = diagnostic_native_field(captured, "wb14_parent")?;
        restored.restart_authority_restore_native_wb14_parent_canonical_bytes(
            wb14.as_deref(),
            &proof,
            clock,
            NativeSoilRestartPositionV1::InProgressSupportCurrent,
        )?;
        restored.diagnostic_restore_captured_residents_v1(
            captured,
            pinned_frozen_litter_lse_configuration,
            pinned_surface_configuration,
            None,
        )?;
        restored.diagnostic_install_hydrology_constructor_inputs_v1(
            pinned_hydrology_constructor_inputs,
        );
        Ok(restored)
    }
    /// Authenticate the complete deferred diagnostic authority into a local,
    /// consuming capability.  This is intentionally separate from the
    /// ordinary native-soil admission: the latter still refuses an unaccepted
    /// support when called directly.
    #[cfg(all(test, feature = "persisted-restart-v1"))]
    #[allow(clippy::too_many_arguments)]
    fn diagnostic_mint_deferred_composite_admission_v1(
        captured: &serde_json::Value,
        target_soil: &DirectV10SoilThermalResidentV2,
        committed_bootstrap: &DirectV10SoilThermalResidentV2,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        hydrology_frame: &DirectRunFrame,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
        pinned_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        provider_configuration: &SnowFreeHalfHourStaticConfiguration,
        prior_gsi_receipt: DirectGsiDailyReceiptV1,
        prepared_gsi_receipt: DirectGsiDailyReceiptV1,
        authenticated_prior_state: crate::runtime_inputs::DirectGsiOwnerStateV1,
        authenticated_prior_cursor: SnowFreeHalfHourProviderCursor,
    ) -> Result<DeferredNativeCompositeAdmissionV1, DirectV10RealConsumerError> {
        prior_gsi_receipt.validate()?;
        prepared_gsi_receipt.validate()?;
        if prior_gsi_receipt.ending_state != prepared_gsi_receipt.beginning_state
            || prior_gsi_receipt.ending_state != authenticated_prior_state
            || prior_gsi_receipt.receipt_sha256.len() != 64
            || prepared_gsi_receipt.receipt_sha256.len() != 64
        {
            return Err(DirectV9RealConsumerError::Identity(
                "deferred composite GSI prior/prepared custody",
            )
            .into());
        }
        let captured_state: crate::runtime_inputs::DirectGsiOwnerStateV1 =
            diagnostic_native_field(captured, "gsi_owner_state")?;
        if captured_state != authenticated_prior_state {
            return Err(DirectV9RealConsumerError::Identity(
                "deferred composite captured/prior GSI state",
            )
            .into());
        }
        let cursor_bytes: Vec<u8> =
            diagnostic_native_field(captured, "provider_cursor_canonical_json")?;
        let captured_cursor = SnowFreeHalfHourProviderCursor::restore_json(
            &cursor_bytes,
            provider_configuration,
            usize::try_from(prepared_gsi_receipt.day_index).map_err(|_| {
                DirectV9RealConsumerError::Identity("deferred composite GSI day width")
            })?,
        )?;
        if captured_cursor != authenticated_prior_cursor {
            return Err(DirectV9RealConsumerError::Identity(
                "deferred composite captured/prior cursor",
            )
            .into());
        }
        let frozen: DiagnosticFrozenLitterResidentsV1 = diagnostic_native_field::<
            Option<DiagnosticFrozenLitterResidentsV1>,
        >(
            captured, "frozen_litter_residents"
        )?
        .ok_or(DirectV9RealConsumerError::Identity(
            "diagnostic native target requires frozen-litter V3/V4 residents",
        ))?;
        let frozen_residents = Self::diagnostic_decode_validate_frozen_litter_residents_v1(
            frozen,
            pinned_frozen_litter_lse_configuration,
            pinned_surface_configuration,
        )?;
        let vegetation_state: V10CoupledOwnedState =
            diagnostic_native_field(captured, "vegetation_state")?;
        let next_day_index: usize = diagnostic_native_field(captured, "next_day_index")?;
        let proof = NativeSoilRestartAdmissionV1::authenticate_deferred_original_v1(
            target_soil,
            committed_bootstrap,
            pinned_lse_configuration,
            &pinned_lse_configuration.soil_thermal_configuration.owner_id,
            &pinned_lse_configuration
                .soil_thermal_configuration
                .configuration_sha256,
            &target_soil.owner().run_id,
            clock,
            NativeSoilRestartPositionV1::InProgressSupportCurrent,
            vegetation_state.0.last_transaction_id,
            next_day_index,
            hydrology_frame.identity.run_id,
        )?;
        let proof = Self::diagnostic_bind_deferred_inactive_scheduler_v1(
            captured,
            pinned_surface_configuration,
            hydrology_frame,
            proof,
        )?;
        Ok(DeferredNativeCompositeAdmissionV1 {
            native: proof,
            prior_gsi_receipt,
            prepared_gsi_receipt,
            prior_gsi_state: authenticated_prior_state,
            prior_cursor: authenticated_prior_cursor,
            frozen_residents,
        })
    }

    #[cfg(all(test, feature = "persisted-restart-v1"))]
    fn diagnostic_bind_deferred_inactive_scheduler_v1(
        captured: &serde_json::Value,
        configuration: &DirectSurfaceLiquidConfiguration,
        frame: &DirectRunFrame,
        proof: NativeSoilRestartAdmissionV1,
    ) -> Result<NativeSoilRestartAdmissionV1, DirectV10RealConsumerError> {
        let frozen_litter_residents: Option<DiagnosticFrozenLitterResidentsV1> =
            diagnostic_native_field(captured, "frozen_litter_residents")?;
        let frozen = frozen_litter_residents.ok_or(DirectV9RealConsumerError::Identity(
            "diagnostic native target requires frozen-litter V3/V4 residents",
        ))?;
        let surface_parent = DirectSurfaceLiquidConfiguration::from_canonical_bytes(
            &frozen.surface_parent_configuration_canonical_bytes,
        )?;
        if surface_parent.canonical_bytes()? != configuration.canonical_bytes()? {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic frozen-litter surface parent/pinned authority join",
            )
            .into());
        }
        let surface_model = crate::direct_runtime::SurfaceLiquidOwnerModelDefinitionV2::
            restart_authority_from_canonical_bytes(&frozen.surface_model_definition_canonical_bytes)?;
        let native_configuration =
            crate::direct_runtime::SurfaceLiquidConfigurationV2::from_canonical_bytes(
                surface_parent,
                surface_model,
                &frozen.surface_configuration_canonical_bytes,
            )?;
        let surface =
            frame
                .surface_liquid_shadow
                .as_ref()
                .ok_or(DirectV9RealConsumerError::Identity(
                    "native inactive scheduler frame surface absent",
                ))?;
        let surface_bytes = surface.canonical_bytes(configuration).map_err(|_| {
            DirectV9RealConsumerError::Identity("native inactive scheduler frame surface")
        })?;
        let count: u64 = diagnostic_native_field(captured, "accepted_interval_count")?;
        let wb14: Option<Vec<u8>> = diagnostic_native_field(captured, "wb14_parent")?;
        proof
            .bind_inactive_scheduler(
                count,
                configuration,
                &surface_bytes,
                wb14.as_deref(),
                Some(&frozen.surface_owner_canonical_bytes),
                Some(&native_configuration),
                frozen.physical_wb14_parent.as_deref(),
            )
            .map_err(Into::into)
    }

    #[cfg(all(test, feature = "persisted-restart-v1"))]
    #[allow(clippy::too_many_arguments)]
    fn diagnostic_restore_native_consumer_from_proof_v1(
        captured: &serde_json::Value,
        target_soil: DirectV10SoilThermalResidentV2,
        _committed_bootstrap: DirectV10SoilThermalResidentV2,
        lane_maps: Vec<DiagnosticNativeLaneMapV1>,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        hydrology_frame: DirectRunFrame,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
        pinned_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_provider_static_configuration: &SnowFreeHalfHourStaticConfiguration,
        pinned_hydrology_constructor_inputs: std::sync::Arc<DirectRunConstructorInputs>,
        proof: &NativeSoilRestartAdmissionV1,
        authenticated_prior_receipt: Option<&DirectGsiDailyReceiptV1>,
        trusted_frozen_residents: Option<(FrozenLitterV3Resident, FrozenLitterV4Resident)>,
    ) -> Result<Self, DirectV10RealConsumerError> {
        let vegetation_configuration =
            diagnostic_native_field(captured, "vegetation_configuration")?;
        let vegetation_state: V10CoupledOwnedState =
            diagnostic_native_field(captured, "vegetation_state")?;
        let vegetation_owner_id = diagnostic_native_field(captured, "vegetation_owner_id")?;
        let captured_lse_configuration: LandSurfaceEnergyConfiguration =
            diagnostic_native_field(captured, "lse_configuration")?;
        if &captured_lse_configuration != pinned_lse_configuration {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic main LSE configuration/pinned authority join",
            )
            .into());
        }
        let lse_configuration = pinned_lse_configuration.clone();
        let lse_state: LandSurfaceEnergyV2State = diagnostic_native_field(captured, "lse_state")?;
        Self::diagnostic_validate_surface_configuration_v1(captured, pinned_surface_configuration)?;
        let surface_configuration = pinned_surface_configuration.clone();
        let biogeochemistry = diagnostic_native_field(captured, "biogeochemistry")?;
        let next_day_index = diagnostic_native_field(captured, "next_day_index")?;
        let gsi_owner_configuration = diagnostic_native_field(captured, "gsi_owner_configuration")?;
        let gsi_owner_state: crate::runtime_inputs::DirectGsiOwnerStateV1 =
            diagnostic_native_field(captured, "gsi_owner_state")?;
        let gsi_state =
            crate::runtime_inputs::restart_authority_restore_gsi_state(&gsi_owner_state)?;
        let provider_static_configuration: crate::snow_stage3_v11_current_context_capture::ProviderStaticConfigurationCaptureV1 = diagnostic_native_field(captured, "provider_static_configuration")?;
        provider_static_configuration.validate_against(pinned_provider_static_configuration)?;
        let provider_static_configuration = pinned_provider_static_configuration.clone();
        let provider_cursor_canonical_json: Vec<u8> =
            diagnostic_native_field(captured, "provider_cursor_canonical_json")?;
        let provider_cursor = SnowFreeHalfHourProviderCursor::restore_json(
            &provider_cursor_canonical_json,
            &provider_static_configuration,
            next_day_index,
        )?;
        let root_zone_hydraulic_configuration =
            diagnostic_native_field(captured, "root_zone_hydraulic_configuration")?;
        let mut restored = Self::restart_authority_try_new_with_native_soil(
            vegetation_configuration,
            vegetation_state,
            vegetation_owner_id,
            lse_configuration,
            lse_state,
            surface_configuration,
            Self::diagnostic_restore_native_lane_maps_v1(lane_maps)?,
            DirectSoilThermalResident::V2(target_soil),
            biogeochemistry,
            hydrology_frame,
            next_day_index,
            gsi_owner_configuration,
            gsi_state,
            provider_static_configuration,
            provider_cursor,
            root_zone_hydraulic_configuration,
            proof,
            clock,
            NativeSoilRestartPositionV1::InProgressSupportCurrent,
        )?;
        let history: Vec<u8> = diagnostic_native_field(captured, "accepted_publication_rotation")?;
        restored
            .restart_authority_restore_accepted_publication_rotation_canonical_bytes_v3(&history)?;
        let wb14: Option<Vec<u8>> = diagnostic_native_field(captured, "wb14_parent")?;
        restored.restart_authority_restore_native_wb14_parent_canonical_bytes(
            wb14.as_deref(),
            proof,
            clock,
            NativeSoilRestartPositionV1::InProgressSupportCurrent,
        )?;
        if let Some(prior_receipt) = authenticated_prior_receipt {
            let captured_prior_receipt: String =
                diagnostic_native_field(captured, "provider_gsi_receipt_sha256")?;
            if captured_prior_receipt != prior_receipt.receipt_sha256 {
                return Err(DirectV9RealConsumerError::Identity(
                    "diagnostic provider GSI receipt custody",
                )
                .into());
            }
            restored
                .inner
                .provider_gsi_receipt_sha256
                .clone_from(&prior_receipt.receipt_sha256);
            restored.restart_authority_install_native_inactive_scheduler_position(
                proof,
                clock,
                NativeSoilRestartPositionV1::InProgressSupportCurrent,
            )?;
        }
        restored.diagnostic_restore_captured_residents_v1(
            captured,
            pinned_frozen_litter_lse_configuration,
            pinned_surface_configuration,
            trusted_frozen_residents,
        )?;
        restored.diagnostic_install_hydrology_constructor_inputs_v1(
            pinned_hydrology_constructor_inputs,
        );
        restored.diagnostic_restore_bound_clock_mode_v1(clock)?;
        Ok(restored)
    }

    #[cfg(all(test, feature = "persisted-restart-v1"))]
    fn diagnostic_restore_bound_clock_mode_v1(
        &mut self,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
    ) -> Result<(), DirectV10RealConsumerError> {
        // Native construction starts in the ordinary V10 mode. Restore the
        // independently authenticated clock mode through the existing guarded
        // installer, as the persisted native reader does. Never copy owner bytes.
        let mut lse_owners = clock
            .owners()
            .iter()
            .filter(|owner| owner.owner_id() == "land_surface_energy");
        let lse_bytes = lse_owners
            .next()
            .ok_or(DirectV9RealConsumerError::Identity(
                "native unique LSE clock mode absent",
            ))?
            .state_bytes();
        if lse_owners.next().is_some() {
            return Err(
                DirectV9RealConsumerError::Identity("native duplicate LSE clock mode").into(),
            );
        }
        self.restart_authority_install_clock_runtime_mode(lse_bytes)?;
        deferred_diagnostic_faults::reached(deferred_diagnostic_faults::Point::PrivateCandidate)?;
        if self
            .restart_authority_complete_lse_clock_bytes()?
            .as_slice()
            != lse_bytes
        {
            return Err(DirectV9RealConsumerError::Identity(
                "native exact complete LSE clock mode/owner",
            )
            .into());
        }
        deferred_diagnostic_faults::reached(deferred_diagnostic_faults::Point::LseProjection)?;
        Ok(())
    }

    #[cfg(all(test, feature = "persisted-restart-v1"))]
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn diagnostic_restore_native_consumer_with_deferred_composite_v1(
        captured: &serde_json::Value,
        target_soil: DirectV10SoilThermalResidentV2,
        committed_bootstrap: DirectV10SoilThermalResidentV2,
        phase_diagnostics: &serde_json::Value,
        lane_maps_value: &serde_json::Value,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        hydrology_frame: DirectRunFrame,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
        pinned_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_provider_static_configuration: &SnowFreeHalfHourStaticConfiguration,
        pinned_hydrology_constructor_inputs: std::sync::Arc<DirectRunConstructorInputs>,
        admission_slot: &mut Option<crate::snow_stage3_v11_current_context_capture::member_restoration::ValidatedDeferredContextV1>,
    ) -> Result<Self, DirectV10RealConsumerError> {
        // Consume at the real entry boundary, before any source check.  A
        // failed attempt therefore cannot be retried with the same capability.
        let admission = admission_slot
            .take()
            .ok_or(DirectV9RealConsumerError::Identity(
                "deferred composite capability consumed",
            ))?;
        let operands = crate::snow_stage3_v11_current_context_capture::member_restoration::DeferredContextOperandsV1 {
            native: captured,
            soil: &target_soil,
            clock,
            phase: phase_diagnostics,
            lane_maps: lane_maps_value,
            bootstrap: &committed_bootstrap,
            frame: &hydrology_frame,
            inputs: pinned_hydrology_constructor_inputs.as_ref(),
        };
        let (prior_gsi_receipt, prepared_gsi_receipt, prior_gsi_state, prior_cursor) = admission
            .consume_gsi_v1(&operands, pinned_surface_configuration)
            .map_err(|_| {
                DirectV9RealConsumerError::Identity("deferred composite source-bound use")
            })?;
        let lane_maps: Vec<DiagnosticNativeLaneMapV1> =
            serde_json::from_value(lane_maps_value.clone())
                .map_err(|error| DirectV9RealConsumerError::Serialization(error.to_string()))?;
        let admission = Self::diagnostic_mint_deferred_composite_admission_v1(
            captured,
            &target_soil,
            &committed_bootstrap,
            clock,
            &hydrology_frame,
            pinned_surface_configuration,
            pinned_lse_configuration,
            pinned_frozen_litter_lse_configuration,
            pinned_provider_static_configuration,
            prior_gsi_receipt,
            prepared_gsi_receipt,
            prior_gsi_state,
            prior_cursor,
        )?;
        deferred_diagnostic_faults::reached(deferred_diagnostic_faults::Point::FullProof)?;
        let DeferredNativeCompositeAdmissionV1 {
            native: proof,
            prior_gsi_receipt,
            prepared_gsi_receipt,
            prior_gsi_state,
            prior_cursor,
            frozen_residents,
        } = admission;
        let captured_state: crate::runtime_inputs::DirectGsiOwnerStateV1 =
            diagnostic_native_field(captured, "gsi_owner_state")?;
        if captured_state != prior_gsi_state
            || prior_gsi_receipt.ending_state != prior_gsi_state
            || prepared_gsi_receipt.beginning_state != prior_gsi_state
        {
            return Err(
                DirectV9RealConsumerError::Identity("deferred composite GSI use custody").into(),
            );
        }
        let cursor_bytes: Vec<u8> =
            diagnostic_native_field(captured, "provider_cursor_canonical_json")?;
        let captured_cursor = SnowFreeHalfHourProviderCursor::restore_json(
            &cursor_bytes,
            pinned_provider_static_configuration,
            usize::try_from(prepared_gsi_receipt.day_index).map_err(|_| {
                DirectV9RealConsumerError::Identity("deferred composite GSI use day width")
            })?,
        )?;
        if captured_cursor != prior_cursor {
            return Err(DirectV9RealConsumerError::Identity(
                "deferred composite cursor use custody",
            )
            .into());
        }
        let restored = Self::diagnostic_restore_native_consumer_from_proof_v1(
            captured,
            target_soil,
            committed_bootstrap,
            lane_maps,
            clock,
            hydrology_frame,
            pinned_surface_configuration,
            pinned_lse_configuration,
            pinned_frozen_litter_lse_configuration,
            pinned_provider_static_configuration,
            pinned_hydrology_constructor_inputs,
            &proof,
            Some(&prior_gsi_receipt),
            Some(frozen_residents),
        )?;
        Ok(restored)
    }

    #[cfg(all(
        test,
        any(
            feature = "restart-authority-evidence",
            feature = "persisted-restart-v1"
        )
    ))]
    fn diagnostic_validate_surface_configuration_v1(
        captured: &serde_json::Value,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
    ) -> Result<(), DirectV10RealConsumerError> {
        let surface_configuration_canonical_json: Vec<u8> =
            diagnostic_native_field(captured, "surface_configuration_canonical_json")?;
        let captured_surface_configuration =
            DirectSurfaceLiquidConfiguration::from_canonical_bytes(
                &surface_configuration_canonical_json,
            )?;
        if captured_surface_configuration.canonical_bytes()?
            != pinned_surface_configuration.canonical_bytes()?
        {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic surface configuration/pinned authority join",
            )
            .into());
        }
        Ok(())
    }

    #[cfg(all(
        test,
        any(
            feature = "restart-authority-evidence",
            feature = "persisted-restart-v1"
        )
    ))]
    fn diagnostic_restore_captured_residents_v1(
        &mut self,
        captured: &serde_json::Value,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
        trusted_frozen_residents: Option<(FrozenLitterV3Resident, FrozenLitterV4Resident)>,
    ) -> Result<(), DirectV10RealConsumerError> {
        if let Some((physical, exact)) = trusted_frozen_residents {
            self.install_validated_frozen_litter_v4_residents(physical, exact)?;
        } else {
            let frozen_litter_residents: Option<DiagnosticFrozenLitterResidentsV1> =
                diagnostic_native_field(captured, "frozen_litter_residents")?;
            let frozen = frozen_litter_residents.ok_or(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Identity(
                    "diagnostic native target requires frozen-litter V3/V4 residents",
                ),
            ))?;
            self.diagnostic_restore_frozen_litter_residents_v1(
                frozen,
                pinned_frozen_litter_lse_configuration,
                pinned_surface_configuration,
            )?;
        }
        let accepted_interval_count: u64 =
            diagnostic_native_field(captured, "accepted_interval_count")?;
        let provider_gsi_receipt_sha256: String =
            diagnostic_native_field(captured, "provider_gsi_receipt_sha256")?;
        if provider_gsi_receipt_sha256.len() != 64 {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic provider GSI receipt width",
            )
            .into());
        }
        // This diagnostic must not authenticate scheduler position by assignment.
        // The file composer separately verifies outer position and retains any
        // original nested mismatch. This constructor never installs that scalar.
        if self.inner.accepted_interval_count != accepted_interval_count {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic captured scheduler position differs from constructor",
            )
            .into());
        }
        if self.inner.provider_gsi_receipt_sha256 != provider_gsi_receipt_sha256 {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic captured GSI receipt differs from constructor",
            )
            .into());
        }
        Ok(())
    }

    #[cfg(all(
        test,
        any(
            feature = "restart-authority-evidence",
            feature = "persisted-restart-v1"
        )
    ))]
    fn diagnostic_restore_frozen_litter_residents_v1(
        &mut self,
        frozen: DiagnosticFrozenLitterResidentsV1,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
    ) -> Result<(), DirectV10RealConsumerError> {
        let (physical, exact) = Self::diagnostic_decode_validate_frozen_litter_residents_v1(
            frozen,
            pinned_frozen_litter_lse_configuration,
            pinned_surface_configuration,
        )?;
        self.install_restored_frozen_litter_v4_residents(physical, exact)?;
        Ok(())
    }

    #[cfg(all(
        test,
        any(
            feature = "restart-authority-evidence",
            feature = "persisted-restart-v1"
        )
    ))]
    fn diagnostic_decode_validate_frozen_litter_residents_v1(
        frozen: DiagnosticFrozenLitterResidentsV1,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
    ) -> Result<(FrozenLitterV3Resident, FrozenLitterV4Resident), DirectV10RealConsumerError> {
        if &frozen.lse_configuration != pinned_frozen_litter_lse_configuration {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic frozen-litter LSE configuration/pinned authority join",
            )
            .into());
        }
        let surface_parent = DirectSurfaceLiquidConfiguration::from_canonical_bytes(
            &frozen.surface_parent_configuration_canonical_bytes,
        )?;
        if surface_parent.canonical_bytes()? != pinned_surface_configuration.canonical_bytes()? {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic frozen-litter surface parent/pinned authority join",
            )
            .into());
        }
        let surface_model = crate::direct_runtime::SurfaceLiquidOwnerModelDefinitionV2::
            restart_authority_from_canonical_bytes(
                &frozen.surface_model_definition_canonical_bytes,
            )?;
        let surface_configuration =
            crate::direct_runtime::SurfaceLiquidConfigurationV2::from_canonical_bytes(
                surface_parent,
                surface_model,
                &frozen.surface_configuration_canonical_bytes,
            )?;
        let surface_owner =
            crate::direct_runtime::SurfaceLiquidOwnerEnvelopeV2::from_canonical_bytes(
                surface_configuration.parent(),
                Some(&surface_configuration),
                &frozen.surface_owner_canonical_bytes,
            )?;
        let mut physical = FrozenLitterV3Resident::try_new(
            pinned_frozen_litter_lse_configuration.clone(),
            frozen.lse_state,
            surface_configuration,
            surface_owner,
        )?;
        physical.restore_restart_authority(
            &frozen.physical_publication_history,
            frozen.physical_wb14_parent.as_deref(),
            &frozen.physical_predecessor_receipt_chain_sha256,
        )?;
        let exact_owner = crate::LseSurfaceEnthalpyOwnerEnvelopeV1::from_canonical_bytes(
            &frozen.exact_surface_owner_canonical_bytes,
        )?;
        let exact = FrozenLitterV4Resident::try_restore(
            &physical,
            exact_owner,
            &frozen.exact_publication_history,
            &frozen.exact_publication_beginning_lse_v3_state_sha256,
        )?;
        Ok((physical, exact))
    }

    #[cfg(all(test, feature = "persisted-restart-v1"))]
    pub(crate) fn diagnostic_preflight_frozen_litter_residents_v1(
        captured: &serde_json::Value,
        pinned_frozen_litter_lse_configuration: &LandSurfaceEnergyConfiguration,
        pinned_surface_configuration: &DirectSurfaceLiquidConfiguration,
    ) -> Result<(), DirectV10RealConsumerError> {
        let frozen: DiagnosticFrozenLitterResidentsV1 = diagnostic_native_field::<
            Option<DiagnosticFrozenLitterResidentsV1>,
        >(
            captured, "frozen_litter_residents"
        )?
        .ok_or(DirectV9RealConsumerError::Identity(
            "diagnostic native target requires frozen-litter V3/V4 residents",
        ))?;
        let _ = Self::diagnostic_decode_validate_frozen_litter_residents_v1(
            frozen,
            pinned_frozen_litter_lse_configuration,
            pinned_surface_configuration,
        )?;
        Ok(())
    }

    #[cfg(all(
        test,
        any(
            feature = "restart-authority-evidence",
            feature = "persisted-restart-v1"
        )
    ))]
    pub(crate) fn diagnostic_validate_inactive_scheduler_from_frozen_litter_v1(
        captured: &serde_json::Value,
        configuration: &DirectSurfaceLiquidConfiguration,
        frame: &DirectRunFrame,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
    ) -> Result<(), DirectV10RealConsumerError> {
        let frozen_litter_residents: Option<DiagnosticFrozenLitterResidentsV1> =
            diagnostic_native_field(captured, "frozen_litter_residents")?;
        let frozen = frozen_litter_residents.ok_or(DirectV9RealConsumerError::Identity(
            "diagnostic native target requires frozen-litter V3/V4 residents",
        ))?;
        let surface_parent = DirectSurfaceLiquidConfiguration::from_canonical_bytes(
            &frozen.surface_parent_configuration_canonical_bytes,
        )?;
        if surface_parent.canonical_bytes()? != configuration.canonical_bytes()? {
            return Err(DirectV9RealConsumerError::Identity(
                "diagnostic frozen-litter surface parent/pinned authority join",
            )
            .into());
        }
        let surface_model = crate::direct_runtime::SurfaceLiquidOwnerModelDefinitionV2::
            restart_authority_from_canonical_bytes(
                &frozen.surface_model_definition_canonical_bytes,
            )?;
        let native_configuration =
            crate::direct_runtime::SurfaceLiquidConfigurationV2::from_canonical_bytes(
                surface_parent,
                surface_model,
                &frozen.surface_configuration_canonical_bytes,
            )?;
        let surface =
            frame
                .surface_liquid_shadow
                .as_ref()
                .ok_or(DirectV9RealConsumerError::Identity(
                    "native inactive scheduler frame surface absent",
                ))?;
        let surface_bytes = surface.canonical_bytes(configuration).map_err(|_| {
            DirectV9RealConsumerError::Identity("native inactive scheduler frame surface")
        })?;
        let count: u64 = diagnostic_native_field(captured, "accepted_interval_count")?;
        let wb14: Option<Vec<u8>> = diagnostic_native_field(captured, "wb14_parent")?;
        NativeSoilRestartAdmissionV1::diagnostic_validate_inactive_scheduler_v1(
            count,
            configuration,
            &surface_bytes,
            wb14.as_deref(),
            Some(&frozen.surface_owner_canonical_bytes),
            Some(&native_configuration),
            frozen.physical_wb14_parent.as_deref(),
            clock,
            frame.identity.run_id,
        )?;
        Ok(())
    }

    pub(crate) fn diagnostic_native_lane_maps_v1(&self) -> Vec<DiagnosticNativeLaneMapV1> {
        self.inner
            .layer_maps
            .iter()
            .map(|map| DiagnosticNativeLaneMapV1 {
                lane_index: map.ofe_lane.lane_index,
                lane_id: map.ofe_lane.lane_id,
                layer_ids: map.layer_ids.clone(),
            })
            .collect()
    }

    pub(crate) fn diagnostic_native_soil_v2(
        &self,
    ) -> Result<DirectV10SoilThermalResidentV2, DirectV10RealConsumerError> {
        self.soil_thermal_v2().cloned()
    }

    #[cfg(test)]
    pub(crate) fn diagnostic_restore_native_lane_maps_v1(
        maps: Vec<DiagnosticNativeLaneMapV1>,
    ) -> Result<Vec<RealHydrologyLaneLayerMap>, DirectV10RealConsumerError> {
        let mut restored = Vec::with_capacity(maps.len());
        for map in maps {
            if map.layer_ids.is_empty() {
                return Err(DirectV9RealConsumerError::Identity("native lane map topology").into());
            }
            restored.push(RealHydrologyLaneLayerMap {
                ofe_lane: RealHydrologyOfeLaneId {
                    lane_index: map.lane_index,
                    lane_id: map.lane_id,
                },
                layer_ids: map.layer_ids,
            });
        }
        Ok(restored)
    }
}

include!("v9_real_consumer_shadow_equilibrium_fixture.rs");

include!("v9_real_consumer_shadow_publication_retention.rs");
include!("v9_real_consumer_shadow_root_zone_configuration.rs");
#[path = "v9_real_consumer_shadow/accepted_publication_support_capability.rs"]
mod accepted_publication_support_capability;
use accepted_publication_support_capability::{
    AcceptedPublicationHistoryLiveRevisionV1, PreparedStage3AcceptedPublicationSupportV1,
    ValidatedStage3AcceptedPublicationSupportV1,
};
#[cfg(test)]
pub(crate) use accepted_publication_support_capability::{
    AcceptedPublicationLiveRevisionPoisonV1, AcceptedPublicationSupportCapabilityAuditV1,
    begin_accepted_publication_support_capability_audit_v1,
    take_accepted_publication_support_capability_audit_v1,
};
#[path = "v9_real_consumer_shadow/frozen_litter_v3_adoption.rs"]
mod frozen_litter_v3_adoption;
pub use frozen_litter_v3_adoption::FrozenLitterV3Resident;
pub(crate) use frozen_litter_v3_adoption::ValidatedV9ToV8ProjectionV1;
#[path = "v9_real_consumer_shadow/frozen_litter_v4_adoption.rs"]
mod frozen_litter_v4_adoption;
pub use frozen_litter_v4_adoption::FrozenLitterV4Resident;
#[path = "v9_real_consumer_shadow/frozen_litter_v3_publication_retention.rs"]
mod frozen_litter_v3_publication_retention;
#[path = "v9_real_consumer_shadow/snow_free_physical_reuse.rs"]
mod snow_free_physical_reuse;
#[cfg(any(test, feature = "restart-authority-evidence"))]
pub(crate) use frozen_litter_v3_publication_retention::FrozenLitterV3PublicationSupportV1;
#[cfg(any(test, feature = "persisted-restart-v1"))]
pub(crate) use snow_free_physical_reuse::record_snow_free_outer_accepted_publication_v1;
pub(crate) use snow_free_physical_reuse::{
    SnowFreePhysicalReusePendingV1, SnowFreePhysicalReuseSeedV1, prepare_snow_free_physical_reuse,
};
#[cfg(test)]
pub(crate) use snow_free_physical_reuse::{
    record_snow_free_ingress_operation_v1, record_snow_free_phase_operation_v1,
    record_snow_free_provider_projection_v1, record_snow_free_routing_operation_v1,
    record_snow_free_vapor_operation_v1, record_snow_free_wb14_operations_v1,
};
#[cfg(feature = "persisted-restart-v1")]
pub use snow_free_physical_reuse::{
    restart_authority_execute_fresh_snow_free_segment_v1,
    restart_authority_v11_parent_owner_envelopes_v1,
};
#[cfg(test)]
#[path = "v9_real_consumer_shadow/accepted_publication_support_capability_tests.rs"]
mod accepted_publication_support_capability_tests;
#[cfg(test)]
#[path = "v9_real_consumer_shadow/v3_publication_retention_tests.rs"]
mod v3_publication_retention_tests;

pub type DirectV10ShadowDayInput = DirectV9ShadowDayInput;
pub type DirectV10ShadowDayReceipt = DirectV9ShadowDayReceipt;

#[derive(Debug, Error, PartialEq)]
pub enum DirectV10RealConsumerError {
    #[error("root-zone configuration identity failure: {0}")]
    RootConfigurationIdentity(&'static str),
    #[error("root-zone scalar domain failure: {0}")]
    RootDomain(&'static str),
    #[error(transparent)]
    V10(#[from] V10StateError),
    #[error(transparent)]
    LseV2(#[from] LseV2StateError),
    #[error(transparent)]
    LseV3(#[from] openwepp_land_surface_energy::LseV3StateError),
    #[error(transparent)]
    SurfaceLiquidV2(#[from] crate::DirectSurfaceLiquidError),
    #[error(transparent)]
    ExactSurfaceEnthalpy(#[from] crate::LseSurfaceEnthalpyErrorV1),
    #[error(transparent)]
    LandSurface(#[from] LandSurfaceEnergyError),
    #[error(transparent)]
    ForcingProvider(#[from] SnowFreeHalfHourForcingError),
    #[error(transparent)]
    Runtime(#[from] DirectV9RealConsumerError),
}

impl DirectV10RealConsumerError {
    #[must_use]
    pub const fn category(&self) -> &'static str {
        match self {
            Self::RootConfigurationIdentity(_) => "root_configuration_identity",
            Self::RootDomain(_) => "root_domain",
            Self::V10(_) => "vegetation_v10",
            Self::LseV2(_) => "land_surface_energy_v2",
            Self::LseV3(_) => "land_surface_energy_v3",
            Self::SurfaceLiquidV2(_) => "surface_liquid_v2",
            Self::ExactSurfaceEnthalpy(_) => "exact_surface_enthalpy",
            Self::LandSurface(_) => "land_surface_energy",
            Self::ForcingProvider(_) => "forcing_provider",
            Self::Runtime(error) => error.category(),
        }
    }
}

fn v11_owner_envelope<T: Serialize>(
    owner_id: &str,
    value: &T,
) -> Result<V11OwnerEnvelope, DirectV11RealConsumerError> {
    Ok(V11OwnerEnvelope::try_new(
        owner_id.to_owned(),
        serde_json::to_vec(value)?,
    )?)
}

pub(crate) fn v11_soil_thermal_owner_envelope(
    owner: &DirectSoilThermalResident,
) -> Result<V11OwnerEnvelope, DirectV11RealConsumerError> {
    V11OwnerEnvelope::try_new(
        "soil_thermal".to_owned(),
        owner
            .canonical_active_owner_bytes()
            .map_err(DirectV10RealConsumerError::Runtime)?,
    )
    .map_err(Into::into)
}

/// Select the LSE beginning that exactly owns the staged V11 bytes.
///
/// Frozen-litter V3/V4 retains the legacy LSE state only as an inner
/// compatibility projection. Support receipts must bind the native V3 owner
/// whenever that owner occupies the staged complete-owner set.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum V11SupportLseRole {
    Covered,
    NativeSnowFree,
}

pub(crate) fn v11_support_lse_beginning<'a>(
    beginning: &'a DirectV10RealConsumerShadow,
    staged_lse_bytes: &[u8],
    role: V11SupportLseRole,
) -> Result<
    (
        &'a LandSurfaceEnergyConfiguration,
        &'a LandSurfaceEnergyState,
    ),
    DirectV11RealConsumerError,
> {
    if openwepp_land_surface_energy::snow_accuracy_policy::Policy::current().identity() == Some(14)
        && (beginning.frozen_litter_v3.is_some() || beginning.frozen_litter_v4.is_some())
    {
        composite_lse_owner::CompositeLseOwnerV1::from_canonical_bytes(staged_lse_bytes)
            .map_err(|_| DirectV11RealConsumerError::Identity("composite support transport"))?;
        if staged_lse_bytes != beginning.canonical_v11_lse_owner_bytes()? {
            return Err(DirectV11RealConsumerError::Identity(
                "policy14 composite support owner",
            ));
        }
        return if role == V11SupportLseRole::Covered {
            Ok((
                &beginning.inner.lse_configuration,
                &beginning.inner.lse_state,
            ))
        } else {
            let physical =
                beginning
                    .frozen_litter_v3
                    .as_ref()
                    .ok_or(DirectV11RealConsumerError::Identity(
                        "composite support missing native owner",
                    ))?;
            Ok((physical.lse_configuration(), &physical.lse_state().0))
        };
    }
    let inner_lse_bytes = serde_json::to_vec(&beginning.inner.lse_state).map_err(|error| {
        DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(
            DirectV9RealConsumerError::Serialization(error.to_string()),
        ))
    })?;
    let resident_bytes = beginning
        .frozen_litter_v3
        .as_ref()
        .map(|resident| {
            serde_json::to_vec(resident.lse_state()).map_err(|error| {
                DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(
                    DirectV9RealConsumerError::Serialization(error.to_string()),
                ))
            })
        })
        .transpose()?;
    let exact_resident_bytes =
        beginning
            .frozen_litter_v4
            .as_ref()
            .map(|exact| {
                let physical = beginning.frozen_litter_v3.as_ref().ok_or(
                    DirectV11RealConsumerError::Identity(
                        "native V4 support selection requires physical resident",
                    ),
                )?;
                exact
                    .v11_complete_lse_owner_bytes(physical)
                    .map_err(DirectV11RealConsumerError::Runtime)
            })
            .transpose()?;
    match select_v11_support_lse_bytes(
        staged_lse_bytes,
        &inner_lse_bytes,
        resident_bytes.as_deref(),
        exact_resident_bytes.as_deref(),
        beginning.inner.authority == CoveredColumnAuthority::V11SnowCovered,
    )? {
        V11SupportLseSelection::Legacy => Ok((
            &beginning.inner.lse_configuration,
            &beginning.inner.lse_state,
        )),
        V11SupportLseSelection::NativeV3 | V11SupportLseSelection::NativeV4 => {
            let resident =
                beginning
                    .frozen_litter_v3
                    .as_ref()
                    .ok_or(DirectV11RealConsumerError::Identity(
                        "native V3 support selection requires resident",
                    ))?;
            Ok((resident.lse_configuration(), &resident.lse_state().0))
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum V11SupportLseSelection {
    Legacy,
    NativeV3,
    NativeV4,
}

fn select_v11_support_lse_bytes(
    staged_lse_bytes: &[u8],
    legacy_lse_bytes: &[u8],
    native_v3_lse_bytes: Option<&[u8]>,
    native_v4_lse_bytes: Option<&[u8]>,
    allow_covered_inner_with_inactive_native_v4: bool,
) -> Result<V11SupportLseSelection, DirectV11RealConsumerError> {
    if allow_covered_inner_with_inactive_native_v4 && staged_lse_bytes == legacy_lse_bytes {
        return Ok(V11SupportLseSelection::Legacy);
    }
    if let Some(native_v4) = native_v4_lse_bytes {
        return (staged_lse_bytes == native_v4)
            .then_some(V11SupportLseSelection::NativeV4)
            .ok_or(DirectV11RealConsumerError::Identity(
                "staged LSE owner does not match the exact native V4 resident",
            ));
    }
    if staged_lse_bytes == legacy_lse_bytes {
        return Ok(V11SupportLseSelection::Legacy);
    }
    if native_v3_lse_bytes.is_some_and(|native| staged_lse_bytes == native) {
        return Ok(V11SupportLseSelection::NativeV3);
    }
    Err(DirectV11RealConsumerError::Identity(
        if native_v3_lse_bytes.is_some() {
            "staged LSE owner is neither legacy beginning nor native V3 resident"
        } else {
            "staged LSE owner does not match the resident beginning"
        },
    ))
}

#[cfg(test)]
mod covered_support_receipt_selection_tests {
    use super::*;

    #[test]
    fn covered_receipt_selects_exact_legacy_staged_bytes() {
        assert_eq!(
            select_v11_support_lse_bytes(b"legacy", b"legacy", Some(b"native"), None, false)
                .expect("legacy bytes"),
            V11SupportLseSelection::Legacy,
        );
    }

    #[test]
    fn covered_receipt_selects_exact_native_v3_staged_bytes() {
        assert_eq!(
            select_v11_support_lse_bytes(b"native", b"legacy", Some(b"native"), None, false)
                .expect("native V3 bytes"),
            V11SupportLseSelection::NativeV3,
        );
    }

    #[test]
    fn covered_receipt_selects_exact_native_v4_staged_bytes() {
        assert_eq!(
            select_v11_support_lse_bytes(
                b"native-v4",
                b"legacy",
                Some(b"native-v3"),
                Some(b"native-v4"),
                false,
            )
            .expect("native V4 bytes"),
            V11SupportLseSelection::NativeV4,
        );
    }

    #[test]
    fn covered_receipt_refuses_legacy_or_v3_downgrade_after_v4_adoption() {
        for staged in [b"legacy".as_slice(), b"native-v3".as_slice()] {
            assert!(
                select_v11_support_lse_bytes(
                    staged,
                    b"legacy",
                    Some(b"native-v3"),
                    Some(b"native-v4"),
                    false,
                )
                .is_err()
            );
        }
    }

    #[test]
    fn represented_snow_selects_active_inner_with_inactive_native_v4() {
        assert_eq!(
            select_v11_support_lse_bytes(
                b"covered-inner",
                b"covered-inner",
                Some(b"native-v3"),
                Some(b"native-v4"),
                true,
            )
            .expect("represented-snow active inner LSE"),
            V11SupportLseSelection::Legacy,
        );
    }

    #[test]
    fn covered_receipt_rejects_mismatched_or_missing_native_owner() {
        for native in [None, Some(b"native".as_slice())] {
            assert!(
                select_v11_support_lse_bytes(b"poison", b"legacy", native, None, false).is_err()
            );
        }
    }

    #[test]
    fn covered_receipt_mismatch_is_exact_rollback_with_no_publication() {
        let staged = b"poison".to_vec();
        let legacy = b"legacy".to_vec();
        let native = b"native".to_vec();
        let before = (
            staged.clone(),
            legacy.clone(),
            native.clone(),
            Vec::<Vec<u8>>::new(),
        );
        assert!(
            select_v11_support_lse_bytes(&staged, &legacy, Some(&native), None, false).is_err(),
            "mismatch must fail before receipt construction or publication",
        );
        assert_eq!(
            (staged, legacy, native, Vec::<Vec<u8>>::new()),
            before,
            "pure selection failure preserves all owner bytes and publishes nothing",
        );
    }
}

struct ImportedStackProfileScopeV1 {
    phase: &'static str,
    started: Option<std::time::Instant>,
    _compact: openwepp_land_surface_energy::solver_mechanism_audit::compact_cost::Guard,
}

impl ImportedStackProfileScopeV1 {
    fn begin(phase: &'static str) -> Self {
        use openwepp_land_surface_energy::solver_mechanism_audit::compact_cost::{self, Bucket};
        let bucket = match phase {
            "imported frozen execute accept" => Bucket::ImportedFrozenExecute,
            "imported frozen runtime" => Bucket::ImportedFrozenRuntime,
            "imported envelope construction" => Bucket::ImportedEnvelopeConstruction,
            "imported accepted candidate" => Bucket::ImportedAcceptedCandidate,
            "imported entry validation"
            | "imported envelope validation"
            | "imported reuse validation"
            | "imported reuse reseal"
            | "imported frozen acceptance" => Bucket::RequiredIntegrity,
            "imported owner publication" | "imported install" | "imported reuse install" => {
                Bucket::ImportedPublicationInstall
            }
            _ => Bucket::OtherNamed,
        };
        Self {
            phase,
            _compact: compact_cost::scope(bucket),
            started: profile_start(),
        }
    }
}

impl Drop for ImportedStackProfileScopeV1 {
    fn drop(&mut self) {
        profile_record(self.phase, self.started.take());
    }
}

impl crate::v11_vegetation_consumer::DirectV11ImportedStack for DirectV11RealConsumerStack<'_> {
    type Error = DirectV11RealConsumerError;

    #[allow(clippy::too_many_lines)]
    fn execute_imported_v10_stack(
        &mut self,
        input: &V11ImportedV10SegmentInput,
    ) -> Result<V11ImportedV10SegmentOutput, Self::Error> {
        if self.snow_free_physical_reuse_pending.is_some()
            || self.snow_free_physical_reuse_seed.is_some()
        {
            return self.execute_snow_free_physical_reuse(input);
        }
        #[cfg(any(test, feature = "persisted-restart-v1"))]
        snow_free_physical_reuse::record_snow_free_physical_execution_v1();
        let entry_profile = ImportedStackProfileScopeV1::begin("imported entry validation");
        if input.configuration != self.beginning.vegetation_configuration
            || input.beginning != self.beginning.vegetation_state
            || input.duration_s_bits != input.support.duration_s_bits()
            || self.interval.lse_forcing.interval_s.to_bits() != input.duration_s_bits
        {
            return Err(DirectV11RealConsumerError::Identity(
                "accepted slab / DirectV10 beginning join",
            ));
        }
        let _interval_index = u8::try_from(self.interval_index)
            .map_err(|_| DirectV11RealConsumerError::Identity("V11 interval index overflow"))?;
        // V3 imports the unchanged V1 support-admission receipt schema and
        // policy, but its identity fields must bind the native successor
        // configuration/state published in the staged complete-owner set.
        // The legacy/V2 paths continue to bind their existing inner owner.
        let staged_lse_bytes = &input
            .staged_resource_owners
            .get("land_surface_energy")
            .ok_or(DirectV11RealConsumerError::Identity(
                "missing staged LSE owner",
            ))?
            .state_bytes;
        let (support_configuration, support_beginning) = v11_support_lse_beginning(
            &self.beginning,
            staged_lse_bytes,
            V11SupportLseRole::NativeSnowFree,
        )?;
        let support_receipt = LseSupportAdmissibilityReceiptV1::admit(
            support_configuration,
            support_beginning,
            digest32_hex(input.parent_transaction_id.digest()),
            digest32_hex(input.accepted_slab_receipt.segment_id().digest()),
            digest32_hex(input.accepted_slab_receipt.slab_id().digest()),
            input.accepted_slab_receipt.slab_ordinal(),
            input.support.start_ns().get(),
            input.support.end_ns().get(),
            input.duration_s_bits,
            self.beginning.inner.soil_thermal.state_sha256().clone(),
        )
        .map_err(|error| {
            DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::LandSurface(error))
        })?;
        drop(entry_profile);
        let physical_candidate_profile =
            ImportedStackProfileScopeV1::begin("imported physical candidate");
        let physical_setup_profile = ImportedStackProfileScopeV1::begin("imported physical setup");
        let mut candidate = self.beginning.clone();
        // This imported stack is the explicit snow-free V11 successor. A
        // preceding covered/terminal segment leaves the retained carrier
        // authority as `V11SnowCovered`; carrying that authority into this
        // segment would demand a Stage-3 lower-boundary set after the snow
        // owner has disappeared. Install the imported V10 authority on the
        // unpublished candidate before projection. V10, unlike historical
        // V8, owns the exact inactive hydraulic anchors required by a
        // structurally zero occupancy while retaining the snow-free boundary.
        install_imported_v10_snow_free_authority(&mut candidate);
        match self.native_inactive_wb14_prefix {
            Some(prefix) => candidate
                .stage_frozen_litter_wb14_parent_after_native_inactive_prefix_v1(
                    self.day_index,
                    self.interval_index,
                    self.interval,
                    self.wb14_coupled_child_binding
                        .ok_or(DirectV11RealConsumerError::Identity(
                            "native inactive prefix coupled-child binding",
                        ))?,
                    prefix,
                ),
            None => candidate.stage_frozen_litter_wb14_parent_from_inner_v1(),
        }
        .map_err(DirectV11RealConsumerError::Runtime)?;
        let deferred_v4_soil_candidate = self
            .deferred_native_v2_soil_custody
            .as_ref()
            .map(DeferredNativeV2SoilCustodyV1::candidate);
        let deferred_v4_soil_continuation = self
            .deferred_native_v2_soil_custody
            .as_ref()
            .and_then(DeferredNativeV2SoilCustodyV1::continuation);
        drop(physical_setup_profile);
        let frozen_evaluation_profile =
            ImportedStackProfileScopeV1::begin("imported frozen evaluation");
        let mut frozen_litter_v4 = if candidate.frozen_litter_v4.is_some() {
            let binding =
                self.wb14_coupled_child_binding
                    .ok_or(DirectV11RealConsumerError::Identity(
                        "native frozen-litter V4 requires coupled-child binding",
                    ))?;
            let frozen_preparation_profile =
                ImportedStackProfileScopeV1::begin("imported frozen preparation");
            let fixed = candidate.prepare_frozen_litter_v3_fixed_final(
                self.day_index,
                self.interval_index,
                self.interval,
                input.duration_s_bits,
                self.finalize_wb14_parent_interval,
                binding,
                deferred_v4_soil_candidate,
                deferred_v4_soil_continuation,
            )?;
            drop(frozen_preparation_profile);
            let frozen_execute_accept_profile =
                ImportedStackProfileScopeV1::begin("imported frozen execute accept");
            let accepted = candidate.execute_and_accept_frozen_litter_v4(
                &fixed,
                input.support.start_ns().get(),
                input.support.end_ns().get(),
                self.finalize_wb14_parent_interval,
                binding,
                deferred_v4_soil_continuation,
            )?;
            drop(frozen_execute_accept_profile);
            Some((fixed, accepted))
        } else {
            None
        };
        let frozen_litter_v3 = if frozen_litter_v4.is_none() && candidate.frozen_litter_v3.is_some()
        {
            let binding =
                self.wb14_coupled_child_binding
                    .ok_or(DirectV11RealConsumerError::Identity(
                        "native frozen-litter V3 requires coupled-child binding",
                    ))?;
            let frozen_preparation_profile =
                ImportedStackProfileScopeV1::begin("imported frozen preparation");
            let fixed = candidate.prepare_frozen_litter_v3_fixed_final(
                self.day_index,
                self.interval_index,
                self.interval,
                input.duration_s_bits,
                self.finalize_wb14_parent_interval,
                binding,
                None,
                None,
            )?;
            drop(frozen_preparation_profile);
            let frozen_execute_accept_profile =
                ImportedStackProfileScopeV1::begin("imported frozen execute accept");
            let accepted = candidate.execute_and_accept_frozen_litter_v3(
                &fixed,
                input.support.start_ns().get(),
                input.support.end_ns().get(),
                self.finalize_wb14_parent_interval,
                binding,
            )?;
            drop(frozen_execute_accept_profile);
            Some((fixed, accepted))
        } else {
            None
        };
        drop(frozen_evaluation_profile);
        let envelope_construction_profile =
            ImportedStackProfileScopeV1::begin("imported envelope construction");
        let deferred_soil = self.deferred_native_v2_soil_custody.as_ref();
        let envelope = if let Some((fixed, accepted)) = frozen_litter_v4.as_ref() {
            candidate.construct_frozen_litter_v3_complete_envelope(
                self.day_index,
                input.duration_s_bits,
                fixed,
                &accepted.physical,
                true,
            )?
        } else if let Some((fixed, accepted)) = frozen_litter_v3.as_ref() {
            if deferred_soil.is_some() {
                return Err(DirectV11RealConsumerError::Identity(
                    "native frozen-litter V3 deferred soil custody is not yet joined",
                ));
            }
            candidate.construct_frozen_litter_v3_complete_envelope(
                self.day_index,
                input.duration_s_bits,
                fixed,
                accepted,
                false,
            )?
        } else {
            candidate
                .inner
                .construct_snow_free_parent_child_envelope_with_duration_and_soil_beginning(
                    self.day_index,
                    self.interval_index,
                    self.interval,
                    f64::from_bits(input.duration_s_bits),
                    Some(input.duration_s_bits),
                    self.finalize_wb14_parent_interval,
                    self.wb14_coupled_child_binding,
                    deferred_soil.map(DeferredNativeV2SoilCustodyV1::candidate),
                    deferred_soil.and_then(DeferredNativeV2SoilCustodyV1::continuation),
                )
                .map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error))
                })?
        };
        drop(envelope_construction_profile);
        let envelope_validation_profile =
            ImportedStackProfileScopeV1::begin("imported envelope validation");
        envelope.validate().map_err(|error| {
            DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error.into()))
        })?;
        drop(envelope_validation_profile);
        drop(physical_candidate_profile);
        let accepted_candidate_profile =
            ImportedStackProfileScopeV1::begin("imported accepted candidate");

        let mut resource_debits = v11_nitrogen_resource_debits(
            &envelope,
            &self.beginning.inner.lse_configuration,
            input,
        )?;
        resource_debits.extend(v11_water_resource_debits(
            &envelope,
            &input.configuration,
            input,
        )?);

        let completed_deferred_soil = deferred_soil
            .map(|custody| custody.advance_snow_free_child(&self.beginning, input, &envelope))
            .transpose()?;
        if let Some(custody) = completed_deferred_soil.as_ref() {
            #[cfg(test)]
            record_integrated_promotion_boundary_v1("deferred-completion", false);
            let continuation =
                custody
                    .continuation()
                    .ok_or(DirectV11RealConsumerError::Identity(
                        "deferred native V2 soil final continuation",
                    ))?;
            #[cfg(test)]
            record_integrated_promotion_boundary_v1("final-replay-entry", false);
            #[cfg(test)]
            if integrated_promotion_boundary_audit_enabled_v1() {
                let trial = continuation.physical_trial();
                let hydrology = envelope.hydrology();
                let pre_ingress_soil = hydrology
                    .pre_ingress_soil_thermal_candidates()
                    .iter()
                    .map(|tile| serde_json::json!({
                        "owner_id": tile.owner_id,
                        "ofe_id": tile.ofe_id,
                        "tile_id": tile.tile_id,
                        "beginning_state_sha256": tile.beginning_state_sha256,
                        "beginning_identity": tile.beginning_identity,
                        "layers": tile.layers.iter().map(|layer| serde_json::json!({
                            "layer_id": layer.layer_id,
                            "beginning_enthalpy_bits": layer.beginning_enthalpy_j_m2_ofe_ground.to_bits(),
                            "ground_heat_credit_bits": layer.ground_heat_credit_j_m2_ofe_ground.to_bits(),
                            "infiltration_enthalpy_credit_bits": layer.infiltration_enthalpy_credit_j_m2_ofe_ground.to_bits(),
                            "ending_enthalpy_bits": layer.ending_enthalpy_j_m2_ofe_ground.to_bits(),
                            "ending_temperature_bits": layer.ending_temperature_k.to_bits(),
                        })).collect::<Vec<_>>(),
                    }))
                    .collect::<Vec<_>>();
                let ingress = hydrology.surface_ingress();
                println!("B01_INTEGRATED_LINEAGE {}", serde_json::to_string(&serde_json::json!({
                    "original_prepared_owner": continuation.original_prepared().beginning_owner(),
                    "physical_trial": {
                        "transaction_id": trial.transaction_id().0,
                        "predecessor_transaction_id": trial.predecessor_transaction_id().map(|id| id.0),
                        "support_start_ns": trial.support_start_ns(),
                        "support_end_ns": trial.support_end_ns(),
                        "beginning_state_sha256": trial.beginning_state_sha256(),
                        "accepted_predecessor_receipt_chain_sha256": trial.accepted_predecessor_receipt_chain_sha256(),
                        "unpublished_predecessor_trial_sha256": trial.unpublished_predecessor_trial_sha256(),
                        "unpublished_trial_sha256": trial.unpublished_trial_sha256(),
                        "selected_ending_state": trial.ending_state(),
                        "layer_credits": trial.layer_credits(),
                    },
                    "accumulated_operands": continuation.accumulated_operands(),
                    "ordered_layer_credit_chain": continuation.diagnostic_layer_credit_chain(),
                    "pre_ingress_soil_thermal": pre_ingress_soil,
                    "surface_ingress_receipts": ingress.receipts(),
                    "surface_ingress_ledgers": ingress.ledgers(),
                    "wb14_child_replay_bytes": ingress.wb14_child_replay_bytes(),
                    "wb14_parent_replay_bytes": ingress.wb14_parent_replay_bytes(),
                })).expect("integrated lineage JSON"));
            }
            let accepted = continuation
                .compose_accepted_outer_candidate(&self.beginning.inner.lse_configuration)
                .map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error))
                })?;
            let seals = seal_soil_thermal_accepted_candidate_v2(
                continuation.original_prepared().beginning_owner(),
                &accepted,
            )
            .map_err(|error| {
                DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error))
            })?;
            #[cfg(test)]
            if let Some(control) = take_integrated_final_replay_control_v1() {
                let mut wrong = accepted.clone();
                match control {
                    B01IntegratedFinalReplayControlV1::SelectedEnding => {
                        let original_temperature = continuation
                            .original_prepared()
                            .beginning_owner()
                            .state
                            .ofes[0]
                            .ordered_layers[0]
                            .temperature_k;
                        let ending_layer = &mut wrong.ending_owner.state.ofes[0].ordered_layers[0];
                        assert_ne!(
                            ending_layer.temperature_k.to_bits(),
                            original_temperature.to_bits(),
                            "native fixture requires a distinct original and selected ending temperature"
                        );
                        ending_layer.temperature_k = original_temperature;
                    }
                    B01IntegratedFinalReplayControlV1::CreditReceiptLineage => {
                        wrong.credit_receipt.predecessor_receipt_chain_sha256 =
                            openwepp_land_surface_energy::Sha256Digest::try_new(
                                "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
                            )
                            .expect("valid credit lineage mismatch digest");
                    }
                    B01IntegratedFinalReplayControlV1::AccumulatedSourceIdentity => {
                        let mut operands = wrong.expected_sources.accepted_operands().to_vec();
                        operands[0].debit_credit_identity_sha256 =
                            openwepp_land_surface_energy::Sha256Digest::try_new(
                                "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                            )
                            .expect("valid accumulated source-identity mismatch digest");
                        wrong.expected_sources = SoilThermalExpectedAcceptedOperandSetV2::try_new(
                            continuation.original_prepared().beginning_owner(),
                            &self.beginning.inner.lse_configuration,
                            operands,
                        )
                        .expect("canonical expected source set admits one changed source identity");
                    }
                }
                let error = candidate
                    .validate_soil_thermal_accepted_v2_from_unpublished_continuation(
                        continuation.physical_trial(),
                        continuation,
                        continuation.original_prepared().beginning_owner(),
                        &wrong,
                    )
                    .expect_err("poisoned selected final replay join must fail");
                let DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::OwnerClosure(
                    detail,
                )) = &error
                else {
                    panic!("final replay control must retain typed owner closure: {error}");
                };
                assert_eq!(*detail, "V2 selected continuation final replay join");
                println!(
                    "B01_INTEGRATED_FINAL_REPLAY_CONTROL {}",
                    serde_json::json!({"control":format!("{control:?}"),"error":error.to_string()})
                );
                std::panic::panic_any(B01IntegratedFinalReplayN8Sentinel);
            }
            candidate
                .validate_soil_thermal_accepted_v2_from_unpublished_continuation(
                    continuation.physical_trial(),
                    continuation,
                    continuation.original_prepared().beginning_owner(),
                    &accepted,
                )
                .map_err(DirectV11RealConsumerError::Runtime)?;
            #[cfg(test)]
            record_integrated_promotion_boundary_v1("final-replay-success", false);
            candidate
                .inner
                .accept_envelope_preserving_native_v2_soil(envelope.transaction_id(), &envelope)
                .map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error))
                })?;
            candidate.vegetation_state = project_v9_runtime_to_v10(
                candidate.inner.vegetation_state(),
                &candidate.vegetation_configuration,
            )
            .map_err(|error| {
                DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::V10(error))
            })?;
            candidate.lse_state = project_validated_v1_runtime_to_v2(
                &candidate.inner.lse_configuration,
                candidate.inner.lse_state(),
                &candidate.lse_configuration,
                &openwepp_land_surface_energy::Sha256Digest::try_new(
                    candidate
                        .vegetation_configuration
                        .configuration_sha256
                        .clone(),
                )
                .map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::LandSurface(
                        error,
                    ))
                })?,
            )
            .map_err(|error| {
                DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::LseV2(error))
            })?;
            let authoritative_complete_envelope = candidate.clone();
            #[cfg(test)]
            if take_integrated_missing_replay_n3_v1() {
                assert!(
                    self.snow_free_physical_reuse_pending.is_none()
                        && self.snow_free_physical_reuse_seed.is_none(),
                    "N3 genuine pre-install boundary has no deferred reuse capability"
                );
                let caller_snapshot = || {
                    serde_json::to_vec(&serde_json::json!({
                        "beginning": self.beginning.canonical_v11_parent_owner_state_bytes().expect("N3 caller snapshot beginning"),
                        "beginning_debug": format!("{:#?}", self.beginning),
                        "interval": format!("{:?}", self.interval),
                        "day_index": self.day_index,
                        "interval_index": self.interval_index,
                        "finalize_wb14_parent_interval": self.finalize_wb14_parent_interval,
                        "wb14_coupled_child_binding": format!("{:?}", self.wb14_coupled_child_binding),
                        "native_inactive_wb14_prefix": format!("{:?}", self.native_inactive_wb14_prefix),
                        "ending": self.ending.as_ref().map(|ending| ending.canonical_v11_parent_owner_state_bytes().expect("N3 caller snapshot ending")),
                        "ending_debug": self.ending.as_ref().map(|ending| format!("{ending:#?}")),
                        "last_support_receipt": &self.last_support_receipt,
                        "last_hydrology_candidate": format!("{:?}", self.last_hydrology_candidate),
                        "ending_snow_owner_bytes": &self.ending_snow_owner_bytes,
                        "deferred_native_v2_soil_custody": format!("{:?}", self.deferred_native_v2_soil_custody),
                        "snow_free_physical_reuse_pending_present": self.snow_free_physical_reuse_pending.is_some(),
                        "snow_free_physical_reuse_seed_present": self.snow_free_physical_reuse_seed.is_some(),
                    }))
                    .expect("N3 caller snapshot JSON")
                };
                let caller_before = caller_snapshot();
                let mut disposable = authoritative_complete_envelope.clone();
                let receiver_before = disposable.clone();
                let receiver_before_owner_state =
                    disposable.canonical_v11_parent_owner_state_bytes()?;
                let receiver_at_guard_debug = format!("{disposable:#?}");
                let accepted = &mut frozen_litter_v4
                    .as_mut()
                    .ok_or(DirectV11RealConsumerError::Identity(
                        "missing-replay N3 requires genuine V4 candidate",
                    ))?
                    .1;
                let error = disposable
                    .accept_promoted_candidate_only_frozen_litter_v4(
                        &self.beginning,
                        continuation.original_prepared().beginning_owner(),
                        accepted,
                    )
                    .expect_err("missing accepted replay must reject deferred V4 promotion");
                let expected_detail = "V4 deferred promotion requires one accepted soil replay";
                assert_eq!(error.category(), "owner_closure");
                let DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::OwnerClosure(
                    detail,
                )) = &error
                else {
                    panic!("N3 must retain the source-defined missing-replay wrapper: {error}");
                };
                assert_eq!(*detail, expected_detail);
                let receiver_after_owner_state =
                    disposable.canonical_v11_parent_owner_state_bytes()?;
                let receiver_after_debug = format!("{disposable:#?}");
                let caller_after = caller_snapshot();
                let receiver_unchanged = disposable == receiver_before;
                let receiver_debug_unchanged = receiver_at_guard_debug == receiver_after_debug;
                let caller_unchanged = caller_before == caller_after;
                println!(
                    "B01_INTEGRATED_N3 {}",
                    serde_json::to_string(&serde_json::json!({
                        "guard": expected_detail,
                        "outer_error_category": error.category(),
                        "outer_error_display": error.to_string(),
                        "receiver_before_owner_state": &receiver_before_owner_state,
                        "receiver_at_guard_debug": receiver_at_guard_debug,
                        "receiver_after_owner_state": &receiver_after_owner_state,
                        "receiver_after_debug": receiver_after_debug,
                        "caller_stack_roots_before": &caller_before,
                        "caller_stack_roots_after": &caller_after,
                        "receiver_unchanged": receiver_unchanged,
                        "receiver_debug_unchanged": receiver_debug_unchanged,
                        "caller_stack_roots_unchanged": caller_unchanged,
                    }))
                    .expect("N3 audit JSON")
                );
                assert!(
                    receiver_unchanged,
                    "genuine missing-replay receiver changed on rejection"
                );
                assert!(
                    receiver_debug_unchanged,
                    "genuine missing-replay receiver debug state changed on rejection"
                );
                assert!(
                    caller_unchanged,
                    "caller changed during genuine missing-replay rejection"
                );
                std::panic::panic_any(B01IntegratedMissingReplayN3Sentinel);
            }
            let transaction_authority = candidate
                .authenticate_soil_thermal_unpublished_continuation_install_authority_v3(
                    &authoritative_complete_envelope,
                    continuation,
                    continuation.original_prepared().beginning_owner(),
                )
                .map_err(DirectV11RealConsumerError::Runtime)?;
            candidate
                .install_soil_thermal_accepted_v2_from_unpublished_continuation_v3(
                    &authoritative_complete_envelope,
                    continuation,
                    continuation.original_prepared().beginning_owner(),
                    transaction_authority,
                    accepted,
                    seals,
                )
                .map_err(DirectV11RealConsumerError::Runtime)?;
            if let Some((_, accepted)) = frozen_litter_v4.as_mut() {
                #[cfg(test)]
                record_integrated_promotion_boundary_v1(
                    "promotion-attempt",
                    accepted
                        .physical
                        .complete_owner_projection
                        .is_candidate_only_unpublished_soil(),
                );
                #[cfg(test)]
                if let Some(control) = take_integrated_original_custody_control_v1() {
                    let mut disposable = candidate.clone();
                    let before = disposable.canonical_v11_parent_owner_state_bytes()?;
                    let before_debug = format!("{disposable:?}");
                    let mut wrong_original_owner = match control {
                        B01IntegratedOriginalCustodyControlV1::WholeOriginalOwnerN2 => disposable
                            .inner
                            .soil_thermal
                            .v2()
                            .expect("N2 genuine native V2 receiver")
                            .owner()
                            .clone(),
                        _ => continuation.original_prepared().beginning_owner().clone(),
                    };
                    let control_name = match control {
                        B01IntegratedOriginalCustodyControlV1::WholeOriginalOwnerN2 => {
                            "whole-original-owner"
                        }
                        B01IntegratedOriginalCustodyControlV1::SupportStart => {
                            wrong_original_owner.support_start_ns =
                                wrong_original_owner.support_start_ns.checked_add(1).expect(
                                    "native fixture support start admits one-ns custody mutation",
                                );
                            "support-start"
                        }
                        B01IntegratedOriginalCustodyControlV1::ExpectedPredecessor => {
                            wrong_original_owner.expected_predecessor_transaction_id =
                                Some(wrong_original_owner.transaction_id);
                            "expected-predecessor"
                        }
                        B01IntegratedOriginalCustodyControlV1::ReceiptChain => {
                            wrong_original_owner.receipt_chain_sha256 =
                                openwepp_land_surface_energy::Sha256Digest::try_new(
                                    "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
                                )
                                .expect("fixed receipt-chain mismatch digest is valid");
                            "receipt-chain"
                        }
                    };
                    let error = disposable
                        .accept_promoted_candidate_only_frozen_litter_v4(
                            &self.beginning,
                            &wrong_original_owner,
                            accepted,
                        )
                        .expect_err(
                            "wrong original custody field must fail aggregate/child-local custody",
                        );
                    let expected_detail = "frozen-litter V4 deferred projection promotion: \
frozen-litter V3 identity failure: candidate-only aggregate/child-local promotion custody";
                    let expected_display =
                        format!("V9 real-consumer serialization failure: {expected_detail}");
                    assert_eq!(error.category(), "serialization");
                    let DirectV10RealConsumerError::Runtime(
                        DirectV9RealConsumerError::Serialization(detail),
                    ) = &error
                    else {
                        panic!(
                            "original-custody control must retain the source-defined serialization wrapper: {error}"
                        );
                    };
                    assert_eq!(detail, expected_detail);
                    assert_eq!(error.to_string(), expected_display);
                    let after = disposable.canonical_v11_parent_owner_state_bytes()?;
                    let after_debug = format!("{disposable:?}");
                    let unchanged = before == after;
                    let debug_unchanged = before_debug == after_debug;
                    println!(
                        "B01_INTEGRATED_ORIGINAL_CUSTODY {}",
                        serde_json::to_string(&serde_json::json!({
                            "control": control_name,
                            "guard": "candidate-only aggregate/child-local promotion custody",
                            "outer_error_category": error.category(),
                            "outer_error_display": error.to_string(),
                            "outer_serialization_detail": detail,
                            "before_owner_state_bytes": &before,
                            "after_owner_state_bytes": &after,
                            "unchanged": unchanged,
                            "before_receiver_debug": before_debug,
                            "after_receiver_debug": after_debug,
                            "debug_unchanged": debug_unchanged,
                        }))
                        .expect("original-custody audit JSON")
                    );
                    assert!(unchanged, "disposable promotion host changed on rejection");
                    assert!(
                        debug_unchanged,
                        "disposable full receiver changed on rejection"
                    );
                    match control {
                        B01IntegratedOriginalCustodyControlV1::WholeOriginalOwnerN2 => {
                            std::panic::panic_any(B01IntegratedWrongOriginalN2Sentinel);
                        }
                        _ => std::panic::panic_any(B01IntegratedOriginalCustodyN4Sentinel),
                    }
                }
                #[cfg(test)]
                if take_integrated_wrong_accepted_restart_n5_v1() {
                    let mut disposable = candidate.clone();
                    let before = disposable.canonical_v11_parent_owner_state_bytes()?;
                    let before_debug = format!("{disposable:?}");
                    enable_integrated_wrong_accepted_restart_n5_v1();
                    let error = disposable
                        .accept_promoted_candidate_only_frozen_litter_v4(
                            &self.beginning,
                            continuation.original_prepared().beginning_owner(),
                            accepted,
                        )
                        .expect_err(
                            "wrong accepted restart must fail deferred projection promotion",
                        );
                    let expected_detail = "frozen-litter V4 deferred projection promotion: \
surface-liquid identity failure: soil-thermal restart V2 identity join";
                    let expected_display =
                        format!("V9 real-consumer serialization failure: {expected_detail}");
                    assert_eq!(error.category(), "serialization");
                    let DirectV10RealConsumerError::Runtime(
                        DirectV9RealConsumerError::Serialization(detail),
                    ) = &error
                    else {
                        panic!("wrong accepted restart must retain serialization wrapper: {error}");
                    };
                    assert_eq!(detail, expected_detail);
                    assert_eq!(error.to_string(), expected_display);
                    let after = disposable.canonical_v11_parent_owner_state_bytes()?;
                    let after_debug = format!("{disposable:?}");
                    assert_eq!(
                        before, after,
                        "receiver changed on rejected accepted-restart join"
                    );
                    assert_eq!(
                        before_debug, after_debug,
                        "full receiver changed on rejected accepted-restart join"
                    );
                    println!(
                        "B01_INTEGRATED_WRONG_ACCEPTED_RESTART {}",
                        serde_json::to_string(&serde_json::json!({
                            "error_category": error.category(), "error_display": error.to_string(),
                            "before_owner_state_bytes": before, "after_owner_state_bytes": after,
                            "debug_unchanged": true,
                        }))
                        .expect("wrong accepted restart audit JSON")
                    );
                    std::panic::panic_any(B01IntegratedWrongAcceptedRestartN5Sentinel);
                }
                #[cfg(test)]
                if let Some(control) = take_integrated_publishable_control_v1() {
                    let mut disposable = candidate.clone();
                    disposable
                        .accept_promoted_candidate_only_frozen_litter_v4(
                            &self.beginning,
                            continuation.original_prepared().beginning_owner(),
                            accepted,
                        )
                        .expect("first genuine candidate-only promotion must succeed");
                    let before = disposable.canonical_v11_parent_owner_state_bytes()?;
                    let before_debug = format!("{disposable:?}");
                    let wrong_original = disposable
                        .inner
                        .soil_thermal
                        .v2()
                        .expect("publishable control retains the genuine native V2 receiver")
                        .owner()
                        .clone();
                    let original = match control {
                        B01IntegratedPublishableControlV1::SecondPromotion => {
                            continuation.original_prepared().beginning_owner()
                        }
                        B01IntegratedPublishableControlV1::SecondPromotionWrongOriginal => {
                            &wrong_original
                        }
                    };
                    let error = disposable
                        .accept_promoted_candidate_only_frozen_litter_v4(
                            &self.beginning,
                            original,
                            accepted,
                        )
                        .expect_err("publishable candidate must fail before a second promotion");
                    let after = disposable.canonical_v11_parent_owner_state_bytes()?;
                    let after_debug = format!("{disposable:?}");
                    assert_eq!(
                        before, after,
                        "publishable receiver changed on rejected second promotion"
                    );
                    assert_eq!(
                        before_debug, after_debug,
                        "publishable full receiver changed on rejected second promotion"
                    );
                    let expected = "V4 deferred promotion requires candidate-only soil custody";
                    assert_eq!(error.category(), "owner_closure");
                    let DirectV10RealConsumerError::Runtime(
                        DirectV9RealConsumerError::OwnerClosure(detail),
                    ) = &error
                    else {
                        panic!("publishable control must retain owner-closure wrapper: {error}");
                    };
                    assert_eq!(*detail, expected);
                    assert_eq!(
                        error.to_string(),
                        format!("V9 real-consumer owner closure failure: {expected}")
                    );
                    println!("B01_INTEGRATED_PUBLISHABLE_CONTROL {}", serde_json::to_string(&serde_json::json!({
                        "control": format!("{control:?}"), "error_category":error.category(), "error_display":error.to_string(),
                        "guard": expected, "before_owner_state_bytes":before, "after_owner_state_bytes":after,
                        "debug_unchanged":true,
                    })).expect("publishable control audit JSON"));
                    std::panic::panic_any(B01IntegratedPublishableN6Sentinel);
                }
                #[cfg(test)]
                if take_integrated_late_v4_receipt_n11_v1() {
                    let mut disposable = candidate.clone();
                    let before = disposable.canonical_v11_parent_owner_state_bytes()?;
                    let before_debug = format!("{disposable:?}");
                    accepted.exact_surface_receipt.receipt_sha256 =
                        openwepp_land_surface_energy::Sha256Digest::try_new(
                            "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
                        )
                        .expect("valid late exact receipt mismatch digest");
                    let error = disposable
                        .accept_promoted_candidate_only_frozen_litter_v4(
                            &self.beginning,
                            continuation.original_prepared().beginning_owner(),
                            accepted,
                        )
                        .expect_err("late V4 receipt mismatch must fail constructor");
                    let DirectV10RealConsumerError::Runtime(
                        DirectV9RealConsumerError::Serialization(detail),
                    ) = &error
                    else {
                        panic!("late V4 error wrapper: {error}");
                    };
                    assert_eq!(
                        detail,
                        "frozen-litter V4 deferred projection promotion: LSEB-E-050 / SURFACELIQUID-E-012: identity refusal: projection V3/exact owner/receipt join"
                    );
                    assert_eq!(before, disposable.canonical_v11_parent_owner_state_bytes()?);
                    assert_eq!(before_debug, format!("{disposable:?}"));
                    assert!(
                        !accepted
                            .physical
                            .complete_owner_projection
                            .is_candidate_only_unpublished_soil()
                    );
                    std::panic::panic_any(B01IntegratedLateV4N11Sentinel);
                }
                candidate
                    .accept_promoted_candidate_only_frozen_litter_v4(
                        &self.beginning,
                        continuation.original_prepared().beginning_owner(),
                        accepted,
                    )
                    .map_err(DirectV11RealConsumerError::Runtime)?;
            }
        } else if let Some((_, accepted)) = frozen_litter_v4.as_ref() {
            candidate
                .accept_frozen_litter_v3_complete_envelope(
                    &self.beginning,
                    input.support.start_ns().get(),
                    input.support.end_ns().get(),
                    &accepted.physical,
                    &envelope,
                )
                .map_err(DirectV11RealConsumerError::Runtime)?;
        } else if frozen_litter_v3.is_some() {
            candidate
                .accept_frozen_litter_v3_complete_envelope(
                    &self.beginning,
                    input.support.start_ns().get(),
                    input.support.end_ns().get(),
                    frozen_litter_v3
                        .as_ref()
                        .map(|(_, accepted)| accepted)
                        .ok_or(DirectV11RealConsumerError::Identity(
                            "missing accepted frozen-litter V3 candidate",
                        ))?,
                    &envelope,
                )
                .map_err(DirectV11RealConsumerError::Runtime)?;
        } else {
            candidate
                .inner
                .accept_envelope(envelope.transaction_id(), &envelope)
                .map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error))
                })?;
        }
        if frozen_litter_v4.is_none() && frozen_litter_v3.is_none() {
            candidate.vegetation_state = project_v9_runtime_to_v10(
                candidate.inner.vegetation_state(),
                &candidate.vegetation_configuration,
            )
            .map_err(|error| {
                DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::V10(error))
            })?;
            candidate.lse_state = project_validated_v1_runtime_to_v2(
                &candidate.inner.lse_configuration,
                candidate.inner.lse_state(),
                &candidate.lse_configuration,
                &openwepp_land_surface_energy::Sha256Digest::try_new(
                    candidate
                        .vegetation_configuration
                        .configuration_sha256
                        .clone(),
                )
                .map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::LandSurface(
                        error,
                    ))
                })?,
            )
            .map_err(|error| {
                DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::LseV2(error))
            })?;
        }
        drop(accepted_candidate_profile);
        let owner_publication_profile =
            ImportedStackProfileScopeV1::begin("imported owner publication");

        let segment_ending = candidate.vegetation_state.clone();
        normalize_v11_staged_parent_lineage(&mut candidate, input.beginning.0.last_transaction_id)?;

        let snow = self
            .ending_snow_owner_bytes
            .as_ref()
            .map(|bytes| V11OwnerEnvelope::try_new("snow".to_owned(), bytes.clone()))
            .transpose()?
            .or_else(|| input.staged_resource_owners.get("snow").cloned())
            .ok_or(DirectV11RealConsumerError::Identity(
                "missing staged snow owner",
            ))?;
        let surface_bytes = if let Some(resident) = candidate.frozen_litter_v3.as_ref() {
            resident
                .surface_owner()
                .canonical_bytes(
                    resident.surface_configuration().parent(),
                    Some(resident.surface_configuration()),
                )
                .map_err(DirectV10RealConsumerError::SurfaceLiquidV2)?
        } else {
            let surface = candidate
                .inner
                .hydrology_frame
                .surface_liquid_shadow
                .as_ref()
                .ok_or(DirectV11RealConsumerError::Identity(
                    "missing staged surface-liquid owner",
                ))?;
            surface
                .canonical_bytes(&candidate.inner.surface_configuration)
                .map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(
                        DirectV9RealConsumerError::Serialization(error.to_string()),
                    ))
                })?
        };
        let beginning_hydrology_adapter = RealHydrologyShadowAdapter::try_from_day_start(
            &self.beginning.inner.hydrology_frame,
            self.day_index,
            TransactionId(input.beginning.0.last_transaction_id),
            f64::from_bits(input.duration_s_bits),
            candidate.inner.surface_configuration.owner_id.clone(),
            &candidate.inner.layer_maps,
        )
        .map_err(|error| {
            DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error.into()))
        })?;
        let hydrology_adapter = RealHydrologyShadowAdapter::try_from_day_start(
            envelope.hydrology().ending_frame(),
            self.day_index,
            TransactionId(input.beginning.0.last_transaction_id),
            f64::from_bits(input.duration_s_bits),
            candidate.inner.surface_configuration.owner_id.clone(),
            &candidate.inner.layer_maps,
        )
        .map_err(|error| {
            DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(error.into()))
        })?;
        let ending_resource_owners: BTreeMap<String, V11OwnerEnvelope> = [
            ("snow".to_owned(), snow),
            (
                "land_surface_energy".to_owned(),
                if openwepp_land_surface_energy::snow_accuracy_policy::Policy::current().identity()
                    == Some(14)
                    && (candidate.frozen_litter_v3.is_some()
                        || candidate.frozen_litter_v4.is_some())
                {
                    V11OwnerEnvelope::try_new(
                        "land_surface_energy".to_owned(),
                        candidate.canonical_v11_lse_owner_bytes()?,
                    )?
                } else if let Some(exact) = candidate.frozen_litter_v4.as_ref() {
                    let physical = candidate.frozen_litter_v3.as_ref().ok_or(
                        DirectV11RealConsumerError::Identity(
                            "native V4 ending requires physical resident",
                        ),
                    )?;
                    V11OwnerEnvelope::try_new(
                        "land_surface_energy".to_owned(),
                        exact
                            .v11_complete_lse_owner_bytes(physical)
                            .map_err(DirectV11RealConsumerError::Runtime)?,
                    )?
                } else if let Some(resident) = candidate.frozen_litter_v3.as_ref() {
                    v11_owner_envelope("land_surface_energy", resident.lse_state())?
                } else {
                    v11_owner_envelope("land_surface_energy", &candidate.inner.lse_state)?
                },
            ),
            (
                "surface_liquid".to_owned(),
                V11OwnerEnvelope::try_new("surface_liquid".to_owned(), surface_bytes)?,
            ),
            (
                "hydrology".to_owned(),
                V11OwnerEnvelope::try_new(
                    "hydrology".to_owned(),
                    hydrology_adapter.snapshot_bytes().to_vec(),
                )?,
            ),
            (
                "bgc".to_owned(),
                v11_owner_envelope("bgc", &candidate.inner.biogeochemistry)?,
            ),
            (
                "soil_thermal".to_owned(),
                v11_soil_thermal_owner_envelope(&candidate.inner.soil_thermal)?,
            ),
        ]
        .into_iter()
        .collect();
        let shared_resource_transitions = v11_shared_resource_transitions(
            &envelope,
            input,
            &resource_debits,
            &ending_resource_owners,
            &beginning_hydrology_adapter,
            &hydrology_adapter,
            &self.beginning.inner.biogeochemistry,
            &candidate.inner.biogeochemistry,
            false,
        )?;
        let mut accepted_ending_owners = ending_resource_owners.clone();
        accepted_ending_owners.insert(
            "vegetation".to_owned(),
            accepted_v11_vegetation_owner(input, &segment_ending)?,
        );
        let ending_owner_states = accepted_ending_owners
            .values()
            .map(V11OwnerEnvelope::to_owner_state)
            .collect::<Result<Vec<_>, _>>()?;
        let ending_complete_owner_set_sha256 = complete_owner_set_digest(&ending_owner_states)
            .map_err(|_| {
                DirectV11RealConsumerError::Identity(
                    "accepted publication ending complete-owner set",
                )
            })?;
        let prepared_publication_support = candidate
            .prepare_unvalidated_accepted_publication_support(
                self.day_index,
                self.interval_index,
                input,
                ending_complete_owner_set_sha256,
                support_receipt.clone(),
                self.interval.lse_forcing.clone(),
                self.interval.vegetation_forcing.clone(),
                self.interval.wb14_parameters.clone(),
                resource_debits.clone(),
                envelope.vegetation().material_proposals().to_vec(),
                envelope.hydrology(),
                None,
            )?;
        let deferred_publication_support = if self.wb14_coupled_child_binding.is_some() {
            Some(prepared_publication_support)
        } else {
            let capability = prepared_publication_support
                .validate_and_mint(candidate.accepted_publication_history.live_revision_v1())?;
            candidate.push_validated_accepted_publication_support(capability)?;
            None
        };

        if frozen_litter_v3.is_some()
            && candidate
                .frozen_litter_v3
                .as_ref()
                .is_none_or(|resident| resident.accepted_publication_count() == 0)
        {
            return Err(DirectV11RealConsumerError::Identity(
                "missing accepted frozen-litter V3 publication",
            ));
        }
        if frozen_litter_v4.is_some()
            && candidate.frozen_litter_v4.as_ref().is_none_or(|resident| {
                resident
                    .accepted_publication_supports_canonical_bytes()
                    .is_empty()
            })
        {
            return Err(DirectV11RealConsumerError::Identity(
                "missing accepted frozen-litter V4 publication",
            ));
        }

        let output = V11ImportedV10SegmentOutput {
            ending: segment_ending,
            lse_support_receipt: V11LseSupportReceiptEnvelope::from_canonical_json(
                serde_json::to_vec(&support_receipt).map_err(|error| {
                    DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::Runtime(
                        DirectV9RealConsumerError::Serialization(error.to_string()),
                    ))
                })?,
            )
            .map_err(|_| DirectV11RealConsumerError::Identity("V11 LSE support receipt"))?,
            resource_debits,
            admitted_resource_fluxes: Vec::<V11AdmittedResourceFlux>::new(),
            shared_resource_transitions,
            ending_resource_owners,
            material_transfers: envelope.vegetation().material_proposals().to_vec(),
        };
        #[cfg(test)]
        {
            self.last_hydrology_candidate = Some(envelope.hydrology().clone());
        }
        drop(owner_publication_profile);
        let install_profile = ImportedStackProfileScopeV1::begin("imported install");
        if crate::snow_accuracy_observer::physical_enabled() {
            let physical_phase = frozen_litter_v4
                .as_ref()
                .map(|(_, v)| &v.physical)
                .or_else(|| frozen_litter_v3.as_ref().map(|(_, v)| v));
            let soil_json =
                |view: crate::v9_real_consumer_shadow::DirectSoilThermalReadView<'_>| match view {
                    crate::v9_real_consumer_shadow::DirectSoilThermalReadView::V1(v) => {
                        serde_json::json!({"v1":v})
                    }
                    crate::v9_real_consumer_shadow::DirectSoilThermalReadView::V2(v) => {
                        serde_json::json!({"v2":v})
                    }
                };
            crate::snow_accuracy_observer::record(serde_json::json!({
                "kind":"retained_lse_final_operands","role":"snow_free","commit_posture":"provisional requires physical-reuse final slab join and accepted_day membership",
                "parent_transaction_id":input.parent_transaction_id,"support":input.support,
                "accepted_slab_sha256":input.accepted_slab_receipt.slab_id().digest(),
                "beginning_inventory_owners":self.beginning.accuracy_inventory_owners()?,
                "ending_inventory_owners":candidate.accuracy_inventory_owners()?,
                "inventory_posture":"physical LSE candidate; post-support native drainage and deferred soil credits require their separate actual joins",
                "day_index":self.day_index,"interval_index":self.interval_index,
                "compositional":false,"children":[envelope.accuracy_final_energy_operands()],
                "litter_phase_receipts":physical_phase.map(|v|&v.litter_phase_receipts),
                "litter_phase_capacity_spills":physical_phase.map(|v|&v.litter_phase_capacity_spills),
                "ending_exact_surface_owner":frozen_litter_v4.as_ref().map(|(_,v)|&v.ending_exact_surface_owner),
                "exact_surface_receipt":frozen_litter_v4.as_ref().map(|(_,v)|&v.exact_surface_receipt),
                "beginning_soil_resident":soil_json(self.beginning.inner.soil_thermal.read_view()),"ending_soil_resident":soil_json(candidate.inner.soil_thermal.read_view())
            }));
        }
        let physical_reuse_pending = match self.wb14_coupled_child_binding {
            Some(provisional_binding) => Some(SnowFreePhysicalReusePendingV1::stage(
                input,
                provisional_binding,
                deferred_publication_support.ok_or(DirectV11RealConsumerError::Identity(
                    "deferred accepted publication prepared support",
                ))?,
                candidate.clone(),
                output.clone(),
                &self.beginning,
                self.interval,
                self.day_index,
                self.interval_index,
                self.finalize_wb14_parent_interval,
                self.native_inactive_wb14_prefix,
                self.ending_snow_owner_bytes.clone(),
                self.deferred_native_v2_soil_custody.clone(),
                self.ending.clone(),
                self.last_support_receipt.clone(),
            )),
            None => None,
        };
        self.last_support_receipt = Some(support_receipt);
        self.ending = Some(candidate);
        self.snow_free_physical_reuse_pending = physical_reuse_pending;
        drop(install_profile);
        Ok(output)
    }

    fn authenticate_outer_validated_candidate(
        &mut self,
        candidate: &openwepp_vegetation::v11::V11AcceptedSegmentCandidate,
    ) -> Result<(), Self::Error> {
        self.authenticate_snow_free_outer_candidate(candidate)
    }
}

#[cfg(test)]
mod native_v4_deferred_soil_join_source_guards {
    #[test]
    fn v4_uses_the_authenticated_deferred_join_and_v3_remains_refused() {
        let source = include_str!("v9_real_consumer_shadow.rs");
        let body = source
            .split("let deferred_soil = self.deferred_native_v2_soil_custody.as_ref();")
            .nth(1)
            .expect("deferred native-V2 soil branch")
            .split("let segment_ending = candidate.vegetation_state.clone();")
            .next()
            .expect("snow-free acceptance body");
        assert!(!body.contains("native frozen-litter V4 deferred soil custody is not yet joined"));
        assert!(body.contains("native frozen-litter V3 deferred soil custody is not yet joined"));

        let replay = body
            .find("validate_soil_thermal_accepted_v2_from_unpublished_continuation")
            .expect("continuation replay validation");
        let accept = body[replay..]
            .find("accept_envelope_preserving_native_v2_soil")
            .map(|offset| replay + offset)
            .expect("non-soil envelope acceptance");
        let vegetation = body[accept..]
            .find("project_v9_runtime_to_v10")
            .map(|offset| accept + offset)
            .expect("V10 vegetation projection");
        let lse = body[vegetation..]
            .find("project_validated_v1_runtime_to_v2")
            .map(|offset| vegetation + offset)
            .expect("V10 LSE projection");
        let authenticate = body[lse..]
            .find("authenticate_soil_thermal_unpublished_continuation_install_authority_v3")
            .map(|offset| lse + offset)
            .expect("three-domain install authentication");
        let install = body[authenticate..]
            .find("install_soil_thermal_accepted_v2_from_unpublished_continuation_v3")
            .map(|offset| authenticate + offset)
            .expect("three-domain continuation install");
        assert!(replay < accept && accept < vegetation && vegetation < lse);
        assert!(lse < authenticate && authenticate < install);
        assert!(
            !body.contains(
                "authenticate_soil_thermal_unpublished_continuation_install_authority_v2("
            )
        );
        assert!(!body.contains("install_soil_thermal_accepted_v2_from_unpublished_continuation("));
    }
}

fn install_imported_v10_snow_free_authority(candidate: &mut DirectV10RealConsumerShadow) {
    candidate.inner.authority = CoveredColumnAuthority::V10NonpositiveAssimilation;
}

include!("v9_real_consumer_shadow_v10_accessors.rs");

fn publication_owner_digest_after_event_handoffs(
    previous: &Stage3AcceptedPublicationSupportV1,
    events: &[AcceptedEventReceiptV1],
) -> Result<Digest32, DirectV11RealConsumerError> {
    publication_owner_chain_after_event_handoffs(previous, events).map(|chain| {
        chain
            .last()
            .copied()
            .unwrap_or(previous.ending_complete_owner_set_sha256)
    })
}

fn publication_owner_chain_after_event_handoffs(
    previous: &Stage3AcceptedPublicationSupportV1,
    events: &[AcceptedEventReceiptV1],
) -> Result<Vec<Digest32>, DirectV11RealConsumerError> {
    let mut owner_chain = vec![previous.ending_complete_owner_set_sha256];
    for (event_index, event) in events
        .iter()
        .enumerate()
        .filter(|(_, event)| event.tick() == previous.support.end_ns())
    {
        let prior_same_parent = events[..event_index]
            .iter()
            .rev()
            .find(|prior| prior.parent_transaction_id() == event.parent_transaction_id());
        event.validate().map_err(|_| {
            DirectV11RealConsumerError::Identity("accepted publication event handoff seal")
        })?;
        if event.beginning_owner_set_digest()
            != owner_chain
                .last()
                .copied()
                .ok_or(DirectV11RealConsumerError::Identity(
                    "accepted publication event handoff chain",
                ))?
            || prior_same_parent.map_or(event.ordinal() != 0, |prior| {
                prior.ordinal().checked_add(1) != Some(event.ordinal())
            })
        {
            return Err(DirectV11RealConsumerError::Identity(
                "accepted publication event handoff chronology",
            ));
        }
        owner_chain.push(event.ending_owner_set_digest());
    }
    Ok(owner_chain)
}

impl DirectV10RealConsumerShadow {
    pub(crate) const fn surface_configuration(&self) -> &DirectSurfaceLiquidConfiguration {
        self.inner.surface_configuration()
    }

    #[cfg(feature = "restart-authority-evidence")]
    pub(crate) fn pending_parent_physical_bgc_poison_for_evidence(
        &self,
    ) -> Result<Self, DirectV11RealConsumerError> {
        let mut poisoned = self.clone();
        let layer = poisoned
            .inner
            .biogeochemistry
            .layers
            .values_mut()
            .next()
            .ok_or(DirectV11RealConsumerError::Identity(
                "pending parent poison requires actual BGC layer",
            ))?;
        layer.ammonium_n += 1.0;
        Ok(poisoned)
    }

    pub(crate) fn validate_pending_v11_parent_finalization_source_v1(
        &self,
        configuration: &VegetationConfigurationV11,
        finalized: &V11CoupledOwnedState,
        physical_posture: &crate::snow_stage3_v11_attachment::PendingParentPhysicalPostureV1,
    ) -> Result<TransactionId, DirectV11RealConsumerError> {
        let predecessor = self.vegetation_state.0.last_transaction_id;
        let source = TransactionId(finalized.last_parent_transaction_id);
        let expected_record = physical_posture.expected_record_source(predecessor, source.0);
        if expected_record.is_none()
            || self.lse_state.0.last_accepted_transaction_id.map(|id| id.0) != expected_record
            || Some(self.inner.biogeochemistry.last_transaction_id) != expected_record
        {
            if crate::snow_accuracy_observer::physical_global_enabled() {
                crate::snow_accuracy_observer::record(serde_json::json!({
                    "kind":"pending_parent_finalization_source_rejection",
                    "source":source,"vegetation_predecessor":predecessor,
                    "active_lse_transaction":self.lse_state.0.last_accepted_transaction_id,
                    "bgc_transaction":self.inner.biogeochemistry.last_transaction_id,
                    "finalized":finalized,
                }));
            }
            return Err(DirectV11RealConsumerError::Identity(
                "pending V11 parent-finalization record source",
            ));
        }

        let mut projected = self.clone();
        projected.accept_v11_parent_finalization(configuration, finalized)?;
        normalize_v8_parent_lineage(&mut projected.vegetation_state.0, predecessor);
        normalize_v8_parent_lineage(&mut projected.inner.vegetation_state.0, predecessor);
        projected.inner.biogeochemistry.last_transaction_id =
            self.inner.biogeochemistry.last_transaction_id;
        if projected.vegetation_state != self.vegetation_state
            || projected.inner.vegetation_state != self.inner.vegetation_state
            || projected.inner.biogeochemistry != self.inner.biogeochemistry
        {
            return Err(DirectV11RealConsumerError::Identity(
                "pending V11 parent-finalization lineage-only projection",
            ));
        }
        Ok(source)
    }

    pub(crate) fn accept_v11_parent_finalization(
        &mut self,
        configuration: &VegetationConfigurationV11,
        finalized: &V11CoupledOwnedState,
    ) -> Result<V11OwnerEnvelope, DirectV11RealConsumerError> {
        let (v10_configuration, v10_state) = project_v11_parent_finalization_to_v10(
            configuration,
            &self.vegetation_state,
            finalized,
        )?;
        let (v9_configuration, v9_state) =
            project_v10_runtime_to_v9(&v10_configuration, &v10_state).map_err(|error| {
                DirectV11RealConsumerError::Runtime(DirectV10RealConsumerError::V10(error))
            })?;
        self.accept_projected_v11_parent_finalization(
            configuration,
            finalized,
            v10_configuration,
            v10_state,
            v9_configuration,
            v9_state,
        )
    }

    pub(crate) fn accept_v11_parent_finalization_with_validated_handoff(
        &mut self,
        configuration: &VegetationConfigurationV11,
        finalized: &V11CoupledOwnedState,
        handoff: ValidatedV11ParentFinalizationV1,
    ) -> Result<V11OwnerEnvelope, DirectV11RealConsumerError> {
        let (v10_configuration, v10_state, v9_configuration, v9_state) =
            handoff.project_to_v10(configuration, &self.vegetation_state, finalized)?;
        self.accept_projected_v11_parent_finalization(
            configuration,
            finalized,
            v10_configuration,
            v10_state,
            v9_configuration,
            v9_state,
        )
    }

    fn accept_projected_v11_parent_finalization(
        &mut self,
        _configuration: &VegetationConfigurationV11,
        finalized: &V11CoupledOwnedState,
        v10_configuration: VegetationConfiguration,
        v10_state: V10CoupledOwnedState,
        v9_configuration: VegetationConfiguration,
        v9_state: V9CoupledOwnedState,
    ) -> Result<V11OwnerEnvelope, DirectV11RealConsumerError> {
        if v10_configuration != self.vegetation_configuration {
            return Err(DirectV11RealConsumerError::Identity(
                "V11 parent finalization V10 configuration",
            ));
        }
        if v9_configuration != self.inner.vegetation_configuration {
            return Err(DirectV11RealConsumerError::Identity(
                "V11 parent finalization V9 configuration",
            ));
        }
        let prior_transaction = self.vegetation_state.0.last_transaction_id;
        let expected_transaction =
            prior_transaction
                .checked_add(1)
                .ok_or(DirectV11RealConsumerError::Identity(
                    "V11 parent finalization transaction overflow",
                ))?;
        if finalized.last_parent_transaction_id != expected_transaction {
            return Err(DirectV11RealConsumerError::Identity(
                if finalized.last_parent_transaction_id <= prior_transaction {
                    "V11 parent finalization nonadvancing vegetation predecessor"
                } else {
                    "V11 parent finalization skipped vegetation predecessor"
                },
            ));
        }
        if !matches!(
            self.inner.biogeochemistry.last_transaction_id,
            value if value == prior_transaction || value == finalized.last_parent_transaction_id
        ) {
            return Err(DirectV11RealConsumerError::Identity(
                "V11 parent finalization BGC predecessor",
            ));
        }
        let mut finalized_bgc = self.inner.biogeochemistry.clone();
        finalized_bgc.last_transaction_id = finalized.last_parent_transaction_id;
        let bgc_owner = v11_owner_envelope("bgc", &finalized_bgc)?;
        self.vegetation_state = v10_state;
        self.inner.vegetation_state = v9_state;
        self.inner.biogeochemistry = finalized_bgc;
        Ok(bgc_owner)
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn prepare_accepted_publication_support(
        &self,
        day_index: usize,
        interval_index: usize,
        input: &V11ImportedV10SegmentInput,
        ending_complete_owner_set_sha256: Digest32,
        lse_support_receipt: LseSupportAdmissibilityReceiptV1,
        lse_forcing: LandSurfaceForcing,
        vegetation_forcing: SnowFreeForcing,
        wb14_parameters: Vec<DirectOfeWb14Parameters>,
        resource_debits: Vec<V11ResourceDebit>,
        material_transfers: Vec<openwepp_vegetation::carbon_nitrogen::MaterialTransfer>,
        hydrology: &crate::land_surface_energy_shadow::UnifiedRealHydrologyCandidate,
        physical_outcome_ledgers: Option<
            &BTreeMap<u32, v11_covered::physical_outcome_ledger::Stage3LanePhysicalOutcomeLedgerV1>,
        >,
    ) -> Result<ValidatedStage3AcceptedPublicationSupportV1, DirectV11RealConsumerError> {
        Stage3AcceptedPublicationSupportV1::try_new(
            day_index,
            interval_index,
            input,
            ending_complete_owner_set_sha256,
            lse_support_receipt,
            lse_forcing,
            vegetation_forcing,
            wb14_parameters,
            resource_debits,
            material_transfers,
            hydrology,
            physical_outcome_ledgers,
            self.accepted_publication_history.live_revision_v1(),
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn prepare_unvalidated_accepted_publication_support(
        &self,
        day_index: usize,
        interval_index: usize,
        input: &V11ImportedV10SegmentInput,
        ending_complete_owner_set_sha256: Digest32,
        lse_support_receipt: LseSupportAdmissibilityReceiptV1,
        lse_forcing: LandSurfaceForcing,
        vegetation_forcing: SnowFreeForcing,
        wb14_parameters: Vec<DirectOfeWb14Parameters>,
        resource_debits: Vec<V11ResourceDebit>,
        material_transfers: Vec<openwepp_vegetation::carbon_nitrogen::MaterialTransfer>,
        hydrology: &crate::land_surface_energy_shadow::UnifiedRealHydrologyCandidate,
        physical_outcome_ledgers: Option<
            &BTreeMap<u32, v11_covered::physical_outcome_ledger::Stage3LanePhysicalOutcomeLedgerV1>,
        >,
    ) -> Result<PreparedStage3AcceptedPublicationSupportV1, DirectV11RealConsumerError> {
        #[cfg(test)]
        v11_covered::record_canonical_covered_publication_retain_entry_v1();
        #[cfg(test)]
        let ending_complete_owner_set_sha256 = if matches!(
            v11_covered::canonical_covered_parity_poison_v1(),
            Some(v11_covered::CanonicalCoveredPhysicalParityPoisonV1::PublicationSupport)
        ) {
            Digest32::zero()
        } else {
            ending_complete_owner_set_sha256
        };
        Stage3AcceptedPublicationSupportV1::prepare(
            day_index,
            interval_index,
            input,
            ending_complete_owner_set_sha256,
            lse_support_receipt,
            lse_forcing,
            vegetation_forcing,
            wb14_parameters,
            resource_debits,
            material_transfers,
            hydrology,
            physical_outcome_ledgers,
        )
    }

    pub(crate) fn push_validated_accepted_publication_support(
        &mut self,
        capability: ValidatedStage3AcceptedPublicationSupportV1,
    ) -> Result<(), DirectV11RealConsumerError> {
        self.accepted_publication_history
            .push_validated_support(capability)?;
        #[cfg(test)]
        self.observe_integrated_accepted_parent_replay_after_append_v1();
        Ok(())
    }

    /// Records the installed immutable support only after its consuming trusted
    /// append has returned. Observation never affects the accepted transition.
    #[cfg(test)]
    fn observe_integrated_accepted_parent_replay_after_append_v1(&self) {
        if !integrated_promotion_boundary_audit_enabled_v1() {
            return;
        }
        if accepted_publication_support_capability::
            trusted_accepted_publication_append_audit_scope_is_active_v1()
        {
            INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| {
                audit
                    .borrow_mut()
                    .accepted_parent_replay_observation_inside_trusted_append_count += 1;
            });
            return;
        }
        let Some(accepted) = self.accepted_publication_history.supports().last() else {
            return;
        };
        if accepted.wb14_parent_replay_bytes.is_none() {
            return;
        }
        let accepted_support = accepted.accuracy_observation_wire();
        if accepted_support.is_null() {
            INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| {
                audit
                    .borrow_mut()
                    .accepted_parent_replay_observation_error_count += 1;
            });
            return;
        }
        match serde_json::to_string(&serde_json::json!({
            "record_version": 1,
            "boundary": "accepted publication-history support with retained WB14 parent replay",
            "accepted_support": accepted_support,
        })) {
            Ok(record) => {
                use std::io::Write;

                let stdout = std::io::stdout();
                let mut stdout = stdout.lock();
                let write_result = if B01_INTEGRATED_ACCEPTED_PARENT_REPLAY_WRITE_FAILURE
                    .with(|slot| slot.replace(false))
                {
                    Err(std::io::Error::other(
                        "forced integrated accepted-parent replay observation write failure",
                    ))
                } else {
                    writeln!(stdout, "B01_INTEGRATED_ACCEPTED_PARENT_REPLAY {record}")
                        .and_then(|()| stdout.flush())
                };
                match write_result {
                    Ok(()) => INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| {
                        audit.borrow_mut().accepted_parent_replay_observation_count += 1;
                    }),
                    Err(_) => INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| {
                        audit
                            .borrow_mut()
                            .accepted_parent_replay_observation_error_count += 1;
                    }),
                }
            }
            Err(_) => INTEGRATED_PROMOTION_BOUNDARY_AUDIT.with(|audit| {
                audit
                    .borrow_mut()
                    .accepted_parent_replay_observation_error_count += 1;
            }),
        }
    }

    pub(crate) fn accepted_publication_supports_for_day(
        &self,
        day_index: usize,
    ) -> Result<Vec<&Stage3AcceptedPublicationSupportV1>, DirectV11RealConsumerError> {
        let supports = self
            .accepted_publication_history
            .supports()
            .iter()
            .filter(|support| support.day_index == day_index)
            .map(std::sync::Arc::as_ref)
            .collect::<Vec<_>>();
        if supports.is_empty()
            || supports.windows(2).any(|pair| {
                pair[0].support.end_ns() != pair[1].support.start_ns()
                    || publication_owner_digest_after_event_handoffs(
                        pair[0],
                        self.accepted_publication_history.event_handoffs(),
                    )
                    .is_err()
                    || publication_owner_digest_after_event_handoffs(
                        pair[0],
                        self.accepted_publication_history.event_handoffs(),
                    )
                    .is_ok_and(|ending| ending != pair[1].beginning_complete_owner_set_sha256)
            })
        {
            return Err(DirectV11RealConsumerError::Identity(
                "accepted publication day support set",
            ));
        }
        Ok(supports)
    }

    pub(crate) fn accepted_publication_ordered_owner_chain(
        &self,
        support: &Stage3AcceptedPublicationSupportV1,
    ) -> Result<Vec<Digest32>, DirectV11RealConsumerError> {
        publication_owner_chain_after_event_handoffs(
            support,
            self.accepted_publication_history.event_handoffs(),
        )
    }

    #[must_use]
    #[cfg(test)]
    pub(crate) fn accepted_publication_supports(&self) -> Vec<Stage3AcceptedPublicationSupportV1> {
        self.accepted_publication_history
            .supports()
            .iter()
            .map(|support| (**support).clone())
            .collect()
    }

    #[must_use]
    pub(crate) fn accepted_publication_event_handoffs(&self) -> &[AcceptedEventReceiptV1] {
        self.accepted_publication_history.event_handoffs()
    }

    #[cfg(test)]
    pub(crate) fn restore_accepted_publication_supports(
        &mut self,
        supports: Vec<Stage3AcceptedPublicationSupportV1>,
    ) -> Result<(), DirectV11RealConsumerError> {
        self.restore_accepted_publication_authority(supports, Vec::new())?;
        Ok(())
    }

    #[cfg(test)]
    fn restore_accepted_publication_authority(
        &mut self,
        supports: Vec<Stage3AcceptedPublicationSupportV1>,
        event_handoffs: Vec<AcceptedEventReceiptV1>,
    ) -> Result<(), DirectV11RealConsumerError> {
        let mut restored = AcceptedPublicationHistoryV1::default();
        restored.replace(supports, &event_handoffs)?;
        self.accepted_publication_history = restored;
        Ok(())
    }

    pub(crate) fn next_transaction_id(&self) -> Result<TransactionId, DirectV11RealConsumerError> {
        self.vegetation_state
            .0
            .last_transaction_id
            .checked_add(1)
            .map(TransactionId)
            .ok_or(DirectV11RealConsumerError::Identity(
                "V11 live transaction overflow",
            ))
    }

    #[allow(clippy::too_many_arguments, clippy::too_many_lines)]
    pub fn try_new(
        vegetation_configuration: VegetationConfiguration,
        vegetation_state: V10CoupledOwnedState,
        vegetation_owner_id: ResourceOwnerId,
        lse_configuration: LandSurfaceEnergyConfiguration,
        lse_state: LandSurfaceEnergyV2State,
        surface_configuration: DirectSurfaceLiquidConfiguration,
        layer_maps: Vec<RealHydrologyLaneLayerMap>,
        soil_thermal: SoilThermalSnapshot,
        biogeochemistry: BiogeochemistryState,
        hydrology_frame: DirectRunFrame,
        next_day_index: usize,
        gsi_owner_configuration: DirectGsiOwnerConfigurationV1,
        gsi_state: GsiState,
        provider_static_configuration: SnowFreeHalfHourStaticConfiguration,
        provider_cursor: SnowFreeHalfHourProviderCursor,
        root_zone_hydraulic_configuration: DirectRootZoneHydraulicConfiguration,
    ) -> Result<Self, DirectV10RealConsumerError> {
        Self::try_new_with_soil_resident(
            vegetation_configuration,
            vegetation_state,
            vegetation_owner_id,
            lse_configuration,
            lse_state,
            surface_configuration,
            layer_maps,
            DirectSoilThermalResident::try_new_v1(soil_thermal)?,
            biogeochemistry,
            hydrology_frame,
            next_day_index,
            gsi_owner_configuration,
            gsi_state,
            provider_static_configuration,
            provider_cursor,
            root_zone_hydraulic_configuration,
            None,
        )
    }

    #[allow(clippy::too_many_arguments, clippy::too_many_lines)]
    pub fn try_new_v2(
        vegetation_configuration: VegetationConfiguration,
        vegetation_state: V10CoupledOwnedState,
        vegetation_owner_id: ResourceOwnerId,
        lse_configuration: LandSurfaceEnergyConfiguration,
        lse_state: LandSurfaceEnergyV2State,
        surface_configuration: DirectSurfaceLiquidConfiguration,
        layer_maps: Vec<RealHydrologyLaneLayerMap>,
        prepared_soil_thermal: openwepp_land_surface_energy::PreparedSoilThermalSupportV2,
        soil_thermal_seals: openwepp_land_surface_energy::SoilThermalReceiptFreeOwnerSealsV2,
        biogeochemistry: BiogeochemistryState,
        hydrology_frame: DirectRunFrame,
        next_day_index: usize,
        gsi_owner_configuration: DirectGsiOwnerConfigurationV1,
        gsi_state: GsiState,
        provider_static_configuration: SnowFreeHalfHourStaticConfiguration,
        provider_cursor: SnowFreeHalfHourProviderCursor,
        root_zone_hydraulic_configuration: DirectRootZoneHydraulicConfiguration,
    ) -> Result<Self, DirectV10RealConsumerError> {
        Self::try_new_with_soil_resident(
            vegetation_configuration,
            vegetation_state,
            vegetation_owner_id,
            lse_configuration,
            lse_state,
            surface_configuration,
            layer_maps,
            DirectSoilThermalResident::try_new_v2(prepared_soil_thermal, soil_thermal_seals)?,
            biogeochemistry,
            hydrology_frame,
            next_day_index,
            gsi_owner_configuration,
            gsi_state,
            provider_static_configuration,
            provider_cursor,
            root_zone_hydraulic_configuration,
            None,
        )
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[allow(clippy::too_many_arguments)]
    pub fn restart_authority_try_new_with_native_soil(
        vegetation_configuration: VegetationConfiguration,
        vegetation_state: V10CoupledOwnedState,
        vegetation_owner_id: ResourceOwnerId,
        lse_configuration: LandSurfaceEnergyConfiguration,
        lse_state: LandSurfaceEnergyV2State,
        surface_configuration: DirectSurfaceLiquidConfiguration,
        layer_maps: Vec<RealHydrologyLaneLayerMap>,
        soil_thermal: DirectSoilThermalResident,
        biogeochemistry: BiogeochemistryState,
        hydrology_frame: DirectRunFrame,
        next_day_index: usize,
        gsi_owner_configuration: DirectGsiOwnerConfigurationV1,
        gsi_state: GsiState,
        provider_static_configuration: SnowFreeHalfHourStaticConfiguration,
        provider_cursor: SnowFreeHalfHourProviderCursor,
        root_zone_hydraulic_configuration: DirectRootZoneHydraulicConfiguration,
        proof: &NativeSoilRestartAdmissionV1,
        clock: &openwepp_coupled_time::CoupledClockStateV1,
        position: NativeSoilRestartPositionV1,
    ) -> Result<Self, DirectV10RealConsumerError> {
        if openwepp_land_surface_energy::snow_accuracy_policy::Policy::current().identity()
            != Some(14)
        {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Identity("native soil restart policy"),
            ));
        }
        proof.validate_constructor_context(
            &soil_thermal,
            &lse_configuration,
            clock,
            position,
            vegetation_state.0.last_transaction_id,
            next_day_index,
            hydrology_frame.identity.run_id,
        )?;
        Self::try_new_with_soil_resident(
            vegetation_configuration,
            vegetation_state,
            vegetation_owner_id,
            lse_configuration,
            lse_state,
            surface_configuration,
            layer_maps,
            soil_thermal,
            biogeochemistry,
            hydrology_frame,
            next_day_index,
            gsi_owner_configuration,
            gsi_state,
            provider_static_configuration,
            provider_cursor,
            root_zone_hydraulic_configuration,
            Some(proof),
        )
    }

    #[allow(clippy::too_many_arguments, clippy::too_many_lines)]
    fn try_new_with_soil_resident(
        vegetation_configuration: VegetationConfiguration,
        vegetation_state: V10CoupledOwnedState,
        vegetation_owner_id: ResourceOwnerId,
        lse_configuration: LandSurfaceEnergyConfiguration,
        lse_state: LandSurfaceEnergyV2State,
        surface_configuration: DirectSurfaceLiquidConfiguration,
        layer_maps: Vec<RealHydrologyLaneLayerMap>,
        soil_thermal: DirectSoilThermalResident,
        biogeochemistry: BiogeochemistryState,
        hydrology_frame: DirectRunFrame,
        next_day_index: usize,
        gsi_owner_configuration: DirectGsiOwnerConfigurationV1,
        gsi_state: GsiState,
        provider_static_configuration: SnowFreeHalfHourStaticConfiguration,
        provider_cursor: SnowFreeHalfHourProviderCursor,
        root_zone_hydraulic_configuration: DirectRootZoneHydraulicConfiguration,
        native_proof: Option<&NativeSoilRestartAdmissionV1>,
    ) -> Result<Self, DirectV10RealConsumerError> {
        gsi_owner_configuration.validate()?;
        provider_static_configuration.validate()?;
        let expected_root_layers = layer_maps
            .iter()
            .flat_map(|map| {
                map.layer_ids.iter().map(move |layer_id| {
                    (
                        map.ofe_lane.lane_index,
                        map.ofe_lane.lane_id,
                        layer_id.clone(),
                    )
                })
            })
            .collect::<Vec<_>>();
        let actual_root_layers = root_zone_hydraulic_configuration
            .ordered_layers
            .iter()
            .map(|layer| {
                (
                    layer.production_lane_index,
                    layer.production_lane_id,
                    layer.layer_id.clone(),
                )
            })
            .collect::<Vec<_>>();
        let expected_strata = vegetation_configuration
            .strata
            .iter()
            .map(|stratum| stratum.stratum_id.clone())
            .collect::<Vec<_>>();
        let actual_strata = root_zone_hydraulic_configuration
            .ordered_strata
            .iter()
            .map(|stratum| stratum.stratum_id.clone())
            .collect::<Vec<_>>();
        if actual_root_layers != expected_root_layers || actual_strata != expected_strata {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Identity("root-zone topology/configuration join"),
            ));
        }
        let expected_provider_destinations = lse_configuration
            .ofes
            .iter()
            .flat_map(|ofe| {
                ofe.tiles
                    .iter()
                    .map(move |tile| (ofe.ofe_id.as_str(), tile.tile_id.as_str()))
            })
            .collect::<Vec<_>>();
        let actual_provider_destinations = provider_static_configuration
            .destinations
            .iter()
            .map(|destination| (destination.ofe_id.as_str(), destination.tile_id.as_str()))
            .collect::<Vec<_>>();
        if actual_provider_destinations != expected_provider_destinations {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Identity("provider/LSE destination topology"),
            ));
        }
        if provider_static_configuration.gsi_owner_configuration_sha256
            != gsi_owner_configuration.configuration_sha256
            || provider_static_configuration.run_id != hydrology_frame.identity.run_id.to_string()
        {
            return Err(DirectV10RealConsumerError::ForcingProvider(
                SnowFreeHalfHourForcingError::Identity("initial GSI/provider owner join"),
            ));
        }
        provider_cursor
            .validate_for_configuration(&provider_static_configuration, next_day_index)?;
        vegetation_state.validate(&vegetation_configuration)?;
        lse_state.validate(&lse_configuration)?;
        // No daily GSI receipt exists at construction. Closure-eligible
        // execution installs the accepted receipt before projecting forcing.
        let provider_gsi_receipt_sha256 = "0".repeat(64);
        let (v9_configuration, v9_state) =
            project_v10_runtime_to_v9(&vegetation_configuration, &vegetation_state)?;
        let (v8_configuration, _) = project_v9_runtime_to_v8(&v9_configuration, &v9_state)
            .map_err(DirectV9RealConsumerError::V9)?;
        let v10_configuration_sha256 = openwepp_land_surface_energy::Sha256Digest::try_new(
            vegetation_configuration.configuration_sha256.clone(),
        )?;
        if lse_configuration
            .vegetation_configuration
            .configuration_sha256
            != v10_configuration_sha256
        {
            return Err(DirectV10RealConsumerError::LseV2(
                LseV2StateError::VegetationIdentity,
            ));
        }
        let v8_configuration_sha256 = openwepp_land_surface_energy::Sha256Digest::try_new(
            v8_configuration.configuration_sha256.clone(),
        )?;
        let (v1_configuration, v1_state) =
            project_v2_runtime_to_v1(&lse_configuration, &lse_state, &v8_configuration_sha256)?;
        let mut inner = DirectV9RealConsumerShadow::try_new_with_authority(
            v9_configuration,
            v9_state,
            vegetation_owner_id,
            v1_configuration,
            v1_state,
            surface_configuration,
            layer_maps,
            soil_thermal,
            biogeochemistry,
            hydrology_frame,
            next_day_index,
            CoveredColumnAuthority::V10NonpositiveAssimilation,
            provider_gsi_receipt_sha256,
            native_proof,
        )?;
        inner.root_zone_hydraulic_configuration = Some(root_zone_hydraulic_configuration.clone());
        Ok(Self {
            inner,
            vegetation_configuration,
            vegetation_state,
            lse_configuration,
            lse_state,
            gsi_owner_configuration,
            gsi_state,
            provider_static_configuration,
            provider_cursor,
            root_zone_hydraulic_configuration,
            accepted_publication_history: AcceptedPublicationHistoryV1::default(),
            frozen_litter_v3: None,
            frozen_litter_v4: None,
        })
    }

    /// Execute and commit one complete provider/owner day atomically. Every
    /// fallible projection, physical solve, successor reconstruction, and
    /// GSI/cursor guard completes on `candidate` before the single assignment.
    pub fn execute_prepared_gsi_day(
        &mut self,
        production_frame: &DirectRunFrame,
        projected_day_frames: &[DirectDayFrame],
        projected_day_inputs: &[DirectPublicationDayInput],
        prepared: PreparedSnowFreeGsiDayV1,
        mut template: DirectV10ShadowDayInput,
    ) -> Result<DirectV10ShadowDayReceipt, DirectV10RealConsumerError> {
        let gsi_receipt = prepared.gsi_receipt();
        if gsi_receipt.run_id != self.provider_static_configuration.run_id
            || gsi_receipt.configuration_sha256 != self.gsi_owner_configuration.configuration_sha256
            || prepared.forcing_receipts().len()
                != self.provider_static_configuration.destinations.len()
            || prepared
                .forcing_receipts()
                .iter()
                .zip(&self.provider_static_configuration.destinations)
                .any(|(receipt, destination)| {
                    receipt.intervals.len() != INTERVALS_PER_DAY
                        || receipt.intervals.iter().any(|interval| {
                            interval.ofe_id != destination.ofe_id
                                || interval.tile_id != destination.tile_id
                                || interval.wb14_configuration_sha256
                                    != destination.wb14_configuration_sha256
                                || interval.co2_pa.to_bits()
                                    != self.provider_static_configuration.co2_pa.to_bits()
                                || interval.reference_height_m.to_bits()
                                    != self
                                        .provider_static_configuration
                                        .reference_height_m
                                        .to_bits()
                        })
                })
        {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Identity("prepared provider static owner"),
            ));
        }
        let mut candidate = self.clone();
        let accepted_gsi_receipt_sha256 = gsi_receipt.receipt_sha256.clone();
        let accepted_gsi_day_index = gsi_receipt.day_index;
        for interval in &mut template.intervals {
            interval.vegetation_forcing.gsi = gsi_receipt.result.growing_season_index;
        }
        candidate
            .inner
            .provider_gsi_receipt_sha256
            .clone_from(&gsi_receipt.receipt_sha256);
        let projected =
            candidate.project_repository_forcing_receipts(prepared.forcing_receipts(), template)?;
        let receipt = candidate.execute_day(
            production_frame,
            projected_day_frames,
            projected_day_inputs,
            &projected,
        )?;
        candidate.inner.provider_gsi_receipt_sha256 = accepted_gsi_receipt_sha256;
        prepared.commit(&mut candidate.gsi_state, &mut candidate.provider_cursor)?;
        candidate.provider_cursor.validate_for_configuration(
            &candidate.provider_static_configuration,
            usize::try_from(accepted_gsi_day_index)
                .map_err(|_| DirectV9RealConsumerError::Identity("provider day width"))?
                .checked_add(1)
                .ok_or(DirectV9RealConsumerError::Identity("provider day overflow"))?,
        )?;
        *self = candidate;
        Ok(receipt)
    }

    #[cfg(test)]
    fn snow_free_provider_configuration(
        &self,
        template: &DirectV10ShadowDayInput,
    ) -> Result<SnowFreeHalfHourProviderConfiguration, DirectV10RealConsumerError> {
        Ok(self.inner.snow_free_provider_configuration(template)?)
    }

    fn project_repository_forcing_receipts(
        &self,
        provider: &ValidatedSnowFreeHalfHourForcingReceipts,
        template: DirectV10ShadowDayInput,
    ) -> Result<DirectV10ShadowDayInput, DirectV10RealConsumerError> {
        Ok(self
            .inner
            .project_repository_forcing_receipts(provider, template)?)
    }

    /// Construct all 48 V11 interval capabilities from one externally
    /// validated static forcing template and the live repository owner day.
    ///
    /// The template supplies only configuration-owned, non-climate science
    /// (soil/root geometry and optical/static forcing operands). Repository
    /// receipts replace atmospheric, radiation, GSI, and precipitation
    /// custody, while the live owner sequence supplies transaction identity.
    pub fn prepare_v11_intervals_from_repository(
        &self,
        provider: &PreparedSnowFreeGsiDayV1,
        template: &DirectV9ShadowIntervalInput,
    ) -> Result<
        Vec<(
            DirectV9ShadowIntervalInput,
            DirectV11SnowCoveredSegmentInput,
        )>,
        DirectV11RealConsumerError,
    > {
        let projected = self.project_v11_repository_forcing_on_unpublished_candidate(
            provider.gsi_receipt(),
            provider.forcing_receipts(),
            template,
        )?;
        projected
            .intervals
            .into_iter()
            .map(|snow_free| {
                let mut covered_lse = snow_free.lse_forcing.clone();
                covered_lse.snow_present_at_end = true;
                covered_lse.forcing_sha256 = covered_lse
                    .canonical_sha256()
                    .map_err(DirectV10RealConsumerError::from)?;
                let covered = DirectV11SnowCoveredSegmentInput::try_new(
                    covered_lse,
                    snow_free.vegetation_forcing.clone(),
                    snow_free.wb14_parameters.clone(),
                )?;
                Ok((snow_free, covered))
            })
            .collect()
    }

    fn project_v11_repository_forcing_on_unpublished_candidate(
        &self,
        gsi_receipt: &DirectGsiDailyReceiptV1,
        forcing_receipts: &ValidatedSnowFreeHalfHourForcingReceipts,
        template: &DirectV9ShadowIntervalInput,
    ) -> Result<DirectV10ShadowDayInput, DirectV11RealConsumerError> {
        gsi_receipt
            .validate()
            .map_err(DirectV10RealConsumerError::from)?;
        if gsi_receipt.run_id != self.provider_static_configuration.run_id
            || gsi_receipt.configuration_sha256 != self.gsi_owner_configuration.configuration_sha256
            || forcing_receipts.len() != self.provider_static_configuration.destinations.len()
            || forcing_receipts
                .iter()
                .zip(&self.provider_static_configuration.destinations)
                .any(|(receipt, destination)| {
                    receipt.intervals.len() != INTERVALS_PER_DAY
                        || receipt.intervals.iter().any(|interval| {
                            interval.ofe_id != destination.ofe_id
                                || interval.tile_id != destination.tile_id
                                || interval.wb14_configuration_sha256
                                    != destination.wb14_configuration_sha256
                                || interval.co2_pa.to_bits()
                                    != self.provider_static_configuration.co2_pa.to_bits()
                                || interval.reference_height_m.to_bits()
                                    != self
                                        .provider_static_configuration
                                        .reference_height_m
                                        .to_bits()
                        })
                })
        {
            return Err(DirectV11RealConsumerError::Identity(
                "prepared V11 provider static owner",
            ));
        }
        let day_index = usize::try_from(gsi_receipt.day_index)
            .map_err(|_| DirectV11RealConsumerError::Identity("provider day width"))?;
        let gsi = gsi_receipt.result.growing_season_index;
        let mut intervals = Vec::with_capacity(INTERVALS_PER_DAY);
        for interval_index in 0..INTERVALS_PER_DAY {
            let ordinal = u128::try_from(interval_index)
                .map_err(|_| DirectV11RealConsumerError::Identity("interval transaction width"))?
                .checked_add(1)
                .ok_or(DirectV11RealConsumerError::Identity(
                    "interval transaction overflow",
                ))?;
            let transaction_id = self
                .vegetation_state
                .0
                .last_transaction_id
                .checked_add(ordinal)
                .ok_or(DirectV11RealConsumerError::Identity(
                    "interval transaction overflow",
                ))?;
            let mut interval = template.clone();
            interval.lse_forcing.transaction_id = TransactionId(transaction_id);
            interval.lse_forcing.interval_s = 1_800.0;
            interval.lse_forcing.snow_present_at_beginning = false;
            interval.lse_forcing.snow_present_at_end = false;
            interval.lse_forcing.snow_terminal_payload_present = false;
            interval.lse_forcing.precipitation_parcels.clear();
            interval.lse_forcing.runon_parcels.clear();
            interval.lse_forcing.forcing_sha256 = interval
                .lse_forcing
                .canonical_sha256()
                .map_err(DirectV10RealConsumerError::from)?;
            interval.vegetation_forcing.gsi = gsi;
            intervals.push(interval);
        }
        let day = DirectV9ShadowDayInput::try_new(day_index, intervals)
            .map_err(DirectV10RealConsumerError::from)?;
        let mut candidate = self.clone();
        candidate
            .inner
            .provider_gsi_receipt_sha256
            .clone_from(&gsi_receipt.receipt_sha256);
        Ok(candidate.project_repository_forcing_receipts(forcing_receipts, day)?)
    }

    fn execute_day(
        &mut self,
        production_frame: &DirectRunFrame,
        projected_day_frames: &[DirectDayFrame],
        projected_day_inputs: &[DirectPublicationDayInput],
        input: &DirectV10ShadowDayInput,
    ) -> Result<DirectV10ShadowDayReceipt, DirectV10RealConsumerError> {
        let mut candidate = self.clone();
        let receipt = candidate.inner.execute_day(
            production_frame,
            projected_day_frames,
            projected_day_inputs,
            input,
        )?;
        candidate.vegetation_state = project_v9_runtime_to_v10(
            candidate.inner.vegetation_state(),
            &candidate.vegetation_configuration,
        )?;
        candidate.lse_state = project_validated_v1_runtime_to_v2(
            &candidate.inner.lse_configuration,
            candidate.inner.lse_state(),
            &candidate.lse_configuration,
            &openwepp_land_surface_energy::Sha256Digest::try_new(
                candidate
                    .vegetation_configuration
                    .configuration_sha256
                    .clone(),
            )?,
        )?;
        *self = candidate;
        Ok(receipt)
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_vegetation_configuration(&self) -> &VegetationConfiguration {
        &self.vegetation_configuration
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_lse_configuration(&self) -> &LandSurfaceEnergyConfiguration {
        &self.lse_configuration
    }

    #[must_use]
    pub(crate) const fn diagnostic_hydrology_frame_v1(&self) -> &DirectRunFrame {
        self.inner.hydrology_frame()
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_hydrology_frame(&self) -> &DirectRunFrame {
        self.diagnostic_hydrology_frame_v1()
    }

    #[must_use]
    pub(crate) fn diagnostic_hydrology_constructor_inputs_v1(
        &self,
    ) -> Option<&std::sync::Arc<crate::DirectRunConstructorInputs>> {
        self.inner.hydrology_constructor_inputs.as_ref()
    }

    pub(crate) fn diagnostic_install_hydrology_constructor_inputs_v1(
        &mut self,
        pinned: std::sync::Arc<crate::DirectRunConstructorInputs>,
    ) {
        self.inner.hydrology_constructor_inputs = Some(pinned);
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub fn restart_authority_soil_thermal(
        &self,
    ) -> Result<&SoilThermalSnapshot, DirectV9RealConsumerError> {
        self.inner.soil_thermal()
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    pub fn restart_authority_soil_resident(&self) -> &DirectSoilThermalResident {
        &self.inner.soil_thermal
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_biogeochemistry(&self) -> &BiogeochemistryState {
        self.inner.biogeochemistry()
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_vegetation_owner_id(&self) -> &ResourceOwnerId {
        &self.inner.vegetation_owner_id
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_surface_configuration(
        &self,
    ) -> &DirectSurfaceLiquidConfiguration {
        self.inner.restart_authority_surface_configuration()
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    pub fn restart_authority_accepted_publication_supports_canonical_bytes(
        &self,
    ) -> Result<Vec<u8>, DirectV10RealConsumerError> {
        let supports = self
            .accepted_publication_history
            .supports()
            .iter()
            .map(|support| support.to_wire())
            .collect::<Vec<_>>();
        let traversed_ending_complete_owner_set_sha256 = self
            .accepted_publication_history
            .validate_cached_tail_against_full_scan()
            .map_err(|_| {
                DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Identity(
                    "accepted publication authority chronology",
                ))
            })?;
        let authority_bytes = serde_json::to_vec(&(
            &supports,
            self.accepted_publication_history.event_handoffs(),
        ))
        .map_err(|_| {
            DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Serialization(
                "accepted publication authority projection".to_owned(),
            ))
        })?;
        let mut preimage = b"OPENWEPP_ACCEPTED_PUBLICATION_AUTHORITY_RESTART_V2\0".to_vec();
        preimage.extend_from_slice(&authority_bytes);
        let wire = Stage3AcceptedPublicationSupportSetWireV2 {
            schema_version: 2,
            supports,
            event_handoffs: self.accepted_publication_history.event_handoffs().to_vec(),
            traversed_ending_complete_owner_set_sha256,
            receipt_sha256: digest_bytes(&preimage),
        };
        serde_json::to_vec(&wire).map_err(|_| {
            DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Serialization(
                "accepted publication support encoding".to_owned(),
            ))
        })
    }

    pub(crate) fn adaptive_parent_telemetry_publication_shape_v1(&self) -> (usize, usize) {
        (
            self.accepted_publication_history.supports().len(),
            self.accepted_publication_history.event_handoffs().len(),
        )
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    pub fn restart_authority_restore_accepted_publication_supports_canonical_bytes(
        &mut self,
        bytes: &[u8],
    ) -> Result<(), DirectV10RealConsumerError> {
        let wire: Stage3AcceptedPublicationSupportSetWireV2 = serde_json::from_slice(bytes)
            .map_err(|_| {
                DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Serialization(
                    "accepted publication support decoding".to_owned(),
                ))
            })?;
        let canonical = serde_json::to_vec(&wire).map_err(|_| {
            DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Serialization(
                "accepted publication support canonicalization".to_owned(),
            ))
        })?;
        let authority_bytes =
            serde_json::to_vec(&(&wire.supports, &wire.event_handoffs)).map_err(|_| {
                DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Serialization(
                    "accepted publication authority seal projection".to_owned(),
                ))
            })?;
        let mut preimage = b"OPENWEPP_ACCEPTED_PUBLICATION_AUTHORITY_RESTART_V2\0".to_vec();
        preimage.extend_from_slice(&authority_bytes);
        let supports = wire
            .supports
            .iter()
            .cloned()
            .map(Stage3AcceptedPublicationSupportV1::try_from_wire)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|_| {
                DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Identity(
                    "accepted publication support wire operands",
                ))
            })?;
        let mut restored_history = AcceptedPublicationHistoryV1::default();
        restored_history
            .replace(supports, &wire.event_handoffs)
            .map_err(|_| {
                DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Identity(
                    "accepted publication authority wire chronology",
                ))
            })?;
        let traversed = restored_history
            .inner
            .tail_authority
            .traversed_ending_owner_sha256;
        if wire.schema_version != 2
            || canonical != bytes
            || wire.receipt_sha256 != digest_bytes(&preimage)
            || wire.traversed_ending_complete_owner_set_sha256 != traversed
        {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Identity("accepted publication support wire seal"),
            ));
        }
        self.accepted_publication_history = restored_history;
        Ok(())
    }

    /// Ending complete-owner digest reached by traversing every retained
    /// accepted support and its zero-duration accepted-event handoffs. The
    /// persisted attachment restore must join this value to its restored V11
    /// complete-owner authority, which makes omission of a terminal handoff
    /// fail even when no later positive-duration support exists yet.
    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    pub fn restart_authority_accepted_publication_traversed_ending_owner_sha256(
        &self,
    ) -> Result<Option<Digest32>, DirectV10RealConsumerError> {
        self.accepted_publication_history
            .validate_cached_tail_against_full_scan()
            .map_err(|_| {
                DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Identity(
                    "accepted publication traversed ending owner",
                ))
            })
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    pub fn restart_authority_install_staged_daily_owners(
        &mut self,
        gsi_state: GsiState,
        provider_cursor: SnowFreeHalfHourProviderCursor,
        expected_next_day_index: usize,
    ) -> Result<(), DirectV10RealConsumerError> {
        provider_cursor.validate_for_configuration(
            &self.provider_static_configuration,
            expected_next_day_index,
        )?;
        self.gsi_state = gsi_state;
        self.provider_cursor = provider_cursor;
        Ok(())
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    pub fn restart_authority_install_scheduler_position(
        &mut self,
        accepted_interval_count: u64,
    ) -> Result<(), DirectV10RealConsumerError> {
        if accepted_interval_count == 0
            || accepted_interval_count > u64::from(u32::MAX) * INTERVALS_PER_DAY as u64
        {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Unsupported("restart evidence scheduler position"),
            ));
        }
        self.inner.accepted_interval_count = accepted_interval_count;
        Ok(())
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_accepted_interval_count(&self) -> u64 {
        self.inner.accepted_interval_count()
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    #[must_use]
    pub const fn restart_authority_next_day_index(&self) -> usize {
        self.inner.next_day_index()
    }

    #[cfg(any(
        feature = "restart-authority-evidence",
        feature = "persisted-restart-v1"
    ))]
    pub fn restart_authority_advance_staged_intervals(
        &mut self,
        prepared: &PreparedSnowFreeGsiDayV1,
        mut template: DirectV10ShadowDayInput,
        start_interval: usize,
        end_interval_exclusive: usize,
    ) -> Result<(), DirectV10RealConsumerError> {
        if start_interval >= end_interval_exclusive || end_interval_exclusive > INTERVALS_PER_DAY {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Unsupported("restart evidence interval range"),
            ));
        }
        let mut candidate = self.clone();
        let receipt = prepared.gsi_receipt();
        for interval in &mut template.intervals {
            interval.vegetation_forcing.gsi = receipt.result.growing_season_index;
        }
        candidate
            .inner
            .provider_gsi_receipt_sha256
            .clone_from(&receipt.receipt_sha256);
        let template_day_index = template.day_index;
        let projected =
            candidate.project_repository_forcing_receipts(prepared.forcing_receipts(), template)?;
        let day_index =
            usize::try_from(candidate.inner.accepted_interval_count / INTERVALS_PER_DAY as u64)
                .map_err(|_| {
                    DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Identity(
                        "restart evidence day index overflow",
                    ))
                })?;
        if template_day_index != day_index || candidate.inner.next_day_index != day_index {
            return Err(DirectV10RealConsumerError::Runtime(
                DirectV9RealConsumerError::Identity("restart evidence continuation day"),
            ));
        }
        for interval_index in start_interval..end_interval_exclusive {
            candidate.inner.execute_interval(
                day_index,
                interval_index,
                &projected.intervals[interval_index],
            )?;
        }
        candidate.vegetation_state = project_v9_runtime_to_v10(
            candidate.inner.vegetation_state(),
            &candidate.vegetation_configuration,
        )?;
        candidate.lse_state = project_validated_v1_runtime_to_v2(
            &candidate.inner.lse_configuration,
            candidate.inner.lse_state(),
            &candidate.lse_configuration,
            &openwepp_land_surface_energy::Sha256Digest::try_new(
                candidate
                    .vegetation_configuration
                    .configuration_sha256
                    .clone(),
            )?,
        )?;
        if end_interval_exclusive == INTERVALS_PER_DAY {
            candidate.inner.next_day_index =
                day_index
                    .checked_add(1)
                    .ok_or(DirectV10RealConsumerError::Runtime(
                        DirectV9RealConsumerError::Identity("restart evidence next day overflow"),
                    ))?;
            candidate.inner.validate_complete_owner_set()?;
        }
        *self = candidate;
        Ok(())
    }

    #[cfg(test)]
    fn execute_first_interval_for_test(
        &mut self,
        input: &DirectV10ShadowDayInput,
    ) -> Result<(), DirectV10RealConsumerError> {
        let mut candidate = self.clone();
        candidate
            .inner
            .execute_interval(0, 0, &input.intervals[0])?;
        candidate.vegetation_state = project_v9_runtime_to_v10(
            candidate.inner.vegetation_state(),
            &candidate.vegetation_configuration,
        )?;
        candidate.lse_state = project_validated_v1_runtime_to_v2(
            &candidate.inner.lse_configuration,
            candidate.inner.lse_state(),
            &candidate.lse_configuration,
            &openwepp_land_surface_energy::Sha256Digest::try_new(
                candidate
                    .vegetation_configuration
                    .configuration_sha256
                    .clone(),
            )?,
        )?;
        *self = candidate;
        Ok(())
    }

    #[cfg(test)]
    fn execute_intervals_for_test(
        &mut self,
        input: &DirectV10ShadowDayInput,
        through_interval: usize,
    ) -> Result<(), DirectV10RealConsumerError> {
        let mut candidate = self.clone();
        for interval_index in 0..=through_interval {
            candidate.inner.execute_interval(
                0,
                interval_index,
                &input.intervals[interval_index],
            )?;
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DirectV9ShadowDayReceipt {
    pub day_index: usize,
    pub accepted_interval_count: usize,
    pub first_transaction_id: TransactionId,
    pub last_transaction_id: TransactionId,
    pub beginning_shadow_diagnostic_fingerprint: String,
    pub ending_shadow_diagnostic_fingerprint: String,
}

#[derive(Debug, Error, PartialEq)]
pub enum DirectV9RealConsumerError {
    #[error("V9 real-consumer identity failure: {0}")]
    Identity(&'static str),
    #[error("V9 real-consumer unsupported domain: {0}")]
    Unsupported(&'static str),
    #[error("V9 real-consumer owner closure failure: {0}")]
    OwnerClosure(&'static str),
    #[error(transparent)]
    Vegetation(#[from] VegetationError),
    #[error(transparent)]
    V9(#[from] V9StateError),
    #[error(transparent)]
    Physical(#[from] ExecuteV8LseRuntimeShadowError),
    #[error(transparent)]
    LandSurface(#[from] LandSurfaceEnergyError),
    #[error(transparent)]
    LandSurfaceShadow(#[from] LandSurfaceEnergyShadowError),
    #[error(transparent)]
    RealHydrology(#[from] RealHydrologyShadowError),
    #[error(transparent)]
    Biogeochemistry(#[from] BiogeochemistryError),
    #[error(transparent)]
    Projection(#[from] V8InputProjectionError),
    #[error(transparent)]
    OwnerEnvelope(#[from] CoveredV8OwnerEnvelopeError),
    #[error("V9 real-consumer serialization failure: {0}")]
    Serialization(String),
}

impl DirectV9RealConsumerError {
    #[must_use]
    pub const fn category(&self) -> &'static str {
        match self {
            Self::Identity(_) => "identity",
            Self::Unsupported(_) => "unsupported",
            Self::OwnerClosure(_) => "owner_closure",
            Self::Vegetation(_) => "vegetation",
            Self::V9(_) => "v9_identity",
            Self::Physical(_) => "strict_v8_lse_runtime",
            Self::LandSurface(_) => "land_surface",
            Self::LandSurfaceShadow(_) => "land_surface_shadow",
            Self::RealHydrology(_) => "real_hydrology",
            Self::Biogeochemistry(_) => "biogeochemistry",
            Self::Projection(_) => "projection",
            Self::OwnerEnvelope(_) => "owner_envelope",
            Self::Serialization(_) => "serialization",
        }
    }
}

include!("v9_real_consumer_shadow/direct_v9_real_consumer_shadow_impl.rs");

fn validate_repository_day_projection(
    production_frame: &DirectRunFrame,
    projected_day_frames: &[DirectDayFrame],
    projected_day_inputs: &[DirectPublicationDayInput],
    shadow_input: &DirectV9ShadowDayInput,
    lse_configuration: &LandSurfaceEnergyConfiguration,
    surface_configuration: &DirectSurfaceLiquidConfiguration,
) -> Result<(), DirectV9RealConsumerError> {
    if projected_day_frames.len() != production_frame.identity.lane_count
        || projected_day_inputs.len() != production_frame.identity.lane_count
        || projected_day_frames.len() != projected_day_inputs.len()
    {
        return Err(DirectV9RealConsumerError::Identity(
            "complete repository day projection",
        ));
    }
    for (lane_index, (day_frame, day_input)) in projected_day_frames
        .iter()
        .zip(projected_day_inputs)
        .enumerate()
    {
        if day_frame.identity != production_frame.identity
            || day_frame.lane_index != lane_index
            || day_frame.day_index != shadow_input.day_index
            || day_frame.forcing.precipitation_m.to_bits() != day_input.precipitation_m.to_bits()
            || day_frame.forcing.effective_temperature_c.to_bits()
                != day_input.effective_temperature_c.to_bits()
        {
            return Err(DirectV9RealConsumerError::Identity(
                "repository day input/frame receipt",
            ));
        }
        let binding = surface_configuration
            .ofe_bindings
            .iter()
            .find(|binding| binding.production_lane_index == lane_index)
            .ok_or(DirectV9RealConsumerError::Identity(
                "repository surface-owner OFE/lane projection",
            ))?;
        let ofe = lse_configuration
            .ofes
            .iter()
            .find(|ofe| ofe.ofe_id == binding.ofe_id)
            .ok_or(DirectV9RealConsumerError::Identity(
                "repository LSE/surface-owner OFE projection",
            ))?;
        let expected_precipitation_kg_m2 = day_input.precipitation_m * 1_000.0;
        for tile in &ofe.tiles {
            let custody = shadow_input
                .precipitation_custody
                .as_ref()
                .and_then(|value| {
                    value.current_source_and_outgoing_mass.get(&(
                        ofe.ofe_id.as_str().to_string(),
                        tile.tile_id.as_str().to_string(),
                    ))
                });
            let tile_precipitation_kg_m2 = shadow_input
                .intervals
                .iter()
                .flat_map(|interval| &interval.lse_forcing.precipitation_parcels)
                .filter(|parcel| {
                    parcel.parcel_kind == LiquidParcelKind::Precipitation
                        && parcel.destination_ofe_id == ofe.ofe_id
                        && parcel.destination_tile_id == tile.tile_id
                })
                .filter(|parcel| {
                    custody.is_none_or(|(source, _)| parcel.source_owner_id.as_str() == source)
                })
                .map(|parcel| parcel.amount_kg_m2_destination_tile_ground)
                .fold(0.0, |sum, value| sum + value);
            let reconstructed_source_mass =
                tile_precipitation_kg_m2 + custody.map_or(0.0, |(_, outgoing_mass)| *outgoing_mass);
            let matches = if custody.is_some() {
                (reconstructed_source_mass - expected_precipitation_kg_m2).abs()
                    <= 1.0e-12 * expected_precipitation_kg_m2.abs().max(1.0)
            } else {
                reconstructed_source_mass.to_bits() == expected_precipitation_kg_m2.to_bits()
            };
            if !matches {
                return Err(DirectV9RealConsumerError::Identity(
                    "repository daily precipitation/subdaily LSE parcel mass",
                ));
            }
        }
    }
    Ok(())
}

include!("v9_real_consumer_shadow/live_vegetation_forcing.rs");

include!("v9_real_consumer_shadow_soil_thermal.rs");
#[cfg(test)]
include!("v9_real_consumer_shadow_tests.rs");

#[path = "v9_real_consumer_shadow/native_snow_liquid_custody.rs"]
pub(crate) mod native_snow_liquid_custody;

#[path = "v9_real_consumer_shadow/native_snow_liquid_publication.rs"]
pub(crate) mod native_snow_liquid_publication;

pub(crate) mod composite_lse_owner;

pub(crate) use v11_covered::owner_finalization::canonical_stage3_snow_owner_bytes_v11;
pub(crate) use v11_covered::owner_finalization::canonical_stage3_snow_owner_bytes_v11_with_pending_and_receipts;

#[cfg(all(test, feature = "persisted-restart-v1"))]
mod deferred_composite_capability_traits {
    use super::DeferredNativeCompositeAdmissionV1;
    use crate::snow_stage3_v11_current_context_capture::member_restoration::ValidatedDeferredContextV1;

    macro_rules! assert_not_impl {
        ($ty:ty, $bound:path) => {{
            trait AmbiguousIfImpl<A> {
                fn marker() {}
            }
            impl<T: ?Sized> AmbiguousIfImpl<()> for T {}
            struct Implemented;
            impl<T: ?Sized + $bound> AmbiguousIfImpl<Implemented> for T {}
            let _ = <$ty as AmbiguousIfImpl<_>>::marker;
        }};
    }

    #[test]
    fn deferred_capabilities_are_non_wire_and_non_copyable() {
        macro_rules! assert_all {
            ($ty:ty) => {{
                assert_not_impl!($ty, Clone);
                assert_not_impl!($ty, Copy);
                assert_not_impl!($ty, serde::Serialize);
                assert_not_impl!($ty, serde::de::DeserializeOwned);
            }};
        }
        assert_all!(ValidatedDeferredContextV1);
        assert_all!(DeferredNativeCompositeAdmissionV1);
    }
}

#[cfg(all(test, feature = "persisted-restart-v1"))]
#[path = "v9_real_consumer_shadow/deferred_diagnostic_faults.rs"]
pub(crate) mod deferred_diagnostic_faults;
