//! Isolated policy13 native positive-origin snow-liquid custody.
//! Numerical candidate construction is separate from accepted history.

use crate::direct_runtime::{
    DirectZeroDurationSnowLiquidInputV1, PositiveSupportSnowLiquidAllocationV1,
    allocate_positive_support_snow_liquid_v1,
};
use crate::{
    DirectSurfaceLiquidError, LseSurfaceEnthalpyOwnerEnvelopeV1, SurfaceLiquidConfigurationV2,
    SurfaceLiquidOwnedStateV2, SurfaceLiquidOwnerEnvelopeV2,
};
use openwepp_kernel_contract::TransactionId;
use openwepp_land_surface_energy::{
    BeginningLitterPhaseState, ExactDyadicEnthalpy, LandSurfaceEnergyConfiguration,
    LandSurfaceEnergyV3State, LitterPhaseConfiguration, Sha256Digest, SurfaceConfiguration,
    physics::{
        LITTER_ICE_HEAT_CAPACITY_J_KG_K, REFERENCE_TEMPERATURE_K, WATER_HEAT_CAPACITY_J_KG_K,
    },
    validate_beginning_litter_state,
};

/// Unpublished arithmetic candidate. This type has no wire or acceptance API;
/// its exact owner still has the predecessor chain. A donor-bound publication
/// must validate and seal the successor chain before installing any field.
pub(crate) struct UnpublishedNativeSnowLiquidCandidateV1 {
    pub(crate) surface_owner: SurfaceLiquidOwnerEnvelopeV2,
    pub(crate) lse_state: LandSurfaceEnergyV3State,
    pub(crate) exact_owner: LseSurfaceEnthalpyOwnerEnvelopeV1,
    pub(crate) allocation: PositiveSupportSnowLiquidAllocationV1,
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn prepare_native_snow_liquid_candidate_v1(
    configuration: &SurfaceLiquidConfigurationV2,
    lse_configuration: &LandSurfaceEnergyConfiguration,
    beginning_lse: &LandSurfaceEnergyV3State,
    beginning_surface: &SurfaceLiquidOwnerEnvelopeV2,
    beginning_exact: &LseSurfaceEnthalpyOwnerEnvelopeV1,
    inputs: &[DirectZeroDurationSnowLiquidInputV1],
    transaction: TransactionId,
    ending_marker: Option<TransactionId>,
) -> Result<UnpublishedNativeSnowLiquidCandidateV1, DirectSurfaceLiquidError> {
    if ending_marker != beginning_lse.0.last_accepted_transaction_id {
        return Err(DirectSurfaceLiquidError::Identity(
            "native custody cannot advance physical marker",
        ));
    }
    beginning_lse
        .validate(lse_configuration)
        .map_err(|_| DirectSurfaceLiquidError::Identity("native drain beginning LSE"))?;
    beginning_exact
        .validate_frozen_parent_join(
            lse_configuration,
            beginning_lse,
            configuration,
            beginning_surface,
        )
        .map_err(|_| DirectSurfaceLiquidError::Identity("native drain exact beginning join"))?;
    let state = beginning_surface
        .v2_state()
        .ok_or(DirectSurfaceLiquidError::Identity("native drain V2 owner"))?;
    let allocation = allocate_positive_support_snow_liquid_v1(
        configuration.parent(),
        &state
            .records()
            .iter()
            .map(|record| record.liquid_kg_m2_tile)
            .collect::<Vec<_>>(),
        inputs,
        transaction,
    )?;
    let mut records = state.records().to_vec();
    let mut exact = beginning_exact.clone();
    let mut lse = beginning_lse.clone();
    for (record, liquid) in records.iter_mut().zip(&allocation.ending_liquid) {
        // Exact accumulation consumes primitive retained receipt credits; the
        // legacy tile aggregate has already rounded and is not an exact operand.
        let energy = allocation
            .receipts
            .iter()
            .filter(|receipt| {
                receipt.disposition
                    == crate::DirectZeroDurationSnowLiquidDispositionV1::RetainedSurface
                    && receipt.recipient_ofe_id == record.key.ofe_id
                    && receipt.recipient_tile_id.as_ref() == Some(&record.key.tile_id)
            })
            .map(|receipt| {
                receipt.credited_enthalpy_j_m2_recipient_tile_ground.ok_or(
                    DirectSurfaceLiquidError::Identity("native drain retained energy operand"),
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        let exact_record = exact
            .records
            .iter_mut()
            .find(|value| value.surface_key == record.key)
            .ok_or(DirectSurfaceLiquidError::Identity(
                "native drain exact tile",
            ))?;
        if energy.iter().any(|value| *value != 0.0) {
            let (high, carry) = ExactDyadicEnthalpy::exact_sum_binary64(
                exact_record.enthalpy_hi_j_m2_tile,
                &exact_record.enthalpy_carry,
                &energy,
            )
            .and_then(|value| value.rounded_high_and_remainder())
            .map_err(|_| DirectSurfaceLiquidError::Domain("native drain exact retained energy"))?;
            exact_record.enthalpy_hi_j_m2_tile = high;
            exact_record.enthalpy_carry = carry;
        }
        let physical_changed = record.liquid_kg_m2_tile.to_bits() != liquid.to_bits()
            || energy.iter().any(|value| *value != 0.0);
        record.liquid_kg_m2_tile = *liquid;
        record.surface_enthalpy_j_m2_tile = exact_record.enthalpy_hi_j_m2_tile;
        record.last_accepted_transaction_id = ending_marker;
        exact_record.last_accepted_transaction_id = ending_marker;
        if !physical_changed {
            continue;
        }
        let tile = lse
            .0
            .tiles
            .iter_mut()
            .find(|tile| tile.ofe_id == record.key.ofe_id && tile.tile_id == record.key.tile_id)
            .ok_or(DirectSurfaceLiquidError::Identity("native drain LSE tile"))?;
        let configured = lse_configuration
            .ofes
            .iter()
            .find(|ofe| ofe.ofe_id == record.key.ofe_id)
            .and_then(|ofe| {
                ofe.tiles
                    .iter()
                    .find(|tile| tile.tile_id == record.key.tile_id)
            })
            .ok_or(DirectSurfaceLiquidError::Identity(
                "native drain LSE configuration tile",
            ))?;
        let dry_capacity = match configured.surface {
            SurfaceConfiguration::ForestLitter {
                thickness_m,
                dry_density_kg_m3,
                dry_specific_heat_j_kg_k,
                ..
            } => thickness_m * dry_density_kg_m3 * dry_specific_heat_j_kg_k,
            SurfaceConfiguration::BareMineralSoil {
                dry_areal_heat_capacity_j_m2_k,
                ..
            } => dry_areal_heat_capacity_j_m2_k,
        };
        let capacity = dry_capacity
            + WATER_HEAT_CAPACITY_J_KG_K * record.liquid_kg_m2_tile
            + LITTER_ICE_HEAT_CAPACITY_J_KG_K * record.litter_ice_kg_m2_tile;
        if !capacity.is_finite() || capacity <= 0.0 {
            return Err(DirectSurfaceLiquidError::Domain(
                "native drain heat capacity",
            ));
        }
        tile.surface_enthalpy_j_m2_tile_ground = record.surface_enthalpy_j_m2_tile;
        tile.surface_temperature_warm_start_k =
            REFERENCE_TEMPERATURE_K + record.surface_enthalpy_j_m2_tile / capacity;
        if !tile.surface_temperature_warm_start_k.is_finite()
            || !(200.0..=350.0).contains(&tile.surface_temperature_warm_start_k)
        {
            return Err(DirectSurfaceLiquidError::Domain(
                "native drain dependent temperature",
            ));
        }
        if let SurfaceConfiguration::ForestLitter {
            thickness_m,
            liquid_capacity_kg_m2_tile_ground,
            ..
        } = configured.surface
        {
            let surface_configured = configuration
                .records()
                .iter()
                .find(|value| value.key == record.key)
                .ok_or(DirectSurfaceLiquidError::Identity(
                    "native drain litter configuration",
                ))?;
            validate_beginning_litter_state(
                LitterPhaseConfiguration {
                    litter_depth_m: thickness_m,
                    dry_heat_capacity_j_m2_k: dry_capacity,
                    liquid_capacity_kg_m2_tile: liquid_capacity_kg_m2_tile_ground,
                    ice_capacity_kg_m2_tile: surface_configured
                        .litter_ice_capacity_kg_m2_tile
                        .ok_or(DirectSurfaceLiquidError::Identity(
                            "native drain litter ice capacity",
                        ))?,
                },
                BeginningLitterPhaseState {
                    liquid_kg_m2_tile: record.liquid_kg_m2_tile,
                    ice_kg_m2_tile: record.litter_ice_kg_m2_tile,
                    sensible_energy_j_m2_tile: record.surface_enthalpy_j_m2_tile,
                    temperature_k: tile.surface_temperature_warm_start_k,
                },
            )
            .map_err(|_| {
                DirectSurfaceLiquidError::Closure("native drain litter temperature coordinate")
            })?;
        }
    }
    let continuations = state.continuations().to_vec();
    let surface = SurfaceLiquidOwnerEnvelopeV2::wrap_v2(
        configuration,
        SurfaceLiquidOwnedStateV2::try_new(configuration, records, continuations)?,
    )?;
    lse.0.last_accepted_transaction_id = ending_marker;
    lse.0.state_sha256 = lse
        .canonical_sha256()
        .map_err(|_| DirectSurfaceLiquidError::Schema("native drain LSE seal"))?;
    lse.validate(lse_configuration)
        .map_err(|_| DirectSurfaceLiquidError::Identity("native drain ending LSE"))?;
    exact.frozen_lse_v3_state_sha256 = lse.0.state_sha256.clone();
    exact.frozen_surface_owner_v2_sha256 = Sha256Digest::try_new(surface.envelope_sha256())
        .map_err(|_| DirectSurfaceLiquidError::Schema("native drain surface digest"))?;
    exact.state_sha256 = exact
        .recomputed_state_sha256()
        .map_err(|_| DirectSurfaceLiquidError::Schema("native drain exact state seal"))?;
    exact
        .validate_frozen_parent_join(lse_configuration, &lse, configuration, &surface)
        .map_err(|_| DirectSurfaceLiquidError::Identity("native drain ending exact join"))?;
    Ok(UnpublishedNativeSnowLiquidCandidateV1 {
        surface_owner: surface,
        lse_state: lse,
        exact_owner: exact,
        allocation,
    })
}
