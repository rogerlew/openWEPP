//! Public canonical-context poisons for the surface-liquid ingress boundary.

use crate::DirectSurfaceLiquidOfeBinding;
use openwepp_kernel_contract::{ResourceOwnerId, TileId, TransactionId};
use openwepp_land_surface_energy::{OfeId, SourceId, SurfaceId};
use sha2::{Digest, Sha256};

use super::tests::{
    initial_state, one_tile_configuration, open_ingress, parameters, resource_candidate,
    three_ofe_configuration,
};
use super::{
    DirectGroundIngressMode, DirectOfeWb14Parameters, DirectSurfaceLiquidConfiguration,
    DirectSurfaceLiquidConfigurationRecord, DirectSurfaceLiquidErrorCode,
    DirectSurfaceLiquidIngressInput, DirectSurfaceLiquidOwnedState, DirectSurfaceLiquidPhase,
    DirectSurfaceLiquidReceiptDisposition, DirectSurfaceLiquidReceiptRecipient,
    DirectTileGroundIngress, DirectWb14CoupledChildBindingV1, DirectWb14ParentWorkingState,
    INTERVAL_S, REFERENCE_TEMPERATURE_K, WATER_DENSITY_KG_M3, execute_surface_liquid_ingress,
    execute_surface_liquid_ingress_with_parent_state_and_coupled_binding, liquid_specific_enthalpy,
};

const B01_PACKET: &[u8] = include_bytes!("fixtures/b01_wb14_current_run_boundary_packet.json");
const B01_OWNER_SEED: &[u8] = include_bytes!("fixtures/b01_wb14_owner_seed.json");

fn b01_hex_f64(value: &str) -> f64 {
    let bits = u64::from_str_radix(value.strip_prefix("0x").expect("hex float"), 16)
        .expect("binary64 bits");
    f64::from_bits(bits)
}

fn b01_bytes(value: &serde_json::Value) -> Vec<u8> {
    value
        .as_array()
        .expect("captured byte array")
        .iter()
        .map(|byte| u8::try_from(byte.as_u64().expect("captured byte integer")).expect("u8"))
        .collect()
}

fn b01_digest(value: &serde_json::Value) -> [u8; 32] {
    b01_bytes(value).try_into().expect("captured SHA-256")
}

fn b01_captured_context() -> (
    DirectSurfaceLiquidConfiguration,
    DirectSurfaceLiquidOwnedState,
    DirectSurfaceLiquidIngressInput,
    DirectWb14ParentWorkingState,
    DirectWb14CoupledChildBindingV1,
) {
    let seed: serde_json::Value = serde_json::from_slice(B01_OWNER_SEED).expect("owner seed JSON");
    let wire = &seed["checkpoint"]["phase"]["committed"]["surface_liquid_configuration"];
    let topology = wire["ofe_topology"]
        .as_array()
        .expect("OFE topology")
        .iter()
        .map(|value| OfeId::try_new(value.as_str().expect("OFE id")).expect("valid OFE id"))
        .collect();
    let bindings: Vec<DirectSurfaceLiquidOfeBinding> =
        serde_json::from_value(wire["ofe_bindings"].clone()).expect("OFE bindings");
    let records = wire["records"]
        .as_array()
        .expect("surface-liquid records")
        .iter()
        .map(|record| DirectSurfaceLiquidConfigurationRecord {
            key: serde_json::from_value(record["key"].clone()).expect("store key"),
            tile_fraction: b01_hex_f64(record["tile_fraction"].as_str().expect("tile fraction")),
            capacity_kg_m2_tile: b01_hex_f64(
                record["capacity_kg_m2_tile"].as_str().expect("capacity"),
            ),
            ofe_area_m2: b01_hex_f64(record["ofe_area_m2"].as_str().expect("OFE area")),
            ground_ingress_mode: serde_json::from_value(record["ground_ingress_mode"].clone())
                .expect("ground ingress mode"),
            runon_destination_ofe_id: record["runon_destination_ofe_id"]
                .as_str()
                .map(|value| OfeId::try_new(value).expect("runon OFE")),
            runon_destination_tile_id: record["runon_destination_tile_id"]
                .as_str()
                .map(|value| TileId::try_new(value).expect("runon tile")),
        })
        .collect();
    let configuration = DirectSurfaceLiquidConfiguration::new(
        ResourceOwnerId::try_new(wire["owner_id"].as_str().expect("owner id"))
            .expect("valid owner id"),
        wire["run_id"].as_u64().expect("run id"),
        topology,
        bindings,
        records,
    )
    .expect("source-defined captured configuration");

    let packet: serde_json::Value =
        serde_json::from_slice(B01_PACKET).expect("boundary packet JSON");
    let records = packet["records"].as_array().expect("packet records");
    let ingress_record = &records[0]["record"];
    let caller_record = &records[1]["record"];
    let beginning: DirectSurfaceLiquidOwnedState =
        serde_json::from_slice(&b01_bytes(&ingress_record["beginning_typed_bytes"]["Ok"]))
            .expect("captured beginning state");
    let input: DirectSurfaceLiquidIngressInput =
        serde_json::from_slice(&b01_bytes(&ingress_record["input_typed_bytes"]["Ok"]))
            .expect("captured ingress input");
    let working: DirectSurfaceLiquidOwnedState =
        serde_json::from_slice(&b01_bytes(&caller_record["working_typed_bytes"]["Ok"]))
            .expect("captured caller working state");
    assert_eq!(
        working, beginning,
        "caller working state must retain the exact ingress beginning owner"
    );
    let parent = DirectWb14ParentWorkingState::from_restart_bytes(
        &configuration,
        &b01_bytes(&caller_record["parent_working_typed_bytes"]["Ok"]),
    )
    .expect("captured parent passes nested context validation");
    let binding = &caller_record["coupled_binding"];
    let coupled_binding = DirectWb14CoupledChildBindingV1 {
        proposed_upper_bound_s_bits: binding["proposed_upper_bound_s_bits"]
            .as_u64()
            .expect("upper bound bits"),
        coupled_parent_transaction_sha256: b01_digest(
            &binding["coupled_parent_transaction_sha256"],
        ),
        accepted_slab_sha256: b01_digest(&binding["accepted_slab_sha256"]),
        parent_beginning_complete_owner_set_sha256: b01_digest(
            &binding["parent_beginning_complete_owner_set_sha256"],
        ),
        parent_support_start_ns: binding["parent_support_start_ns"]
            .as_str()
            .expect("parent start")
            .parse()
            .expect("parent start ns"),
        parent_support_end_ns: binding["parent_support_end_ns"]
            .as_str()
            .expect("parent end")
            .parse()
            .expect("parent end ns"),
        child_support_start_ns: binding["child_support_start_ns"]
            .as_str()
            .expect("child start")
            .parse()
            .expect("child start ns"),
        child_support_end_ns: binding["child_support_end_ns"]
            .as_str()
            .expect("child end")
            .parse()
            .expect("child end ns"),
    };
    (configuration, beginning, input, parent, coupled_binding)
}

#[test]
fn b01_wb14_captured_parent_context_passes_source_defined_joins() {
    let (configuration, beginning, input, parent, binding) = b01_captured_context();
    assert_eq!(
        configuration.configuration_sha256,
        beginning.configuration_sha256
    );
    assert_eq!(parent.candidate_state(), &beginning);
    assert_eq!(input.day_index, 4);
    assert_eq!(input.interval_index, 22);
    assert_eq!(input.interval_s.to_bits(), 60.0_f64.to_bits());
    assert_eq!(input.transaction_id, TransactionId(255));
    assert_eq!(
        input.wb14_parameters,
        serde_json::from_value::<Vec<DirectOfeWb14Parameters>>(
            serde_json::from_slice::<serde_json::Value>(
                &parent
                    .restart_bytes(&configuration)
                    .expect("validated parent bytes"),
            )
            .expect("validated parent JSON")["parameters"]
                .clone(),
        )
        .expect("captured parent parameters"),
    );
    assert_eq!(
        configuration
            .ofe_bindings
            .iter()
            .map(|row| row.production_lane_id)
            .collect::<Vec<_>>(),
        vec![1],
    );
    let (derived_start, derived_end, derived_wb14_configuration, derived_lanes) =
        super::wb14_parent_binding(&configuration, &input).expect("derived WB14 parent binding");
    assert_eq!(derived_start, 385_200_000_000_000);
    assert_eq!(derived_end, 387_000_000_000_000);
    assert_eq!(binding.parent_support_start_ns, 385_200_000_000_000);
    assert_eq!(binding.parent_support_end_ns, 387_000_000_000_000);
    assert_eq!(binding.child_support_start_ns, 385_920_000_000_000);
    assert_eq!(binding.child_support_end_ns, 385_980_000_000_000);
    assert_eq!(binding.proposed_upper_bound_s_bits, 60.0_f64.to_bits());
    let parent_wire: serde_json::Value = serde_json::from_slice(
        &parent
            .restart_bytes(&configuration)
            .expect("validated parent bytes"),
    )
    .expect("validated parent JSON");
    assert_eq!(parent_wire["parent_day_index"], 4);
    assert_eq!(parent_wire["parent_interval_index"], 22);
    assert_eq!(parent_wire["accepted_until_ns"], 385_920_000_000_000_u64);
    assert_eq!(
        parent_wire["parent_support_start_ns"],
        385_200_000_000_000_i64
    );
    assert_eq!(
        parent_wire["parent_support_end_ns"],
        387_000_000_000_000_i64
    );
    assert_eq!(
        parent_wire["wb14_configuration_sha256"],
        derived_wb14_configuration,
    );
    assert_eq!(
        serde_json::from_value::<Vec<u32>>(parent_wire["production_lane_ids"].clone())
            .expect("captured parent production lanes"),
        derived_lanes,
    );
    assert_eq!(
        parent_wire["wb14_model_definition_sha256"],
        format!(
            "{:x}",
            Sha256::digest(
                b"OPENWEPP_WB14_GREEN_AMPT_MODEL_DEFINITION_V1:advance_wb14_continuation_interval"
            )
        ),
    );
    assert_eq!(
        parent_wire["candidate_state"]["continuations"]
            .as_array()
            .map(Vec::len),
        Some(beginning.continuations.len()),
    );
    let authority = &parent_wire["per_ofe_authorities"]["ofe-1"]["authority"];
    assert_eq!(
        b01_digest(&authority["coupled_parent_transaction_sha256"]),
        binding.coupled_parent_transaction_sha256,
    );
    assert_eq!(
        b01_digest(&authority["inactive_prefix"]["prefix_ending_owner_sha256"]),
        binding.parent_beginning_complete_owner_set_sha256,
    );
    assert_eq!(authority["production_lane_id"], 1);
    parent
        .validate_in_process(&configuration)
        .expect("captured parent nested joins");
}

#[test]
fn b01_wb14_captured_first_physical_child_must_enter_real_ingress() {
    let (configuration, beginning, input, parent, binding) = b01_captured_context();
    let resource = resource_candidate(&configuration, &beginning, input.transaction_id, None, &[]);
    let result = execute_surface_liquid_ingress_with_parent_state_and_coupled_binding(
        &configuration,
        &resource,
        &input,
        Some(&parent),
        false,
        Some(binding),
    );
    if let Err(error) = &result {
        let failure = error.failure().expect("canonical expected-red failure");
        assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E008);
        assert_eq!(failure.phase, DirectSurfaceLiquidPhase::IngressCandidate);
        assert_eq!(failure.context.transaction_id, Some(TransactionId(255)));
        assert_eq!(failure.detail, "WB14 day or interval continuation mismatch",);
    }
    result.expect("EXPECTED_RED baseline: the validated first physical child must be admitted");
}

fn five_window_configuration() -> DirectSurfaceLiquidConfiguration {
    let base = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let records = (0..5)
        .map(|index| {
            let mut record = base.records[0].clone();
            record.key.tile_id = TileId::try_new(format!("tile-{index}")).expect("tile");
            record.key.surface_id =
                SurfaceId::try_new(format!("surface-tile-{index}")).expect("surface");
            record.key.source_id =
                SourceId::try_new(format!("source-tile-{index}")).expect("source");
            record.tile_fraction = 0.2;
            record.capacity_kg_m2_tile = 1.0;
            record
        })
        .collect();
    DirectSurfaceLiquidConfiguration::new(
        base.owner_id,
        base.run_id,
        base.ofe_topology,
        base.ofe_bindings,
        records,
    )
    .expect("five-window configuration")
}

#[test]
fn identity_mismatch_does_not_hide_later_comparison_scale_overflow() {
    let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(4_143);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S,
        tile_ingress: vec![open_ingress(&configuration.records[0], 0.1)],
        wb14_parameters: parameters(&configuration),
    };
    let mut candidate =
        execute_surface_liquid_ingress(&configuration, &resource, &input).expect("open candidate");
    let source_id = candidate
        .closure_operands
        .poison_first_source_mass_comparison_scale_for_test();
    let mut outlet = candidate
        .receipts
        .iter()
        .find(|receipt| {
            receipt.source_parcel_id == source_id
                && receipt.disposition == DirectSurfaceLiquidReceiptDisposition::RetainedSurface
        })
        .expect("retained receipt")
        .clone();
    outlet.disposition = DirectSurfaceLiquidReceiptDisposition::OutletRunoff;
    outlet.recipient = DirectSurfaceLiquidReceiptRecipient::Outlet {
        ofe_id: outlet.basis_ofe_id.clone(),
    };
    outlet.mass_kg_m2_basis_ofe_ground = f64::MAX * 0.6;
    outlet.temperature_k = REFERENCE_TEMPERATURE_K;
    outlet.enthalpy_j_m2_basis_ofe_ground = 0.0;
    candidate.receipts.push(outlet);
    let infiltration = candidate
        .receipts
        .iter_mut()
        .find(|receipt| receipt.disposition == DirectSurfaceLiquidReceiptDisposition::Infiltration)
        .expect("infiltration receipt");
    let DirectSurfaceLiquidReceiptRecipient::SoilInfiltration {
        production_lane_id, ..
    } = &mut infiltration.recipient
    else {
        panic!("wrong receipt variant");
    };
    *production_lane_id += 100;

    let failure = candidate
        .validate(&configuration, &resource, &input)
        .expect_err("later comparison arithmetic must outrank identity mismatch")
        .failure()
        .expect("failure")
        .clone();
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E003);
    assert_eq!(failure.phase, DirectSurfaceLiquidPhase::IndependentClosure);
    assert_eq!(
        failure.context.ofe_id.as_ref().map(OfeId::as_str),
        Some("only")
    );
    assert_eq!(
        failure.context.tile_id.as_ref().map(TileId::as_str),
        Some("tile")
    );
    assert_eq!(failure.detail, "parcel mass join");
}

#[test]
fn candidate_validation_preflights_public_schema_and_identity_before_closure_arithmetic() {
    let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(4_140);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S,
        tile_ingress: vec![open_ingress(&configuration.records[0], 0.1)],
        wb14_parameters: parameters(&configuration),
    };
    let mut candidate =
        execute_surface_liquid_ingress(&configuration, &resource, &input).expect("valid candidate");
    candidate
        .closure_operands
        .poison_first_store_arithmetic_overflow_for_test();

    let mut wrong_transaction = input.clone();
    wrong_transaction.transaction_id = TransactionId(4_141);
    let error = candidate
        .validate(&configuration, &resource, &wrong_transaction)
        .expect_err("identity preflight must precede closure arithmetic");
    let failure = error.failure().expect("canonical identity failure");
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E002);
    assert_eq!(failure.phase, DirectSurfaceLiquidPhase::IngressCandidate);
    assert!(failure.rollback.beginning_owner_sha256.is_some());
    assert!(failure.rollback.attempted_owner_sha256.is_some());

    let mut empty_configuration = configuration.clone();
    empty_configuration.records.clear();
    let error = candidate
        .validate(&empty_configuration, &resource, &input)
        .expect_err("schema preflight must precede closure arithmetic");
    assert_eq!(error.code(), DirectSurfaceLiquidErrorCode::E001);
}

#[test]
fn projection_arithmetic_e003_precedes_reordered_partition_e009() {
    let configuration = three_ofe_configuration();
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(4_143);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S,
        tile_ingress: configuration
            .records
            .iter()
            .map(|record| open_ingress(record, 0.1))
            .collect(),
        wb14_parameters: parameters(&configuration),
    };
    let mut candidate = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect("three-OFE candidate");
    candidate
        .closure_operands
        .reorder_partition_inputs_for_test();
    let mut duplicate = candidate.receipts[0].clone();
    duplicate.mass_kg_m2_basis_ofe_ground = f64::MAX * 0.75;
    duplicate.enthalpy_j_m2_basis_ofe_ground = 0.0;
    candidate.receipts[0] = duplicate.clone();
    candidate.receipts[1] = duplicate;

    let error = candidate
        .validate(&configuration, &resource, &input)
        .expect_err("later projection E003 must precede partition E009");
    let failure = error.failure().expect("canonical arithmetic failure");
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E003);
    assert_eq!(failure.phase, DirectSurfaceLiquidPhase::IndependentClosure);
    assert_eq!(failure.context.transaction_id, Some(transaction_id));
    assert_eq!(
        failure.context.parcel_id,
        Some(candidate.receipts[0].parcel_id.clone())
    );
    assert_eq!(
        failure.rollback.beginning_owner_sha256.as_deref(),
        Some(resource.beginning_state().state_sha256.as_str())
    );
    assert_eq!(
        failure.rollback.attempted_owner_sha256.as_deref(),
        Some(candidate.ending_state().state_sha256.as_str())
    );
}

#[test]
fn five_window_temporal_mass_uses_exact_parent_remainder_and_rejects_one_ulp_loss() {
    let configuration = five_window_configuration();
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(4_142);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let mut ingress = configuration
        .records
        .iter()
        .enumerate()
        .map(|(index, record)| open_ingress(record, if index == 0 { 0.5 } else { 0.0 }))
        .collect::<Vec<_>>();
    let support_windows = [
        (360.0, 720.0),
        (720.0, 1_080.0),
        (1_080.0, 1_440.0),
        (1_440.0, 1_800.0),
    ];
    for (row, (start_s, end_s)) in ingress.iter_mut().skip(1).zip(support_windows) {
        let DirectTileGroundIngress::OpenRawPrecipitation {
            raw_precipitation, ..
        } = row
        else {
            panic!("open ingress fixture");
        };
        raw_precipitation.start_s = start_s;
        raw_precipitation.end_s = end_s;
    }
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S,
        tile_ingress: ingress,
        wb14_parameters: parameters(&configuration),
    };
    let candidate = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect("five-window candidate");
    candidate
        .validate(&configuration, &resource, &input)
        .expect("exact temporal mass closure");

    let parent = candidate
        .closure_operands()
        .source_parcels()
        .iter()
        .find(|row| row.mass_kg_m2_basis_ofe_ground().to_bits() == 0.1_f64.to_bits())
        .expect("0.1 kg/m2 parent");
    let attributed = candidate
        .receipts()
        .iter()
        .filter(|row| row.source_parcel_id == parent.source_parcel_id())
        .map(|row| row.mass_kg_m2_basis_ofe_ground)
        .sum::<f64>();
    assert_eq!(
        attributed.to_bits(),
        parent.mass_kg_m2_basis_ofe_ground().to_bits()
    );
    let all_ratio = (0..5).map(|_| 0.1 * (360.0 / 1_800.0)).sum::<f64>();
    assert_ne!(all_ratio.to_bits(), 0.1_f64.to_bits());

    let mut poison = candidate.clone();
    let receipt = poison
        .receipts
        .iter_mut()
        .find(|row| {
            row.source_parcel_id == parent.source_parcel_id()
                && row.mass_kg_m2_basis_ofe_ground > 0.0
        })
        .expect("positive temporal child");
    receipt.mass_kg_m2_basis_ofe_ground =
        f64::from_bits(receipt.mass_kg_m2_basis_ofe_ground.to_bits() - 1);
    let error = super::super::surface_liquid_closure::validate_surface_liquid_closure_operands(
        &configuration,
        &resource,
        &poison.closure_operands,
        &poison.receipts,
        &poison.ending_state,
    )
    .expect_err("one-ULP temporal mass loss must fail exact closure");
    assert_eq!(error.code(), DirectSurfaceLiquidErrorCode::E010);
}

#[test]
fn cadence_failure_is_e008_with_exact_transaction_and_attempt_hash() {
    let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(411);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S + 1.0,
        tile_ingress: vec![open_ingress(&configuration.records[0], 0.1)],
        wb14_parameters: parameters(&configuration),
    };
    let error = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect_err("wrong cadence");
    let failure = error.failure().expect("canonical failure");
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E008);
    assert_eq!(failure.phase, DirectSurfaceLiquidPhase::IngressCandidate);
    assert_eq!(failure.context.transaction_id, Some(transaction_id));
    assert!(failure.rollback.attempted_owner_sha256.is_some());
}

#[test]
fn nonfinite_interval_is_e003_before_cadence() {
    let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(4_111);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: f64::NAN,
        tile_ingress: vec![open_ingress(&configuration.records[0], 0.1)],
        wb14_parameters: parameters(&configuration),
    };
    let error = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect_err("nonfinite interval");
    let failure = error.failure().expect("canonical interval failure");
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E003);
    assert_eq!(failure.phase, DirectSurfaceLiquidPhase::IngressCandidate);
    assert_eq!(failure.context.transaction_id, Some(transaction_id));
    assert!(failure.rollback.beginning_owner_sha256.is_some());
    assert!(failure.rollback.attempted_owner_sha256.is_some());
}

#[test]
fn unknown_ingress_identity_precedes_cardinality() {
    let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(4_112);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let mut unknown = open_ingress(&configuration.records[0], 0.1);
    let DirectTileGroundIngress::OpenRawPrecipitation { tile_id, .. } = &mut unknown else {
        panic!("open ingress fixture");
    };
    *tile_id = openwepp_kernel_contract::TileId::try_new("unknown").expect("unknown tile");
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S,
        tile_ingress: vec![open_ingress(&configuration.records[0], 0.1), unknown],
        wb14_parameters: parameters(&configuration),
    };
    let error = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect_err("unknown identity plus cardinality");
    let failure = error.failure().expect("canonical ingress identity failure");
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E002);
    assert_eq!(failure.context.transaction_id, Some(transaction_id));
    assert_eq!(
        failure
            .context
            .tile_id
            .as_ref()
            .map(openwepp_kernel_contract::TileId::as_str),
        Some("unknown")
    );
    assert!(failure.rollback.beginning_owner_sha256.is_some());
    assert!(failure.rollback.attempted_owner_sha256.is_some());
}

#[test]
fn public_ingress_failures_retain_available_owner_and_exact_offender_context() {
    let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let beginning = initial_state(&configuration, 0.0);
    let resource_transaction = TransactionId(4_120);
    let resource = resource_candidate(&configuration, &beginning, resource_transaction, None, &[]);
    let mut input = DirectSurfaceLiquidIngressInput {
        transaction_id: TransactionId(4_121),
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S,
        tile_ingress: vec![open_ingress(&configuration.records[0], 0.1)],
        wb14_parameters: parameters(&configuration),
    };

    let mismatch = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect_err("transaction mismatch");
    let failure = mismatch.failure().expect("canonical transaction failure");
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E002);
    assert_eq!(failure.context.transaction_id, Some(input.transaction_id));
    assert_eq!(
        failure.context.owner_id.as_ref(),
        Some(&configuration.owner_id)
    );
    assert_eq!(failure.context.ofe_id, None);
    assert_eq!(failure.context.tile_id, None);

    input.transaction_id = resource_transaction;
    let DirectTileGroundIngress::OpenRawPrecipitation {
        raw_precipitation, ..
    } = &mut input.tile_ingress[0]
    else {
        panic!("open ingress fixture");
    };
    raw_precipitation.mass_kg_m2_tile_ground = f64::NAN;
    let invalid = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect_err("invalid direct ingress amount");
    let failure = invalid.failure().expect("canonical direct-ingress failure");
    let key = &configuration.records[0].key;
    assert_eq!(failure.code, DirectSurfaceLiquidErrorCode::E003);
    assert_eq!(failure.context.transaction_id, Some(resource_transaction));
    assert_eq!(
        failure.context.owner_id.as_ref(),
        Some(&configuration.owner_id)
    );
    assert_eq!(failure.context.ofe_id.as_ref(), Some(&key.ofe_id));
    assert_eq!(failure.context.tile_id.as_ref(), Some(&key.tile_id));
    assert_eq!(failure.context.surface_id.as_ref(), Some(&key.surface_id));
    assert_eq!(failure.context.source_id.as_ref(), Some(&key.source_id));
}

#[test]
fn full_infiltration_preserves_exact_source_mass_and_never_debits_surface_store() {
    // 0x1.f9e1df20c7aa4p-6: dividing by 1000 and multiplying back rounds one
    // ULP upward, so this ordinary finite value exercises the exact WB14
    // full-infiltration identity branch.
    let source_mass = f64::from_bits(0x3f9f_9e1d_f20c_7aa4);
    assert!(source_mass / WATER_DENSITY_KG_M3 * WATER_DENSITY_KG_M3 > source_mass);

    for (case_index, beginning_fraction) in [0.0, 0.5].into_iter().enumerate() {
        let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
        let beginning = initial_state(&configuration, beginning_fraction);
        let transaction_id = TransactionId(410 + case_index as u128);
        let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
        let input = DirectSurfaceLiquidIngressInput {
            transaction_id,
            day_index: 3,
            interval_index: 0,
            interval_s: INTERVAL_S,
            tile_ingress: vec![open_ingress(&configuration.records[0], source_mass)],
            wb14_parameters: vec![DirectOfeWb14Parameters {
                ofe_id: configuration.ofe_topology[0].clone(),
                effective_conductivity_m_s: 1.0e-6,
                matric_potential_m: 0.1,
                infiltration_storage_capacity_m: 1.0,
            }],
        };
        let candidate = execute_surface_liquid_ingress(&configuration, &resource, &input)
            .expect("exact full-infiltration candidate");
        let infiltration = candidate
            .receipts
            .iter()
            .find(|receipt| {
                receipt.disposition == DirectSurfaceLiquidReceiptDisposition::Infiltration
            })
            .expect("full-infiltration receipt");
        assert_eq!(
            infiltration.mass_kg_m2_basis_ofe_ground.to_bits(),
            source_mass.to_bits()
        );
        let ledger = &candidate.ledgers[0];
        assert_eq!(
            ledger.ingress_mass_kg_m2_ofe_ground.to_bits(),
            source_mass.to_bits()
        );
        assert_eq!(
            ledger.infiltration_mass_kg_m2_ofe_ground.to_bits(),
            source_mass.to_bits()
        );
        assert_eq!(
            ledger.retained_mass_kg_m2_ofe_ground.to_bits(),
            0.0_f64.to_bits()
        );
        assert_eq!(
            ledger.runoff_mass_kg_m2_ofe_ground.to_bits(),
            0.0_f64.to_bits()
        );
        let attributed = ledger.infiltration_mass_kg_m2_ofe_ground
            + ledger.retained_mass_kg_m2_ofe_ground
            + ledger.runoff_mass_kg_m2_ofe_ground;
        assert_eq!(
            attributed.to_bits(),
            source_mass.to_bits(),
            "I + E = X exactly"
        );
        assert!(candidate.receipts.iter().all(|receipt| {
            receipt.mass_kg_m2_basis_ofe_ground.is_finite()
                && receipt.mass_kg_m2_basis_ofe_ground >= 0.0
        }));
        assert_eq!(
            candidate.ending_state.records[0]
                .liquid_kg_m2_tile
                .to_bits(),
            beginning.records[0].liquid_kg_m2_tile.to_bits(),
            "full infiltration must not debit the beginning surface store"
        );

        let mut poison = candidate.clone();
        let poisoned = poison
            .receipts
            .iter_mut()
            .find(|receipt| {
                receipt.disposition == DirectSurfaceLiquidReceiptDisposition::Infiltration
            })
            .expect("poisoned infiltration receipt");
        poisoned.mass_kg_m2_basis_ofe_ground *= 0.5;
        poisoned.enthalpy_j_m2_basis_ofe_ground =
            poisoned.mass_kg_m2_basis_ofe_ground * liquid_specific_enthalpy(poisoned.temperature_k);
        let error = super::super::surface_liquid_closure::validate_surface_liquid_closure_operands(
            &configuration,
            &resource,
            &poison.closure_operands,
            &poison.receipts,
            &poison.ending_state,
        )
        .expect_err("raw source/OFE mass closure poison");
        assert_eq!(error.code(), DirectSurfaceLiquidErrorCode::E010);
    }
}

#[test]
fn canonical_last_enthalpy_remainders_close_exactly_and_reject_one_ulp_loss() {
    let configuration = one_tile_configuration(DirectGroundIngressMode::OpenRawPrecipitation);
    let beginning = initial_state(&configuration, 0.0);
    let transaction_id = TransactionId(414);
    let resource = resource_candidate(&configuration, &beginning, transaction_id, None, &[]);
    let input = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: 3,
        interval_index: 0,
        interval_s: INTERVAL_S,
        tile_ingress: vec![open_ingress(&configuration.records[0], 0.3)],
        wb14_parameters: vec![DirectOfeWb14Parameters {
            ofe_id: configuration.ofe_topology[0].clone(),
            effective_conductivity_m_s: 1.0e-6,
            matric_potential_m: 0.1,
            infiltration_storage_capacity_m: 3.0e-5,
        }],
    };
    let candidate = execute_surface_liquid_ingress(&configuration, &resource, &input)
        .expect("partial-infiltration enthalpy fixture");
    let receipt = |disposition| {
        candidate
            .receipts
            .iter()
            .find(|row| row.disposition == disposition)
            .expect("required split receipt")
    };
    let infiltration = receipt(DirectSurfaceLiquidReceiptDisposition::Infiltration);
    let retained = receipt(DirectSurfaceLiquidReceiptDisposition::RetainedSurface);
    let runoff = receipt(DirectSurfaceLiquidReceiptDisposition::OutletRunoff);
    assert!(
        (infiltration.mass_kg_m2_basis_ofe_ground - 0.03).abs() <= 8.0 * f64::EPSILON,
        "fixture must exercise I≈0.03 kg/m²"
    );
    let parent_q = candidate.closure_operands.source_parcels()[0].enthalpy_j_m2_basis_ofe_ground();
    let excess_q = retained.enthalpy_j_m2_basis_ofe_ground + runoff.enthalpy_j_m2_basis_ofe_ground;
    assert_eq!(
        excess_q.to_bits(),
        (parent_q - infiltration.enthalpy_j_m2_basis_ofe_ground).to_bits(),
        "retention + runoff must exactly reconstruct excess Q"
    );
    assert_eq!(
        (infiltration.enthalpy_j_m2_basis_ofe_ground + excess_q).to_bits(),
        parent_q.to_bits(),
        "infiltration + excess must exactly reconstruct parent Q"
    );

    let mut poison = candidate.clone();
    let poisoned = poison
        .receipts
        .iter_mut()
        .find(|row| row.disposition == DirectSurfaceLiquidReceiptDisposition::OutletRunoff)
        .expect("canonical-last runoff receipt");
    poisoned.enthalpy_j_m2_basis_ofe_ground =
        f64::from_bits(poisoned.enthalpy_j_m2_basis_ofe_ground.to_bits() - 1);
    let error = super::super::surface_liquid_closure::validate_surface_liquid_closure_operands(
        &configuration,
        &resource,
        &poison.closure_operands,
        &poison.receipts,
        &poison.ending_state,
    )
    .expect_err("one-ULP canonical-last energy loss must fail exact closure");
    assert_eq!(error.code(), DirectSurfaceLiquidErrorCode::E010);
}
