//! Expected-red M1 physical-column and real-receiver tests.
//!
//! The planned evaluator is public in the LSE crate; this wrapper test owns the
//! authenticated hydrology fixture and never supplies a test-only evaluator.

use super::{
    LandSurfaceEnergyRealHydrologyAdapter, M1CallerState, M1CallerSupportResult,
    M1PreparedCallerContext, M1PrescribedRoutingControl, M1ReceiverDiagnosticResult,
    M1ReceiverFailureInjection, V8RollbackSnapshot, advance_m1_caller_support, endpoint_fixture,
    execute_m1_cold_canopy_receiver_diagnostic,
    execute_m1_cold_canopy_receiver_from_prepared_context,
    execute_native_m1_receiver_from_current_owners,
};
use openwepp_kernel_contract::ResourceOwnerId;
use openwepp_land_surface_energy::{
    BandDirectionalFluxes, CoveredColumnAuthority, CoveredColumnInputs, LandSurfaceEnergyError,
    M1ColumnLiquidRoutingInput, M1ColumnTopologyBinding, M1CoupledColumnInput,
    M1CoupledColumnTrial, M1CoupledError, M1CoupledEvaluation, M1OccupancySupportCondition,
    M1PhaseReservoirInput, M1RoutingOccupancyInput, M1SupportConditions, NativeSnowExchangeV1,
    Sha256Digest, evaluate_m1_coupled_column, route_m1_column_liquid, solve_m1_coupled_column,
};
use serde_json::Value;
use std::collections::{BTreeMap, BTreeSet};

const RADIATION: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/radiation-reference-m1.json"
));
const GAS: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/dark-gas-reference-m1.json"
));
const ROUTING: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/reference-controls-m1.json"
));
const ORIGINAL: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/original-input-reference.json"
));

fn decimal(value: &Value) -> f64 {
    value.as_str().expect("decimal").parse().expect("valid")
}
fn assert_gas_reference(actual: f64, expected: &Value, gas: &Value, quantity: &str) {
    let expected = decimal(expected);
    let tolerance = &gas["comparisons"][quantity];
    assert!(actual.is_finite());
    assert!(
        (actual - expected).abs()
            <= decimal(&tolerance["absolute"])
                .max(decimal(&tolerance["relative"]) * expected.abs())
    );
}

fn vulnerability(psi_mm: f64, p50_mm: f64, exponent: f64) -> f64 {
    (-std::f64::consts::LN_2 * (psi_mm / p50_mm).powf(exponent)).exp()
}

fn independently_reconstruct_hydraulics(
    actual: &M1CoupledEvaluation,
    row: &Value,
    original: &Value,
    gas: &Value,
) {
    let occupancy = actual
        .occupancy(row["occupancy_id"].as_str().expect("occupancy"))
        .expect("known frozen occupancy");
    let source = covered_input(original)
        .occupancies
        .into_iter()
        .find(|item| item.occupancy_id == row["occupancy_id"].as_str().expect("occupancy"))
        .expect("original occupancy coefficients");
    let p = &occupancy.hydraulics.potentials_mm;
    let sun_flux = occupancy.sun.vapor_kg_m2_tile_s;
    let shade_flux = occupancy.shade.vapor_kg_m2_tile_s;
    let ksun = source.k1_sun_max_s1
        * source.sun.leaf_area_m2_m2_tile
        * vulnerability(p[2], source.p50_xylem_mm, source.vulnerability_exponent);
    let kshade = source.k1_shade_max_s1
        * source.shade.leaf_area_m2_m2_tile
        * vulnerability(p[2], source.p50_xylem_mm, source.vulnerability_exponent);
    let qsun = ksun * (p[2] - p[0]);
    let qshade = kshade * (p[2] - p[1]);
    assert_gas_reference(
        qsun,
        &Value::String(format!("{sun_flux}")),
        gas,
        "water_flux_kg_m2_tile_s",
    );
    assert_gas_reference(
        qshade,
        &Value::String(format!("{shade_flux}")),
        gas,
        "water_flux_kg_m2_tile_s",
    );
    let stem_k = source.k2_max / source.height_m
        * vulnerability(p[3], source.p50_xylem_mm, source.vulnerability_exponent)
        * source.sai;
    let qstem = stem_k * (p[3] - p[2] - 1000.0 * source.height_m);
    assert_gas_reference(qstem, &row["stem_flux"], gas, "water_flux_kg_m2_tile_s");
    let mut qroot_sum = 0.0;
    for (layer, expected) in source
        .root_layers
        .iter()
        .filter(|layer| layer.accessible && !layer.frozen && layer.root_fraction > 0.0)
        .zip(row["root_fluxes"].as_array().expect("root flows"))
    {
        let kr = source.k3_max_m_s / layer.z3_m
            * vulnerability(
                layer.soil_potential_mm,
                source.p50_root_mm,
                source.vulnerability_exponent,
            );
        let ks = layer.ksoil_m2_s / layer.dxroot_m;
        let coefficient = kr * ks / (kr + ks)
            * (source.lai + source.sai)
            * layer.root_fraction
            * source.root_to_leaf_area;
        let qroot = coefficient * (layer.soil_potential_mm - p[3] + layer.gravity_head_mm);
        qroot_sum += qroot;
        assert_gas_reference(qroot, expected, gas, "water_flux_kg_m2_tile_s");
    }
    let continuity = [
        qsun - sun_flux,
        qshade - shade_flux,
        qsun + qshade - qstem,
        qstem - qroot_sum,
    ];
    let expected = row["continuity_residuals"]
        .as_array()
        .expect("four frozen continuity residuals");
    assert_eq!(continuity.len(), expected.len());
    for (actual, expected) in continuity.iter().zip(expected) {
        assert_gas_reference(*actual, expected, gas, "continuity_residual_kg_m2_tile_s");
    }
}

// Fieldwise test-side source operands: production evaluation takes this and a
// trial vector, not an oracle JSON object or an expected residual callback.
pub(super) fn provider_covered_input() -> CoveredColumnInputs {
    let original: Value = serde_json::from_str(ORIGINAL).expect("retained original M1 input");
    serde_json::from_value(original["inputs"].clone()).expect("retained CoveredColumnInputs")
}
fn covered_input(original: &Value) -> CoveredColumnInputs {
    serde_json::from_value(original["inputs"].clone()).expect("original CoveredColumnInputs")
}
pub(super) fn provider_conditions() -> M1SupportConditions {
    M1SupportConditions {
        model_definition_id: "OPENWEPP_C3_WOODY_COLD_M1_V1".to_owned(),
        occupancy_conditions: vec![
            M1OccupancySupportCondition {
                occupancy_id: "stratum-z-upper::forest".to_owned(),
                liquid_conducting: true,
                full_supply: true,
            },
            M1OccupancySupportCondition {
                occupancy_id: "stratum-a-lower::forest".to_owned(),
                liquid_conducting: true,
                full_supply: true,
            },
        ],
    }
}
fn conditions() -> M1SupportConditions {
    provider_conditions()
}

pub(super) fn provider_topology_binding() -> M1ColumnTopologyBinding {
    M1ColumnTopologyBinding {
        occupancy_ids: [
            "stratum-z-upper::forest".to_owned(),
            "stratum-a-lower::forest".to_owned(),
        ],
        soil_layer_ids: [
            "thermal-1".to_owned(),
            "thermal-2".to_owned(),
            "soil-1".to_owned(),
            "soil-2".to_owned(),
            "soil-dry".to_owned(),
            "soil-frozen".to_owned(),
        ],
    }
}
fn topology_binding() -> M1ColumnTopologyBinding {
    provider_topology_binding()
}

fn raw_column_input(
    column: CoveredColumnInputs,
    support: M1SupportConditions,
) -> M1CoupledColumnInput {
    M1CoupledColumnInput::from_covered_column(
        column,
        [
            M1PhaseReservoirInput::new("stratum-z-upper::forest", 0.018, 0.0),
            M1PhaseReservoirInput::new("stratum-a-lower::forest", 0.018, 0.0),
        ],
        support,
        topology_binding(),
    )
}

fn assert_m1_diagnostic_envelope(error: M1CoupledError) {
    assert_eq!(error.code(), "LSEB-E-030");
    assert_eq!(
        error,
        M1CoupledError::LandSurfaceEnergy(LandSurfaceEnergyError::UnsupportedDomain(
            "m1_diagnostic_envelope"
        ))
    );
}

fn native_exchange_presence_poison(column: &CoveredColumnInputs) -> NativeSnowExchangeV1 {
    let optical = column
        .stage3_optical
        .as_ref()
        .expect("actual optical receipt");
    let mut exchange = NativeSnowExchangeV1 {
        policy_id: 14,
        ofe_id: optical.ofe_id.clone(),
        tile_id: optical.tile_id.clone(),
        start_ns: 0,
        end_ns: 60_000_000_000,
        snow_temperature_k: 265.15,
        snow_saturation_specific_humidity: 0.003,
        pressure_pa: column.pressure_pa,
        heat_conductance_m_s: 0.025,
        vapor_conductance_m_s: 0.02,
        forcing_sha256: Sha256Digest::try_new("aa".repeat(32)).expect("typed forcing digest"),
        exposure_sha256: Sha256Digest::try_new("bb".repeat(32)).expect("typed exposure digest"),
        payload_sha256: Sha256Digest::try_new("cc".repeat(32)).expect("typed payload digest"),
    };
    exchange.payload_sha256 = exchange
        .reconstructed_sha256()
        .expect("actual native exchange seal");
    exchange
}

#[test]
fn m1_diagnostic_envelope_binds_actual_topology_and_rejects_structural_poison_first() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input");
    let binding = topology_binding();
    assert_eq!(
        binding.occupancy_ids,
        [
            "stratum-z-upper::forest".to_owned(),
            "stratum-a-lower::forest".to_owned(),
        ]
    );
    assert_eq!(
        binding.soil_layer_ids,
        [
            "thermal-1".to_owned(),
            "thermal-2".to_owned(),
            "soil-1".to_owned(),
            "soil-2".to_owned(),
            "soil-dry".to_owned(),
            "soil-frozen".to_owned(),
        ]
    );

    let mut wrong_occupancy_count = covered_input(&original);
    wrong_occupancy_count.occupancies.pop();
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(
            &raw_column_input(wrong_occupancy_count, conditions()),
            &trial(),
        )
        .expect_err("one occupancy is outside the M1 diagnostic envelope"),
    );

    let mut wrong_occupancy_order = covered_input(&original);
    wrong_occupancy_order.occupancies.swap(0, 1);
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(
            &raw_column_input(wrong_occupancy_order, conditions()),
            &trial(),
        )
        .expect_err("occupancy order is outside the M1 diagnostic envelope"),
    );

    let mut wrong_occupancy_identity = covered_input(&original);
    wrong_occupancy_identity.occupancies[1].occupancy_id = "wrong-occupancy".to_owned();
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(
            &raw_column_input(wrong_occupancy_identity, conditions()),
            &trial(),
        )
        .expect_err("occupancy identity is outside the M1 diagnostic envelope"),
    );

    let mut wrong_soil_count = covered_input(&original);
    wrong_soil_count.ground.soil_nodes.pop();
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(&raw_column_input(wrong_soil_count, conditions()), &trial())
            .expect_err("five soil nodes are outside the M1 diagnostic envelope"),
    );

    let mut wrong_soil_identity = covered_input(&original);
    wrong_soil_identity.ground.soil_nodes[5].layer_id = "wrong-soil".to_owned();
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(
            &raw_column_input(wrong_soil_identity, conditions()),
            &trial(),
        )
        .expect_err("soil identity is outside the M1 diagnostic envelope"),
    );

    let mut wrong_soil_order = covered_input(&original);
    wrong_soil_order.ground.soil_nodes.swap(0, 1);
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(&raw_column_input(wrong_soil_order, conditions()), &trial())
            .expect_err("soil order is outside the M1 diagnostic envelope"),
    );

    let mut wrong_boundary_mode = covered_input(&original);
    wrong_boundary_mode.authority = CoveredColumnAuthority::HistoricalV8;
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(
            &raw_column_input(wrong_boundary_mode, conditions()),
            &trial(),
        )
        .expect_err("historical lower-boundary mode is outside the M1 diagnostic envelope"),
    );

    let mut native_exchange_present = covered_input(&original);
    let native_exchange = native_exchange_presence_poison(&native_exchange_present);
    native_exchange_present
        .stage3_lower_boundary
        .as_mut()
        .expect("actual V11 lower boundary")
        .native_snow_exchange = Some(native_exchange);
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(
            &raw_column_input(native_exchange_present, conditions()),
            &trial(),
        )
        .expect_err("native exchange presence is outside the M1 diagnostic envelope"),
    );

    let mut structural_before_pressure = covered_input(&original);
    structural_before_pressure.occupancies.pop();
    structural_before_pressure.pressure_pa = f64::NAN;
    assert_m1_diagnostic_envelope(
        evaluate_m1_coupled_column(
            &raw_column_input(structural_before_pressure, conditions()),
            &trial(),
        )
        .expect_err("structural envelope precedes invalid pressure"),
    );

    let mut missing_condition_key = conditions();
    missing_condition_key.occupancy_conditions.pop();
    let error = evaluate_m1_coupled_column(
        &raw_column_input(covered_input(&original), missing_condition_key),
        &trial(),
    )
    .expect_err("valid topology with missing condition key remains VEG-E-140");
    assert_eq!(error.code(), "VEG-E-140");
}

#[test]
fn m1_positive_top_liquid_requires_explicit_finite_nonnegative_enthalpy() {
    let radiation: Value = serde_json::from_str(RADIATION).expect("radiation");
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input");
    let positive_top_rain = |top_liquid_specific_enthalpy_j_kg: Option<f64>| {
        let input = radiation_input_with_conditions_and_top_rain(
            &radiation,
            &original,
            conditions(),
            decimal(&radiation["inputs"]["p"]),
            0.001,
        );
        match top_liquid_specific_enthalpy_j_kg {
            Some(value) => input.with_top_liquid_specific_enthalpy(value),
            None => input,
        }
    };

    for top_liquid_specific_enthalpy_j_kg in [None, Some(-1.0), Some(f64::NAN), Some(f64::INFINITY)]
    {
        let error = evaluate_m1_coupled_column(
            &positive_top_rain(top_liquid_specific_enthalpy_j_kg),
            &trial(),
        )
        .expect_err("positive top liquid without a finite nonnegative enthalpy is rejected");
        assert_eq!(error.code(), "VEG-E-142");
    }

    let evaluation = evaluate_m1_coupled_column(&positive_top_rain(Some(0.0)), &trial())
        .expect("explicit zero-enthalpy liquid input is admitted");
    assert_eq!(
        evaluation.reservoir_operands()[0].incident_enthalpy_j_kg,
        0.0
    );
}
fn radiation_input_with_conditions_and_top_rain(
    root: &Value,
    original: &Value,
    support: M1SupportConditions,
    pressure_pa: f64,
    top_rain_kg_m2_tile: f64,
) -> M1CoupledColumnInput {
    let x = &root["inputs"];
    let mut column = covered_input(original);
    column.pressure_pa = pressure_pa;
    column.air_temperature_k = decimal(&x["tcan"]);
    column.air_specific_humidity_kg_kg = decimal(&x["qcan"]);
    column.interval_s = decimal(&x["dt"]);
    column.top_rain_kg_m2_tile = top_rain_kg_m2_tile;
    column.atmospheric_downward_longwave_w_m2 = decimal(&x["lw_down"]);
    column.ground.air_pressure_pa = column.pressure_pa;
    column.ground.air_temperature_k = column.air_temperature_k;
    column.ground.air_specific_humidity_kg_kg = column.air_specific_humidity_kg_kg;
    column.ground.atmospheric_downward_longwave_w_m2 = column.atmospheric_downward_longwave_w_m2;
    for (index, occupancy) in column.occupancies.iter_mut().enumerate() {
        occupancy.sun.vcmax25 = occupancy.shade.vcmax25;
        occupancy.sun.jmax25 = occupancy.shade.jmax25;
        occupancy.sun.rd25 = occupancy.shade.rd25;
        occupancy.sun.leaf_area_m2_m2_tile = decimal(&x["sun_area"][index]);
        occupancy.shade.leaf_area_m2_m2_tile = decimal(&x["shade_area"][index]);
        occupancy.stem_area_m2_m2_tile = decimal(&x["stem_area"][index]);
        occupancy.lai = occupancy.sun.leaf_area_m2_m2_tile + occupancy.shade.leaf_area_m2_m2_tile;
        occupancy.sai = occupancy.stem_area_m2_m2_tile;
        occupancy.clumping_index = decimal(&x["clumping"][index]);
        occupancy.gb_wet_m_s = decimal(&x["gb"][index]);
        occupancy.liquid_capacity_kg_m2_plant =
            decimal(&x["capacity"][index]) / decimal(&x["plant_area"][index]);
        let sw = decimal(&x["shortwave_total"][index]);
        occupancy.sun.absorbed_shortwave_w_m2_tile = sw;
        occupancy.sun.absorbed_par_w_m2_leaf = 0.0;
        occupancy.shade.absorbed_shortwave_w_m2_tile = 0.0;
        occupancy.shade.absorbed_par_w_m2_leaf = 0.0;
        occupancy.stem_absorbed_shortwave_w_m2_tile = 0.0;
        let receipt = column
            .shortwave
            .occupancies
            .iter_mut()
            .find(|receipt| receipt.occupancy_id == occupancy.occupancy_id)
            .expect("shortwave identity");
        receipt.sun_leaf_absorbed_w_m2_tile = BandDirectionalFluxes {
            direct_nir: sw,
            ..BandDirectionalFluxes::default()
        };
        receipt.shade_leaf_absorbed_w_m2_tile = BandDirectionalFluxes::default();
        receipt.stem_absorbed_w_m2_tile = BandDirectionalFluxes::default();
    }
    // The explicit two occupancy NIR absorption is the whole prescribed
    // incident shortwave control: 14 + 9 W m-2, no reflected or ground term.
    column.shortwave.incident_w_m2_tile = BandDirectionalFluxes {
        direct_nir: decimal(&x["shortwave_total"][0]) + decimal(&x["shortwave_total"][1]),
        ..BandDirectionalFluxes::default()
    };
    column.shortwave.top_reflected_w_m2_tile = BandDirectionalFluxes::default();
    column.shortwave.ground_absorbed_by_incident_w_m2_tile = BandDirectionalFluxes::default();
    M1CoupledColumnInput::from_covered_column(
        column,
        [
            M1PhaseReservoirInput::new(
                "stratum-z-upper::forest",
                decimal(&x["state"][0]),
                decimal(&x["state"][1]),
            ),
            M1PhaseReservoirInput::new(
                "stratum-a-lower::forest",
                decimal(&x["state"][2]),
                decimal(&x["state"][3]),
            ),
        ],
        support,
        topology_binding(),
    )
}
fn radiation_input_with_conditions(
    root: &Value,
    original: &Value,
    support: M1SupportConditions,
    pressure_pa: f64,
) -> M1CoupledColumnInput {
    radiation_input_with_conditions_and_top_rain(root, original, support, pressure_pa, 0.0)
}
fn radiation_input(root: &Value, original: &Value) -> M1CoupledColumnInput {
    radiation_input_with_conditions(root, original, conditions(), decimal(&root["inputs"]["p"]))
}
fn trial() -> M1CoupledColumnTrial {
    M1CoupledColumnTrial::from_coordinates([
        267., 266., 268., 0.018, -6385.68, 0., 269., 267., 270., 0.023, -7917.29, 0., 268., 0.0015,
        265.15, 291.5, 289.8, 293., 293., 293., 270.,
    ])
}
fn gas_probe_input(
    _root: &Value,
    row: &Value,
    original: &Value,
) -> (M1CoupledColumnInput, M1CoupledColumnTrial) {
    let mut column = covered_input(original);
    column.pressure_pa = 90_000.0;
    column.air_temperature_k = 268.0;
    column.air_specific_humidity_kg_kg = 0.0015;
    column.ground.air_pressure_pa = column.pressure_pa;
    column.ground.air_temperature_k = column.air_temperature_k;
    column.ground.air_specific_humidity_kg_kg = column.air_specific_humidity_kg_kg;
    column.ground.atmospheric_downward_longwave_w_m2 = column.atmospheric_downward_longwave_w_m2;
    let mut masses = [0.0; 2];
    for (index, occupancy) in column.occupancies.iter_mut().enumerate() {
        occupancy.sun.leaf_area_m2_m2_tile = 0.0;
        occupancy.shade.leaf_area_m2_m2_tile = 1.0;
        occupancy.lai = 1.0;
        let capacity = occupancy.liquid_capacity_kg_m2_plant * (occupancy.lai + occupancy.sai);
        masses[index] = capacity * 0.25_f64.powf(1.5);
        occupancy.beginning_canopy_liquid_kg_m2_tile = masses[index];
    }
    let input = M1CoupledColumnInput::from_covered_column(
        column,
        [
            M1PhaseReservoirInput::new("stratum-z-upper::forest", masses[0], 0.0),
            M1PhaseReservoirInput::new("stratum-a-lower::forest", masses[1], 0.0),
        ],
        conditions(),
        topology_binding(),
    );
    let temperature = decimal(&row["leaf_temperature_k"]);
    let row_trial = M1CoupledColumnTrial::from_coordinates([
        temperature,
        temperature,
        temperature,
        masses[0],
        0.0,
        0.0,
        temperature,
        temperature,
        temperature,
        masses[1],
        0.0,
        0.0,
        268.0,
        0.0015,
        265.15,
        291.5,
        289.8,
        293.0,
        293.0,
        293.0,
        270.0,
    ]);
    (input, row_trial)
}
fn independently_reconstruct_reservoirs(value: &M1CoupledEvaluation, must_close: bool) {
    for o in value.reservoir_operands() {
        let rm = o.ending_mass_kg_m2
            - o.beginning_mass_kg_m2
            - o.dt_s * (o.incident_liquid_kg_m2_s - o.vapor_kg_m2_s - o.drainage_kg_m2_s);
        let t = o.wet_temperature_k.expect("nonempty reservoir");
        let rh = o.ending_enthalpy_j_m2
            - o.beginning_enthalpy_j_m2
            - o.dt_s
                * (o.non_vapor_heat_w_m2 + o.incident_liquid_kg_m2_s * o.incident_enthalpy_j_kg
                    - o.vapor_kg_m2_s * (2_501_000. + 1_849. * (t - 273.15))
                    - o.drainage_kg_m2_s * 4_218. * (t - 273.15));
        assert!((rm - o.mass_residual_kg_m2).abs() <= 1e-12);
        assert!((rh - o.enthalpy_residual_j_m2).abs() <= 1e-9);
        if must_close {
            assert!(rm.abs() <= 1e-9 && rh.abs() <= 1e-6);
        }
        assert!(
            o.diagnosed_liquid_mass_kg_m2 >= 0.
                && o.diagnosed_liquid_mass_kg_m2 <= o.liquid_capacity_kg_m2
        );
    }
}

#[test]
fn m1_prescribed_twenty_one_coordinate_physical_evaluator_has_all_fd_columns() {
    let root: Value = serde_json::from_str(RADIATION).expect("radiation");
    let original: Value = serde_json::from_str(ORIGINAL).expect("original");
    let input = radiation_input(&root, &original);
    let trial = trial();
    let base = evaluate_m1_coupled_column(&input, &trial).expect("actual evaluator");
    assert_eq!(base.residuals().len(), 21);
    let jacobian = base.jacobian().expect("diagnostic Jacobian");
    assert!(jacobian.iter().all(|row| row.len() == 21));
    for coordinate in 0..21 {
        let h = match coordinate {
            3 | 9 => 1e-8,
            4 | 10 => 1e-3,
            5 | 11 => 1e-10,
            13 => 1e-8,
            _ => 1e-4,
        };
        let high = evaluate_m1_coupled_column(
            &input,
            &trial
                .with_coordinate_offset(coordinate, h)
                .expect("known valid high probe"),
        )
        .expect("inward/high probe");
        let fd = if matches!(coordinate, 5 | 11) {
            high.residuals()
                .iter()
                .zip(base.residuals())
                .map(|(a, b)| (a - b) / h)
                .collect::<Vec<_>>()
        } else {
            let low = evaluate_m1_coupled_column(
                &input,
                &trial
                    .with_coordinate_offset(coordinate, -h)
                    .expect("known valid low probe"),
            )
            .expect("low probe");
            high.residuals()
                .iter()
                .zip(low.residuals())
                .map(|(a, b)| (a - b) / (2. * h))
                .collect::<Vec<_>>()
        };
        assert_eq!(fd.len(), 21);
        let column = base
            .jacobian_column(coordinate)
            .expect("known valid Jacobian column");
        assert_eq!(column.len(), 21);
        for (actual, analytic) in fd.iter().zip(column) {
            assert!(actual.is_finite() && analytic.is_finite());
            assert!((actual - analytic).abs() <= 1e-6 * actual.abs().max(1.));
        }
    }
    independently_reconstruct_reservoirs(&base, false);
}

#[test]
fn m1_frozen_radiation_columns_and_all_four_gas_rows_bind_physical_outputs() {
    let radiation: Value = serde_json::from_str(RADIATION).expect("radiation");
    let original: Value = serde_json::from_str(ORIGINAL).expect("original");
    let base = evaluate_m1_coupled_column(&radiation_input(&radiation, &original), &trial())
        .expect("evaluation");
    let jacobian = base.jacobian().expect("diagnostic Jacobian");
    assert_eq!(base.residuals().len(), 21);
    assert_eq!(jacobian.len(), 21);
    assert_eq!(base.reservoir_operands().len(), 2);
    for (index, operand) in base.reservoir_operands().iter().enumerate() {
        let expected = &radiation["expected"];
        assert!(
            (operand.wet_temperature_k.expect("nonempty reservoir")
                - decimal(&expected["temperature"][index]))
            .abs()
                <= 1e-9
        );
        assert!(
            (operand.non_vapor_heat_w_m2 - decimal(&expected["q_nonvapor"][index])).abs() <= 1e-6
        );
        assert!((operand.vapor_kg_m2_s - decimal(&expected["e"][index])).abs() <= 1e-12);
        assert!((operand.wet_fraction - decimal(&expected["wet_fraction"][index])).abs() <= 1e-12);
        assert!((operand.emission_w_m2 - decimal(&expected["emission"][index])).abs() <= 1e-9);
        assert!(
            (operand.wet_longwave_w_m2 - decimal(&expected["wet_longwave"][index])).abs() <= 1e-9
        );
        assert!(
            (operand.wet_sensible_w_m2 - decimal(&expected["wet_sensible"][index])).abs() <= 1e-9
        );
        assert!(
            (base.residuals()[6 * index + 3] - decimal(&expected["residual"][2 * index])).abs()
                <= 1e-9
        );
        assert!(
            (base.residuals()[6 * index + 4] - decimal(&expected["residual"][2 * index + 1])).abs()
                <= 1e-6
        );
    }
    for column in radiation["columns"].as_array().expect("four columns") {
        let index = match column["coordinate"].as_str().expect("coordinate") {
            "upper_M" => 3,
            "upper_H" => 4,
            "lower_M" => 9,
            "lower_H" => 10,
            _ => unreachable!(),
        };
        for (actual, expected) in [3, 4, 9, 10]
            .iter()
            .zip(column["residual"].as_array().expect("rows"))
        {
            let actual = jacobian[*actual][index];
            assert!((actual - decimal(expected)).abs() <= 1e-6 * decimal(expected).abs().max(1.));
        }
    }
    // Independent central probes bind each reservoir M/H sensitivity of the
    // exposed ordinary non-vapor heat operands, rather than a fixture-only
    // derivative API.
    for column in radiation["columns"].as_array().expect("four columns") {
        let coordinate = match column["coordinate"].as_str().expect("coordinate") {
            "upper_M" => 3,
            "upper_H" => 4,
            "lower_M" => 9,
            "lower_H" => 10,
            _ => unreachable!(),
        };
        let step = decimal(&column["step"]);
        let high = evaluate_m1_coupled_column(
            &radiation_input(&radiation, &original),
            &trial()
                .with_coordinate_offset(coordinate, step)
                .expect("known valid high probe"),
        )
        .expect("high heat probe");
        let low = evaluate_m1_coupled_column(
            &radiation_input(&radiation, &original),
            &trial()
                .with_coordinate_offset(coordinate, -step)
                .expect("known valid low probe"),
        )
        .expect("low heat probe");
        for index in 0..2 {
            let fd = (high.reservoir_operands()[index].non_vapor_heat_w_m2
                - low.reservoir_operands()[index].non_vapor_heat_w_m2)
                / (2.0 * step);
            assert!((fd - decimal(&column["q_nonvapor"][index])).abs() <= 1e-6 * fd.abs().max(1.0));
        }
    }
    let gas: Value = serde_json::from_str(GAS).expect("gas");
    assert_eq!(gas["rows"].as_array().expect("four gas controls").len(), 4);
    for row in gas["rows"].as_array().expect("rows") {
        let (gas_input, gas_trial) = gas_probe_input(&gas, row, &original);
        let gas_evaluation =
            evaluate_m1_coupled_column(&gas_input, &gas_trial).expect("frozen gas row");
        let actual = gas_evaluation
            .occupancy(row["occupancy_id"].as_str().expect("occupancy"))
            .expect("known frozen occupancy");
        let sun = &row["leaves"][0];
        let shade = &row["leaves"][1];
        assert_eq!(
            actual.sun.gas_branch,
            sun["gas_branch"].as_str().expect("sun branch")
        );
        assert_eq!(
            actual.shade.gas_branch,
            shade["gas_branch"].as_str().expect("shade branch")
        );
        assert_eq!(actual.sun.beta, decimal(&sun["beta"]));
        assert_eq!(actual.shade.beta, decimal(&shade["beta"]));
        assert_gas_reference(
            actual.shade.internal_specific_humidity_kg_kg,
            &row["internal_liquid_qsat"],
            &gas,
            "specific_humidity",
        );
        assert_gas_reference(
            actual.shade.dark_respiration,
            &shade["rd"],
            &gas,
            "respiration_assimilation",
        );
        assert_gas_reference(
            actual.shade.net_assimilation,
            &shade["an"],
            &gas,
            "respiration_assimilation",
        );
        assert_gas_reference(
            actual.shade.gross_assimilation,
            &shade["ag"],
            &gas,
            "respiration_assimilation",
        );
        assert_gas_reference(
            actual.shade.conductance_m_s,
            &shade["gs_m_s"],
            &gas,
            "conductance_m_s",
        );
        assert_gas_reference(actual.shade.ci_pa, &shade["ci_pa"], &gas, "ci_pa");
        assert_gas_reference(
            actual.shade.vapor_kg_m2_tile_s,
            &shade["vapor_kg_m2_tile_s"],
            &gas,
            "water_flux_kg_m2_tile_s",
        );
        assert_eq!(actual.sun.vapor_kg_m2_tile_s, 0.0);
        assert_eq!(actual.sun.net_assimilation, 0.0);
        assert_gas_reference(
            actual.hydraulics.stem_flux_kg_m2_tile_s,
            &row["stem_flux"],
            &gas,
            "water_flux_kg_m2_tile_s",
        );
        assert_gas_reference(
            actual.hydraulics.total_leaf_demand_kg_m2_tile_s,
            &row["total_leaf_demand"],
            &gas,
            "water_flux_kg_m2_tile_s",
        );
        assert_eq!(actual.hydraulics.potentials_mm.len(), 4);
        for (a, e) in actual
            .hydraulics
            .potentials_mm
            .iter()
            .zip(row["potentials_mm"].as_array().expect("potentials"))
        {
            assert_gas_reference(*a, e, &gas, "hydraulic_potential_mm");
        }
        assert_eq!(
            actual.hydraulics.root_layer_ids,
            row["root_layer_ids"]
                .as_array()
                .expect("layer order")
                .iter()
                .map(|value| value.as_str().expect("layer").to_owned())
                .collect::<Vec<_>>()
        );
        assert_eq!(
            actual.hydraulics.root_fluxes_kg_m2_tile_s.len(),
            row["root_fluxes"].as_array().expect("root flows").len()
        );
        for (actual_flow, expected_flow) in actual
            .hydraulics
            .root_fluxes_kg_m2_tile_s
            .iter()
            .zip(row["root_fluxes"].as_array().expect("root flows"))
        {
            assert_gas_reference(*actual_flow, expected_flow, &gas, "water_flux_kg_m2_tile_s");
        }
        independently_reconstruct_hydraulics(&gas_evaluation, row, &original, &gas);
        assert_eq!(actual.hydraulics.continuity_residuals_kg_m2_tile_s.len(), 4);
        for (actual_residual, expected_residual) in actual
            .hydraulics
            .continuity_residuals_kg_m2_tile_s
            .iter()
            .zip(row["continuity_residuals"].as_array().expect("continuity"))
        {
            assert_gas_reference(
                *actual_residual,
                expected_residual,
                &gas,
                "continuity_residual_kg_m2_tile_s",
            );
        }
    }
}

#[test]
fn m1_original_sixty_second_solve_has_original_geometry_active_cold_shade_and_real_closure() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input");
    let solved = solve_m1_coupled_column(&M1CoupledColumnInput::from_covered_column(
        covered_input(&original),
        [
            M1PhaseReservoirInput::new("stratum-z-upper::forest", 0.018, 0.0),
            M1PhaseReservoirInput::new("stratum-a-lower::forest", 0.018, 0.0),
        ],
        conditions(),
        topology_binding(),
    ))
    .expect("actual solve");
    assert_eq!(solved.support_duration_s(), 60.);
    assert!(
        solved
            .occupancies()
            .iter()
            .all(|o| o.shade.gas_branch == "ExactZeroPar"
                && o.shade.net_assimilation < 0.
                && o.shade.vapor_kg_m2_tile_s > 0.)
    );
    for operand in solved.reservoir_operands() {
        assert_eq!(operand.beginning_mass_kg_m2, 0.018);
        assert_eq!(operand.beginning_enthalpy_j_m2, 0.0);
        assert!(operand.ending_mass_kg_m2.is_finite() && operand.ending_enthalpy_j_m2.is_finite());
        assert!(operand.vapor_kg_m2_s != 0.0 && operand.non_vapor_heat_w_m2 != 0.0);
        assert!(
            operand.ending_mass_kg_m2 != operand.beginning_mass_kg_m2
                || operand.ending_enthalpy_j_m2 != operand.beginning_enthalpy_j_m2
        );
    }
    independently_reconstruct_reservoirs(&solved, true);
}

fn endpoint_owner_snapshot(fixture: &super::EndpointFixture) -> V8RollbackSnapshot {
    let adapter = LandSurfaceEnergyRealHydrologyAdapter::new(&fixture.hydrology);
    let vegetation_owner_id = ResourceOwnerId::try_new("vegetation-v8").expect("owner");
    let biogeochemistry_owner_id = ResourceOwnerId::try_new("biogeochemistry").expect("owner");
    let pending_owner_id = ResourceOwnerId::try_new("m1-coupled-pending-envelope").expect("owner");
    V8RollbackSnapshot::capture_endpoint_beginning(
        &vegetation_owner_id,
        &fixture.vegetation_state,
        &adapter,
        &fixture.lse_state,
        &fixture.thermal,
        &biogeochemistry_owner_id,
        &fixture.biogeochemistry,
        &pending_owner_id,
        &[],
        &[],
        &[],
    )
    .expect("six actual endpoint-owner bytes")
}

fn prescribed_routing_input() -> M1ColumnLiquidRoutingInput {
    let root: Value = serde_json::from_str(ROUTING).expect("routing reference");
    let routing = &root["routing_control"];
    // This test supplies physical routing operands, never an oracle object or
    // expected terminal answer. The lower entry has no direct incident parcel:
    // its input is the upper release routed by the shared M1 geometry routine.
    M1ColumnLiquidRoutingInput::new(
        M1RoutingOccupancyInput {
            occupancy_id: "stratum-z-upper::forest".to_owned(),
            plant_area_m2_m2_tile: decimal(&routing["upper_plant_area"]),
            incident_mass_kg_m2_tile: decimal(&routing["top_input_mass"]),
            incident_enthalpy_j_kg: decimal(&routing["top_input_h"]),
            interception_fraction: decimal(&routing["interception_fraction"]),
            stemflow_fraction: decimal(&routing["upper_stemflow_fraction"]),
            initial_drainage_mass_kg_m2_tile: decimal(&routing["upper_drainage_mass"]),
            initial_drainage_enthalpy_j_kg: decimal(&routing["upper_drainage_h"]),
            second_drainage_mass_kg_m2_tile: 0.0,
            second_drainage_enthalpy_j_kg: 0.0,
        },
        M1RoutingOccupancyInput {
            occupancy_id: "stratum-a-lower::forest".to_owned(),
            plant_area_m2_m2_tile: decimal(&routing["lower_plant_area"]),
            incident_mass_kg_m2_tile: 0.0,
            incident_enthalpy_j_kg: 0.0,
            interception_fraction: decimal(&routing["interception_fraction"]),
            stemflow_fraction: decimal(&routing["lower_stemflow_fraction"]),
            initial_drainage_mass_kg_m2_tile: decimal(&routing["lower_drainage_mass"]),
            initial_drainage_enthalpy_j_kg: decimal(&routing["lower_drainage_h"]),
            second_drainage_mass_kg_m2_tile: 0.0,
            second_drainage_enthalpy_j_kg: 0.0,
        },
        decimal(&routing["tile_fraction"]),
    )
    .expect("typed M1 routing input")
}

fn prescribed_routing_control() -> M1PrescribedRoutingControl {
    // The orchestrator wrapper receives typed routing operands, while the
    // reusable LSE geometry routine remains the single route used by solve.
    M1PrescribedRoutingControl::new(prescribed_routing_input())
        .expect("typed prescribed routing control")
}

fn assert_raw_receiver_operands(result: &M1ReceiverDiagnosticResult) {
    let candidate = result.actual_candidate();
    let ingress = candidate.surface_ingress();
    assert!(!ingress.receipts().is_empty());
    assert!(!ingress.ledgers().is_empty());
    let receipt_mass: f64 = ingress
        .receipts()
        .iter()
        .map(|receipt| receipt.mass_kg_m2_basis_ofe_ground)
        .sum();
    let receipt_enthalpy: f64 = ingress
        .receipts()
        .iter()
        .map(|receipt| receipt.enthalpy_j_m2_basis_ofe_ground)
        .sum();
    let ledger_mass: f64 = ingress
        .ledgers()
        .iter()
        .map(|ledger| ledger.ingress_mass_kg_m2_ofe_ground)
        .sum();
    let ledger_enthalpy: f64 = ingress
        .ledgers()
        .iter()
        .map(|ledger| ledger.ingress_enthalpy_j_m2_ofe_ground)
        .sum();
    assert!((receipt_mass - ledger_mass).abs() <= 1e-12);
    assert!((receipt_enthalpy - ledger_enthalpy).abs() <= 1e-8);
    let root: Value = serde_json::from_str(ROUTING).expect("routing reference");
    let expected_terminal = root["routing_control"]["terminal"]
        .as_array()
        .expect("terminal");
    let expected_mass: f64 = expected_terminal
        .iter()
        .map(|row| decimal(&row["ofe_mass"]))
        .sum();
    let expected_enthalpy: f64 = expected_terminal
        .iter()
        .map(|row| decimal(&row["ofe_energy"]))
        .sum();
    assert!((ledger_mass - expected_mass).abs() <= 1e-12);
    assert!((ledger_enthalpy - expected_enthalpy).abs() <= 1e-8);
    for ledger in ingress.ledgers() {
        assert!(
            (ledger.ingress_mass_kg_m2_ofe_ground
                - ledger.infiltration_mass_kg_m2_ofe_ground
                - ledger.retained_mass_kg_m2_ofe_ground
                - ledger.runoff_mass_kg_m2_ofe_ground)
                .abs()
                <= 1e-12
        );
        assert!(
            (ledger.ingress_enthalpy_j_m2_ofe_ground
                - ledger.infiltration_enthalpy_j_m2_ofe_ground
                - ledger.retained_enthalpy_j_m2_ofe_ground
                - ledger.runoff_enthalpy_j_m2_ofe_ground)
                .abs()
                <= 1e-8
        );
    }
    let join = result.contribution_join();
    let terminal = root["routing_control"]["terminal"]
        .as_array()
        .expect("terminal");
    assert_eq!(join.contributors().len(), terminal.len());
    let mut unique_contributor_origins = BTreeSet::new();
    let mut contributor_groups = BTreeMap::new();
    for (actual, expected) in join.contributors().iter().zip(terminal) {
        assert_eq!(
            actual.origin(),
            expected["origin"].as_str().expect("origin")
        );
        assert!(unique_contributor_origins.insert(actual.origin().to_owned()));
        assert!(!actual.source_parcel_id().is_empty());
        assert_eq!(actual.transaction_id(), candidate.transaction_id());
        assert_eq!(actual.start_s(), 0.0);
        assert_eq!(actual.end_s(), 60.0);
        assert!(!actual.source_parcel_id().is_empty());
        assert!((actual.tile_mass_kg_m2() - decimal(&expected["mass"])).abs() <= 1e-12);
        assert!((actual.specific_enthalpy_j_kg() - decimal(&expected["h"])).abs() <= 1e-9);
        assert!((actual.ofe_mass_kg_m2_ground() - decimal(&expected["ofe_mass"])).abs() <= 1e-12);
        assert!(
            (actual.ofe_enthalpy_j_m2_ground() - decimal(&expected["ofe_energy"])).abs() <= 1e-8
        );
        assert!(
            (actual.ofe_enthalpy_j_m2_ground()
                - actual.ofe_mass_kg_m2_ground() * actual.specific_enthalpy_j_kg())
            .abs()
                <= 1e-8
        );
        let grouped = contributor_groups
            .entry((actual.source_parcel_id().to_owned(), actual.kind()))
            .or_insert((0.0, 0.0));
        grouped.0 += actual.ofe_mass_kg_m2_ground();
        grouped.1 += actual.ofe_enthalpy_j_m2_ground();
    }
    assert_eq!(unique_contributor_origins.len(), terminal.len());
    let mut unique_raw_receipt_ids = BTreeSet::new();
    let mut receipt_groups = BTreeMap::new();
    for receipt in ingress.receipts() {
        assert!(unique_raw_receipt_ids.insert(receipt.parcel_id.clone()));
        assert!(!receipt.source_parcel_id.is_empty());
        assert_eq!(receipt.transaction_id, candidate.transaction_id());
        assert_eq!(receipt.start_s, 0.0);
        assert_eq!(receipt.end_s, 60.0);
        assert_eq!(receipt.basis_ofe_id, receipt.origin_store_key.ofe_id);
        assert_eq!(receipt.origin_store_key.run_id, 83);
        assert_eq!(receipt.recipient_store_key.run_id, 83);
        assert_eq!(receipt.origin_store_key.ofe_id.as_str(), "ofe-1");
        assert_eq!(receipt.origin_store_key.tile_id.as_str(), "forest");
        assert_eq!(receipt.recipient_store_key.ofe_id.as_str(), "ofe-1");
        assert_eq!(receipt.recipient_store_key.tile_id.as_str(), "forest");
        assert!(receipt.temperature_k.is_finite());
        assert!(
            (receipt.enthalpy_j_m2_basis_ofe_ground
                - receipt.mass_kg_m2_basis_ofe_ground * 4218.0 * (receipt.temperature_k - 273.15))
                .abs()
                <= 1e-8
        );
        match (&receipt.disposition, &receipt.recipient) {
            (
                crate::DirectSurfaceLiquidReceiptDisposition::Infiltration,
                crate::DirectSurfaceLiquidReceiptRecipient::SoilInfiltration { ofe_id, .. },
            ) => assert_eq!(ofe_id, &receipt.basis_ofe_id),
            (
                crate::DirectSurfaceLiquidReceiptDisposition::RetainedSurface,
                crate::DirectSurfaceLiquidReceiptRecipient::SurfaceStore { store_key },
            ) => assert_eq!(store_key, &receipt.recipient_store_key),
            (
                crate::DirectSurfaceLiquidReceiptDisposition::RoutedRunoff,
                crate::DirectSurfaceLiquidReceiptRecipient::RoutedOfe {
                    destination_ofe_id,
                    destination_store_key,
                    ..
                },
            ) => {
                assert_eq!(destination_ofe_id, &receipt.recipient_store_key.ofe_id);
                assert_eq!(destination_store_key, &receipt.recipient_store_key);
            }
            (
                crate::DirectSurfaceLiquidReceiptDisposition::OutletRunoff,
                crate::DirectSurfaceLiquidReceiptRecipient::Outlet { ofe_id },
            ) => assert_eq!(ofe_id, &receipt.recipient_store_key.ofe_id),
            _ => panic!("receipt disposition and actual recipient disagree"),
        }
        let grouped = receipt_groups
            .entry((receipt.source_parcel_id.clone(), receipt.kind))
            .or_insert((0.0, 0.0));
        grouped.0 += receipt.mass_kg_m2_basis_ofe_ground;
        grouped.1 += receipt.enthalpy_j_m2_basis_ofe_ground;
    }
    assert_eq!(contributor_groups.len(), receipt_groups.len());
    for (source_and_branch, expected) in &contributor_groups {
        let actual = receipt_groups
            .get(source_and_branch)
            .expect("every expected contributor is represented by raw receipts");
        assert!((actual.0 - expected.0).abs() <= 1e-12);
        assert!((actual.1 - expected.1).abs() <= 1e-8);
    }
    for source_and_branch in receipt_groups.keys() {
        assert!(
            contributor_groups.contains_key(source_and_branch),
            "raw receipt group has no contributor"
        );
    }
    let operands = candidate.receiver_closure_operands();
    assert!(!operands.production_soil.is_empty());
    assert!(!operands.soil_thermal.is_empty());
    assert!(!operands.lse_tiles.is_empty());
    let infiltration_receipt_m: f64 = ingress
        .ledgers()
        .iter()
        .map(|ledger| ledger.infiltration_mass_kg_m2_ofe_ground / 1_000.0)
        .sum();
    let infiltration_owner_m: f64 = operands
        .production_soil
        .iter()
        .map(|soil| soil.infiltration_m)
        .sum();
    assert!(infiltration_owner_m > 0.0);
    assert!((infiltration_receipt_m - infiltration_owner_m).abs() <= 1e-12);
    for soil in &operands.production_soil {
        let beginning_from_layers: f64 = soil
            .ordered_layers
            .iter()
            .map(|layer| {
                layer.beginning_liquid_m
                    + layer.residual_theta * (layer.layer_depth_m - layer.frozen_depth_m).max(0.0)
            })
            .sum();
        let ending_from_layers: f64 = soil
            .ordered_layers
            .iter()
            .map(|layer| {
                layer.ending_liquid_m
                    + layer.residual_theta * (layer.layer_depth_m - layer.frozen_depth_m).max(0.0)
            })
            .sum();
        assert!((beginning_from_layers - soil.beginning_aggregate_soil_water_m).abs() <= 1e-12);
        assert!((ending_from_layers - soil.ending_aggregate_soil_water_m).abs() <= 1e-12);
        assert!(
            (soil.ending_aggregate_soil_water_m
                - soil.beginning_aggregate_soil_water_m
                - soil.infiltration_m)
                .abs()
                <= 1e-12
        );
    }
    let ledger_infiltration_h: f64 = ingress
        .ledgers()
        .iter()
        .map(|ledger| ledger.infiltration_enthalpy_j_m2_ofe_ground)
        .sum();
    let ledger_retained_h: f64 = ingress
        .ledgers()
        .iter()
        .map(|ledger| ledger.retained_enthalpy_j_m2_ofe_ground)
        .sum();
    assert!(
        (ledger_infiltration_h
            - operands
                .soil_thermal
                .iter()
                .map(|row| row.infiltration_enthalpy_j_m2_ofe_ground)
                .sum::<f64>())
        .abs()
            <= 1e-8
    );
    assert!(
        (ledger_retained_h
            - operands
                .lse_tiles
                .iter()
                .map(|row| row.retained_enthalpy_j_m2_ofe_ground)
                .sum::<f64>())
        .abs()
            <= 1e-8
    );
    for thermal in &operands.soil_thermal {
        assert!(
            (thermal.beginning_enthalpy_j_m2_ofe_ground
                + thermal.infiltration_enthalpy_j_m2_ofe_ground
                - thermal.ending_enthalpy_j_m2_ofe_ground)
                .abs()
                <= 1e-8
        );
    }
    for tile in &operands.lse_tiles {
        assert!(
            (tile.tile_fraction
                * (tile.ending_enthalpy_j_m2_tile_ground
                    - tile.beginning_enthalpy_j_m2_tile_ground)
                - tile.retained_enthalpy_j_m2_ofe_ground)
                .abs()
                <= 1e-8
        );
    }
}

#[test]
fn m1_receiver_uses_prescribed_release_components_and_actual_raw_owners() {
    let mut fixture = endpoint_fixture();
    let before = endpoint_owner_snapshot(&fixture);
    let control = prescribed_routing_control();
    let candidate = execute_m1_cold_canopy_receiver_diagnostic(&mut fixture, &control, None)
        .expect("actual real-hydrology candidate");
    assert_raw_receiver_operands(&candidate);
    let after = endpoint_owner_snapshot(&fixture);
    assert_eq!(before.owners().len(), 6);
    assert_eq!(before.owners(), after.owners());
    before
        .check_snapshot(&after)
        .expect("candidate-only wrapper");
}

#[test]
fn owner_txn_prepared_m1_context_authenticates_plant_area_and_accepted_beginning() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original M1 preparation");
    let input = raw_column_input(covered_input(&original), conditions());
    let evaluation = solve_m1_coupled_column(&input).expect("accepted M1 solve");
    let context = M1PreparedCallerContext::new(input, evaluation).expect("bound M1 preparation");
    let control = prescribed_routing_control();
    let mut fixture = endpoint_fixture();
    let error = execute_m1_cold_canopy_receiver_from_prepared_context(
        &mut fixture,
        &control,
        context.clone(),
        None,
    )
    .expect_err("the actual original60 M1 solve has no terminal liquid release");
    assert_eq!(error.rejection_stage().as_str(), "receiver");
    assert_eq!(error.rejection_reason().as_str(), "wrong_source_branch");

    let before = endpoint_owner_snapshot(&fixture);
    let error = execute_m1_cold_canopy_receiver_from_prepared_context(
        &mut fixture,
        &control,
        context,
        Some(M1ReceiverFailureInjection::WrongPlantArea),
    )
    .expect_err("finite wrong M1 plant area reaches provenance guard");
    assert_eq!(error.rejection_stage().as_str(), "receiver");
    assert_eq!(error.rejection_reason().as_str(), "wrong_area_conversion");
    let after = endpoint_owner_snapshot(&fixture);
    before
        .check_snapshot(&after)
        .expect("area poison is pre-install");
}

#[test]
fn owner_txn_prepared_m1_context_rejects_a_foreign_accepted_input() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original M1 preparation");
    let input = raw_column_input(covered_input(&original), conditions());
    let evaluation = solve_m1_coupled_column(&input).expect("accepted M1 solve");
    let mut foreign = input.clone();
    foreign.top_liquid_specific_enthalpy_j_kg = Some(-4_218.0);
    assert!(M1PreparedCallerContext::new(foreign, evaluation).is_err());
}

#[test]
fn owner_txn_original60_m1_executes_direct_unified_callback_without_v8_runtime() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original M1 preparation");
    let input = raw_column_input(covered_input(&original), conditions());
    let evaluation = solve_m1_coupled_column(&input).expect("accepted M1 solve");
    let prepared = M1PreparedCallerContext::new(input, evaluation).expect("bound M1 preparation");
    let fixture = endpoint_fixture();
    let candidate = execute_native_m1_receiver_from_current_owners(&fixture, &prepared, None)
        .expect("direct M1 unified real-hydrology callback");
    assert_eq!(candidate.transaction_id().0, 41);
    let requested_root: f64 = candidate
        .arbitration()
        .requests
        .iter()
        .filter(|row| {
            row.key.requesting_component
                == openwepp_land_surface_energy::RequestingComponent::VegetationRoot
        })
        .map(|row| row.amount_kg_m2_stand_ground)
        .sum();
    let finalized_root: f64 = candidate
        .finalized_uses()
        .iter()
        .filter(|row| {
            row.key.requesting_component
                == openwepp_land_surface_energy::RequestingComponent::VegetationRoot
        })
        .map(|row| row.amount_kg_m2_stand_ground)
        .sum();
    assert!(requested_root > 0.0);
    assert_eq!(requested_root.to_bits(), finalized_root.to_bits());
    assert_ne!(candidate.beginning_frame(), candidate.ending_frame());
    assert!(candidate.surface_ingress().receipts().is_empty());
}

#[test]
fn owner_txn_original60_stages_native_ending_and_advances_cursor() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original M1 preparation");
    let input = raw_column_input(covered_input(&original), conditions());
    let evaluation = solve_m1_coupled_column(&input).expect("accepted M1 solve");
    let prepared = M1PreparedCallerContext::new(input, evaluation).expect("bound M1 preparation");
    let mut fixture = endpoint_fixture();
    let mut caller = M1CallerState::beginning(&fixture, &prepared).expect("caller beginning");
    let before = caller.ending_frame().clone();
    assert_eq!(
        advance_m1_caller_support(&mut caller, &mut fixture, prepared, 0, None)
            .expect("native M1 caller stage"),
        M1CallerSupportResult::ZeroTransfer
    );
    // A support is staged only. The complete parent seam consumes the
    // contiguous [0, 0] slab exactly once.
    assert_eq!(caller.accepted_cursor(), 1);
    assert_ne!(caller.ending_frame(), &before);
    assert!(caller.complete_parent().is_err());
    assert_eq!(caller.accepted_cursor(), 1);
}

#[test]
fn m1_receiver_prescribed_routing_uses_shared_geometry_and_once_only_tile_conversion() {
    let root: Value = serde_json::from_str(ROUTING).expect("routing reference");
    let expected = &root["routing_control"];
    let routed = route_m1_column_liquid(&prescribed_routing_input()).expect("shared geometry");
    assert_eq!(routed.captures().len(), 9);
    for (actual, frozen) in routed.captures().iter().zip(
        expected["upper"]
            .as_array()
            .expect("upper capture")
            .iter()
            .chain(expected["lower"].as_array().expect("lower capture")),
    ) {
        assert_eq!(
            actual.kind(),
            frozen["kind"].as_str().expect("capture kind")
        );
        assert!((actual.mass_kg_m2_tile() - decimal(&frozen["mass"])).abs() <= 1e-12);
        assert!((actual.enthalpy_j_kg() - decimal(&frozen["h"])).abs() <= 1e-9);
    }
    let terminal = expected["terminal"].as_array().expect("terminal branches");
    assert_eq!(routed.terminal_parcels().len(), terminal.len());
    let mut expected_ofe_mass = 0.0;
    let mut expected_ofe_energy = 0.0;
    for (actual, frozen) in routed.terminal_parcels().iter().zip(terminal) {
        assert_eq!(actual.origin(), frozen["origin"].as_str().expect("origin"));
        assert!((actual.mass_kg_m2_tile() - decimal(&frozen["mass"])).abs() <= 1e-12);
        assert!((actual.enthalpy_j_kg() - decimal(&frozen["h"])).abs() <= 1e-9);
        assert!((actual.energy_j_m2_tile() - decimal(&frozen["energy"])).abs() <= 1e-8);
        assert!((actual.mass_kg_m2_ofe_ground() - decimal(&frozen["ofe_mass"])).abs() <= 1e-12);
        assert!((actual.energy_j_m2_ofe_ground() - decimal(&frozen["ofe_energy"])).abs() <= 1e-8);
        expected_ofe_mass += decimal(&frozen["ofe_mass"]);
        expected_ofe_energy += decimal(&frozen["ofe_energy"]);
    }
    assert!((routed.total_ofe_mass_kg_m2_ground() - expected_ofe_mass).abs() <= 1e-12);
    assert!((routed.total_ofe_energy_j_m2_ground() - expected_ofe_energy).abs() <= 1e-8);
}

#[test]
fn m1_receiver_fixed_failures_restore_each_actual_owner_byte_record() {
    let control = prescribed_routing_control();
    let injections = [
        M1ReceiverFailureInjection::WrongPhase,
        M1ReceiverFailureInjection::WrongOwner,
        M1ReceiverFailureInjection::WrongSupport,
        M1ReceiverFailureInjection::WrongLiquidEnthalpy,
        M1ReceiverFailureInjection::WrongAreaConversion,
        M1ReceiverFailureInjection::WrongSourceBranch,
        M1ReceiverFailureInjection::WrongReceiptDestination,
        M1ReceiverFailureInjection::MissingReceipt,
        M1ReceiverFailureInjection::ForeignReceipt,
        M1ReceiverFailureInjection::DuplicateTransfer,
        M1ReceiverFailureInjection::LateReceiverFailure,
    ];
    for injection in injections {
        let mut fixture = endpoint_fixture();
        let before = endpoint_owner_snapshot(&fixture);
        let error =
            execute_m1_cold_canopy_receiver_diagnostic(&mut fixture, &control, Some(injection))
                .expect_err("fixed receiver rejection");
        assert_eq!(error.code(), "VEG-E-143");
        let (stage, reason) = match injection {
            M1ReceiverFailureInjection::WrongPhase => ("preflight", "wrong_phase"),
            M1ReceiverFailureInjection::WrongOwner => ("preflight", "wrong_owner"),
            M1ReceiverFailureInjection::WrongSupport => ("preflight", "wrong_support"),
            M1ReceiverFailureInjection::WrongLiquidEnthalpy => {
                ("receiver", "wrong_liquid_enthalpy")
            }
            M1ReceiverFailureInjection::WrongAreaConversion => {
                ("receiver", "wrong_area_conversion")
            }
            M1ReceiverFailureInjection::WrongSourceBranch => ("receiver", "wrong_source_branch"),
            M1ReceiverFailureInjection::WrongPlantArea => ("receiver", "wrong_area_conversion"),
            M1ReceiverFailureInjection::WrongReceiptDestination
            | M1ReceiverFailureInjection::MissingReceipt
            | M1ReceiverFailureInjection::ForeignReceipt => ("receiver", "wrong_source_branch"),
            M1ReceiverFailureInjection::DuplicateTransfer => ("receiver", "duplicate_transfer"),
            M1ReceiverFailureInjection::LateReceiverFailure => {
                ("late_receiver", "injected_failure")
            }
        };
        assert_eq!(error.rejection_stage().as_str(), stage);
        assert_eq!(error.rejection_reason().as_str(), reason);
        if injection == M1ReceiverFailureInjection::LateReceiverFailure {
            let rejected = error.rejected_candidate().expect("late rejected candidate");
            assert_raw_receiver_operands(rejected);
        }
        let after = endpoint_owner_snapshot(&fixture);
        assert_eq!(before.owners().len(), 6);
        assert_eq!(before.owners(), after.owners(), "{injection:?}");
        before
            .check_snapshot(&after)
            .unwrap_or_else(|failure| panic!("{injection:?}: {failure}"));
    }
}

#[test]
fn m1_combined_support_and_raw_domain_guards_preserve_precedence() {
    let radiation: Value = serde_json::from_str(RADIATION).expect("radiation");
    let original: Value = serde_json::from_str(ORIGINAL).expect("original");
    let unsupported = radiation_input_with_conditions(
        &radiation,
        &original,
        M1SupportConditions {
            occupancy_conditions: vec![M1OccupancySupportCondition {
                occupancy_id: "stratum-z-upper::forest".to_owned(),
                liquid_conducting: true,
                full_supply: false,
            }],
            ..conditions()
        },
        f64::NAN,
    );
    let error = evaluate_m1_coupled_column(&unsupported, &trial()).expect_err("support first");
    assert_eq!(error.code(), "VEG-E-140");
    let wrong_model = radiation_input_with_conditions(
        &radiation,
        &original,
        M1SupportConditions {
            model_definition_id: "wrong-model".to_owned(),
            ..conditions()
        },
        decimal(&radiation["inputs"]["p"]),
    );
    let error = evaluate_m1_coupled_column(&wrong_model, &trial()).expect_err("model identity");
    assert_eq!(error.code(), "VEG-E-140");
    let raw_invalid =
        radiation_input_with_conditions(&radiation, &original, conditions(), f64::NAN);
    let error = evaluate_m1_coupled_column(&raw_invalid, &trial()).expect_err("raw input");
    assert_eq!(error.code(), "VEG-E-141");
    for support in [
        M1SupportConditions {
            occupancy_conditions: vec![M1OccupancySupportCondition {
                occupancy_id: "stratum-z-upper::forest".to_owned(),
                liquid_conducting: true,
                full_supply: true,
            }],
            ..conditions()
        },
        M1SupportConditions {
            occupancy_conditions: vec![
                M1OccupancySupportCondition {
                    occupancy_id: "stratum-z-upper::forest".to_owned(),
                    liquid_conducting: true,
                    full_supply: true,
                },
                M1OccupancySupportCondition {
                    occupancy_id: "stratum-z-upper::forest".to_owned(),
                    liquid_conducting: true,
                    full_supply: true,
                },
            ],
            ..conditions()
        },
        M1SupportConditions {
            occupancy_conditions: vec![
                M1OccupancySupportCondition {
                    occupancy_id: "stratum-z-upper::forest".to_owned(),
                    liquid_conducting: true,
                    full_supply: true,
                },
                M1OccupancySupportCondition {
                    occupancy_id: "unknown-occupancy".to_owned(),
                    liquid_conducting: true,
                    full_supply: true,
                },
            ],
            ..conditions()
        },
    ] {
        let invalid = radiation_input_with_conditions(&radiation, &original, support, f64::NAN);
        assert_eq!(
            evaluate_m1_coupled_column(&invalid, &trial())
                .expect_err("support precedence")
                .code(),
            "VEG-E-140"
        );
    }
}
