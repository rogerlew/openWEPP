//! Canonical frozen-litter V3 publication retention seam.

use openwepp_coupled_time::{Digest32, digest_bytes};
use serde::{Deserialize, Serialize};

// The successor runtime adopter is a separate manifest-owned slice. Keep this
// canonical seam warning-clean while it remains deliberately unwired.
#[allow(dead_code)]
const FROZEN_LITTER_V3_PUBLICATION_SUPPORT_SCHEMA: &str =
    "OPENWEPP_FROZEN_LITTER_V3_PUBLICATION_SUPPORT_V1";

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[allow(dead_code)]
struct FrozenLitterV3PublicationReceiptFrameV1 {
    ordinal: u32,
    model_version: String,
    model_definition_sha256: String,
    lse_configuration_sha256: String,
    receipt_sha256: String,
    canonical_receipt_bytes: Vec<u8>,
}

/// Additive successor publication value for one accepted frozen-litter
/// support. V1 publication bytes remain unchanged; a later runtime adopter
/// must retain this value beside, never inside, the V1 support.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[allow(dead_code)]
pub(crate) struct FrozenLitterV3PublicationSupportV1 {
    schema: String,
    surface_configuration_sha256: String,
    projection_sha256: String,
    projection_receipt_chain_sha256: String,
    canonical_projection_bytes: Vec<u8>,
    ordered_litter_phase_receipts: Vec<FrozenLitterV3PublicationReceiptFrameV1>,
    publication_sha256: Digest32,
}

#[derive(Deserialize)]
#[allow(dead_code)]
struct FrozenLitterV3ProjectionRetentionView {
    receipt_chain_sha256: String,
    litter_phase_receipt_bytes: Vec<Vec<u8>>,
    projection_sha256: String,
}

#[allow(dead_code)]
impl FrozenLitterV3PublicationSupportV1 {
    pub(crate) fn try_new(
        configuration: &crate::SurfaceLiquidConfigurationV2,
        projection: &crate::SurfaceLiquidCompleteOwnerProjectionV3,
        ordered_receipts: &[openwepp_land_surface_energy::LitterPhaseReceipt],
    ) -> Result<Self, crate::DirectSurfaceLiquidError> {
        let canonical_projection_bytes = projection.canonical_bytes(configuration)?;
        let ordered_litter_phase_receipts = ordered_receipts
            .iter()
            .enumerate()
            .map(|(ordinal, receipt)| {
                let ordinal = u32::try_from(ordinal).map_err(|_| {
                    crate::DirectSurfaceLiquidError::Identity(
                        "frozen-litter V3 publication receipt ordinal width",
                    )
                })?;
                let canonical_receipt_bytes =
                    openwepp_land_surface_energy::litter_phase_receipt_json(receipt).map_err(
                        |_| {
                            crate::DirectSurfaceLiquidError::Identity(
                                "invalid frozen-litter V3 publication receipt",
                            )
                        },
                    )?;
                Ok(FrozenLitterV3PublicationReceiptFrameV1 {
                    ordinal,
                    model_version: receipt.identity.model_version.clone(),
                    model_definition_sha256: receipt.identity.model_definition_sha256.to_string(),
                    lse_configuration_sha256: receipt.identity.lse_configuration_sha256.to_string(),
                    receipt_sha256: receipt.receipt_sha256.to_string(),
                    canonical_receipt_bytes,
                })
            })
            .collect::<Result<Vec<_>, crate::DirectSurfaceLiquidError>>()?;
        let mut value = Self {
            schema: FROZEN_LITTER_V3_PUBLICATION_SUPPORT_SCHEMA.into(),
            surface_configuration_sha256: configuration.configuration_sha256().into(),
            projection_sha256: projection.projection_sha256().into(),
            projection_receipt_chain_sha256: projection.identity().receipt_chain_sha256.clone(),
            canonical_projection_bytes,
            ordered_litter_phase_receipts,
            publication_sha256: Digest32::zero(),
        };
        value.publication_sha256 = value.recomputed_sha256()?;
        value.validate_constructed(configuration, projection, ordered_receipts)?;
        Ok(value)
    }

    fn validate_constructed(
        &self,
        configuration: &crate::SurfaceLiquidConfigurationV2,
        projection: &crate::SurfaceLiquidCompleteOwnerProjectionV3,
        ordered_receipts: &[openwepp_land_surface_energy::LitterPhaseReceipt],
    ) -> Result<(), crate::DirectSurfaceLiquidError> {
        let expected_count = configuration
            .parent()
            .records
            .iter()
            .filter(|record| {
                record.key.surface_class == openwepp_land_surface_energy::SurfaceClass::ForestLitter
            })
            .count();
        if self.schema != FROZEN_LITTER_V3_PUBLICATION_SUPPORT_SCHEMA
            || self.surface_configuration_sha256 != configuration.configuration_sha256()
            || self.projection_sha256 != projection.projection_sha256()
            || self.projection_receipt_chain_sha256 != projection.identity().receipt_chain_sha256
            || self.ordered_litter_phase_receipts.len() != ordered_receipts.len()
            || self.ordered_litter_phase_receipts.len()
                != projection.litter_phase_receipt_bytes().len()
            || expected_count != ordered_receipts.len()
            || self.publication_sha256 == Digest32::zero()
            || self.publication_sha256 != self.recomputed_sha256()?
        {
            return Err(crate::DirectSurfaceLiquidError::Identity(
                "frozen-litter V3 constructed publication support seal",
            ));
        }
        for (ordinal, ((frame, receipt), projection_receipt_bytes)) in self
            .ordered_litter_phase_receipts
            .iter()
            .zip(ordered_receipts)
            .zip(projection.litter_phase_receipt_bytes())
            .enumerate()
        {
            let configured = configuration
                .parent()
                .records
                .iter()
                .filter(|record| {
                    record.key.surface_class
                        == openwepp_land_surface_energy::SurfaceClass::ForestLitter
                })
                .nth(ordinal)
                .ok_or(crate::DirectSurfaceLiquidError::Identity(
                    "frozen-litter V3 constructed publication receipt order",
                ))?;
            if usize::try_from(frame.ordinal) != Ok(ordinal)
                || &frame.canonical_receipt_bytes != projection_receipt_bytes
                || frame.model_version != receipt.identity.model_version
                || frame.model_definition_sha256
                    != receipt.identity.model_definition_sha256.as_str()
                || frame.lse_configuration_sha256
                    != receipt.identity.lse_configuration_sha256.as_str()
                || frame.receipt_sha256 != receipt.receipt_sha256.as_str()
                || receipt.identity.transaction_id != projection.identity().transaction_id
                || receipt.identity.support_start_ns != projection.identity().support_start_ns
                || receipt.identity.support_end_ns != projection.identity().support_end_ns
                || receipt.identity.ofe_id != configured.key.ofe_id
                || receipt.identity.tile_id != configured.key.tile_id
            {
                return Err(crate::DirectSurfaceLiquidError::Identity(
                    "frozen-litter V3 constructed publication receipt identity",
                ));
            }
        }
        Ok(())
    }

    pub(crate) fn canonical_bytes(
        &self,
        configuration: &crate::SurfaceLiquidConfigurationV2,
    ) -> Result<Vec<u8>, crate::DirectSurfaceLiquidError> {
        self.validate(configuration)?;
        serde_json::to_vec(self).map_err(|_| {
            crate::DirectSurfaceLiquidError::Schema(
                "frozen-litter V3 publication support serialization",
            )
        })
    }

    #[must_use]
    pub(crate) const fn publication_sha256(&self) -> &Digest32 {
        &self.publication_sha256
    }

    pub(crate) fn from_canonical_bytes(
        configuration: &crate::SurfaceLiquidConfigurationV2,
        bytes: &[u8],
    ) -> Result<Self, crate::DirectSurfaceLiquidError> {
        let value: Self = serde_json::from_slice(bytes).map_err(|_| {
            crate::DirectSurfaceLiquidError::Schema("frozen-litter V3 publication support parsing")
        })?;
        value.validate(configuration)?;
        if serde_json::to_vec(&value).map_err(|_| {
            crate::DirectSurfaceLiquidError::Schema(
                "frozen-litter V3 publication support canonicalization",
            )
        })? != bytes
        {
            return Err(crate::DirectSurfaceLiquidError::Schema(
                "noncanonical frozen-litter V3 publication support bytes",
            ));
        }
        Ok(value)
    }

    pub(crate) fn complete_owner_projection(
        &self,
        configuration: &crate::SurfaceLiquidConfigurationV2,
    ) -> Result<crate::SurfaceLiquidCompleteOwnerProjectionV3, crate::DirectSurfaceLiquidError>
    {
        self.validate(configuration)?;
        crate::SurfaceLiquidCompleteOwnerProjectionV3::from_canonical_bytes(
            configuration,
            &self.canonical_projection_bytes,
        )
    }

    pub(crate) fn ordered_litter_phase_receipts(
        &self,
        configuration: &crate::SurfaceLiquidConfigurationV2,
    ) -> Result<
        Vec<openwepp_land_surface_energy::LitterPhaseReceipt>,
        crate::DirectSurfaceLiquidError,
    > {
        self.validate(configuration)?;
        self.replay_receipts()
    }

    fn validate(
        &self,
        configuration: &crate::SurfaceLiquidConfigurationV2,
    ) -> Result<(), crate::DirectSurfaceLiquidError> {
        let projection = crate::SurfaceLiquidCompleteOwnerProjectionV3::from_canonical_bytes(
            configuration,
            &self.canonical_projection_bytes,
        )?;
        let projection_view: FrozenLitterV3ProjectionRetentionView =
            serde_json::from_slice(&self.canonical_projection_bytes).map_err(|_| {
                crate::DirectSurfaceLiquidError::Schema("frozen-litter V3 retained projection view")
            })?;
        let receipts = self.replay_receipts()?;
        let expected_count = configuration
            .parent()
            .records
            .iter()
            .filter(|record| {
                record.key.surface_class == openwepp_land_surface_energy::SurfaceClass::ForestLitter
            })
            .count();
        if self.schema != FROZEN_LITTER_V3_PUBLICATION_SUPPORT_SCHEMA
            || self.surface_configuration_sha256 != configuration.configuration_sha256()
            || self.projection_sha256 != projection.projection_sha256()
            || self.projection_sha256 != projection_view.projection_sha256
            || self.projection_receipt_chain_sha256 != projection.identity().receipt_chain_sha256
            || self.projection_receipt_chain_sha256 != projection_view.receipt_chain_sha256
            || projection_view.litter_phase_receipt_bytes
                != self
                    .ordered_litter_phase_receipts
                    .iter()
                    .map(|frame| frame.canonical_receipt_bytes.clone())
                    .collect::<Vec<_>>()
            || expected_count != receipts.len()
            || self.publication_sha256 == Digest32::zero()
            || self.publication_sha256 != self.recomputed_sha256()?
        {
            return Err(crate::DirectSurfaceLiquidError::Identity(
                "frozen-litter V3 publication support seal",
            ));
        }
        for ((ordinal, frame), receipt) in self
            .ordered_litter_phase_receipts
            .iter()
            .enumerate()
            .zip(&receipts)
        {
            let configured = configuration
                .parent()
                .records
                .iter()
                .filter(|record| {
                    record.key.surface_class
                        == openwepp_land_surface_energy::SurfaceClass::ForestLitter
                })
                .nth(ordinal)
                .ok_or(crate::DirectSurfaceLiquidError::Identity(
                    "frozen-litter V3 publication receipt order",
                ))?;
            if usize::try_from(frame.ordinal) != Ok(ordinal)
                || frame.model_version != receipt.identity.model_version
                || frame.model_definition_sha256
                    != receipt.identity.model_definition_sha256.as_str()
                || frame.lse_configuration_sha256
                    != receipt.identity.lse_configuration_sha256.as_str()
                || frame.receipt_sha256 != receipt.receipt_sha256.as_str()
                || receipt.identity.transaction_id != projection.identity().transaction_id
                || receipt.identity.support_start_ns != projection.identity().support_start_ns
                || receipt.identity.support_end_ns != projection.identity().support_end_ns
                || receipt.identity.ofe_id != configured.key.ofe_id
                || receipt.identity.tile_id != configured.key.tile_id
            {
                return Err(crate::DirectSurfaceLiquidError::Identity(
                    "frozen-litter V3 publication receipt identity",
                ));
            }
        }
        Ok(())
    }

    fn replay_receipts(
        &self,
    ) -> Result<
        Vec<openwepp_land_surface_energy::LitterPhaseReceipt>,
        crate::DirectSurfaceLiquidError,
    > {
        self.ordered_litter_phase_receipts
            .iter()
            .map(|frame| {
                let receipt = openwepp_land_surface_energy::litter_phase_receipt_from_json(
                    &frame.canonical_receipt_bytes,
                )
                .map_err(|_| {
                    crate::DirectSurfaceLiquidError::Identity(
                        "frozen-litter V3 publication receipt replay",
                    )
                })?;
                if openwepp_land_surface_energy::litter_phase_receipt_json(&receipt).map_err(
                    |_| {
                        crate::DirectSurfaceLiquidError::Identity(
                            "frozen-litter V3 publication receipt canonical replay",
                        )
                    },
                )? != frame.canonical_receipt_bytes
                {
                    return Err(crate::DirectSurfaceLiquidError::Schema(
                        "noncanonical frozen-litter V3 publication receipt bytes",
                    ));
                }
                Ok(receipt)
            })
            .collect()
    }

    fn recomputed_sha256(&self) -> Result<Digest32, crate::DirectSurfaceLiquidError> {
        let mut value = self.clone();
        value.publication_sha256 = Digest32::zero();
        let bytes = serde_json::to_vec(&value).map_err(|_| {
            crate::DirectSurfaceLiquidError::Schema("frozen-litter V3 publication support digest")
        })?;
        Ok(digest_bytes(
            &[
                b"OPENWEPP_FROZEN_LITTER_V3_PUBLICATION_SUPPORT_V1\0".as_slice(),
                bytes.as_slice(),
            ]
            .concat(),
        ))
    }
}

/// Native histories order owner transitions. Existing phase wire bytes remain
/// unchanged; a policy12 custody record is distinguished by its own schema.
#[derive(Clone, Debug, PartialEq)]
pub(crate) enum FrozenLitterHistoryEntryV1 {
    Phase(FrozenLitterV3PublicationSupportV1),
    Custody(Box<super::native_snow_liquid_publication::NativeSnowLiquidPublicationV1>),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct FrozenLitterHistoryIdentityV1 {
    pub transaction_id: openwepp_kernel_contract::TransactionId,
    pub predecessor_transaction_id: Option<openwepp_kernel_contract::TransactionId>,
    pub parent_support_start_ns: u128,
    pub parent_support_end_ns: u128,
    pub support_start_ns: u128,
    pub support_end_ns: u128,
    pub beginning_surface_owner_sha256: String,
    pub ending_surface_owner_sha256: String,
    pub predecessor_receipt_chain_sha256: String,
    pub receipt_chain_sha256: String,
}
impl FrozenLitterHistoryIdentityV1 {
    pub(crate) fn from_phase(projection: &crate::SurfaceLiquidCompleteOwnerProjectionV3) -> Self {
        let id = projection.identity();
        Self {
            transaction_id: id.transaction_id,
            predecessor_transaction_id: id.predecessor_transaction_id,
            parent_support_start_ns: id.parent_support_start_ns,
            parent_support_end_ns: id.parent_support_end_ns,
            support_start_ns: id.support_start_ns,
            support_end_ns: id.support_end_ns,
            beginning_surface_owner_sha256: id.beginning_surface_owner_sha256.clone(),
            ending_surface_owner_sha256: projection.envelope_sha256().into(),
            predecessor_receipt_chain_sha256: id.predecessor_receipt_chain_sha256.clone(),
            receipt_chain_sha256: id.receipt_chain_sha256.clone(),
        }
    }
}
impl FrozenLitterHistoryEntryV1 {
    pub(crate) fn publication_sha256(&self) -> &Digest32 {
        match self {
            Self::Phase(value) => value.publication_sha256(),
            Self::Custody(value) => &value.publication_sha256,
        }
    }
    pub(crate) fn identity(
        &self,
        configuration: &crate::SurfaceLiquidConfigurationV2,
        lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    ) -> Result<FrozenLitterHistoryIdentityV1, crate::DirectSurfaceLiquidError> {
        match self {
            Self::Phase(value) => Ok(FrozenLitterHistoryIdentityV1::from_phase(
                &value.complete_owner_projection(configuration)?,
            )),
            Self::Custody(value) => {
                value.validate(configuration, lse_configuration)?;
                let id = &value.identity;
                Ok(FrozenLitterHistoryIdentityV1 {
                    transaction_id: id.transaction_id,
                    predecessor_transaction_id: id.predecessor_transaction_id,
                    parent_support_start_ns: id.parent_start_ns,
                    parent_support_end_ns: id.parent_end_ns,
                    support_start_ns: id.support_start_ns,
                    support_end_ns: id.support_end_ns,
                    beginning_surface_owner_sha256: value
                        .beginning_exact
                        .frozen_surface_owner_v2_sha256
                        .to_string(),
                    ending_surface_owner_sha256: value
                        .ending_exact
                        .frozen_surface_owner_v2_sha256
                        .to_string(),
                    predecessor_receipt_chain_sha256: id
                        .predecessor_physical_receipt_chain_sha256
                        .clone(),
                    receipt_chain_sha256: value
                        .receipt_sha256
                        .as_bytes()
                        .iter()
                        .map(|byte| format!("{byte:02x}"))
                        .collect(),
                })
            }
        }
    }
    pub(crate) fn canonical_bytes(
        &self,
        configuration: &crate::SurfaceLiquidConfigurationV2,
        lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    ) -> Result<Vec<u8>, crate::DirectSurfaceLiquidError> {
        match self {
            Self::Phase(value) => value.canonical_bytes(configuration),
            Self::Custody(value) => value.canonical_bytes(configuration, lse_configuration),
        }
    }
    pub(crate) fn from_canonical_bytes(
        configuration: &crate::SurfaceLiquidConfigurationV2,
        lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
        bytes: &[u8],
    ) -> Result<Self, crate::DirectSurfaceLiquidError> {
        let probe: serde_json::Value = serde_json::from_slice(bytes).map_err(|_| {
            crate::DirectSurfaceLiquidError::Schema("native history schema discriminator")
        })?;
        match probe.get("schema").and_then(serde_json::Value::as_str) {
            Some(FROZEN_LITTER_V3_PUBLICATION_SUPPORT_SCHEMA)=>Ok(Self::Phase(
                FrozenLitterV3PublicationSupportV1::from_canonical_bytes(configuration,bytes)?)),
            Some(super::native_snow_liquid_publication::NATIVE_SNOW_CUSTODY_SCHEMA)=>Ok(Self::Custody(Box::new(
                super::native_snow_liquid_publication::NativeSnowLiquidPublicationV1::from_canonical_bytes(
                    configuration,lse_configuration,bytes)?))),
            _=>Err(crate::DirectSurfaceLiquidError::Schema("unknown native history kind")),
        }
    }
}

/// Full semantic history validation is mandatory at durable restore. Dry
/// intervals may be absent; a same-endpoint phase then drain is not overlap.
/// Private in-process progress derived only from fully validated history.
/// Full restore and incremental acceptance use the same transition checks.
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct NativeHistoryCursorV1 {
    prior: Option<(FrozenLitterHistoryIdentityV1, bool)>,
    consumed: std::collections::BTreeSet<Digest32>,
    dirty_parent: Option<(openwepp_kernel_contract::TransactionId, u128, u128)>,
    dirty_parent_digest: Option<Digest32>,
}
impl NativeHistoryCursorV1 {
    pub(crate) fn dirty_parent(
        &self,
    ) -> Option<(
        openwepp_kernel_contract::TransactionId,
        u128,
        u128,
        Digest32,
    )> {
        self.dirty_parent
            .zip(self.dirty_parent_digest)
            .map(|((tx, start, end), digest)| (tx, start, end, digest))
    }
    pub(crate) fn advance(
        &mut self,
        entry: &FrozenLitterHistoryEntryV1,
        current: FrozenLitterHistoryIdentityV1,
    ) -> Result<(), crate::DirectSurfaceLiquidError> {
        use super::native_snow_liquid_publication::NativeSnowCustodyKindV1;
        use crate::DirectSurfaceLiquidError as Error;
        let parent = (
            current.transaction_id,
            current.parent_support_start_ns,
            current.parent_support_end_ns,
        );
        if let Some((previous, previous_is_phase)) = &self.prior {
            if current.predecessor_receipt_chain_sha256 != previous.receipt_chain_sha256
                || current.beginning_surface_owner_sha256 != previous.ending_surface_owner_sha256
            {
                return Err(Error::Identity("native history physical predecessor chain"));
            }
            let same_support = current.support_start_ns == previous.support_start_ns
                && current.support_end_ns == previous.support_end_ns;
            if current.support_start_ns < previous.support_end_ns
                && !(same_support
                    && *previous_is_phase
                    && matches!(entry, FrozenLitterHistoryEntryV1::Custody(_)))
            {
                return Err(Error::Identity(
                    "native history overlapping or reordered origin support",
                ));
            }
        }
        if self.dirty_parent.is_some_and(|dirty| dirty != parent) {
            return Err(Error::Identity(
                "native history omitted dirty parent finalization",
            ));
        }
        match entry {
            FrozenLitterHistoryEntryV1::Phase(_) => {
                if current.support_end_ns == current.parent_support_end_ns {
                    self.dirty_parent = None;
                }
            }
            FrozenLitterHistoryEntryV1::Custody(record) => {
                if self
                    .dirty_parent_digest
                    .is_some_and(|digest| digest != record.identity.parent_transaction_sha256)
                {
                    return Err(Error::Identity(
                        "native history foreign dirty parent digest",
                    ));
                }
                match record.identity.kind {
                    NativeSnowCustodyKindV1::Drain => {
                        for output in &record.outputs {
                            if !self.consumed.insert(output.receipt_sha256) {
                                return Err(Error::Identity(
                                    "native history replayed donor output",
                                ));
                            }
                        }
                        if record.beginning_lse.0.last_accepted_transaction_id
                            == Some(current.transaction_id)
                            && self.prior.as_ref().is_none_or(|(previous, is_phase)| {
                                !*is_phase
                                    || previous.transaction_id != current.transaction_id
                                    || previous.parent_support_start_ns
                                        != current.parent_support_start_ns
                                    || previous.parent_support_end_ns
                                        != current.parent_support_end_ns
                                    || previous.support_end_ns != current.support_end_ns
                                    || previous.support_end_ns != previous.parent_support_end_ns
                            })
                        {
                            return Err(Error::Identity(
                                "native history foreign existing final marker",
                            ));
                        }
                        self.dirty_parent =
                            if current.support_end_ns < current.parent_support_end_ns {
                                Some(parent)
                            } else {
                                None
                            };
                        self.dirty_parent_digest = self
                            .dirty_parent
                            .map(|_| record.identity.parent_transaction_sha256);
                    }
                    NativeSnowCustodyKindV1::ParentFinalization => {
                        if self.dirty_parent_digest
                            != Some(record.identity.parent_transaction_sha256)
                        {
                            return Err(Error::Identity("native history dirty parent digest"));
                        }
                        if self.dirty_parent != Some(parent)
                            || current.support_end_ns != current.parent_support_end_ns
                        {
                            return Err(Error::Identity(
                                "native history unearned parent finalization",
                            ));
                        }
                        self.dirty_parent = None;
                    }
                }
            }
        }
        if self.dirty_parent.is_none() {
            self.dirty_parent_digest = None;
        }
        self.prior = Some((
            current,
            matches!(entry, FrozenLitterHistoryEntryV1::Phase(_)),
        ));
        Ok(())
    }
}

pub(crate) fn validate_native_history_v1(
    entries: &[FrozenLitterHistoryEntryV1],
    configuration: &crate::SurfaceLiquidConfigurationV2,
    lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
) -> Result<NativeHistoryCursorV1, crate::DirectSurfaceLiquidError> {
    let mut cursor = NativeHistoryCursorV1::default();
    for entry in entries {
        let identity = entry.identity(configuration, lse_configuration)?;
        cursor.advance(entry, identity)?;
    }
    Ok(cursor)
}
