#![cfg(test)]
//! Private field-complete inverse of the diagnostic constructor capture.
//! No solver or process transition is evaluated here. The native constructor
//! remains the authority for installing the reconstructed operands.
use serde_json::Value;

trait Decode: Sized {
    fn decode(value: &Value) -> Result<Self, String>;
}
fn field<T: Decode>(value: &Value, name: &str) -> Result<T, String> {
    T::decode(
        value
            .get(name)
            .ok_or_else(|| format!("missing constructor field {name}"))?,
    )
    .map_err(|error| format!("{name}: {error}"))
}
macro_rules! scalar {
    ($($ty:ty),* $(,)?) => {$(impl Decode for $ty {
        fn decode(value: &Value) -> Result<Self, String> {
            serde_json::from_value(value.clone()).map_err(|error| error.to_string())
        }
    })*};
}
scalar!(
    f64,
    bool,
    u8,
    u16,
    u32,
    u64,
    usize,
    i8,
    i16,
    i32,
    i64,
    String,
    (f64, f64, f64)
);
impl<T: Decode> Decode for Option<T> {
    fn decode(value: &Value) -> Result<Self, String> {
        if value.is_null() {
            Ok(None)
        } else {
            T::decode(value).map(Some)
        }
    }
}
impl<T: Decode> Decode for Box<T> {
    fn decode(value: &Value) -> Result<Self, String> {
        T::decode(value).map(Box::new)
    }
}
impl<T: Decode> Decode for Vec<T> {
    fn decode(value: &Value) -> Result<Self, String> {
        value
            .as_array()
            .ok_or("constructor array required")?
            .iter()
            .map(T::decode)
            .collect()
    }
}
impl<T: Decode, const N: usize> Decode for [T; N] {
    fn decode(value: &Value) -> Result<Self, String> {
        Vec::<T>::decode(value)?
            .try_into()
            .map_err(|v: Vec<T>| format!("constructor array length {}, expected {N}", v.len()))
    }
}
impl Decode for openwepp_unit_boundary::TemperatureCelsius {
    fn decode(value: &Value) -> Result<Self, String> {
        Self::try_new(f64::decode(value)?).map_err(|error| error.to_string())
    }
}
macro_rules! captured_struct {
    ($ty:path { $($name:ident),* $(,)? }) => {
        impl Decode for $ty {
            fn decode(value: &Value) -> Result<Self, String> {
                Ok(Self { $($name: field(value, stringify!($name))?),* })
            }
        }
    };
}
macro_rules! captured_enum {
    ($ty:path { $($variant:ident),* $(,)? }) => {
        impl Decode for $ty {
            fn decode(value: &Value) -> Result<Self, String> {
                $(if serde_json::to_value(Self::$variant).map_err(|error| error.to_string())? == *value {
                    return Ok(Self::$variant);
                })*
                Err(format!("unknown {} captured variant", stringify!($ty)))
            }
        }
    };
}
macro_rules! active_context {
    ($ty:path) => {
        impl Decode for $ty {
            fn decode(value: &Value) -> Result<Self, String> {
                match value.as_str() {
                    Some("inactive") => return Ok(Self::Inactive),
                    Some("missing") => return Ok(Self::Missing),
                    Some("ambiguous") => return Ok(Self::Ambiguous),
                    _ => {}
                }
                if let Some(fields) = value.get("annual_or_fallow") {
                    return Ok(Self::AnnualOrFallow {
                        active_slot_index: field(fields, "active_slot_index")?,
                        active_crop_slot_index: field(fields, "active_crop_slot_index")?,
                        runtime_day_of_year: field(fields, "runtime_day_of_year")?,
                    });
                }
                if let Some(fields) = value.get("perennial") {
                    return Ok(Self::Perennial {
                        active_slot_index: field(fields, "active_slot_index")?,
                        active_crop_slot_index: field(fields, "active_crop_slot_index")?,
                        runtime_day_of_year: field(fields, "runtime_day_of_year")?,
                    });
                }
                Err(format!("unknown {} captured context", stringify!($ty)))
            }
        }
    };
}
impl Decode for crate::DirectSnowMassTransitionLedgers {
    fn decode(value: &Value) -> Result<Self, String> {
        Self::try_from_parts(
            field(value, "solid_to_liquid")?,
            field(value, "liquid_disposition")?,
            field(value, "stage3_outcome")?,
        )
        .map_err(|error| error.to_string())
    }
}
// Source fields: direct_runtime/00_core_frames.rs:508
captured_struct!(crate::direct_runtime::DirectDayConstructorInputs {
    forcing,
    normalization_inputs,
    interception_m,
    storage_bounds_inputs,
    decomposition_inputs,
    residue_partition_inputs,
    annual_growth_inputs,
    perennial_growth_inputs,
    storage_input_inputs,
    liquid_input_inputs,
    runon_carry_inputs,
    infiltration_depression_inputs,
    saturation_addback_inputs,
    runoff_partition_inputs,
    percolation_inputs,
    subsurface_compute_inputs,
    deep_seepage_inputs,
    subsurface_loss_inputs,
    evapotranspiration_compute_inputs,
    evapotranspiration_inputs,
    snow_coupling_inputs,
    storage_reconciliation_inputs,
    hydrology_projection_inputs,
    erosion_inputs,
    frost_storage_liquid_delta_m,
    winter_frost_compute_inputs,
    winter_frost_outcome,
    frost_layer_carry_projection,
    snow_runtime_carry,
    frost_runtime_carry
});
// Source fields: direct_runtime/02_state_reports.rs:57
captured_struct!(crate::direct_runtime::DirectDayForcing {
    precipitation_m,
    effective_temperature_c
});
// Source fields: direct_runtime/decomposition.rs:389
captured_enum!(crate::direct_runtime::DirectDecompositionAction {
    None,
    Herbicide,
    Burn,
    Silage,
    Cut,
    Remove,
    Grazing
});
// Source fields: direct_runtime/decomposition.rs:358
active_context!(crate::direct_runtime::DirectDecompositionActiveContext);
// Source fields: direct_runtime/decomposition.rs:407
captured_struct!(crate::direct_runtime::DirectDecompositionInputs {
    active_context,
    active_action,
    residue_type_selector,
    surface_residue_seed_kg_m2,
    interrill_ground_seed_kg_m2,
    rill_ground_seed_kg_m2,
    residue_cover_factor,
    root_residue_seed_kg_m2,
    surface_litter_input_kg_m2,
    residue_depth_conversion_m_per_kg_m2,
    temperature_max_c,
    temperature_min_c,
    precipitation_m,
    water_stress_fraction,
    surface_decomposition_rate,
    root_decomposition_rate,
    burn_surface_fraction,
    remove_surface_fraction,
    cut_transfer_fraction,
    grazing_digest_fraction
});
// Source fields: direct_runtime/storage.rs:1163
captured_struct!(crate::direct_runtime::DirectDeepSeepageInputs {
    deep_seepage_handoff_m
});
// Source fields: direct_runtime/erosion.rs:157
captured_struct!(crate::direct_runtime::DirectErod13Inputs {
    ie_m_s,
    te_s,
    fs,
    ft,
    taufe_pa,
    q_m2_s,
    g_kg_s_m,
    di_kg_s_m2,
    beta,
    vf_m_s,
    dgdx_kg_s_m2,
    cntlen_m,
    kr_s_m,
    kradjf,
    tcadjf,
    shrsol_pa,
    tcend_kg_s_m,
    shcrit_pa,
    detinr_kg_s_m2,
    effdrr_m,
    effdrn_m,
    veleff_m_s,
    pkro_m3_s,
    tc_k,
    tc_m,
    q_runoff_m,
    peakro_m_s,
    watdur_s
});
// Source fields: direct_runtime/erosion.rs:144
captured_enum!(
    crate::direct_runtime::DirectErosionHydrographShapeAuthority {
        Dc01SourceShape,
        RoutedHydrograph
    }
);
// Source fields: direct_runtime/erosion.rs:90
captured_struct!(crate::direct_runtime::DirectErosionInputs {
    wave1_enabled,
    wave1,
    wave1_continuity,
    wave1_operand_seed,
    hydrograph_shape_authority,
    routed_hydrograph_runoff_fraction
});
// Source fields: direct_runtime/evapotranspiration.rs:658
captured_struct!(
    crate::direct_runtime::DirectEvapotranspirationComputeInputs {
        et_demand_m,
        leaf_area_index,
        canopy_height_m,
        canopy_cover_fraction,
        residue_interception_m,
        same_pass_infiltration_m,
        outside_water_depth_m,
        root_depth_m,
        plant_tolerance,
        growth_context_required,
        stage_state,
        pmet,
        pmet_compute
    }
);
// Source fields: direct_runtime/storage.rs:1291
captured_struct!(crate::direct_runtime::DirectEvapotranspirationInputs {
    evapotranspiration_handoff_m
});
// Source fields: direct_runtime/evapotranspiration.rs:634
captured_struct!(
    crate::direct_runtime::DirectEvapotranspirationPmetComputeInputs {
        runtime_day_of_year,
        radiation_ly,
        wind_m_s,
        dew_point_c,
        temperature_max_c,
        temperature_min_c,
        latitude_degrees,
        elevation_m,
        kcb,
        rawp,
        canopy_height_m,
        radpot_ly,
        solthk_m
    }
);
// Source fields: direct_runtime/evapotranspiration.rs:620
captured_struct!(crate::direct_runtime::DirectEvapotranspirationPmetInputs {
    soil_evaporation_m,
    plant_transpiration_m,
    soil_evaporation_storage_return_m
});
// Source fields: direct_runtime/evapotranspiration.rs:605
captured_struct!(crate::direct_runtime::DirectEvapotranspirationStageState {
    s1_m,
    s2_m,
    threshold_m,
    counter
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1140
captured_struct!(crate::hydrology::DirectFrostControlInputs {
    frost_file_present,
    wint_red_enabled,
    fine_top_count,
    fine_bot_count,
    ksnowf,
    kresf,
    ksoilf,
    kfactor1,
    kfactor2,
    kfactor3,
    landuse_class_proxy
});
// Source fields: direct_runtime/00_core_frames.rs:312
captured_struct!(crate::direct_runtime::DirectFrostFineLayerCarry {
    layer_index,
    fine_index,
    fgfrst,
    slfsd_m,
    slsic_m,
    slsw_theta,
    sltime_s
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1350
captured_struct!(crate::hydrology::DirectFrostFineLayerProjection {
    layer_index,
    fine_index,
    fgfrst,
    slfsd_m,
    slsic_m,
    slsw_theta,
    sltime_s
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1115
captured_struct!(crate::hydrology::DirectFrostHourlyForcing {
    radiation_mj_m2,
    air_temperature_c,
    cloud_fraction
});
// Source fields: direct_runtime/01_publication.rs:108
captured_struct!(crate::direct_runtime::DirectFrostLayerCarryProjection {
    layer_index,
    fine_layer_count,
    fine_layer_thickness_m
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1316
captured_struct!(crate::hydrology::DirectFrostLayerProjection {
    layer_index,
    theta_after_m,
    frozen_depth_m,
    frozen_water_m
});
// Source fields: direct_runtime/00_core_frames.rs:293
captured_struct!(crate::direct_runtime::DirectFrostLayerShadowCarry {
    layer_index,
    st_m,
    soil_water_m,
    frozen_depth_m,
    frozen_water_m,
    soilf_m,
    yst_m,
    nwfrzz_m
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1331
captured_struct!(crate::hydrology::DirectFrostLayerShadowProjection {
    layer_index,
    st_m,
    soil_water_m,
    frozen_depth_m,
    frozen_water_m,
    soilf_m,
    yst_m,
    nwfrzz_m
});
// Source fields: direct_runtime/00_core_frames.rs:252
captured_struct!(crate::direct_runtime::DirectFrostRuntimeCarry {
    active_frost_coupling,
    dfrost_m,
    dthaw_m,
    nft,
    ws_frz_m,
    infcap_frz_m_s,
    frwatc_soil_water_before_m,
    frwatc_soil_water_after_m,
    frwatc_frozen_water_before_m,
    frwatc_frozen_water_after_m,
    frwatc_freeze_debit_m,
    frwatc_thaw_credit_m,
    frwatc_net_liquid_delta_m,
    frdp_m,
    thdp_m,
    tfrdp_m,
    tthawd_m,
    fgthwd_flag,
    total_fine_layer_count,
    conductivity_tilled_w_m_k,
    conductivity_untilled_w_m_k,
    conductivity_residue_w_m_k,
    shadow_total_water_before_m,
    shadow_total_water_after_m,
    shadow_wb_delta_m,
    shadow_frwatc_residual_m,
    watpdg_m,
    watbtm_m,
    layer_shadows,
    fine_layers
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1162
captured_struct!(crate::hydrology::DirectFrostThermalInputs {
    snow_depth_m,
    snow_density_kg_m3,
    residue_depth_m,
    wind_m_s,
    albedo,
    canopy_height_m,
    random_roughness_m,
    day_of_year,
    seasonal_temperature_curve
});
// Source fields: direct_runtime/growth.rs:317
captured_enum!(crate::direct_runtime::DirectGrowthAction {
    None,
    PrePlantSkip,
    PlantingReset,
    HarvestReset,
    StopReset,
    Cut,
    Grazing,
    TypedStateOverride
});
// Source fields: direct_runtime/growth.rs:260
active_context!(crate::direct_runtime::DirectGrowthActiveContext);
// Source fields: direct_runtime/growth.rs:415
captured_struct!(crate::direct_runtime::DirectGrowthInputs {
    active_context,
    active_action,
    state_before,
    planting_day,
    harvest_day,
    stop_day,
    water_stress,
    temperature_max_c,
    temperature_min_c,
    radiation_mj_m2,
    monthly_temperature_max_c,
    monthly_temperature_min_c,
    soil_depth_m,
    btemp,
    otemp,
    gddmax,
    dlai,
    dropfc,
    decfct,
    spriod,
    bb,
    bbb,
    hmax,
    beinp,
    extnct,
    hi,
    xmxlai,
    rsr,
    rtmmax,
    rdmax,
    et_demand_m,
    residue_interception_m,
    plant_tolerance
});
// Source fields: direct_runtime/growth.rs:361
captured_struct!(crate::direct_runtime::DirectGrowthStateSurface {
    sumgdd,
    live_biomass_kg_m2,
    interception_live_biomass_kg_m2,
    canopy_height_m,
    canopy_cover_fraction,
    leaf_area_index,
    root_mass_kg_m2,
    root_depth_m,
    harvest_index
});
// Source fields: direct_runtime/projection.rs:321
captured_struct!(crate::direct_runtime::DirectHydrologyProjectionInputs {
    aggregate_storage_tolerance_m,
    snow_water_m,
    frozen_soil_water_m,
    frost_depth_m,
    profile_depth_m,
    profile_porosity_cap_m,
    profile_field_capacity_m,
    profile_wilting_point_m
});
// Source fields: direct_runtime/runoff_result_types.rs:145
captured_struct!(crate::direct_runtime::DirectInfiltrationDepressionInputs {
    cumulative_infiltration_handoff_m,
    depression_storage_delta_handoff_m,
    producer_inputs
});
// Source fields: direct_runtime/runoff_result_types.rs:9
captured_struct!(crate::direct_runtime::DirectLiquidInputInputs {
    liquid_input_handoff_m
});
// Source fields: direct_runtime/normalization.rs:173
captured_struct!(crate::direct_runtime::DirectNormalizationInputs {
    precipitation_m,
    effective_temperature_c,
    storage_initial_m,
    surface_transfer_m,
    lateral_transfer_m,
    upstream_flow_m,
    subsurface_input_m
});
// Source fields: direct_runtime/subsurface.rs:784
captured_struct!(crate::direct_runtime::DirectPercolationInputs {
    soil_water_initial_m,
    reconcile_legacy_soil_water_from_layers,
    same_pass_infiltration_m,
    same_pass_infiltration_lineage,
    tillage_depth_m,
    lane_substeps,
    restrictive_layer_enabled,
    restrictive_layer_conductivity_m_s,
    restrictive_layer_thickness_m,
    layers
});
// Source fields: direct_runtime/01_publication.rs:3
captured_struct!(crate::direct_runtime::DirectPublicationFrame {
    runoff_m,
    infiltration_m,
    evapotranspiration_m,
    drainage_m,
    lateral_flow_m
});
// Source fields: direct_runtime/decomposition.rs:842
captured_struct!(crate::direct_runtime::DirectResiduePartitionInputs {
    standing_residue_kg_m2,
    flat_residue_offset_kg_m2,
    buried_residue_kg_m2,
    cover_fraction,
    rescov_interrill_weight
});
// Source fields: direct_runtime/runoff_result_types.rs:476
captured_struct!(crate::direct_runtime::DirectRunoffPartitionInputs {
    liquid_input_m,
    runon_input_m,
    cumulative_infiltration_m,
    depression_storage_delta_m,
    surface_saturation_runoff_m,
    frost_retained_local_liquid_m,
    frost_preprojected_local_liquid_m
});
// Source fields: direct_runtime/runoff_result_types.rs:73
captured_struct!(crate::direct_runtime::DirectRunonCarryInputs {
    surface_runon_handoff_m,
    subsurface_carry_handoff_m
});
// Source fields: direct_runtime/runoff_result_types.rs:412
captured_struct!(crate::direct_runtime::DirectSaturationAddbackInputs {
    surface_saturation_runoff_handoff_m
});
// Source fields: direct_runtime/storage.rs:1355
captured_struct!(crate::direct_runtime::DirectSnowCouplingInputs {
    snow_coupling_handoff_m,
    snow_state_projected,
    active_snow_coupling,
    mass_transition_ledgers,
    hourly_routed_melt_m,
    sublimation_m,
    post_winter_rain_m,
    runtime_swe_after_m,
    runtime_depth_after_m,
    runtime_density_after_kg_m3,
    runtime_settle_day_count_after,
    coe_boundary_depth_after_m,
    coe_boundary_density_after_kg_m3,
    coe_boundary_settle_day_count_after,
    liquid_holding_capacity_after_m,
    liquid_water_retained_after_m,
    liquid_water_released_m,
    snow_albedo_state_after,
    snow_layers_after
});
// Source fields: winter_column.rs:44
captured_struct!(crate::winter_column::DirectSnowLayerState {
    mass_swe_m,
    thickness_m,
    density_kg_m3,
    settle_day_count,
    temperature_c,
    liquid_water_m,
    cold_content_j_m2,
    refrozen_liquid_m
});
// Source fields: hydrology/support_helpers_mod/snow_mass_transition.rs:49
captured_struct!(crate::hydrology::DirectSnowLiquidDispositionLedger {
    incoming_liquid_m,
    routed_liquid_m,
    retained_liquid_delta_m,
    refrozen_liquid_m,
    liquid_closure_residual_m
});
// Source fields: direct_runtime/00_core_frames.rs:172
captured_struct!(crate::direct_runtime::DirectSnowRuntimeCarry {
    runtime_swe_m,
    runtime_depth_m,
    runtime_density_kg_m3,
    runtime_settle_day_count,
    coe_boundary_depth_m,
    coe_boundary_density_kg_m3,
    coe_boundary_settle_day_count,
    liquid_water_retained_m,
    snow_albedo_state,
    layers
});
// Source fields: hydrology/support_helpers_mod/snow_mass_transition.rs:33
captured_struct!(crate::hydrology::DirectSnowSolidToLiquidLedger {
    raw_signed_melt_m,
    redistributed_positive_melt_m,
    snowpack_swe_loss_m,
    rain_released_m,
    liquid_handoff_m
});
// Source fields: hydrology/support_helpers_mod/snow_mass_transition.rs:65
captured_struct!(crate::hydrology::DirectSnowStage3Outcome {
    enabled,
    meltwater_temperature_c,
    sublimation_m
});
// Source fields: direct_runtime/normalization.rs:387
captured_struct!(crate::direct_runtime::DirectStorageBoundsInputs {
    storage_initial_m,
    total_accounted_input_m,
    closure_tolerance_m
});
// Source fields: direct_runtime/storage.rs:1093
captured_struct!(crate::direct_runtime::DirectStorageInputInputs {
    precip_input_handoff_m
});
// Source fields: direct_runtime/storage.rs:1602
captured_struct!(crate::direct_runtime::DirectStorageReconciliationInputs {
    storage_initial_m,
    precip_input_m,
    snow_coupling_m,
    frost_liquid_delta_m,
    runon_input_m,
    interception_m,
    evapotranspiration_m,
    evapotranspiration_storage_return_m,
    deep_seepage_m,
    subsurface_loss_m,
    closure_tolerance_m
});
// Source fields: direct_runtime/subsurface.rs:898
captured_struct!(crate::direct_runtime::DirectSubsurfaceComputeInputs {
    avg_slope,
    slope_length_m,
    lateral_anisotropy_ratio,
    soil_depth_m,
    solwpv_mode,
    mofe_hourly_carry_arrays_enabled,
    lane_substeps,
    drainage_capacity_m,
    drain_enabled,
    drain_depth_m,
    drain_spacing_m,
    drain_diameter_m,
    layers
});
// Source fields: direct_runtime/subsurface.rs:651
captured_struct!(crate::direct_runtime::DirectSubsurfaceLayerInputs {
    theta_m,
    field_capacity_m,
    upper_limit_m,
    conductivity_m_s,
    depth_m,
    residual_theta,
    frozen_depth_m,
    frozen_water_m,
    porosity,
    field_capacity_theta,
    coca,
    lateral_conductivity_m_s
});
// Source fields: direct_runtime/subsurface.rs:713
captured_struct!(crate::direct_runtime::DirectSubsurfaceLayerState {
    theta_m,
    field_capacity_m,
    upper_limit_m,
    conductivity_m_s,
    depth_m,
    residual_theta,
    frozen_depth_m,
    frozen_water_m,
    porosity,
    field_capacity_theta,
    coca,
    lateral_conductivity_m_s
});
// Source fields: direct_runtime/storage.rs:1227
captured_struct!(crate::direct_runtime::DirectSubsurfaceLossInputs {
    subsurface_loss_handoff_m
});
// Source fields: direct_runtime/02_state_reports.rs:73
captured_struct!(crate::direct_runtime::DirectTransferBuffers {
    surface_carry_m,
    surface_hourly_weights,
    lateral_carry_m,
    upstream_flow_m,
    subsurface_input_m
});
// Source fields: direct_runtime/erosion_continuity.rs:161
captured_struct!(crate::direct_runtime::DirectWave1ContinuityInputs {
    enabled,
    inter_ofe,
    enrichment,
    segments,
    peakro_m_s,
    runoff_depth_m,
    qin_m2_s,
    efflen_m,
    slplen_m,
    cntlen_m,
    rspace_m,
    width_m,
    field_width_m,
    effdrn_s,
    effdrr_s,
    kr_s_m,
    kradjf,
    shcrit_pa,
    tcadjf,
    detinr_kg_s_m2,
    shrsol_pa,
    tcend_kg_s_m,
    ktrato,
    veleff_m_s,
    beta,
    strldn,
    surface_frozen,
    theta_suppressed
});
// Source fields: direct_runtime/erosion_seed.rs:78
captured_struct!(crate::direct_runtime::DirectWave1OperandSeed {
    enabled,
    is_cropland,
    segments,
    slplen_m,
    efflen_m,
    cntlen_m,
    rspace_m,
    field_width_m,
    avg_slope,
    slpend,
    sand,
    ssasol,
    classes,
    veleff_m_s,
    baselines,
    kr_s_m,
    ki,
    shcrit_pa,
    hmax_m,
    flivmx,
    random_roughness_m,
    initial_daydis
});
// Source fields: direct_runtime/erosion_continuity.rs:112
captured_struct!(crate::direct_runtime::DirectWave1SlopeSegment { xu, xl, a, b });
// Source fields: direct_runtime/runoff_result_types.rs:349
captured_struct!(crate::direct_runtime::DirectWb14HyetographInterval {
    start_s,
    end_s,
    intensity_m_s
});
// Source fields: direct_runtime/runoff_result_types.rs:210
captured_struct!(
    crate::direct_runtime::DirectWb14InfiltrationProducerInputs {
        hyetograph,
        hourly_additional_supply_m,
        effective_conductivity_m_s,
        matric_potential_m,
        storage_capacity_m,
        depression_storage_capacity_m
    }
);
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1298
captured_struct!(crate::hydrology::DirectWinterFrostComputeInputs {
    controls,
    thermal,
    theta_residual,
    theta_field_capacity,
    soil_conductivity_m_s,
    layer_bulk_density_kg_m3,
    hourly
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1368
captured_struct!(crate::hydrology::DirectWinterFrostPartitionOutcome {
    active_frost_coupling,
    dthaw_after_m,
    nft_after,
    infcap_frz_m_s,
    soil_water_after_frwatc_m,
    frwatc_soil_water_before_m,
    frwatc_soil_water_after_m,
    frwatc_frozen_water_before_m,
    frwatc_frozen_water_after_m,
    frwatc_freeze_debit_m,
    frwatc_thaw_credit_m,
    frwatc_net_liquid_delta_m,
    frozen_water_after_m,
    frost_depth_after_m,
    thdp_after_m,
    tfrdp_after_m,
    tthawd_after_m,
    fgthwd_flag_after,
    total_fine_layer_count,
    conductivity_tilled_w_m_k,
    conductivity_untilled_w_m_k,
    conductivity_residue_w_m_k,
    shadow_total_water_before_m,
    shadow_total_water_after_m,
    shadow_wb_delta_m,
    shadow_frwatc_residual_m,
    watpdg_m,
    watbtm_m,
    layer_projection,
    layer_shadow_projection,
    fine_layer_projection
});
// Source fields: direct_runtime/erosion_adjustments.rs:72
captured_struct!(crate::direct_runtime::ErosionConsolidationBaselines {
    kicrat,
    krcrat,
    tccrat,
    bconsd
});
// Source fields: direct_runtime/erosion_operands.rs:144
captured_struct!(crate::direct_runtime::ErosionParticleClass {
    dia_m,
    spg,
    frac,
    fall_m_s,
    frcly,
    frslt,
    frsnd,
    frorg
});
// Source fields: hydrology/03_kernel_support_00_support_helpers.rs:1186
captured_struct!(crate::hydrology::FrostSeasonalTemperatureCurve {
    annual_mean_c,
    amplitude_c,
    phase_shift_days
});
// Source fields: hydrology/08_snow_albedo.rs:68
captured_enum!(crate::hydrology::SnowAlbedoModel {
    Brock2000TemperatureAgeV1
});
// Source fields: hydrology/08_snow_albedo.rs:89
captured_struct!(crate::hydrology::SnowAlbedoState {
    model,
    albedo,
    accumulated_positive_temperature_c_day
});
// Source fields: direct_runtime/erosion_enrichment.rs:45
captured_struct!(crate::direct_runtime::Wave1EnrichmentInputs {
    classes,
    tcf1,
    fidel,
    ssasol,
    inflow_fractions
});
// Source fields: direct_runtime/erosion_continuity.rs:134
captured_struct!(crate::direct_runtime::Wave1InterOfeContinuity {
    shrspv_pa,
    tcprev_kg_s_m,
    ktrprv,
    prior_shear_last,
    prior_transport_last
});

fn lane(value: &Value) -> Result<crate::DirectLaneConstructorInputs, String> {
    let water: [f64; 6] = field(value, "water")?;
    let winter_snow: crate::DirectSnowRuntimeCarry = field(value, "winter_snow")?;
    let winter_frost: crate::DirectFrostRuntimeCarry = field(value, "winter_frost")?;
    Ok(crate::DirectLaneConstructorInputs {
        lane_id: field(value, "lane_id")?,
        upstream_lane_id: field(value, "upstream_lane_id")?,
        downstream_lane_id: field(value, "downstream_lane_id")?,
        upstream_area_ratio: field(value, "upstream_area_ratio")?,
        area_m2: field(value, "area_m2")?,
        runoff_publication_q_scale: field(value, "runoff_publication_q_scale")?,
        runoff_publication_qofe_scale: field(value, "runoff_publication_qofe_scale")?,
        runoff_publication_efflen_m: field(value, "runoff_publication_efflen_m")?,
        runoff_publication_cumulative_length_m: field(
            value,
            "runoff_publication_cumulative_length_m",
        )?,
        runoff_publication_ofe_length_m: field(value, "runoff_publication_ofe_length_m")?,
        water: crate::DirectWaterState {
            soil_water_m: water[0],
            infiltration_m: water[1],
            runoff_m: water[2],
            evapotranspiration_m: water[3],
            drainage_m: water[4],
            lateral_flow_m: water[5],
        },
        transfer: field(value, "transfer")?,
        publication: field(value, "publication")?,
        subsurface_layers: field(value, "subsurface_layers")?,
        evapotranspiration_stage_state: field(value, "evapotranspiration_stage_state")?,
        plant_growth_state: field(value, "plant_growth_state")?,
        plant_water_stress: field(value, "plant_water_stress")?,
        winter_column: Box::new(crate::DirectWinterColumnState {
            snow: winter_snow.into(),
            frost: winter_frost.into(),
        }),
        snow_runtime_carry: field(value, "snow_runtime_carry")?,
        frost_runtime_carry: field(value, "frost_runtime_carry")?,
        day_inputs: field(value, "day_inputs")?,
    })
}

pub(super) fn restore(value: &Value) -> Result<crate::DirectRunConstructorInputs, String> {
    let identity = value
        .get("identity")
        .ok_or("constructor identity missing")?;
    let identity = crate::DirectRunIdentity::new(
        field(identity, "run_id")?,
        field(identity, "hillslope_id")?,
        field(identity, "lane_count")?,
        field(identity, "day_count")?,
    )
    .map_err(|error| error.to_string())?;
    let phase_plan = crate::DirectPhasePlan::default();
    let captured_ranks: Vec<usize> = field(value, "phase_plan_ranks")?;
    let canonical_ranks = phase_plan
        .phases()
        .iter()
        .map(|phase| phase.rank())
        .collect::<Vec<_>>();
    if captured_ranks != canonical_ranks {
        return Err("captured constructor phase plan differs from canonical ordered plan".into());
    }
    let lanes = value
        .get("lanes")
        .and_then(Value::as_array)
        .ok_or("constructor lanes missing")?
        .iter()
        .map(lane)
        .collect::<Result<Vec<_>, _>>()?;
    let restored = crate::DirectRunConstructorInputs {
        identity,
        lanes,
        phase_plan,
    };
    if super::capture_direct_run_constructor_inputs(&restored) != *value {
        return Err("constructor inverse canonical recapture mismatch".into());
    }
    Ok(restored)
}
