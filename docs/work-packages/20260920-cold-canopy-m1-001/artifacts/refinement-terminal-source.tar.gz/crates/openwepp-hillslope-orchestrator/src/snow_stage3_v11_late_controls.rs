//! Actual-entry lifecycle controls over the authenticated original operand bundle.
use super::*;
use crate::v9_real_consumer_shadow::{
    DirectV9RealConsumerError, DirectV10RealConsumerError,
    deferred_diagnostic_faults::{self as faults, Point, Progress},
};

pub(super) struct Context<'a> {
    pub native: &'a Value,
    pub soil: &'a crate::v9_real_consumer_shadow::DirectV10SoilThermalResidentV2,
    pub bootstrap: &'a crate::v9_real_consumer_shadow::DirectV10SoilThermalResidentV2,
    pub phase: &'a Value,
    pub lane_maps: &'a Value,
    pub clock: &'a CoupledClockStateV1,
    pub frame: &'a crate::DirectRunFrame,
    pub inputs: &'a crate::DirectRunConstructorInputs,
    pub surface: &'a crate::DirectSurfaceLiquidConfiguration,
    pub lse: &'a openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    pub frozen_lse: &'a openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
    pub provider: &'a crate::runtime_inputs::SnowFreeHalfHourStaticConfiguration,
    pub gsi: &'a AuthenticatedGsiPreimagesV1,
}

impl Context<'_> {
    fn snapshot(&self) -> Result<Vec<Vec<u8>>, String> {
        let frame = capture_direct_run_frame_dynamic(self.frame, self.inputs, self.surface)?;
        let inputs = capture_direct_run_constructor_inputs(self.inputs);
        [
            serde_json::to_vec(self.native),
            serde_json::to_vec(self.soil),
            serde_json::to_vec(self.bootstrap),
            serde_json::to_vec(self.phase),
            serde_json::to_vec(self.lane_maps),
            serde_json::to_vec(self.clock),
            serde_json::to_vec(&frame),
            serde_json::to_vec(&inputs),
        ]
        .into_iter()
        .map(|result| result.map_err(|error| error.to_string()))
        .collect()
    }

    fn mint(&self) -> Result<ValidatedDeferredContextV1, String> {
        ValidatedDeferredContextV1::mint(
            &DeferredContextOperandsV1 {
                native: self.native,
                soil: self.soil,
                clock: self.clock,
                phase: self.phase,
                lane_maps: self.lane_maps,
                bootstrap: self.bootstrap,
                frame: self.frame,
                inputs: self.inputs,
            },
            self.gsi.clone(),
            self.surface,
        )
    }

    fn attempt(
        &self,
        phase: &Value,
        slot: &mut Option<ValidatedDeferredContextV1>,
    ) -> Result<DirectV10RealConsumerShadow, DirectV10RealConsumerError> {
        DirectV10RealConsumerShadow::diagnostic_restore_native_consumer_with_deferred_composite_v1(
            self.native,
            self.soil.clone(),
            self.bootstrap.clone(),
            phase,
            self.lane_maps,
            self.clock,
            self.frame.clone(),
            self.surface,
            self.lse,
            self.frozen_lse,
            self.provider,
            std::sync::Arc::new(self.inputs.clone()),
            slot,
        )
    }
}

#[derive(Clone, Copy, Debug)]
enum Substitution {
    None,
    PriorReceipt,
    PreparedReceipt,
    PriorAndPrematurePosture,
}

struct Case {
    name: &'static str,
    substitution: Substitution,
    fault: Point,
    expected: &'static str,
    progress: Progress,
}

fn cases() -> [Case; 6] {
    [
        Case {
            name: "prior receipt before late projection fault",
            substitution: Substitution::PriorReceipt,
            fault: Point::LseProjection,
            expected: "deferred composite GSI prior/prepared custody",
            progress: Progress::default(),
        },
        Case {
            name: "prepared receipt before late projection fault",
            substitution: Substitution::PreparedReceipt,
            fault: Point::LseProjection,
            expected: "deferred composite GSI prior/prepared custody",
            progress: Progress::default(),
        },
        Case {
            name: "source-bound premature posture before receipt and late fault",
            substitution: Substitution::PriorAndPrematurePosture,
            fault: Point::LseProjection,
            expected: "deferred composite source-bound use",
            progress: Progress::default(),
        },
        Case {
            name: "failure after complete proof",
            substitution: Substitution::None,
            fault: Point::FullProof,
            expected: "injected after complete deferred proof",
            progress: Progress {
                full_proof: true,
                private_candidate: false,
                lse_projection: false,
            },
        },
        Case {
            name: "failure after private construction",
            substitution: Substitution::None,
            fault: Point::PrivateCandidate,
            expected: "injected after private native construction",
            progress: Progress {
                full_proof: true,
                private_candidate: true,
                lse_projection: false,
            },
        },
        Case {
            name: "failure after native LSE projection",
            substitution: Substitution::None,
            fault: Point::LseProjection,
            expected: "injected after complete native LSE projection",
            progress: Progress {
                full_proof: true,
                private_candidate: true,
                lse_projection: true,
            },
        },
    ]
}

fn assert_identity(
    result: Result<DirectV10RealConsumerShadow, DirectV10RealConsumerError>,
    expected: &str,
) {
    match result {
        Err(DirectV10RealConsumerError::Runtime(DirectV9RealConsumerError::Identity(actual))) => {
            assert_eq!(actual, expected);
        }
        Err(error) => panic!("wrong owning typed error: {error:?}; expected {expected}"),
        Ok(_) => panic!("unexpected constructor success; expected {expected}"),
    }
}

pub(super) fn run(context: &Context<'_>) -> Result<(), String> {
    let before = context.snapshot()?;
    for case in cases() {
        println!("late control starting: {}", case.name);
        let _fault_scope = faults::Scope::begin(case.fault);
        let mut token = context.mint()?;
        let mut phase = context.phase.clone();
        match case.substitution {
            Substitution::None => {}
            Substitution::PriorReceipt | Substitution::PriorAndPrematurePosture => {
                // Both are original, individually validated canonical receipts.
                // Substitution changes their semantic phase, not their encoding.
                token.prior_receipt = context.gsi.prepared_receipt.clone();
            }
            Substitution::PreparedReceipt => {
                token.prepared_receipt = context.gsi.prior_receipt.clone();
            }
        }
        if matches!(case.substitution, Substitution::PriorAndPrematurePosture) {
            phase["deferred_native_v2_soil_custody"]["posture"] =
                serde_json::json!("installable_capability");
        }
        let mut slot = Some(token);
        let gsi_before = crate::runtime_inputs::gsi_receipt_advance_audit_v1();
        let work_before = crate::direct_runtime::direct_runtime_audit_snapshot();
        assert_identity(context.attempt(&phase, &mut slot), case.expected);
        assert!(
            slot.is_none(),
            "attempt consumes capability on every outcome"
        );
        assert_eq!(faults::progress(), case.progress, "actual reached boundary");
        assert_identity(
            context.attempt(context.phase, &mut slot),
            "deferred composite capability consumed",
        );
        assert_eq!(
            context.snapshot()?,
            before,
            "every retained resident/bootstrap/native/phase/lane/clock/frame/input byte unchanged"
        );
        let gsi_after = crate::runtime_inputs::gsi_receipt_advance_audit_v1();
        let work_after = crate::direct_runtime::direct_runtime_audit_snapshot();
        assert_eq!(
            work_after.direct_compute_operations,
            work_before.direct_compute_operations
        );
        assert_eq!(
            work_after.direct_state_mutations,
            work_before.direct_state_mutations
        );
        assert_eq!(work_after.day_frame_commits, work_before.day_frame_commits);
        assert_eq!(
            work_after.publication_capture_runs,
            work_before.publication_capture_runs
        );
        println!(
            "late control PASS: {}; typed={}; progress={:?}; consumed=true; exact_rollback=true; frame_constructions={}; gsi_prepare={}; gsi_validate={}",
            case.name,
            case.expected,
            faults::progress(),
            work_after.run_frame_constructions - work_before.run_frame_constructions,
            gsi_after.prepare_advances - gsi_before.prepare_advances,
            gsi_after.validator_advances - gsi_before.validator_advances
        );
    }
    Ok(())
}
