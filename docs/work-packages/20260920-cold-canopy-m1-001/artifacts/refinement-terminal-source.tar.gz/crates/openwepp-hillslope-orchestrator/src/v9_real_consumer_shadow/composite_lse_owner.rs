//! Scientific encoding/validation of the shared policy14 component transport.
use crate::{DirectSurfaceLiquidError as Error, LseSurfaceEnthalpyOwnerEnvelopeV1};
pub(crate) use openwepp_coupled_time::Policy14LseOwnerTransport as CompositeLseOwnerV1;
use openwepp_land_surface_energy::{LandSurfaceEnergyState, LandSurfaceEnergyV3State};

pub(crate) fn composite_lse_bytes(
    authority: openwepp_coupled_time::Policy14RuntimeAuthority,
    active: &LandSurfaceEnergyState,
    native: &LandSurfaceEnergyV3State,
    exact: &LseSurfaceEnthalpyOwnerEnvelopeV1,
) -> Result<Vec<u8>, Error> {
    active
        .validate_schema()
        .map_err(|_| Error::Identity("composite active LSE schema"))?;
    let active_bytes =
        serde_json::to_vec(active).map_err(|_| Error::Schema("composite active encoding"))?;
    let native_bytes =
        serde_json::to_vec(native).map_err(|_| Error::Schema("composite native encoding"))?;
    let exact_bytes = exact
        .canonical_bytes()
        .map_err(|_| Error::Identity("composite exact encoding"))?;
    CompositeLseOwnerV1::new(authority, active_bytes, native_bytes, exact_bytes)
        .and_then(|value| value.canonical_bytes())
        .map_err(|_| Error::Identity("composite component transport"))
}

pub(crate) fn actual_runtime_authority(
    value: openwepp_land_surface_energy::CoveredColumnAuthority,
) -> openwepp_coupled_time::Policy14RuntimeAuthority {
    use openwepp_coupled_time::Policy14RuntimeAuthority as Wire;
    use openwepp_land_surface_energy::CoveredColumnAuthority as Actual;
    match value {
        Actual::HistoricalV8 => Wire::HistoricalV8,
        Actual::V10NonpositiveAssimilation => Wire::V10NonpositiveAssimilation,
        Actual::V11SnowCovered => Wire::V11SnowCovered,
    }
}
