use std::{cell::Cell, collections::BTreeMap, rc::Rc};

use openwepp_coupled_time::{
    CoupledClockStateV1, Digest32, EventClass, EventProposalV1, EventQueueV1, LedgerEntryV1,
    ParentCommitCandidateV1, commit_parent, complete_owner_set_digest,
};
use openwepp_kernel_contract::{ResourceOwnerId, SoilLayerId, TransactionId};
use openwepp_land_surface_energy::{
    M1ColumnLiquidRoutingInput, M1CoupledColumnInput, M1CoupledError, M1CoupledEvaluation,
    M1RoutingOccupancyInput, ParcelId, Sha256Digest,
};
use sha2::{Digest, Sha256};

use super::{
    EndpointFixture, ExecuteV8LseRuntimeShadowError, LandSurfaceEnergyRealHydrologyAdapter,
    UnifiedRealHydrologyCandidate,
};
use crate::{
    DirectCanopyLiquidRelease, DirectIngressAmount, DirectOfeWb14Parameters,
    DirectOpenLiquidIngressParcel, DirectSurfaceLiquidIngressInput, DirectSurfaceLiquidParcelKind,
    DirectTileGroundIngress,
    vegetation_real_hydrology_shadow::{
        RealHydrologyLaneLayerMap, RealHydrologyOfeLaneId, RealHydrologyShadowAdapter,
    },
};

// The endpoint source is a frozen provider dependency. These private trait
// implementations retain one immutable bootstrap without changing its bytes.
impl Clone for EndpointFixture {
    fn clone(&self) -> Self {
        Self {
            vegetation_configuration: self.vegetation_configuration.clone(),
            vegetation_state: self.vegetation_state.clone(),
            surface_configuration: self.surface_configuration.clone(),
            frame: self.frame.clone(),
            hydrology: self.hydrology.clone(),
            lse_configuration: self.lse_configuration.clone(),
            lse_state: self.lse_state.clone(),
            forcing: self.forcing.clone(),
            thermal: self.thermal.clone(),
            receipt: self.receipt.clone(),
            biogeochemistry: self.biogeochemistry.clone(),
        }
    }
}
impl std::fmt::Debug for EndpointFixture {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("EndpointFixture")
            .field("vegetation_configuration", &self.vegetation_configuration)
            .field("vegetation_state", &self.vegetation_state)
            .field("surface_configuration", &self.surface_configuration)
            .field("frame", &self.frame)
            .field("hydrology", &self.hydrology)
            .field("lse_configuration", &self.lse_configuration)
            .field("lse_state", &self.lse_state)
            .field("forcing", &self.forcing)
            .field("thermal", &self.thermal)
            .field("receipt", &self.receipt)
            .field("biogeochemistry", &self.biogeochemistry)
            .finish()
    }
}
impl PartialEq for EndpointFixture {
    fn eq(&self, other: &Self) -> bool {
        self.vegetation_configuration == other.vegetation_configuration
            && self.vegetation_state == other.vegetation_state
            && self.surface_configuration == other.surface_configuration
            && self.frame == other.frame
            && self.hydrology == other.hydrology
            && self.lse_configuration == other.lse_configuration
            && self.lse_state == other.lse_state
            && self.forcing == other.forcing
            && self.thermal == other.thermal
            && self.receipt == other.receipt
            && self.biogeochemistry == other.biogeochemistry
    }
}

struct FullNitrogen(Cell<u32>);
impl openwepp_vegetation::NitrogenArbiter for FullNitrogen {
    fn beginning_amount(
        &self,
        _: &openwepp_kernel_contract::MineralNitrogenKey,
    ) -> Result<f64, openwepp_vegetation::VegetationError> {
        Ok(1.0)
    }
    fn authorize(
        &self,
        requests: &[openwepp_vegetation::NitrogenRequest],
    ) -> Result<Vec<openwepp_vegetation::NitrogenAuthorization>, openwepp_vegetation::VegetationError>
    {
        self.0.set(self.0.get() + 1);
        Ok(requests
            .iter()
            .map(|r| openwepp_kernel_contract::MaximumAuthorization {
                transaction_id: r.transaction_id,
                owner_id: r.owner_id.clone(),
                key: r.key.clone(),
                amount: r.amount,
                basis: r.basis,
            })
            .collect())
    }
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1PrescribedRoutingControl {
    input: M1ColumnLiquidRoutingInput,
}
impl M1PrescribedRoutingControl {
    pub(crate) fn new(
        input: M1ColumnLiquidRoutingInput,
    ) -> Result<Self, openwepp_land_surface_energy::LandSurfaceEnergyError> {
        Ok(Self { input })
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1PreparedCallerContext {
    input: M1CoupledColumnInput,
    evaluation: M1CoupledEvaluation,
    accepted_plant_area_m2_m2_tile: [f64; 2],
}
impl M1PreparedCallerContext {
    fn persistent_forcing(
        &self,
        _beginning: &openwepp_vegetation::cold_canopy_m1_owner::M1OwnerState,
        configuration: &openwepp_vegetation::VegetationConfiguration,
    ) -> Result<
        openwepp_vegetation::cold_canopy_m1_owner::M1PersistentForcing,
        M1ReceiverDiagnosticError,
    > {
        let expected_layers = configuration
            .strata
            .iter()
            .flat_map(|stratum| stratum.root_layers.iter())
            .map(|root| root.layer_id.clone())
            .collect::<std::collections::BTreeSet<_>>();
        let soil_temperature_k_by_layer = self
            .input
            .column
            .ground
            .soil_nodes
            .iter()
            .filter(|node| {
                expected_layers
                    .iter()
                    .any(|layer| layer.as_str() == node.layer_id)
            })
            .map(|node| {
                let layer_id = SoilLayerId::try_new(node.layer_id.clone())
                    .map_err(|_| m1_owner_identity_error())?;
                if !node.beginning_temperature_k.is_finite() || node.beginning_temperature_k <= 0.0
                {
                    return Err(m1_owner_identity_error());
                }
                Ok((layer_id, node.beginning_temperature_k))
            })
            .collect::<Result<BTreeMap<_, _>, _>>()?;
        Ok(
            openwepp_vegetation::cold_canopy_m1_owner::M1PersistentForcing {
                air_temperature_k: self.input.column.air_temperature_k,
                // The current support forcing is supplied by the caller at
                // candidate construction. Historical per-stratum GSI remains
                // state for its own persistent-history role.
                gsi: 0.0,
                soil_temperature_k_by_layer,
                duration_s: self.evaluation.support_duration_s(),
            },
        )
    }

    fn construct_m1_owner_candidate(
        &self,
        configuration: &openwepp_vegetation::VegetationConfiguration,
        beginning: &openwepp_vegetation::cold_canopy_m1_owner::M1OwnerState,
        biogeochemistry: &openwepp_biogeochemistry::BiogeochemistryState,
        forcing: &openwepp_vegetation::cold_canopy_m1_owner::M1PersistentForcing,
        support_transaction_id: TransactionId,
    ) -> Result<
        openwepp_vegetation::cold_canopy_m1_owner::M1ParentSegmentCandidate,
        M1ReceiverDiagnosticError,
    > {
        use openwepp_vegetation::cold_canopy_m1_owner::{
            M1AcceptedStratumResult, M1OwnerReservoir, construct_parent_segment_candidate,
        };

        let accepted = configuration
            .strata
            .iter()
            .map(|stratum| {
                let occupancy_ids = stratum
                    .tile_ids
                    .iter()
                    .map(|tile| format!("{}::{}", stratum.stratum_id.as_str(), tile.as_str()))
                    .filter(|id| {
                        self.input
                            .column
                            .occupancies
                            .iter()
                            .any(|row| row.occupancy_id == *id)
                    })
                    .collect::<Vec<_>>();
                if occupancy_ids.len() != 1 {
                    return Err(m1_owner_identity_error());
                }
                let occupancy_id = occupancy_ids
                    .into_iter()
                    .next()
                    .ok_or_else(m1_owner_identity_error)?;
                let tile_id = stratum
                    .tile_ids
                    .iter()
                    .find(|tile| {
                        occupancy_id
                            == format!("{}::{}", stratum.stratum_id.as_str(), tile.as_str())
                    })
                    .ok_or_else(m1_owner_identity_error)?;
                let occupancy_fraction = configuration
                    .topology_tiles
                    .iter()
                    .find(|tile| tile.tile_id == *tile_id)
                    .map(|tile| tile.fraction)
                    .ok_or_else(m1_owner_identity_error)?;
                let input = self
                    .input
                    .column
                    .occupancies
                    .iter()
                    .find(|row| row.occupancy_id == occupancy_id)
                    .ok_or_else(m1_owner_identity_error)?;
                let evaluation = self
                    .evaluation
                    .occupancy(&occupancy_id)
                    .map_err(|_| m1_owner_identity_error())?;
                let reservoir_index = self
                    .input
                    .reservoirs
                    .iter()
                    .position(|item| item.occupancy_id == occupancy_id)
                    .ok_or_else(m1_owner_identity_error)?;
                let reservoir = self
                    .evaluation
                    .reservoir_operands()
                    .get(reservoir_index)
                    .ok_or_else(m1_owner_identity_error)?;
                Ok(M1AcceptedStratumResult {
                    stratum_id: stratum.stratum_id.clone(),
                    occupancy_id,
                    plant_area_m2_m2_tile: input.lai + input.sai,
                    occupancy_fraction,
                    sun_leaf_area_m2_m2_tile: input.sun.leaf_area_m2_m2_tile,
                    shade_leaf_area_m2_m2_tile: input.shade.leaf_area_m2_m2_tile,
                    sun_gross_umol_m2_leaf_s: evaluation.sun.gross_assimilation,
                    shade_gross_umol_m2_leaf_s: evaluation.shade.gross_assimilation,
                    sun_net_umol_m2_leaf_s: evaluation.sun.net_assimilation,
                    shade_net_umol_m2_leaf_s: evaluation.shade.net_assimilation,
                    sun_dark_respiration_umol_m2_leaf_s: evaluation.sun.dark_respiration,
                    shade_dark_respiration_umol_m2_leaf_s: evaluation.shade.dark_respiration,
                    root_use_kg_m2_tile: evaluation
                        .hydraulics
                        .all_root_fluxes_kg_m2_tile_s
                        .iter()
                        .sum::<f64>()
                        * self.evaluation.support_duration_s(),
                    captured_incident_liquid_kg_m2_tile: reservoir.incident_liquid_kg_m2_s
                        * reservoir.dt_s,
                })
            })
            .collect::<Result<Vec<_>, M1ReceiverDiagnosticError>>()?;
        let ending_reservoirs = self
            .input
            .reservoirs
            .iter()
            .zip(self.evaluation.reservoir_operands())
            .map(|(input, ending)| {
                M1OwnerReservoir::try_new(
                    input.occupancy_id.clone(),
                    ending.ending_mass_kg_m2,
                    ending.ending_enthalpy_j_m2,
                )
                .map_err(|_| m1_owner_identity_error())
            })
            .collect::<Result<Vec<_>, _>>()?;
        let arbiter = crate::v9_real_consumer_shadow::BiogeochemistryNitrogenArbiter::try_new(
            biogeochemistry,
        )
        .map_err(|_| m1_owner_identity_error())?;
        construct_parent_segment_candidate(
            configuration,
            beginning,
            support_transaction_id,
            ending_reservoirs,
            accepted,
            forcing,
            &arbiter,
        )
        .map_err(|_| m1_owner_identity_error())
    }
    /// Bind caller input to the accepted evaluation minted by the solver.
    /// An evaluation is not a capability merely because its individual
    /// operands are well formed: it retains the complete materialized input,
    /// so this boundary does not replay physiology.
    pub(crate) fn new(
        input: M1CoupledColumnInput,
        evaluation: M1CoupledEvaluation,
    ) -> Result<Self, M1CoupledError> {
        if !evaluation.is_bound_to(&input) {
            return Err(M1CoupledError::LandSurfaceEnergy(
                openwepp_land_surface_energy::LandSurfaceEnergyError::UnsupportedDomain(
                    "m1_prepared_context",
                ),
            ));
        }
        let accepted_plant_area_m2_m2_tile = [
            input.column.occupancies[0].lai + input.column.occupancies[0].sai,
            input.column.occupancies[1].lai + input.column.occupancies[1].sai,
        ];
        Ok(Self {
            input,
            evaluation,
            accepted_plant_area_m2_m2_tile,
        })
    }
}

fn m1_owner_identity_error() -> M1ReceiverDiagnosticError {
    M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
        rejected_candidate: None,
    }
}

impl M1PreparedCallerContext {
    fn actual_routing_control(
        &self,
    ) -> Result<M1PrescribedRoutingControl, M1ReceiverDiagnosticError> {
        let rows = &self.input.column.occupancies;
        let reservoirs = self.evaluation.reservoir_operands();
        if rows.len() != 2 || reservoirs.len() != 2 {
            return Err(M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Topology),
                rejected_candidate: None,
            });
        }
        let row = |index: usize| -> Result<M1RoutingOccupancyInput, M1ReceiverDiagnosticError> {
            let state = &reservoirs[index];
            // Route raw top forcing once at the upper occupancy.  The M1
            // evaluator's incident operand is already captured flow, so it
            // must never be fed back through interception here.
            let initial_drainage_enthalpy_j_kg = if state.drainage_kg_m2_s > 0.0 {
                let wet_temperature = state.wet_temperature_k.ok_or(M1ReceiverDiagnosticError {
                    injection: None,
                    source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                    rejected_candidate: None,
                })?;
                4218.0 * (wet_temperature - 273.15)
            } else {
                state.incident_enthalpy_j_kg
            };
            Ok(M1RoutingOccupancyInput {
                occupancy_id: rows[index].occupancy_id.clone(),
                plant_area_m2_m2_tile: rows[index].lai + rows[index].sai,
                incident_mass_kg_m2_tile: if index == 0 {
                    self.input.column.top_rain_kg_m2_tile
                } else {
                    0.0
                },
                incident_enthalpy_j_kg: if index == 0 && self.input.column.top_rain_kg_m2_tile > 0.0
                {
                    self.input.top_liquid_specific_enthalpy_j_kg.ok_or(
                        M1ReceiverDiagnosticError {
                            injection: None,
                            source: M1ReceiverDiagnosticSource::Context(
                                M1ReceiverContextError::Identity,
                            ),
                            rejected_candidate: None,
                        },
                    )?
                } else {
                    0.0
                },
                interception_fraction: rows[index].liquid_interception_fraction,
                stemflow_fraction: rows[index].stemflow_fraction,
                initial_drainage_mass_kg_m2_tile: state.drainage_kg_m2_s * state.dt_s,
                initial_drainage_enthalpy_j_kg,
                second_drainage_mass_kg_m2_tile: 0.0,
                second_drainage_enthalpy_j_kg: 0.0,
            })
        };
        M1ColumnLiquidRoutingInput::new(row(0)?, row(1)?, self.input.column.tile_fraction)
            .map(M1PrescribedRoutingControl::new)
            .and_then(|result| result)
            .map_err(|source| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Routing(source),
                rejected_candidate: None,
            })
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1CallerOwners {
    reservoirs: Vec<(String, f64, f64)>,
    frame: crate::DirectRunFrame,
    hydrology: RealHydrologyShadowAdapter,
    lse: openwepp_land_surface_energy::LandSurfaceEnergyState,
    vegetation: openwepp_vegetation::V8CoupledOwnedState,
    m1_configuration: openwepp_vegetation::VegetationConfiguration,
    m1_vegetation: openwepp_vegetation::cold_canopy_m1_owner::M1OwnerState,
    thermal: super::V8SoilThermalPhysicalBeginning,
    biogeochemistry: openwepp_biogeochemistry::BiogeochemistryState,
    accepted_cursor: u64,
    surface_configuration: crate::DirectSurfaceLiquidConfiguration,
    snow_owner_bytes: Vec<u8>,
    accepted_support_evidence: Vec<M1AcceptedSupportEvidence>,
    /// Last validated custody transition set, retained only through this live parent.
    prior_shared_resource_transitions:
        Vec<openwepp_vegetation::v11::V11SharedResourceOwnerTransition>,
    /// One exact typed resource transition set for every accepted support in
    /// the live parent. This is bounded by the fixed thirty-support parent and
    /// is consumed only after parent-finalization joins succeed.
    accepted_resource_transition_sets: Vec<M1ResourceCustodyBundle>,
}
#[derive(Clone, Debug, PartialEq, serde::Serialize)]
pub(crate) struct M1ResourceCustodyBundle {
    pub(crate) slab: openwepp_coupled_time::AcceptedSlabReceiptV1,
    pub(crate) debits: Vec<openwepp_vegetation::v11::V11ResourceDebit>,
    pub(crate) fluxes: Vec<openwepp_vegetation::v11::V11AdmittedResourceFlux>,
    pub(crate) transitions: Vec<openwepp_vegetation::v11::V11SharedResourceOwnerTransition>,
    pub(crate) candidates: Vec<openwepp_vegetation::v11::V11CompleteOwnerCandidate>,
    pub(crate) ending_owner_states: Vec<openwepp_coupled_time::OwnerState>,
}
/// Bounded parent-local producer evidence.  It is assembled at the same seam
/// that stages real owners; no fixture reconstruction or post-hoc balance
/// report is permitted here.
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1AcceptedSupportEvidence {
    pub(crate) support_transaction_id: TransactionId,
    pub(crate) m1_candidate: openwepp_vegetation::cold_canopy_m1_owner::M1ParentSegmentCandidate,
    pub(crate) bgc_candidate: openwepp_biogeochemistry::BiogeochemistryOwnerCandidate,
    pub(crate) reservoir_operands: Vec<openwepp_land_surface_energy::M1ReservoirOperands>,
    pub(crate) native_receiver: Option<UnifiedRealHydrologyCandidate>,
    pub(crate) m1_configuration: openwepp_vegetation::VegetationConfiguration,
    /// Exact support endpoints retained from the installed production adapter.
    /// The native closure operands begin after root debits and cannot replace these.
    pub(crate) beginning_hydrology: RealHydrologyShadowAdapter,
    pub(crate) ending_hydrology: RealHydrologyShadowAdapter,
    pub(crate) native_consumed_forcing_bits: [u64; 10],
    pub(crate) beginning_thermal_sha256: Sha256Digest,
    pub(crate) ending_thermal_sha256: Sha256Digest,
    pub(crate) prepared_soil_temperature_bits: Vec<u64>,
    pub(crate) prepared_soil_temperature_by_layer: BTreeMap<String, u64>,
    pub(crate) bgc_parent_predecessor: u128,
    /// Private digest of the actual terminal ingress receipts. It binds the
    /// M1-only flux adapter to native lineage without changing the V11 wire.
    pub(crate) native_receipt_proof: Digest32,
}
/// The canonical BGC constructor validates a support-scoped candidate.  This
/// wrapper retains that validated physical candidate while presenting the
/// parent predecessor in persistent owner bytes until the one consuming
/// parent finalization.  It is deliberately not a mutable candidate rewrite.
#[derive(Clone, Debug, PartialEq)]
struct M1StagedParentBiogeochemistry {
    physical: openwepp_biogeochemistry::BiogeochemistryOwnerCandidate,
    parent_predecessor: u128,
}
impl M1StagedParentBiogeochemistry {
    fn try_new(
        physical: openwepp_biogeochemistry::BiogeochemistryOwnerCandidate,
        parent_predecessor: u128,
    ) -> Result<Self, M1ReceiverDiagnosticError> {
        physical.validate().map_err(|_| m1_owner_identity_error())?;
        if physical.beginning().last_transaction_id != parent_predecessor {
            return Err(m1_owner_identity_error());
        }
        Ok(Self {
            physical,
            parent_predecessor,
        })
    }
    fn staged_ending(&self) -> openwepp_biogeochemistry::BiogeochemistryState {
        let mut ending = self.physical.ending().clone();
        ending.last_transaction_id = self.parent_predecessor;
        ending
    }
    fn physical(&self) -> &openwepp_biogeochemistry::BiogeochemistryOwnerCandidate {
        &self.physical
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1CallerState {
    owners: M1CallerOwners,
    staged: Option<M1CallerOwners>,
    parent_clock: Option<CoupledClockStateV1>,
    // This is caller-owned continuity, rather than a property inferred from
    // a transient parent clock.  It prevents a later parent from switching
    // the admitted fixed diagnostic run or cycle.
    provider_run_identity: Option<[u8; 32]>,
    provider_cycle_ordinal: Option<u32>,
    parent_publication_count: u64,
    /// Exact seven-owner state sealed by the accepted parent finalization event.
    sealed_finalized_owners: Option<Vec<openwepp_coupled_time::OwnerState>>,
    durable_parent_commit: Option<openwepp_coupled_time::ParentCommitV1>,
    /// Immutable authority/configuration captured once at caller construction.
    native_bootstrap: EndpointFixture,
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) enum M1CallerSupportResult {
    ZeroTransfer,
    PositiveTransfer(M1ReceiverDiagnosticResult),
}
impl M1CallerState {
    fn beginning_from_validated_reservoirs(
        fixture: &EndpointFixture,
        reservoirs: Vec<(String, f64, f64)>,
    ) -> Result<Self, M1ReceiverDiagnosticError> {
        let thermal = super::V8SoilThermalPhysicalBeginning::try_from_v1(&fixture.thermal)
            .map_err(|_| m1_owner_identity_error())?;
        let mut m1_configuration = fixture.vegetation_configuration.clone();
        m1_configuration.model_definition_sha256 =
            "60792c5fd1e5e3a09a9e4cfaa08673bd0c61ff3c86fa098155785606ff043328".to_owned();
        m1_configuration.configuration_sha256 = m1_configuration
            .canonical_sha256()
            .map_err(|_| m1_owner_identity_error())?;
        let m1_vegetation = openwepp_vegetation::cold_canopy_m1_owner::M1OwnerState::try_new(
            &m1_configuration,
            "OPENWEPP_C3_WOODY_COLD_M1_V1".to_owned(),
            m1_configuration.model_definition_sha256.clone(),
            u64::try_from(fixture.vegetation_state.last_transaction_id)
                .map_err(|_| m1_owner_identity_error())?,
            reservoirs
                .iter()
                .map(|(occupancy_id, mass, enthalpy)| {
                    openwepp_vegetation::cold_canopy_m1_owner::M1OwnerReservoir::try_new(
                        occupancy_id.clone(),
                        *mass,
                        *enthalpy,
                    )
                })
                .collect::<Result<Vec<_>, _>>()
                .map_err(|_| m1_owner_identity_error())?,
            fixture.vegetation_state.strata.clone(),
        )
        .map_err(|_| m1_owner_identity_error())?;
        let state = crate::hydrology::Wb11HydrologyKernel::initialize_stage3_persistent_state(
            1,
            Vec::new(),
        )
        .map_err(|_| m1_owner_identity_error())?;
        let mut lanes = BTreeMap::new();
        lanes.insert(1_u32, state);
        let snow_owner_bytes =
            crate::v9_real_consumer_shadow::canonical_stage3_snow_owner_bytes_v11(&lanes)
                .map_err(|_| m1_owner_identity_error())?;
        Ok(Self {
            owners: M1CallerOwners {
                reservoirs,
                frame: fixture.frame.clone(),
                hydrology: fixture.hydrology.clone(),
                lse: fixture.lse_state.clone(),
                vegetation: fixture.vegetation_state.clone(),
                m1_configuration,
                m1_vegetation,
                thermal,
                biogeochemistry: fixture.biogeochemistry.clone(),
                accepted_cursor: 0,
                surface_configuration: fixture.surface_configuration.clone(),
                snow_owner_bytes,
                accepted_support_evidence: Vec::new(),
                prior_shared_resource_transitions: Vec::new(),
                accepted_resource_transition_sets: Vec::new(),
            },
            staged: None,
            parent_clock: None,
            provider_run_identity: None,
            provider_cycle_ordinal: None,
            parent_publication_count: 0,
            sealed_finalized_owners: None,
            durable_parent_commit: None,
            native_bootstrap: fixture.clone(),
        })
    }
    pub(crate) fn beginning_from_provider_reservoirs(
        fixture: &EndpointFixture,
        reservoirs: Vec<(String, f64, f64)>,
    ) -> Result<Self, M1ReceiverDiagnosticError> {
        Self::beginning_from_validated_reservoirs(fixture, reservoirs)
    }
    pub(crate) fn provider_seven_beginning_owner_bytes(
        &self,
    ) -> Result<BTreeMap<String, Vec<u8>>, M1ReceiverDiagnosticError> {
        let mut owners =
            Self::canonical_complete_owner_bytes(&self.owners, &self.owners.surface_configuration)?;
        owners.insert("snow".to_owned(), self.owners.snow_owner_bytes.clone());
        Ok(owners)
    }
    /// Complete, ordered owner bytes for the private M1 adapter.  These carry
    /// actual owner state, not identifiers or diagnostic digests.
    fn canonical_complete_owner_bytes(
        owners: &M1CallerOwners,
        surface_configuration: &crate::DirectSurfaceLiquidConfiguration,
    ) -> Result<BTreeMap<String, Vec<u8>>, M1ReceiverDiagnosticError> {
        let surface = owners
            .frame
            .surface_liquid_shadow
            .as_ref()
            .ok_or_else(m1_owner_identity_error)?;
        // M1 is admitted before a WB14 parent exists, so the actual working
        // state is `None`; the shared V11 encoder still retains that field in
        // the complete-owner projection.
        let surface_bytes =
            crate::v9_real_consumer_shadow::canonical_surface_liquid_complete_owner_projection_v2(
                surface,
                surface_configuration,
                None,
            )
            .map_err(|_| m1_owner_identity_error())?;
        let thermal_bytes = owners
            .thermal
            .canonical_active_owner_bytes()
            .map_err(|_| m1_owner_identity_error())?;
        let mut result = BTreeMap::new();
        result.insert(
            "bgc".to_owned(),
            serde_json::to_vec(&owners.biogeochemistry).map_err(|_| m1_owner_identity_error())?,
        );
        result.insert(
            "hydrology".to_owned(),
            crate::v9_real_consumer_shadow::canonical_hydrology_owner_bytes_v1(&owners.frame)
                .map_err(|_| m1_owner_identity_error())?,
        );
        result.insert(
            "land_surface_energy".to_owned(),
            serde_json::to_vec(&owners.lse).map_err(|_| m1_owner_identity_error())?,
        );
        result.insert("soil_thermal".to_owned(), thermal_bytes);
        result.insert("surface_liquid".to_owned(), surface_bytes);
        result.insert(
            "vegetation".to_owned(),
            serde_json::to_vec(&owners.m1_vegetation).map_err(|_| m1_owner_identity_error())?,
        );
        Ok(result)
    }
    pub(crate) fn accepted_cursor(&self) -> u64 {
        self.current_owners().accepted_cursor
    }
    /// Actual current M1 reservoirs supplied to the next fixed support solve.
    /// These are caller-owned state, never retained fixture initials.
    pub(crate) fn provider_current_reservoirs(&self) -> &[(String, f64, f64)] {
        &self.current_owners().reservoirs
    }
    pub(crate) fn provider_native_bootstrap(&self) -> &EndpointFixture {
        &self.native_bootstrap
    }
    /// Project the actual staged thermal owner into the next M1 column.  The
    /// fixed provider owns the column construction, but it must never revive
    /// the bootstrap temperatures after a native support has been staged.
    pub(crate) fn provider_current_soil_temperatures(
        &self,
    ) -> Result<BTreeMap<String, f64>, M1ReceiverDiagnosticError> {
        let super::V8SoilThermalPhysicalBeginning::V1(snapshot) = &self.current_owners().thermal
        else {
            return Err(m1_owner_identity_error());
        };
        let mut temperatures = BTreeMap::new();
        for layer in snapshot
            .ofes
            .iter()
            .flat_map(|ofe| ofe.ordered_layers.iter())
        {
            let prior =
                temperatures.insert(layer.layer_id.as_str().to_owned(), layer.temperature_k);
            if prior.is_some() {
                return Err(m1_owner_identity_error());
            }
        }
        Ok(temperatures)
    }
    pub(crate) fn provider_parent_clock(&self) -> Option<&CoupledClockStateV1> {
        self.parent_clock.as_ref()
    }
    pub(crate) fn provider_matches_admitted_support(
        &self,
        run_identity: [u8; 32],
        cycle_ordinal: u32,
        parent_ordinal: u32,
        record_ordinal: u32,
        start_ns: u128,
        end_ns: u128,
    ) -> bool {
        let Some(clock) = self.parent_clock.as_ref() else {
            return false;
        };
        self.provider_run_identity == Some(run_identity)
            && self.provider_cycle_ordinal == Some(cycle_ordinal)
            && self.current_owners().accepted_cursor / 30 == u64::from(parent_ordinal)
            && record_ordinal
                == parent_ordinal.saturating_mul(30)
                    + (self.current_owners().accepted_cursor % 30) as u32
            && clock.accepted_until().get() == start_ns
            && clock.parent_support().start_ns().get()
                == u128::from(parent_ordinal) * 1_800_000_000_000
            && clock.parent_support().end_ns().get()
                == u128::from(parent_ordinal + 1) * 1_800_000_000_000
            && end_ns == start_ns + 60_000_000_000
    }
    pub(crate) fn provider_replace_parent_clock(&mut self, clock: CoupledClockStateV1) {
        self.parent_clock = Some(clock);
    }
    pub(crate) fn provider_current_owner_bytes(
        &self,
    ) -> Result<BTreeMap<String, Vec<u8>>, M1ReceiverDiagnosticError> {
        let mut owners = Self::canonical_complete_owner_bytes(
            self.current_owners(),
            &self.current_owners().surface_configuration,
        )?;
        owners.insert(
            "snow".to_owned(),
            self.current_owners().snow_owner_bytes.clone(),
        );
        Ok(owners)
    }
    pub(crate) fn provider_last_accepted_support_evidence(
        &self,
    ) -> Option<&M1AcceptedSupportEvidence> {
        self.current_owners().accepted_support_evidence.last()
    }
    pub(crate) fn provider_admitted_owner_count(&self) -> Option<usize> {
        self.parent_clock.as_ref().map(|clock| clock.owners().len())
    }
    pub(crate) fn provider_has_staged_owner(&self) -> bool {
        self.staged.is_some()
    }
    pub(crate) fn provider_parent_publication_count(&self) -> u64 {
        self.parent_publication_count
    }
    pub(crate) fn provider_parent_revision(&self) -> u64 {
        self.current_owners().m1_vegetation.revision()
    }
    pub(crate) fn provider_sealed_finalized_owners(
        &self,
    ) -> Option<&[openwepp_coupled_time::OwnerState]> {
        self.sealed_finalized_owners.as_deref()
    }
    pub(crate) fn provider_parent_transaction_namespace(&self) -> Option<u128> {
        self.parent_clock.as_ref().map(|clock| {
            let mut leading = [0_u8; 16];
            leading.copy_from_slice(&clock.parent_transaction_id().digest().as_bytes()[..16]);
            u128::from_be_bytes(leading)
        })
    }
    pub(crate) fn provider_next_support_transaction_id(&self) -> Option<TransactionId> {
        self.parent_clock.as_ref().map(|_| {
            TransactionId((1_u128 << 127) | u128::from(self.current_owners().accepted_cursor))
        })
    }
    pub(crate) fn provider_active_material_transfers(
        &self,
    ) -> Vec<openwepp_vegetation::carbon_nitrogen::MaterialTransfer> {
        self.current_owners()
            .accepted_support_evidence
            .iter()
            .flat_map(|evidence| evidence.m1_candidate.material_proposals().iter().cloned())
            .collect()
    }
    pub(crate) fn provider_parent_material_transfers(
        &self,
    ) -> Result<
        Vec<openwepp_vegetation::carbon_nitrogen::MaterialTransfer>,
        M1ReceiverDiagnosticError,
    > {
        self.canonical_parent_material_transfers(self.current_owners())
    }
    fn canonical_parent_material_transfers(
        &self,
        owners: &M1CallerOwners,
    ) -> Result<
        Vec<openwepp_vegetation::carbon_nitrogen::MaterialTransfer>,
        M1ReceiverDiagnosticError,
    > {
        let next = u128::from(
            owners
                .m1_vegetation
                .revision()
                .checked_add(1)
                .ok_or_else(m1_owner_identity_error)?,
        );
        let mut values = owners
            .accepted_support_evidence
            .iter()
            .flat_map(|evidence| evidence.m1_candidate.material_proposals().iter().cloned())
            .collect::<Vec<_>>();
        for (index, value) in values.iter_mut().enumerate() {
            value.transaction_id = next;
            value.proposal_id = u64::try_from(index)
                .ok()
                .and_then(|value| value.checked_add(1))
                .ok_or_else(m1_owner_identity_error)?;
        }
        Ok(values)
    }
    pub(crate) fn provider_matches_initial_phase(
        &self,
        expected: &BTreeMap<String, (u64, u64)>,
    ) -> bool {
        self.accepted_cursor() == 0
            && self.parent_clock.is_none()
            && self.staged.is_none()
            && self
                .owners
                .reservoirs
                .iter()
                .map(|(occupancy, mass, enthalpy)| {
                    (occupancy.clone(), (mass.to_bits(), enthalpy.to_bits()))
                })
                .collect::<BTreeMap<_, _>>()
                == *expected
    }
    pub(crate) fn provider_active_participants(&self) -> Option<&[String]> {
        self.parent_clock
            .as_ref()
            .map(|clock| clock.active_participants())
    }
    pub(crate) fn ending_frame(&self) -> &crate::DirectRunFrame {
        &self.current_owners().frame
    }
    fn current_owners(&self) -> &M1CallerOwners {
        self.staged.as_ref().unwrap_or(&self.owners)
    }

    fn current_owners_mut(&mut self) -> &mut M1CallerOwners {
        self.staged.as_mut().unwrap_or(&mut self.owners)
    }

    pub(crate) fn provider_previous_resource_transitions(
        &self,
    ) -> &[openwepp_vegetation::v11::V11SharedResourceOwnerTransition] {
        &self.current_owners().prior_shared_resource_transitions
    }

    pub(crate) fn provider_record_resource_custody_bundle(
        &mut self,
        bundle: M1ResourceCustodyBundle,
    ) {
        let owners = self.current_owners_mut();
        owners.prior_shared_resource_transitions = bundle.transitions.clone();
        owners.accepted_resource_transition_sets.push(bundle);
    }

    fn native_fixture_from_current(
        &self,
        bootstrap: &EndpointFixture,
        prepared: &M1PreparedCallerContext,
        authenticated_gsi: f64,
        support_transaction_id: TransactionId,
    ) -> Result<EndpointFixture, M1ReceiverDiagnosticError> {
        let owners = self.current_owners();
        let thermal = match &owners.thermal {
            super::V8SoilThermalPhysicalBeginning::V1(snapshot) => snapshot.clone(),
            _ => {
                return Err(M1ReceiverDiagnosticError {
                    injection: None,
                    source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                    rejected_candidate: None,
                });
            }
        };
        let mut forcing = bootstrap.forcing.clone();
        // These fields are the admitted support inputs consumed by native
        // execution.  Configuration-only fields remain bootstrap-owned.
        forcing.interval_s = prepared.evaluation.support_duration_s();
        forcing.air_temperature_k = prepared.input.column.air_temperature_k;
        forcing.air_specific_humidity_kg_kg = prepared.input.column.air_specific_humidity_kg_kg;
        forcing.air_pressure_pa = prepared.input.column.pressure_pa;
        forcing.reference_wind_m_s = prepared.input.column.reference_wind_m_s;
        forcing.direct_vis_w_m2 = prepared
            .input
            .column
            .shortwave
            .incident_w_m2_tile
            .direct_vis;
        forcing.diffuse_vis_w_m2 = prepared
            .input
            .column
            .shortwave
            .incident_w_m2_tile
            .diffuse_vis;
        forcing.direct_nir_w_m2 = prepared
            .input
            .column
            .shortwave
            .incident_w_m2_tile
            .direct_nir;
        forcing.diffuse_nir_w_m2 = prepared
            .input
            .column
            .shortwave
            .incident_w_m2_tile
            .diffuse_nir;
        forcing.atmospheric_downward_longwave_w_m2 =
            prepared.input.column.atmospheric_downward_longwave_w_m2;
        forcing.forcing_sha256 = forcing
            .canonical_sha256()
            .map_err(|_| m1_owner_identity_error())?;
        let mut vegetation_forcing = bootstrap.receipt.forcing().clone();
        vegetation_forcing.air_temperature_k = prepared.input.column.air_temperature_k;
        vegetation_forcing.specific_humidity = prepared.input.column.air_specific_humidity_kg_kg;
        vegetation_forcing.longwave_down_w_m2 =
            prepared.input.column.atmospheric_downward_longwave_w_m2;
        vegetation_forcing.rain_kg_m2 = prepared.input.column.top_rain_kg_m2_tile;
        vegetation_forcing.gsi = authenticated_gsi;
        let hydrology = if owners.hydrology.transaction_id() == support_transaction_id {
            // A successor support may already own this exact checked child
            // transaction and frame. Reuse only that identical beginning;
            // `with_effective_*` continues to reject an equal transaction.
            if owners.hydrology.beginning_frame() != &owners.frame {
                return Err(m1_owner_identity_error());
            }
            owners.hydrology.clone()
        } else {
            owners
                .hydrology
                .with_effective_beginning_frame_at_transaction(
                    &owners.frame,
                    support_transaction_id,
                )
                .map_err(|_| m1_owner_identity_error())?
        };
        let adapter = LandSurfaceEnergyRealHydrologyAdapter::new(&hydrology);
        let receipt = super::V8CanopyForcingReceipt::try_new(
            bootstrap
                .vegetation_configuration
                .configuration_sha256
                .clone(),
            owners.vegetation.state_sha256.clone(),
            bootstrap.lse_configuration.configuration_sha256.clone(),
            forcing.forcing_sha256.clone(),
            super::unified_beginning_hydrology_snapshot_sha256(
                &adapter,
                &bootstrap.surface_configuration,
            )
            .map_err(|_| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                rejected_candidate: None,
            })?,
            thermal.snapshot_sha256.clone(),
            support_transaction_id,
            vegetation_forcing,
        )
        .map_err(|_| M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
            rejected_candidate: None,
        })?;
        Ok(EndpointFixture {
            vegetation_configuration: bootstrap.vegetation_configuration.clone(),
            vegetation_state: owners.vegetation.clone(),
            surface_configuration: bootstrap.surface_configuration.clone(),
            frame: owners.frame.clone(),
            hydrology,
            lse_configuration: bootstrap.lse_configuration.clone(),
            lse_state: owners.lse.clone(),
            forcing,
            thermal,
            receipt,
            biogeochemistry: owners.biogeochemistry.clone(),
        })
    }
    pub(crate) fn beginning(
        fixture: &EndpointFixture,
        prepared: &M1PreparedCallerContext,
    ) -> Result<Self, M1ReceiverDiagnosticError> {
        let reservoirs = prepared
            .input
            .reservoirs
            .iter()
            .map(|r| (r.occupancy_id.clone(), r.mass_kg_m2, r.enthalpy_j_m2))
            .collect();
        Self::beginning_from_validated_reservoirs(fixture, reservoirs)
    }
    fn prepared_m1_endings(
        &self,
        prepared: &M1PreparedCallerContext,
        current_gsi: f64,
        support_transaction_id: TransactionId,
    ) -> Result<
        (
            openwepp_vegetation::cold_canopy_m1_owner::M1ParentSegmentCandidate,
            M1StagedParentBiogeochemistry,
        ),
        M1ReceiverDiagnosticError,
    > {
        let beginning = self.current_owners();
        let mut forcing =
            prepared.persistent_forcing(&beginning.m1_vegetation, &beginning.m1_configuration)?;
        if !current_gsi.is_finite() || !(0.0..=1.0).contains(&current_gsi) {
            return Err(m1_owner_identity_error());
        }
        forcing.gsi = current_gsi;
        let vegetation = prepared.construct_m1_owner_candidate(
            &beginning.m1_configuration,
            &beginning.m1_vegetation,
            &beginning.biogeochemistry,
            &forcing,
            support_transaction_id,
        )?;
        let biogeochemistry = M1StagedParentBiogeochemistry::try_new(
            construct_m1_biogeochemistry_candidate(&beginning.biogeochemistry, &vegetation)?,
            beginning.biogeochemistry.last_transaction_id,
        )?;
        Ok((vegetation, biogeochemistry))
    }

    fn stage(
        &mut self,
        prepared: &M1PreparedCallerContext,
        support: u64,
        lse_configuration: &openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
        m1_candidate: openwepp_vegetation::cold_canopy_m1_owner::M1ParentSegmentCandidate,
        m1_bgc: M1StagedParentBiogeochemistry,
        received: Option<&UnifiedRealHydrologyCandidate>,
        native_consumed_forcing_bits: [u64; 10],
    ) -> Result<(), M1ReceiverDiagnosticError> {
        let beginning = self.staged.as_ref().unwrap_or(&self.owners);
        if support != beginning.accepted_cursor {
            return Err(M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Support),
                rejected_candidate: None,
            });
        }
        if m1_candidate.beginning() != &beginning.m1_vegetation
            || m1_candidate.ending().revision() != beginning.m1_vegetation.revision()
        {
            return Err(m1_owner_identity_error());
        }
        let mut ending = beginning.clone();
        ending.m1_vegetation = m1_candidate.ending().clone();
        // A support ID is a disjoint, high-bit receipt identity.  Its BGC
        // candidate carries the real physical material/N ending, but its
        // persistent lineage must stay at the admitted parent predecessor
        // until the single V11-style parent finalization event.
        ending.biogeochemistry = m1_bgc.staged_ending();
        ending.reservoirs = prepared
            .input
            .topology
            .occupancy_ids
            .iter()
            .zip(prepared.evaluation.reservoir_operands())
            .map(|(id, r)| (id.clone(), r.ending_mass_kg_m2, r.ending_enthalpy_j_m2))
            .collect();
        ending.accepted_cursor = beginning.accepted_cursor + 1;
        if let Some(received) = received {
            let installed = install_actual_receiver_candidate_locally(
                &beginning.lse,
                &beginning.vegetation,
                &beginning.biogeochemistry,
                received,
            )?;
            // These are the actual native receiver endings.  Keep this
            // installation staged until every subsequent owner check has
            // completed; failure therefore leaves the caller untouched.
            ending.frame = installed.frame;
            ending.lse = installed.lse_state;
            let thermal_beginning = match &beginning.thermal {
                super::V8SoilThermalPhysicalBeginning::V1(snapshot) => snapshot,
                _ => {
                    return Err(M1ReceiverDiagnosticError {
                        injection: None,
                        source: M1ReceiverDiagnosticSource::Context(
                            M1ReceiverContextError::Identity,
                        ),
                        rejected_candidate: None,
                    });
                }
            };
            let thermal_ending = crate::v9_real_consumer_shadow::aggregate_soil_thermal_ending(
                thermal_beginning,
                lse_configuration,
                received.transaction_id(),
                &installed.thermal_candidates,
            )
            .map_err(|_| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                rejected_candidate: None,
            })?;
            ending.thermal = super::V8SoilThermalPhysicalBeginning::V1(thermal_ending);
            ending.hydrology = beginning
                .hydrology
                .with_effective_beginning_frame_at_transaction(
                    &ending.frame,
                    // A received candidate identifies the accepted ending.
                    // The next support must carry a distinct checked identity;
                    // it is not the persistent M1 revision.
                    TransactionId(
                        received
                            .transaction_id()
                            .0
                            .checked_add(1)
                            .ok_or_else(m1_owner_identity_error)?,
                    ),
                )
                .map_err(|_| M1ReceiverDiagnosticError {
                    injection: None,
                    source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                    rejected_candidate: None,
                })?;
        }
        // Retain the real adapter facts only for the active parent.  In
        // particular, the receiver closure's beginning is post-root-debit;
        // custody must use these complete support endpoints instead.
        let native_receipt_proof = received
            .map(|candidate| {
                serde_json::to_vec(candidate.surface_ingress().receipts())
                    .map(|bytes| Digest32::from_bytes(Sha256::digest(bytes).into()))
                    .map_err(|_| m1_owner_identity_error())
            })
            .transpose()?
            .unwrap_or_else(Digest32::zero);
        ending
            .accepted_support_evidence
            .push(M1AcceptedSupportEvidence {
                support_transaction_id: m1_candidate.support_transaction_id(),
                m1_candidate: m1_candidate.clone(),
                bgc_candidate: m1_bgc.physical().clone(),
                reservoir_operands: prepared.evaluation.reservoir_operands().to_vec(),
                native_receiver: received.cloned(),
                m1_configuration: beginning.m1_configuration.clone(),
                beginning_hydrology: beginning.hydrology.clone(),
                ending_hydrology: ending.hydrology.clone(),
                // Extracted from the concrete fixture passed to native
                // execution, not copied from the prepared solver input.
                native_consumed_forcing_bits,
                beginning_thermal_sha256: beginning.thermal.state_sha256().clone(),
                ending_thermal_sha256: ending.thermal.state_sha256().clone(),
                prepared_soil_temperature_bits: prepared
                    .input
                    .column
                    .ground
                    .soil_nodes
                    .iter()
                    .map(|node| node.beginning_temperature_k.to_bits())
                    .collect(),
                prepared_soil_temperature_by_layer: prepared
                    .input
                    .column
                    .ground
                    .soil_nodes
                    .iter()
                    .map(|node| {
                        (
                            node.layer_id.as_str().to_owned(),
                            node.beginning_temperature_k.to_bits(),
                        )
                    })
                    .collect(),
                bgc_parent_predecessor: m1_bgc.parent_predecessor,
                native_receipt_proof,
            });
        self.staged = Some(ending);
        Ok(())
    }
    /// Atomically install one sealed contiguous parent interval. Callers must
    /// supply the interval admitted by the coupled-time parent; staging has no
    /// install path of its own.
    pub(crate) fn admit_fixed_sequence_parent_clock(
        &mut self,
        clock: CoupledClockStateV1,
        run_identity: [u8; 32],
        cycle_ordinal: u32,
        parent_ordinal: u32,
        expected_initial_phase: &BTreeMap<String, (u64, u64)>,
    ) -> Result<(), M1ReceiverDiagnosticError> {
        let expected_parent = self.current_owners().accepted_cursor / 30;
        if self.parent_clock.is_some()
            || self.staged.is_some()
            || clock.parent_support().duration_ns() != 1_800_000_000_000
            || u64::from(parent_ordinal) != expected_parent
            || cycle_ordinal > 1
        {
            return Err(m1_owner_identity_error());
        }
        match (self.provider_run_identity, self.provider_cycle_ordinal) {
            (Some(bound_run), Some(bound_cycle))
                if bound_run != run_identity || bound_cycle != cycle_ordinal =>
            {
                return Err(m1_owner_identity_error());
            }
            (Some(_), Some(_)) => {}
            (None, None) => {}
            _ => return Err(m1_owner_identity_error()),
        }
        // Initial M/H is an independent-cycle beginning condition.  Once the
        // first parent has been admitted, retained ending state is continuous
        // and must never be reset or compared to the initial phase again.
        if parent_ordinal == 0 {
            let actual = self
                .owners
                .reservoirs
                .iter()
                .map(|(occupancy, mass, enthalpy)| {
                    (occupancy.clone(), (mass.to_bits(), enthalpy.to_bits()))
                })
                .collect::<BTreeMap<_, _>>();
            if &actual != expected_initial_phase {
                return Err(m1_owner_identity_error());
            }
        }
        if self.provider_run_identity.is_none() {
            self.provider_run_identity = Some(run_identity);
            self.provider_cycle_ordinal = Some(cycle_ordinal);
        }
        self.parent_clock = Some(clock);
        Ok(())
    }
    pub(crate) fn complete_parent(&mut self) -> Result<(), M1ReceiverDiagnosticError> {
        let clock = self
            .parent_clock
            .clone()
            .ok_or_else(m1_owner_identity_error)?;
        if !clock.is_complete() {
            return Err(m1_owner_identity_error());
        }
        // The receiving parent owns every retained support result. Before
        // discarding that bounded evidence, join it one-for-one to the
        // completed clock and its accepted slabs, including exact resource
        // transition parent/segment/slab/support identity and accepted-order
        // material proposals. No turnover or resource candidate is rebuilt.
        let staged = self.staged.as_ref().ok_or_else(m1_owner_identity_error)?;
        let slabs = clock.accepted_slab_receipts();
        if slabs.len() != 30
            || staged.accepted_support_evidence.len() != slabs.len()
            || staged.accepted_resource_transition_sets.len() != slabs.len()
        {
            return Err(m1_owner_identity_error());
        }
        let mut material_ids = std::collections::BTreeSet::new();
        let mut support_transaction_ids = std::collections::BTreeSet::new();
        let mut parent_material_transfers = Vec::new();
        let mut native_proof_bytes = Vec::new();
        for (ordinal, ((evidence, bundle), slab)) in staged
            .accepted_support_evidence
            .iter()
            .zip(&staged.accepted_resource_transition_sets)
            .zip(slabs)
            .enumerate()
        {
            if bundle.slab != *slab
                || slab.slab_ordinal()
                    != u32::try_from(ordinal).map_err(|_| m1_owner_identity_error())?
                || !support_transaction_ids.insert(evidence.support_transaction_id)
                || bundle.transitions.is_empty()
                || bundle.debits.is_empty()
                || bundle.candidates.is_empty()
                || bundle.ending_owner_states.is_empty()
                || bundle.transitions.iter().any(|transition| {
                    transition.parent_transaction_id != slab.parent_transaction_id()
                        || transition.segment_id != slab.segment_id()
                        || transition.accepted_slab_id != slab.slab_id()
                        || transition.support != slab.support()
                })
                || evidence
                    .m1_candidate
                    .material_proposals()
                    .iter()
                    .any(|proposal| {
                        proposal.transaction_id != evidence.support_transaction_id.0
                            || !material_ids
                                .insert((evidence.support_transaction_id, proposal.proposal_id))
                    })
            {
                return Err(m1_owner_identity_error());
            }
            parent_material_transfers
                .extend(evidence.m1_candidate.material_proposals().iter().cloned());
            native_proof_bytes.extend_from_slice(evidence.native_receipt_proof.as_bytes());
            native_proof_bytes.extend_from_slice(
                &serde_json::to_vec(bundle).map_err(|_| m1_owner_identity_error())?,
            );
        }
        parent_material_transfers = self.canonical_parent_material_transfers(staged)?;
        let material_digest = Digest32::from_bytes(
            Sha256::digest(
                serde_json::to_vec(&parent_material_transfers)
                    .map_err(|_| m1_owner_identity_error())?,
            )
            .into(),
        );
        // Complete all fallible parent-finalization work on an immutable
        // staged clone.  A failed finalization must leave both the live clock
        // and the staged successor available for its typed refusal path.
        let mut ending = self.staged.clone().ok_or_else(m1_owner_identity_error)?;
        let finalized_vegetation = ending
            .m1_vegetation
            .finalize_parent_lineage()
            .map_err(|_| m1_owner_identity_error())?;
        // The BGC physical ending was staged support-by-support with the
        // parent predecessor.  Finalization changes only its canonical
        // lineage to the sealed M1 parent revision; material transfers are
        // therefore neither regenerated nor applied a second time.
        ending.biogeochemistry.last_transaction_id = u128::from(finalized_vegetation.revision());
        ending.m1_vegetation = finalized_vegetation;
        let mut finalized_owners =
            Self::canonical_complete_owner_bytes(&ending, &ending.surface_configuration)?;
        finalized_owners.insert("snow".to_owned(), ending.snow_owner_bytes.clone());
        if finalized_owners.len() != 7 {
            return Err(m1_owner_identity_error());
        }
        let ending_owners = clock
            .owners()
            .iter()
            .map(|owner| {
                finalized_owners
                    .get(owner.owner_id())
                    .cloned()
                    .and_then(|bytes| {
                        openwepp_coupled_time::OwnerState::new(owner.owner_id().to_owned(), bytes)
                            .ok()
                    })
                    .ok_or_else(m1_owner_identity_error)
            })
            .collect::<Result<Vec<_>, _>>()?;
        let mutation_set = clock
            .owners()
            .iter()
            .zip(&ending_owners)
            .filter_map(|(beginning, ending)| {
                (beginning != ending).then(|| beginning.owner_id().to_owned())
            })
            .collect::<Vec<_>>();
        if !matches!(mutation_set.as_slice(), [vegetation] if vegetation == "vegetation")
            && !matches!(mutation_set.as_slice(), [bgc, vegetation] if bgc == "bgc" && vegetation == "vegetation")
        {
            return Err(m1_owner_identity_error());
        }
        let beginning_digest =
            complete_owner_set_digest(clock.owners()).map_err(|_| m1_owner_identity_error())?;
        let ending_digest =
            complete_owner_set_digest(&ending_owners).map_err(|_| m1_owner_identity_error())?;
        let mut context_bytes = Vec::new();
        context_bytes.extend_from_slice(clock.parent_transaction_id().digest().as_bytes());
        context_bytes.extend_from_slice(&clock.accepted_until().get().to_be_bytes());
        context_bytes.extend_from_slice(beginning_digest.as_bytes());
        context_bytes.extend_from_slice(ending_digest.as_bytes());
        context_bytes.extend_from_slice(material_digest.as_bytes());
        context_bytes.extend_from_slice(&Sha256::digest(native_proof_bytes));
        let context = Digest32::from_bytes(Sha256::digest(context_bytes).into());
        let ledger = LedgerEntryV1::new(
            "m1-parent-finalization".to_owned(),
            "canonical-owner-transition".to_owned(),
            context,
            context,
            context,
        )
        .map_err(|_| m1_owner_identity_error())?;
        let event = EventProposalV1::new(
            EventClass::OwnershipTransfer,
            "vegetation".to_owned(),
            context,
            ending_owners.clone(),
            mutation_set,
            "m1-parent-finalization".to_owned(),
            clock.active_participants().to_vec(),
            vec![ledger],
        )
        .map_err(|_| m1_owner_identity_error())?;
        let mut committed_clock = clock.clone();
        let mut queue = EventQueueV1::new(clock.accepted_until(), vec![event])
            .map_err(|_| m1_owner_identity_error())?;
        let accepted = queue
            .apply_next(&mut committed_clock)
            .map_err(|_| m1_owner_identity_error())?
            .ok_or_else(m1_owner_identity_error)?;
        if queue
            .apply_next(&mut committed_clock)
            .map_err(|_| m1_owner_identity_error())?
            .is_some()
            || accepted.beginning_owner_set_digest() != beginning_digest
            || accepted.ending_owner_set_digest() != ending_digest
            || committed_clock.owners() != ending_owners
        {
            return Err(m1_owner_identity_error());
        }
        // Support-local candidate evidence is needed only through this single
        // consuming parent handoff.  Do not turn caller-owned persistent
        // state into an unbounded numerical-history archive.
        ending.accepted_support_evidence.clear();
        ending.prior_shared_resource_transitions.clear();
        ending.accepted_resource_transition_sets.clear();
        let next_publication_count = self
            .parent_publication_count
            .checked_add(1)
            .ok_or_else(m1_owner_identity_error)?;
        let candidate = ParentCommitCandidateV1::new(&committed_clock, Vec::new())
            .map_err(|_| m1_owner_identity_error())?;
        let durable =
            commit_parent(committed_clock, candidate).map_err(|_| m1_owner_identity_error())?;
        if durable.clock().owners() != ending_owners {
            return Err(m1_owner_identity_error());
        }
        let durable_commit = durable.commit().clone();
        // Every fallible operation is now complete. The consuming install is a
        // single state transition, retaining the actual durable handoff.
        self.sealed_finalized_owners = Some(ending_owners);
        self.durable_parent_commit = Some(durable_commit);
        self.owners = ending;
        self.staged = None;
        self.parent_clock = None;
        self.parent_publication_count = next_publication_count;
        Ok(())
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum M1ReceiverFailureInjection {
    WrongPhase,
    WrongOwner,
    WrongSupport,
    WrongLiquidEnthalpy,
    WrongAreaConversion,
    WrongSourceBranch,
    WrongPlantArea,
    WrongReceiptDestination,
    MissingReceipt,
    ForeignReceipt,
    DuplicateTransfer,
    LateReceiverFailure,
}
#[derive(Clone, Debug, PartialEq)]
struct M1ReceiverLocalOwners {
    frame: crate::DirectRunFrame,
    lse_state: openwepp_land_surface_energy::LandSurfaceEnergyState,
    vegetation_state: openwepp_vegetation::V8CoupledOwnedState,
    thermal_candidates: Vec<super::SoilThermalTileCandidate>,
    biogeochemistry: openwepp_biogeochemistry::BiogeochemistryState,
}

fn install_actual_receiver_candidate_locally(
    lse_beginning: &openwepp_land_surface_energy::LandSurfaceEnergyState,
    vegetation_beginning: &openwepp_vegetation::V8CoupledOwnedState,
    biogeochemistry_beginning: &openwepp_biogeochemistry::BiogeochemistryState,
    candidate: &UnifiedRealHydrologyCandidate,
) -> Result<M1ReceiverLocalOwners, M1ReceiverDiagnosticError> {
    let lse_state = openwepp_land_surface_energy::build_lse_ending_state(
        lse_beginning,
        candidate.transaction_id(),
        candidate.ending_lse_tile_states().to_vec(),
    )
    .map_err(|source| M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Routing(source),
        rejected_candidate: None,
    })?;
    Ok(M1ReceiverLocalOwners {
        frame: candidate.ending_frame().clone(),
        lse_state,
        vegetation_state: vegetation_beginning.clone(),
        thermal_candidates: candidate.soil_thermal_candidates().to_vec(),
        biogeochemistry: biogeochemistry_beginning.clone(),
    })
}

/// Join the sealed M1 vegetation candidate to the existing BGC owner through
/// the canonical material and exact nitrogen protocol.  This is a candidate
/// operation only; installation remains at the complete caller parent.
fn construct_m1_biogeochemistry_candidate(
    beginning: &openwepp_biogeochemistry::BiogeochemistryState,
    vegetation: &openwepp_vegetation::cold_canopy_m1_owner::M1ParentSegmentCandidate,
) -> Result<openwepp_biogeochemistry::BiogeochemistryOwnerCandidate, M1ReceiverDiagnosticError> {
    use openwepp_biogeochemistry::{
        MaterialPool, MaterialProposal, TransformationsMode, construct_biogeochemistry_candidate,
    };

    let proposals = vegetation
        .material_proposals()
        .iter()
        .map(|proposal| MaterialProposal {
            transaction_id: proposal.transaction_id,
            owner_id: proposal.owner_id.clone(),
            donor: proposal.donor,
            receiver: proposal.receiver,
            proposal_id: proposal.proposal_id,
            amounts: MaterialPool {
                carbon: proposal.carbon,
                nitrogen: proposal.nitrogen,
                dry_matter: proposal.dry_matter,
            },
        })
        .collect::<Vec<_>>();
    let (requests, authorizations, uses) = vegetation.nitrogen_protocol();
    construct_biogeochemistry_candidate(
        beginning,
        vegetation.support_transaction_id(),
        requests,
        authorizations,
        uses,
        &proposals,
        TransformationsMode::Disabled,
    )
    .map_err(|_| M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
        rejected_candidate: None,
    })
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1NativeCapability {
    transaction_id: TransactionId,
    consumed: Rc<Cell<bool>>,
}
impl M1NativeCapability {
    fn new(transaction_id: TransactionId) -> Self {
        Self {
            transaction_id,
            consumed: Rc::new(Cell::new(false)),
        }
    }
    pub(crate) fn consume(&self) -> Result<(), M1ReceiverDiagnosticError> {
        if self.consumed.replace(true) {
            return Err(m1_duplicate_capability_error());
        }
        Ok(())
    }
    pub(crate) fn transaction_id(&self) -> TransactionId {
        self.transaction_id
    }
    pub(crate) fn is_consumed(&self) -> bool {
        self.consumed.get()
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1ReceiverDiagnosticResult {
    actual_candidate: UnifiedRealHydrologyCandidate,
    contribution_join: M1ReceiverContributionJoin,
    capability: M1NativeCapability,
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1ReceiverContributionJoin {
    contributors: Vec<M1ReceiverContribution>,
}
impl M1ReceiverContributionJoin {
    pub(crate) fn contributors(&self) -> &[M1ReceiverContribution] {
        &self.contributors
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1ReceiverContribution {
    origin: String,
    source_parcel_id: String,
    kind: crate::DirectSurfaceLiquidParcelKind,
    transaction_id: openwepp_kernel_contract::TransactionId,
    mass: f64,
    enthalpy: f64,
    fraction: f64,
    source_occupancy_id: String,
    destination_occupancy_id: Option<String>,
}
#[derive(Clone, Debug, PartialEq)]
struct M1ReceiverAuthenticatedHandoff {
    parcel_id: ParcelId,
    kind: DirectSurfaceLiquidParcelKind,
    source_owner_id: ResourceOwnerId,
    source_ofe_id: openwepp_land_surface_energy::OfeId,
    source_tile_id: openwepp_kernel_contract::TileId,
    destination_ofe_id: openwepp_land_surface_energy::OfeId,
    destination_tile_id: openwepp_kernel_contract::TileId,
    accepted_source_state_sha256: Sha256Digest,
    transaction_id: TransactionId,
    interval_s: f64,
}

impl M1ReceiverAuthenticatedHandoff {
    fn validate(
        &self,
        accepted_state_sha256: &str,
        forest: &crate::DirectSurfaceLiquidConfigurationRecord,
    ) -> Result<(), M1ReceiverDiagnosticError> {
        let error = |source| M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(source),
            rejected_candidate: None,
        };
        if self.kind != DirectSurfaceLiquidParcelKind::TerminalReceiver
            || self.parcel_id.to_string() != "m1-prescribed-terminal-receiver"
        {
            return Err(error(M1ReceiverContextError::Topology));
        }
        if self.source_owner_id.as_str() != "vegetation-v8" {
            return Err(error(M1ReceiverContextError::Owner));
        }
        if self.source_ofe_id != forest.key.ofe_id
            || self.source_tile_id != forest.key.tile_id
            || self.destination_ofe_id != forest.key.ofe_id
            || self.destination_tile_id != forest.key.tile_id
        {
            return Err(error(M1ReceiverContextError::Branch));
        }
        if self.accepted_source_state_sha256.as_str() != accepted_state_sha256 {
            return Err(error(M1ReceiverContextError::Identity));
        }
        if self.transaction_id != TransactionId(41)
            || self.interval_s.to_bits() != 60.0_f64.to_bits()
        {
            return Err(error(M1ReceiverContextError::Support));
        }
        Ok(())
    }
}

impl M1ReceiverContribution {
    pub(crate) fn origin(&self) -> &str {
        &self.origin
    }
    pub(crate) fn source_parcel_id(&self) -> &str {
        &self.source_parcel_id
    }
    pub(crate) const fn kind(&self) -> crate::DirectSurfaceLiquidParcelKind {
        self.kind
    }
    pub(crate) const fn transaction_id(&self) -> openwepp_kernel_contract::TransactionId {
        self.transaction_id
    }
    pub(crate) const fn start_s(&self) -> f64 {
        0.0
    }
    pub(crate) const fn end_s(&self) -> f64 {
        60.0
    }
    pub(crate) const fn tile_mass_kg_m2(&self) -> f64 {
        self.mass
    }
    pub(crate) const fn mass_kg_m2_tile(&self) -> f64 {
        self.mass
    }
    pub(crate) const fn specific_enthalpy_j_kg(&self) -> f64 {
        self.enthalpy
    }
    pub(crate) const fn ofe_mass_kg_m2_ground(&self) -> f64 {
        self.mass * self.fraction
    }
    pub(crate) fn ofe_enthalpy_j_m2_ground(&self) -> f64 {
        self.ofe_mass_kg_m2_ground() * self.enthalpy
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct M1ReceiverStage(&'static str);
impl M1ReceiverStage {
    pub(crate) const fn as_str(self) -> &'static str {
        self.0
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct M1ReceiverReason(&'static str);
impl M1ReceiverReason {
    pub(crate) const fn as_str(self) -> &'static str {
        self.0
    }
}
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct M1ReceiverDiagnosticError {
    injection: Option<M1ReceiverFailureInjection>,
    source: M1ReceiverDiagnosticSource,
    rejected_candidate: Option<M1ReceiverDiagnosticResult>,
}

#[derive(Clone, Debug, PartialEq)]
enum M1ReceiverDiagnosticSource {
    Routing(openwepp_land_surface_energy::LandSurfaceEnergyError),
    Runtime(
        ExecuteV8LseRuntimeShadowError,
        Option<M1ReceiverContextError>,
    ),
    Context(M1ReceiverContextError),
    Injection(M1ReceiverFailureInjection),
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum M1ReceiverContextError {
    Cadence,
    Identity,
    Topology,
    Phase,
    Owner,
    Support,
    Area,
    Branch,
    Duplicate,
    LiquidEnthalpy,
}
impl M1ReceiverDiagnosticError {
    pub(crate) const fn code(&self) -> &'static str {
        "VEG-E-143"
    }
    pub(crate) const fn rejection_stage(&self) -> M1ReceiverStage {
        M1ReceiverStage(match self.source {
            M1ReceiverDiagnosticSource::Context(
                M1ReceiverContextError::Phase
                | M1ReceiverContextError::Owner
                | M1ReceiverContextError::Support,
            )
            | M1ReceiverDiagnosticSource::Runtime(_, Some(M1ReceiverContextError::Support)) => {
                "preflight"
            }
            M1ReceiverDiagnosticSource::Injection(
                M1ReceiverFailureInjection::LateReceiverFailure,
            ) => "late_receiver",
            _ => "receiver",
        })
    }
    pub(crate) const fn rejection_reason(&self) -> M1ReceiverReason {
        M1ReceiverReason(match self.source {
            M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Phase) => "wrong_phase",
            M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Owner) => "wrong_owner",
            M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Support)
            | M1ReceiverDiagnosticSource::Runtime(_, Some(M1ReceiverContextError::Support)) => {
                "wrong_support"
            }
            M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::LiquidEnthalpy) => {
                "wrong_liquid_enthalpy"
            }
            M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Area) => {
                "wrong_area_conversion"
            }
            M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Branch) => {
                "wrong_source_branch"
            }
            M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Duplicate)
            | M1ReceiverDiagnosticSource::Runtime(_, Some(M1ReceiverContextError::Duplicate)) => {
                "duplicate_transfer"
            }
            M1ReceiverDiagnosticSource::Injection(
                M1ReceiverFailureInjection::LateReceiverFailure,
            ) => "injected_failure",
            _ => "actual_receiver_failure",
        })
    }
    pub(crate) fn rejected_candidate(&self) -> Option<&M1ReceiverDiagnosticResult> {
        self.rejected_candidate.as_ref()
    }
    pub(crate) fn is_genuine_late_owning_receiver_failure(&self) -> bool {
        matches!(
            self.source,
            M1ReceiverDiagnosticSource::Injection(M1ReceiverFailureInjection::LateReceiverFailure)
        ) && self.rejected_candidate.is_some()
    }
    pub(crate) fn replay_consumed_capability(&self) -> Result<(), M1ReceiverDiagnosticError> {
        self.rejected_candidate
            .as_ref()
            .ok_or_else(m1_invalid_capability_error)?
            .replay_capability()
    }
}
/// The native handoff is consumed during the successful staged install.  A
/// later attempt to present it is rejected at the same typed receiver seam.
pub(crate) fn m1_duplicate_capability_error() -> M1ReceiverDiagnosticError {
    M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Duplicate),
        rejected_candidate: None,
    }
}
pub(crate) fn m1_invalid_capability_error() -> M1ReceiverDiagnosticError {
    m1_owner_identity_error()
}
impl M1ReceiverDiagnosticResult {
    pub(crate) const fn actual_candidate(&self) -> &UnifiedRealHydrologyCandidate {
        &self.actual_candidate
    }
    pub(crate) const fn contribution_join(&self) -> &M1ReceiverContributionJoin {
        &self.contribution_join
    }
    pub(crate) fn capability(&self) -> M1NativeCapability {
        self.capability.clone()
    }
    pub(crate) fn replay_capability(&self) -> Result<(), M1ReceiverDiagnosticError> {
        self.capability.consume()
    }
    pub(crate) fn capability_consumed(&self) -> bool {
        self.capability.is_consumed()
    }
}

fn amount(mass: f64, h: f64) -> DirectIngressAmount {
    let temperature_k = 273.15 + h / 4218.0;
    DirectIngressAmount {
        mass_kg_m2_tile_ground: mass,
        temperature_k,
        // The receiver validates this exact expression against the parcel
        // temperature.  The original branch enthalpy remains in the
        // contributor record; a merge publishes its canonical mixture value.
        specific_liquid_enthalpy_j_kg: 4218.0 * (temperature_k - 273.15),
        start_s: 0.0,
        end_s: 60.0,
    }
}
/// Rebind only the diagnostic support duration.  The frozen fixture's physical
/// forcing and beginning owners stay byte-identical; these cloned digests make
/// the prescribed 60 s support an authentic endpoint input rather than an
/// ingress cadence exception.
fn prescribed_sixty_second_context(
    fixture: &EndpointFixture,
) -> Result<
    (
        openwepp_vegetation::VegetationConfiguration,
        openwepp_vegetation::V8CoupledOwnedState,
        openwepp_land_surface_energy::LandSurfaceEnergyConfiguration,
        openwepp_land_surface_energy::LandSurfaceEnergyState,
        openwepp_land_surface_energy::LandSurfaceForcing,
        RealHydrologyShadowAdapter,
        super::V8CanopyForcingReceipt,
    ),
    M1ReceiverDiagnosticError,
> {
    let mut vegetation = fixture.vegetation_configuration.clone();
    vegetation.dt_s = 60.0;
    vegetation.configuration_sha256 =
        vegetation
            .canonical_sha256()
            .map_err(|_| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
                rejected_candidate: None,
            })?;
    let mut lse_configuration = fixture.lse_configuration.clone();
    lse_configuration
        .vegetation_configuration
        .configuration_sha256 = openwepp_land_surface_energy::Sha256Digest::try_new(
        vegetation.configuration_sha256.clone(),
    )
    .map_err(|_| M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
        rejected_candidate: None,
    })?;
    lse_configuration.configuration_sha256 =
        lse_configuration
            .canonical_sha256()
            .map_err(|_| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
                rejected_candidate: None,
            })?;
    let mut vegetation_state = fixture.vegetation_state.clone();
    vegetation_state.configuration_sha256 = vegetation.configuration_sha256.clone();
    vegetation_state.state_sha256 = vegetation_state.canonical_sha256();
    let mut lse_state = fixture.lse_state.clone();
    lse_state.configuration_sha256 = lse_configuration.configuration_sha256.clone();
    lse_state.state_sha256 =
        lse_state
            .canonical_sha256()
            .map_err(|_| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
                rejected_candidate: None,
            })?;
    let mut forcing = fixture.forcing.clone();
    forcing.interval_s = 60.0;
    forcing.forcing_sha256 = forcing
        .canonical_sha256()
        .map_err(|_| M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
            rejected_candidate: None,
        })?;
    let layer_ids = [
        "thermal-1",
        "thermal-2",
        "soil-1",
        "soil-2",
        "soil-dry",
        "soil-frozen",
    ]
    .map(|id| {
        SoilLayerId::try_new(id).map_err(|_| M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
            rejected_candidate: None,
        })
    })
    .into_iter()
    .collect::<Result<Vec<_>, _>>()?;
    let hydrology = RealHydrologyShadowAdapter::try_from_day_start(
        &fixture.frame,
        0,
        TransactionId(41),
        60.0,
        ResourceOwnerId::try_new("production-hydrology").map_err(|_| {
            M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Owner),
                rejected_candidate: None,
            }
        })?,
        &[RealHydrologyLaneLayerMap {
            ofe_lane: RealHydrologyOfeLaneId {
                lane_index: 0,
                lane_id: 1,
            },
            layer_ids,
        }],
    )
    .map_err(|_| M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
        rejected_candidate: None,
    })?;
    let adapter = LandSurfaceEnergyRealHydrologyAdapter::new(&hydrology);
    let thermal =
        super::V8SoilThermalPhysicalBeginning::try_from_v1(&fixture.thermal).map_err(|_| {
            M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
                rejected_candidate: None,
            }
        })?;
    let receipt = super::V8CanopyForcingReceipt::try_new(
        vegetation.configuration_sha256.clone(),
        vegetation_state.state_sha256.clone(),
        lse_configuration.configuration_sha256.clone(),
        forcing.forcing_sha256.clone(),
        super::unified_beginning_hydrology_snapshot_sha256(
            &adapter,
            &fixture.surface_configuration,
        )
        .map_err(|_| M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
            rejected_candidate: None,
        })?,
        thermal
            .snapshot_sha256()
            .map_err(|_| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
                rejected_candidate: None,
            })?,
        TransactionId(41),
        fixture.receipt.forcing().clone(),
    )
    .map_err(|_| M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Cadence),
        rejected_candidate: None,
    })?;
    Ok((
        vegetation,
        vegetation_state,
        lse_configuration,
        lse_state,
        forcing,
        hydrology,
        receipt,
    ))
}

fn validate_prescribed_source_context(
    control: &M1PrescribedRoutingControl,
    fixture: &EndpointFixture,
    forest: &crate::DirectSurfaceLiquidConfigurationRecord,
) -> Result<(), M1ReceiverDiagnosticError> {
    let reject = |source| M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(source),
        rejected_candidate: None,
    };
    let mut configured = fixture
        .vegetation_configuration
        .strata
        .iter()
        .filter(|row| row.tile_ids.contains(&forest.key.tile_id))
        .collect::<Vec<_>>();
    configured.sort_by_key(|row| row.vertical_rank);
    if configured.len() != 2 || configured[0].vertical_rank >= configured[1].vertical_rank {
        return Err(reject(M1ReceiverContextError::Topology));
    }
    let expected = configured
        .iter()
        .map(|row| {
            fixture
                .vegetation_state
                .strata
                .get(&row.stratum_id)
                .ok_or_else(|| reject(M1ReceiverContextError::Identity))?;
            Ok(format!(
                "{}::{}",
                row.stratum_id.as_str(),
                forest.key.tile_id.as_str()
            ))
        })
        .collect::<Result<Vec<_>, M1ReceiverDiagnosticError>>()?;
    let upper = control.input.upper();
    let lower = control.input.lower();
    if upper.occupancy_id != expected[0] || lower.occupancy_id != expected[1] {
        return Err(reject(M1ReceiverContextError::Branch));
    }
    if !upper.plant_area_m2_m2_tile.is_finite()
        || upper.plant_area_m2_m2_tile <= 0.0
        || !lower.plant_area_m2_m2_tile.is_finite()
        || lower.plant_area_m2_m2_tile <= 0.0
        || control.input.tile_fraction().to_bits() != forest.tile_fraction.to_bits()
    {
        return Err(reject(M1ReceiverContextError::Area));
    }
    Ok(())
}

fn validate_m1_prepared_context(
    prepared: &M1PreparedCallerContext,
    control: &M1PrescribedRoutingControl,
) -> Result<(), M1ReceiverDiagnosticError> {
    let reject = |source| M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(source),
        rejected_candidate: None,
    };
    let rows = &prepared.input.column.occupancies;
    if rows.len() != 2
        || prepared.evaluation.reservoir_operands().len() != 2
        || prepared.input.topology.occupancy_ids[0] != control.input.upper().occupancy_id
        || prepared.input.topology.occupancy_ids[1] != control.input.lower().occupancy_id
    {
        return Err(reject(M1ReceiverContextError::Topology));
    }
    for ((index, row), route) in rows
        .iter()
        .enumerate()
        .zip([control.input.upper(), control.input.lower()])
    {
        let area = row.lai + row.sai;
        if !area.is_finite()
            || area <= 0.0
            || area.to_bits() != route.plant_area_m2_m2_tile.to_bits()
            || area.to_bits() != prepared.accepted_plant_area_m2_m2_tile[index].to_bits()
        {
            return Err(reject(M1ReceiverContextError::Area));
        }
    }
    // `M1CoupledEvaluation` deliberately exposes only accepted operands, so
    // bind every caller-owned beginning reservoir and occupancy to that
    // materialization before any routing or owner staging.  This closes the
    // former `new(input, evaluation)` pairing seam for unrelated solves.
    for ((input_reservoir, operand), occupancy) in prepared
        .input
        .reservoirs
        .iter()
        .zip(prepared.evaluation.reservoir_operands())
        .zip(prepared.evaluation.occupancies())
    {
        if input_reservoir.occupancy_id != occupancy.occupancy_id
            || input_reservoir.mass_kg_m2.to_bits() != operand.beginning_mass_kg_m2.to_bits()
            || input_reservoir.enthalpy_j_m2.to_bits() != operand.beginning_enthalpy_j_m2.to_bits()
            || operand.dt_s.to_bits() != prepared.evaluation.support_duration_s().to_bits()
        {
            return Err(reject(M1ReceiverContextError::Identity));
        }
    }
    let dt_s = prepared.evaluation.support_duration_s();
    let top_rate = prepared.input.column.top_rain_kg_m2_tile / dt_s;
    let upper_capture = openwepp_land_surface_energy::m1_liquid_interception_fraction(
        rows[0].lai + rows[0].sai,
        rows[0].liquid_interception_fraction,
    )
    .map_err(|_| reject(M1ReceiverContextError::Identity))?
        * top_rate;
    let upper_through = (top_rate - upper_capture) * (1.0 - rows[0].stemflow_fraction);
    let lower_capture = openwepp_land_surface_energy::m1_liquid_interception_fraction(
        rows[1].lai + rows[1].sai,
        rows[1].liquid_interception_fraction,
    )
    .map_err(|_| reject(M1ReceiverContextError::Identity))?
        * (upper_through + prepared.evaluation.reservoir_operands()[0].drainage_kg_m2_s);
    if prepared.evaluation.reservoir_operands()[0]
        .incident_liquid_kg_m2_s
        .to_bits()
        != upper_capture.to_bits()
        || prepared.evaluation.reservoir_operands()[1]
            .incident_liquid_kg_m2_s
            .to_bits()
            != lower_capture.to_bits()
    {
        return Err(reject(M1ReceiverContextError::Identity));
    }
    Ok(())
}

fn validate_terminal_receipts<'a>(
    receipts: &'a [crate::DirectSurfaceLiquidParcelReceipt],
    handoff: &M1ReceiverAuthenticatedHandoff,
    forest: &crate::DirectSurfaceLiquidConfigurationRecord,
) -> Result<Vec<&'a crate::DirectSurfaceLiquidParcelReceipt>, M1ReceiverDiagnosticError> {
    let expected_source = handoff.parcel_id.to_string();
    let matching = receipts
        .iter()
        .filter(|receipt| {
            receipt.kind == handoff.kind
                && receipt.source_parcel_id == expected_source
                && receipt.transaction_id == handoff.transaction_id
        })
        .collect::<Vec<_>>();
    if matching.len() != 1
        || matching.iter().any(|receipt| {
            receipt.start_s.to_bits() != 0.0_f64.to_bits()
                || receipt.end_s.to_bits() != handoff.interval_s.to_bits()
                || receipt.origin_store_key.ofe_id != forest.key.ofe_id
                || receipt.origin_store_key.tile_id != forest.key.tile_id
                || receipt.recipient_store_key.ofe_id != handoff.destination_ofe_id
                || receipt.recipient_store_key.tile_id != handoff.destination_tile_id
                || receipt.basis_ofe_id != handoff.destination_ofe_id
        })
    {
        return Err(M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Branch),
            rejected_candidate: None,
        });
    }
    Ok(matching)
}

fn validate_contributor_handoff(
    contributors: &[M1ReceiverContribution],
    route: &openwepp_land_surface_energy::M1ColumnLiquidRouting,
) -> Result<(), M1ReceiverDiagnosticError> {
    if contributors.len() != route.terminal_parcels().len() || contributors.is_empty() {
        return Err(M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Branch),
            rejected_candidate: None,
        });
    }
    for (row, parcel) in contributors.iter().zip(route.terminal_parcels()) {
        let expected_fraction = parcel.mass_kg_m2_ofe_ground() / parcel.mass_kg_m2_tile();
        if row.origin != parcel.origin()
            || row.source_occupancy_id != parcel.source_occupancy_id()
            || row.destination_occupancy_id.as_deref() != parcel.destination_occupancy_id()
        {
            return Err(M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Branch),
                rejected_candidate: None,
            });
        }
        if row.mass.to_bits() != parcel.mass_kg_m2_tile().to_bits()
            || row.enthalpy.to_bits() != parcel.enthalpy_j_kg().to_bits()
            || row.fraction.to_bits() != expected_fraction.to_bits()
            || !row.mass.is_finite()
            || !row.enthalpy.is_finite()
            || !row.fraction.is_finite()
        {
            return Err(M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Area),
                rejected_candidate: None,
            });
        }
    }
    Ok(())
}

/// Resolve the fixed diagnostic's covered and open surfaces by the configured
/// M1 occupancy key.  The two-record fixture is a scope limit, never an
/// authorization to use record position or a literal tile name.
fn configured_m1_surface_records<'a>(
    fixture: &'a EndpointFixture,
    covered_id: &str,
) -> Result<
    (
        &'a crate::DirectSurfaceLiquidConfigurationRecord,
        &'a crate::DirectSurfaceLiquidConfigurationRecord,
    ),
    M1ReceiverDiagnosticError,
> {
    let reject = || M1ReceiverDiagnosticError {
        injection: None,
        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
        rejected_candidate: None,
    };
    let (_, tile) = covered_id.rsplit_once("::").ok_or_else(reject)?;
    let covered = fixture
        .surface_configuration
        .records
        .iter()
        .filter(|record| record.key.tile_id.as_str() == tile)
        .collect::<Vec<_>>();
    if covered.len() != 1 {
        return Err(reject());
    }
    let open = fixture
        .surface_configuration
        .records
        .iter()
        .filter(|record| {
            record.key.ofe_id == covered[0].key.ofe_id
                && record.key.tile_id != covered[0].key.tile_id
        })
        .collect::<Vec<_>>();
    if open.len() != 1 {
        return Err(reject());
    }
    Ok((covered[0], open[0]))
}

pub(crate) fn execute_m1_cold_canopy_receiver_diagnostic(
    fixture: &mut EndpointFixture,
    control: &M1PrescribedRoutingControl,
    injection: Option<M1ReceiverFailureInjection>,
) -> Result<M1ReceiverDiagnosticResult, M1ReceiverDiagnosticError> {
    let route =
        openwepp_land_surface_energy::route_m1_column_liquid(&control.input).map_err(|source| {
            M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Routing(source),
                rejected_candidate: None,
            }
        })?;
    let (forest, open) =
        configured_m1_surface_records(fixture, &control.input.upper().occupancy_id)?;
    validate_prescribed_source_context(control, fixture, forest)?;
    let terminal_mass: f64 = route
        .terminal_parcels()
        .iter()
        .map(|parcel| parcel.mass_kg_m2_tile())
        .sum();
    let terminal_energy: f64 = route
        .terminal_parcels()
        .iter()
        .map(|parcel| parcel.energy_j_m2_tile())
        .sum();
    if !terminal_mass.is_finite() || terminal_mass <= 0.0 || !terminal_energy.is_finite() {
        return Err(M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Routing(
                openwepp_land_surface_energy::LandSurfaceEnergyError::ConstitutiveDomain(
                    "M1 receiver terminal mixture",
                ),
            ),
            rejected_candidate: None,
        });
    }
    let terminal_h = terminal_energy / terminal_mass;
    let (
        vegetation_configuration,
        vegetation_state,
        lse_configuration,
        lse_state,
        forcing,
        hydrology,
        receipt,
    ) = prescribed_sixty_second_context(fixture)?;
    let mut contributors = route
        .terminal_parcels()
        .iter()
        .map(|parcel| M1ReceiverContribution {
            origin: parcel.origin().to_owned(),
            source_parcel_id: "m1-prescribed-terminal-receiver".to_owned(),
            kind: DirectSurfaceLiquidParcelKind::TerminalReceiver,
            transaction_id: TransactionId(41),
            mass: parcel.mass_kg_m2_tile(),
            enthalpy: parcel.enthalpy_j_kg(),
            fraction: parcel.mass_kg_m2_ofe_ground() / parcel.mass_kg_m2_tile(),
            source_occupancy_id: parcel.source_occupancy_id().to_owned(),
            destination_occupancy_id: parcel.destination_occupancy_id().map(str::to_owned),
        })
        .collect::<Vec<_>>();
    let mut terminal_parcel = DirectOpenLiquidIngressParcel {
        kind: DirectSurfaceLiquidParcelKind::TerminalReceiver,
        parcel_id: ParcelId::try_new("m1-prescribed-terminal-receiver").map_err(|_| {
            M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                rejected_candidate: None,
            }
        })?,
        source_owner_id: ResourceOwnerId::try_new("vegetation-v8").map_err(|_| {
            M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Owner),
                rejected_candidate: None,
            }
        })?,
        source_ofe_id: forest.key.ofe_id.clone(),
        source_tile_id: forest.key.tile_id.clone(),
        destination_ofe_id: forest.key.ofe_id.clone(),
        destination_tile_id: forest.key.tile_id.clone(),
        accepted_source_state_sha256: Sha256Digest::try_new(vegetation_state.state_sha256.clone())
            .map_err(|_| M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                rejected_candidate: None,
            })?,
        amount: amount(terminal_mass, terminal_h),
    };
    let mut handoff = M1ReceiverAuthenticatedHandoff {
        parcel_id: terminal_parcel.parcel_id.clone(),
        kind: terminal_parcel.kind,
        source_owner_id: terminal_parcel.source_owner_id.clone(),
        source_ofe_id: terminal_parcel.source_ofe_id.clone(),
        source_tile_id: terminal_parcel.source_tile_id.clone(),
        destination_ofe_id: terminal_parcel.destination_ofe_id.clone(),
        destination_tile_id: terminal_parcel.destination_tile_id.clone(),
        accepted_source_state_sha256: terminal_parcel.accepted_source_state_sha256.clone(),
        transaction_id: TransactionId(41),
        interval_s: 60.0,
    };
    // Negative controls poison the authenticated handoff or the real ingress;
    // every rejection is subsequently produced by this preflight or the native
    // receiver, never by a selector label.
    match injection {
        Some(M1ReceiverFailureInjection::WrongPhase) => {
            terminal_parcel.amount.temperature_k = 250.0
        }
        Some(M1ReceiverFailureInjection::WrongOwner) => {
            terminal_parcel.source_owner_id =
                ResourceOwnerId::try_new("foreign-owner").map_err(|_| {
                    M1ReceiverDiagnosticError {
                        injection: None,
                        source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Owner),
                        rejected_candidate: None,
                    }
                })?;
            handoff.source_owner_id = terminal_parcel.source_owner_id.clone();
        }
        Some(M1ReceiverFailureInjection::WrongSupport) => {
            // Keep the authenticated handoff sealed at 60 s; poison only the
            // actual native ingress support so its preflight rejects it.
            terminal_parcel.amount.end_s = 61.0;
        }
        Some(M1ReceiverFailureInjection::WrongLiquidEnthalpy) => {
            terminal_parcel.amount.specific_liquid_enthalpy_j_kg += 1.0
        }
        Some(M1ReceiverFailureInjection::WrongAreaConversion) => contributors[0].fraction *= 0.5,
        Some(M1ReceiverFailureInjection::WrongSourceBranch) => {
            contributors[0].source_occupancy_id.push_str(":foreign")
        }
        _ => {}
    }
    // This validates the selected source owner, source state, canonical parcel
    // identity, topology, and support before the native ingress consumes it.
    // The phase boundary is liquid-only for this receiver handoff.
    handoff
        .validate(&vegetation_state.state_sha256, forest)
        .map_err(|mut error| {
            error.injection = injection;
            error
        })?;
    validate_contributor_handoff(&contributors, &route).map_err(|mut error| {
        error.injection = injection;
        error
    })?;
    if terminal_parcel.amount.temperature_k < 273.15 {
        return Err(M1ReceiverDiagnosticError {
            injection,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Phase),
            rejected_candidate: None,
        });
    }
    if terminal_parcel
        .amount
        .specific_liquid_enthalpy_j_kg
        .to_bits()
        != (4218.0 * (terminal_parcel.amount.temperature_k - 273.15)).to_bits()
    {
        return Err(M1ReceiverDiagnosticError {
            injection,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::LiquidEnthalpy),
            rejected_candidate: None,
        });
    }
    let mut ingress = DirectSurfaceLiquidIngressInput {
        transaction_id: TransactionId(41),
        day_index: 0,
        interval_index: 0,
        interval_s: 60.0,
        tile_ingress: vec![
            DirectTileGroundIngress::CoveredCanopyReleaseAndTerminalGround {
                ofe_id: forest.key.ofe_id.clone(),
                tile_id: forest.key.tile_id.clone(),
                surface_id: forest.key.surface_id.clone(),
                release: DirectCanopyLiquidRelease {
                    throughfall: amount(0.0, 0.0),
                    initial_drainage: amount(0.0, 0.0),
                    second_drainage: amount(0.0, 0.0),
                    stemflow: amount(0.0, 0.0),
                },
                direct_ground_parcels: vec![terminal_parcel],
            },
            DirectTileGroundIngress::OpenRawPrecipitation {
                ofe_id: open.key.ofe_id.clone(),
                tile_id: open.key.tile_id.clone(),
                surface_id: open.key.surface_id.clone(),
                raw_precipitation: amount(0.0, 0.0),
            },
        ],
        wb14_parameters: vec![DirectOfeWb14Parameters {
            ofe_id: forest.key.ofe_id.clone(),
            effective_conductivity_m_s: 1e-6,
            matric_potential_m: 0.1,
            infiltration_storage_capacity_m: 0.04,
        }],
    };
    if injection == Some(M1ReceiverFailureInjection::DuplicateTransfer) {
        let DirectTileGroundIngress::CoveredCanopyReleaseAndTerminalGround {
            direct_ground_parcels,
            ..
        } = &mut ingress.tile_ingress[0]
        else {
            unreachable!()
        };
        direct_ground_parcels.push(direct_ground_parcels[0].clone());
    }
    let _prescribed_ingress =
        super::multi_tile_runtime::set_m1_prescribed_ingress_for_test(ingress);
    let adapter = LandSurfaceEnergyRealHydrologyAdapter::new(&hydrology);
    let thermal =
        super::V8SoilThermalPhysicalBeginning::try_from_v1(&fixture.thermal).map_err(|_| {
            M1ReceiverDiagnosticError {
                injection: Some(M1ReceiverFailureInjection::WrongSupport),
                source: M1ReceiverDiagnosticSource::Injection(
                    M1ReceiverFailureInjection::WrongSupport,
                ),
                rejected_candidate: None,
            }
        })?;
    let result = super::execute_v8_lse_runtime_shadow_v11_physical_with_carriers(
        &vegetation_configuration,
        &vegetation_state,
        &ResourceOwnerId::try_new("vegetation-v8").map_err(|_| M1ReceiverDiagnosticError {
            injection: injection.filter(|value| *value == M1ReceiverFailureInjection::WrongOwner),
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Owner),
            rejected_candidate: None,
        })?,
        &receipt,
        &lse_configuration,
        &lse_state,
        &forcing,
        &adapter,
        &fixture.surface_configuration,
        0,
        0,
        &[DirectOfeWb14Parameters {
            ofe_id: forest.key.ofe_id.clone(),
            effective_conductivity_m_s: 1e-6,
            matric_potential_m: 0.1,
            infiltration_storage_capacity_m: 0.04,
        }],
        &thermal,
        &FullNitrogen(Cell::new(0)),
        &fixture.biogeochemistry,
        openwepp_land_surface_energy::CoveredColumnAuthority::HistoricalV8,
        None,
        60.0_f64.to_bits(),
        None,
        true,
        None,
        None,
    )
    .map_err(|source| {
        let actual_context = match &source {
            ExecuteV8LseRuntimeShadowError::Physical(
                super::LandSurfaceEnergyShadowError::SurfaceLiquid(
                    crate::DirectSurfaceLiquidError::Failure(failure),
                ),
            ) if failure.phase == crate::DirectSurfaceLiquidPhase::IngressCandidate
                && failure.detail == "invalid ingress amount domain" => Some(M1ReceiverContextError::Support),
            ExecuteV8LseRuntimeShadowError::Physical(
                super::LandSurfaceEnergyShadowError::SurfaceLiquid(
                    crate::DirectSurfaceLiquidError::Failure(failure),
                ),
            ) if failure.phase == crate::DirectSurfaceLiquidPhase::IngressCandidate
                && failure.detail == "surface-liquid identity failure: invalid covered runon kind, destination, or identity" => Some(M1ReceiverContextError::Duplicate),
            _ => None,
        };
        M1ReceiverDiagnosticError {
            injection,
            source: M1ReceiverDiagnosticSource::Runtime(source, actual_context),
            rejected_candidate: None,
        }
    })?;
    let actual_candidate = result.hydrology_candidate().clone();
    let receipts = actual_candidate.surface_ingress().receipts().to_vec();
    let mut checked_receipts = receipts.clone();
    match injection {
        Some(M1ReceiverFailureInjection::WrongReceiptDestination) => {
            checked_receipts[0].recipient_store_key.tile_id = open.key.tile_id.clone();
        }
        Some(M1ReceiverFailureInjection::MissingReceipt) => checked_receipts.clear(),
        Some(M1ReceiverFailureInjection::ForeignReceipt) => {
            checked_receipts[0].source_parcel_id.push_str(":foreign");
        }
        _ => {}
    }
    let matching_receipts = validate_terminal_receipts(&checked_receipts, &handoff, forest)
        .map_err(|mut error| {
            error.injection = injection;
            error
        })?;
    let receipt_mass: f64 = matching_receipts
        .iter()
        .map(|r| r.mass_kg_m2_basis_ofe_ground)
        .sum();
    let receipt_energy: f64 = matching_receipts
        .iter()
        .map(|r| r.enthalpy_j_m2_basis_ofe_ground)
        .sum();
    let contributor_mass: f64 = contributors
        .iter()
        .map(M1ReceiverContribution::ofe_mass_kg_m2_ground)
        .sum();
    let contributor_energy: f64 = contributors
        .iter()
        .map(M1ReceiverContribution::ofe_enthalpy_j_m2_ground)
        .sum();
    if (receipt_mass - contributor_mass).abs() > 1.0e-12
        || (receipt_energy - contributor_energy).abs() > 1.0e-8
    {
        return Err(M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Branch),
            rejected_candidate: None,
        });
    }
    let native_transaction_id = actual_candidate.transaction_id();
    let diagnostic = M1ReceiverDiagnosticResult {
        actual_candidate,
        contribution_join: M1ReceiverContributionJoin {
            contributors: contributors.clone(),
        },
        capability: M1NativeCapability::new(native_transaction_id),
    };
    if injection.is_none() {
        let receiver = diagnostic.actual_candidate.receiver_closure_operands();
        eprintln!(
            "M1_RECEIVER_RAW_PRIMITIVES={}",
            serde_json::json!({
                "contributors": contributors.iter().map(|row| serde_json::json!({"origin":row.origin,"source_occupancy_id":row.source_occupancy_id,"destination_occupancy_id":row.destination_occupancy_id,"source_parcel_id":row.source_parcel_id,"kind":format!("{:?}",row.kind),"transaction_id":row.transaction_id.0.to_string(),"mass":row.mass,"h":row.enthalpy,"fraction":row.fraction})).collect::<Vec<_>>(),
                "receipts": receipts.iter().map(|row| serde_json::json!({"parcel_id":row.parcel_id,"source_parcel_id":row.source_parcel_id,"kind":format!("{:?}",row.kind),"transaction_id":row.transaction_id.0.to_string(),"start_s":row.start_s,"end_s":row.end_s,"mass":row.mass_kg_m2_basis_ofe_ground,"temperature_k":row.temperature_k,"energy":row.enthalpy_j_m2_basis_ofe_ground,"basis_ofe":row.basis_ofe_id.as_str()})).collect::<Vec<_>>(),
                "production_soil": receiver.production_soil.iter().map(|row| serde_json::json!({"ofe":row.ofe_id.as_str(),"infiltration_m":row.infiltration_m,"begin":row.beginning_aggregate_soil_water_m,"end":row.ending_aggregate_soil_water_m,"layers":row.ordered_layers.iter().map(|layer| serde_json::json!({"id":layer.layer_id.as_str(),"begin":layer.beginning_liquid_m,"end":layer.ending_liquid_m,"depth":layer.layer_depth_m,"residual":layer.residual_theta,"frozen":layer.frozen_depth_m})).collect::<Vec<_>>() })).collect::<Vec<_>>(),
                "thermal": receiver.soil_thermal.iter().map(|row| serde_json::json!({"ofe":row.ofe_id.as_str(),"tile":row.tile_id.as_str(),"layer":row.layer_id.as_str(),"begin":row.beginning_enthalpy_j_m2_ofe_ground,"infiltration":row.infiltration_enthalpy_j_m2_ofe_ground,"end":row.ending_enthalpy_j_m2_ofe_ground})).collect::<Vec<_>>(),
                "lse": receiver.lse_tiles.iter().map(|row| serde_json::json!({"ofe":row.ofe_id.as_str(),"tile":row.tile_id.as_str(),"fraction":row.tile_fraction,"begin":row.beginning_enthalpy_j_m2_tile_ground,"retained":row.retained_enthalpy_j_m2_ofe_ground,"end":row.ending_enthalpy_j_m2_tile_ground})).collect::<Vec<_>>(),
            })
        );
    }
    let local_beginning = M1ReceiverLocalOwners {
        frame: diagnostic.actual_candidate.beginning_frame().clone(),
        lse_state: lse_state.clone(),
        vegetation_state: vegetation_state.clone(),
        thermal_candidates: diagnostic
            .actual_candidate
            .pre_ingress_soil_thermal_candidates()
            .to_vec(),
        biogeochemistry: fixture.biogeochemistry.clone(),
    };
    let mut local_owners = install_actual_receiver_candidate_locally(
        &lse_state,
        &vegetation_state,
        &fixture.biogeochemistry,
        &diagnostic.actual_candidate,
    )?;
    // This is a local diagnostic owner transaction. It proves the authentic
    // candidate can be installed without publishing it into the fixture.
    if local_owners.lse_state == local_beginning.lse_state
        || local_owners.thermal_candidates == local_beginning.thermal_candidates
    {
        return Err(M1ReceiverDiagnosticError {
            injection: None,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
            rejected_candidate: None,
        });
    }
    if injection == Some(M1ReceiverFailureInjection::LateReceiverFailure) {
        local_owners = local_beginning.clone();
        if local_owners != local_beginning {
            return Err(M1ReceiverDiagnosticError {
                injection: None,
                source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Identity),
                rejected_candidate: None,
            });
        }
        return Err(M1ReceiverDiagnosticError {
            injection,
            source: M1ReceiverDiagnosticSource::Injection(
                M1ReceiverFailureInjection::LateReceiverFailure,
            ),
            rejected_candidate: Some(diagnostic),
        });
    }
    Ok(diagnostic)
}

pub(crate) fn execute_m1_cold_canopy_receiver_from_prepared_context(
    fixture: &mut EndpointFixture,
    _control: &M1PrescribedRoutingControl,
    mut prepared: M1PreparedCallerContext,
    injection: Option<M1ReceiverFailureInjection>,
) -> Result<M1ReceiverDiagnosticResult, M1ReceiverDiagnosticError> {
    if injection == Some(M1ReceiverFailureInjection::WrongPlantArea) {
        prepared.input.column.occupancies[0].lai *= 0.5;
    }
    let actual_control = prepared.actual_routing_control()?;
    validate_m1_prepared_context(&prepared, &actual_control).map_err(|mut error| {
        error.injection = injection;
        error
    })?;
    let route = openwepp_land_surface_energy::route_m1_column_liquid(&actual_control.input)
        .map_err(|source| M1ReceiverDiagnosticError {
            injection,
            source: M1ReceiverDiagnosticSource::Routing(source),
            rejected_candidate: None,
        })?;
    if route
        .terminal_parcels()
        .iter()
        .all(|parcel| parcel.mass_kg_m2_tile().to_bits() == 0.0_f64.to_bits())
    {
        return Err(M1ReceiverDiagnosticError {
            injection,
            source: M1ReceiverDiagnosticSource::Context(M1ReceiverContextError::Branch),
            rejected_candidate: None,
        });
    }
    execute_m1_cold_canopy_receiver_diagnostic(fixture, &actual_control, injection)
}

pub(crate) fn advance_m1_caller_support(
    caller: &mut M1CallerState,
    fixture: &mut EndpointFixture,
    prepared: M1PreparedCallerContext,
    support: u64,
    injection: Option<M1ReceiverFailureInjection>,
) -> Result<M1CallerSupportResult, M1ReceiverDiagnosticError> {
    let bootstrap_gsi = fixture.receipt.forcing().gsi;
    advance_m1_caller_support_with_gsi(caller, fixture, prepared, support, bootstrap_gsi, injection)
}

/// Provider-aware form of the M1 receiver seam.  The GSI is authenticated by
/// the admitted fixed support, rather than copied from the bootstrap fixture.
pub(crate) fn advance_m1_caller_support_with_gsi(
    caller: &mut M1CallerState,
    fixture: &mut EndpointFixture,
    prepared: M1PreparedCallerContext,
    support: u64,
    authenticated_gsi: f64,
    injection: Option<M1ReceiverFailureInjection>,
) -> Result<M1CallerSupportResult, M1ReceiverDiagnosticError> {
    let control = prepared.actual_routing_control()?;
    validate_m1_prepared_context(&prepared, &control)?;
    let route =
        openwepp_land_surface_energy::route_m1_column_liquid(&control.input).map_err(|source| {
            M1ReceiverDiagnosticError {
                injection,
                source: M1ReceiverDiagnosticSource::Routing(source),
                rejected_candidate: None,
            }
        })?;
    // Mint the M1 ending before native ingress, but retain it as a candidate.
    // Native parcels can therefore prove their source is this exact sealed M1
    // ending while any downstream failure leaves the parent uninstalled.
    let (m1_candidate, m1_bgc) = caller.prepared_m1_endings(
        &prepared,
        authenticated_gsi,
        // Support identities occupy the high u128 namespace.  Persistent M1
        // and BGC parent revisions are u64-derived values, so this cannot
        // collide with a parent lineage and remains monotone by support.
        TransactionId((1_u128 << 127) | u128::from(support)),
    )?;
    let current = caller.native_fixture_from_current(
        fixture,
        &prepared,
        authenticated_gsi,
        m1_candidate.support_transaction_id(),
    )?;
    let native = execute_native_m1_receiver_from_m1_ending(
        &current,
        &prepared,
        Some(&route),
        m1_candidate.ending(),
        m1_candidate.support_transaction_id(),
    )
    .map_err(|source| M1ReceiverDiagnosticError {
        injection,
        source: M1ReceiverDiagnosticSource::Runtime(
            ExecuteV8LseRuntimeShadowError::Physical(source),
            None,
        ),
        rejected_candidate: None,
    })?;
    if route.terminal_parcels().is_empty() {
        caller.stage(
            &prepared,
            support,
            &fixture.lse_configuration,
            m1_candidate,
            m1_bgc,
            Some(&native),
            native_fixture_consumed_forcing_bits(&current),
        )?;
        return Ok(M1CallerSupportResult::ZeroTransfer);
    }
    let mut received = M1ReceiverDiagnosticResult {
        actual_candidate: native,
        contribution_join: M1ReceiverContributionJoin {
            contributors: route
                .terminal_parcels()
                .iter()
                .enumerate()
                .map(
                    |(index, parcel)| -> Result<M1ReceiverContribution, M1ReceiverDiagnosticError> {
                        Ok(M1ReceiverContribution {
                            origin: parcel.origin().to_owned(),
                            // This is the terminal capability identifier minted by
                            // the native ingress, not a routing diagnostic label.
                            source_parcel_id: format!("m1-native-terminal-{index}"),
                            kind: DirectSurfaceLiquidParcelKind::TerminalReceiver,
                            transaction_id: m1_candidate.support_transaction_id(),
                            mass: parcel.mass_kg_m2_tile(),
                            enthalpy: parcel.enthalpy_j_kg(),
                            fraction: configured_m1_surface_records(
                                &current,
                                parcel.source_occupancy_id(),
                            )
                            .and_then(|(surface, _)| {
                                current
                                    .lse_configuration
                                    .ofes
                                    .iter()
                                    .find(|ofe| ofe.ofe_id == surface.key.ofe_id)
                                    .and_then(|ofe| {
                                        ofe.tiles
                                            .iter()
                                            .find(|tile| tile.tile_id == surface.key.tile_id)
                                    })
                                    .map(|tile| tile.fraction_ofe_ground)
                                    .ok_or_else(m1_owner_identity_error)
                            })?,
                            source_occupancy_id: parcel.source_occupancy_id().to_owned(),
                            destination_occupancy_id: parcel
                                .destination_occupancy_id()
                                .map(str::to_owned),
                        })
                    },
                )
                .collect::<Result<Vec<_>, _>>()?,
        },
        capability: M1NativeCapability::new(m1_candidate.support_transaction_id()),
    };
    if injection == Some(M1ReceiverFailureInjection::LateReceiverFailure) {
        received.capability.consume()?;
        return Err(M1ReceiverDiagnosticError {
            injection,
            source: M1ReceiverDiagnosticSource::Injection(
                M1ReceiverFailureInjection::LateReceiverFailure,
            ),
            rejected_candidate: Some(received),
        });
    }
    // Consume the native capability before owner installation. A second
    // presentation of this candidate is refused by the same guard before it
    // can reach the real install seam.
    received.capability.consume()?;
    caller.stage(
        &prepared,
        support,
        &fixture.lse_configuration,
        m1_candidate,
        m1_bgc,
        Some(received.actual_candidate()),
        native_fixture_consumed_forcing_bits(&current),
    )?;
    Ok(M1CallerSupportResult::PositiveTransfer(received))
}

fn native_fixture_consumed_forcing_bits(fixture: &EndpointFixture) -> [u64; 10] {
    [
        fixture.forcing.air_temperature_k.to_bits(),
        fixture.forcing.air_specific_humidity_kg_kg.to_bits(),
        fixture.forcing.air_pressure_pa.to_bits(),
        fixture.forcing.reference_wind_m_s.to_bits(),
        fixture.forcing.direct_vis_w_m2.to_bits(),
        fixture.forcing.diffuse_vis_w_m2.to_bits(),
        fixture.forcing.direct_nir_w_m2.to_bits(),
        fixture.forcing.diffuse_nir_w_m2.to_bits(),
        fixture.forcing.atmospheric_downward_longwave_w_m2.to_bits(),
        fixture.receipt.forcing().rain_kg_m2.to_bits(),
    ]
}

/// Execute the accepted M1 root withdrawals against the current hydrology
/// owners.  This intentionally does not enter the V8 runtime: its request
/// rows are the accepted M1 hydraulic fluxes and its finalization is a
/// zero-pre-ingress LSE/thermal pass-through before native ingress applies.
pub(crate) fn execute_native_m1_receiver_from_current_owners(
    fixture: &EndpointFixture,
    prepared: &M1PreparedCallerContext,
    routing: Option<&openwepp_land_surface_energy::M1ColumnLiquidRouting>,
) -> Result<UnifiedRealHydrologyCandidate, super::LandSurfaceEnergyShadowError> {
    // Retained only as the frozen direct-fixture control. Caller integration
    // always uses the sealed M1 ending overload below.
    execute_native_m1_receiver_with_source(fixture, prepared, routing, None)
}

fn execute_native_m1_receiver_from_m1_ending(
    fixture: &EndpointFixture,
    prepared: &M1PreparedCallerContext,
    routing: Option<&openwepp_land_surface_energy::M1ColumnLiquidRouting>,
    ending: &openwepp_vegetation::cold_canopy_m1_owner::M1OwnerState,
    support_transaction_id: TransactionId,
) -> Result<UnifiedRealHydrologyCandidate, super::LandSurfaceEnergyShadowError> {
    execute_native_m1_receiver_with_source(
        fixture,
        prepared,
        routing,
        Some((ending, support_transaction_id)),
    )
}

fn execute_native_m1_receiver_with_source(
    fixture: &EndpointFixture,
    prepared: &M1PreparedCallerContext,
    routing: Option<&openwepp_land_surface_energy::M1ColumnLiquidRouting>,
    m1_ending: Option<(
        &openwepp_vegetation::cold_canopy_m1_owner::M1OwnerState,
        TransactionId,
    )>,
) -> Result<UnifiedRealHydrologyCandidate, super::LandSurfaceEnergyShadowError> {
    use openwepp_land_surface_energy::{
        ComponentId, GroundWaterKey, OwnerKind, OwnerRollbackHash, PotentialWaterRequestBatch,
        RequestingComponent, RuntimeTileIdentity, StandGroundWaterAmountBasis, WaterAmount,
        WaterAuthorizationReason, WaterProtocol, WaterSourceType,
    };
    use sha2::Digest;

    // The native withdrawal request is legal only for the forcing that the
    // admitted M1 support actually solved.  These comparisons bind the
    // rebuilt native context to its prepared support before any candidate or
    // authorization work occurs; endpoint bootstrap forcing is never an
    // alternate authority.
    let forcing = &fixture.forcing;
    let column = &prepared.input.column;
    if forcing.interval_s.to_bits() != prepared.evaluation.support_duration_s().to_bits()
        || forcing.air_temperature_k.to_bits() != column.air_temperature_k.to_bits()
        || forcing.air_specific_humidity_kg_kg.to_bits()
            != column.air_specific_humidity_kg_kg.to_bits()
        || forcing.air_pressure_pa.to_bits() != column.pressure_pa.to_bits()
        || forcing.reference_wind_m_s.to_bits() != column.reference_wind_m_s.to_bits()
        || forcing.direct_vis_w_m2.to_bits()
            != column.shortwave.incident_w_m2_tile.direct_vis.to_bits()
        || forcing.diffuse_vis_w_m2.to_bits()
            != column.shortwave.incident_w_m2_tile.diffuse_vis.to_bits()
        || forcing.direct_nir_w_m2.to_bits()
            != column.shortwave.incident_w_m2_tile.direct_nir.to_bits()
        || forcing.diffuse_nir_w_m2.to_bits()
            != column.shortwave.incident_w_m2_tile.diffuse_nir.to_bits()
        || forcing.atmospheric_downward_longwave_w_m2.to_bits()
            != column.atmospheric_downward_longwave_w_m2.to_bits()
    {
        return Err(super::LandSurfaceEnergyShadowError::Identity(
            "M1 admitted forcing/native context binding",
        ));
    }

    let thermal = super::V8SoilThermalPhysicalBeginning::try_from_v1(&fixture.thermal)
        .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 thermal beginning"))?;
    let adapter = LandSurfaceEnergyRealHydrologyAdapter::new(&fixture.hydrology);
    let hydrology_sha = super::unified_beginning_hydrology_snapshot_sha256(
        &adapter,
        &fixture.surface_configuration,
    )?;
    let transaction_id = m1_ending.map_or_else(
        || fixture.receipt.transaction_id(),
        |(_, support_transaction_id)| support_transaction_id,
    );
    let (forest, _) =
        configured_m1_surface_records(fixture, &prepared.input.topology.occupancy_ids[0])
            .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 configured surface"))?;
    let lane = fixture
        .surface_configuration
        .ofe_bindings
        .iter()
        .find(|row| row.ofe_id == forest.key.ofe_id)
        .ok_or(super::LandSurfaceEnergyShadowError::Identity(
            "M1 forest lane",
        ))?;
    let (vegetation_owner_name, vegetation_state_sha256) = m1_ending.map_or_else(
        || {
            (
                "vegetation-v8",
                fixture.vegetation_state.state_sha256.as_str(),
            )
        },
        |(ending, _)| ("vegetation-m1", ending.state_sha256()),
    );
    let vegetation_owner = ResourceOwnerId::try_new(vegetation_owner_name)
        .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 vegetation owner"))?;
    let vegetation_state_sha256 =
        openwepp_land_surface_energy::Sha256Digest::try_new(vegetation_state_sha256.to_owned())
            .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 vegetation digest"))?;
    let biogeochemistry_owner = ResourceOwnerId::try_new("biogeochemistry-v8")
        .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 biogeochemistry owner"))?;
    let biogeochemistry_sha = openwepp_land_surface_energy::Sha256Digest::try_new(format!(
        "{:x}",
        sha2::Sha256::digest(
            serde_json::to_vec(&fixture.biogeochemistry)
                .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 BGC bytes"))?
        )
    ))
    .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 BGC digest"))?;
    let identity_for = |tile: &openwepp_land_surface_energy::TileState| -> Result<RuntimeTileIdentity, super::LandSurfaceEnergyShadowError> {
        let surface = fixture.surface_configuration.records.iter().find(|row| row.key.ofe_id == tile.ofe_id && row.key.tile_id == tile.tile_id).ok_or(super::LandSurfaceEnergyShadowError::Identity("M1 tile surface"))?;
        Ok(RuntimeTileIdentity {
        transaction_id,
        soil_thermal_transaction_id: thermal.transaction_id_or(transaction_id),
        lse_owner_id: fixture.lse_configuration.owner_id.clone(),
        hydrology_owner_id: fixture
            .lse_configuration
            .hydrology_configuration
            .owner_id
            .clone(),
        soil_thermal_owner_id: fixture
            .lse_configuration
            .soil_thermal_configuration
            .owner_id
            .clone(),
        vegetation_owner_id: vegetation_owner.clone(),
        biogeochemistry_owner_id: biogeochemistry_owner.clone(),
        configuration_sha256: fixture.lse_configuration.configuration_sha256.clone(),
        beginning_lse_state_sha256: fixture.lse_state.state_sha256.clone(),
        beginning_hydrology_snapshot_sha256: hydrology_sha.clone(),
        beginning_soil_thermal_state_sha256: thermal.state_sha256().clone(),
        beginning_vegetation_state_sha256: vegetation_state_sha256.clone(),
        beginning_biogeochemistry_state_sha256: biogeochemistry_sha.clone(),
        ofe_id: tile.ofe_id.clone(),
        tile_id: tile.tile_id.clone(),
        surface_id: surface.key.surface_id.clone(),
        surface_class: surface.key.surface_class,
        ground_source_type: WaterSourceType::LitterLiquid,
        ground_source_id: surface.key.source_id.clone(),
        ground_source_tile_id: Some(tile.tile_id.clone()),
        ground_soil_layer_id: None,
        tile_fraction: surface.tile_fraction,
        interval_s: prepared.evaluation.support_duration_s(),
    }) };
    let mut soil_sources = BTreeMap::new();
    let mut requests = Vec::new();
    for occupancy in prepared.evaluation.occupancies() {
        for (layer, flux) in occupancy
            .hydraulics
            .all_root_layer_ids
            .iter()
            .zip(&occupancy.hydraulics.all_root_fluxes_kg_m2_tile_s)
        {
            let component = ComponentId::try_new(occupancy.occupancy_id.clone())
                .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 occupancy"))?;
            let layer_id = SoilLayerId::try_new(layer.clone())
                .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 root layer"))?;
            let source = crate::vegetation_real_hydrology_shadow::RealHydrologySourceKey {
                ofe_lane: crate::vegetation_real_hydrology_shadow::RealHydrologyOfeLaneId {
                    lane_index: lane.production_lane_index,
                    lane_id: lane.production_lane_id,
                },
                layer_id: layer_id.clone(),
            };
            let key = GroundWaterKey {
                transaction_id,
                requesting_owner_id: vegetation_owner.clone(),
                requesting_component: RequestingComponent::VegetationRoot,
                ofe_id: forest.key.ofe_id.clone(),
                requesting_tile_id: forest.key.tile_id.clone(),
                occupancy_id: Some(component),
                surface_id: None,
                surface_class: None,
                source_type: WaterSourceType::SoilLayerLiquid,
                source_id: openwepp_land_surface_energy::SourceId::try_new(layer.clone())
                    .map_err(|_| super::LandSurfaceEnergyShadowError::Identity("M1 root source"))?,
                source_tile_id: None,
                soil_layer_id: Some(layer_id),
                amount_basis: StandGroundWaterAmountBasis::KgH2oM2StandGroundInterval,
            };
            let amount = flux * prepared.evaluation.support_duration_s() * forest.tile_fraction;
            if !amount.is_finite()
                || amount < 0.0
                || soil_sources.insert(key.clone(), source).is_some()
            {
                return Err(super::LandSurfaceEnergyShadowError::Identity(
                    "M1 root request",
                ));
            }
            requests.push(WaterAmount {
                key,
                amount_kg_m2_stand_ground: amount,
            });
        }
    }
    // The unified owner also seals one LSE ground receiver request per tile.
    // M1 has no pre-ingress ground withdrawal, so these are explicit lawful
    // zero uses rather than absent receivers.
    for record in &fixture.surface_configuration.records {
        requests.push(WaterAmount {
            key: GroundWaterKey {
                transaction_id,
                requesting_owner_id: fixture.lse_configuration.owner_id.clone(),
                requesting_component: RequestingComponent::GroundSurface,
                ofe_id: record.key.ofe_id.clone(),
                requesting_tile_id: record.key.tile_id.clone(),
                occupancy_id: None,
                surface_id: Some(record.key.surface_id.clone()),
                surface_class: Some(record.key.surface_class),
                source_type: record.key.source_type,
                source_id: record.key.source_id.clone(),
                source_tile_id: Some(record.key.tile_id.clone()),
                soil_layer_id: None,
                amount_basis: StandGroundWaterAmountBasis::KgH2oM2StandGroundInterval,
            },
            amount_kg_m2_stand_ground: 0.0,
        });
    }
    let batch = PotentialWaterRequestBatch::try_new(
        transaction_id,
        fixture.lse_state.state_sha256.clone(),
        requests,
    )?;
    let mut ordered_layers = Vec::new();
    for thermal_ofe in thermal.ordered_ofes() {
        let ofe = fixture
            .lse_configuration
            .ofes
            .iter()
            .find(|ofe| ofe.ofe_id == thermal_ofe.ofe_id)
            .ok_or(super::LandSurfaceEnergyShadowError::Identity(
                "M1 thermal OFE",
            ))?;
        let layers = thermal_ofe
            .ordered_layers
            .iter()
            .map(|layer| layer.layer_id.clone())
            .collect::<Vec<_>>();
        for tile in &ofe.tiles {
            ordered_layers.push((
                thermal_ofe.ofe_id.clone(),
                tile.tile_id.clone(),
                layers.clone(),
            ));
        }
    }
    let expectations = super::UnifiedReceiverExpectations::try_new(
        fixture.lse_configuration.owner_id.clone(),
        fixture.lse_state.state_sha256.clone(),
        fixture
            .lse_configuration
            .hydrology_configuration
            .owner_id
            .clone(),
        hydrology_sha.clone(),
        fixture
            .lse_configuration
            .soil_thermal_configuration
            .owner_id
            .clone(),
        thermal.state_sha256().clone(),
        ordered_layers,
    )?;
    let zero_ingress = || DirectIngressAmount {
        mass_kg_m2_tile_ground: 0.0,
        temperature_k: 273.15,
        specific_liquid_enthalpy_j_kg: 0.0,
        start_s: 0.0,
        end_s: adapter.owner.interval_s(),
    };
    let mut tile_ingress = Vec::new();
    for row in &fixture.surface_configuration.records {
        if row.key.surface_class == openwepp_land_surface_energy::SurfaceClass::ForestLitter {
            let mut direct_ground_parcels = Vec::new();
            if let Some(routing) = routing {
                for (index, parcel) in routing.terminal_parcels().iter().enumerate() {
                    let parcel_id = ParcelId::try_new(format!("m1-native-terminal-{index}"))
                        .map_err(|_| {
                            super::LandSurfaceEnergyShadowError::Identity("M1 parcel id")
                        })?;
                    direct_ground_parcels.push(DirectOpenLiquidIngressParcel {
                        kind: DirectSurfaceLiquidParcelKind::TerminalReceiver,
                        parcel_id,
                        source_owner_id: vegetation_owner.clone(),
                        source_ofe_id: row.key.ofe_id.clone(),
                        source_tile_id: row.key.tile_id.clone(),
                        destination_ofe_id: row.key.ofe_id.clone(),
                        destination_tile_id: row.key.tile_id.clone(),
                        accepted_source_state_sha256: vegetation_state_sha256.clone(),
                        amount: DirectIngressAmount {
                            mass_kg_m2_tile_ground: parcel.mass_kg_m2_tile(),
                            temperature_k: 273.15 + parcel.enthalpy_j_kg() / 4218.0,
                            specific_liquid_enthalpy_j_kg: parcel.enthalpy_j_kg(),
                            start_s: 0.0,
                            end_s: adapter.owner.interval_s(),
                        },
                    });
                }
            }
            // The terminal-ground variant is a custody-bearing ingress
            // shape: it is invalid without an actual terminal parcel.  A
            // solved no-drainage support remains a lawful canopy-only no-op.
            let release = DirectCanopyLiquidRelease {
                throughfall: zero_ingress(),
                initial_drainage: zero_ingress(),
                second_drainage: zero_ingress(),
                stemflow: zero_ingress(),
            };
            tile_ingress.push(if direct_ground_parcels.is_empty() {
                DirectTileGroundIngress::CoveredCanopyRelease {
                    ofe_id: row.key.ofe_id.clone(),
                    tile_id: row.key.tile_id.clone(),
                    surface_id: row.key.surface_id.clone(),
                    release,
                }
            } else {
                DirectTileGroundIngress::CoveredCanopyReleaseAndTerminalGround {
                    ofe_id: row.key.ofe_id.clone(),
                    tile_id: row.key.tile_id.clone(),
                    surface_id: row.key.surface_id.clone(),
                    release,
                    direct_ground_parcels,
                }
            });
        } else {
            tile_ingress.push(DirectTileGroundIngress::OpenRawPrecipitation {
                ofe_id: row.key.ofe_id.clone(),
                tile_id: row.key.tile_id.clone(),
                surface_id: row.key.surface_id.clone(),
                raw_precipitation: zero_ingress(),
            });
        }
    }
    let ingress = DirectSurfaceLiquidIngressInput {
        transaction_id,
        day_index: adapter.owner.day_index(),
        interval_index: 0,
        interval_s: adapter.owner.interval_s(),
        tile_ingress,
        wb14_parameters: vec![DirectOfeWb14Parameters {
            ofe_id: forest.key.ofe_id.clone(),
            effective_conductivity_m_s: 1e-6,
            matric_potential_m: 0.1,
            infiltration_storage_capacity_m: 0.04,
        }],
    };
    super::execute_unified_real_hydrology_shadow(
        &adapter,
        &fixture.surface_configuration,
        &expectations,
        &batch,
        &soil_sources,
        &ingress,
        |authorizations| {
            for row in authorizations {
                let request = batch
                    .requests
                    .iter()
                    .find(|request| request.key == row.key)
                    .ok_or(super::LandSurfaceEnergyShadowError::Identity(
                        "M1 authorization key",
                    ))?;
                if row.amount_kg_m2_stand_ground.to_bits()
                    != request.amount_kg_m2_stand_ground.to_bits()
                    || (row.key.requesting_component == RequestingComponent::VegetationRoot
                        && request.amount_kg_m2_stand_ground > 0.0
                        && row.reason != WaterAuthorizationReason::FullSupply)
                {
                    return Err(super::LandSurfaceEnergyShadowError::Identity(
                        "M1 full supply authorization",
                    ));
                }
            }
            let thermal_candidates = fixture
                .lse_state
                .tiles
                .iter()
                .map(|tile| {
                    openwepp_land_surface_energy::build_soil_thermal_passthrough_candidate(
                        &identity_for(tile)?,
                        thermal.finalization_beginning(),
                    )
                    .map_err(Into::into)
                })
                .collect::<Result<Vec<_>, super::LandSurfaceEnergyShadowError>>()?;
            let rollback_hashes = [
                (
                    OwnerKind::LandSurfaceEnergy,
                    fixture.lse_configuration.owner_id.as_str(),
                    &fixture.lse_state.state_sha256,
                ),
                (
                    OwnerKind::Hydrology,
                    fixture
                        .lse_configuration
                        .hydrology_configuration
                        .owner_id
                        .as_str(),
                    &hydrology_sha,
                ),
                (
                    OwnerKind::SoilThermal,
                    fixture
                        .lse_configuration
                        .soil_thermal_configuration
                        .owner_id
                        .as_str(),
                    thermal.state_sha256(),
                ),
            ]
            .into_iter()
            .map(|(owner_kind, owner_id, digest)| OwnerRollbackHash {
                owner_kind,
                owner_id: owner_id.to_owned(),
                before_sha256: digest.clone(),
                after_sha256: digest.clone(),
            })
            .collect();
            let protocol = WaterProtocol {
                transaction_id,
                hydrology_owner_id: fixture
                    .lse_configuration
                    .hydrology_configuration
                    .owner_id
                    .clone(),
                beginning_snapshot_sha256: expectations.beginning_hydrology_snapshot_sha256.clone(),
                requests: batch.requests.clone(),
                authorizations: authorizations.to_vec(),
                finalized_uses: batch.requests.clone(),
                condensation_credits: Vec::new(),
            };
            super::UnifiedLseFinalization::try_new(
                &expectations,
                protocol,
                fixture.lse_state.tiles.clone(),
                thermal_candidates,
                rollback_hashes,
            )
        },
    )
}
