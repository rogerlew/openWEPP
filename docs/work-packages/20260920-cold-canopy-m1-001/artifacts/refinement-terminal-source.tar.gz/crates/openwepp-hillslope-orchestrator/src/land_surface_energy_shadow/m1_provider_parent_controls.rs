//! Expected-red controls which own actual M1 parent admission and all supports.

use std::collections::{BTreeMap, BTreeSet};

use openwepp_coupled_time::CoupledTimeError;

use super::m1_fixed_sequence_provider::{
    FixedSequenceAdmissionAudit, FixedSequenceSourceAdapter, M1ParentExecutionError,
    actual_m1_caller_beginning_for_provider_controls, admit_fixed_sequence_provider_for_parent,
    advance_fixed_sequence_support,
};
use super::m1_receiver::M1ReceiverFailureInjection;

const MANIFEST: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/m1-fixed-sequence-adapter-dependencies-v1.json"
));
const PROVIDER_ID: &str = "OPENWEPP_COLD_M1_FIXED_SEQUENCE_PROVIDER_V1";

fn parent_zero() -> super::m1_fixed_sequence_provider::AdmittedFixedSequenceProvider {
    let adapter =
        FixedSequenceSourceAdapter::from_retained_endpoint_fixture_with_dependency_manifest(
            MANIFEST.as_bytes(),
        );
    let payload = adapter
        .canonical_payload_bytes(PROVIDER_ID, 0)
        .expect("frozen payload");
    admit_fixed_sequence_provider_for_parent(
        &payload,
        &adapter,
        &mut FixedSequenceAdmissionAudit::new(),
    )
    .expect("admission")
}

fn assert_reservoir_closure(operands: &[openwepp_land_surface_energy::M1ReservoirOperands]) {
    for o in operands {
        let t = o.wet_temperature_k.expect("wet temperature");
        let mass = o.ending_mass_kg_m2
            - o.beginning_mass_kg_m2
            - o.dt_s * (o.incident_liquid_kg_m2_s - o.vapor_kg_m2_s - o.drainage_kg_m2_s);
        let enthalpy = o.ending_enthalpy_j_m2
            - o.beginning_enthalpy_j_m2
            - o.dt_s
                * (o.non_vapor_heat_w_m2 + o.incident_liquid_kg_m2_s * o.incident_enthalpy_j_kg
                    - o.vapor_kg_m2_s * (2_501_000. + 1_849. * (t - 273.15))
                    - o.drainage_kg_m2_s * 4_218. * (t - 273.15));
        assert!((mass - o.mass_residual_kg_m2).abs() <= 1e-12);
        assert!((enthalpy - o.enthalpy_residual_j_m2).abs() <= 1e-9);
        assert!(mass.abs() <= 1e-9 && enthalpy.abs() <= 1e-6);
    }
}

fn canonical_m1_owner(bytes: &[u8]) -> serde_json::Value {
    serde_json::from_slice(bytes).expect("actual canonical M1 owner JSON")
}

fn json_u128(value: &serde_json::Value) -> u128 {
    value
        .as_u64()
        .map(u128::from)
        .or_else(|| value.as_str().and_then(|value| value.parse().ok()))
        .expect("canonical M1 lineage integer")
}

fn m1_lineage(value: &serde_json::Value) -> (u64, BTreeMap<String, u128>) {
    let revision = value["revision"].as_u64().expect("canonical M1 revision");
    let strata = value["strata"].as_object().expect("canonical M1 strata");
    let lineage = strata
        .iter()
        .map(|(stratum, state)| (stratum.clone(), json_u128(&state["last_transaction_id"])))
        .collect();
    (revision, lineage)
}

fn m1_without_logical_lineage(mut value: serde_json::Value) -> serde_json::Value {
    let owner = value.as_object_mut().expect("canonical M1 owner object");
    owner.remove("revision");
    owner.remove("state_sha256");
    let strata = owner
        .get_mut("strata")
        .and_then(serde_json::Value::as_object_mut)
        .expect("canonical M1 strata");
    for state in strata.values_mut() {
        state
            .as_object_mut()
            .expect("canonical M1 stratum")
            .remove("last_transaction_id");
    }
    value
}

fn bgc_without_logical_lineage(mut value: serde_json::Value) -> serde_json::Value {
    value
        .as_object_mut()
        .expect("canonical BGC owner object")
        .remove("last_transaction_id");
    value
}

fn assert_raw_water_replay(
    raw_water: &[super::m1_fixed_sequence_provider::M1RawWaterOracle],
    transitions: &[openwepp_vegetation::v11::V11SharedResourceOwnerTransition],
) {
    use openwepp_vegetation::v11::V11SharedResourceKind;

    let water_transitions = transitions
        .iter()
        .filter(|transition| {
            transition.shared_resource_key.resource == V11SharedResourceKind::Water
        })
        .collect::<Vec<_>>();
    assert_eq!(
        raw_water.len(),
        water_transitions.len(),
        "one raw witness per full water key"
    );
    let transition_keys = water_transitions
        .iter()
        .map(|transition| transition.shared_resource_key.clone())
        .collect::<BTreeSet<_>>();
    let raw_keys = raw_water
        .iter()
        .map(|raw| raw.key.clone())
        .collect::<BTreeSet<_>>();
    assert_eq!(raw_keys.len(), raw_water.len(), "duplicate raw water key");
    assert_eq!(raw_keys, transition_keys, "missing or extra raw water key");

    let mut lanes = BTreeMap::<(usize, u32), Vec<_>>::new();
    for raw in raw_water {
        assert_eq!(raw.key.resource, V11SharedResourceKind::Water);
        assert_eq!(raw.key.owner_id, "hydrology");
        assert_eq!(raw.key.source_id, "soil_water");
        assert_eq!(raw.key.amount_basis, "kg_m2_stand_ground");
        lanes
            .entry((raw.lane_index, raw.lane_id))
            .or_default()
            .push(raw);
    }
    for (_, rows) in lanes {
        let first = rows[0];
        let mut replay = first.beginning_lane.clone();
        for raw in &rows {
            assert_eq!(raw.beginning_lane, first.beginning_lane);
            assert_eq!(raw.beginning_layer_ids, raw.receiver_layer_ids);
            assert_eq!(
                raw.receiver_beginning_lane_depth_bits,
                first.receiver_beginning_lane_depth_bits
            );
            assert_eq!(raw.ending_lane_depth_bits, first.ending_lane_depth_bits);
            assert_eq!(raw.infiltration_m_bits, first.infiltration_m_bits);
            assert_eq!(raw.beginning_layer_ids.len(), raw.beginning_lane.len());
            assert_eq!(
                raw.receiver_layer_ids.len(),
                raw.receiver_beginning_lane_depth_bits.len()
            );
            assert_eq!(raw.beginning_layer_ids[raw.layer_index], raw.key.layer_id);
            assert_eq!(raw.receiver_layer_ids[raw.layer_index], raw.key.layer_id);
            assert_eq!(raw.ordered_ingress, first.ordered_ingress);
            assert_eq!(raw.tillage_depth_m_bits, first.tillage_depth_m_bits);
            let debit = openwepp_kernel_contract::canonical_resource_amount_sum(&raw.native_uses)
                .expect("native keyed root debit sum");
            assert!(debit <= f64::from_bits(raw.beginning_supply_kg_m2_bits));
            let debit_m = if debit.to_bits() == raw.beginning_supply_kg_m2_bits {
                replay[raw.layer_index].theta_m
            } else {
                debit / 1_000.0
            };
            crate::direct_runtime::apply_direct_finalized_layer_liquid_debit(
                &mut replay[raw.layer_index],
                debit_m,
            )
            .expect("native keyed root debit replay");
        }
        assert_eq!(
            replay
                .iter()
                .map(|layer| layer.theta_m.to_bits())
                .collect::<Vec<_>>(),
            first.receiver_beginning_lane_depth_bits,
            "raw receiver pre-ingress lane"
        );
        for receipt in &first.ordered_ingress {
            assert_eq!(
                receipt.kind,
                crate::DirectSurfaceLiquidParcelKind::TerminalReceiver
            );
            assert_eq!(
                receipt.disposition,
                crate::DirectSurfaceLiquidReceiptDisposition::Infiltration
            );
            assert!(!receipt.parcel_id.is_empty() && !receipt.source_parcel_id.is_empty());
            assert_eq!(receipt.basis_ofe_id.as_str(), first.key.ofe_id);
            match &receipt.recipient {
                crate::DirectSurfaceLiquidReceiptRecipient::SoilInfiltration {
                    ofe_id,
                    production_lane_index,
                    production_lane_id,
                    ordered_soil_layer_ids,
                    ..
                } => {
                    assert_eq!(ofe_id.as_str(), first.key.ofe_id);
                    assert_eq!(*production_lane_index, first.lane_index);
                    assert_eq!(*production_lane_id, first.lane_id);
                    assert_eq!(ordered_soil_layer_ids.len(), replay.len());
                }
                _ => panic!("raw M1 ingress has non-soil recipient"),
            }
        }
        let ingress_kg_m2 = first
            .ordered_ingress
            .iter()
            .map(|receipt| receipt.mass_kg_m2_basis_ofe_ground)
            .try_fold(0.0, |sum, amount| {
                let next = sum + amount;
                next.is_finite().then_some(next)
            })
            .expect("ordered native ingress sum");
        assert_eq!(
            (ingress_kg_m2 / 1_000.0).to_bits(),
            first.infiltration_m_bits,
            "raw receiver infiltration input"
        );
        crate::direct_runtime::apply_direct_same_pass_infiltration(
            &mut replay,
            ingress_kg_m2 / 1_000.0,
            f64::from_bits(first.tillage_depth_m_bits),
        )
        .expect("native same-pass ingress replay");
        assert_eq!(
            replay
                .iter()
                .map(|layer| layer.theta_m.to_bits())
                .collect::<Vec<_>>(),
            first.ending_lane_depth_bits,
            "actual ending lane facts"
        );
        for raw in rows {
            assert_eq!(
                raw.receiver_beginning_depth_bits,
                raw.receiver_beginning_lane_depth_bits[raw.layer_index]
            );
            assert_eq!(
                raw.ending_depth_bits,
                raw.ending_lane_depth_bits[raw.layer_index]
            );
            let transition = water_transitions
                .iter()
                .find(|transition| transition.shared_resource_key == raw.key)
                .expect("full-key transition");
            assert_eq!(
                transition.beginning_amount.to_bits(),
                raw.beginning_supply_kg_m2_bits
            );
            assert_eq!(
                transition.ending_amount.to_bits(),
                (f64::from_bits(raw.ending_depth_bits) * 1_000.0).to_bits()
            );
        }
    }
}

#[test]
fn m1_parent_first_support_prints_actual_custody_operands_and_retains_parent_bgc_lineage() {
    let admitted = parent_zero();
    let receipts = admitted
        .parent_gsi_support_receipts(0)
        .expect("GSI receipts");
    let mut caller = actual_m1_caller_beginning_for_provider_controls().expect("actual caller");
    admitted
        .admit_parent_into_actual_caller(&mut caller, 0, &receipts)
        .expect("actual parent admission");
    let outcome = advance_fixed_sequence_support(&mut caller, &admitted, 0, None)
        .unwrap_or_else(|error| panic!("actual first support ordinal 0 rejected: {error:?}"));
    let raw_water = super::m1_fixed_sequence_provider::take_m1_raw_water_oracle();
    assert_raw_water_replay(&raw_water, outcome.shared_resource_owner_transitions());
    assert_eq!(outcome.record_ordinal(), 0);
    let beginning_bgc = outcome.beginning_biogeochemistry();
    assert_eq!(
        outcome.staged_bgc_parent_predecessor(),
        beginning_bgc.last_transaction_id
    );
    println!(
        "m1-first-support ordinal={} support={:?} reservoirs={:?} root_n_debits={:?} bgc_begin={:?} bgc_end={:?}",
        outcome.record_ordinal(),
        outcome.support(),
        outcome.reservoir_operands(),
        outcome.resource_debits(),
        beginning_bgc,
        outcome.ending_biogeochemistry(),
    );
}

#[test]
fn m1_parent_owns_admission_thirty_actual_supports_and_one_consuming_commit() {
    let admitted = parent_zero();
    let receipts = admitted
        .parent_gsi_support_receipts(0)
        .expect("GSI receipts");
    let mut caller = actual_m1_caller_beginning_for_provider_controls().expect("actual caller");
    admitted
        .admit_parent_into_actual_caller(&mut caller, 0, &receipts)
        .expect("actual parent admission");
    let beginning = caller
        .beginning_owner_bytes()
        .expect("seven beginning owners");
    let counters = caller.parent_only_counters();
    let mut prior = beginning.clone();
    let beginning_m1 = canonical_m1_owner(&beginning["vegetation"]);
    let (beginning_m1_revision, beginning_stratum_lineage) = m1_lineage(&beginning_m1);
    let mut slab_ids = Vec::new();
    let mut prior_thermal_ending = None::<String>;
    let parent_bgc_predecessor =
        json_u128(&canonical_m1_owner(&beginning["bgc"])["last_transaction_id"]);
    for ordinal in 0..30_u32 {
        let record = admitted.record(ordinal).expect("provider record");
        let outcome = advance_fixed_sequence_support(&mut caller, &admitted, ordinal, None)
            .expect("actual support");
        let raw_water = super::m1_fixed_sequence_provider::take_m1_raw_water_oracle();
        assert_eq!(outcome.record_ordinal(), ordinal);
        // These discriminators compare raw consumed inputs to independently
        // admitted record values and immutable provider geometry.
        let forcing = outcome.native_consumed_forcing_bits();
        let overrides = record.override_binary64_bits();
        let immutable = super::m1_coupled_expected_red::provider_covered_input();
        assert_eq!(forcing[0], overrides[0]);
        assert_eq!(forcing[1], overrides[1]);
        assert_eq!(forcing[8], overrides[2]);
        assert_eq!(
            forcing[9],
            (f64::from_bits(overrides[3]) * immutable.interval_s).to_bits()
        );
        assert_eq!(forcing[2], immutable.pressure_pa.to_bits());
        assert_eq!(forcing[3], immutable.reference_wind_m_s.to_bits());
        assert_eq!(
            forcing[4],
            immutable.shortwave.incident_w_m2_tile.direct_vis.to_bits()
        );
        assert_eq!(
            forcing[5],
            immutable.shortwave.incident_w_m2_tile.diffuse_vis.to_bits()
        );
        assert_eq!(
            forcing[6],
            immutable.shortwave.incident_w_m2_tile.direct_nir.to_bits()
        );
        assert_eq!(
            forcing[7],
            immutable.shortwave.incident_w_m2_tile.diffuse_nir.to_bits()
        );
        assert_eq!(
            outcome.staged_bgc_parent_predecessor(),
            parent_bgc_predecessor
        );
        let (thermal_beginning, thermal_ending) = outcome.staged_thermal_transition_sha256();
        if let Some(previous) = &prior_thermal_ending {
            assert_eq!(thermal_beginning, previous);
        }
        prior_thermal_ending = Some(thermal_ending.to_owned());
        assert_eq!(
            outcome.support().start_ns().get(),
            u128::from(ordinal) * 60_000_000_000
        );
        assert_eq!(
            outcome.support().end_ns().get(),
            u128::from(ordinal + 1) * 60_000_000_000
        );
        assert_eq!(
            outcome.applied_override_bits(),
            record.override_binary64_bits()
        );
        assert_eq!(outcome.gsi_bits(), admitted.gsi_bits());
        assert_eq!(outcome.gsi_support_receipt(), receipts[ordinal as usize]);
        assert_eq!(
            outcome.parent_forcing_receipt(),
            admitted.parent_forcing_receipt(0).expect("forcing")
        );
        assert_eq!(outcome.beginning_owner_bytes(), prior);
        assert_eq!(outcome.ending_owner_bytes().len(), 7);
        assert_eq!(outcome.ending_owner_bytes()["snow"], beginning["snow"]);
        assert_reservoir_closure(outcome.reservoir_operands());
        assert_eq!(caller.parent_only_counters(), counters);
        assert_eq!(
            caller.staged_owner_bytes().expect("actual staged owners"),
            outcome.ending_owner_bytes()
        );
        // The serialized staged M1 owner is the parent-only lineage oracle.
        // `parent_only_counters` alone cannot hide a support-local mutation.
        let staged_m1 = canonical_m1_owner(&outcome.ending_owner_bytes()["vegetation"]);
        let (staged_m1_revision, staged_stratum_lineage) = m1_lineage(&staged_m1);
        assert_eq!(staged_m1_revision, beginning_m1_revision);
        assert_eq!(staged_stratum_lineage, beginning_stratum_lineage);
        assert_eq!(caller.accepted_cursor(), u64::from(ordinal + 1));
        assert_ne!(
            outcome.checked_support_transaction_id(),
            caller.parent_only_transaction_id()
        );
        let slab = outcome.accepted_slab_receipt();
        assert_eq!(slab.slab_ordinal(), ordinal);
        assert_eq!(slab.support(), outcome.support());
        assert!(
            slab.authenticates_complete_ending_owners(&outcome.ending_owner_states())
                .expect("actual OwnerStates")
        );
        slab_ids.push(slab.id());
        // These are the actual V11 wire primitives; this control deliberately
        // does not use an M1 summary or a balance predicate supplied by the
        // implementation under test.
        let debits: &[openwepp_vegetation::v11::V11ResourceDebit] = outcome.resource_debits();
        let fluxes: &[openwepp_vegetation::v11::V11AdmittedResourceFlux] =
            outcome.admitted_resource_fluxes();
        assert!(
            fluxes
                .iter()
                .all(|flux| flux.flux_class == "terminal_receiver")
        );
        let transitions: &[openwepp_vegetation::v11::V11SharedResourceOwnerTransition] =
            outcome.shared_resource_owner_transitions();
        assert_raw_water_replay(&raw_water, transitions);
        let complete_candidates: &[openwepp_vegetation::v11::V11CompleteOwnerCandidate] =
            outcome.complete_owner_candidates();
        let candidate_debits: &[openwepp_vegetation::v11::V11ResourceDebit] =
            outcome.raw_resource_candidate_debits();
        let candidate_fluxes: &[openwepp_vegetation::v11::V11AdmittedResourceFlux] =
            outcome.raw_resource_candidate_fluxes();
        let transition_debit_ids = transitions
            .iter()
            .flat_map(|transition| transition.debit_receipt_ids.iter().copied())
            .collect::<BTreeSet<_>>();
        let transition_flux_ids = transitions
            .iter()
            .flat_map(|transition| transition.admitted_flux_receipt_ids.iter().copied())
            .collect::<BTreeSet<_>>();
        assert_eq!(
            transition_debit_ids,
            debits.iter().map(|debit| debit.receipt_id).collect()
        );
        assert_eq!(
            transition_flux_ids,
            fluxes.iter().map(|flux| flux.receipt_id).collect()
        );
        assert_eq!(
            candidate_debits
                .iter()
                .map(|debit| debit.receipt_id)
                .collect::<BTreeSet<_>>(),
            debits.iter().map(|debit| debit.receipt_id).collect()
        );
        assert_eq!(
            candidate_fluxes
                .iter()
                .map(|flux| flux.receipt_id)
                .collect::<BTreeSet<_>>(),
            fluxes.iter().map(|flux| flux.receipt_id).collect()
        );
        for transition in transitions {
            let owner_id = &transition.shared_resource_key.owner_id;
            let debit = debits
                .iter()
                .filter(|debit| transition.debit_receipt_ids.contains(&debit.receipt_id))
                .map(|debit| {
                    assert_eq!(debit.parent_transaction_id, slab.parent_transaction_id());
                    assert_eq!(debit.segment_id, slab.segment_id());
                    assert_eq!(debit.accepted_slab_id, slab.slab_id());
                    assert_eq!(debit.support, slab.support());
                    assert_eq!(&debit.owner_id, owner_id);
                    debit.final_use
                })
                .fold(0.0, |sum, amount| sum + amount);
            let flux = fluxes
                .iter()
                .filter(|flux| {
                    transition
                        .admitted_flux_receipt_ids
                        .contains(&flux.receipt_id)
                })
                .map(|flux| {
                    assert_eq!(flux.flux_class, "terminal_receiver");
                    assert_eq!(flux.parent_transaction_id, slab.parent_transaction_id());
                    assert_eq!(flux.segment_id, slab.segment_id());
                    assert_eq!(flux.accepted_slab_id, slab.slab_id());
                    assert_eq!(flux.support, slab.support());
                    assert_eq!(flux.shared_resource_key, transition.shared_resource_key);
                    if &flux.receiver_owner_id == owner_id {
                        flux.amount
                    } else if &flux.source_owner_id == owner_id {
                        -flux.amount
                    } else {
                        panic!("V11 resource flux is unrelated to its owner transition");
                    }
                })
                .fold(0.0, |sum, amount| sum + amount);
            match transition.shared_resource_key.resource {
                openwepp_vegetation::v11::V11SharedResourceKind::Water => {}
                openwepp_vegetation::v11::V11SharedResourceKind::Ammonium
                | openwepp_vegetation::v11::V11SharedResourceKind::Nitrate => {
                    // Mineral-N stays on its original exact wire arithmetic;
                    // the water replay above is deliberately separate.
                    assert_eq!(
                        (transition.beginning_amount - debit + flux).to_bits(),
                        transition.ending_amount.to_bits(),
                        "exact mineral-N transition arithmetic"
                    );
                }
            }
            let candidate = complete_candidates
                .iter()
                .find(|candidate| candidate.owner_id == *owner_id)
                .expect("actual V11 complete owner candidate");
            let component = candidate
                .components
                .iter()
                .find(|component| component.shared_resource_key == transition.shared_resource_key)
                .expect("actual V11 owner component");
            assert_eq!(
                component.ending_amount_bits,
                transition.ending_amount.to_bits()
            );
            assert_eq!(
                component
                    .debit_receipt_ids
                    .iter()
                    .copied()
                    .collect::<BTreeSet<_>>(),
                transition.debit_receipt_ids.iter().copied().collect()
            );
            assert_eq!(
                component
                    .admitted_flux_receipt_ids
                    .iter()
                    .copied()
                    .collect::<BTreeSet<_>>(),
                transition
                    .admitted_flux_receipt_ids
                    .iter()
                    .copied()
                    .collect()
            );
        }
        let transfers: &[openwepp_vegetation::carbon_nitrogen::MaterialTransfer] =
            outcome.material_transfers();
        let beginning_bgc = outcome.beginning_biogeochemistry();
        let ending_bgc = outcome.ending_biogeochemistry();
        let receiver_keys = beginning_bgc
            .receivers
            .keys()
            .chain(ending_bgc.receivers.keys())
            .chain(transfers.iter().map(|transfer| &transfer.receiver))
            .collect::<BTreeSet<_>>();
        for transfer in transfers {
            assert_eq!(
                transfer.transaction_id,
                outcome.checked_support_transaction_id()
            );
            assert!(transfer.carbon >= 0. && transfer.nitrogen >= 0. && transfer.dry_matter >= 0.);
        }
        for receiver in receiver_keys {
            let beginning = beginning_bgc
                .receivers
                .get(receiver)
                .copied()
                .unwrap_or_default();
            let ending = ending_bgc
                .receivers
                .get(receiver)
                .copied()
                .unwrap_or_default();
            let incoming = transfers
                .iter()
                .filter(|transfer| &transfer.receiver == receiver)
                .fold(
                    openwepp_biogeochemistry::MaterialPool::default(),
                    |sum, transfer| openwepp_biogeochemistry::MaterialPool {
                        carbon: sum.carbon + transfer.carbon,
                        nitrogen: sum.nitrogen + transfer.nitrogen,
                        dry_matter: sum.dry_matter + transfer.dry_matter,
                    },
                );
            assert_eq!(
                (ending.carbon - beginning.carbon).to_bits(),
                incoming.carbon.to_bits()
            );
            assert_eq!(
                (ending.nitrogen - beginning.nitrogen).to_bits(),
                incoming.nitrogen.to_bits()
            );
            assert_eq!(
                (ending.dry_matter - beginning.dry_matter).to_bits(),
                incoming.dry_matter.to_bits()
            );
        }
        if outcome.native_receiver().is_positive() {
            let receipt = outcome
                .native_receiver()
                .receipt()
                .expect("actual native receipt");
            assert!(receipt.mass_kg_m2_tile() > 0. && receipt.enthalpy_j_kg().is_finite());
            assert_eq!(receipt.support(), slab.support());
            assert_eq!(
                receipt.transaction_id(),
                outcome.checked_support_transaction_id()
            );
            assert_eq!(
                caller.native_capability_consumption_receipt(),
                Some(receipt)
            );
            let replay = caller
                .replay_native_capability(receipt)
                .expect_err("accepted native capability is consumed exactly once");
            assert_eq!(replay.code(), "VEG-E-143");
            assert_eq!(replay.rejection_stage().as_str(), "receiver");
            assert_eq!(replay.rejection_reason().as_str(), "duplicate_transfer");
        } else {
            let source_operands = outcome.native_receiver_source_operands();
            assert!(source_operands.is_empty());
            assert_eq!(
                source_operands
                    .iter()
                    .map(|operand| operand.mass_kg_m2_tile())
                    .fold(0.0, |sum, amount| sum + amount)
                    .to_bits(),
                0.0_f64.to_bits()
            );
        }
        prior = outcome.ending_owner_bytes().clone();
    }
    assert_ne!(
        admitted.record(0).expect("0").override_binary64_bits(),
        admitted.record(1).expect("1").override_binary64_bits()
    );
    caller
        .complete_parent()
        .expect("one actual consuming commit");
    let finalized_owners = caller
        .sealed_finalized_complete_owner_states()
        .expect("actual V11 finalization candidate")
        .iter()
        .map(|owner| (owner.owner_id().to_owned(), owner.state_bytes().to_vec()))
        .collect::<BTreeMap<_, _>>();
    assert_eq!(
        caller.beginning_owner_bytes().expect("installed owners"),
        finalized_owners
    );
    assert_ne!(finalized_owners["vegetation"], prior["vegetation"]);
    let mutation_set = prior
        .iter()
        .filter_map(|(owner_id, bytes)| {
            (finalized_owners.get(owner_id) != Some(bytes)).then(|| owner_id.as_str())
        })
        .collect::<Vec<_>>();
    assert!(
        matches!(
            mutation_set.as_slice(),
            ["vegetation"] | ["bgc", "vegetation"]
        ),
        "canonical parent finalization changes only vegetation or BGC plus vegetation"
    );
    assert_eq!(finalized_owners["snow"], prior["snow"]);
    for owner in [
        "hydrology",
        "land_surface_energy",
        "soil_thermal",
        "surface_liquid",
    ] {
        assert_eq!(finalized_owners[owner], prior[owner]);
    }
    let finalized_m1 = canonical_m1_owner(&finalized_owners["vegetation"]);
    let (finalized_m1_revision, finalized_stratum_lineage) = m1_lineage(&finalized_m1);
    assert_eq!(finalized_m1_revision, beginning_m1_revision + 1);
    assert_eq!(
        finalized_stratum_lineage,
        beginning_stratum_lineage
            .iter()
            .map(|(stratum, transaction)| (stratum.clone(), transaction + 1))
            .collect()
    );
    assert_eq!(
        m1_without_logical_lineage(finalized_m1),
        m1_without_logical_lineage(canonical_m1_owner(&prior["vegetation"]))
    );
    let finalized_bgc = canonical_m1_owner(&finalized_owners["bgc"]);
    let prior_bgc = canonical_m1_owner(&prior["bgc"]);
    assert_eq!(
        bgc_without_logical_lineage(finalized_bgc.clone()),
        bgc_without_logical_lineage(prior_bgc)
    );
    assert_eq!(
        json_u128(&finalized_bgc["last_transaction_id"]),
        u128::from(finalized_m1_revision)
    );
    assert_eq!(
        caller.parent_only_counters().parent_revision,
        counters.parent_revision + 1
    );
    assert_eq!(
        caller.parent_only_counters().publication_count,
        counters.publication_count + 1
    );
    assert!(caller.parent_clock_is_none() && caller.staged_owner_is_none());
    assert_eq!(
        caller
            .last_parent_receipt()
            .expect("actual successful parent receipt")
            .accepted_slab_ids(),
        slab_ids
    );
    assert!(matches!(
        caller.complete_parent(),
        Err(M1ParentExecutionError::NoLiveParent(
            CoupledTimeError::ParentNotFinalizable
        ))
    ));
}

#[test]
fn m1_parent_late_owning_rejection_follows_an_actual_prefix_and_positive_capability() {
    let admitted = parent_zero();
    let receipts = admitted
        .parent_gsi_support_receipts(0)
        .expect("GSI receipts");
    let mut caller = actual_m1_caller_beginning_for_provider_controls().expect("actual caller");
    admitted
        .admit_parent_into_actual_caller(&mut caller, 0, &receipts)
        .expect("actual parent admission");
    let prefix = advance_fixed_sequence_support(&mut caller, &admitted, 0, None)
        .expect("first prescribed support establishes an authentic prefix");
    assert_eq!(caller.accepted_cursor(), 1);
    let clock = caller
        .active_parent_clock()
        .expect("live actual parent clock");
    assert_eq!(clock.accepted_slab_receipts().len(), 1);
    assert_eq!(
        clock.accepted_slab_receipts()[0].id(),
        prefix.accepted_slab_receipt().id()
    );
    assert_eq!(clock.accepted_until(), prefix.support().end_ns());
    for ordinal in 1..30_u32 {
        // The receiver's own native route is built before this injection and
        // before staging (`advance_m1_caller_support`); this is a fresh
        // candidate attempt, never a replay of an accepted receipt.
        let before = super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
            .expect("actual pre-injection seam");
        let rejected = advance_fixed_sequence_support(
            &mut caller,
            &admitted,
            ordinal,
            Some(M1ReceiverFailureInjection::LateReceiverFailure),
        );
        match rejected {
            Err(M1ParentExecutionError::LateOwningReceiver(rejected)) => {
                assert_eq!(rejected.code(), "VEG-E-143");
                assert_eq!(rejected.rejection_stage().as_str(), "late_receiver");
                assert_eq!(rejected.rejection_reason().as_str(), "injected_failure");
                let candidate = rejected
                    .rejected_candidate()
                    .expect("late failure retains the actual native candidate");
                let native = candidate.actual_candidate();
                assert_eq!(
                    native.transaction_id(),
                    caller
                        .current_support_transaction_id()
                        .expect("current attempted support")
                );
                let contributors = candidate.contribution_join().contributors();
                assert!(!contributors.is_empty());
                for (index, contributor) in contributors.iter().enumerate() {
                    assert_eq!(
                        contributor.kind(),
                        crate::DirectSurfaceLiquidParcelKind::TerminalReceiver
                    );
                    assert_eq!(
                        contributor.source_parcel_id(),
                        format!("m1-native-terminal-{index}")
                    );
                    assert_eq!(contributor.transaction_id(), native.transaction_id());
                    assert!(
                        contributor.tile_mass_kg_m2().is_finite()
                            && contributor.tile_mass_kg_m2() > 0.0
                    );
                    assert!(contributor.specific_enthalpy_j_kg().is_finite());
                }
                assert_eq!(
                    super::m1_fixed_sequence_provider::RealM1CallerSnapshot::capture(&caller)
                        .expect("actual post-injection seam"),
                    before
                );
                let replay = caller
                    .replay_native_capability(&rejected)
                    .expect_err("late rejection consumes the real native capability");
                assert_eq!(replay.code(), "VEG-E-143");
                assert_eq!(replay.rejection_stage().as_str(), "receiver");
                assert_eq!(replay.rejection_reason().as_str(), "duplicate_transfer");
                return;
            }
            Ok(accepted) => {
                // The zero native-source branch stages authentically before
                // the receiver's late seam.  It is therefore the only
                // successful injected call and becomes the real prefix.
                assert!(!accepted.native_receiver().is_positive());
            }
            Err(other) => panic!("required typed LateOwningReceiver, got {other:?}"),
        }
    }
    panic!("NoPositiveNativeReceiverInParent fails this required late gate");
}
