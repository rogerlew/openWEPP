//! Test-only diagnostic. Expected bytes remain the independent captured map.
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    io::Write,
    path::Path,
};

type Owners = BTreeMap<String, Vec<u8>>;
const REFUSAL: &str = "native six-owner projection";
const MAX_SAVED_BYTES: usize = 64 * 1024 * 1024;

fn rows(expected: &Owners, actual: &Owners) -> Vec<Value> {
    expected.keys().chain(actual.keys()).collect::<BTreeSet<_>>()
        .into_iter().enumerate().map(|(index, key)| {
            let left = expected.get(key);
            let right = actual.get(key);
            let first_difference = match (left, right) {
                (Some(a), Some(b)) => a.iter().zip(b).position(|(x,y)| x != y)
                    .or_else(|| (a.len() != b.len()).then_some(a.len().min(b.len()))),
                _ => Some(0),
            };
            json!({"owner":key, "file_index":index,
                "expected_present":left.is_some(), "actual_present":right.is_some(),
                "expected_len":left.map(Vec::len), "actual_len":right.map(Vec::len),
                "expected_sha256":left.map(|b| format!("{:x}", Sha256::digest(b))),
                "actual_sha256":right.map(|b| format!("{:x}", Sha256::digest(b))),
                "equal":left == right, "first_difference_offset_or_length_boundary":first_difference,
                "expected_file":left.filter(|_|left != right).map(|_|format!("{index}-expected.bin")),
                "actual_file":right.filter(|_|left != right).map(|_|format!("{index}-actual.bin"))})
        }).collect()
}

fn write_new(path: &Path, bytes: &[u8]) -> Result<(), String> {
    std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .and_then(|mut f| f.write_all(bytes))
        .map_err(|error| format!("{}: {error}", path.display()))
}

fn save(expected: &Owners, actual: &Owners, directory: &Path) -> Result<(), String> {
    let report = rows(expected, actual);
    let bytes = expected
        .keys()
        .chain(actual.keys())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .filter(|key| expected.get(*key) != actual.get(*key))
        .try_fold(0usize, |sum, key| {
            sum.checked_add(expected.get(key).map_or(0, Vec::len))
                .and_then(|sum| sum.checked_add(actual.get(key).map_or(0, Vec::len)))
        })
        .ok_or("owner report length overflow")?;
    if bytes > MAX_SAVED_BYTES {
        return Err("owner report exceeds 64 MiB total byte limit".into());
    }
    std::fs::create_dir(directory).map_err(|error| format!("{}: {error}", directory.display()))?;
    for row in &report {
        let key = row["owner"].as_str().ok_or("report key")?;
        for (field, owners) in [("expected_file", expected), ("actual_file", actual)] {
            if let Some(name) = row[field].as_str() {
                write_new(
                    &directory.join(name),
                    owners.get(key).ok_or("report source missing")?,
                )?;
            }
        }
    }
    let value = json!({"comparison":"canonical_v11_parent_owner_state_bytes exact map equality",
        "expected_provenance":"original b01_wb14_snow_free_pre_child_current_context_v1 /complete_owner_canonical_bytes",
        "actual_provenance":"private restored consumer canonical_v11_parent_owner_state_bytes()",
        "execution_binding":"enclosing source/binary/input/argv receipt and OPENWEPP_B01_OWNER_COMPARISON_DIR",
        "all_equal":expected==actual,"saved_bytes":bytes,"owners":report});
    write_new(
        &directory.join("owners.json"),
        &serde_json::to_vec_pretty(&value).map_err(|error| error.to_string())?,
    )
}

pub(super) fn compare(
    expected: &Owners,
    actual: &Owners,
    output: Option<&Path>,
) -> Result<(), String> {
    let diagnostics = output.map_or_else(
        || Err("owner report output directory not configured".into()),
        |directory| save(expected, actual, directory),
    );
    match (expected == actual, diagnostics) {
        (false, Ok(())) => Err(REFUSAL.into()),
        (false, Err(error)) => Err(format!("{REFUSAL}; diagnostic output failure: {error}")),
        (true, result) => result,
    }
}

#[test]
fn owner_report_equal_missing_extra_and_byte_boundaries() {
    let expected = Owners::from([
        ("same".into(), vec![1, 2]),
        ("missing".into(), vec![3]),
        ("changed".into(), vec![1, 2]),
        ("longer".into(), vec![1, 2, 3]),
        ("shorter".into(), vec![1]),
    ]);
    let actual = Owners::from([
        ("same".into(), vec![1, 2]),
        ("extra".into(), vec![4]),
        ("changed".into(), vec![1, 3]),
        ("longer".into(), vec![1, 2]),
        ("shorter".into(), vec![1, 2]),
    ]);
    let report = rows(&expected, &actual);
    assert_eq!(report.len(), 6);
    for (key, equal, offset) in [
        ("same", true, None),
        ("missing", false, Some(0)),
        ("extra", false, Some(0)),
        ("changed", false, Some(1)),
        ("longer", false, Some(2)),
        ("shorter", false, Some(1)),
    ] {
        let row = report
            .iter()
            .find(|row| row["owner"] == key)
            .expect("union key");
        assert_eq!(row["equal"], json!(equal));
        assert_eq!(
            row["first_difference_offset_or_length_boundary"],
            json!(offset)
        );
    }
    assert!(
        rows(&expected, &expected)
            .iter()
            .all(|row| row["equal"] == true)
    );
}

#[test]
fn owner_report_io_failure_preserves_comparison_refusal() {
    let expected = Owners::from([("owner".into(), vec![1])]);
    let actual = Owners::from([("owner".into(), vec![2])]);
    let error = compare(&expected, &actual, Some(Path::new("/dev/null/impossible")))
        .expect_err("IO refusal");
    assert!(error.starts_with("native six-owner projection; diagnostic output failure:"));
    assert!(
        compare(
            &expected,
            &expected,
            Some(Path::new("/dev/null/impossible"))
        )
        .is_err()
    );
}

#[test]
fn owner_report_saves_exact_bytes_and_refuses_overwrite() {
    let directory = std::env::temp_dir().join(format!(
        "b01-owner-report-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("time")
            .as_nanos()
    ));
    let expected = Owners::from([("owner/unsafe-key".into(), vec![0, 255, 1])]);
    let actual = Owners::from([("owner/unsafe-key".into(), vec![0, 255, 2])]);
    assert_eq!(
        compare(&expected, &actual, Some(&directory)),
        Err(REFUSAL.into())
    );
    assert_eq!(
        std::fs::read(directory.join("0-expected.bin")).expect("expected bytes"),
        expected["owner/unsafe-key"]
    );
    assert_eq!(
        std::fs::read(directory.join("0-actual.bin")).expect("actual bytes"),
        actual["owner/unsafe-key"]
    );
    assert!(
        compare(&expected, &actual, Some(&directory))
            .expect_err("existing output")
            .contains("diagnostic output failure")
    );
    std::fs::remove_dir_all(directory).expect("temporary test output cleanup");
}
