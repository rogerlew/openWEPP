//! Experimental adopter-owned LSE component identity transport. This module
//! authenticates opaque canonical bytes, never physical state or regime.
use crate::{CoupledTimeError, Digest32, digest_bytes};
use serde::{Deserialize, Serialize};

pub const POLICY14_LSE_COMPONENT_SCHEMA: &str =
    "OPENWEPP_B01_LSE_CANONICAL_COMPONENT_BYTES_V2_POLICY14";

/// Actual retained consumer mode, independent of a requested solver role.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum Policy14RuntimeAuthority {
    HistoricalV8,
    V10NonpositiveAssimilation,
    V11SnowCovered,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Policy14LseOwnerTransport {
    schema: String,
    policy_id: u8,
    pub runtime_authority: Policy14RuntimeAuthority,
    pub active_covered_runtime_lse_v1: Vec<u8>,
    active_covered_sha256: Digest32,
    pub native_litter_lse_v3: Vec<u8>,
    native_litter_sha256: Digest32,
    pub native_exact_surface_enthalpy_v4: Vec<u8>,
    native_exact_sha256: Digest32,
}

impl Policy14LseOwnerTransport {
    pub fn new(
        runtime_authority: Policy14RuntimeAuthority,
        active: Vec<u8>,
        native: Vec<u8>,
        exact: Vec<u8>,
    ) -> Result<Self, CoupledTimeError> {
        if active.is_empty() || native.is_empty() || exact.is_empty() {
            return Err(CoupledTimeError::NonCanonicalIdentity);
        }
        Ok(Self {
            schema: POLICY14_LSE_COMPONENT_SCHEMA.into(),
            policy_id: 14,
            runtime_authority,
            active_covered_sha256: digest_bytes(&active),
            active_covered_runtime_lse_v1: active,
            native_litter_sha256: digest_bytes(&native),
            native_litter_lse_v3: native,
            native_exact_sha256: digest_bytes(&exact),
            native_exact_surface_enthalpy_v4: exact,
        })
    }

    pub fn canonical_bytes(&self) -> Result<Vec<u8>, CoupledTimeError> {
        if self.schema != POLICY14_LSE_COMPONENT_SCHEMA
            || self.policy_id != 14
            || self.active_covered_runtime_lse_v1.is_empty()
            || self.native_litter_lse_v3.is_empty()
            || self.native_exact_surface_enthalpy_v4.is_empty()
            || self.active_covered_sha256 != digest_bytes(&self.active_covered_runtime_lse_v1)
            || self.native_litter_sha256 != digest_bytes(&self.native_litter_lse_v3)
            || self.native_exact_sha256 != digest_bytes(&self.native_exact_surface_enthalpy_v4)
        {
            return Err(CoupledTimeError::NonCanonicalIdentity);
        }
        serde_json::to_vec(self).map_err(|_| CoupledTimeError::NonCanonicalIdentity)
    }

    pub fn from_canonical_bytes(bytes: &[u8]) -> Result<Self, CoupledTimeError> {
        let value: Self =
            serde_json::from_slice(bytes).map_err(|_| CoupledTimeError::NonCanonicalIdentity)?;
        if value.canonical_bytes()? != bytes {
            return Err(CoupledTimeError::NonCanonicalIdentity);
        }
        Ok(value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn policy14_mode_is_required_closed_and_changes_complete_identity() {
        let value = Policy14LseOwnerTransport::new(
            Policy14RuntimeAuthority::V11SnowCovered,
            b"active".to_vec(),
            b"native".to_vec(),
            b"exact".to_vec(),
        )
        .unwrap();
        let bytes = value.canonical_bytes().unwrap();
        let mut changed = value.clone();
        changed.runtime_authority = Policy14RuntimeAuthority::V10NonpositiveAssimilation;
        assert_ne!(
            digest_bytes(&bytes),
            digest_bytes(&changed.canonical_bytes().unwrap())
        );
        for index in 0..3 {
            let mut poison = serde_json::to_value(&value).unwrap();
            match index {
                0 => {
                    poison.as_object_mut().unwrap().remove("runtime_authority");
                }
                1 => poison["runtime_authority"] = serde_json::json!("foreign"),
                _ => {
                    poison["schema"] =
                        serde_json::json!("OPENWEPP_B01_LSE_CANONICAL_COMPONENT_BYTES_V1_POLICY14")
                }
            }
            assert!(
                Policy14LseOwnerTransport::from_canonical_bytes(
                    &serde_json::to_vec(&poison).unwrap()
                )
                .is_err()
            );
        }
    }
    #[test]
    fn policy14_transport_checks_each_order_preserving_poison() {
        let original = Policy14LseOwnerTransport::new(
            Policy14RuntimeAuthority::V11SnowCovered,
            b"active".to_vec(),
            b"native".to_vec(),
            b"exact".to_vec(),
        )
        .unwrap();
        let bytes = original.canonical_bytes().unwrap();
        assert_eq!(
            Policy14LseOwnerTransport::from_canonical_bytes(&bytes).unwrap(),
            original
        );
        for index in 0..8 {
            let mut poison = original.clone();
            match index {
                0 => poison.schema = "foreign".into(),
                1 => poison.policy_id = 13,
                2 => poison.active_covered_runtime_lse_v1.push(0),
                3 => poison.native_litter_lse_v3.push(0),
                4 => poison.native_exact_surface_enthalpy_v4.push(0),
                5 => poison.active_covered_sha256 = Digest32::zero(),
                6 => poison.native_litter_sha256 = Digest32::zero(),
                _ => poison.native_exact_sha256 = Digest32::zero(),
            }
            assert!(
                Policy14LseOwnerTransport::from_canonical_bytes(
                    &serde_json::to_vec(&poison).unwrap()
                )
                .is_err()
            );
        }
        let mut swapped = original;
        std::mem::swap(
            &mut swapped.active_covered_runtime_lse_v1,
            &mut swapped.native_litter_lse_v3,
        );
        assert!(
            Policy14LseOwnerTransport::from_canonical_bytes(&serde_json::to_vec(&swapped).unwrap())
                .is_err()
        );
    }
}
