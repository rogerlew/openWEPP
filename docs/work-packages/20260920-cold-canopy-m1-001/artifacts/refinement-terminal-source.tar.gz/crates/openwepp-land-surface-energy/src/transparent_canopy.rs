//! Isolated policy14 transparent-column liquid enthalpy identity.
use crate::{
    CoveredColumnInputs, LandSurfaceEnergyError, LandSurfaceForcing, LiquidParcelKind, OfeId,
    RuntimeTileIdentity,
};
use openwepp_kernel_contract::TileId;
use sha2::{Digest, Sha256};

#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TransparentCanopyLiquidBoundaryV1 {
    policy_id: u8,
    ofe_id: OfeId,
    tile_id: TileId,
    tile_fraction: f64,
    forcing: LandSurfaceForcing,
    configuration_sha256: Option<crate::Sha256Digest>,
    source_sha256: [u8; 32],
    incoming_mass_kg_m2_tile: f64,
    incoming_enthalpy_j_m2_tile: f64,
    mixture_temperature_k: f64,
}

pub(crate) fn normal(value: f64) -> Result<f64, LandSurfaceEnergyError> {
    if !value.is_finite() || (value != 0.0 && !value.is_normal()) {
        return Err(LandSurfaceEnergyError::ConstitutiveDomain(
            "transparent liquid arithmetic domain",
        ));
    }
    Ok(value)
}
pub(crate) fn product(a: f64, b: f64) -> Result<f64, LandSurfaceEnergyError> {
    normal(a)?;
    normal(b)?;
    let result = normal(a * b)?;
    if a != 0.0 && b != 0.0 && result == 0.0 {
        return Err(LandSurfaceEnergyError::ConstitutiveDomain(
            "transparent liquid product underflow",
        ));
    }
    Ok(result)
}

impl TransparentCanopyLiquidBoundaryV1 {
    pub fn try_new(
        forcing: &LandSurfaceForcing,
        ofe_id: &OfeId,
        tile_id: &TileId,
        tile_fraction: f64,
    ) -> Result<Self, LandSurfaceEnergyError> {
        forcing.validate_policy14_transparent_material()?;
        if !tile_fraction.is_finite() || tile_fraction <= 0.0 || tile_fraction > 1.0 {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent liquid tile fraction",
            ));
        }
        let mut mass = 0.0;
        let mut enthalpy = 0.0;
        for p in forcing.precipitation_parcels.iter().filter(|p| {
            p.parcel_kind == LiquidParcelKind::Precipitation
                && &p.destination_ofe_id == ofe_id
                && &p.destination_tile_id == tile_id
        }) {
            let m = normal(p.amount_kg_m2_destination_tile_ground)?;
            mass = normal(mass + m)?;
            if m > 0.0 {
                let h =
                    p.specific_liquid_enthalpy_j_kg
                        .ok_or(LandSurfaceEnergyError::StateLineage(
                            "transparent liquid missing enthalpy",
                        ))?;
                enthalpy = normal(enthalpy + product(m, h)?)?;
            }
        }
        if mass <= 0.0 {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent liquid missing positive input",
            ));
        }
        let denominator = product(4218.0, mass)?;
        let delta = normal(enthalpy / denominator)?;
        if enthalpy != 0.0 && delta == 0.0 {
            return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                "transparent liquid division underflow",
            ));
        }
        let temperature = normal(273.15 + delta)?;
        if !(200.0..=350.0).contains(&temperature) {
            return Err(LandSurfaceEnergyError::UnsupportedDomain(
                "transparent liquid material temperature",
            ));
        }
        let source_bytes = serde_json::to_vec(&(forcing, ofe_id, tile_id, tile_fraction))
            .map_err(|_| LandSurfaceEnergyError::StateLineage("transparent source encoding"))?;
        let source_sha256 = Sha256::digest(source_bytes).into();
        Ok(Self {
            policy_id: 14,
            ofe_id: ofe_id.clone(),
            tile_id: tile_id.clone(),
            tile_fraction,
            forcing: forcing.clone(),
            configuration_sha256: None,
            source_sha256,
            incoming_mass_kg_m2_tile: mass,
            incoming_enthalpy_j_m2_tile: enthalpy,
            mixture_temperature_k: temperature,
        })
    }
    pub fn validate_against_actual_forcing(
        &self,
        forcing: &LandSurfaceForcing,
        ofe: &OfeId,
        tile: &TileId,
        fraction: f64,
    ) -> Result<(), LandSurfaceEnergyError> {
        let mut expected = Self::try_new(forcing, ofe, tile, fraction)?;
        expected.configuration_sha256 = self.configuration_sha256.clone();
        if self != &expected {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent liquid actual source binding",
            ));
        }
        Ok(())
    }
    fn validate(&self) -> Result<(), LandSurfaceEnergyError> {
        self.validate_against_actual_forcing(
            &self.forcing,
            &self.ofe_id,
            &self.tile_id,
            self.tile_fraction,
        )
    }
}

impl CoveredColumnInputs {
    pub fn is_wholly_transparent_canopy(&self) -> bool {
        !self.occupancies.is_empty()
            && self.occupancies.iter().all(|o| {
                [
                    o.lai,
                    o.sai,
                    o.sun.leaf_area_m2_m2_tile,
                    o.shade.leaf_area_m2_m2_tile,
                    o.stem_area_m2_m2_tile,
                    o.beginning_canopy_liquid_kg_m2_tile,
                ]
                .iter()
                .all(|v| *v == 0.0)
            })
    }
    pub fn bind_transparent_liquid(
        &mut self,
        forcing: &LandSurfaceForcing,
        identity: &RuntimeTileIdentity,
    ) -> Result<(), LandSurfaceEnergyError> {
        if crate::snow_accuracy_policy::Policy::current().identity() == Some(14)
            && self.is_wholly_transparent_canopy()
            && self.top_rain_kg_m2_tile > 0.0
        {
            let mut boundary = TransparentCanopyLiquidBoundaryV1::try_new(
                forcing,
                &identity.ofe_id,
                &identity.tile_id,
                self.tile_fraction,
            )?;
            boundary.configuration_sha256 = Some(identity.configuration_sha256.clone());
            self.transparent_liquid_boundary = Some(Box::new(boundary));
        }
        self.validate_transparent_liquid(Some(identity))
    }
    pub fn validate_transparent_liquid(
        &self,
        identity: Option<&RuntimeTileIdentity>,
    ) -> Result<(), LandSurfaceEnergyError> {
        let eligible = crate::snow_accuracy_policy::Policy::current().identity() == Some(14)
            && self.is_wholly_transparent_canopy()
            && self.top_rain_kg_m2_tile > 0.0;
        match (&self.transparent_liquid_boundary, eligible) {
            (None, false) => Ok(()),
            (Some(b), true) => {
                b.validate()?;
                if b.incoming_mass_kg_m2_tile.to_bits() != self.top_rain_kg_m2_tile.to_bits()
                    || b.tile_fraction.to_bits() != self.tile_fraction.to_bits()
                    || b.forcing.interval_s.to_bits() != self.interval_s.to_bits()
                {
                    return Err(LandSurfaceEnergyError::StateLineage(
                        "transparent liquid column mass/support/fraction",
                    ));
                }
                if let Some(id) = identity {
                    if b.configuration_sha256.as_ref() != Some(&id.configuration_sha256)
                        || b.ofe_id != id.ofe_id
                        || b.tile_id != id.tile_id
                        || b.forcing.transaction_id != id.transaction_id
                        || b.forcing.interval_s.to_bits() != id.interval_s.to_bits()
                        || b.tile_fraction.to_bits() != id.tile_fraction.to_bits()
                    {
                        return Err(LandSurfaceEnergyError::StateLineage(
                            "transparent liquid runtime identity",
                        ));
                    }
                }
                Ok(())
            }
            _ => Err(LandSurfaceEnergyError::StateLineage(
                "transparent liquid boundary policy/eligibility/presence",
            )),
        }
    }
    // Called only after immutable input admission. This same exact anchor is
    // used by the residual and both ordinary/native inactive Jacobian rows.
    pub(crate) fn inactive_component_anchor_k(&self, component: usize, canopy: f64) -> f64 {
        crate::solver::inactive_component_temperature_anchor_k(component, canopy)
    }
}

/// Source/rank proof for zero-area passage, never authority from a global flag.
#[derive(Clone, Copy, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TransparentCanopyPassageProofV1 {
    boundary_sha256: [u8; 32],
    occupancy_sha256: [u8; 32],
    rank: u32,
    top_mass_kg_m2_tile: f64,
    top_enthalpy_j_m2_tile: f64,
    raw_mixture_temperature_k: f64,
}
impl TransparentCanopyPassageProofV1 {
    pub(crate) fn release_temperature_k(self) -> f64 {
        crate::covered_liquid::canonical_liquid_reference_temperature_k(
            self.raw_mixture_temperature_k,
        )
    }
    pub(crate) fn validate_ledger(
        self,
        l: &crate::CoveredOccupancyLiquidLedger,
    ) -> Result<(), LandSurfaceEnergyError> {
        if self.top_mass_kg_m2_tile <= 0.0
            || !(200.0..=350.0).contains(&self.raw_mixture_temperature_k)
            || l.wet_surface_temperature_k.to_bits() != self.release_temperature_k().to_bits()
            || [
                l.beginning_store_kg_m2_tile,
                l.ending_store_kg_m2_tile,
                l.evaporation_kg_m2_tile,
                l.condensation_kg_m2_tile,
                l.initial_drainage_kg_m2_tile,
                l.second_drainage_kg_m2_tile,
                l.wet_fraction,
            ]
            .iter()
            .any(|x| *x != 0.0)
        {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent passage ledger posture",
            ));
        }
        for m in [
            self.top_mass_kg_m2_tile,
            l.incident_rain_kg_m2_tile,
            l.throughfall_kg_m2_tile,
            l.stemflow_kg_m2_tile,
        ] {
            normal(m)?;
            product(m, l.wet_surface_specific_enthalpy_j_kg)?;
        }
        normal(self.top_enthalpy_j_m2_tile)?;
        Ok(())
    }
}
impl CoveredColumnInputs {
    pub(crate) fn passage_proof(
        &self,
        occupancy: &crate::CoveredOccupancyInputs,
    ) -> Result<Option<TransparentCanopyPassageProofV1>, LandSurfaceEnergyError> {
        let eligible = crate::snow_accuracy_policy::Policy::current().identity() == Some(14)
            && self.is_wholly_transparent_canopy()
            && self.top_rain_kg_m2_tile > 0.0;
        if eligible != self.transparent_liquid_boundary.is_some() {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent passage required proof posture",
            ));
        }
        let Some(b) = &self.transparent_liquid_boundary else {
            return Ok(None);
        };
        if !self.is_wholly_transparent_canopy() || b.configuration_sha256.is_none() {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent passage beginning eligibility",
            ));
        }
        let matches = self
            .occupancies
            .iter()
            .enumerate()
            .filter(|(_, o)| o.occupancy_id == occupancy.occupancy_id)
            .collect::<Vec<_>>();
        if matches.len() != 1 || matches[0].1 != occupancy {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent passage occupancy identity",
            ));
        }
        let rank = u32::try_from(matches[0].0)
            .map_err(|_| LandSurfaceEnergyError::StateLineage("transparent passage rank"))?;
        let configuration =
            b.configuration_sha256
                .as_ref()
                .ok_or(LandSurfaceEnergyError::StateLineage(
                    "transparent passage configuration",
                ))?;
        let mut hash = Sha256::new();
        hash.update(b.source_sha256);
        hash.update(configuration.as_str().as_bytes());
        Ok(Some(TransparentCanopyPassageProofV1 {
            boundary_sha256: hash.finalize().into(),
            occupancy_sha256: Sha256::digest(occupancy.occupancy_id.as_bytes()).into(),
            rank,
            top_mass_kg_m2_tile: b.incoming_mass_kg_m2_tile,
            top_enthalpy_j_m2_tile: b.incoming_enthalpy_j_m2_tile,
            raw_mixture_temperature_k: b.mixture_temperature_k,
        }))
    }
    pub(crate) fn validate_passage_ledger(
        &self,
        occupancy: &crate::CoveredOccupancyInputs,
        l: &crate::CoveredOccupancyLiquidLedger,
    ) -> Result<(), LandSurfaceEnergyError> {
        if l.transparent_passage != self.passage_proof(occupancy)? {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent passage actual source/rank proof",
            ));
        }
        l.validate()?;
        if l.transparent_passage.is_some() {
            if l.stemflow_kg_m2_tile.to_bits()
                != product(occupancy.stemflow_fraction, l.incident_rain_kg_m2_tile)?.to_bits()
                || l.throughfall_kg_m2_tile.to_bits()
                    != product(
                        1.0 - occupancy.stemflow_fraction,
                        l.incident_rain_kg_m2_tile,
                    )?
                    .to_bits()
            {
                return Err(LandSurfaceEnergyError::StateLineage(
                    "transparent passage unchanged E04 splits",
                ));
            }
        }
        Ok(())
    }
}

impl CoveredColumnInputs {
    /// Trusted adapter transition after validating the actual native config/state.
    /// Every non-configuration/runtime-source identity remains exactly unchanged.
    pub fn rebind_transparent_liquid_native_configuration(
        &mut self,
        forcing: &LandSurfaceForcing,
        predecessor: &RuntimeTileIdentity,
        native: &RuntimeTileIdentity,
    ) -> Result<(), LandSurfaceEnergyError> {
        self.validate_transparent_liquid(Some(predecessor))?;
        if let Some(boundary) = &self.transparent_liquid_boundary {
            boundary.validate_against_actual_forcing(
                forcing,
                &predecessor.ofe_id,
                &predecessor.tile_id,
                predecessor.tile_fraction,
            )?;
        }
        let mut permitted = predecessor.clone();
        permitted.configuration_sha256 = native.configuration_sha256.clone();
        permitted.beginning_lse_state_sha256 = native.beginning_lse_state_sha256.clone();
        if permitted != *native {
            return Err(LandSurfaceEnergyError::StateLineage(
                "transparent native configuration transition identity",
            ));
        }
        let mut candidate = self.clone();
        candidate.bind_transparent_liquid(forcing, native)?;
        candidate.validate_transparent_liquid(Some(native))?;
        *self = candidate;
        Ok(())
    }
}
