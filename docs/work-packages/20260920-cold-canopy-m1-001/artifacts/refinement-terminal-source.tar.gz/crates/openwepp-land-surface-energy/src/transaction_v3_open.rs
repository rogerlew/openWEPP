//! Native open-litter V3 potential/fixed-final transaction. Phase remains post-solve.
#![allow(clippy::missing_errors_doc)]
use crate::transaction_v3::{exact_v3_authorization_map, v3_ground_key};
use crate::*;

#[derive(Clone, Debug, PartialEq)]
pub struct V3OpenPotentialPhase {
    identity: RuntimeTileIdentity,
    beginning: OpenSurfaceProblem,
    context: V3LitterResidualContext,
    accepted: V3PhaseFreeOpenEvaluation,
    request_batch: PotentialWaterRequestBatch,
}
impl V3OpenPotentialPhase {
    pub fn identity(&self) -> &RuntimeTileIdentity {
        &self.identity
    }
    pub fn accepted(&self) -> &V3PhaseFreeOpenEvaluation {
        &self.accepted
    }
    pub fn request_batch(&self) -> &PotentialWaterRequestBatch {
        &self.request_batch
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct V3FixedFinalOpenCandidate {
    pub identity: RuntimeTileIdentity,
    pub accepted_fixed_final: V3PhaseFreeOpenEvaluation,
    pub potential_request_batch: PotentialWaterRequestBatch,
    pub phase_specific_authorization: V3PhaseSpecificVaporAuthorization,
    pub water_protocol: WaterProtocol,
    pub soil_thermal: SoilThermalTileCandidate,
    pub rollback_hashes: Vec<OwnerRollbackHash>,
}
fn accepted_open(
    outcome: NormalizedSolveOutcome<V3PhaseFreeOpenEvaluation>,
) -> Result<V3PhaseFreeOpenEvaluation, LandSurfaceEnergyError> {
    match outcome {
        NormalizedSolveOutcome::Accepted { detail, .. } => Ok(detail),
        NormalizedSolveOutcome::Rejected(_) => Err(
            LandSurfaceEnergyError::FrozenLitterTransaction("native V3 open solve rejected"),
        ),
    }
}
fn validate_identity(
    identity: &RuntimeTileIdentity,
    beginning: &OpenSurfaceProblem,
) -> Result<(), LandSurfaceEnergyError> {
    if identity.transaction_id.0 == 0
        || !identity.interval_s.is_finite()
        || identity.interval_s < 60.0
        || (identity.interval_s / 60.0).fract() != 0.0
        || identity.interval_s.to_bits() != beginning.interval_s.to_bits()
        || identity.tile_fraction.to_bits() != beginning.tile_fraction.to_bits()
        || identity.surface_class != SurfaceClass::ForestLitter
        || beginning.class != SurfaceClassKind::ForestLitter
        || identity.ground_source_type != WaterSourceType::LitterLiquid
        || identity.ground_source_tile_id.as_ref() != Some(&identity.tile_id)
        || identity.ground_soil_layer_id.is_some()
    {
        return Err(LandSurfaceEnergyError::FrozenLitterV3Identity(
            "open V3 runtime/source/support",
        ));
    }
    beginning.validate()?;
    Ok(())
}
pub fn solve_v3_open_potential_phase(
    identity: RuntimeTileIdentity,
    beginning: &OpenSurfaceProblem,
    initial: &[f64],
    configuration: LitterPhaseConfiguration,
    litter_beginning: BeginningLitterPhaseState,
) -> Result<V3OpenPotentialPhase, LandSurfaceEnergyError> {
    validate_identity(&identity, beginning)?;
    let context = V3LitterResidualContext {
        configuration,
        beginning: litter_beginning,
        finalized_vapor: None,
    };
    let accepted = accepted_open(solve_v3_phase_free_open_surface(
        beginning, initial, context,
    )?)?;
    let rates = accepted.vapor.finalized;
    let named = V3PhaseSpecificVaporAuthorization {
        liquid_outbound_rate_kg_m2_s: rates.liquid_signed_rate_kg_m2_s.max(0.0),
        ice_outbound_rate_kg_m2_s: rates.ice_signed_rate_kg_m2_s.max(0.0),
    }
    .aggregate_outbound_kg_m2_stand_ground(identity.tile_fraction, identity.interval_s)?;
    let request_batch = PotentialWaterRequestBatch::try_new(
        identity.transaction_id,
        identity.beginning_lse_state_sha256.clone(),
        vec![WaterAmount {
            key: v3_ground_key(&identity),
            amount_kg_m2_stand_ground: accepted
                .predecessor
                .water
                .request_kg_m2_stand_ground
                .max(named),
        }],
    )?;
    Ok(V3OpenPotentialPhase {
        identity,
        beginning: beginning.clone(),
        context,
        accepted,
        request_batch,
    })
}
pub fn finalize_v3_open_phase(
    phase: &V3OpenPotentialPhase,
    expected: &Sha256Digest,
    authorizations: Vec<WaterAuthorization>,
    authorization: V3PhaseSpecificVaporAuthorization,
    initial: &[f64],
    soil: SoilThermalFinalizationBeginning<'_>,
) -> Result<V3FixedFinalOpenCandidate, LandSurfaceEnergyError> {
    if expected != &phase.identity.beginning_lse_state_sha256 {
        return Err(LandSurfaceEnergyError::StateLineage(
            "stale V3 open potential beginning",
        ));
    }
    let exact = exact_v3_authorization_map(&phase.request_batch, authorizations)?;
    let potential = phase.accepted.vapor.finalized;
    for (a, p) in [
        (
            authorization.liquid_outbound_rate_kg_m2_s,
            potential.liquid_signed_rate_kg_m2_s,
        ),
        (
            authorization.ice_outbound_rate_kg_m2_s,
            potential.ice_signed_rate_kg_m2_s,
        ),
    ] {
        if !a.is_finite() || a < 0.0 || a > p.max(0.0) {
            return Err(LandSurfaceEnergyError::FrozenLitterVapor(
                "open phase authorization exceeds potential",
            ));
        }
    }
    let aggregate = authorization.aggregate_outbound_kg_m2_stand_ground(
        phase.identity.tile_fraction,
        phase.identity.interval_s,
    )?;
    let ground = exact.get(&v3_ground_key(&phase.identity)).ok_or(
        LandSurfaceEnergyError::FrozenLitterV3Identity("open aggregate authorization"),
    )?;
    if aggregate.to_bits() != ground.amount_kg_m2_stand_ground.to_bits() {
        return Err(LandSurfaceEnergyError::FrozenLitterVapor(
            "open named/aggregate authorization mismatch",
        ));
    }
    let mut context = phase.context;
    context.finalized_vapor = Some(authorization.as_solver_authorization());
    let accepted = accepted_open(solve_v3_phase_free_open_surface(
        &phase.beginning,
        initial,
        context,
    )?)?;
    let rates = accepted.vapor.finalized;
    let debit = V3PhaseSpecificVaporAuthorization {
        liquid_outbound_rate_kg_m2_s: rates.liquid_signed_rate_kg_m2_s.max(0.0),
        ice_outbound_rate_kg_m2_s: rates.ice_signed_rate_kg_m2_s.max(0.0),
    }
    .aggregate_outbound_kg_m2_stand_ground(
        phase.identity.tile_fraction,
        phase.identity.interval_s,
    )?;
    let water_protocol = WaterProtocol {
        transaction_id: phase.identity.transaction_id,
        hydrology_owner_id: phase.identity.hydrology_owner_id.clone(),
        beginning_snapshot_sha256: phase.identity.beginning_hydrology_snapshot_sha256.clone(),
        requests: phase.request_batch.requests.clone(),
        authorizations: exact.into_values().collect(),
        finalized_uses: vec![WaterAmount {
            key: v3_ground_key(&phase.identity),
            amount_kg_m2_stand_ground: debit,
        }],
        // Named inbound phase transport remains in the V3 receipt, once.
        condensation_credits: Vec::new(),
    };
    water_protocol.validate()?;
    let (joins, soil_thermal) = crate::transaction::build_open_soil_candidate(
        &phase.identity,
        &phase.beginning,
        &accepted.predecessor,
        soil,
    )?;
    for join in joins {
        validate_ground_heat_join(join)?;
    }
    Ok(V3FixedFinalOpenCandidate {
        identity: phase.identity.clone(),
        accepted_fixed_final: accepted,
        potential_request_batch: phase.request_batch.clone(),
        phase_specific_authorization: authorization,
        water_protocol,
        soil_thermal,
        rollback_hashes: crate::transaction::rollback_hashes(&phase.identity),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use openwepp_kernel_contract::{ResourceOwnerId, SoilLayerId, TileId, TransactionId};
    fn owner(s: &str) -> ResourceOwnerId {
        ResourceOwnerId::try_new(s).unwrap()
    }
    fn digest(c: char) -> Sha256Digest {
        Sha256Digest::try_new(c.to_string().repeat(64)).unwrap()
    }
    fn identity(interval_s: f64) -> RuntimeTileIdentity {
        RuntimeTileIdentity {
            transaction_id: TransactionId(91),
            soil_thermal_transaction_id: TransactionId(91),
            lse_owner_id: owner("lse-v3"),
            hydrology_owner_id: owner("hydrology"),
            soil_thermal_owner_id: owner("soil"),
            vegetation_owner_id: owner("vegetation"),
            biogeochemistry_owner_id: owner("bgc"),
            configuration_sha256: digest('a'),
            beginning_lse_state_sha256: digest('b'),
            beginning_hydrology_snapshot_sha256: digest('c'),
            beginning_soil_thermal_state_sha256: digest('d'),
            beginning_vegetation_state_sha256: digest('e'),
            beginning_biogeochemistry_state_sha256: digest('f'),
            ofe_id: OfeId::try_new("ofe-1").expect("ofe"),
            tile_id: TileId::try_new("forest").expect("tile"),
            surface_id: SurfaceId::try_new("litter").expect("surface"),
            surface_class: SurfaceClass::ForestLitter,
            ground_source_type: WaterSourceType::LitterLiquid,
            ground_source_id: crate::SourceId::try_new("litter").expect("source"),
            ground_source_tile_id: Some(TileId::try_new("forest").expect("tile")),
            ground_soil_layer_id: None,
            tile_fraction: 0.38,
            interval_s,
        }
    }

    #[test]
    fn v3_open_transaction_phase_custody_and_rejection() {
        for interval in [60.0, 1800.0] {
            let (mut problem, context) =
                crate::solver_litter_open::tests::equilibrium(3.0, 17.0, 285.0);
            problem.interval_s = interval;
            // Opposing phase signs with unequal interception fractions.
            let mut context = context;
            context.beginning.ice_kg_m2_tile = 8.5;
            context.beginning.sensible_energy_j_m2_tile =
                (3235.68 + 3.0 * 4218.0 + 8.5 * 2106.0) * (285.0 - 273.15);
            problem.surface_enthalpy_j_m2_tile = context.beginning.sensible_energy_j_m2_tile;
            problem.air_specific_humidity_kg_kg =
                0.3 * crate::physics::saturation_specific_humidity(285.0, 101325.0).unwrap();
            let before = problem.clone();
            let phase = solve_v3_open_potential_phase(
                identity(interval),
                &problem,
                &problem.initial_trial(),
                context.configuration,
                context.beginning,
            )
            .unwrap();
            let rates = phase.accepted().vapor.finalized;
            assert!(rates.liquid_signed_rate_kg_m2_s > 0.0 && rates.ice_signed_rate_kg_m2_s < 0.0);
            let auth = V3PhaseSpecificVaporAuthorization {
                liquid_outbound_rate_kg_m2_s: rates.liquid_signed_rate_kg_m2_s.max(0.0),
                ice_outbound_rate_kg_m2_s: rates.ice_signed_rate_kg_m2_s.max(0.0),
            };
            let amount = auth
                .aggregate_outbound_kg_m2_stand_ground(0.38, interval)
                .unwrap();
            let authorization = WaterAuthorization {
                key: phase.request_batch().requests[0].key.clone(),
                amount_kg_m2_stand_ground: amount,
                reason: WaterAuthorizationReason::FullSupply,
            };
            let soil = SoilThermalSnapshot {
                owner_id: owner("soil"),
                configuration_sha256: digest('a'),
                state_sha256: digest('d'),
                snapshot_sha256: digest('9'),
                last_accepted_transaction_id: Some(TransactionId(90)),
                ofes: vec![SoilThermalOfeSnapshot {
                    ofe_id: identity(interval).ofe_id,
                    ordered_layers: vec![SoilThermalLayerSnapshot {
                        layer_id: SoilLayerId::try_new("soil-1").unwrap(),
                        temperature_k: 285.0,
                        enthalpy_j_m2_ofe_ground: 120000.0 * (285.0 - 273.15),
                    }],
                }],
            };
            let final_value = finalize_v3_open_phase(
                &phase,
                &digest('b'),
                vec![authorization.clone()],
                auth,
                &problem.initial_trial(),
                SoilThermalFinalizationBeginning::V1(&soil),
            )
            .unwrap();
            assert!(final_value.accepted_fixed_final.vapor.ice_signed_mass_kg_m2 < 0.0);
            assert!(final_value.water_protocol.condensation_credits.is_empty());
            let independent_debit = final_value
                .accepted_fixed_final
                .vapor
                .finalized
                .liquid_signed_rate_kg_m2_s
                * 0.38
                * interval;
            assert!(
                (final_value.water_protocol.finalized_uses[0].amount_kg_m2_stand_ground
                    - independent_debit)
                    .abs()
                    <= 2.0 * f64::EPSILON * independent_debit.abs()
            );
            assert!(
                finalize_v3_open_phase(
                    &phase,
                    &digest('f'),
                    vec![authorization.clone()],
                    auth,
                    &problem.initial_trial(),
                    SoilThermalFinalizationBeginning::V1(&soil)
                )
                .is_err()
            );
            assert!(
                finalize_v3_open_phase(
                    &phase,
                    &digest('b'),
                    vec![authorization.clone(), authorization],
                    auth,
                    &problem.initial_trial(),
                    SoilThermalFinalizationBeginning::V1(&soil)
                )
                .is_err()
            );
            assert_eq!(problem, before);
        }
        let (mut problem, context) =
            crate::solver_litter_open::tests::equilibrium(3.0, 17.0, 285.0);
        problem.interval_s = 59.999999999;
        assert!(
            solve_v3_open_potential_phase(
                identity(problem.interval_s),
                &problem,
                &problem.initial_trial(),
                context.configuration,
                context.beginning
            )
            .is_err()
        );
    }
}

impl V3OpenPotentialPhase {
    /// Read-only experimental physical-input observation.
    pub fn accuracy_observation_beginning(&self) -> &OpenSurfaceProblem {
        &self.beginning
    }
}
