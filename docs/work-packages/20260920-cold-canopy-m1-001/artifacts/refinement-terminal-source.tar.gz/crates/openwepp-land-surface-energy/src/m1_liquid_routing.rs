//! Typed M1 same-tile liquid routing geometry.
//!
//! This module has no receiver ownership. It preserves individual source
//! parcels through the two-occupancy column so callers create one receipt per
//! terminal contribution or an explicit conservative merge retaining lineage.

use crate::{LandSurfaceEnergyError, REFERENCE_TEMPERATURE_K, WATER_HEAT_CAPACITY_J_KG_K};

#[derive(Clone, Debug, PartialEq)]
pub struct M1RoutingOccupancyInput {
    pub occupancy_id: String,
    pub plant_area_m2_m2_tile: f64,
    pub incident_mass_kg_m2_tile: f64,
    pub incident_enthalpy_j_kg: f64,
    pub interception_fraction: f64,
    pub stemflow_fraction: f64,
    pub initial_drainage_mass_kg_m2_tile: f64,
    pub initial_drainage_enthalpy_j_kg: f64,
    pub second_drainage_mass_kg_m2_tile: f64,
    pub second_drainage_enthalpy_j_kg: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct M1ColumnLiquidRoutingInput {
    upper: M1RoutingOccupancyInput,
    lower: M1RoutingOccupancyInput,
    tile_fraction: f64,
}

impl M1ColumnLiquidRoutingInput {
    pub fn new(
        upper: M1RoutingOccupancyInput,
        lower: M1RoutingOccupancyInput,
        tile_fraction: f64,
    ) -> Result<Self, LandSurfaceEnergyError> {
        let input = Self {
            upper,
            lower,
            tile_fraction,
        };
        input.validate()?;
        Ok(input)
    }
    /// Immutable upper occupancy input retained by the prescribed M1 route.
    #[must_use]
    pub const fn upper(&self) -> &M1RoutingOccupancyInput {
        &self.upper
    }
    /// Immutable lower occupancy input retained by the prescribed M1 route.
    #[must_use]
    pub const fn lower(&self) -> &M1RoutingOccupancyInput {
        &self.lower
    }
    /// Exact same-tile ground fraction used by every terminal conversion.
    #[must_use]
    pub const fn tile_fraction(&self) -> f64 {
        self.tile_fraction
    }
    fn validate(&self) -> Result<(), LandSurfaceEnergyError> {
        if !self.tile_fraction.is_finite()
            || !(0.0..=1.0).contains(&self.tile_fraction)
            || self.tile_fraction == 0.0
            || self.upper.occupancy_id.is_empty()
            || self.lower.occupancy_id.is_empty()
            || self.upper.occupancy_id == self.lower.occupancy_id
        {
            return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                "M1 liquid routing input",
            ));
        }
        for occupancy in [&self.upper, &self.lower] {
            let values = [
                occupancy.plant_area_m2_m2_tile,
                occupancy.incident_mass_kg_m2_tile,
                occupancy.incident_enthalpy_j_kg,
                occupancy.interception_fraction,
                occupancy.stemflow_fraction,
                occupancy.initial_drainage_mass_kg_m2_tile,
                occupancy.initial_drainage_enthalpy_j_kg,
                occupancy.second_drainage_mass_kg_m2_tile,
                occupancy.second_drainage_enthalpy_j_kg,
            ];
            if values.iter().any(|value| !value.is_finite()) {
                return Err(LandSurfaceEnergyError::NonFinite("M1 liquid routing input"));
            }
            if occupancy.plant_area_m2_m2_tile < 0.0
                || occupancy.incident_mass_kg_m2_tile < 0.0
                || occupancy.initial_drainage_mass_kg_m2_tile < 0.0
                || occupancy.second_drainage_mass_kg_m2_tile < 0.0
                || !(0.0..=1.0).contains(&occupancy.interception_fraction)
                || !(0.0..=1.0).contains(&occupancy.stemflow_fraction)
            {
                return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                    "M1 liquid routing input",
                ));
            }
            for (mass, enthalpy) in [
                (
                    occupancy.incident_mass_kg_m2_tile,
                    occupancy.incident_enthalpy_j_kg,
                ),
                (
                    occupancy.initial_drainage_mass_kg_m2_tile,
                    occupancy.initial_drainage_enthalpy_j_kg,
                ),
                (
                    occupancy.second_drainage_mass_kg_m2_tile,
                    occupancy.second_drainage_enthalpy_j_kg,
                ),
            ] {
                if mass > 0.0
                    && (enthalpy < 0.0
                        || REFERENCE_TEMPERATURE_K + enthalpy / WATER_HEAT_CAPACITY_J_KG_K > 373.15
                        || !(mass * enthalpy).is_finite())
                {
                    return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                        "M1 liquid source enthalpy",
                    ));
                }
            }
        }
        if self.lower.incident_mass_kg_m2_tile != 0.0 {
            return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                "M1 lower direct incident liquid",
            ));
        }
        Ok(())
    }
}

/// Canonical E04/M1 interception geometry shared with the coupled evaluator.
pub fn m1_liquid_interception_fraction(
    plant_area_m2_m2_tile: f64,
    interception_fraction: f64,
) -> Result<f64, LandSurfaceEnergyError> {
    if !plant_area_m2_m2_tile.is_finite() || !interception_fraction.is_finite() {
        return Err(LandSurfaceEnergyError::NonFinite(
            "M1 liquid interception geometry",
        ));
    }
    if plant_area_m2_m2_tile < 0.0 || !(0.0..=1.0).contains(&interception_fraction) {
        return Err(LandSurfaceEnergyError::ConstitutiveDomain(
            "M1 liquid interception geometry",
        ));
    }
    Ok(interception_fraction * plant_area_m2_m2_tile.tanh())
}

#[derive(Clone, Debug, PartialEq)]
pub struct M1LiquidCapture {
    kind: &'static str,
    occupancy_id: String,
    source_occupancy_id: String,
    source_branch: String,
    mass_kg_m2_tile: f64,
    enthalpy_j_kg: f64,
}
impl M1LiquidCapture {
    #[must_use]
    pub const fn kind(&self) -> &'static str {
        self.kind
    }
    #[must_use]
    pub fn occupancy_id(&self) -> &str {
        &self.occupancy_id
    }
    #[must_use]
    pub fn source_occupancy_id(&self) -> &str {
        &self.source_occupancy_id
    }
    #[must_use]
    pub fn source_branch(&self) -> &str {
        &self.source_branch
    }
    #[must_use]
    pub const fn mass_kg_m2_tile(&self) -> f64 {
        self.mass_kg_m2_tile
    }
    #[must_use]
    pub const fn enthalpy_j_kg(&self) -> f64 {
        self.enthalpy_j_kg
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct M1TerminalLiquidParcel {
    origin: String,
    source_occupancy_id: String,
    destination_occupancy_id: Option<String>,
    mass_kg_m2_tile: f64,
    enthalpy_j_kg: f64,
    tile_fraction: f64,
}
impl M1TerminalLiquidParcel {
    #[must_use]
    pub fn origin(&self) -> &str {
        &self.origin
    }
    #[must_use]
    pub fn source_occupancy_id(&self) -> &str {
        &self.source_occupancy_id
    }
    #[must_use]
    pub fn destination_occupancy_id(&self) -> Option<&str> {
        self.destination_occupancy_id.as_deref()
    }
    #[must_use]
    pub const fn mass_kg_m2_tile(&self) -> f64 {
        self.mass_kg_m2_tile
    }
    #[must_use]
    pub const fn enthalpy_j_kg(&self) -> f64 {
        self.enthalpy_j_kg
    }
    #[must_use]
    pub fn energy_j_m2_tile(&self) -> f64 {
        self.mass_kg_m2_tile * self.enthalpy_j_kg
    }
    #[must_use]
    pub fn mass_kg_m2_ofe_ground(&self) -> f64 {
        self.mass_kg_m2_tile * self.tile_fraction
    }
    #[must_use]
    pub fn energy_j_m2_ofe_ground(&self) -> f64 {
        self.energy_j_m2_tile() * self.tile_fraction
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct M1ColumnLiquidRouting {
    captures: Vec<M1LiquidCapture>,
    terminal_parcels: Vec<M1TerminalLiquidParcel>,
}
impl M1ColumnLiquidRouting {
    #[must_use]
    pub fn captures(&self) -> &[M1LiquidCapture] {
        &self.captures
    }
    #[must_use]
    pub fn terminal_parcels(&self) -> &[M1TerminalLiquidParcel] {
        &self.terminal_parcels
    }
    #[must_use]
    pub fn total_ofe_mass_kg_m2_ground(&self) -> f64 {
        self.terminal_parcels
            .iter()
            .map(M1TerminalLiquidParcel::mass_kg_m2_ofe_ground)
            .sum()
    }
    #[must_use]
    pub fn total_ofe_energy_j_m2_ground(&self) -> f64 {
        self.terminal_parcels
            .iter()
            .map(M1TerminalLiquidParcel::energy_j_m2_ofe_ground)
            .sum()
    }
}

fn route_one(
    input: &M1RoutingOccupancyInput,
    source_occupancy_id: &str,
    source_branch: &str,
    mass: f64,
    enthalpy_j_kg: f64,
    captures: &mut Vec<M1LiquidCapture>,
) -> Result<(f64, f64, f64), LandSurfaceEnergyError> {
    let captured =
        m1_liquid_interception_fraction(input.plant_area_m2_m2_tile, input.interception_fraction)?
            * mass;
    let free = mass - captured;
    let stemflow = input.stemflow_fraction * free;
    let throughfall = free - stemflow;
    if ![
        captured,
        stemflow,
        throughfall,
        captured * enthalpy_j_kg,
        stemflow * enthalpy_j_kg,
        throughfall * enthalpy_j_kg,
    ]
    .iter()
    .all(|value| value.is_finite())
    {
        return Err(LandSurfaceEnergyError::NonFinite(
            "M1 liquid routing derived contribution",
        ));
    }
    captures.extend([
        M1LiquidCapture {
            kind: "capture",
            occupancy_id: input.occupancy_id.clone(),
            source_occupancy_id: source_occupancy_id.to_owned(),
            source_branch: source_branch.to_owned(),
            mass_kg_m2_tile: captured,
            enthalpy_j_kg,
        },
        M1LiquidCapture {
            kind: "stemflow",
            occupancy_id: input.occupancy_id.clone(),
            source_occupancy_id: source_occupancy_id.to_owned(),
            source_branch: source_branch.to_owned(),
            mass_kg_m2_tile: stemflow,
            enthalpy_j_kg,
        },
        M1LiquidCapture {
            kind: "throughfall",
            occupancy_id: input.occupancy_id.clone(),
            source_occupancy_id: source_occupancy_id.to_owned(),
            source_branch: source_branch.to_owned(),
            mass_kg_m2_tile: throughfall,
            enthalpy_j_kg,
        },
    ]);
    Ok((captured, stemflow, throughfall))
}

/// Routes source-preserving M1 liquid through a two-occupancy column.
pub fn route_m1_column_liquid(
    input: &M1ColumnLiquidRoutingInput,
) -> Result<M1ColumnLiquidRouting, LandSurfaceEnergyError> {
    input.validate()?;
    let mut captures = Vec::new();
    let (_, upper_stemflow, upper_throughfall) = route_one(
        &input.upper,
        &input.upper.occupancy_id,
        "top_incident",
        input.upper.incident_mass_kg_m2_tile,
        input.upper.incident_enthalpy_j_kg,
        &mut captures,
    )?;
    let mut terminal_parcels = Vec::new();
    if upper_stemflow != 0.0 {
        terminal_parcels.push(M1TerminalLiquidParcel {
            origin: "upper_stemflow".to_owned(),
            source_occupancy_id: input.upper.occupancy_id.clone(),
            destination_occupancy_id: None,
            mass_kg_m2_tile: upper_stemflow,
            enthalpy_j_kg: input.upper.incident_enthalpy_j_kg,
            tile_fraction: input.tile_fraction,
        });
    }
    for (origin, mass, enthalpy) in [
        (
            "upper_throughfall",
            upper_throughfall,
            input.upper.incident_enthalpy_j_kg,
        ),
        (
            "upper_drainage",
            input.upper.initial_drainage_mass_kg_m2_tile,
            input.upper.initial_drainage_enthalpy_j_kg,
        ),
        (
            "upper_drainage_second",
            input.upper.second_drainage_mass_kg_m2_tile,
            input.upper.second_drainage_enthalpy_j_kg,
        ),
    ] {
        if mass == 0.0 {
            continue;
        }
        let (_, stemflow, throughfall) = route_one(
            &input.lower,
            &input.upper.occupancy_id,
            origin,
            mass,
            enthalpy,
            &mut captures,
        )?;
        if stemflow != 0.0 {
            terminal_parcels.push(M1TerminalLiquidParcel {
                origin: format!("{origin}_stemflow"),
                source_occupancy_id: input.upper.occupancy_id.clone(),
                destination_occupancy_id: Some(input.lower.occupancy_id.clone()),
                mass_kg_m2_tile: stemflow,
                enthalpy_j_kg: enthalpy,
                tile_fraction: input.tile_fraction,
            });
        }
        if throughfall != 0.0 {
            terminal_parcels.push(M1TerminalLiquidParcel {
                origin: format!("{origin}_throughfall"),
                source_occupancy_id: input.upper.occupancy_id.clone(),
                destination_occupancy_id: Some(input.lower.occupancy_id.clone()),
                mass_kg_m2_tile: throughfall,
                enthalpy_j_kg: enthalpy,
                tile_fraction: input.tile_fraction,
            });
        }
    }
    for (origin, mass, enthalpy) in [
        (
            "lower_drainage",
            input.lower.initial_drainage_mass_kg_m2_tile,
            input.lower.initial_drainage_enthalpy_j_kg,
        ),
        (
            "lower_drainage_second",
            input.lower.second_drainage_mass_kg_m2_tile,
            input.lower.second_drainage_enthalpy_j_kg,
        ),
    ] {
        if mass != 0.0 {
            if !(mass * enthalpy).is_finite() {
                return Err(LandSurfaceEnergyError::NonFinite(
                    "M1 liquid routing terminal energy",
                ));
            }
            terminal_parcels.push(M1TerminalLiquidParcel {
                origin: origin.to_owned(),
                source_occupancy_id: input.lower.occupancy_id.clone(),
                destination_occupancy_id: None,
                mass_kg_m2_tile: mass,
                enthalpy_j_kg: enthalpy,
                tile_fraction: input.tile_fraction,
            });
        }
    }
    let result = M1ColumnLiquidRouting {
        captures,
        terminal_parcels,
    };
    if !result.total_ofe_mass_kg_m2_ground().is_finite()
        || !result.total_ofe_energy_j_m2_ground().is_finite()
        || result
            .terminal_parcels
            .iter()
            .any(|parcel| !parcel.energy_j_m2_tile().is_finite())
    {
        return Err(LandSurfaceEnergyError::NonFinite(
            "M1 liquid routing aggregate",
        ));
    }
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn reference_input() -> M1ColumnLiquidRoutingInput {
        M1ColumnLiquidRoutingInput::new(
            M1RoutingOccupancyInput {
                occupancy_id: "stratum-z-upper::forest".to_owned(),
                plant_area_m2_m2_tile: 1.35,
                incident_mass_kg_m2_tile: 0.04,
                incident_enthalpy_j_kg: 21_090.0,
                interception_fraction: 0.5,
                stemflow_fraction: 0.1,
                initial_drainage_mass_kg_m2_tile: 0.006,
                initial_drainage_enthalpy_j_kg: 0.0,
                second_drainage_mass_kg_m2_tile: 0.0,
                second_drainage_enthalpy_j_kg: 0.0,
            },
            M1RoutingOccupancyInput {
                occupancy_id: "stratum-a-lower::forest".to_owned(),
                plant_area_m2_m2_tile: 0.9,
                incident_mass_kg_m2_tile: 0.0,
                incident_enthalpy_j_kg: 0.0,
                interception_fraction: 0.5,
                stemflow_fraction: 0.2,
                initial_drainage_mass_kg_m2_tile: 0.002,
                initial_drainage_enthalpy_j_kg: 8436.0,
                second_drainage_mass_kg_m2_tile: 0.0,
                second_drainage_enthalpy_j_kg: 0.0,
            },
            0.38,
        )
        .expect("valid reference routing input")
    }
    #[test]
    fn routing_preserves_contributions_and_converts_area_once() {
        let upper = M1RoutingOccupancyInput {
            occupancy_id: "stratum-z-upper::forest".to_owned(),
            plant_area_m2_m2_tile: 1.35,
            incident_mass_kg_m2_tile: 0.04,
            incident_enthalpy_j_kg: 21_090.0,
            interception_fraction: 0.5,
            stemflow_fraction: 0.1,
            initial_drainage_mass_kg_m2_tile: 0.006,
            initial_drainage_enthalpy_j_kg: 0.0,
            second_drainage_mass_kg_m2_tile: 0.0,
            second_drainage_enthalpy_j_kg: 0.0,
        };
        let lower = M1RoutingOccupancyInput {
            occupancy_id: "stratum-a-lower::forest".to_owned(),
            plant_area_m2_m2_tile: 0.9,
            incident_mass_kg_m2_tile: 0.0,
            incident_enthalpy_j_kg: 0.0,
            interception_fraction: 0.5,
            stemflow_fraction: 0.2,
            initial_drainage_mass_kg_m2_tile: 0.002,
            initial_drainage_enthalpy_j_kg: 8436.0,
            second_drainage_mass_kg_m2_tile: 0.0,
            second_drainage_enthalpy_j_kg: 0.0,
        };
        let routed = route_m1_column_liquid(
            &M1ColumnLiquidRoutingInput::new(upper, lower, 0.38).expect("valid"),
        )
        .expect("route");
        assert_eq!(routed.captures().len(), 9);
        assert_eq!(routed.terminal_parcels().len(), 6);
        assert_eq!(routed.terminal_parcels()[0].origin(), "upper_stemflow");
        assert_eq!(
            routed.captures()[3].occupancy_id(),
            "stratum-a-lower::forest"
        );
        assert_eq!(
            routed.captures()[3].source_occupancy_id(),
            "stratum-z-upper::forest"
        );
        assert_eq!(routed.captures()[3].source_branch(), "upper_throughfall");
        assert_eq!(routed.captures()[6].source_branch(), "upper_drainage");
        assert_eq!(
            routed.terminal_parcels()[1].source_occupancy_id(),
            "stratum-z-upper::forest"
        );
        assert_eq!(
            routed.terminal_parcels()[1].destination_occupancy_id(),
            Some("stratum-a-lower::forest")
        );
        assert_eq!(routed.terminal_parcels()[3].enthalpy_j_kg(), 0.0);
        assert!((routed.total_ofe_mass_kg_m2_ground() - 0.008_022_340_187_130_082).abs() <= 1e-12);
    }

    #[test]
    fn routing_refuses_nonliquid_source_enthalpy_overflow_and_unbound_area() {
        let input = |mass, enthalpy, fraction| {
            M1ColumnLiquidRoutingInput::new(
                M1RoutingOccupancyInput {
                    occupancy_id: "upper".to_owned(),
                    plant_area_m2_m2_tile: 1.0,
                    incident_mass_kg_m2_tile: mass,
                    incident_enthalpy_j_kg: enthalpy,
                    interception_fraction: 0.5,
                    stemflow_fraction: 0.0,
                    initial_drainage_mass_kg_m2_tile: 0.0,
                    initial_drainage_enthalpy_j_kg: 0.0,
                    second_drainage_mass_kg_m2_tile: 0.0,
                    second_drainage_enthalpy_j_kg: 0.0,
                },
                M1RoutingOccupancyInput {
                    occupancy_id: "lower".to_owned(),
                    plant_area_m2_m2_tile: 1.0,
                    incident_mass_kg_m2_tile: 0.0,
                    incident_enthalpy_j_kg: 0.0,
                    interception_fraction: 0.5,
                    stemflow_fraction: 0.0,
                    initial_drainage_mass_kg_m2_tile: 0.0,
                    initial_drainage_enthalpy_j_kg: 0.0,
                    second_drainage_mass_kg_m2_tile: 0.0,
                    second_drainage_enthalpy_j_kg: 0.0,
                },
                fraction,
            )
        };
        assert!(input(1.0, -1.0, 0.5).is_err());
        assert!(input(1.0, WATER_HEAT_CAPACITY_J_KG_K * 100.0 + 1.0, 0.5).is_err());
        // This is a finite liquid enthalpy; the rejection is the finite
        // mass-times-enthalpy product overflow, not the temperature guard.
        assert!(input(f64::MAX, WATER_HEAT_CAPACITY_J_KG_K, 0.5).is_err());
        assert!(input(1.0, 0.0, 0.0).is_err());
        assert!(input(1.0, 0.0, 1.0 + f64::EPSILON).is_err());
        assert!(input(1.0, 0.0, 0.5).is_ok());
    }

    #[test]
    fn routing_rejects_finite_terminal_products_whose_aggregate_overflows() {
        let upper = M1RoutingOccupancyInput {
            occupancy_id: "upper".to_owned(),
            plant_area_m2_m2_tile: 1.0,
            incident_mass_kg_m2_tile: 0.0,
            incident_enthalpy_j_kg: 0.0,
            interception_fraction: 0.0,
            stemflow_fraction: 0.0,
            initial_drainage_mass_kg_m2_tile: 0.0,
            initial_drainage_enthalpy_j_kg: 0.0,
            second_drainage_mass_kg_m2_tile: 0.0,
            second_drainage_enthalpy_j_kg: 0.0,
        };
        let lower = M1RoutingOccupancyInput {
            occupancy_id: "lower".to_owned(),
            plant_area_m2_m2_tile: 1.0,
            incident_mass_kg_m2_tile: 0.0,
            incident_enthalpy_j_kg: 0.0,
            interception_fraction: 0.0,
            stemflow_fraction: 0.0,
            initial_drainage_mass_kg_m2_tile: f64::MAX * 0.75,
            initial_drainage_enthalpy_j_kg: 1.0,
            second_drainage_mass_kg_m2_tile: f64::MAX * 0.75,
            second_drainage_enthalpy_j_kg: 1.0,
        };
        let input = M1ColumnLiquidRoutingInput::new(upper, lower, 1.0)
            .expect("each individual terminal product remains finite");
        assert!(matches!(
            route_m1_column_liquid(&input),
            Err(LandSurfaceEnergyError::NonFinite(_))
        ));
    }

    #[test]
    fn routing_has_exhaustive_reference_capture_and_terminal_lineage() {
        let routed = route_m1_column_liquid(&reference_input()).expect("reference route");
        let captures: Vec<_> = routed
            .captures()
            .iter()
            .map(|value| {
                (
                    value.occupancy_id(),
                    value.source_occupancy_id(),
                    value.source_branch(),
                    value.kind(),
                )
            })
            .collect();
        assert_eq!(
            captures,
            vec![
                (
                    "stratum-z-upper::forest",
                    "stratum-z-upper::forest",
                    "top_incident",
                    "capture"
                ),
                (
                    "stratum-z-upper::forest",
                    "stratum-z-upper::forest",
                    "top_incident",
                    "stemflow"
                ),
                (
                    "stratum-z-upper::forest",
                    "stratum-z-upper::forest",
                    "top_incident",
                    "throughfall"
                ),
                (
                    "stratum-a-lower::forest",
                    "stratum-z-upper::forest",
                    "upper_throughfall",
                    "capture"
                ),
                (
                    "stratum-a-lower::forest",
                    "stratum-z-upper::forest",
                    "upper_throughfall",
                    "stemflow"
                ),
                (
                    "stratum-a-lower::forest",
                    "stratum-z-upper::forest",
                    "upper_throughfall",
                    "throughfall"
                ),
                (
                    "stratum-a-lower::forest",
                    "stratum-z-upper::forest",
                    "upper_drainage",
                    "capture"
                ),
                (
                    "stratum-a-lower::forest",
                    "stratum-z-upper::forest",
                    "upper_drainage",
                    "stemflow"
                ),
                (
                    "stratum-a-lower::forest",
                    "stratum-z-upper::forest",
                    "upper_drainage",
                    "throughfall"
                ),
            ]
        );
        let terminal: Vec<_> = routed
            .terminal_parcels()
            .iter()
            .map(|value| {
                (
                    value.origin(),
                    value.source_occupancy_id(),
                    value.destination_occupancy_id(),
                )
            })
            .collect();
        assert_eq!(
            terminal,
            vec![
                ("upper_stemflow", "stratum-z-upper::forest", None),
                (
                    "upper_throughfall_stemflow",
                    "stratum-z-upper::forest",
                    Some("stratum-a-lower::forest")
                ),
                (
                    "upper_throughfall_throughfall",
                    "stratum-z-upper::forest",
                    Some("stratum-a-lower::forest")
                ),
                (
                    "upper_drainage_stemflow",
                    "stratum-z-upper::forest",
                    Some("stratum-a-lower::forest")
                ),
                (
                    "upper_drainage_throughfall",
                    "stratum-z-upper::forest",
                    Some("stratum-a-lower::forest")
                ),
                ("lower_drainage", "stratum-a-lower::forest", None),
            ]
        );
    }

    #[test]
    fn routing_preserves_positive_second_drainage_lineage() {
        let mut input = reference_input();
        input.upper.second_drainage_mass_kg_m2_tile = 0.003;
        input.upper.second_drainage_enthalpy_j_kg = 4218.0;
        input.lower.second_drainage_mass_kg_m2_tile = 0.004;
        input.lower.second_drainage_enthalpy_j_kg = 8436.0;
        let routed = route_m1_column_liquid(&input).expect("second drainage route");
        assert!(
            routed
                .captures()
                .iter()
                .any(|value| value.source_branch() == "upper_drainage_second")
        );
        assert!(
            routed
                .terminal_parcels()
                .iter()
                .any(|value| value.origin() == "upper_drainage_second_stemflow")
        );
        assert!(
            routed
                .terminal_parcels()
                .iter()
                .any(|value| value.origin() == "upper_drainage_second_throughfall")
        );
        assert!(
            routed
                .terminal_parcels()
                .iter()
                .any(|value| value.origin() == "lower_drainage_second")
        );
    }
}
