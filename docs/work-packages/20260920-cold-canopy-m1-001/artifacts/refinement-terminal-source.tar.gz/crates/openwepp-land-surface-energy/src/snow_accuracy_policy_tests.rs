use super::*;
#[test]
fn dimensional_policy_and_no_tightening() {
    assert_eq!(Policy::parse("P1"), Ok(Policy::P1));
    assert!(Policy::parse("unknown").is_err());
    assert_eq!(
        Policy::P1.coefficients(Quantity::Mass, 1e-9, 1e-8, 600.0),
        (1e-4, 1e-4)
    );
    assert_eq!(
        Policy::P2.coefficients(Quantity::WaterDepth, 1e-9, 5e-3, 600.0),
        (1e-5, 5e-3)
    );
    assert_eq!(
        Policy::P1.coefficients(Quantity::Temperature, 0.01, 1e-8, 600.0),
        (0.01, 1e-8)
    );
    assert_eq!(
        Policy::R0.coefficients(Quantity::Energy, 1e-6, 1e-8, 600.0),
        (1e-6, 1e-8)
    );
    assert_eq!(
        Policy::P1.coefficients(Quantity::HeatFlux, 1e-5, 1e-8, 100.0),
        (0.001, 1e-4)
    );
    assert_eq!(
        Policy::P2.coefficients(Quantity::VaporFlux, 1e-10, 1e-6, 100.0),
        (0.0001, 0.001)
    );
}
#[test]
fn accounting_is_independent_and_invalid_never_passes() {
    assert!(within(0.0, 0.00005, 0.0001, 0.0001));
    assert!(!within(0.0, 0.00005, 1e-9, 0.0));
    assert!(!within(f64::NAN, 0.0, 1.0, 0.001));
    assert!(!within(f64::INFINITY, f64::INFINITY, 1.0, 0.001));
    assert!(!within(0.0, 1.0, f64::INFINITY, 0.001));
    assert!(!within(0.0, 0.01, 1e-6, 0.0));
}
#[test]
fn support_scope_restores_and_rejects_invalid() {
    assert!(SupportScope::new(0.0).is_err());
    assert!(SupportScope::new(f64::NAN).is_err());
    let outer = SupportScope::new(600.0).expect("valid support");
    {
        let _inner = SupportScope::new(60.0).expect("nested support");
        assert_eq!(support_seconds(), 60.0);
    }
    assert_eq!(support_seconds(), 600.0);
    drop(outer);
    assert!(support_seconds().is_nan());
}
