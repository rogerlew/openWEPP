#![allow(clippy::missing_errors_doc)]

use std::collections::BTreeSet;

use openwepp_kernel_contract::{ResourceOwnerId, TileId, TransactionId};
use serde::{
    Deserialize, Serialize,
    ser::{SerializeMap, SerializeSeq},
};

use crate::{
    LandSurfaceEnergyConfiguration, LandSurfaceEnergyError, MODEL_DEFINITION_SHA256, OfeId,
    Sha256Digest, SurfaceConfiguration, SurfaceHeatStorageMode, canonical_digest, require_finite,
};

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TileState {
    pub ofe_id: OfeId,
    pub tile_id: TileId,
    pub surface_enthalpy_j_m2_tile_ground: f64,
    pub surface_temperature_warm_start_k: f64,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LandSurfaceEnergyState {
    pub model_definition_sha256: Sha256Digest,
    pub configuration_sha256: Sha256Digest,
    pub state_sha256: Sha256Digest,
    pub owner_id: ResourceOwnerId,
    pub last_accepted_transaction_id: Option<TransactionId>,
    pub tiles: Vec<TileState>,
}

/// Sorted typed view used only for the canonical digest.  Serializing through
/// `serde_json::Value` rejects legitimate `u128` transaction identities;
/// this keeps the pre-existing lexicographic object-member order while
/// handing the exact integer directly to the serializer.
struct CanonicalLandSurfaceEnergyState<'a>(&'a LandSurfaceEnergyState);

struct CanonicalTiles<'a>(&'a [TileState]);
struct CanonicalTile<'a>(&'a TileState);

impl Serialize for CanonicalTile<'_> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let tile = self.0;
        let mut map = serializer.serialize_map(Some(4))?;
        map.serialize_entry("ofe_id", &tile.ofe_id)?;
        map.serialize_entry(
            "surface_enthalpy_j_m2_tile_ground",
            &tile.surface_enthalpy_j_m2_tile_ground,
        )?;
        map.serialize_entry(
            "surface_temperature_warm_start_k",
            &tile.surface_temperature_warm_start_k,
        )?;
        map.serialize_entry("tile_id", &tile.tile_id)?;
        map.end()
    }
}

impl Serialize for CanonicalTiles<'_> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let mut sequence = serializer.serialize_seq(Some(self.0.len()))?;
        for tile in self.0 {
            sequence.serialize_element(&CanonicalTile(tile))?;
        }
        sequence.end()
    }
}

impl Serialize for CanonicalLandSurfaceEnergyState<'_> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let state = self.0;
        let mut map = serializer.serialize_map(Some(6))?;
        map.serialize_entry("configuration_sha256", &state.configuration_sha256)?;
        map.serialize_entry(
            "last_accepted_transaction_id",
            &state.last_accepted_transaction_id,
        )?;
        map.serialize_entry("model_definition_sha256", &state.model_definition_sha256)?;
        map.serialize_entry("owner_id", &state.owner_id)?;
        map.serialize_entry("state_sha256", "")?;
        map.serialize_entry("tiles", &CanonicalTiles(&state.tiles))?;
        map.end()
    }
}

impl LandSurfaceEnergyState {
    pub fn validate_schema(&self) -> Result<(), LandSurfaceEnergyError> {
        if self.model_definition_sha256.as_str() != MODEL_DEFINITION_SHA256 {
            return Err(LandSurfaceEnergyError::Identity {
                field: "state.model_definition_sha256",
                expected: MODEL_DEFINITION_SHA256.into(),
                found: self.model_definition_sha256.to_string(),
            });
        }
        if self.tiles.is_empty() {
            return Err(LandSurfaceEnergyError::topology_cardinality(
                "empty state tile set",
            ));
        }
        let mut identities = BTreeSet::new();
        for tile in &self.tiles {
            if !identities.insert((tile.ofe_id.clone(), tile.tile_id.clone())) {
                return Err(LandSurfaceEnergyError::topology_cardinality(
                    "duplicate tile state",
                ));
            }
            require_finite(
                tile.surface_enthalpy_j_m2_tile_ground,
                "state.surface_enthalpy_j_m2_tile_ground",
            )?;
            require_finite(
                tile.surface_temperature_warm_start_k,
                "state.surface_temperature_warm_start_k",
            )?;
            if !(200.0..=350.0).contains(&tile.surface_temperature_warm_start_k) {
                return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                    "state.surface_temperature_warm_start_k",
                ));
            }
        }
        let computed = self.canonical_sha256()?;
        if self.state_sha256 != computed {
            return Err(LandSurfaceEnergyError::Identity {
                field: "state_sha256",
                expected: computed.to_string(),
                found: self.state_sha256.to_string(),
            });
        }
        Ok(())
    }

    pub fn validate(
        &self,
        configuration: &LandSurfaceEnergyConfiguration,
    ) -> Result<(), LandSurfaceEnergyError> {
        self.validate_schema()?;
        if self.model_definition_sha256.as_str() != MODEL_DEFINITION_SHA256 {
            return Err(LandSurfaceEnergyError::Identity {
                field: "state.model_definition_sha256",
                expected: MODEL_DEFINITION_SHA256.into(),
                found: self.model_definition_sha256.to_string(),
            });
        }
        if self.configuration_sha256 != configuration.configuration_sha256 {
            return Err(LandSurfaceEnergyError::Identity {
                field: "state.configuration_sha256",
                expected: configuration.configuration_sha256.to_string(),
                found: self.configuration_sha256.to_string(),
            });
        }
        if self.owner_id != configuration.owner_id {
            return Err(LandSurfaceEnergyError::Identity {
                field: "state.owner_id",
                expected: configuration.owner_id.as_str().into(),
                found: self.owner_id.as_str().into(),
            });
        }
        let expected: BTreeSet<_> = configuration
            .ofes
            .iter()
            .flat_map(|ofe| {
                ofe.tiles
                    .iter()
                    .map(move |tile| (ofe.ofe_id.clone(), tile.tile_id.clone()))
            })
            .collect();
        let mut actual = BTreeSet::new();
        for tile in &self.tiles {
            if !actual.insert((tile.ofe_id.clone(), tile.tile_id.clone())) {
                return Err(LandSurfaceEnergyError::topology_cardinality(
                    "duplicate tile state",
                ));
            }
            require_finite(
                tile.surface_enthalpy_j_m2_tile_ground,
                "state.surface_enthalpy_j_m2_tile_ground",
            )?;
            require_finite(
                tile.surface_temperature_warm_start_k,
                "state.surface_temperature_warm_start_k",
            )?;
            if !(200.0..=350.0).contains(&tile.surface_temperature_warm_start_k) {
                return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                    "state.surface_temperature_warm_start_k",
                ));
            }
            let configured_tile = configuration
                .ofes
                .iter()
                .find(|ofe| ofe.ofe_id == tile.ofe_id)
                .and_then(|ofe| {
                    ofe.tiles
                        .iter()
                        .find(|candidate| candidate.tile_id == tile.tile_id)
                })
                .ok_or(LandSurfaceEnergyError::topology_cardinality(
                    "extra tile state",
                ))?;
            if configured_tile.surface_heat_storage_mode == SurfaceHeatStorageMode::EquilibriumZero
                && tile.surface_enthalpy_j_m2_tile_ground != 0.0
            {
                return Err(LandSurfaceEnergyError::ConstitutiveDomain(
                    "equilibrium-zero surface enthalpy",
                ));
            }
            if let SurfaceConfiguration::ForestLitter { .. } = configured_tile.surface {
                if configured_tile.surface_heat_storage_mode
                    == SurfaceHeatStorageMode::EquilibriumZero
                {
                    return Err(LandSurfaceEnergyError::UnsupportedDomain(
                        "equilibrium-zero forest litter state",
                    ));
                }
            }
        }
        if actual != expected {
            return Err(LandSurfaceEnergyError::topology_cardinality(
                "state tile set mismatch",
            ));
        }
        let computed = self.canonical_sha256()?;
        if self.state_sha256 != computed {
            return Err(LandSurfaceEnergyError::Identity {
                field: "state_sha256",
                expected: computed.to_string(),
                found: self.state_sha256.to_string(),
            });
        }
        Ok(())
    }

    pub fn validate_transaction_lineage(
        &self,
        candidate: TransactionId,
    ) -> Result<(), LandSurfaceEnergyError> {
        if candidate.0 == 0 {
            return Err(LandSurfaceEnergyError::StateLineage(
                "zero candidate transaction",
            ));
        }
        if let Some(previous) = self.last_accepted_transaction_id {
            if previous.0 >= candidate.0 {
                return Err(LandSurfaceEnergyError::StateLineage(
                    "candidate transaction is not newer than accepted state",
                ));
            }
        }
        Ok(())
    }

    pub fn canonical_sha256(&self) -> Result<Sha256Digest, LandSurfaceEnergyError> {
        canonical_digest(&CanonicalLandSurfaceEnergyState(self))
    }

    pub fn from_json(
        bytes: &[u8],
        configuration: &LandSurfaceEnergyConfiguration,
    ) -> Result<Self, LandSurfaceEnergyError> {
        let value: Self = serde_json::from_slice(bytes)
            .map_err(|error| LandSurfaceEnergyError::MalformedSerialization(error.to_string()))?;
        value.validate(configuration)?;
        Ok(value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn digest(byte: char) -> Sha256Digest {
        Sha256Digest::try_new(byte.to_string().repeat(64)).expect("test digest")
    }

    fn state(transaction: TransactionId) -> LandSurfaceEnergyState {
        LandSurfaceEnergyState {
            model_definition_sha256: digest('a'),
            configuration_sha256: digest('b'),
            state_sha256: digest('c'),
            owner_id: ResourceOwnerId::try_new("lse").expect("owner"),
            last_accepted_transaction_id: Some(transaction),
            tiles: vec![TileState {
                ofe_id: OfeId::try_new("ofe-1").expect("ofe"),
                tile_id: TileId::try_new("tile-1").expect("tile"),
                surface_enthalpy_j_m2_tile_ground: 42.0,
                surface_temperature_warm_start_k: 273.15,
            }],
        }
    }

    fn old_value_canonical_bytes(state: &LandSurfaceEnergyState) -> Vec<u8> {
        let mut value = serde_json::to_value(state).expect("low transaction fits Value");
        *value
            .get_mut("state_sha256")
            .expect("serialized state digest") = serde_json::Value::String(String::new());
        serde_json::to_vec(&value).expect("old canonical bytes")
    }

    #[test]
    fn canonical_state_projection_matches_old_value_bytes_for_low_transaction() {
        let state = state(TransactionId(41));
        let old = old_value_canonical_bytes(&state);
        let typed = serde_json::to_vec(&CanonicalLandSurfaceEnergyState(&state))
            .expect("typed canonical bytes");
        assert_eq!(typed, old);
        assert_eq!(
            canonical_digest(&CanonicalLandSurfaceEnergyState(&state)).expect("typed digest"),
            canonical_digest(
                &serde_json::from_slice::<serde_json::Value>(&old).expect("old value")
            )
            .expect("old digest")
        );
    }

    #[test]
    fn high_transaction_state_roundtrips_and_hashes_without_value_conversion() {
        let mut state = state(TransactionId((1_u128 << 127) + 7));
        state.state_sha256 = state.canonical_sha256().expect("high transaction digest");
        let bytes = serde_json::to_vec(&state).expect("typed state JSON");
        let restored: LandSurfaceEnergyState =
            serde_json::from_slice(&bytes).expect("typed roundtrip");
        assert_eq!(restored, state);
        assert_eq!(
            restored.canonical_sha256().expect("restored digest"),
            state.state_sha256
        );
    }
}
