//! Native V3 litter on the canonical open reference-air/soil equation set.
#![allow(clippy::missing_errors_doc)]
use crate::{
    FinalizedLitterVapor, LandSurfaceEnergyError, LitterVaporEnvironment, LitterVaporReceipt,
    NormalizedSolveOutcome, OpenSurfaceEvaluation, OpenSurfaceProblem, PostVaporLitterState,
    SurfaceClassKind, SurfaceStorageBranch, V3LitterResidualContext,
    V3PhaseFreeSurfaceEnergyLedger,
};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug)]
pub(crate) struct PhaseBranches {
    liquid_cap: Option<f64>,
    ice_cap: Option<f64>,
}
impl PhaseBranches {
    fn select(raw: crate::RawLitterVapor, context: V3LitterResidualContext, interval: f64) -> Self {
        let branch = |rate: f64, mass: f64, cap: Option<f64>| {
            let cap = cap.map_or(mass / interval, |c| c.min(mass / interval));
            if rate >= 0.0 && cap <= rate {
                Some(cap)
            } else {
                None
            }
        };
        Self {
            liquid_cap: branch(
                raw.raw_liquid_signed_rate_kg_m2_s,
                context.beginning.liquid_kg_m2_tile,
                context
                    .finalized_vapor
                    .map(|v| v.liquid_signed_rate_kg_m2_s),
            ),
            ice_cap: branch(
                raw.raw_ice_signed_rate_kg_m2_s,
                context.beginning.ice_kg_m2_tile,
                context.finalized_vapor.map(|v| v.ice_signed_rate_kg_m2_s),
            ),
        }
    }
    fn rates(self, raw: crate::RawLitterVapor) -> FinalizedLitterVapor {
        FinalizedLitterVapor {
            liquid_signed_rate_kg_m2_s: self
                .liquid_cap
                .unwrap_or(raw.raw_liquid_signed_rate_kg_m2_s),
            ice_signed_rate_kg_m2_s: self.ice_cap.unwrap_or(raw.raw_ice_signed_rate_kg_m2_s),
        }
    }
}

#[derive(Clone, Copy)]
pub(crate) struct PrivatePostVapor {
    pub liquid_kg_m2_tile: f64,
    pub sensible_energy_j_m2_tile: f64,
}

#[derive(Clone, Copy)]
pub(crate) struct V3OpenVapor {
    pub raw: crate::RawLitterVapor,
    pub rates: FinalizedLitterVapor,
    pub energy: [f64; 6],
    pub post_vapor: PrivatePostVapor,
    receipt: Option<LitterVaporReceipt>,
    branches: PhaseBranches,
}

pub(crate) fn open_v3_vapor(
    problem: &OpenSurfaceProblem,
    temperature_k: f64,
    vapor_resistance_s_m: f64,
    air_density_kg_m3: f64,
    context: V3LitterResidualContext,
    frozen: Option<PhaseBranches>,
) -> Result<V3OpenVapor, LandSurfaceEnergyError> {
    if problem.class != SurfaceClassKind::ForestLitter
        || problem.storage_branch != SurfaceStorageBranch::FiniteCapacity
        || problem.surface_liquid_kg_m2_tile.to_bits()
            != context.beginning.liquid_kg_m2_tile.to_bits()
        || problem.surface_enthalpy_j_m2_tile.to_bits()
            != context.beginning.sensible_energy_j_m2_tile.to_bits()
        || problem.surface_dry_heat_capacity_j_m2_k.to_bits()
            != context.configuration.dry_heat_capacity_j_m2_k.to_bits()
        || problem.surface_depth_m.to_bits() != context.configuration.litter_depth_m.to_bits()
        || problem.litter_capacity_kg_m2_tile.map(f64::to_bits)
            != Some(context.configuration.liquid_capacity_kg_m2_tile.to_bits())
    {
        return Err(LandSurfaceEnergyError::FrozenLitterV3Identity(
            "V3 open predecessor/state join",
        ));
    }
    crate::validate_litter_phase_configuration(context.configuration)?;
    crate::validate_beginning_litter_state(context.configuration, context.beginning)?;
    let raw = crate::evaluate_raw_litter_vapor(
        context.configuration,
        context.beginning,
        LitterVaporEnvironment {
            accepted_phase_free_temperature_k: temperature_k,
            air_density_kg_m3,
            air_pressure_pa: problem.air_pressure_pa,
            recipient_specific_humidity_kg_kg: problem.air_specific_humidity_kg_kg,
            // The shared phase law's historical field names its air recipient.
            // For open topology this is exactly the open neutral r_v to reference air.
            litter_to_canopy_resistance_s_m: vapor_resistance_s_m,
        },
    )?;
    let natural_rates =
        crate::solver_litter_phase::bound_phase_vapor(raw, context, problem.interval_s)?;
    let rates = frozen.map_or(natural_rates, |branches| branches.rates(raw));
    let energy = crate::litter_phase::phase_vapor_energy_primitives(
        rates,
        temperature_k,
        problem.interval_s,
    )?;
    let receipt = if frozen.is_none() {
        Some(crate::finalize_litter_vapor(
            raw,
            rates,
            context.beginning,
            temperature_k,
            problem.interval_s,
        )?)
    } else {
        None
    };
    if let Some(receipt) = receipt {
        crate::install_finalized_vapor(
            context.configuration,
            context.beginning,
            temperature_k,
            receipt,
        )?;
    }
    let [liquid, _, sensible] = crate::litter_phase::post_vapor_numeric_primitives(
        context.configuration,
        context.beginning,
        temperature_k,
        energy[0],
        energy[1],
    )?;
    let post_vapor = PrivatePostVapor {
        liquid_kg_m2_tile: liquid,
        sensible_energy_j_m2_tile: sensible,
    };
    Ok(V3OpenVapor {
        raw,
        rates,
        energy,
        post_vapor,
        receipt,
        branches: PhaseBranches::select(raw, context, problem.interval_s),
    })
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct V3PhaseFreeOpenEvaluation {
    pub predecessor: OpenSurfaceEvaluation,
    pub vapor: LitterVaporReceipt,
    pub post_vapor: PostVaporLitterState,
    pub surface_energy: V3PhaseFreeSurfaceEnergyLedger,
}
impl V3PhaseFreeOpenEvaluation {
    pub(crate) fn from_accepted_primitives(
        predecessor: OpenSurfaceEvaluation,
        vapor: V3OpenVapor,
        context: V3LitterResidualContext,
        interval_s: f64,
    ) -> Result<Self, LandSurfaceEnergyError> {
        let receipt = vapor
            .receipt
            .ok_or(LandSurfaceEnergyError::FrozenLitterV3Identity(
                "Jacobian probe cannot publish",
            ))?;
        let surface_energy = V3PhaseFreeSurfaceEnergyLedger {
            beginning_sensible_energy_j_m2: context.beginning.sensible_energy_j_m2_tile,
            ending_sensible_energy_j_m2: vapor.post_vapor.sensible_energy_j_m2_tile,
            absorbed_shortwave_w_m2: predecessor.shortwave_absorbed_w_m2_tile.total(),
            net_longwave_w_m2: predecessor.longwave_net_w_m2_tile,
            // The shared ledger names the historical covered recipient; here
            // the actual recipient is reference air, as bound by the open problem.
            sensible_to_canopy_air_w_m2: predecessor.sensible_w_m2_tile,
            liquid_vapor_energy_w_m2: vapor.energy[4] / interval_s,
            ice_vapor_energy_w_m2: vapor.energy[5] / interval_s,
            ground_heat_w_m2: predecessor.ground_heat_cn_w_m2_tile[0],
            storage_w_m2: predecessor.surface_storage_w_m2_tile,
            reconstructed_energy_residual_w_m2: predecessor.raw_residuals[0],
        };
        let post_vapor = crate::install_finalized_vapor(
            context.configuration,
            context.beginning,
            predecessor.surface_temperature_k,
            receipt,
        )?;
        Ok(Self {
            predecessor,
            vapor: receipt,
            post_vapor,
            surface_energy,
        })
    }
}

pub fn evaluate_v3_phase_free_open_surface(
    problem: &OpenSurfaceProblem,
    trial: &[f64],
    context: V3LitterResidualContext,
) -> Result<V3PhaseFreeOpenEvaluation, LandSurfaceEnergyError> {
    crate::solver::evaluate_open_surface_v3(problem, trial, context)
}

pub fn solve_v3_phase_free_open_surface(
    problem: &OpenSurfaceProblem,
    initial_trial: &[f64],
    context: V3LitterResidualContext,
) -> Result<NormalizedSolveOutcome<V3PhaseFreeOpenEvaluation>, LandSurfaceEnergyError> {
    problem.validate()?;
    #[derive(Clone)]
    struct Detail {
        natural: Option<V3PhaseFreeOpenEvaluation>,
        branches: PhaseBranches,
    }
    let outcome = crate::numerics::solve_normalized_system(
        |trial, frozen: Option<&PhaseBranches>| {
            let (predecessor, vapor) = crate::solver::evaluate_open_surface_v3_private(
                problem,
                trial,
                context,
                frozen.copied(),
            )?;
            let residual = predecessor.normalized_residuals.clone();
            let branches = vapor.branches;
            let natural = if frozen.is_none() {
                Some(V3PhaseFreeOpenEvaluation::from_accepted_primitives(
                    predecessor,
                    vapor,
                    context,
                    problem.interval_s,
                )?)
            } else {
                None
            };
            Ok((residual, Detail { natural, branches }))
        },
        initial_trial.to_vec(),
        &vec![1.0; problem.soil_nodes.len() + 1],
        |trial| {
            trial
                .iter()
                .all(|t| t.is_finite() && (200.0..=350.0).contains(t))
        },
        |detail: &Detail| detail.branches,
    )?;
    Ok(match outcome {
        NormalizedSolveOutcome::Accepted {
            solution,
            detail,
            iterations,
            residual_norm_history,
            backtracking_count,
            step_norm,
            pivot_magnitude,
            matrix_norm,
        } => NormalizedSolveOutcome::Accepted {
            solution,
            detail: detail
                .natural
                .ok_or(LandSurfaceEnergyError::FrozenLitterV3Identity(
                    "accepted open probe",
                ))?,
            iterations,
            residual_norm_history,
            backtracking_count,
            step_norm,
            pivot_magnitude,
            matrix_norm,
        },
        NormalizedSolveOutcome::Rejected(failure) => NormalizedSolveOutcome::Rejected(failure),
    })
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use crate::*;

    pub(crate) fn equilibrium(
        liquid: f64,
        ice: f64,
        temperature: f64,
    ) -> (OpenSurfaceProblem, V3LitterResidualContext) {
        let configuration = LitterPhaseConfiguration {
            litter_depth_m: 0.04,
            dry_heat_capacity_j_m2_k: 3235.68,
            liquid_capacity_kg_m2_tile: 6.0,
            ice_capacity_kg_m2_tile: 34.0,
        };
        let beginning = BeginningLitterPhaseState {
            liquid_kg_m2_tile: liquid,
            ice_kg_m2_tile: ice,
            sensible_energy_j_m2_tile: (configuration.dry_heat_capacity_j_m2_k
                + liquid * 4218.0
                + ice * 2106.0)
                * (temperature - 273.15),
            temperature_k: temperature,
        };
        // The selected occupied phases each fill exactly half their named
        // capacity, giving the independent h_u=1/2 equilibrium; empty uses q=0.
        let humidity = if liquid + ice == 0.0 {
            0.0
        } else {
            0.5 * (1.0 - std::f64::consts::PI.mul_add(0.5, 0.0).cos())
                * crate::physics::saturation_specific_humidity(temperature, 101325.0).unwrap()
        };
        let problem = OpenSurfaceProblem {
            interval_s: 1800.0,
            tile_fraction: 0.38,
            class: SurfaceClassKind::ForestLitter,
            storage_branch: SurfaceStorageBranch::FiniteCapacity,
            terminal_shortwave_w_m2_tile: BandDirectionalFluxes::default(),
            surface_vis_albedo: 0.12,
            surface_nir_albedo: 0.24,
            surface_emissivity: 1.0,
            surface_depth_m: 0.04,
            surface_conductivity_w_m_k: 0.103,
            surface_dry_heat_capacity_j_m2_k: configuration.dry_heat_capacity_j_m2_k,
            litter_capacity_kg_m2_tile: Some(6.0),
            open_geometry: OpenNeutralGeometry {
                reference_height_m: 24.0,
                roughness_momentum_m: 1.25,
                roughness_heat_m: 0.12,
                roughness_vapor_m: 0.08,
            },
            air_temperature_k: temperature,
            air_specific_humidity_kg_kg: humidity,
            air_pressure_pa: 101325.0,
            reference_wind_m_s: 3.7,
            atmospheric_downward_longwave_w_m2: 5.670374419e-8 * temperature.powi(4),
            surface_liquid_kg_m2_tile: liquid,
            surface_enthalpy_j_m2_tile: beginning.sensible_energy_j_m2_tile,
            surface_temperature_warm_start_k: temperature,
            bare_soil: None,
            soil_nodes: vec![SoilThermalNodeOperands {
                layer_id: "soil-1".into(),
                depth_m: 0.08,
                conductivity_w_m_k: 1.1,
                heat_capacity_j_m2_k: 120000.0,
                beginning_temperature_k: temperature,
            }],
        };
        (
            problem,
            V3LitterResidualContext {
                configuration,
                beginning,
                finalized_vapor: None,
            },
        )
    }

    #[test]
    fn v3_open_litter_equilibrium_uses_reference_air_and_named_phase_capacity() {
        for (liquid, ice) in [(0.0, 0.0), (3.0, 0.0), (0.0, 17.0), (3.0, 17.0)] {
            for temperature in [270.0, 273.15, 285.0] {
                let (problem, context) = equilibrium(liquid, ice, temperature);
                let beginning = problem.clone();
                let outcome =
                    solve_v3_phase_free_open_surface(&problem, &problem.initial_trial(), context)
                        .unwrap();
                let NormalizedSolveOutcome::Accepted {
                    solution, detail, ..
                } = outcome
                else {
                    panic!("equilibrium rejected")
                };
                assert!(solution.iter().all(|t| (*t - temperature).abs() < 1e-8));
                assert!(detail.vapor.liquid_signed_mass_kg_m2.abs() < 1e-10);
                assert!(detail.vapor.ice_signed_mass_kg_m2.abs() < 1e-10);
                assert!((detail.post_vapor.liquid_kg_m2_tile - liquid).abs() < 1e-10);
                assert!((detail.post_vapor.ice_kg_m2_tile - ice).abs() < 1e-10);
                assert_eq!(problem, beginning);
            }
        }
    }

    #[test]
    fn v3_open_litter_caps_are_phase_specific_and_invalid_inputs_reject() {
        let (mut problem, mut context) = equilibrium(3.0, 17.0, 285.0);
        problem.air_specific_humidity_kg_kg = 0.0;
        context.finalized_vapor = Some(FinalizedLitterVapor {
            liquid_signed_rate_kg_m2_s: 0.0,
            ice_signed_rate_kg_m2_s: 1e-8,
        });
        let detail =
            evaluate_v3_phase_free_open_surface(&problem, &problem.initial_trial(), context)
                .unwrap();
        assert_eq!(detail.vapor.liquid_signed_mass_kg_m2, 0.0);
        assert_eq!(
            detail.vapor.ice_signed_mass_kg_m2,
            1e-8 * problem.interval_s
        );
        let valid = problem.clone();
        context
            .finalized_vapor
            .as_mut()
            .unwrap()
            .liquid_signed_rate_kg_m2_s = f64::NAN;
        assert!(
            evaluate_v3_phase_free_open_surface(&problem, &problem.initial_trial(), context)
                .is_err()
        );
        assert_eq!(problem, valid);
        context.finalized_vapor = None;
        problem.surface_liquid_kg_m2_tile += 1.0;
        assert!(
            evaluate_v3_phase_free_open_surface(&problem, &problem.initial_trial(), context)
                .is_err()
        );
    }
    #[test]
    fn v3_open_litter_phase_ties_freeze_private_probes_only() {
        let (mut problem, mut context) = equilibrium(3.0, 17.0, 285.0);
        problem.air_specific_humidity_kg_kg = 0.0;
        let x = problem.initial_trial();
        let (_, natural) =
            crate::solver::evaluate_open_surface_v3_private(&problem, &x, context, None).unwrap();
        let raw = natural.raw;
        context.finalized_vapor = Some(FinalizedLitterVapor {
            liquid_signed_rate_kg_m2_s: raw.raw_liquid_signed_rate_kg_m2_s,
            ice_signed_rate_kg_m2_s: raw.raw_ice_signed_rate_kg_m2_s,
        });
        let (_, tie) =
            crate::solver::evaluate_open_surface_v3_private(&problem, &x, context, None).unwrap();
        assert!(tie.branches.liquid_cap.is_some() && tie.branches.ice_cap.is_some());
        for delta in [-1e-4, 1e-4] {
            let mut probe = x.clone();
            probe[0] += delta;
            let (evaluation, vapor) = crate::solver::evaluate_open_surface_v3_private(
                &problem,
                &probe,
                context,
                Some(tie.branches),
            )
            .unwrap();
            assert!(
                evaluation
                    .normalized_residuals
                    .iter()
                    .all(|r| r.is_finite())
            );
            assert_eq!(vapor.rates, tie.rates);
            assert!(vapor.receipt.is_none());
            assert!(
                V3PhaseFreeOpenEvaluation::from_accepted_primitives(
                    evaluation,
                    vapor,
                    context,
                    problem.interval_s
                )
                .is_err()
            );
            if delta < 0.0 {
                assert!(
                    crate::finalize_litter_vapor(
                        vapor.raw,
                        vapor.rates,
                        context.beginning,
                        probe[0],
                        problem.interval_s
                    )
                    .is_err()
                );
                let (_, fresh) = crate::solver::evaluate_open_surface_v3_private(
                    &problem, &probe, context, None,
                )
                .unwrap();
                assert!(
                    fresh.rates.liquid_signed_rate_kg_m2_s < tie.rates.liquid_signed_rate_kg_m2_s
                );
            }
        }
        // The other phase remains on its own raw branch.
        context
            .finalized_vapor
            .as_mut()
            .unwrap()
            .ice_signed_rate_kg_m2_s = 1.0;
        let (_, one) =
            crate::solver::evaluate_open_surface_v3_private(&problem, &x, context, None).unwrap();
        assert!(one.branches.liquid_cap.is_some());
        assert!(one.branches.ice_cap.is_none());
        // Availability ties use the same cap-side derivative, independently.
        let mut raw = raw;
        raw.raw_liquid_signed_rate_kg_m2_s =
            context.beginning.liquid_kg_m2_tile / problem.interval_s;
        context.finalized_vapor = None;
        assert!(
            PhaseBranches::select(raw, context, problem.interval_s)
                .liquid_cap
                .is_some()
        );
    }

    #[test]
    fn v3_open_litter_nonzero_flux_uses_independent_energy_and_mass_operands() {
        let (mut problem, context) = equilibrium(3.0, 17.0, 285.0);
        problem.air_specific_humidity_kg_kg = 0.0;
        problem.atmospheric_downward_longwave_w_m2 += 25.0;
        let outcome =
            solve_v3_phase_free_open_surface(&problem, &problem.initial_trial(), context).unwrap();
        let NormalizedSolveOutcome::Accepted { detail, .. } = outcome else {
            panic!("nonzero solution rejected")
        };
        let t = detail.predecessor.surface_temperature_k;
        let ml = detail.vapor.finalized.liquid_signed_rate_kg_m2_s * 1800.0;
        let mi = detail.vapor.finalized.ice_signed_rate_kg_m2_s * 1800.0;
        assert!(ml > 0.0 && mi > 0.0);
        let wl = 3.0 - ml;
        let wi = 17.0 - mi;
        assert_eq!(detail.post_vapor.liquid_kg_m2_tile, wl);
        assert_eq!(detail.post_vapor.ice_kg_m2_tile, wi);
        let u = (3235.68 + 4218.0 * wl + 2106.0 * wi) * (t - 273.15);
        assert_eq!(detail.post_vapor.sensible_energy_j_m2_tile, u);
        let radiation = problem.atmospheric_downward_longwave_w_m2 - 5.670374419e-8 * t.powi(4);
        let h = problem.air_pressure_pa / (287.05 * problem.air_temperature_k)
            * 1004.64
            * (t - problem.air_temperature_k)
            / detail.predecessor.neutral_resistances.heat_s_m;
        // Constants are checked independently against the declared crate model.
        assert!((radiation - detail.predecessor.longwave_net_w_m2_tile).abs() < 1e-10);
        let soil_t = detail.predecessor.soil_temperature_k[0];
        let g = 0.5 / (0.04 / (2.0 * 0.103) + 0.08 / (2.0 * 1.1)) * (t - soil_t);
        let ql = ml * (4218.0 * (t - 273.15) + 2501000.0 - 2369.0 * (t - 273.15));
        let qi = mi * (2106.0 * (t - 273.15) + 2501000.0 - 2369.0 * (t - 273.15) + 333700.0);
        assert!((h - detail.predecessor.sensible_w_m2_tile).abs() < 1e-10);
        assert!((g - detail.predecessor.ground_heat_cn_w_m2_tile[0]).abs() < 1e-10);
        assert!((ql - detail.vapor.liquid_signed_energy_j_m2).abs() < 1e-8);
        assert!((qi - detail.vapor.ice_signed_energy_j_m2).abs() < 1e-8);
        let storage = (u - context.beginning.sensible_energy_j_m2_tile) / 1800.0;
        let balance = 1800.0 * (storage - radiation + h + g) + ql + qi;
        // Nonlinear consistency allowance is dt times the declared equation
        // tolerance; it is distinct from transport/rounding accounting.
        let scale =
            radiation.abs() + h.abs() + g.abs() + ((ql + qi) / 1800.0).abs() + storage.abs();
        let nonlinear_allowance = 1800.0 * (1e-6 + 1e-10 * scale.max(1.0));
        assert!(
            balance.abs() <= nonlinear_allowance,
            "energy residual={balance}"
        );
        let soil_energy = 120000.0 * (soil_t - problem.soil_nodes[0].beginning_temperature_k);
        let soil_allowance =
            1800.0 * (1e-6 + 1e-10 * (g.abs() + (soil_energy / 1800.0).abs()).max(1.0));
        assert!((soil_energy - 1800.0 * g).abs() <= soil_allowance);
    }

    #[test]
    fn v3_open_litter_near_exhaustion_probe_is_not_a_physical_candidate() {
        let (mut problem, context) = equilibrium(3.0, 0.0, 305.0);
        problem.reference_wind_m_s = 20.0;
        problem.air_specific_humidity_kg_kg = 0.0;
        let x = problem.initial_trial();
        let (_, raw) =
            crate::solver::evaluate_open_surface_v3_private(&problem, &x, context, None).unwrap();
        problem.interval_s = 3.0 / (raw.raw.raw_liquid_signed_rate_kg_m2_s * (1.0 + 1e-8));
        let (_, base) =
            crate::solver::evaluate_open_surface_v3_private(&problem, &x, context, None).unwrap();
        assert!(base.post_vapor.liquid_kg_m2_tile > 0.0);
        assert!(base.branches.liquid_cap.is_none());
        let mut probe = x;
        probe[0] += f64::EPSILON.sqrt() * 305.0;
        let (detail, private) = crate::solver::evaluate_open_surface_v3_private(
            &problem,
            &probe,
            context,
            Some(base.branches),
        )
        .unwrap();
        assert!(private.post_vapor.liquid_kg_m2_tile < 0.0);
        assert!(detail.normalized_residuals.iter().all(|v| v.is_finite()));
        assert!(private.receipt.is_none());
        assert!(
            crate::finalize_litter_vapor(
                private.raw,
                private.rates,
                context.beginning,
                probe[0],
                problem.interval_s
            )
            .is_err()
        );
        let natural = evaluate_v3_phase_free_open_surface(&problem, &probe, context).unwrap();
        assert!(natural.post_vapor.liquid_kg_m2_tile >= 0.0);
    }
}
