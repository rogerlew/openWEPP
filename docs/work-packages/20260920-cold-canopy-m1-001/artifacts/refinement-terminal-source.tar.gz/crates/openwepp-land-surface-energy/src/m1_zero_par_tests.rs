use crate::{
    CoveredColumnInputs, V10LeafGasBranch, m1_zero_par_leaf_state, solve_m1_full_supply_hydraulics,
};
use serde_json::Value;

const GAS: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/dark-gas-reference-m1.json"
));
const ORIGINAL: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../docs/work-packages/20260920-cold-canopy-m1-001/artifacts/original-input-reference.json"
));

fn decimal(value: &Value) -> f64 {
    value
        .as_str()
        .expect("decimal")
        .parse()
        .expect("finite decimal")
}
fn close(actual: f64, expected: &Value, tolerance: &Value) {
    let expected = decimal(expected);
    assert!(actual.is_finite());
    assert!(
        (actual - expected).abs()
            <= decimal(&tolerance["absolute"])
                .max(decimal(&tolerance["relative"]) * expected.abs()),
        "{actual} != {expected}"
    );
}

#[test]
fn m1_internal_liquid_zero_par_rows_match_frozen_gas_controls() {
    let gas: Value = serde_json::from_str(GAS).expect("gas reference");
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input");
    let mut column: CoveredColumnInputs =
        serde_json::from_value(original["inputs"].clone()).expect("covered input");
    let mut seen = std::collections::BTreeSet::new();
    for row in gas["rows"].as_array().expect("four rows") {
        let occupancy = column
            .occupancies
            .iter_mut()
            .find(|o| o.occupancy_id == row["occupancy_id"].as_str().expect("occupancy"))
            .expect("occupancy coefficients");
        occupancy.sun.leaf_area_m2_m2_tile = 0.0;
        occupancy.shade.leaf_area_m2_m2_tile = 1.0;
        occupancy.sun.absorbed_par_w_m2_leaf = 0.0;
        occupancy.shade.absorbed_par_w_m2_leaf = 0.0;
        let occupancy = occupancy.clone();
        let temperature = decimal(&row["leaf_temperature_k"]);
        let shade = m1_zero_par_leaf_state(
            occupancy.shade,
            occupancy.biochemical,
            temperature,
            268.0,
            0.0015,
            90_000.0,
            column.ca_pa,
            occupancy.gb_leaf_m_s,
            occupancy.g0_umol_m2_s,
            0.25,
        )
        .expect("shade");
        let sun = m1_zero_par_leaf_state(
            occupancy.sun,
            occupancy.biochemical,
            temperature,
            268.0,
            0.0015,
            90_000.0,
            column.ca_pa,
            occupancy.gb_leaf_m_s,
            occupancy.g0_umol_m2_s,
            0.25,
        )
        .expect("sun");
        let leaves = row["leaves"].as_array().expect("leaves");
        assert!(seen.insert((
            row["occupancy_id"].as_str().expect("id").to_owned(),
            temperature.to_bits()
        )));
        assert_eq!(shade.gas_branch, V10LeafGasBranch::ExactZeroPar);
        assert_eq!(sun.gas_branch, V10LeafGasBranch::Inactive);
        assert_eq!(sun.beta, decimal(&leaves[0]["beta"]));
        assert_eq!(shade.beta, decimal(&leaves[1]["beta"]));
        close(
            sun.internal_specific_humidity_kg_kg,
            &row["internal_liquid_qsat"],
            &gas["comparisons"]["specific_humidity"],
        );
        close(
            sun.conductance_m_s,
            &leaves[0]["gs_m_s"],
            &gas["comparisons"]["conductance_m_s"],
        );
        close(sun.ci_pa, &leaves[0]["ci_pa"], &gas["comparisons"]["ci_pa"]);
        assert_eq!(sun.gross_assimilation_umol_co2_m2_leaf_s, 0.0);
        assert_eq!(sun.net_assimilation_umol_co2_m2_leaf_s, 0.0);
        assert_eq!(sun.dark_respiration_umol_co2_m2_leaf_s, 0.0);
        close(
            shade.internal_specific_humidity_kg_kg,
            &row["internal_liquid_qsat"],
            &gas["comparisons"]["specific_humidity"],
        );
        close(
            shade.dark_respiration_umol_co2_m2_leaf_s,
            &leaves[1]["rd"],
            &gas["comparisons"]["respiration_assimilation"],
        );
        close(
            shade.net_assimilation_umol_co2_m2_leaf_s,
            &leaves[1]["an"],
            &gas["comparisons"]["respiration_assimilation"],
        );
        close(
            shade.gross_assimilation_umol_co2_m2_leaf_s,
            &leaves[1]["ag"],
            &gas["comparisons"]["respiration_assimilation"],
        );
        close(
            shade.conductance_m_s,
            &leaves[1]["gs_m_s"],
            &gas["comparisons"]["conductance_m_s"],
        );
        close(
            shade.ci_pa,
            &leaves[1]["ci_pa"],
            &gas["comparisons"]["ci_pa"],
        );
        close(
            shade.vapor_kg_m2_tile_s,
            &leaves[1]["vapor_kg_m2_tile_s"],
            &gas["comparisons"]["water_flux_kg_m2_tile_s"],
        );
        assert_eq!(sun.vapor_kg_m2_tile_s, 0.0);
        let hydraulic = solve_m1_full_supply_hydraulics(
            &column,
            &occupancy,
            [sun.vapor_kg_m2_tile_s, shade.vapor_kg_m2_tile_s],
            [sun.gas_branch, shade.gas_branch],
        )
        .expect("hydraulics");
        for (actual, expected) in hydraulic
            .potentials_mm
            .iter()
            .zip(row["potentials_mm"].as_array().expect("potentials"))
        {
            close(
                *actual,
                expected,
                &gas["comparisons"]["hydraulic_potential_mm"],
            );
        }
        close(
            hydraulic.stem_flux_kg_m2_tile_s,
            &row["stem_flux"],
            &gas["comparisons"]["water_flux_kg_m2_tile_s"],
        );
        let expected_ids: Vec<String> = row["root_layer_ids"]
            .as_array()
            .expect("ids")
            .iter()
            .map(|x| x.as_str().expect("id").to_owned())
            .collect();
        let actual: Vec<_> = hydraulic
            .root_layer_ids
            .iter()
            .zip(&hydraulic.root_fluxes_kg_m2_tile_s)
            .filter(|(id, _)| expected_ids.contains(id))
            .collect();
        assert_eq!(actual.len(), expected_ids.len());
        for ((id, flux), expected) in actual
            .iter()
            .zip(row["root_fluxes"].as_array().expect("fluxes"))
        {
            assert_eq!(
                *id,
                &expected_ids[actual.iter().position(|x| x.0 == *id).expect("position")]
            );
            close(
                **flux,
                expected,
                &gas["comparisons"]["water_flux_kg_m2_tile_s"],
            );
        }
        for (actual, expected) in hydraulic
            .continuity_residuals_kg_m2_tile_s
            .iter()
            .zip(row["continuity_residuals"].as_array().expect("continuity"))
        {
            close(
                *actual,
                expected,
                &gas["comparisons"]["continuity_residual_kg_m2_tile_s"],
            );
        }
    }
    assert_eq!(
        seen,
        std::collections::BTreeSet::from([
            ("stratum-z-upper::forest".to_owned(), 263.15_f64.to_bits()),
            ("stratum-a-lower::forest".to_owned(), 263.15_f64.to_bits()),
            ("stratum-z-upper::forest".to_owned(), 278.15_f64.to_bits()),
            ("stratum-a-lower::forest".to_owned(), 278.15_f64.to_bits()),
        ])
    );
}

#[test]
fn m1_zero_par_leaf_rejects_vpd_area_humidity_and_pressure_domain_poison() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input");
    let column: CoveredColumnInputs =
        serde_json::from_value(original["inputs"].clone()).expect("covered input");
    let mut leaf = column.occupancies[0].shade;
    leaf.leaf_area_m2_m2_tile = 1.0;
    leaf.absorbed_par_w_m2_leaf = 0.0;
    let invoke = |leaf, q, pressure| {
        m1_zero_par_leaf_state(
            leaf,
            column.occupancies[0].biochemical,
            263.15,
            268.0,
            q,
            pressure,
            column.ca_pa,
            column.occupancies[0].gb_leaf_m_s,
            column.occupancies[0].g0_umol_m2_s,
            0.25,
        )
    };
    assert_eq!(
        invoke(leaf, 0.01, 90_000.0).expect_err("VPD").code(),
        "VEG-E-140"
    );
    assert_eq!(
        invoke(leaf, f64::NAN, 90_000.0)
            .expect_err("humidity")
            .code(),
        "VEG-E-141"
    );
    assert_eq!(
        invoke(leaf, 0.0015, 79_999.0).expect_err("pressure").code(),
        "VEG-E-141"
    );
    let mut negative = leaf;
    negative.leaf_area_m2_m2_tile = -1.0;
    assert_eq!(
        invoke(negative, 0.0015, 90_000.0)
            .expect_err("negative area")
            .code(),
        "VEG-E-140"
    );
    let mut nonfinite = leaf;
    nonfinite.leaf_area_m2_m2_tile = f64::NAN;
    assert_eq!(
        invoke(nonfinite, 0.0015, 90_000.0)
            .expect_err("nonfinite area")
            .code(),
        "VEG-E-141"
    );
}

#[test]
fn m1_zero_par_leaf_rejects_every_nonfinite_gas_operand_with_saturation_code() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input");
    let column: CoveredColumnInputs =
        serde_json::from_value(original["inputs"].clone()).expect("covered input");
    let leaf = column.occupancies[0].shade;
    let biochemical = column.occupancies[0].biochemical;
    let invoke = |leaf, leaf_t, canopy_t, q, p, ca, gb, g0, fw| {
        m1_zero_par_leaf_state(leaf, biochemical, leaf_t, canopy_t, q, p, ca, gb, g0, fw)
    };
    for poison in [f64::NAN, f64::INFINITY] {
        let cases = [
            invoke(
                leaf,
                poison,
                268.0,
                0.0015,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25,
            ),
            invoke(
                leaf,
                263.15,
                poison,
                0.0015,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25,
            ),
            invoke(
                leaf,
                263.15,
                268.0,
                poison,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25,
            ),
            invoke(
                leaf,
                263.15,
                268.0,
                0.0015,
                poison,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25,
            ),
            invoke(
                leaf,
                263.15,
                268.0,
                0.0015,
                90_000.0,
                poison,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25,
            ),
            invoke(
                leaf,
                263.15,
                268.0,
                0.0015,
                90_000.0,
                column.ca_pa,
                poison,
                column.occupancies[0].g0_umol_m2_s,
                0.25,
            ),
            invoke(
                leaf,
                263.15,
                268.0,
                0.0015,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                poison,
                0.25,
            ),
            invoke(
                leaf,
                263.15,
                268.0,
                0.0015,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                poison,
            ),
        ];
        for result in cases {
            assert_eq!(
                result.expect_err("nonfinite gas operand").code(),
                "VEG-E-141"
            );
        }
        let mut area = leaf;
        area.leaf_area_m2_m2_tile = poison;
        assert_eq!(
            invoke(
                area,
                263.15,
                268.0,
                0.0015,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25
            )
            .expect_err("nonfinite area")
            .code(),
            "VEG-E-141"
        );
        let mut par = leaf;
        par.absorbed_par_w_m2_leaf = poison;
        assert_eq!(
            invoke(
                par,
                263.15,
                268.0,
                0.0015,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25
            )
            .expect_err("nonfinite PAR")
            .code(),
            "VEG-E-141"
        );
        let mut rd25 = leaf;
        rd25.rd25 = poison;
        assert_eq!(
            invoke(
                rd25,
                263.15,
                268.0,
                0.0015,
                90_000.0,
                column.ca_pa,
                column.occupancies[0].gb_leaf_m_s,
                column.occupancies[0].g0_umol_m2_s,
                0.25
            )
            .expect_err("nonfinite rd25")
            .code(),
            "VEG-E-141"
        );
    }
    assert_eq!(
        invoke(
            leaf,
            263.14,
            268.0,
            0.0015,
            90_000.0,
            column.ca_pa,
            column.occupancies[0].gb_leaf_m_s,
            column.occupancies[0].g0_umol_m2_s,
            0.25
        )
        .expect_err("finite leaf-temperature domain")
        .code(),
        "VEG-E-140"
    );
}

#[test]
fn m1_full_supply_hydraulics_rejects_nonfinite_and_invalid_branch_operands() {
    let original: Value = serde_json::from_str(ORIGINAL).expect("original input");
    let column: CoveredColumnInputs =
        serde_json::from_value(original["inputs"].clone()).expect("covered input");
    let mut occupancy = column.occupancies[0].clone();
    occupancy.sun.leaf_area_m2_m2_tile = 0.0;
    occupancy.shade.leaf_area_m2_m2_tile = 1.0;
    let branches = [V10LeafGasBranch::Inactive, V10LeafGasBranch::ExactZeroPar];
    assert_eq!(
        solve_m1_full_supply_hydraulics(&column, &occupancy, [0.0, f64::NAN], branches)
            .expect_err("nonfinite demand")
            .code(),
        "VEG-E-141"
    );
    assert_eq!(
        solve_m1_full_supply_hydraulics(&column, &occupancy, [1.0, 0.0], branches)
            .expect_err("inactive demand")
            .code(),
        "VEG-E-140"
    );
    assert_eq!(
        solve_m1_full_supply_hydraulics(
            &column,
            &occupancy,
            [0.0, 0.0],
            [
                V10LeafGasBranch::ExactZeroPar,
                V10LeafGasBranch::ExactZeroPar
            ],
        )
        .expect_err("inactive branch")
        .code(),
        "VEG-E-140"
    );
    occupancy.k1_shade_max_s1 = 0.0;
    assert_eq!(
        solve_m1_full_supply_hydraulics(&column, &occupancy, [0.0, 0.0], branches)
            .expect_err("positive-area leaf coefficient")
            .code(),
        "VEG-E-140"
    );
}
