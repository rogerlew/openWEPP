use super::*;
use crate::{
    BandDirectionalFluxes, BiochemicalConstants, ComponentId, CoveredColumnAuthority,
    CoveredColumnShortwaveInputs, CoveredOccupancyInputs, CoveredOccupancyShortwaveInputs,
    LeafBiochemicalInputs, OpenNeutralGeometry, OpenSurfaceProblem, RootHydraulicLayer,
    SoilThermalLayerSnapshot, SoilThermalNodeOperands, SoilThermalOfeSnapshot, SoilThermalSnapshot,
    SurfaceId, SurfaceStorageBranch, UnderCanopyGeometry, WaterAuthorizationReason,
    evaluate_v3_phase_free_covered_column,
};
use openwepp_kernel_contract::SoilLayerId;

fn digest(byte: char) -> Sha256Digest {
    Sha256Digest::try_new(byte.to_string().repeat(64)).expect("test digest")
}

fn owner(value: &str) -> ResourceOwnerId {
    ResourceOwnerId::try_new(value).expect("test owner")
}

fn configuration() -> LitterPhaseConfiguration {
    LitterPhaseConfiguration {
        litter_depth_m: 0.04,
        dry_heat_capacity_j_m2_k: 3_235.68,
        liquid_capacity_kg_m2_tile: 6.0,
        ice_capacity_kg_m2_tile: 34.0,
    }
}

fn litter_beginning() -> BeginningLitterPhaseState {
    let liquid = 4.0;
    let ice = 0.5;
    let temperature = 295.0;
    let capacity = configuration().dry_heat_capacity_j_m2_k
        + liquid * crate::WATER_HEAT_CAPACITY_J_KG_K
        + ice * crate::LITTER_ICE_HEAT_CAPACITY_J_KG_K;
    BeginningLitterPhaseState {
        liquid_kg_m2_tile: liquid,
        ice_kg_m2_tile: ice,
        sensible_energy_j_m2_tile: capacity * (temperature - crate::REFERENCE_TEMPERATURE_K),
        temperature_k: temperature,
    }
}

#[allow(clippy::too_many_lines)]
fn column() -> CoveredColumnInputs {
    let litter = litter_beginning();
    let ground = OpenSurfaceProblem {
        interval_s: 1_800.0,
        tile_fraction: 0.38,
        class: SurfaceClassKind::ForestLitter,
        storage_branch: SurfaceStorageBranch::FiniteCapacity,
        terminal_shortwave_w_m2_tile: BandDirectionalFluxes {
            direct_vis: 47.4,
            diffuse_vis: 8.7,
            direct_nir: 41.1,
            diffuse_nir: 52.1,
        },
        surface_vis_albedo: 0.12,
        surface_nir_albedo: 0.24,
        surface_emissivity: 1.0,
        surface_depth_m: 0.04,
        surface_conductivity_w_m_k: 0.103,
        surface_dry_heat_capacity_j_m2_k: 3_235.68,
        litter_capacity_kg_m2_tile: Some(6.0),
        open_geometry: OpenNeutralGeometry {
            reference_height_m: 24.0,
            roughness_momentum_m: 1.25,
            roughness_heat_m: 0.12,
            roughness_vapor_m: 0.08,
        },
        air_temperature_k: 296.0,
        air_specific_humidity_kg_kg: 0.0102,
        air_pressure_pa: 101_325.0,
        reference_wind_m_s: 3.7,
        atmospheric_downward_longwave_w_m2: 395.0,
        surface_liquid_kg_m2_tile: litter.liquid_kg_m2_tile,
        surface_enthalpy_j_m2_tile: litter.sensible_energy_j_m2_tile,
        surface_temperature_warm_start_k: litter.temperature_k,
        bare_soil: None,
        soil_nodes: vec![
            SoilThermalNodeOperands {
                layer_id: "thermal-1".into(),
                depth_m: 0.08,
                conductivity_w_m_k: 1.1,
                heat_capacity_j_m2_k: 120_000.0,
                beginning_temperature_k: 291.5,
            },
            SoilThermalNodeOperands {
                layer_id: "thermal-2".into(),
                depth_m: 0.18,
                conductivity_w_m_k: 1.35,
                heat_capacity_j_m2_k: 180_000.0,
                beginning_temperature_k: 289.8,
            },
        ],
    };
    let occupancy = CoveredOccupancyInputs {
        occupancy_id: "canopy-rank-0".into(),
        medlyn_g1_kpa_sqrt: 3.5,
        g0_umol_m2_s: 25.0,
        sun: LeafBiochemicalInputs {
            leaf_area_m2_m2_tile: 1.11,
            absorbed_shortwave_w_m2_tile: 220.67,
            absorbed_par_w_m2_leaf: 136.73,
            vcmax25: 62.0,
            jmax25: 108.0,
            rd25: 1.15,
        },
        shade: LeafBiochemicalInputs {
            leaf_area_m2_m2_tile: 1.60,
            absorbed_shortwave_w_m2_tile: 300.71,
            absorbed_par_w_m2_leaf: 118.23,
            vcmax25: 41.0,
            jmax25: 74.0,
            rd25: 0.81,
        },
        biochemical: BiochemicalConstants {
            ha_vcmax_j_mol: 65_330.0,
            hd_vcmax_j_mol: 200_000.0,
            entropy_vcmax_j_mol_k: 650.0,
            ha_jmax_j_mol: 43_540.0,
            hd_jmax_j_mol: 200_000.0,
            entropy_jmax_j_mol_k: 650.0,
            kc25_pa: 40.49,
            ha_kc_j_mol: 79_430.0,
            ko25_pa: 27_840.0,
            ha_ko_j_mol: 36_380.0,
            gamma25_pa: 4.275,
            ha_gamma_j_mol: 37_830.0,
            oxygen_partial_pressure_pa: 20_265.0,
            tp_vcmax_ratio: 0.167,
            electron_quantum_yield: 0.85,
            par_photon_umol_per_j: 4.6,
            electron_curvature: 0.7,
            ac_aj_curvature: 0.98,
            ag_ap_curvature: 0.95,
        },
        stem_area_m2_m2_tile: 0.72,
        stem_absorbed_shortwave_w_m2_tile: 185.38,
        beginning_canopy_liquid_kg_m2_tile: 0.018,
        liquid_interception_fraction: 0.35,
        liquid_capacity_kg_m2_plant: 0.023_328_503_368_824_437,
        stemflow_fraction: 0.08,
        gb_leaf_m_s: 0.035_961_386_715_575_215,
        gb_wet_m_s: 0.019_071_405_305_591_295,
        gb_stem_m_s: 0.013_082_876_106_352_972,
        lai: 2.71,
        sai: 0.72,
        clumping_index: 0.82,
        k1_sun_max_s1: 1.2e-6,
        k1_shade_max_s1: 1.2e-6,
        k2_max: 4.2e-6,
        k3_max_m_s: 5.0e-5,
        height_m: 12.5,
        root_to_leaf_area: 1.8,
        p50_leaf_mm: -9_800.0,
        p50_xylem_mm: -7_200.0,
        p50_root_mm: -14_000.0,
        vulnerability_exponent: 2.0,
        root_layers: vec![RootHydraulicLayer {
            layer_id: "soil-1".into(),
            accessible: true,
            frozen: false,
            root_fraction: 1.0,
            soil_potential_mm: 100.0,
            gravity_head_mm: 120.0,
            z3_m: 0.32,
            dxroot_m: 0.18,
            ksoil_m2_s: 6.0e-11,
        }],
    };
    let ground_absorbed = crate::partition_ground_shortwave(
        ground.terminal_shortwave_w_m2_tile,
        ground.surface_vis_albedo,
        ground.surface_nir_albedo,
    )
    .expect("ground shortwave")
    .absorbed;
    let sun = BandDirectionalFluxes {
        direct_vis: occupancy.sun.absorbed_shortwave_w_m2_tile,
        ..BandDirectionalFluxes::default()
    };
    let shade = BandDirectionalFluxes {
        direct_vis: occupancy.shade.absorbed_shortwave_w_m2_tile,
        ..BandDirectionalFluxes::default()
    };
    let stem = BandDirectionalFluxes {
        direct_vis: occupancy.stem_absorbed_shortwave_w_m2_tile,
        ..BandDirectionalFluxes::default()
    };
    let incident = BandDirectionalFluxes {
        direct_vis: ground_absorbed.direct_vis
            + sun.direct_vis
            + shade.direct_vis
            + stem.direct_vis,
        diffuse_vis: ground_absorbed.diffuse_vis,
        direct_nir: ground_absorbed.direct_nir,
        diffuse_nir: ground_absorbed.diffuse_nir,
    };
    CoveredColumnInputs {
        transparent_liquid_boundary: None,
        authority: CoveredColumnAuthority::HistoricalV8,
        interval_s: ground.interval_s,
        tile_fraction: ground.tile_fraction,
        pressure_pa: ground.air_pressure_pa,
        air_temperature_k: ground.air_temperature_k,
        air_specific_humidity_kg_kg: ground.air_specific_humidity_kg_kg,
        reference_wind_m_s: ground.reference_wind_m_s,
        atmospheric_downward_longwave_w_m2: ground.atmospheric_downward_longwave_w_m2,
        ca_pa: 42.0,
        canopy_to_atmosphere_heat_resistance_s_m: 20.99,
        canopy_to_atmosphere_vapor_resistance_s_m: 22.73,
        latent_heat_j_kg: 2_501_000.0,
        top_rain_kg_m2_tile: 0.0,
        under_canopy_geometry: UnderCanopyGeometry {
            canopy_height_m: 12.5,
            canopy_roughness_m: 1.25,
            reference_height_m: 24.0,
            leaf_area_index: 2.7,
        },
        ground,
        occupancies: vec![occupancy],
        shortwave: CoveredColumnShortwaveInputs {
            incident_w_m2_tile: incident,
            top_reflected_w_m2_tile: BandDirectionalFluxes::default(),
            ground_absorbed_by_incident_w_m2_tile: ground_absorbed,
            occupancies: vec![CoveredOccupancyShortwaveInputs {
                occupancy_id: "canopy-rank-0".into(),
                sun_leaf_absorbed_w_m2_tile: sun,
                shade_leaf_absorbed_w_m2_tile: shade,
                stem_absorbed_w_m2_tile: stem,
            }],
        },
        stage3_lower_boundary: None,
        stage3_optical: None,
    }
}

fn identity(interval_s: f64) -> RuntimeTileIdentity {
    RuntimeTileIdentity {
        transaction_id: TransactionId(91),
        soil_thermal_transaction_id: TransactionId(91),
        lse_owner_id: owner("lse-v3"),
        hydrology_owner_id: owner("hydrology"),
        soil_thermal_owner_id: owner("soil"),
        vegetation_owner_id: owner("vegetation"),
        biogeochemistry_owner_id: owner("bgc"),
        configuration_sha256: digest('a'),
        beginning_lse_state_sha256: digest('b'),
        beginning_hydrology_snapshot_sha256: digest('c'),
        beginning_soil_thermal_state_sha256: digest('d'),
        beginning_vegetation_state_sha256: digest('e'),
        beginning_biogeochemistry_state_sha256: digest('f'),
        ofe_id: OfeId::try_new("ofe-1").expect("ofe"),
        tile_id: TileId::try_new("forest").expect("tile"),
        surface_id: SurfaceId::try_new("litter").expect("surface"),
        surface_class: SurfaceClass::ForestLitter,
        ground_source_type: WaterSourceType::LitterLiquid,
        ground_source_id: crate::SourceId::try_new("litter").expect("source"),
        ground_source_tile_id: Some(TileId::try_new("forest").expect("tile")),
        ground_soil_layer_id: None,
        tile_fraction: 0.38,
        interval_s,
    }
}

fn initial_trial() -> Vec<f64> {
    vec![
        -17_238.6, -17_192.4, -17_085.3, -4_540.2, 0.413, 0.415, 303.6, 303.5, 306.4, 312.5, 300.1,
        0.01393, 296.0, 291.5, 289.8,
    ]
}

fn roots() -> Vec<RootRuntimeIdentity> {
    vec![RootRuntimeIdentity {
        solver_occupancy_id: "canopy-rank-0".into(),
        requesting_owner_id: owner("vegetation"),
        occupancy_id: ComponentId::try_new("canopy-rank-0").expect("occupancy"),
        layer_id: SoilLayerId::try_new("soil-1").expect("layer"),
        source_id: crate::SourceId::try_new("soil-1").expect("source"),
    }]
}

fn soil() -> SoilThermalSnapshot {
    SoilThermalSnapshot {
        owner_id: owner("soil"),
        configuration_sha256: digest('a'),
        state_sha256: digest('d'),
        snapshot_sha256: digest('9'),
        last_accepted_transaction_id: Some(TransactionId(90)),
        ofes: vec![SoilThermalOfeSnapshot {
            ofe_id: OfeId::try_new("ofe-1").expect("ofe"),
            ordered_layers: vec![
                SoilThermalLayerSnapshot {
                    layer_id: SoilLayerId::try_new("thermal-1").expect("layer"),
                    temperature_k: 291.5,
                    enthalpy_j_m2_ofe_ground: 1.0e6,
                },
                SoilThermalLayerSnapshot {
                    layer_id: SoilLayerId::try_new("thermal-2").expect("layer"),
                    temperature_k: 289.8,
                    enthalpy_j_m2_ofe_ground: 2.0e6,
                },
            ],
        }],
    }
}

#[test]
fn potential_and_fixed_final_use_v3_and_return_the_accepted_evaluation() {
    let beginning = column();
    let beginning_bytes = serde_json::to_vec(&format!("{beginning:?}")).expect("beginning bytes");
    let potential = solve_v3_covered_potential_phase(
        identity(1_800.0),
        &beginning,
        roots(),
        &initial_trial(),
        configuration(),
        litter_beginning(),
    )
    .expect("V3 potential");
    let vapor = potential.accepted().evaluation.vapor.finalized;
    let phase_authorization = V3PhaseSpecificVaporAuthorization {
        liquid_outbound_rate_kg_m2_s: vapor.liquid_signed_rate_kg_m2_s.max(0.0),
        ice_outbound_rate_kg_m2_s: vapor.ice_signed_rate_kg_m2_s.max(0.0),
    };
    let amount = phase_authorization
        .aggregate_outbound_kg_m2_stand_ground(beginning.tile_fraction, beginning.interval_s)
        .expect("aggregate authorization");
    let authorizations = potential
        .request_batch()
        .requests
        .iter()
        .map(|request| WaterAuthorization {
            key: request.key.clone(),
            amount_kg_m2_stand_ground: if request.key.requesting_component
                == RequestingComponent::GroundSurface
            {
                amount
            } else {
                request.amount_kg_m2_stand_ground
            },
            reason: WaterAuthorizationReason::FullSupply,
        })
        .collect();
    let fixed = finalize_v3_covered_phase(
        &potential,
        &digest('b'),
        authorizations,
        phase_authorization,
        &potential.accepted().solution,
        SoilThermalFinalizationBeginning::V1(&soil()),
    )
    .expect("V3 fixed final");
    let accepted = &fixed.accepted_fixed_final.evaluation;
    assert_eq!(
        (accepted.vapor.finalized.liquid_signed_rate_kg_m2_s
            + accepted.vapor.finalized.ice_signed_rate_kg_m2_s)
            .to_bits(),
        accepted
            .predecessor
            .ground_water
            .final_kg_m2_tile_s
            .to_bits()
    );
    assert_eq!(
        fixed.water_protocol.requests,
        potential.request_batch().requests
    );
    assert_eq!(fixed.water_protocol.authorizations.len(), 2);
    assert_eq!(fixed.water_protocol.finalized_uses.len(), 2);
    let finalized_surface_use = fixed
        .water_protocol
        .finalized_uses
        .iter()
        .find(|row| row.key.requesting_component == RequestingComponent::GroundSurface)
        .expect("named V3 surface finalized use");
    assert_eq!(
        finalized_surface_use.amount_kg_m2_stand_ground.to_bits(),
        amount.to_bits(),
        "the publishable debit is the authorized aggregate of accepted liquid and ice vapor"
    );
    assert!(fixed.water_protocol.condensation_credits.is_empty());
    assert_eq!(
        serde_json::to_vec(&format!("{beginning:?}")).expect("ending bytes"),
        beginning_bytes
    );
}

#[test]
fn phase_free_v3_evaluation_admits_subfreezing_litter_without_legacy_liquid_domain() {
    let mut beginning = column();
    let mut litter = litter_beginning();
    let temperature_k = 270.0;
    let capacity = configuration().dry_heat_capacity_j_m2_k
        + litter.liquid_kg_m2_tile * crate::WATER_HEAT_CAPACITY_J_KG_K
        + litter.ice_kg_m2_tile * crate::LITTER_ICE_HEAT_CAPACITY_J_KG_K;
    litter.temperature_k = temperature_k;
    litter.sensible_energy_j_m2_tile = capacity * (temperature_k - crate::REFERENCE_TEMPERATURE_K);
    beginning.ground.surface_temperature_warm_start_k = temperature_k;
    beginning.ground.surface_enthalpy_j_m2_tile = litter.sensible_energy_j_m2_tile;
    let mut trial = initial_trial();
    trial[12] = temperature_k;

    let evaluation = evaluate_v3_phase_free_covered_column(
        &beginning,
        &trial,
        None,
        None,
        V3LitterResidualContext {
            configuration: configuration(),
            beginning: litter,
            finalized_vapor: None,
        },
    )
    .expect("subfreezing V3 evaluation");

    assert_eq!(
        evaluation
            .vapor
            .raw
            .environment
            .accepted_phase_free_temperature_k
            .to_bits(),
        temperature_k.to_bits()
    );
    assert!(evaluation.vapor.raw.raw_ice_signed_rate_kg_m2_s.is_finite());
}

#[test]
fn off_grid_support_rejects_before_any_v3_solve() {
    let beginning = column();
    let error = solve_v3_covered_potential_phase(
        identity(90.0),
        &beginning,
        roots(),
        &initial_trial(),
        configuration(),
        litter_beginning(),
    )
    .expect_err("off-grid support");
    assert!(matches!(
        error,
        LandSurfaceEnergyError::FrozenLitterTransaction(_)
    ));
}

#[test]
fn aggregate_and_named_authorization_mismatch_fails_closed() {
    let beginning = column();
    let potential = solve_v3_covered_potential_phase(
        identity(1_800.0),
        &beginning,
        roots(),
        &initial_trial(),
        configuration(),
        litter_beginning(),
    )
    .expect("V3 potential");
    let authorizations = potential
        .request_batch()
        .requests
        .iter()
        .map(|request| WaterAuthorization {
            key: request.key.clone(),
            amount_kg_m2_stand_ground: if request.key.requesting_component
                == RequestingComponent::GroundSurface
            {
                0.0
            } else {
                request.amount_kg_m2_stand_ground
            },
            reason: WaterAuthorizationReason::ZeroSupply,
        })
        .collect();
    let error = finalize_v3_covered_phase(
        &potential,
        &digest('b'),
        authorizations,
        V3PhaseSpecificVaporAuthorization {
            liquid_outbound_rate_kg_m2_s: 1.0e-9,
            ice_outbound_rate_kg_m2_s: 0.0,
        },
        &potential.accepted().solution,
        SoilThermalFinalizationBeginning::V1(&soil()),
    )
    .expect_err("mismatched aggregate authorization");
    assert!(matches!(
        error,
        LandSurfaceEnergyError::FrozenLitterVapor(_)
    ));
}

#[test]
fn successor_producer_binds_only_the_v3_covered_solver() {
    let source = include_str!("transaction_v3.rs");
    assert!(
        source
            .matches("solve_v3_phase_free_covered_column(")
            .count()
            >= 2
    );
    assert!(!source.contains("solve_covered_potential_phase("));
    assert!(!source.contains("finalize_covered_phase("));
    assert!(!source.contains("solve_covered_column("));
}

#[test]
fn native_snow_shared_node_evaluates_constitutive_fluxes_independent_of_guess() {
    use crate::{
        NativeSnowExchangeV1, Stage3SnowCoveredLowerBoundary,
        Stage3SnowOpticalBoundaryReceiptInputs, Stage3SnowOpticalBoundaryReceiptV1,
    };
    crate::snow_accuracy_policy::Policy::B01.install().unwrap();
    let mut c = column();
    c.authority = CoveredColumnAuthority::V11SnowCovered;
    let optical =
        Stage3SnowOpticalBoundaryReceiptV1::try_new(Stage3SnowOpticalBoundaryReceiptInputs {
            ofe_id: OfeId::try_new("ofe-1").unwrap(),
            tile_id: TileId::try_new("forest").unwrap(),
            terminal_w_m2_tile: c.ground.terminal_shortwave_w_m2_tile,
            absorbed_w_m2_tile: crate::partition_ground_shortwave(
                c.ground.terminal_shortwave_w_m2_tile,
                c.ground.surface_vis_albedo,
                c.ground.surface_nir_albedo,
            )
            .unwrap()
            .absorbed,
            reflected_w_m2_tile: crate::partition_ground_shortwave(
                c.ground.terminal_shortwave_w_m2_tile,
                c.ground.surface_vis_albedo,
                c.ground.surface_nir_albedo,
            )
            .unwrap()
            .reflected,
            snow_vis_albedo: c.ground.surface_vis_albedo,
            snow_nir_albedo: c.ground.surface_nir_albedo,
            stage3_albedo_state_sha256: digest('a'),
            forcing_receipt_sha256: digest('b'),
        })
        .unwrap();
    let mut exchange = NativeSnowExchangeV1 {
        policy_id: 14,
        ofe_id: optical.ofe_id.clone(),
        tile_id: optical.tile_id.clone(),
        start_ns: 0,
        end_ns: 1_800_000_000_000,
        snow_temperature_k: 273.15,
        snow_saturation_specific_humidity: 0.004,
        pressure_pa: c.pressure_pa,
        heat_conductance_m_s: 0.025,
        vapor_conductance_m_s: 0.02,
        forcing_sha256: digest('b'),
        exposure_sha256: digest('c'),
        payload_sha256: digest('d'),
    };
    exchange.payload_sha256 = exchange.reconstructed_sha256().unwrap();
    c.stage3_lower_boundary = Some(Stage3SnowCoveredLowerBoundary {
        native_snow_exchange: Some(exchange.clone()),
        snow_temperature_k: 273.15,
        latent_heat_j_kg: 2_834_000.0,
        sensible_to_canopy_air_w_m2: 777.0,
        vapor_to_canopy_air_kg_m2_s: 0.0001,
        net_longwave_w_m2: 0.0,
        shortwave_absorbed_w_m2: optical.absorbed_w_m2_tile.total(),
        precipitation_advection_w_m2: 0.0,
        carrier_receipt_id: digest('e'),
        snow_vis_albedo: optical.snow_vis_albedo,
        snow_nir_albedo: optical.snow_nir_albedo,
        stage3_albedo_state_sha256: digest('a'),
        forcing_receipt_sha256: digest('b'),
        optical_receipt_sha256: Some(optical.receipt_sha256.clone()),
        reciprocal_longwave_receipt_sha256: None,
        final_canopy_boundary_receipt_sha256: None,
    });
    c.stage3_optical = Some(optical);
    for (t, q) in [(270.0, 0.002), (280.0, 0.006), (273.15, 0.004)] {
        let mut x = initial_trial();
        x[10] = t;
        x[11] = q;
        x[12] = 273.15;
        let actual = crate::evaluate_covered_column(&c, &x, None, None).unwrap();
        // Independent operands and explicit units: kg/m3 * J/kg/K * m/s * K.
        let rho = c.pressure_pa / (287.05 * t);
        let expected_h = rho * 1004.64 * 0.025 * (273.15 - t);
        let expected_v = rho * 0.02 * (0.004 - q);
        assert_eq!(actual.ground_sensible_to_canopy_air_w_m2, expected_h);
        assert_eq!(
            actual.lower_boundary_vapor_to_canopy_air_kg_m2_s,
            expected_v
        );
        let mut perturbed = c.clone();
        let b = perturbed.stage3_lower_boundary.as_mut().unwrap();
        b.sensible_to_canopy_air_w_m2 = -999.0;
        b.vapor_to_canopy_air_kg_m2_s = -0.0002;
        assert_eq!(
            actual,
            crate::evaluate_covered_column(&perturbed, &x, None, None).unwrap()
        );
    }
    let mut initial = initial_trial();
    initial[12] = 273.15;
    let solved = crate::solver::solve_covered_column(&c, None, initial.clone())
        .expect("native coupled nonlinear solution");
    let mut different_guess = c.clone();
    different_guess
        .stage3_lower_boundary
        .as_mut()
        .unwrap()
        .sensible_to_canopy_air_w_m2 = -999.0;
    different_guess
        .stage3_lower_boundary
        .as_mut()
        .unwrap()
        .vapor_to_canopy_air_kg_m2_s = -0.0002;
    assert_eq!(
        solved,
        crate::solver::solve_covered_column(&different_guess, None, initial).unwrap()
    );
    let mut bad = c.clone();
    bad.stage3_lower_boundary
        .as_mut()
        .unwrap()
        .native_snow_exchange = None;
    assert!(crate::evaluate_covered_column(&bad, &initial_trial(), None, None).is_err());
    let mut bad = c.clone();
    bad.stage3_lower_boundary
        .as_mut()
        .unwrap()
        .native_snow_exchange
        .as_mut()
        .unwrap()
        .heat_conductance_m_s *= 2.0;
    assert!(crate::evaluate_covered_column(&bad, &initial_trial(), None, None).is_err());
}

#[test]
#[ignore = "isolated policy14 process and prospective transparent rain identity"]
fn transparent_rain_wet_identity_conserves_incoming_heat() {
    crate::snow_accuracy_policy::Policy::B01.install().unwrap();
    let mut c = column();
    c.top_rain_kg_m2_tile = 2.0;
    let o = &mut c.occupancies[0];
    o.lai = 0.0;
    o.sai = 0.0;
    o.sun.leaf_area_m2_m2_tile = 0.0;
    o.shade.leaf_area_m2_m2_tile = 0.0;
    o.stem_area_m2_m2_tile = 0.0;
    o.beginning_canopy_liquid_kg_m2_tile = 0.0;
    o.sun.absorbed_shortwave_w_m2_tile = 0.0;
    o.shade.absorbed_shortwave_w_m2_tile = 0.0;
    o.stem_absorbed_shortwave_w_m2_tile = 0.0;
    let f = transparent_test_forcing(&c, vec![(2.0, 280.0)]);
    let id = identity(c.interval_s);
    c.bind_transparent_liquid(&f, &id).unwrap();
    // Explicit independently prescribed incoming rain: 2 kg/m² at280 K.
    let mut x = initial_trial();
    x[8] = 300.0;
    let r = crate::evaluate_covered_occupancy_block(
        &c,
        &c.occupancies[0],
        &x[..10],
        300.0,
        0.01,
        [0.0; 4],
    )
    .unwrap();
    assert_eq!(
        r[8], 0.0,
        "transparent numerical coordinate retains canonical anchor; passage temperature is separate"
    );
}

fn transparent_test_forcing(
    c: &CoveredColumnInputs,
    parcels: Vec<(f64, f64)>,
) -> crate::LandSurfaceForcing {
    let id = identity(c.interval_s);
    let mut f = crate::LandSurfaceForcing {
        forcing_sha256: digest('a'),
        transaction_id: id.transaction_id,
        interval_s: c.interval_s,
        air_temperature_k: c.air_temperature_k,
        air_specific_humidity_kg_kg: c.air_specific_humidity_kg_kg,
        air_pressure_pa: c.pressure_pa,
        reference_wind_m_s: c.reference_wind_m_s,
        neutral_stability: true,
        snow_present_at_beginning: false,
        snow_present_at_end: false,
        snow_terminal_payload_present: false,
        direct_vis_w_m2: 0.0,
        diffuse_vis_w_m2: 0.0,
        direct_nir_w_m2: 0.0,
        diffuse_nir_w_m2: 0.0,
        atmospheric_downward_longwave_w_m2: c.atmospheric_downward_longwave_w_m2,
        precipitation_parcels: parcels
            .into_iter()
            .enumerate()
            .map(|(i, (m, t))| crate::LiquidParcel {
                parcel_kind: crate::LiquidParcelKind::Precipitation,
                parcel_id: crate::ParcelId::try_new(format!("rain-{i}")).unwrap(),
                source_owner_id: owner("climate"),
                source_ofe_id: id.ofe_id.clone(),
                source_tile_id: id.tile_id.clone(),
                destination_ofe_id: id.ofe_id.clone(),
                destination_tile_id: id.tile_id.clone(),
                start_s: 0.0,
                end_s: c.interval_s,
                amount_kg_m2_destination_tile_ground: m,
                temperature_provider: crate::LiquidTemperatureProvider::HarderPomeroyHourly,
                temperature_k: (m > 0.0).then_some(t),
                specific_liquid_enthalpy_j_kg: (m > 0.0).then_some(4218.0 * (t - 273.15)),
                source_state_sha256: Some(digest('b')),
            })
            .collect(),
        runon_parcels: vec![],
    };
    f.forcing_sha256 = f.canonical_sha256().unwrap();
    f
}

#[test]
#[ignore = "isolated policy14 transparent source and two-rank full solve"]
fn transparent_liquid_source_poisons_two_ranks_and_solver_parity() {
    crate::snow_accuracy_policy::Policy::B01.install().unwrap();
    let mut c = column();
    c.authority = CoveredColumnAuthority::V10NonpositiveAssimilation;
    c.top_rain_kg_m2_tile = 3.0;
    let mut o = c.occupancies[0].clone();
    o.lai = 0.0;
    o.sai = 0.0;
    o.sun.leaf_area_m2_m2_tile = 0.0;
    o.shade.leaf_area_m2_m2_tile = 0.0;
    o.stem_area_m2_m2_tile = 0.0;
    o.beginning_canopy_liquid_kg_m2_tile = 0.0;
    o.sun.absorbed_shortwave_w_m2_tile = 0.0;
    o.shade.absorbed_shortwave_w_m2_tile = 0.0;
    o.stem_absorbed_shortwave_w_m2_tile = 0.0;
    o.stemflow_fraction = 0.2;
    c.occupancies = vec![o.clone(), o];
    c.occupancies[1].occupancy_id = "canopy-rank-1".into();
    c.occupancies[1].stemflow_fraction = 0.3;
    let ground = crate::partition_ground_shortwave(
        c.ground.terminal_shortwave_w_m2_tile,
        c.ground.surface_vis_albedo,
        c.ground.surface_nir_albedo,
    )
    .unwrap();
    c.shortwave.incident_w_m2_tile = c.ground.terminal_shortwave_w_m2_tile;
    c.shortwave.top_reflected_w_m2_tile = ground.reflected;
    c.shortwave.ground_absorbed_by_incident_w_m2_tile = ground.absorbed;
    c.shortwave.occupancies = c
        .occupancies
        .iter()
        .map(|o| CoveredOccupancyShortwaveInputs {
            occupancy_id: o.occupancy_id.clone(),
            sun_leaf_absorbed_w_m2_tile: BandDirectionalFluxes::default(),
            shade_leaf_absorbed_w_m2_tile: BandDirectionalFluxes::default(),
            stem_absorbed_w_m2_tile: BandDirectionalFluxes::default(),
        })
        .collect();
    let source = transparent_test_forcing(&c, vec![(1.0, 278.15), (2.0, 288.15)]);
    let id = identity(c.interval_s);
    assert!(c.validate_transparent_liquid(Some(&id)).is_err());
    c.bind_transparent_liquid(&source, &id).unwrap();
    c.validate_transparent_liquid(Some(&id)).unwrap();
    let boundary = c.transparent_liquid_boundary.as_ref().unwrap();
    let expected_t = 273.15 + (1.0 * 5.0 + 2.0 * 15.0) / 3.0;
    assert_eq!(c.inactive_component_anchor_k(2, 310.0), 310.0);
    let mut foreign = source.clone();
    foreign.precipitation_parcels[0].source_state_sha256 = Some(digest('c'));
    foreign.forcing_sha256 = foreign.canonical_sha256().unwrap();
    assert!(
        boundary
            .validate_against_actual_forcing(&foreign, &id.ofe_id, &id.tile_id, c.tile_fraction)
            .is_err()
    );
    let mut foreign = transparent_test_forcing(&c, vec![(1.0, 280.15), (2.0, 287.15)]);
    // Same mass and same mixture temperature still has a different actual source.
    assert!(
        boundary
            .validate_against_actual_forcing(&foreign, &id.ofe_id, &id.tile_id, c.tile_fraction)
            .is_err()
    );
    for poison in 0..9 {
        foreign = source.clone();
        match poison {
            0 => foreign.precipitation_parcels[0].temperature_k = None,
            1 => foreign.precipitation_parcels[0].specific_liquid_enthalpy_j_kg = None,
            2 => foreign.precipitation_parcels[0].source_state_sha256 = None,
            3 => foreign.precipitation_parcels[0].end_s = c.interval_s + 60.0,
            4 => foreign
                .precipitation_parcels
                .push(foreign.precipitation_parcels[0].clone()),
            5 => {
                foreign.precipitation_parcels[0].temperature_provider =
                    crate::LiquidTemperatureProvider::AcceptedUpstreamOutletParcel
            }
            6 => foreign.precipitation_parcels[0].specific_liquid_enthalpy_j_kg = Some(42.0),
            7 => foreign.precipitation_parcels[0].amount_kg_m2_destination_tile_ground = 0.0,
            _ => {
                foreign.precipitation_parcels[0].amount_kg_m2_destination_tile_ground =
                    f64::from_bits(1)
            }
        }
        foreign.forcing_sha256 = foreign.canonical_sha256().unwrap();
        assert!(
            crate::TransparentCanopyLiquidBoundaryV1::try_new(
                &foreign,
                &id.ofe_id,
                &id.tile_id,
                c.tile_fraction
            )
            .is_err(),
            "poison{poison}"
        );
    }
    for poison in 0..5 {
        let mut bad = c.clone();
        match poison {
            0 => bad.top_rain_kg_m2_tile = 4.0,
            1 => bad.interval_s += 60.0,
            2 => bad.tile_fraction = 0.5,
            3 => bad.occupancies[1].lai = 1.0,
            _ => bad.occupancies[1].beginning_canopy_liquid_kg_m2_tile = 0.1,
        }
        assert!(
            bad.validate_transparent_liquid(Some(&id)).is_err(),
            "column poison{poison}"
        );
    }
    let mut wrong = id.clone();
    wrong.transaction_id = TransactionId(92);
    assert!(c.validate_transparent_liquid(Some(&wrong)).is_err());
    wrong = id.clone();
    wrong.ofe_id = OfeId::try_new("foreign").unwrap();
    assert!(c.validate_transparent_liquid(Some(&wrong)).is_err());
    wrong = id.clone();
    wrong.tile_id = TileId::try_new("foreign").unwrap();
    assert!(c.validate_transparent_liquid(Some(&wrong)).is_err());
    let mut dry = c.clone();
    dry.top_rain_kg_m2_tile = 0.0;
    dry.transparent_liquid_boundary = None;
    dry.validate_transparent_liquid(Some(&id)).unwrap();
    assert_eq!(dry.inactive_component_anchor_k(2, 300.0), 300.0);
    let mut x = initial_trial()[..10].to_vec();
    x.extend_from_slice(&initial_trial()[..10]);
    x.extend_from_slice(&initial_trial()[10..]);
    // Authentic warm066 zero-area hydraulic beginning, both ranks.
    for base in [0, 10] {
        x[base..base + 4].fill(0.0);
        x[base + 4..base + 6].fill(1.0);
    }
    x[8] = expected_t;
    x[18] = expected_t;
    let detail = crate::evaluate_covered_column(&c, &x, None, None).unwrap();
    let mut outgoing_h = 0.0;
    let mut outgoing_m = 0.0;
    let mut scale = 0.0;
    for (i, o) in detail.occupancies.iter().enumerate() {
        let l = &o.liquid;
        let m = l.stemflow_kg_m2_tile
            + if i + 1 == detail.occupancies.len() {
                l.throughfall_kg_m2_tile
                    + l.initial_drainage_kg_m2_tile
                    + l.second_drainage_kg_m2_tile
            } else {
                0.0
            };
        outgoing_m += m;
        outgoing_h += m * 4218.0 * (l.wet_surface_temperature_k - 273.15);
        scale += m * 4218.0 * (l.wet_surface_temperature_k.abs() + 273.15);
    }
    let incoming_h: f64 = 4218.0 * 35.0;
    scale += 1.0 * 4218.0 * (278.15 + 273.15)
        + 2.0 * 4218.0 * (288.15 + 273.15)
        + incoming_h.abs()
        + outgoing_h.abs();
    let n = 64.0 * (2.0 + 4.0 * 2.0 + 8.0);
    let nu = n * 2.0_f64.powi(-53);
    let bound = nu / (1.0 - nu) * scale;
    assert!((outgoing_h - incoming_h).abs() <= bound);
    assert!((outgoing_m - 3.0).abs() <= 16.0 * f64::EPSILON);
    let mut perturbed = x.clone();
    perturbed[8] += 0.001;
    let p = crate::evaluate_covered_column(&c, &perturbed, None, None).unwrap();
    assert!(((p.raw_residuals[8] - detail.raw_residuals[8]) / 0.001 - 1.0).abs() < 1e-9);
    perturbed = x.clone();
    perturbed[20] += 0.001;
    let p = crate::evaluate_covered_column(&c, &perturbed, None, None).unwrap();
    assert!(((p.raw_residuals[8] - detail.raw_residuals[8]) / 0.001 + 1.0).abs() < 1e-9);
    for guess in [280.0, 305.0] {
        let mut trial = x.clone();
        trial[8] = guess;
        trial[18] = guess;
        trial[20] = guess;
        let ordinary = crate::solve_covered_column(&c, None, trial.clone()).unwrap();
        let crate::CoveredColumnSolveOutcome::Accepted(a) = ordinary else {
            panic!("ordinary solve {ordinary:?}")
        };
        assert!((a.solution[8] - a.solution[20].max(273.15)).abs() < 1e-10);
        assert!((a.solution[18] - a.solution[20].max(273.15)).abs() < 1e-10);
        for o in &a.evaluation.occupancies {
            assert!((o.liquid.wet_surface_temperature_k - expected_t).abs() < 1e-10);
        }
        let native = crate::solve_v3_phase_free_covered_column(
            &c,
            None,
            &trial,
            crate::V3LitterResidualContext {
                configuration: configuration(),
                beginning: litter_beginning(),
                finalized_vapor: None,
            },
        )
        .unwrap();
        let crate::NormalizedSolveOutcome::Accepted {
            solution: native_solution,
            ..
        } = native
        else {
            panic!("native solve {native:?}")
        };
        assert!((native_solution[8] - native_solution[20].max(273.15)).abs() < 1e-10);
        assert!((native_solution[18] - native_solution[20].max(273.15)).abs() < 1e-10);
    }
    eprintln!(
        "transparent independent mass={outgoing_m} energy={outgoing_h} expected={incoming_h} allowance={bound}"
    );
}

#[test]
#[ignore = "isolated policy14 source-bound cold liquid passage"]
fn transparent_cold_source_is_admitted_without_changing_numerical_anchor() {
    crate::snow_accuracy_policy::Policy::B01.install().unwrap();
    let mut c = column();
    c.top_rain_kg_m2_tile = 9.400473273461845e-8;
    for o in &mut c.occupancies {
        o.lai = 0.0;
        o.sai = 0.0;
        o.sun.leaf_area_m2_m2_tile = 0.0;
        o.shade.leaf_area_m2_m2_tile = 0.0;
        o.stem_area_m2_m2_tile = 0.0;
        o.beginning_canopy_liquid_kg_m2_tile = 0.0;
    }
    let f = transparent_test_forcing(&c, vec![(c.top_rain_kg_m2_tile, 265.28179297231515)]);
    let id = identity(c.interval_s);
    c.bind_transparent_liquid(&f, &id).unwrap();
    assert_eq!(c.inactive_component_anchor_k(2, 265.0), 273.15);
    assert_eq!(c.inactive_component_anchor_k(2, 300.0), 300.0);
    for pass in [
        crate::CoveredLiquidPass::Potential,
        crate::CoveredLiquidPass::FixedAuthorizationFinal,
    ] {
        let prep =
            crate::covered_liquid::prepare_covered_liquid(&c.occupancies[0], c.top_rain_kg_m2_tile)
                .unwrap();
        let ledger = crate::covered_liquid::finalize_covered_liquid_for_column(
            &c,
            &c.occupancies[0],
            prep,
            0.0,
            300.0,
            pass,
        )
        .unwrap();
        assert_eq!(ledger.wet_surface_temperature_k, 265.28179297231515);
        c.validate_passage_ledger(&c.occupancies[0], &ledger)
            .unwrap();
        let mut missing = ledger;
        missing.transparent_passage = None;
        assert!(
            c.validate_passage_ledger(&c.occupancies[0], &missing)
                .is_err()
        );
        assert!(
            crate::covered_liquid::finalize_covered_liquid(prep, 0.0, 265.28179297231515, pass)
                .is_err()
        );
    }
}

#[test]
#[ignore = "isolated policy14 validated native configuration transition"]
fn transparent_native_configuration_transition_rebinds_actual_source_and_refuses_foreign_join() {
    crate::snow_accuracy_policy::Policy::B01.install().unwrap();
    let mut c = column();
    c.top_rain_kg_m2_tile = 2.0;
    for o in &mut c.occupancies {
        o.lai = 0.0;
        o.sai = 0.0;
        o.sun.leaf_area_m2_m2_tile = 0.0;
        o.shade.leaf_area_m2_m2_tile = 0.0;
        o.stem_area_m2_m2_tile = 0.0;
        o.beginning_canopy_liquid_kg_m2_tile = 0.0;
    }
    let f = transparent_test_forcing(&c, vec![(2.0, 265.28179297231515)]);
    let old = identity(c.interval_s);
    c.bind_transparent_liquid(&f, &old).unwrap();
    let proof = c.passage_proof(&c.occupancies[0]).unwrap();
    let before = c.clone();
    let mut native = old.clone();
    native.configuration_sha256 = digest('d');
    native.beginning_lse_state_sha256 = digest('e');
    assert!(c.validate_transparent_liquid(Some(&native)).is_err());
    let mut foreign = f.clone();
    foreign.precipitation_parcels[0].source_state_sha256 = Some(digest('c'));
    foreign.forcing_sha256 = foreign.canonical_sha256().unwrap();
    assert!(
        c.rebind_transparent_liquid_native_configuration(&foreign, &old, &native)
            .is_err()
    );
    assert_eq!(c, before);
    let mut wrong = native.clone();
    wrong.transaction_id = TransactionId(old.transaction_id.0 + 1);
    assert!(
        c.rebind_transparent_liquid_native_configuration(&f, &old, &wrong)
            .is_err()
    );
    assert_eq!(c, before);
    c.rebind_transparent_liquid_native_configuration(&f, &old, &native)
        .unwrap();
    c.validate_transparent_liquid(Some(&native)).unwrap();
    assert!(c.validate_transparent_liquid(Some(&old)).is_err());
    assert_ne!(proof, c.passage_proof(&c.occupancies[0]).unwrap());
    c.transparent_liquid_boundary
        .as_ref()
        .unwrap()
        .validate_against_actual_forcing(&f, &native.ofe_id, &native.tile_id, c.tile_fraction)
        .unwrap();
}
