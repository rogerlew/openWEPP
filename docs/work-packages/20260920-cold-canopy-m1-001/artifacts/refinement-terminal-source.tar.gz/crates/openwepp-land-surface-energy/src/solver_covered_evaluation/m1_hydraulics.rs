use super::{
    CoveredColumnInputs, CoveredOccupancyInputs, LandSurfaceEnergyError, M1CoupledError,
    V10LeafGasBranch, evaluate_covered_hydraulics, leaf_hydraulic_coefficient,
    root_hydraulic_coefficient, stem_hydraulic_coefficient,
};

#[derive(Clone, Debug, PartialEq)]
pub struct M1FullSupplyHydraulics {
    pub potentials_mm: [f64; 4],
    pub root_layer_ids: Vec<String>,
    pub root_fluxes_kg_m2_tile_s: Vec<f64>,
    pub stem_flux_kg_m2_tile_s: f64,
    pub continuity_residuals_kg_m2_tile_s: [f64; 4],
}

pub(crate) fn solve_m1_full_supply_hydraulics(
    column: &CoveredColumnInputs,
    occupancy: &CoveredOccupancyInputs,
    demand: [f64; 2],
    branches: [V10LeafGasBranch; 2],
) -> Result<M1FullSupplyHydraulics, M1CoupledError> {
    #[cfg(all(test, feature = "m1-trust-region-physical-stage"))]
    crate::m1_physical_budget_enter(crate::M1PhysicalBudgetOperation::Hydraulic)
        .map_err(M1CoupledError::PhysicalBudget)?;
    super::record_m1_actual_hydraulic_entry();
    if demand.iter().any(|x| !x.is_finite()) || !occupancy.height_m.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    if demand.iter().any(|x| *x < 0.0) || occupancy.height_m <= 0.0 {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
    }
    let leaf_classes = [
        (
            occupancy.sun.leaf_area_m2_m2_tile,
            occupancy.k1_sun_max_s1,
            demand[0],
            branches[0],
        ),
        (
            occupancy.shade.leaf_area_m2_m2_tile,
            occupancy.k1_shade_max_s1,
            demand[1],
            branches[1],
        ),
    ];
    for (area, maximum, leaf_demand, branch) in leaf_classes {
        if !area.is_finite() || !maximum.is_finite() {
            return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
        }
        if area < 0.0 {
            return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
        }
        if area == 0.0 {
            if branch != V10LeafGasBranch::Inactive || leaf_demand != 0.0 {
                return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
            }
        } else if branch != V10LeafGasBranch::ExactZeroPar || maximum <= 0.0 {
            return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
        }
    }
    let mut coefficients = Vec::with_capacity(occupancy.root_layers.len());
    for layer in &occupancy.root_layers {
        if !layer.root_fraction.is_finite() {
            return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
        }
        if layer.root_fraction < 0.0 {
            return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
        }
        if layer.accessible && !layer.frozen && layer.root_fraction > 0.0 {
            if [
                layer.z3_m,
                layer.dxroot_m,
                layer.ksoil_m2_s,
                layer.soil_potential_mm,
                layer.gravity_head_mm,
            ]
            .iter()
            .any(|x| !x.is_finite())
            {
                return Err(
                    openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into(),
                );
            }
            if [layer.z3_m, layer.dxroot_m, layer.ksoil_m2_s]
                .iter()
                .any(|x| *x <= 0.0)
            {
                return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
            }
            let k = root_hydraulic_coefficient(occupancy, layer);
            if !k.is_finite() {
                return Err(
                    openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into(),
                );
            }
            if k <= 0.0 {
                return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
            }
            coefficients.push(Some(k));
        } else {
            coefficients.push(None);
        }
    }
    let total: f64 = coefficients.iter().flatten().sum();
    if !total.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    if total <= 0.0 {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
    }
    let sum_demand = demand[0] + demand[1];
    if !sum_demand.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    let numerator = occupancy
        .root_layers
        .iter()
        .zip(&coefficients)
        .filter_map(|(l, k)| k.map(|value| value * (l.soil_potential_mm + l.gravity_head_mm)))
        .sum::<f64>()
        - sum_demand;
    if !numerator.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    let psi_root = numerator / total;
    if !psi_root.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    let stem_k = stem_hydraulic_coefficient(occupancy, psi_root);
    if !stem_k.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    if stem_k <= 0.0 {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
    }
    let psi_stem = psi_root - 1000.0 * occupancy.height_m - sum_demand / stem_k;
    if !psi_stem.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    let ks = leaf_hydraulic_coefficient(
        occupancy.k1_sun_max_s1,
        occupancy.sun.leaf_area_m2_m2_tile,
        occupancy,
        psi_stem,
    );
    let kh = leaf_hydraulic_coefficient(
        occupancy.k1_shade_max_s1,
        occupancy.shade.leaf_area_m2_m2_tile,
        occupancy,
        psi_stem,
    );
    if !ks.is_finite() || !kh.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    if (occupancy.sun.leaf_area_m2_m2_tile > 0.0 && ks <= 0.0)
        || (occupancy.shade.leaf_area_m2_m2_tile > 0.0 && kh <= 0.0)
    {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::condition_error().into());
    }
    let psi_sun = if ks == 0.0 {
        psi_stem
    } else {
        psi_stem - demand[0] / ks
    };
    let psi_shade = if kh == 0.0 {
        psi_stem
    } else {
        psi_stem - demand[1] / kh
    };
    if [psi_sun, psi_shade, psi_stem, psi_root]
        .iter()
        .any(|x| !x.is_finite())
    {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    let block = [
        psi_sun, psi_shade, psi_stem, psi_root, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0,
    ];
    let checked = evaluate_covered_hydraulics(
        column, None, None, occupancy, &block, demand[0], demand[1], demand[0], demand[1], branches,
    )?;
    if checked
        .residuals
        .iter()
        .zip(checked.tolerances)
        .any(|(r, t)| !r.is_finite() || r.abs() > t)
    {
        return Err(LandSurfaceEnergyError::NumericalAcceptedResidual.into());
    }
    let roots = checked.source_water;
    let stem_flux = stem_k * (psi_root - psi_stem - 1000.0 * occupancy.height_m);
    if !stem_flux.is_finite() {
        return Err(openwepp_vegetation::cold_canopy_m1::M1Error::saturation_error().into());
    }
    Ok(M1FullSupplyHydraulics {
        potentials_mm: [psi_sun, psi_shade, psi_stem, psi_root],
        root_layer_ids: roots.iter().map(|x| x.layer_id.clone()).collect(),
        root_fluxes_kg_m2_tile_s: roots.iter().map(|x| x.final_kg_m2_tile_s).collect(),
        stem_flux_kg_m2_tile_s: stem_flux,
        continuity_residuals_kg_m2_tile_s: [
            -checked.residuals[0],
            -checked.residuals[1],
            checked.residuals[4],
            checked.residuals[5],
        ],
    })
}
