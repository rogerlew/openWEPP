//! Owner-authorized isolated P experiment. No primary-production selector.
use std::cell::Cell;
use std::sync::OnceLock;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Policy {
    R0,
    P1,
    P2,
    P1Step,
    C600,
    C1800,
    B01,
    B1,
    B5,
}
#[derive(Clone, Copy, Debug)]
pub enum Quantity {
    Mass,
    WaterDepth,
    Energy,
    Temperature,
    HeatFlux,
    VaporFlux,
}
static POLICY: OnceLock<Policy> = OnceLock::new();
thread_local! { static SUPPORT_SECONDS: Cell<f64> = const { Cell::new(f64::NAN) }; }

impl Policy {
    /// # Errors
    /// Rejects names outside the frozen experimental ladder.
    pub fn parse(name: &str) -> Result<Self, &'static str> {
        match name {
            "R0" => Ok(Self::R0),
            "P1" => Ok(Self::P1),
            "P2" => Ok(Self::P2),
            "P1_STEP" => Ok(Self::P1Step),
            "C600" => Ok(Self::C600),
            "C1800" => Ok(Self::C1800),
            "B01" => Ok(Self::B01),
            "B1" => Ok(Self::B1),
            "B5" => Ok(Self::B5),
            _ => Err("unknown snow accuracy policy"),
        }
    }
    /// # Errors
    /// Rejects any second startup installation.
    pub fn install(self) -> Result<(), &'static str> {
        POLICY.set(self).map_err(|_| "policy already installed")
    }
    pub fn current() -> Self {
        POLICY.get().copied().unwrap_or(Self::R0)
    }
    #[must_use]
    pub fn coefficients(
        self,
        quantity: Quantity,
        absolute: f64,
        relative: f64,
        seconds: f64,
    ) -> (f64, f64) {
        let (mass, energy, temperature, requested_relative) = match self {
            Self::R0
            | Self::P1Step
            | Self::C600
            | Self::C1800
            | Self::B01
            | Self::B1
            | Self::B5 => {
                return (absolute, relative);
            }
            Self::P1 => (1e-4_f64, 0.1_f64, 0.001_f64, 1e-4_f64),
            Self::P2 => (0.01_f64, 1.0_f64, 0.01_f64, 0.001_f64),
        };
        let requested = match quantity {
            Quantity::Mass => mass,
            Quantity::WaterDepth => mass / 1000.0,
            Quantity::Energy => energy,
            Quantity::Temperature => temperature,
            Quantity::HeatFlux => energy / seconds,
            Quantity::VaporFlux => mass / seconds,
        };
        let rel = if matches!(quantity, Quantity::Temperature) {
            relative
        } else {
            relative.max(requested_relative)
        };
        if !requested.is_finite() || requested < 0.0 {
            return (f64::NAN, f64::NAN);
        }
        (absolute.max(requested), rel)
    }
    #[must_use]
    pub fn endpoint_interval_seconds(self) -> Option<u32> {
        match self {
            Self::C600 => Some(600),
            Self::C1800 => Some(1800),
            _ => None,
        }
    }
    #[must_use]
    pub fn identity(self) -> Option<u8> {
        match self {
            Self::R0 => None,
            Self::P1 => Some(1),
            Self::P2 => Some(2),
            Self::P1Step => Some(8),
            Self::C600 => Some(3),
            Self::C1800 => Some(4),
            Self::B01 => Some(14),
            Self::B1 => Some(6),
            Self::B5 => Some(7),
        }
    }
    #[must_use]
    pub fn bulk_threshold(self) -> Option<f64> {
        match self {
            Self::B01 => Some(0.1),
            Self::B1 => Some(1.0),
            Self::B5 => Some(5.0),
            _ => None,
        }
    }
    #[must_use]
    pub fn temperature_step(self) -> f64 {
        if self == Self::P1Step {
            return 0.001;
        }
        self.coefficients(Quantity::Temperature, 1e-8, 0.0, 1.0).0
    }
}

#[must_use]
pub fn within(left: f64, right: f64, absolute: f64, relative: f64) -> bool {
    let allowance = absolute + relative * left.abs().max(right.abs());
    left.is_finite()
        && right.is_finite()
        && absolute.is_finite()
        && relative.is_finite()
        && absolute >= 0.0
        && relative >= 0.0
        && allowance.is_finite()
        && (left - right).abs() <= allowance
}
pub fn support_seconds() -> f64 {
    SUPPORT_SECONDS.with(Cell::get)
}
pub struct SupportScope(f64);
impl SupportScope {
    /// # Errors
    /// Rejects nonfinite or nonpositive physical support duration.
    pub fn new(seconds: f64) -> Result<Self, &'static str> {
        if !seconds.is_finite() || seconds <= 0.0 {
            return Err("invalid experimental support seconds");
        }
        Ok(Self(SUPPORT_SECONDS.with(|s| s.replace(seconds))))
    }
}
impl Drop for SupportScope {
    fn drop(&mut self) {
        SUPPORT_SECONDS.with(|s| s.set(self.0));
    }
}
#[cfg(test)]
#[path = "snow_accuracy_policy_tests.rs"]
mod tests;
