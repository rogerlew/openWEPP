//! Production-owned, default-off persisted restart V1 implementation.
//!
//! The wire and admission semantics are promoted unchanged from the released
//! authority. This crate owns no selector, publication, output, or production
//! state mutation path; callers receive an isolated restored candidate.

// This module is a byte- and behavior-preserving promotion of the released
// restart authority. Keep its reviewed function shapes and numeric expressions
// stable; these selected pedantic style lints are intentionally not rewritten
// during the authority-to-production move.
#![allow(
    clippy::cast_lossless,
    clippy::cast_precision_loss,
    clippy::cast_sign_loss,
    clippy::implicit_clone,
    clippy::large_enum_variant,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate,
    clippy::needless_pass_by_value,
    clippy::redundant_closure_for_method_calls,
    clippy::ref_option,
    clippy::result_large_err,
    clippy::semicolon_if_nothing_returned,
    clippy::too_many_lines,
    clippy::unreadable_literal
)]

mod canonical;
mod checkpoint;
mod checkpoint_v2;
mod continuation_template;
mod erosion;
#[cfg(feature = "fixtures")]
mod evidence_fixture;
mod frozen_litter_v3_checkpoint;
mod frozen_litter_v3_host;
mod frozen_litter_v3_projection;
mod frozen_litter_v3_scientific_owner;
mod frozen_litter_v4_exact_enthalpy;
mod groundwater;
mod growth_et;
mod gsi_forcing;
mod host;
mod host_v2;
mod hydrology_core;
mod hydrology_restart;
mod primitives;
mod projection;
mod projection_v2;
mod scientific_owners;
mod scientific_owners_v2;
mod snow_stage3_handoff;
mod snow_stage3_v11;
mod snow_stage3_v11_v3;
mod snow_stage3_v11_v4_exact_enthalpy;
mod snow_stage3_v11_v5_snow_enthalpy;
mod soil_thermal_v2;
mod subsurface;
mod surface_liquid;
mod transaction;
mod transaction_v2;
mod transfer;
mod vegetation_v11;
mod vegetation_v11_v3;
mod winter;

pub use canonical::{
    CanonicalJsonError, canonical_sha256, from_canonical_bytes, to_canonical_bytes,
};
pub use checkpoint::{
    CompleteCommittedOwnerStateV1, DirectV10CheckpointPhaseV1, DirectV10RealConsumerCheckpointV1,
    ExpectedRestartStaticContext, IsolatedRestoredCheckpointV1, RestartAdmissionFailureV1,
    RestoredCompleteCommittedOwnerStateV1, RestoredScientificOwnerStateSetV1,
    ScientificOwnerStateSetV1, admit_checkpoint_into_owner_store_v1, admit_checkpoint_v1,
};
pub use checkpoint_v2::*;
pub use continuation_template::*;
pub use erosion::{
    DirectErosionDownstreamRestartV1, DirectErosionInflowIntakeRestartV1,
    DirectErosionRuntimeCarryRestartV1, ErosionRestartError,
};
#[cfg(feature = "fixtures")]
pub use evidence_fixture::*;
pub use frozen_litter_v3_checkpoint::*;
pub use frozen_litter_v3_host::*;
pub use frozen_litter_v3_projection::*;
pub use frozen_litter_v3_scientific_owner::*;
pub use frozen_litter_v4_exact_enthalpy::*;
pub use groundwater::{DirectGroundwaterRunStateRestartV1, GroundwaterRestartError};
pub use growth_et::{
    DirectEvapotranspirationStageRestartV1, DirectGrowthStateSurfaceRestartV1, GrowthEtRestartError,
};
pub use gsi_forcing::{
    DirectGsiDailyReceiptRestartV1, DirectGsiDateRestartV1, DirectGsiOwnerConfigurationRestartV1,
    DirectGsiOwnerStateRestartV1, GsiForcingRestartError, SnowFreeHalfHourDayReceiptRestartV1,
    SnowFreeHalfHourDestinationRestartV1, SnowFreeHalfHourProviderCursorRestartV1,
    SnowFreeHalfHourStaticConfigurationRestartV1, SnowFreePrecipitationParcelRestartV1,
};
pub use host::{
    DirectV10RestartHost, RestartInstallError, admit_and_install_checkpoint_v1,
    install_restored_checkpoint,
};
pub use host_v2::*;
pub use hydrology_core::{DirectHydrologyCoreError, DirectWaterStateRestartV1};
pub use hydrology_restart::{
    DIRECT_HYDROLOGY_EXACT_ENTHALPY_RESTART_V2_SCHEMA, DirectHydrologyExactEnthalpyRestartV2,
    DirectHydrologyNativeCustodyRestartV1, DirectHydrologyRestartV1, DirectLaneRestartV1,
    DirectRuntimePostureV1, ExpectedDirectHydrologyExactEnthalpyRestartContextV2,
    ExpectedDirectHydrologyNativeCustodyContextV1, ExpectedDirectHydrologyRestartContext,
    HydrologyRestartError,
};
pub use primitives::{
    AcceptedIntervalCount, DestinationCount, HexF64, HexU128, InProgressIntervalIndex, LaneCount,
    OptionalLaneLink, Sha256Hex, WireDayIndex, WireIntervalIndex, WireLaneId, WirePrimitiveError,
};
pub use projection::{
    DirectHydrologyExactEnthalpyProjectionInputsV2, checkpoint_identities_v1,
    project_complete_owner_state_v1, project_exact_hydrology_state_v2,
    project_scientific_owner_state_v1,
};
pub use projection_v2::*;
pub use scientific_owners::*;
pub use scientific_owners_v2::*;
pub use snow_stage3_handoff::{SnowStage3HandoffRestartError, SnowStage3HandoffRestartV1};
pub use snow_stage3_v11::{
    DirectSnowStage3V11AttachmentRestartV2, ExpectedSnowStage3V11RestartContext,
    SnowStage3V11RestartError,
};
pub use snow_stage3_v11_v3::*;
pub use snow_stage3_v11_v4_exact_enthalpy::*;
pub use snow_stage3_v11_v5_snow_enthalpy::*;
pub use soil_thermal_v2::*;
pub use subsurface::{DirectSubsurfaceLayerRestartV1, SubsurfaceRestartError};
pub use surface_liquid::{
    DirectSurfaceLiquidConfigurationRestartV1, DirectSurfaceLiquidOwnedStateRestartV1,
    GroundIngressModeWireV1, SurfaceClassWireV1, SurfaceLiquidRestartError, WaterSourceWireV1,
};
pub use transaction::{
    DirectV10ExactEnthalpyCheckpointPhaseV2, DirectV10ExactEnthalpyCheckpointV2,
    DirectV10PreparedDayExactEnthalpyTransactionV2, DirectV10PreparedDayTransactionV1,
    RestartTransactionError,
};
pub use transaction_v2::*;
pub use transfer::{
    DirectLaneTransferLedgerRestartV1, DirectRunTransferDownstreamOperandsRestartV1,
    DirectTransferBuffersRestartV1, TransferRestartError,
};
pub use vegetation_v11::*;
pub use vegetation_v11_v3::*;
pub use winter::{DirectWinterColumnRestartV1, RestoredWinterCompatibility, WinterRestartError};

#[cfg(test)]
mod frozen_litter_v3_tests;
#[cfg(test)]
mod v2_tests;

mod snow_stage3_v11_native_custody;
pub use snow_stage3_v11_native_custody::*;
