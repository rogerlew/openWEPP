use crate::{HexF64, Sha256Hex, WireDayIndex, canonical_sha256};
use openwepp_hillslope_orchestrator::runtime_inputs::{
    DirectGsiDailyReceiptV1, DirectGsiDateV1, DirectGsiForcingV1, DirectGsiOwnerConfigurationV1,
    DirectGsiOwnerStateV1, DirectGsiParametersV1, DirectGsiResultV1, SnowFreeHalfHourDayReceipt,
    SnowFreeHalfHourDestination, SnowFreeHalfHourIntervalReceipt, SnowFreeHalfHourProviderCursor,
    SnowFreeHalfHourStaticConfiguration, SnowFreePrecipitationParcelReceipt,
    SnowFreeSolidPrecipitationParcelReceipt,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use thiserror::Error;

#[derive(Debug, Error, PartialEq, Eq)]
pub enum GsiForcingRestartError {
    #[error("invalid GSI/forcing identity or digest: {0}")]
    Identity(&'static str),
    #[error("invalid GSI/forcing numeric domain: {0}")]
    Domain(&'static str),
    #[error("invalid GSI/forcing cardinality or ordering: {0}")]
    Ordering(&'static str),
    #[error("platform-width value is not representable")]
    Width,
}
fn f(field: &'static str, value: &HexF64) -> Result<f64, GsiForcingRestartError> {
    let value = value.to_f64();
    value
        .is_finite()
        .then_some(value)
        .ok_or(GsiForcingRestartError::Domain(field))
}
fn sha(value: String) -> Result<Sha256Hex, GsiForcingRestartError> {
    Sha256Hex::try_new(value).map_err(|_| GsiForcingRestartError::Identity("sha256"))
}
fn native_sha(value: &Sha256Hex) -> String {
    value.as_str().to_owned()
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SnowFreeHalfHourDestinationRestartV1 {
    pub ofe_id: String,
    pub tile_id: String,
    pub wb14_configuration_sha256: Sha256Hex,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SnowFreeHalfHourStaticConfigurationRestartV1 {
    pub run_id: String,
    pub co2_pa: HexF64,
    pub reference_height_m: HexF64,
    pub gsi_owner_configuration_sha256: Sha256Hex,
    pub destinations: Vec<SnowFreeHalfHourDestinationRestartV1>,
    pub configuration_sha256: Sha256Hex,
}

impl SnowFreeHalfHourStaticConfigurationRestartV1 {
    pub fn project(
        value: &SnowFreeHalfHourStaticConfiguration,
    ) -> Result<Self, GsiForcingRestartError> {
        value
            .validate()
            .map_err(|_| GsiForcingRestartError::Identity("forcing configuration"))?;
        Ok(Self {
            run_id: value.run_id.clone(),
            co2_pa: HexF64::from_f64(value.co2_pa),
            reference_height_m: HexF64::from_f64(value.reference_height_m),
            gsi_owner_configuration_sha256: sha(value.gsi_owner_configuration_sha256.clone())?,
            destinations: value
                .destinations
                .iter()
                .map(|destination| {
                    Ok(SnowFreeHalfHourDestinationRestartV1 {
                        ofe_id: destination.ofe_id.clone(),
                        tile_id: destination.tile_id.clone(),
                        wb14_configuration_sha256: sha(destination
                            .wb14_configuration_sha256
                            .clone())?,
                    })
                })
                .collect::<Result<_, GsiForcingRestartError>>()?,
            configuration_sha256: sha(value.configuration_sha256())?,
        })
    }

    pub fn restore(&self) -> Result<SnowFreeHalfHourStaticConfiguration, GsiForcingRestartError> {
        let value = SnowFreeHalfHourStaticConfiguration {
            run_id: self.run_id.clone(),
            co2_pa: f("forcing.co2_pa", &self.co2_pa)?,
            reference_height_m: f("forcing.reference_height_m", &self.reference_height_m)?,
            gsi_owner_configuration_sha256: native_sha(&self.gsi_owner_configuration_sha256),
            destinations: self
                .destinations
                .iter()
                .map(|destination| SnowFreeHalfHourDestination {
                    ofe_id: destination.ofe_id.clone(),
                    tile_id: destination.tile_id.clone(),
                    wb14_configuration_sha256: native_sha(&destination.wb14_configuration_sha256),
                })
                .collect(),
        };
        value
            .validate()
            .map_err(|_| GsiForcingRestartError::Identity("forcing configuration"))?;
        if value.configuration_sha256() != self.configuration_sha256.as_str() {
            return Err(GsiForcingRestartError::Identity(
                "forcing configuration digest",
            ));
        }
        Ok(value)
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectGsiDateRestartV1 {
    pub year: i32,
    pub ordinal_day: u16,
}
impl DirectGsiDateRestartV1 {
    fn project(v: &DirectGsiDateV1) -> Self {
        Self {
            year: v.year,
            ordinal_day: v.ordinal_day,
        }
    }
    fn restore(&self) -> Result<DirectGsiDateV1, GsiForcingRestartError> {
        if self.ordinal_day == 0 || self.ordinal_day > 366 {
            return Err(GsiForcingRestartError::Domain("gsi.ordinal_day"));
        }
        Ok(DirectGsiDateV1 {
            year: self.year,
            ordinal_day: self.ordinal_day,
        })
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectGsiParametersRestartV1 {
    pub minimum_temperature_inactive_c: HexF64,
    pub minimum_temperature_unconstrained_c: HexF64,
    pub vapor_pressure_deficit_unconstrained_pa: HexF64,
    pub vapor_pressure_deficit_inactive_pa: HexF64,
    pub photoperiod_inactive_hours: HexF64,
    pub photoperiod_unconstrained_hours: HexF64,
}
impl DirectGsiParametersRestartV1 {
    fn project(v: DirectGsiParametersV1) -> Self {
        Self {
            minimum_temperature_inactive_c: HexF64::from_f64(v.minimum_temperature_inactive_c),
            minimum_temperature_unconstrained_c: HexF64::from_f64(
                v.minimum_temperature_unconstrained_c,
            ),
            vapor_pressure_deficit_unconstrained_pa: HexF64::from_f64(
                v.vapor_pressure_deficit_unconstrained_pa,
            ),
            vapor_pressure_deficit_inactive_pa: HexF64::from_f64(
                v.vapor_pressure_deficit_inactive_pa,
            ),
            photoperiod_inactive_hours: HexF64::from_f64(v.photoperiod_inactive_hours),
            photoperiod_unconstrained_hours: HexF64::from_f64(v.photoperiod_unconstrained_hours),
        }
    }
    fn restore(&self) -> Result<DirectGsiParametersV1, GsiForcingRestartError> {
        Ok(DirectGsiParametersV1 {
            minimum_temperature_inactive_c: f(
                "gsi.minimum_temperature_inactive_c",
                &self.minimum_temperature_inactive_c,
            )?,
            minimum_temperature_unconstrained_c: f(
                "gsi.minimum_temperature_unconstrained_c",
                &self.minimum_temperature_unconstrained_c,
            )?,
            vapor_pressure_deficit_unconstrained_pa: f(
                "gsi.vpd_unconstrained_pa",
                &self.vapor_pressure_deficit_unconstrained_pa,
            )?,
            vapor_pressure_deficit_inactive_pa: f(
                "gsi.vpd_inactive_pa",
                &self.vapor_pressure_deficit_inactive_pa,
            )?,
            photoperiod_inactive_hours: f(
                "gsi.photoperiod_inactive_hours",
                &self.photoperiod_inactive_hours,
            )?,
            photoperiod_unconstrained_hours: f(
                "gsi.photoperiod_unconstrained_hours",
                &self.photoperiod_unconstrained_hours,
            )?,
        })
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectGsiOwnerConfigurationRestartV1 {
    pub schema_version: String,
    pub owner_id: String,
    pub parameters: DirectGsiParametersRestartV1,
    pub latitude_degrees: HexF64,
    pub configuration_sha256: Sha256Hex,
}
impl DirectGsiOwnerConfigurationRestartV1 {
    pub fn project(v: &DirectGsiOwnerConfigurationV1) -> Result<Self, GsiForcingRestartError> {
        v.validate()
            .map_err(|_| GsiForcingRestartError::Identity("gsi configuration"))?;
        Ok(Self {
            schema_version: v.schema_version.clone(),
            owner_id: v.owner_id.clone(),
            parameters: DirectGsiParametersRestartV1::project(v.parameters),
            latitude_degrees: HexF64::from_f64(v.latitude_degrees),
            configuration_sha256: sha(v.configuration_sha256.clone())?,
        })
    }
    pub fn restore(&self) -> Result<DirectGsiOwnerConfigurationV1, GsiForcingRestartError> {
        let v = DirectGsiOwnerConfigurationV1 {
            schema_version: self.schema_version.clone(),
            owner_id: self.owner_id.clone(),
            parameters: self.parameters.restore()?,
            latitude_degrees: f("gsi.latitude_degrees", &self.latitude_degrees)?,
            configuration_sha256: native_sha(&self.configuration_sha256),
        };
        v.validate()
            .map_err(|_| GsiForcingRestartError::Identity("gsi configuration"))?;
        Ok(v)
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectGsiOwnerStateRestartV1 {
    pub history_oldest_first: Vec<HexF64>,
    pub last_date: Option<DirectGsiDateRestartV1>,
    pub state_sha256: Sha256Hex,
}
impl DirectGsiOwnerStateRestartV1 {
    pub fn project(v: &DirectGsiOwnerStateV1) -> Result<Self, GsiForcingRestartError> {
        Ok(Self {
            history_oldest_first: v
                .history_oldest_first
                .iter()
                .copied()
                .map(HexF64::from_f64)
                .collect(),
            last_date: v.last_date.as_ref().map(DirectGsiDateRestartV1::project),
            state_sha256: sha(v.state_sha256.clone())?,
        })
    }
    pub fn restore(&self) -> Result<DirectGsiOwnerStateV1, GsiForcingRestartError> {
        if self.history_oldest_first.len() > 21 {
            return Err(GsiForcingRestartError::Ordering("gsi history cardinality"));
        }
        if self.history_oldest_first.is_empty() != self.last_date.is_none() {
            return Err(GsiForcingRestartError::Ordering(
                "gsi history/date equivalence",
            ));
        }
        let v = DirectGsiOwnerStateV1 {
            history_oldest_first: self
                .history_oldest_first
                .iter()
                .map(|x| {
                    let value = f("gsi.history", x)?;
                    if !(0.0..=1.0).contains(&value) {
                        return Err(GsiForcingRestartError::Domain("gsi.history"));
                    }
                    Ok(value)
                })
                .collect::<Result<_, _>>()?,
            last_date: self
                .last_date
                .as_ref()
                .map(DirectGsiDateRestartV1::restore)
                .transpose()?,
            state_sha256: native_sha(&self.state_sha256),
        };
        let mut digest_input = v.clone();
        digest_input.state_sha256.clear();
        let json = serde_json::to_value(&digest_input)
            .map_err(|_| GsiForcingRestartError::Identity("gsi state digest"))?;
        let mut bytes = serde_json::to_vec(&json)
            .map_err(|_| GsiForcingRestartError::Identity("gsi state digest"))?;
        bytes.push(b'\n');
        let computed = format!("{:x}", Sha256::digest(bytes));
        if computed != v.state_sha256 {
            return Err(GsiForcingRestartError::Identity("gsi state digest"));
        }
        openwepp_hillslope_orchestrator::runtime_inputs::restart_authority_restore_gsi_state(&v)
            .map_err(|_| GsiForcingRestartError::Domain("native GSI state"))?;
        Ok(v)
    }

    pub fn seal_wire_digest(&mut self) -> Result<(), GsiForcingRestartError> {
        let value = DirectGsiOwnerStateV1 {
            history_oldest_first: self
                .history_oldest_first
                .iter()
                .map(|value| f("gsi.history", value))
                .collect::<Result<_, _>>()?,
            last_date: self
                .last_date
                .as_ref()
                .map(DirectGsiDateRestartV1::restore)
                .transpose()?,
            state_sha256: String::new(),
        };
        let json = serde_json::to_value(&value)
            .map_err(|_| GsiForcingRestartError::Identity("gsi state digest"))?;
        let mut bytes = serde_json::to_vec(&json)
            .map_err(|_| GsiForcingRestartError::Identity("gsi state digest"))?;
        bytes.push(b'\n');
        self.state_sha256 = sha(format!("{:x}", Sha256::digest(bytes)))?;
        Ok(())
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectGsiForcingRestartV1 {
    pub minimum_temperature_c: HexF64,
    pub vapor_pressure_deficit_pa: HexF64,
    pub latitude_degrees: HexF64,
    pub year: i32,
    pub ordinal_day: u16,
}
impl DirectGsiForcingRestartV1 {
    fn project(v: DirectGsiForcingV1) -> Self {
        Self {
            minimum_temperature_c: HexF64::from_f64(v.minimum_temperature_c),
            vapor_pressure_deficit_pa: HexF64::from_f64(v.vapor_pressure_deficit_pa),
            latitude_degrees: HexF64::from_f64(v.latitude_degrees),
            year: v.year,
            ordinal_day: v.ordinal_day,
        }
    }
    fn restore(&self) -> Result<DirectGsiForcingV1, GsiForcingRestartError> {
        if self.ordinal_day == 0 || self.ordinal_day > 366 {
            return Err(GsiForcingRestartError::Domain("gsi forcing date"));
        }
        Ok(DirectGsiForcingV1 {
            minimum_temperature_c: f("gsi.minimum_temperature_c", &self.minimum_temperature_c)?,
            vapor_pressure_deficit_pa: f("gsi.vpd_pa", &self.vapor_pressure_deficit_pa)?,
            latitude_degrees: f("gsi.latitude", &self.latitude_degrees)?,
            year: self.year,
            ordinal_day: self.ordinal_day,
        })
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectGsiResultRestartV1 {
    pub minimum_temperature_indicator: HexF64,
    pub vapor_pressure_deficit_indicator: HexF64,
    pub photoperiod_indicator: HexF64,
    pub instantaneous_gsi: HexF64,
    pub photoperiod_hours: HexF64,
    pub growing_season_index: HexF64,
    pub sample_count: u32,
}
impl DirectGsiResultRestartV1 {
    fn project(v: DirectGsiResultV1) -> Self {
        Self {
            minimum_temperature_indicator: HexF64::from_f64(v.minimum_temperature_indicator),
            vapor_pressure_deficit_indicator: HexF64::from_f64(v.vapor_pressure_deficit_indicator),
            photoperiod_indicator: HexF64::from_f64(v.photoperiod_indicator),
            instantaneous_gsi: HexF64::from_f64(v.instantaneous_gsi),
            photoperiod_hours: HexF64::from_f64(v.photoperiod_hours),
            growing_season_index: HexF64::from_f64(v.growing_season_index),
            sample_count: v.sample_count,
        }
    }
    fn restore(&self) -> Result<DirectGsiResultV1, GsiForcingRestartError> {
        Ok(DirectGsiResultV1 {
            minimum_temperature_indicator: f(
                "gsi.minimum_temperature_indicator",
                &self.minimum_temperature_indicator,
            )?,
            vapor_pressure_deficit_indicator: f(
                "gsi.vpd_indicator",
                &self.vapor_pressure_deficit_indicator,
            )?,
            photoperiod_indicator: f("gsi.photoperiod_indicator", &self.photoperiod_indicator)?,
            instantaneous_gsi: f("gsi.instantaneous_gsi", &self.instantaneous_gsi)?,
            photoperiod_hours: f("gsi.photoperiod_hours", &self.photoperiod_hours)?,
            growing_season_index: f("gsi.growing_season_index", &self.growing_season_index)?,
            sample_count: self.sample_count,
        })
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DirectGsiDailyReceiptRestartV1 {
    pub schema_version: String,
    pub owner_id: String,
    pub run_id: String,
    pub day_index: WireDayIndex,
    pub source_climate_sha256: Sha256Hex,
    pub beginning_state: DirectGsiOwnerStateRestartV1,
    pub ending_state: DirectGsiOwnerStateRestartV1,
    pub parameters: DirectGsiParametersRestartV1,
    pub forcing: DirectGsiForcingRestartV1,
    pub result: DirectGsiResultRestartV1,
    pub configuration_sha256: Sha256Hex,
    pub beginning_state_sha256: Sha256Hex,
    pub ending_state_sha256: Sha256Hex,
    pub forcing_sha256: Sha256Hex,
    pub result_sha256: Sha256Hex,
    pub receipt_sha256: Sha256Hex,
}
impl DirectGsiDailyReceiptRestartV1 {
    pub fn project(v: &DirectGsiDailyReceiptV1) -> Result<Self, GsiForcingRestartError> {
        v.validate()
            .map_err(|_| GsiForcingRestartError::Identity("gsi receipt"))?;
        Ok(Self {
            schema_version: v.schema_version.clone(),
            owner_id: v.owner_id.clone(),
            run_id: v.run_id.clone(),
            day_index: WireDayIndex(v.day_index),
            source_climate_sha256: sha(v.source_climate_sha256.clone())?,
            beginning_state: DirectGsiOwnerStateRestartV1::project(&v.beginning_state)?,
            ending_state: DirectGsiOwnerStateRestartV1::project(&v.ending_state)?,
            parameters: DirectGsiParametersRestartV1::project(v.parameters),
            forcing: DirectGsiForcingRestartV1::project(v.forcing),
            result: DirectGsiResultRestartV1::project(v.result),
            configuration_sha256: sha(v.configuration_sha256.clone())?,
            beginning_state_sha256: sha(v.beginning_state_sha256.clone())?,
            ending_state_sha256: sha(v.ending_state_sha256.clone())?,
            forcing_sha256: sha(v.forcing_sha256.clone())?,
            result_sha256: sha(v.result_sha256.clone())?,
            receipt_sha256: sha(v.receipt_sha256.clone())?,
        })
    }
    pub fn restore(&self) -> Result<DirectGsiDailyReceiptV1, GsiForcingRestartError> {
        let v = DirectGsiDailyReceiptV1 {
            schema_version: self.schema_version.clone(),
            owner_id: self.owner_id.clone(),
            run_id: self.run_id.clone(),
            day_index: self.day_index.0,
            source_climate_sha256: native_sha(&self.source_climate_sha256),
            beginning_state: self.beginning_state.restore()?,
            ending_state: self.ending_state.restore()?,
            parameters: self.parameters.restore()?,
            forcing: self.forcing.restore()?,
            result: self.result.restore()?,
            configuration_sha256: native_sha(&self.configuration_sha256),
            beginning_state_sha256: native_sha(&self.beginning_state_sha256),
            ending_state_sha256: native_sha(&self.ending_state_sha256),
            forcing_sha256: native_sha(&self.forcing_sha256),
            result_sha256: native_sha(&self.result_sha256),
            receipt_sha256: native_sha(&self.receipt_sha256),
        };
        v.validate()
            .map_err(|_| GsiForcingRestartError::Identity("gsi receipt"))?;
        Ok(v)
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SnowFreePrecipitationParcelRestartV1 {
    pub parcel_id: String,
    pub source_owner_id: String,
    pub destination_ofe_id: String,
    pub destination_tile_id: String,
    pub start_s: HexF64,
    pub end_s: HexF64,
    pub mass_kg_m2: HexF64,
    pub temperature_k: HexF64,
    pub enthalpy_j_m2: HexF64,
}
impl SnowFreePrecipitationParcelRestartV1 {
    fn project(v: &SnowFreePrecipitationParcelReceipt) -> Self {
        Self {
            parcel_id: v.parcel_id.clone(),
            source_owner_id: v.source_owner_id.clone(),
            destination_ofe_id: v.destination_ofe_id.clone(),
            destination_tile_id: v.destination_tile_id.clone(),
            start_s: HexF64::from_f64(v.start_s),
            end_s: HexF64::from_f64(v.end_s),
            mass_kg_m2: HexF64::from_f64(v.mass_kg_m2),
            temperature_k: HexF64::from_f64(v.temperature_k),
            enthalpy_j_m2: HexF64::from_f64(v.enthalpy_j_m2),
        }
    }
    pub fn restore(&self) -> Result<SnowFreePrecipitationParcelReceipt, GsiForcingRestartError> {
        Ok(SnowFreePrecipitationParcelReceipt {
            parcel_id: self.parcel_id.clone(),
            source_owner_id: self.source_owner_id.clone(),
            destination_ofe_id: self.destination_ofe_id.clone(),
            destination_tile_id: self.destination_tile_id.clone(),
            start_s: f("parcel.start_s", &self.start_s)?,
            end_s: f("parcel.end_s", &self.end_s)?,
            mass_kg_m2: f("parcel.mass", &self.mass_kg_m2)?,
            temperature_k: f("parcel.temperature", &self.temperature_k)?,
            enthalpy_j_m2: f("parcel.enthalpy", &self.enthalpy_j_m2)?,
        })
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SnowFreeSolidPrecipitationParcelRestartV1 {
    pub parcel_id: String,
    pub source_owner_id: String,
    pub destination_ofe_id: String,
    pub destination_tile_id: String,
    pub start_s: HexF64,
    pub end_s: HexF64,
    pub mass_kg_m2: HexF64,
    pub temperature_k: HexF64,
    pub enthalpy_j_m2: HexF64,
}

impl SnowFreeSolidPrecipitationParcelRestartV1 {
    fn project(v: &SnowFreeSolidPrecipitationParcelReceipt) -> Self {
        Self {
            parcel_id: v.parcel_id.clone(),
            source_owner_id: v.source_owner_id.clone(),
            destination_ofe_id: v.destination_ofe_id.clone(),
            destination_tile_id: v.destination_tile_id.clone(),
            start_s: HexF64::from_f64(v.start_s),
            end_s: HexF64::from_f64(v.end_s),
            mass_kg_m2: HexF64::from_f64(v.mass_kg_m2),
            temperature_k: HexF64::from_f64(v.temperature_k),
            enthalpy_j_m2: HexF64::from_f64(v.enthalpy_j_m2),
        }
    }

    fn restore(&self) -> Result<SnowFreeSolidPrecipitationParcelReceipt, GsiForcingRestartError> {
        Ok(SnowFreeSolidPrecipitationParcelReceipt {
            parcel_id: self.parcel_id.clone(),
            source_owner_id: self.source_owner_id.clone(),
            destination_ofe_id: self.destination_ofe_id.clone(),
            destination_tile_id: self.destination_tile_id.clone(),
            start_s: f("solid_parcel.start_s", &self.start_s)?,
            end_s: f("solid_parcel.end_s", &self.end_s)?,
            mass_kg_m2: f("solid_parcel.mass", &self.mass_kg_m2)?,
            temperature_k: f("solid_parcel.temperature", &self.temperature_k)?,
            enthalpy_j_m2: f("solid_parcel.enthalpy", &self.enthalpy_j_m2)?,
        })
    }
}

// The interval and day DTOs deliberately name every runtime field. Their
// restoration is admitted only through the runtime day-receipt validator.
#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SnowFreeHalfHourIntervalReceiptRestartV1 {
    pub provider_definition_sha256: Sha256Hex,
    pub source_climate_sha256: Sha256Hex,
    pub run_id: String,
    pub day_index: WireDayIndex,
    pub ofe_id: String,
    pub tile_id: String,
    pub interval_index: u8,
    pub transaction_id: String,
    pub start_s: u32,
    pub end_s: u32,
    pub parent_hour_index: u8,
    pub air_temperature_c: HexF64,
    pub dew_point_c: HexF64,
    pub wind_m_s: HexF64,
    pub pressure_kpa: HexF64,
    pub actual_vapor_pressure_kpa: HexF64,
    pub specific_humidity_kg_kg: HexF64,
    pub vpd_kpa: HexF64,
    pub cloud_fraction: HexF64,
    pub solar_zenith_cosine: HexF64,
    pub global_horizontal_shortwave_w_m2: HexF64,
    pub direct_visible_w_m2: HexF64,
    pub diffuse_visible_w_m2: HexF64,
    pub direct_nir_w_m2: HexF64,
    pub diffuse_nir_w_m2: HexF64,
    pub downward_longwave_w_m2: HexF64,
    pub co2_pa: HexF64,
    pub reference_height_m: HexF64,
    pub gsi: HexF64,
    pub gsi_receipt_sha256: Sha256Hex,
    pub wb14_configuration_sha256: Sha256Hex,
    pub active_precipitation_m: HexF64,
    pub rain_m: HexF64,
    pub snowfall_m: HexF64,
    pub rain_fraction: HexF64,
    pub snow_fraction: HexF64,
    pub hydrometeor_temperature_c: Option<HexF64>,
    pub precipitation_parcels: Vec<SnowFreePrecipitationParcelRestartV1>,
    pub solid_precipitation_parcels: Vec<SnowFreeSolidPrecipitationParcelRestartV1>,
    pub interval_receipt_sha256: Sha256Hex,
}
macro_rules! pf {
    ($v:ident,$n:ident) => {
        HexF64::from_f64($v.$n)
    };
}
impl SnowFreeHalfHourIntervalReceiptRestartV1 {
    fn project(v: &SnowFreeHalfHourIntervalReceipt) -> Result<Self, GsiForcingRestartError> {
        Ok(Self {
            provider_definition_sha256: sha(v.provider_definition_sha256.clone())?,
            source_climate_sha256: sha(v.source_climate_sha256.clone())?,
            run_id: v.run_id.clone(),
            day_index: WireDayIndex(
                u64::try_from(v.day_index).map_err(|_| GsiForcingRestartError::Width)?,
            ),
            ofe_id: v.ofe_id.clone(),
            tile_id: v.tile_id.clone(),
            interval_index: u8::try_from(v.interval_index)
                .map_err(|_| GsiForcingRestartError::Width)?,
            transaction_id: v.transaction_id.clone(),
            start_s: u32::try_from(v.start_s).map_err(|_| GsiForcingRestartError::Width)?,
            end_s: u32::try_from(v.end_s).map_err(|_| GsiForcingRestartError::Width)?,
            parent_hour_index: u8::try_from(v.parent_hour_index)
                .map_err(|_| GsiForcingRestartError::Width)?,
            air_temperature_c: pf!(v, air_temperature_c),
            dew_point_c: pf!(v, dew_point_c),
            wind_m_s: pf!(v, wind_m_s),
            pressure_kpa: pf!(v, pressure_kpa),
            actual_vapor_pressure_kpa: pf!(v, actual_vapor_pressure_kpa),
            specific_humidity_kg_kg: pf!(v, specific_humidity_kg_kg),
            vpd_kpa: pf!(v, vpd_kpa),
            cloud_fraction: pf!(v, cloud_fraction),
            solar_zenith_cosine: pf!(v, solar_zenith_cosine),
            global_horizontal_shortwave_w_m2: pf!(v, global_horizontal_shortwave_w_m2),
            direct_visible_w_m2: pf!(v, direct_visible_w_m2),
            diffuse_visible_w_m2: pf!(v, diffuse_visible_w_m2),
            direct_nir_w_m2: pf!(v, direct_nir_w_m2),
            diffuse_nir_w_m2: pf!(v, diffuse_nir_w_m2),
            downward_longwave_w_m2: pf!(v, downward_longwave_w_m2),
            co2_pa: pf!(v, co2_pa),
            reference_height_m: pf!(v, reference_height_m),
            gsi: pf!(v, gsi),
            gsi_receipt_sha256: sha(v.gsi_receipt_sha256.clone())?,
            wb14_configuration_sha256: sha(v.wb14_configuration_sha256.clone())?,
            active_precipitation_m: pf!(v, active_precipitation_m),
            rain_m: pf!(v, rain_m),
            snowfall_m: pf!(v, snowfall_m),
            rain_fraction: pf!(v, rain_fraction),
            snow_fraction: pf!(v, snow_fraction),
            hydrometeor_temperature_c: v.hydrometeor_temperature_c.map(HexF64::from_f64),
            precipitation_parcels: v
                .precipitation_parcels
                .iter()
                .map(SnowFreePrecipitationParcelRestartV1::project)
                .collect(),
            solid_precipitation_parcels: v
                .solid_precipitation_parcels
                .iter()
                .map(SnowFreeSolidPrecipitationParcelRestartV1::project)
                .collect(),
            interval_receipt_sha256: sha(v.interval_receipt_sha256.clone())?,
        })
    }
    fn restore(&self) -> Result<SnowFreeHalfHourIntervalReceipt, GsiForcingRestartError> {
        Ok(SnowFreeHalfHourIntervalReceipt {
            provider_definition_sha256: native_sha(&self.provider_definition_sha256),
            source_climate_sha256: native_sha(&self.source_climate_sha256),
            run_id: self.run_id.clone(),
            day_index: usize::try_from(self.day_index.0)
                .map_err(|_| GsiForcingRestartError::Width)?,
            ofe_id: self.ofe_id.clone(),
            tile_id: self.tile_id.clone(),
            interval_index: usize::from(self.interval_index),
            transaction_id: self.transaction_id.clone(),
            start_s: self.start_s as usize,
            end_s: self.end_s as usize,
            parent_hour_index: usize::from(self.parent_hour_index),
            air_temperature_c: f("interval.air_temperature_c", &self.air_temperature_c)?,
            dew_point_c: f("interval.dew_point_c", &self.dew_point_c)?,
            wind_m_s: f("interval.wind_m_s", &self.wind_m_s)?,
            pressure_kpa: f("interval.pressure_kpa", &self.pressure_kpa)?,
            actual_vapor_pressure_kpa: f(
                "interval.actual_vapor_pressure_kpa",
                &self.actual_vapor_pressure_kpa,
            )?,
            specific_humidity_kg_kg: f(
                "interval.specific_humidity",
                &self.specific_humidity_kg_kg,
            )?,
            vpd_kpa: f("interval.vpd_kpa", &self.vpd_kpa)?,
            cloud_fraction: f("interval.cloud_fraction", &self.cloud_fraction)?,
            solar_zenith_cosine: f("interval.solar_zenith", &self.solar_zenith_cosine)?,
            global_horizontal_shortwave_w_m2: f(
                "interval.shortwave",
                &self.global_horizontal_shortwave_w_m2,
            )?,
            direct_visible_w_m2: f("interval.direct_visible", &self.direct_visible_w_m2)?,
            diffuse_visible_w_m2: f("interval.diffuse_visible", &self.diffuse_visible_w_m2)?,
            direct_nir_w_m2: f("interval.direct_nir", &self.direct_nir_w_m2)?,
            diffuse_nir_w_m2: f("interval.diffuse_nir", &self.diffuse_nir_w_m2)?,
            downward_longwave_w_m2: f("interval.longwave", &self.downward_longwave_w_m2)?,
            co2_pa: f("interval.co2", &self.co2_pa)?,
            reference_height_m: f("interval.reference_height", &self.reference_height_m)?,
            gsi: f("interval.gsi", &self.gsi)?,
            gsi_receipt_sha256: native_sha(&self.gsi_receipt_sha256),
            wb14_configuration_sha256: native_sha(&self.wb14_configuration_sha256),
            active_precipitation_m: f(
                "interval.active_precipitation_m",
                &self.active_precipitation_m,
            )?,
            rain_m: f("interval.rain_m", &self.rain_m)?,
            snowfall_m: f("interval.snowfall_m", &self.snowfall_m)?,
            rain_fraction: f("interval.rain_fraction", &self.rain_fraction)?,
            snow_fraction: f("interval.snow_fraction", &self.snow_fraction)?,
            hydrometeor_temperature_c: self
                .hydrometeor_temperature_c
                .as_ref()
                .map(|value| f("interval.hydrometeor_temperature_c", value))
                .transpose()?,
            precipitation_parcels: self
                .precipitation_parcels
                .iter()
                .map(SnowFreePrecipitationParcelRestartV1::restore)
                .collect::<Result<_, _>>()?,
            solid_precipitation_parcels: self
                .solid_precipitation_parcels
                .iter()
                .map(SnowFreeSolidPrecipitationParcelRestartV1::restore)
                .collect::<Result<_, _>>()?,
            interval_receipt_sha256: native_sha(&self.interval_receipt_sha256),
        })
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SnowFreeHalfHourDayReceiptRestartV1 {
    pub provider_version: String,
    pub provider_definition_sha256: Sha256Hex,
    pub source_climate_sha256: Sha256Hex,
    pub run_id: String,
    pub day_index: WireDayIndex,
    pub daily_horizontal_energy_mj_m2: HexF64,
    pub intervals: Vec<SnowFreeHalfHourIntervalReceiptRestartV1>,
    pub next_day_precipitation_carry: Vec<SnowFreePrecipitationParcelRestartV1>,
    pub next_day_solid_precipitation_carry: Vec<SnowFreeSolidPrecipitationParcelRestartV1>,
    pub receipt_sha256: Sha256Hex,
}
impl SnowFreeHalfHourDayReceiptRestartV1 {
    pub fn project(v: &SnowFreeHalfHourDayReceipt) -> Result<Self, GsiForcingRestartError> {
        v.validate()
            .map_err(|_| GsiForcingRestartError::Identity("forcing day receipt"))?;
        Ok(Self {
            provider_version: v.provider_version.clone(),
            provider_definition_sha256: sha(v.provider_definition_sha256.clone())?,
            source_climate_sha256: sha(v.source_climate_sha256.clone())?,
            run_id: v.run_id.clone(),
            day_index: WireDayIndex(
                u64::try_from(v.day_index).map_err(|_| GsiForcingRestartError::Width)?,
            ),
            daily_horizontal_energy_mj_m2: HexF64::from_f64(v.daily_horizontal_energy_mj_m2),
            intervals: v
                .intervals
                .iter()
                .map(SnowFreeHalfHourIntervalReceiptRestartV1::project)
                .collect::<Result<_, _>>()?,
            next_day_precipitation_carry: v
                .next_day_precipitation_carry
                .iter()
                .map(SnowFreePrecipitationParcelRestartV1::project)
                .collect(),
            next_day_solid_precipitation_carry: v
                .next_day_solid_precipitation_carry
                .iter()
                .map(SnowFreeSolidPrecipitationParcelRestartV1::project)
                .collect(),
            receipt_sha256: sha(v.receipt_sha256.clone())?,
        })
    }
    pub fn restore(&self) -> Result<SnowFreeHalfHourDayReceipt, GsiForcingRestartError> {
        if self.intervals.len() != 48 {
            return Err(GsiForcingRestartError::Ordering(
                "forcing interval cardinality",
            ));
        }
        let v = SnowFreeHalfHourDayReceipt {
            provider_version: self.provider_version.clone(),
            provider_definition_sha256: native_sha(&self.provider_definition_sha256),
            source_climate_sha256: native_sha(&self.source_climate_sha256),
            run_id: self.run_id.clone(),
            day_index: usize::try_from(self.day_index.0)
                .map_err(|_| GsiForcingRestartError::Width)?,
            daily_horizontal_energy_mj_m2: f("day.energy", &self.daily_horizontal_energy_mj_m2)?,
            intervals: self
                .intervals
                .iter()
                .map(SnowFreeHalfHourIntervalReceiptRestartV1::restore)
                .collect::<Result<_, _>>()?,
            next_day_precipitation_carry: self
                .next_day_precipitation_carry
                .iter()
                .map(SnowFreePrecipitationParcelRestartV1::restore)
                .collect::<Result<_, _>>()?,
            next_day_solid_precipitation_carry: self
                .next_day_solid_precipitation_carry
                .iter()
                .map(SnowFreeSolidPrecipitationParcelRestartV1::restore)
                .collect::<Result<_, _>>()?,
            receipt_sha256: native_sha(&self.receipt_sha256),
        };
        v.validate()
            .map_err(|_| GsiForcingRestartError::Identity("forcing day receipt"))?;
        Ok(v)
    }
}

#[derive(Deserialize, Serialize)]
struct NativeCursorSnapshot {
    next_day_index: usize,
    configuration_sha256: Option<String>,
    pending_carry: Vec<SnowFreePrecipitationParcelReceipt>,
    pending_solid_carry: Vec<SnowFreeSolidPrecipitationParcelReceipt>,
}
#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SnowFreeHalfHourProviderCursorRestartV1 {
    pub next_day_index: WireDayIndex,
    pub static_configuration_sha256: Sha256Hex,
    pub pending_carry: Vec<SnowFreePrecipitationParcelRestartV1>,
    pub pending_solid_carry: Vec<SnowFreeSolidPrecipitationParcelRestartV1>,
    pub cursor_sha256: Sha256Hex,
}
#[derive(Serialize)]
struct CursorDigestInput<'a> {
    next_day_index: &'a WireDayIndex,
    static_configuration_sha256: &'a Sha256Hex,
    pending_carry: &'a [SnowFreePrecipitationParcelRestartV1],
    pending_solid_carry: &'a [SnowFreeSolidPrecipitationParcelRestartV1],
}
impl SnowFreeHalfHourProviderCursorRestartV1 {
    pub fn seal(&mut self) -> Result<(), GsiForcingRestartError> {
        self.cursor_sha256 = sha(canonical_sha256(&CursorDigestInput {
            next_day_index: &self.next_day_index,
            static_configuration_sha256: &self.static_configuration_sha256,
            pending_carry: &self.pending_carry,
            pending_solid_carry: &self.pending_solid_carry,
        })
        .map_err(|_| GsiForcingRestartError::Identity("cursor digest"))?)?;
        Ok(())
    }
    pub fn project(
        v: &SnowFreeHalfHourProviderCursor,
        configuration: &SnowFreeHalfHourStaticConfiguration,
        expected_next_day_index: usize,
    ) -> Result<Self, GsiForcingRestartError> {
        v.validate_for_configuration(configuration, expected_next_day_index)
            .map_err(|_| GsiForcingRestartError::Identity("provider cursor"))?;
        let snapshot: NativeCursorSnapshot = serde_json::from_slice(
            &v.to_json_bytes()
                .map_err(|_| GsiForcingRestartError::Identity("provider cursor"))?,
        )
        .map_err(|_| GsiForcingRestartError::Identity("provider cursor"))?;
        let configuration_sha256 = configuration.configuration_sha256();
        if snapshot
            .configuration_sha256
            .as_deref()
            .is_some_and(|digest| digest != configuration_sha256)
        {
            return Err(GsiForcingRestartError::Identity("cursor configuration"));
        }
        let mut dto = Self {
            next_day_index: WireDayIndex(
                u64::try_from(snapshot.next_day_index)
                    .map_err(|_| GsiForcingRestartError::Width)?,
            ),
            static_configuration_sha256: sha(configuration_sha256.to_owned())?,
            pending_carry: snapshot
                .pending_carry
                .iter()
                .map(SnowFreePrecipitationParcelRestartV1::project)
                .collect(),
            pending_solid_carry: snapshot
                .pending_solid_carry
                .iter()
                .map(SnowFreeSolidPrecipitationParcelRestartV1::project)
                .collect(),
            cursor_sha256: sha("0".repeat(64))?,
        };
        dto.seal()?;
        Ok(dto)
    }
    pub fn restore(
        &self,
        configuration: &SnowFreeHalfHourStaticConfiguration,
        expected_next_day_index: usize,
    ) -> Result<SnowFreeHalfHourProviderCursor, GsiForcingRestartError> {
        let digest = canonical_sha256(&CursorDigestInput {
            next_day_index: &self.next_day_index,
            static_configuration_sha256: &self.static_configuration_sha256,
            pending_carry: &self.pending_carry,
            pending_solid_carry: &self.pending_solid_carry,
        })
        .map_err(|_| GsiForcingRestartError::Identity("cursor digest"))?;
        if digest != self.cursor_sha256.as_str()
            || configuration.configuration_sha256() != self.static_configuration_sha256.as_str()
        {
            return Err(GsiForcingRestartError::Identity(
                "cursor digest/configuration",
            ));
        }
        let snapshot = NativeCursorSnapshot {
            next_day_index: usize::try_from(self.next_day_index.0)
                .map_err(|_| GsiForcingRestartError::Width)?,
            configuration_sha256: Some(native_sha(&self.static_configuration_sha256)),
            pending_carry: self
                .pending_carry
                .iter()
                .map(SnowFreePrecipitationParcelRestartV1::restore)
                .collect::<Result<_, _>>()?,
            pending_solid_carry: self
                .pending_solid_carry
                .iter()
                .map(SnowFreeSolidPrecipitationParcelRestartV1::restore)
                .collect::<Result<_, _>>()?,
        };
        let bytes = serde_json::to_vec(&snapshot)
            .map_err(|_| GsiForcingRestartError::Identity("cursor serialization"))?;
        SnowFreeHalfHourProviderCursor::restore_json(&bytes, configuration, expected_next_day_index)
            .map_err(|_| GsiForcingRestartError::Identity("provider cursor"))
    }
}

#[cfg(test)]
mod static_configuration_restart_tests {
    use super::*;

    fn physical_configuration(ofe_count: usize) -> SnowFreeHalfHourStaticConfiguration {
        SnowFreeHalfHourStaticConfiguration {
            run_id: "restart-scale-proof".to_owned(),
            co2_pa: 42.0,
            reference_height_m: 24.0,
            gsi_owner_configuration_sha256: "a".repeat(64),
            destinations: (1..=ofe_count)
                .map(|lane_id| SnowFreeHalfHourDestination {
                    ofe_id: format!("ofe-{lane_id}"),
                    tile_id: format!("tile-{lane_id}"),
                    wb14_configuration_sha256: format!("{lane_id:064x}"),
                })
                .collect(),
        }
    }

    fn assert_physical_projection_restore(ofe_count: usize) {
        let configuration = physical_configuration(ofe_count);
        let projected = SnowFreeHalfHourStaticConfigurationRestartV1::project(&configuration)
            .expect("project physical topology");
        let restored = projected.restore().expect("restore physical topology");
        assert_eq!(restored, configuration);
    }

    fn assert_rejected_without_mutation(projected: &SnowFreeHalfHourStaticConfigurationRestartV1) {
        let before = projected.clone();
        assert!(projected.restore().is_err());
        assert_eq!(*projected, before);
    }

    #[test]
    fn static_configuration_restart_accepts_one_ofe_physical_order() {
        assert_physical_projection_restore(1);
    }

    #[test]
    fn static_configuration_restart_accepts_nine_ofe_physical_order() {
        assert_physical_projection_restore(9);
    }

    #[test]
    fn static_configuration_restart_accepts_ten_ofe_physical_order() {
        assert_physical_projection_restore(10);
    }

    #[test]
    fn static_configuration_restart_accepts_nineteen_ofe_physical_order() {
        assert_physical_projection_restore(19);
    }

    #[test]
    fn static_configuration_restart_rejects_duplicate_destination_without_mutation() {
        let mut projected =
            SnowFreeHalfHourStaticConfigurationRestartV1::project(&physical_configuration(10))
                .expect("project physical topology");
        projected.destinations[9].ofe_id = projected.destinations[8].ofe_id.clone();
        projected.destinations[9].tile_id = projected.destinations[8].tile_id.clone();
        assert_rejected_without_mutation(&projected);
    }

    #[test]
    fn static_configuration_restart_rejects_omission_with_stale_digest() {
        let mut projected =
            SnowFreeHalfHourStaticConfigurationRestartV1::project(&physical_configuration(10))
                .expect("project physical topology");
        projected.destinations.pop().expect("destination to omit");
        assert_rejected_without_mutation(&projected);
    }

    #[test]
    fn static_configuration_restart_rejects_substitution_with_stale_digest() {
        let mut projected =
            SnowFreeHalfHourStaticConfigurationRestartV1::project(&physical_configuration(10))
                .expect("project physical topology");
        projected.destinations[9].ofe_id = "ofe-foreign".to_owned();
        assert_rejected_without_mutation(&projected);
    }

    #[test]
    fn static_configuration_restart_rejects_reorder_with_stale_digest() {
        let mut projected =
            SnowFreeHalfHourStaticConfigurationRestartV1::project(&physical_configuration(10))
                .expect("project physical topology");
        projected.destinations.swap(8, 9);
        assert_rejected_without_mutation(&projected);
    }

    #[test]
    fn static_configuration_restart_rejects_stale_configuration_digest() {
        let mut projected =
            SnowFreeHalfHourStaticConfigurationRestartV1::project(&physical_configuration(10))
                .expect("project physical topology");
        projected.configuration_sha256 = Sha256Hex::try_new("0".repeat(64)).expect("digest");
        assert_rejected_without_mutation(&projected);
    }

    #[test]
    fn static_configuration_restart_accepts_intentionally_resealed_physical_order() {
        let original =
            SnowFreeHalfHourStaticConfigurationRestartV1::project(&physical_configuration(10))
                .expect("project original topology");
        let mut reordered = physical_configuration(10);
        reordered.destinations.swap(8, 9);
        let resealed = SnowFreeHalfHourStaticConfigurationRestartV1::project(&reordered)
            .expect("project intentionally resealed topology");
        assert_ne!(resealed.configuration_sha256, original.configuration_sha256);
        assert_eq!(
            resealed.restore().expect("restore resealed topology"),
            reordered
        );
    }
}

#[cfg(test)]
mod b01_native_provider_prefix_authentication_tests {
    use super::*;
    use openwepp_hillslope_orchestrator::runtime_inputs::{
        SnowFreeHalfHourForcingError, build_hillslope_climate_runtime_request,
        restart_authority_project_gsi_state, restart_authority_restore_gsi_state,
    };
    use openwepp_input_contract::parsers::climate::{ParserMode, parse_climate_file};

    #[test]
    #[ignore = "requires owner-authorized pinned B01 corpus/provider computation"]
    fn b01_pinned_bootstrap_provider_prefix_retains_receipts_and_keeps_day4_prepared() {
        let seed_path = std::env::var_os("OPENWEPP_B01_PINNED_SEED").expect("bound pinned seed");
        let climate_path =
            std::env::var_os("OPENWEPP_B01_ORIGINAL_CLIMATE").expect("bound original climate");
        let expected_path = std::env::var_os("OPENWEPP_B01_GSI_AUTH_EXPECTED_JSON")
            .expect("bound independently captured GSI expectation");
        let seed: serde_json::Value =
            serde_json::from_slice(&std::fs::read(seed_path).expect("pinned seed bytes"))
                .expect("pinned seed JSON");
        let committed = &seed["checkpoint"]["phase"]["committed"];
        let gsi_configuration: DirectGsiOwnerConfigurationRestartV1 =
            serde_json::from_value(committed["gsi_configuration"].clone())
                .expect("pinned GSI configuration wire");
        let gsi_state: DirectGsiOwnerStateRestartV1 =
            serde_json::from_value(committed["gsi_state"].clone()).expect("pinned GSI state wire");
        let static_configuration: SnowFreeHalfHourStaticConfigurationRestartV1 =
            serde_json::from_value(committed["static_forcing_configuration"].clone())
                .expect("pinned provider configuration wire");
        let cursor: SnowFreeHalfHourProviderCursorRestartV1 =
            serde_json::from_value(committed["provider_cursor"].clone())
                .expect("pinned provider cursor wire");
        let configuration = gsi_configuration.restore().expect("GSI configuration");
        let mut gsi = restart_authority_restore_gsi_state(&gsi_state.restore().expect("GSI state"))
            .expect("native GSI bootstrap");
        let provider_configuration = static_configuration
            .restore()
            .expect("provider configuration");
        assert_eq!(
            provider_configuration.gsi_owner_configuration_sha256,
            configuration.configuration_sha256,
            "pinned provider and GSI configuration join"
        );
        let mut cursor = cursor
            .restore(&provider_configuration, 0)
            .expect("provider cursor");
        let bootstrap_gsi = gsi.clone();
        let bootstrap_cursor = cursor.clone();
        let climate = build_hillslope_climate_runtime_request(
            &parse_climate_file(climate_path, ParserMode::SnowFreeHalfHourProvider)
                .expect("original climate"),
        )
        .expect("climate runtime request");

        let mut committed_preimages = Vec::new();
        for day_index in 0..4 {
            let prepared = climate
                .prepare_snow_free_gsi_day_from_repository(
                    day_index,
                    &provider_configuration,
                    &configuration,
                    &gsi,
                    &cursor,
                )
                .expect("provider prefix preparation");
            committed_preimages.push(prepared.gsi_receipt().clone());
            prepared
                .commit(&mut gsi, &mut cursor)
                .expect("provider prefix commit");
            cursor
                .validate_for_configuration(&provider_configuration, day_index + 1)
                .expect("provider prefix cursor");
        }
        let gsi_after_day3 = gsi.clone();
        let cursor_after_day3 = cursor.clone();
        let prepared_day4 = climate
            .prepare_snow_free_gsi_day_from_repository(
                4,
                &provider_configuration,
                &configuration,
                &gsi,
                &cursor,
            )
            .expect("day4 preparation");
        println!(
            "B01_PROVIDER_PREFIX_PREIMAGES={} B01_PROVIDER_DAY4_PREPARED_PREIMAGE={}",
            serde_json::to_string(&committed_preimages).expect("prefix preimages JSON"),
            serde_json::to_string(prepared_day4.gsi_receipt())
                .expect("prepared day4 preimage JSON"),
        );
        let expected: serde_json::Value =
            serde_json::from_slice(&std::fs::read(expected_path).expect("GSI expectation bytes"))
                .expect("GSI expectation JSON");
        assert_eq!(committed_preimages.len(), 4);
        assert_eq!(
            committed_preimages[3].receipt_sha256,
            expected["captured_gsi_receipt"]
                .as_str()
                .expect("expected committed receipt"),
            "prior committed receipt authentication"
        );
        assert_eq!(
            prepared_day4.gsi_receipt().receipt_sha256,
            expected["prepared_receipt"]["receipt_sha256"]
                .as_str()
                .expect("expected prepared receipt"),
            "current prepared receipt authentication"
        );
        assert_ne!(
            committed_preimages[3].receipt_sha256,
            prepared_day4.gsi_receipt().receipt_sha256,
            "committed and prepared receipt phases must remain distinct"
        );
        let projected_gsi = restart_authority_project_gsi_state(&gsi).expect("projected day3 GSI");
        let expected_history = expected["captured_gsi_state"]["history_oldest_first"]
            .as_array()
            .expect("captured GSI history")
            .iter()
            .map(|value| {
                value["exact_decimal"]
                    .as_str()
                    .expect("captured exact GSI history value")
                    .parse::<f64>()
                    .expect("captured exact GSI history parses")
            })
            .collect::<Vec<_>>();
        let expected_date = &expected["captured_gsi_state"]["last_date"];
        assert_eq!(
            projected_gsi.state_sha256,
            expected["captured_gsi_state"]["state_sha256"]
                .as_str()
                .expect("captured GSI state digest"),
            "generated day3 ending GSI equals captured tuple"
        );
        assert_eq!(
            projected_gsi.history_oldest_first, expected_history,
            "generated day3 GSI history equals captured tuple"
        );
        assert_eq!(
            projected_gsi
                .last_date
                .as_ref()
                .map(|date| (date.year, date.ordinal_day)),
            Some((
                i32::try_from(expected_date["year"].as_i64().expect("captured GSI year"))
                    .expect("captured GSI year fits i32"),
                u16::try_from(
                    expected_date["ordinal_day"]
                        .as_u64()
                        .expect("captured GSI ordinal day")
                )
                .expect("captured GSI ordinal day fits u16"),
            )),
            "generated day3 GSI date equals captured tuple"
        );
        let cursor_json: serde_json::Value =
            serde_json::from_slice(&cursor.to_json_bytes().expect("cursor JSON bytes"))
                .expect("cursor JSON");
        assert_eq!(
            cursor_json,
            expected["provider_cursor"].clone(),
            "full captured cursor tuple"
        );
        assert_eq!(gsi, gsi_after_day3, "preparation does not advance live GSI");
        assert_eq!(
            cursor, cursor_after_day3,
            "preparation does not advance cursor"
        );
        let mut wrong_state = bootstrap_gsi;
        let mut correct_cursor = cursor.clone();
        let prepared = climate
            .prepare_snow_free_gsi_day_from_repository(
                4,
                &provider_configuration,
                &configuration,
                &gsi,
                &cursor,
            )
            .expect("reprepare day4 for state control");
        assert!(matches!(
            prepared.commit(&mut wrong_state, &mut correct_cursor),
            Err(SnowFreeHalfHourForcingError::Identity(
                "GSI/provider atomic commit beginning"
            ))
        ));
        let mut correct_state = gsi.clone();
        let mut wrong_cursor = bootstrap_cursor;
        let prepared = climate
            .prepare_snow_free_gsi_day_from_repository(
                4,
                &provider_configuration,
                &configuration,
                &gsi,
                &cursor,
            )
            .expect("reprepare day4 for cursor control");
        assert!(matches!(
            prepared.commit(&mut correct_state, &mut wrong_cursor),
            Err(SnowFreeHalfHourForcingError::Identity(
                "GSI/provider atomic commit beginning"
            ))
        ));
        let mut wrong_configuration = provider_configuration.clone();
        wrong_configuration.gsi_owner_configuration_sha256 = "0".repeat(64);
        assert!(matches!(
            climate.prepare_snow_free_gsi_day_from_repository(
                4,
                &wrong_configuration,
                &configuration,
                &gsi,
                &cursor,
            ),
            Err(SnowFreeHalfHourForcingError::Identity(_))
        ));
        let mut wrong_phase = prepared_day4.gsi_receipt().clone();
        wrong_phase.receipt_sha256 = committed_preimages[3].receipt_sha256.clone();
        assert!(matches!(
            wrong_phase.validate(),
            Err(openwepp_hillslope_orchestrator::runtime_inputs::SnowFreeHalfHourForcingError::Identity(_))
        ), "a committed receipt cannot be substituted for the prepared receipt phase");
    }
}
