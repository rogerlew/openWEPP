"""Reconstruct inventory mutation coverage from preserved inert-test stderr."""
import ast
import hashlib
import json
from pathlib import Path
import re
import sys

if not __debug__:
    raise SystemExit('Optimized Python is forbidden')
root = Path(__file__).resolve().parent
label = sys.argv[1]
assert label.isalnum()
rows, locators = set(), set()
mutations = 0
parts = []
source = binary = None
for group in range(7):
    receipt = root / 'checks' / f'{label}-controls-{group}.json'
    for index, record in enumerate(json.loads(receipt.read_text())):
        name = record['command'][2].split('::')[-1]
        if not re.fullmatch(r'm1_refinement_inventory_mutation_.*_(positive|zero)_control', name):
            continue
        assert record['exit'] == 0 and record['selected_one_test']
        assert record['physical_invocations'] == 0
        source = source or record['source_before']
        binary = binary or record['binary_sha256']
        assert source == record['source_before'] == record['source_after']
        assert binary == record['binary_sha256']
        raw = receipt.with_name(receipt.stem + f'-{index}.stderr')
        data = raw.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        assert digest == record['stderr_sha256']
        match = re.fullmatch(r'mutation coverage family=([\w-]+) lambda=(\w+) rows=(\d+) locators=(\d+) mutations=(\d+) row_ids=(.*?) locator_ids=(.*)\n', data.decode('utf-8'))
        assert match, name
        row_ids = set(ast.literal_eval(match[6]))
        locator_ids = set(ast.literal_eval(match[7]))
        assert len(row_ids) == int(match[3]) and len(locator_ids) == int(match[4])
        assert int(match[5]) == 68 * len(locator_ids)
        assert not rows.intersection(row_ids) and not locators.intersection(locator_ids)
        rows.update(row_ids)
        locators.update(locator_ids)
        mutations += int(match[5])
        parts.append({'test': name, 'family': match[1], 'lambda': match[2], 'rows': len(row_ids), 'locators': len(locator_ids), 'mutations': int(match[5]), 'raw_stderr': str(raw), 'raw_sha256': digest})
inventory_path = root / 'inventory-approved-discovery.json'
inventory = json.loads(inventory_path.read_text())
expected = {entry['id'] for entry in inventory['entries'] if entry['position'] != 'not-refinement'}
assert rows == expected and len(rows) == 107 and len(parts) == 10
assert len(locators) == 30312 and mutations == 2061216
result = {'evidence_class': 'Ran: independent postprocessing of authenticated inert-test coverage logs; no physical evaluation', 'source_sha256': source, 'binary_sha256': binary, 'inventory_sha256': hashlib.sha256(inventory_path.read_bytes()).hexdigest(), 'partitions': parts, 'row_ids': sorted(rows), 'unique_rows': len(rows), 'unique_locator_alternatives': len(locators), 'field_presence_mutations': mutations, 'physical_invocations': 0}
with (root / 'checks' / f'{label}-coverage.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({key: result[key] for key in ['unique_rows', 'unique_locator_alternatives', 'field_presence_mutations', 'source_sha256']}))
