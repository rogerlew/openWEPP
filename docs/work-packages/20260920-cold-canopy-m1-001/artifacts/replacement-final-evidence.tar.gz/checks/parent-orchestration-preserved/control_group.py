"""Run at most four explicitly whitelisted inert controls per bounded command."""
import ast
import json
from pathlib import Path
import subprocess
import sys
if not __debug__:raise SystemExit('Optimized Python forbidden')
label=sys.argv[1]; group=int(sys.argv[2]); assert label.isalnum()
r=Path('/home/roger/openwepp-experiments/cold-canopy-m1-recovered-terminal-20261004')
tree=ast.parse((r/'run_metadata.py').read_text())
allowed=next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='allowed' for t in node.targets))
names=sorted(name for name in allowed if not name.startswith('m1_refinement_inventory_oracle_'))
assert len(names)==26 and 0<=group<7
selected=names[group*4:(group+1)*4];assert selected
name=f'{label}-controls-{group}'
with (r/'checks'/f'{name}-run.stdout').open('x') as output:
 result=subprocess.run([sys.executable,str(r/'run_metadata.py'),str(r),name,*selected],stdout=output,stderr=subprocess.STDOUT,timeout=125)
print(json.dumps({'label':name,'tests':selected,'runner_exit':result.returncode}))
