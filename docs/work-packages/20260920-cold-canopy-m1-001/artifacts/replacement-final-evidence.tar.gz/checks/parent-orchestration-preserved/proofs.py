"""Parent-only bounded orchestration of existing structural proof helpers."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

if not __debug__:
    raise SystemExit('Optimized Python is forbidden')
label = sys.argv[1]
assert label.isalnum()
root = Path('/home/roger/openwepp-experiments/cold-canopy-m1-recovered-terminal-20261004')
art = Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
spec = importlib.util.spec_from_file_location('custody', art / 'separate-accuracy-source-custody.py')
custody = importlib.util.module_from_spec(spec)
spec.loader.exec_module(custody)
identity = lambda: custody.identity(custody.entries(root / 'source'))
stage1 = root / 'source/crates/openwepp-land-surface-energy/src/m1_trust_region_stage1.rs'
inventory = json.loads((root / 'terminal-inventory.json').read_text())
assert inventory.get('final_source_sha256', inventory['source_sha256']) == hashlib.sha256(stage1.read_bytes()).hexdigest(), 'Parent must independently reconcile and bind inventory first'
outdir = root / 'checks' / f'{label}-proofs'
outdir.mkdir()
receipt = {'evidence_class': 'Ran: offline structural proof helpers only; not scientific completeness or capture approval', 'source_before': identity(), 'started_utc': datetime.now(timezone.utc).isoformat(), 'steps': []}
steps = [
    ('outcome_type_bound.py', [], 'outcome-type-bound-draft.json'),
    ('collection_bounds.py', [], 'collection-bound-draft.json'),
    ('build_schema.py', [], 'schema-draft.json'),
    ('schema_bound.py', [str(root / 'schema-draft.json')], 'schema-bound-draft.json'),
    ('schema_coverage.py', [], 'schema-coverage-draft.json'),
    ('field_table.py', [], 'field-table-draft.json'),
    ('proof_inputs.py', [], 'proof-inputs.json'),
]
try:
    for helper, args, output in steps:
        argv = [sys.executable, str(root / helper), *args]
        with (outdir / f'{helper}.stdout').open('xb') as stdout, (outdir / f'{helper}.stderr').open('xb') as stderr:
            result = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr, timeout=20)
        row = {'argv': argv, 'exit': result.returncode, 'helper_sha256': hashlib.sha256((root / helper).read_bytes()).hexdigest()}
        receipt['steps'].append(row)
        if result.returncode:
            raise RuntimeError(f'{helper}: {result.returncode}')
        if helper == 'schema_bound.py':
            (root / output).write_bytes((outdir / f'{helper}.stdout').read_bytes())
        data = (root / output).read_bytes()
        (outdir / output).write_bytes(data)
        row['output_sha256'] = hashlib.sha256(data).hexdigest()
        print(helper, 'PASS', flush=True)
finally:
    receipt['source_after'] = identity()
    receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (outdir / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['source_unchanged']
