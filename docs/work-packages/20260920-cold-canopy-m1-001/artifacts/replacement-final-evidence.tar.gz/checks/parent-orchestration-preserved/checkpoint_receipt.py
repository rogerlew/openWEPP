"""Index exact-source control receipts; never launches tests or alters source."""
from pathlib import Path
import ast
import hashlib
import json
import re
import sys
if not __debug__: raise SystemExit('Optimized Python forbidden')
label, stem = sys.argv[1:]
assert label.isalnum() and re.fullmatch(r'replacement-[a-z-]+', stem)
r=Path('/home/roger/openwepp-experiments/cold-canopy-m1-recovered-terminal-20261004')
a=Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
allowed=next(ast.literal_eval(n.value) for n in ast.parse((r/'run_metadata.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='allowed' for t in n.targets))
build=json.loads((r/'checks'/f'{label}-no-run.json').read_text())
assert build['exit']==0 and build['source_unchanged']
source=build['source_after']
binary=json.loads((r/'checks'/f'{label}-build-inputs.json').read_text())['binary_sha256']
archive=json.loads((a/f'{stem}-source.json').read_text())
assert archive['source_sha256']==source
labels=[label+'-'+f for f in ['p0','first_residual_h0','first_factor_scratch','second_residual_h1','second_factor_final']]+[f'{label}-controls-{n}' for n in range(7)]
tests={}
for test_label in labels:
 p=r/'checks'/f'{test_label}.json'
 for row in json.loads(p.read_text()):
  assert row['exit']==0 and row['selected_one_test'] and row['physical_invocations']==0
  assert row['source_before']==row['source_after']==source and row['binary_sha256']==binary
  name=row['command'][2].split('::')[-1]
  assert name not in tests
  tests[name]=str(p)
assert set(tests)==allowed
out={'evidence_class':'Ran: all explicitly whitelisted inert controls on exact checkpoint; not final model or capture acceptance','source_sha256':source,'binary_sha256':binary,'tests':tests,'count':len(tests),'run_metadata_sha256':hashlib.sha256((r/'run_metadata.py').read_bytes()).hexdigest(),'index_helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_archive':f'{stem}-source.tar.gz','source_receipt':f'{stem}-source.json','build_receipt':str(r/'checks'/f'{label}-build-inputs.json'),'physical_invocations':0}
p=a/f'{stem}-results.json'
assert not p.exists()
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'count':len(tests),'source':source}))
