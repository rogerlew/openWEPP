"""Parent-only custody and explicit inert family runner after a stable no-run."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

label = sys.argv[1]
assert label.isalnum(), 'Use an alphanumeric unique label'
root = Path('/home/roger/openwepp-experiments/cold-canopy-m1-recovered-terminal-20261004')
source = root / 'source'
deps = Path('/workdir/.cache/openwepp/targets/cold-canopy-m1-replacement/candidate/release/deps')
receipt = root / 'checks' / f'{label}-build-inputs.json'
helper = Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
spec = importlib.util.spec_from_file_location('custody', helper / 'separate-accuracy-source-custody.py')
custody = importlib.util.module_from_spec(spec)
spec.loader.exec_module(custody)
build = json.loads((root / 'checks' / f'{label}-no-run.json').read_text())
assert build['exit'] == 0 and build['source_unchanged']
assert custody.identity(custody.entries(source)) == build['source_after']
inputs = [root / name for name in ['build-env.json', 'tools.json', 'check.py', 'run_metadata.py', 'capture_once.py', 'capture_payload.py', 'protocol-draft.json', 'reconstruct.py', 'inventory-approved-discovery.json']]
inputs += [Path(tool['resolved']) for tool in json.loads((root / 'tools.json').read_text()).values()]
inputs += [source / name for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'flake.nix', 'flake.lock']]
command = [sys.executable, str(helper / 'separate-accuracy-build-custody.py'), 'freeze', str(receipt), '--source', str(source), '--deps', str(deps), '--binary', str(deps / 'openwepp_land_surface_energy-70194d0f8e103327')]
for path in inputs:
    command.extend(['--input', str(path)])
subprocess.run(command, check=True, timeout=10)
(root / 'build-inputs.json').write_bytes(receipt.read_bytes())
for family in ['p0', 'first_residual_h0', 'first_factor_scratch', 'second_residual_h1', 'second_factor_final']:
    name = f'{label}-{family}'
    with (root / 'checks' / f'{name}-run.stdout').open('x') as output:
        result = subprocess.run([sys.executable, str(root / 'run_metadata.py'), str(root), name, f'm1_refinement_inventory_oracle_{family}_control'], stdout=output, stderr=subprocess.STDOUT, timeout=31)
    print(family, result.returncode, flush=True)
