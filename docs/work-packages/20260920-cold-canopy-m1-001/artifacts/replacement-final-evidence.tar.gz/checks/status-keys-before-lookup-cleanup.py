"""Extract finite status-key expansions from the actual serializer helpers."""
import re

def status_keys(text):
 result={}
 for m in re.finditer(r'fn (refinement_capture_(?:status_[a-z_]+|field_status_json(?:_resolved)?))\(',text):
  name=m[1];start=text.index('{',m.end());end=start+1;depth=1
  while depth:
   depth+=(text[end]=='{')-(text[end]=='}');end+=1
  body=text[start:end]
  for pattern in [r'(?:field|put)!\(\s*"([a-z][a-z0-9_]*)"',r'refinement_capture_status_insert\(\s*fields,\s*trace,\s*resolved,\s*"([a-z][a-z0-9_]*)"']:
   for match in re.finditer(pattern,body):
    result.setdefault(match[1],[]).append({'function':name,'line':text[:start+match.start()].count('\n')+1})
  if 'factor_application_snapshot_{ordinal}' in body:
   assert 'for ordinal in 1..=2_u8' in body
   assert 'format!("{prefix}_{suffix}")' in body
   suffixes=re.findall(r'\(\s*"([a-z_]+)",\s*snapshot\.is_some_and',body)
   assert len(suffixes)==5 and len(set(suffixes))==5,suffixes
   for ordinal in (1,2):
    for suffix in suffixes:
     key=f'factor_application_snapshot_{ordinal}_{suffix}'
     result.setdefault(key,[]).append({'function':name,'line':text[:start+body.index('for ordinal')].count('\n')+1,'dynamic_expansion':'ordinal in1..=2 and five actual tuple suffixes'})
 assert result,'No status serializer keys found'
 return result
