"""Run explicitly selected inert metadata controls against an exact-source binary."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path(sys.argv[1]).resolve()
name = sys.argv[2]
tests = sys.argv[3:]
allowed = {
    'm1_refinement_atomic_terminal_inventory_schema_control',
    'm1_refinement_inventory_semantic_groups_control',
    'm1_refinement_inventory_locator_alternatives_control',
    'm1_refinement_factor_output_copy_boundary_control',
    'm1_refinement_inventory_alternative_shape_control',
    'm1_refinement_inventory_locator_semantics_control',
    'm1_refinement_inventory_locator_numeric_domains_control',
    'm1_refinement_mixed_norm_prefix_status_control',
    'm1_refinement_resolved_refusal_comparison_control',
    'm1_refinement_complete_terminal_scalar_and_comparison_control',
    'm1_refinement_complete_zero_lambda_terminal_control',
    'm1_refinement_complete_second_factor_snapshot_control',
    'm1_refinement_inventory_oracle_p0_control',
    'm1_refinement_inventory_oracle_first_residual_h0_control',
    'm1_refinement_inventory_oracle_first_factor_scratch_control',
    'm1_refinement_inventory_oracle_second_residual_h1_control',
    'm1_refinement_inventory_oracle_second_factor_final_control',
    'm1_refinement_inventory_work_cap_control',
    'm1_refinement_inventory_mutation_p0_positive_control',
    'm1_refinement_inventory_mutation_p0_zero_control',
    'm1_refinement_inventory_mutation_first_residual_h0_positive_control',
    'm1_refinement_inventory_mutation_first_residual_h0_zero_control',
    'm1_refinement_inventory_mutation_first_factor_scratch_positive_control',
    'm1_refinement_inventory_mutation_first_factor_scratch_zero_control',
    'm1_refinement_inventory_mutation_second_residual_h1_positive_control',
    'm1_refinement_inventory_mutation_second_residual_h1_zero_control',
    'm1_refinement_inventory_mutation_second_factor_final_positive_control',
    'm1_refinement_inventory_mutation_second_factor_final_zero_control',
    'm1_refinement_inventory_mutation_partition_coverage_control',
    'm1_refinement_inventory_impossible_tuples_control',
}
if not tests or len(set(tests)) != len(tests) or any(test not in allowed for test in tests):
    raise SystemExit('Only explicitly inspected inert metadata controls are permitted')
spec = importlib.util.spec_from_file_location('custody', '/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts/separate-accuracy-source-custody.py')
custody = importlib.util.module_from_spec(spec)
spec.loader.exec_module(custody)
build = json.loads((root / 'build-inputs.json').read_text())
if (root / 'source').resolve() != Path(build['source_root']).resolve():
    raise SystemExit('Source root differs from successful build custody')
binary = Path(build['binary_path'])
if hashlib.sha256(binary.read_bytes()).hexdigest() != build['binary_sha256']:
    raise SystemExit('Binary differs from successful build custody')
for path, digest in build['pins'].items():
    if hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest:
        raise SystemExit(f'Build input drift: {path}')
source_before = custody.identity(custody.entries(root / 'source'))
records = []
for index, test in enumerate(tests):
    now = datetime.datetime.now(datetime.timezone.utc)
    remaining = (datetime.datetime.fromisoformat('2026-10-05T05:14:00+00:00') - now).total_seconds()
    limit = min(30, int(remaining) - 6)
    if limit <= 0:
        raise SystemExit('Readiness reached')
    command = [str(binary), '--exact', 'm1_trust_region_stage1::' + test, '--nocapture', '--test-threads=1']
    output = root / 'checks' / f'{name}-{index}'
    started = time.monotonic()
    with output.with_suffix('.stdout').open('wb') as stdout, output.with_suffix('.stderr').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=root/'source', stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=5)
            code = 'TIMEOUT_GROUP_KILLED'
    stdout = output.with_suffix('.stdout').read_bytes()
    record = {'command': command, 'cwd': str(root/'source'), 'start_utc': now.isoformat(), 'timeout_seconds': limit, 'elapsed_seconds': time.monotonic()-started, 'exit': code, 'selected_one_test': b'running 1 test\n' in stdout and b'running 0 tests' not in stdout, 'source_before': source_before, 'source_after': custody.identity(custody.entries(root/'source')), 'binary_sha256': build['binary_sha256'], 'physical_invocations': 0}
    for suffix in ['stdout', 'stderr']:
        record[suffix+'_sha256'] = hashlib.sha256(output.with_suffix('.'+suffix).read_bytes()).hexdigest()
    records.append(record)
    (root/'checks'/f'{name}.json').write_text(json.dumps(records, indent=2)+'\n')
    print(json.dumps(record), flush=True)
    print(stdout.decode(), flush=True)
    if code != 0 or not record['selected_one_test'] or record['source_after'] != source_before:
        raise SystemExit('Metadata check failed; raw evidence preserved')
