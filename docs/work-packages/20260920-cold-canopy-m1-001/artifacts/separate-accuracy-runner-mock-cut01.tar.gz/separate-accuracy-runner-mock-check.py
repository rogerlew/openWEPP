#!/usr/bin/env python3
"""Nonphysical IPC checks for the separate-accuracy runner.

The test binary is generated in a temporary directory.  It only speaks the
runner's line protocol and returns synthetic JSON arrays; it imports no Rust
code and never opens the real runner state or binary.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / "separate-accuracy-runner.py"
INPUT = ROOT / "separate-accuracy-input-check.json"
MEASURE = ROOT / "separate-accuracy-measurement-draft.json"
TEST = "m1_coupled_tests::m1_separate_accuracy_diagnostic_ipc"
RECEIPT = ROOT / "separate-accuracy-runner-mock-check-receipt.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


FAKE = r'''#!/usr/bin/env python3
import json, os, sys
TEST = "m1_coupled_tests::m1_separate_accuracy_diagnostic_ipc"
mode = os.environ.get("MOCK_MODE", "success")
if "--list" in sys.argv:
    print(TEST)
    raise SystemExit(0)
line = sys.stdin.readline()
if mode == "noframes":
    raise SystemExit(0)
if not line.startswith("RUN_INIT "):
    raise SystemExit(11)
request = json.loads(line[len("RUN_INIT "):])
support = 86400 // request["cadence_seconds"]
if request["case"] == "C_freeze_then_melt_day" and request["cadence_seconds"] > 60:
    support += 1
def marker(value):
    print("M1_SEPARATE_ACCURACY " + json.dumps(value, sort_keys=True), flush=True)
marker({"event":"READY", "pid":os.getpid(), "base_sha256":"4b324b0a9c136f2203e8073ca260db5be9e7dd07722a37aec60f2cd528be2d54", "request":request, "support_count":support})
command = sys.stdin.readline().strip()
if mode == "rust_frame":
    # Model the old Rust endpoint: only a literal command is recognized.
    raise SystemExit(12 if command != "RUN_FRESH_DAYS" else 0)
if mode == "child_exit":
    raise SystemExit(13)
if not command.startswith("RUN_FRESH_DAYS "):
    raise SystemExit(14)
days = int(command.split()[1])
marker({"event":"END", "day_count":days, "support_count":support})
if sys.stdin.readline().strip() != "DUMP":
    raise SystemExit(15)
value = 1 if mode == "different" else 0
payload = [[{"support_id": index, "synthetic":value} for index in range(support)] for _ in range(days)]
marker({"event":"DUMP", "days":payload})
'''


def command(work, *args, mode="success"):
    env = os.environ.copy()
    env["MOCK_MODE"] = mode
    return subprocess.run(
        [sys.executable, str(work / "separate-accuracy-runner.py"), *args],
        cwd=work, text=True, capture_output=True, timeout=20, env=env,
    )


def prepare(measure_mutator=None):
    tmp = tempfile.TemporaryDirectory(prefix="separate-accuracy-runner-mock-")
    work = Path(tmp.name)
    for item in (RUNNER, INPUT, MEASURE):
        shutil.copy2(item, work / item.name)
    if measure_mutator:
        measure = json.loads((work / MEASURE.name).read_text())
        measure_mutator(measure)
        (work / MEASURE.name).write_text(json.dumps(measure, indent=2) + "\n")
    binary = work / "fake-child.py"
    binary.write_text(FAKE)
    binary.chmod(0o755)
    receipt = {
        "input_check_sha256": sha(work / INPUT.name),
        "measurement_sha256": sha(work / MEASURE.name),
        "binary_sha256": sha(binary),
    }
    (work / "separate-accuracy-source-review-approved.json").write_text(json.dumps(receipt))
    return tmp, work, binary


def cell(index=0):
    item = json.loads(MEASURE.read_text())["cell_sequence"][index]
    return json.dumps(item, sort_keys=True, separators=(",", ":"))


def require(condition, name, detail):
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def ready(work):
    result = command(work, "READY")
    require(result.returncode == 0, "READY", result.stderr)


def success_schedule():
    tmp, work, binary = prepare()
    try:
        ready(work)
        first = cell()
        diag = command(work, "RUN_FRESH_DAYS", "--cell", first, "--test-binary", str(binary))
        require(diag.returncode == 0, "diagnostic", diag.stderr)
        for batch in range(6):
            timed = command(work, "RUN_FRESH_DAYS", "--cell", first, "--test-binary", str(binary), "--kind", "timing", "--batch", str(batch))
            require(timed.returncode == 0, f"timing batch {batch}", timed.stderr)
        state = json.loads((work / "separate-accuracy-runner-state.json").read_text())
        results = state["results"]
        require(len(results) == 7, "success result count", len(results))
        require(results[0]["fresh_complete_days"] == 1, "diagnostic day count", results[0])
        require(all(row["fresh_complete_days"] == 4 for row in results[1:]), "timing day count", results[1:])
        return {"result_count": len(results), "physical_seconds": state["physical_seconds"]}
    finally:
        tmp.cleanup()


def expected_failure(name, mode, expected):
    tmp, work, binary = prepare()
    try:
        ready(work)
        result = command(work, "RUN_FRESH_DAYS", "--cell", cell(), "--test-binary", str(binary), mode=mode)
        require(result.returncode != 0 and expected in result.stderr, name, result.stderr)
        state = json.loads((work / "separate-accuracy-runner-state.json").read_text())
        charge = state["failed"][0]["charged_seconds"]
        return {"stderr": result.stderr.strip(), "charged_seconds": charge}
    finally:
        tmp.cleanup()


def digest_mismatch():
    tmp, work, binary = prepare()
    try:
        ready(work)
        diagnostic = command(work, "RUN_FRESH_DAYS", "--cell", cell(), "--test-binary", str(binary))
        require(diagnostic.returncode == 0, "digest diagnostic", diagnostic.stderr)
        timing = command(work, "RUN_FRESH_DAYS", "--cell", cell(), "--test-binary", str(binary), "--kind", "timing", "--batch", "0", mode="different")
        require(timing.returncode != 0 and "timed day digest differs" in timing.stderr, "digest mismatch", timing.stderr)
        return {"stderr": timing.stderr.strip()}
    finally:
        tmp.cleanup()


def order_and_b_eligibility():
    tmp, work, binary = prepare()
    try:
        ready(work)
        out_of_order = command(work, "RUN_FRESH_DAYS", "--cell", cell(1), "--test-binary", str(binary))
        require(out_of_order.returncode != 0 and "next frozen cell_sequence" in out_of_order.stderr, "order", out_of_order.stderr)
        # Simulate completed A diagnostics so B is the next scheduled diagnostic.
        state_path = work / "separate-accuracy-runner-state.json"
        state = json.loads(state_path.read_text())
        for i in range(24):
            item = json.loads(cell(i))
            state.setdefault("results", []).append({"kind":"diagnostic", "cell":item, "key":json.dumps({"cell":item,"kind":"diagnostic","batch":0}, sort_keys=True, separators=(",",":"))})
        state_path.write_text(json.dumps(state))
        b_cell = json.loads(cell(24))
        b_key = json.dumps({"cell":b_cell,"kind":"diagnostic","batch":0}, sort_keys=True, separators=(",",":"))
        state = json.loads(state_path.read_text())
        state["completed"].append(b_key)
        state["results"].append({"kind":"diagnostic", "cell":b_cell, "key":b_key, "day_digests":["synthetic"]})
        state_path.write_text(json.dumps(state))
        b = command(work, "RUN_FRESH_DAYS", "--cell", cell(24), "--test-binary", str(binary), "--kind", "timing", "--batch", "0")
        return {
            "order": out_of_order.stderr.strip(),
            "b_eligibility_rejected": b.returncode != 0 and "B eligibility" in b.stderr,
            "b_returncode": b.returncode,
            "b_stderr": b.stderr.strip(),
        }
    finally:
        tmp.cleanup()


def global_limit():
    tmp, work, binary = prepare(lambda value: value["limits"].__setitem__("all_physical_elapsed_seconds", 0))
    try:
        ready(work)
        result = command(work, "RUN_FRESH_DAYS", "--cell", cell(), "--test-binary", str(binary))
        require(result.returncode != 0 and "physical cap exhausted" in result.stderr, "global cap", result.stderr)
        return {"stderr": result.stderr.strip()}
    finally:
        tmp.cleanup()


def run():
    receipt = {"schema": 1, "evidence_class": "Ran: synthetic fake child only; no Rust/binary/physical execution.", "runner_sha256": sha(RUNNER), "measurement_sha256": sha(MEASURE), "checks": {}}
    try:
        receipt["checks"]["success_1_diagnostic_plus_6x4"] = {"status":"PASS", "detail":success_schedule()}
        receipt["checks"]["old_rust_frame_rejected"] = {"status":"PASS", "detail":expected_failure("frame", "rust_frame", "missing END marker")}
        child = expected_failure("child exit", "child_exit", "missing END marker")
        receipt["checks"]["child_exit_charged"] = {"status":"PASS" if child["charged_seconds"] > 0 else "FAIL", "detail":child}
        receipt["checks"]["no_frames_rejected"] = {"status":"PASS", "detail":expected_failure("noframes", "noframes", "missing READY marker")}
        receipt["checks"]["digest_mismatch_rejected"] = {"status":"PASS", "detail":digest_mismatch()}
        order_b = order_and_b_eligibility()
        receipt["checks"]["order_and_b_eligibility_rejected"] = {
            "status":"PASS" if order_b["b_eligibility_rejected"] else "FAIL",
            "detail":order_b,
        }
        receipt["checks"]["global_limit_rejected"] = {"status":"PASS", "detail":global_limit()}
        receipt["status"] = "PASS" if all(value["status"] == "PASS" for value in receipt["checks"].values()) else "FAIL"
    except Exception as error:
        receipt["status"] = "FAIL"
        receipt["error"] = str(error)
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--write-receipt", action="store_true")
    args = parser.parse_args()
    output = run()
    if args.write_receipt:
        RECEIPT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps(output, indent=2, sort_keys=True))
    raise SystemExit(0 if output["status"] == "PASS" else 1)
