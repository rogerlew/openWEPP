#!/usr/bin/env python3
"""Fail-closed, one-fresh-day runner for the frozen Rust IPC harness."""
import argparse, calendar, hashlib, json, os, selectors, subprocess, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent; INPUT=ROOT/'separate-accuracy-input-check.json'; MEASURE=ROOT/'separate-accuracy-measurement-draft.json'; STATE=ROOT/'separate-accuracy-runner-state.json'; RECEIPT=ROOT/'separate-accuracy-source-review-approved.json'
TEST='m1_coupled_tests::m1_separate_accuracy_diagnostic_ipc'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
def save(x): STATE.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def state(): return load(STATE) if STATE.exists() else {'phase':'NEW','physical_seconds':0.0,'completed':[],'failed':[]}
def frozen():
 i=load(INPUT);return {'input_check_sha256':sha(INPUT),'manifest_sha256':i['manifest_sha256'],'base_sha256':i['base_sha256'],'forcing_sha256':i['forcing_sha256'],'measurement_sha256':sha(MEASURE)}
def cell(s):
 x=json.loads(s); need={'case','formulation','profile','cadence_seconds'}
 if set(x)<need: raise SystemExit('cell missing '+repr(sorted(need-set(x))))
 if x.get('stability_variant','ordinary')=='strict_reference' and x['profile']!='P0': raise SystemExit('strict_reference requires P0')
 if x['cadence_seconds'] not in (60,300,900,1800): raise SystemExit('unauthorized cadence')
 return x
def marker(line):
 prefix='M1_SEPARATE_ACCURACY '
 return json.loads(line[len(prefix):]) if line.startswith(prefix) else None
def authenticate(binary):
 if not RECEIPT.exists(): raise SystemExit('physical execution blocked: reviewed source-freeze receipt absent')
 receipt=load(RECEIPT)
 required={'input_check_sha256':sha(INPUT),'binary_sha256':sha(binary),'measurement_sha256':sha(MEASURE)}
 for name,value in required.items():
  if receipt.get(name) != value: raise SystemExit('receipt '+name+' mismatch')
 if receipt.get('input_check_sha256') != sha(INPUT): raise SystemExit('receipt input hash mismatch')
 if receipt.get('binary_sha256') != sha(binary): raise SystemExit('receipt binary hash mismatch')
 listed=subprocess.run([str(binary),'--list'],text=True,capture_output=True,check=False)
 if listed.returncode or TEST not in listed.stdout: raise SystemExit('frozen binary lacks fully-qualified diagnostic IPC test')
def read_marker(proc, deadline, wanted):
 sel=selectors.DefaultSelector(); sel.register(proc.stdout,selectors.EVENT_READ)
 while time.monotonic()<deadline:
  events=sel.select(max(0.0,deadline-time.monotonic()))
  if not events: break
  line=proc.stdout.readline()
  if not line: break
  event=marker(line.rstrip('\n'))
  if event and event.get('event')==wanted: return event
 raise RuntimeError(f'missing {wanted} marker')
def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'))
def campaign(measure): return measure['cell_sequence']
def completed_result(cur,key):
 for result in cur.get('results',[]):
  if result['key']==key:return result
 return None
def enforce_campaign(cur, request, kind, batch, measure):
 cells=campaign(measure); requested={k:request[k] for k in ('investigation','case','formulation','profile','cadence_seconds') if k in request}
 if kind=='diagnostic':
  index=sum(1 for item in cur.get('results',[]) if item['kind']=='diagnostic')
  if index>=len(cells) or requested!=cells[index]: raise SystemExit('launch is not the next frozen cell_sequence diagnostic')
 if kind=='timing':
  diag_key=canonical({'cell':request,'kind':'diagnostic','batch':0})
  if completed_result(cur,diag_key) is None: raise SystemExit('timing requires completed frozen diagnostic')
  if request['investigation']=='B':
   reduced60={**request,'cadence_seconds':60}
   eligible=any(r['kind']=='diagnostic' and r['cell']==reduced60 for r in cur.get('results',[]))
   if not eligible: raise SystemExit('B eligibility requires completed reduced-60 diagnostic')
def run(cur, raw, binary, kind, batch):
 if cur['phase']!='READY': raise SystemExit('RUN_FRESH_DAYS requires READY')
 if kind == 'timing' and not 0 <= batch < 6: raise SystemExit('timing batch must be 0..5')
 if kind == 'diagnostic' and batch != 0: raise SystemExit('diagnostic batch must be 0')
 if kind not in ('diagnostic','timing'): raise SystemExit('unsupported physical kind')
 measure=load(MEASURE); x=cell(raw); enforce_campaign(cur,x,kind,batch,measure); key=canonical({'cell':x,'kind':kind,'batch':batch})
 if kind == 'timing':
  diagnostic=json.dumps({'cell':x,'kind':'diagnostic','batch':0},sort_keys=True,separators=(',',':'))
  prior=json.dumps({'cell':x,'kind':'timing','batch':batch-1},sort_keys=True,separators=(',',':')) if batch else diagnostic
  if prior not in cur['completed']: raise SystemExit('timing requires completed diagnostic then prior consecutive batch')
 if key in cur['completed'] or any(v['key']==key for v in cur['failed']): raise SystemExit('no retry: cell/replicate already terminal')
 authenticate(binary); limits=load(MEASURE)['limits']; now=time.time()
 # Fixed UTC cutoff is read from frozen protocol; deny launch after it.
 cutoff='2026-10-01T00:18:00Z'
 if now>=calendar.timegm(time.strptime(cutoff,'%Y-%m-%dT%H:%M:%SZ')): raise SystemExit('frozen work cutoff reached')
 cell_used=sum(r.get('charged_elapsed_seconds',0.0) for r in cur.get('results',[]) if r.get('cell')==x)
 cap=min(float(limits['candidate_cell_elapsed_seconds'])-cell_used,float(limits['command_seconds']),float(limits['all_physical_elapsed_seconds'])-cur['physical_seconds'])
 launch_ns=time.monotonic_ns()
 if cap<=0: raise SystemExit('physical cap exhausted')
 proc=subprocess.Popen([str(binary),TEST,'--exact','--ignored','--nocapture'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
 try:
  proc.stdin.write('RUN_INIT '+json.dumps(x,sort_keys=True,separators=(',',':'))+'\n');proc.stdin.flush()
  ready=read_marker(proc,time.monotonic()+cap,'READY')
  if ready.get('pid') != proc.pid or ready.get('base_sha256') != frozen()['base_sha256']: raise RuntimeError('READY PID/base identity mismatch')
  expected=86400//x['cadence_seconds']
  if x['case']=='C_freeze_then_melt_day' and x['cadence_seconds']>60: expected+=1
  if ready.get('request')!=x or ready.get('support_count')!=expected: raise RuntimeError('READY authentication/support count mismatch')
  # Linux MAKE_PROCESS_CPUCLOCK(pid, CPUCLOCK_SCHED), matching the frozen timing driver.
  clock_id=((~proc.pid)<<3)|2
  cpu0=time.clock_gettime_ns(clock_id); wall0=time.perf_counter_ns()
  fresh_days=1 if kind == 'diagnostic' else 4
  proc.stdin.write(f'RUN_FRESH_DAYS {fresh_days}\n');proc.stdin.flush()
  end=read_marker(proc,time.monotonic()+max(0.0,cap-(time.monotonic_ns()-launch_ns)/1_000_000_000),'END'); wall1=time.perf_counter_ns(); cpu1=time.clock_gettime_ns(clock_id)
  if cpu1 < cpu0 or wall1 < wall0: raise RuntimeError('nonmonotonic child CPU/wall clock')
  wall=(wall1-wall0)/1_000_000_000; cpu=(cpu1-cpu0)/1_000_000_000
  if end.get('day_count')!=fresh_days or end.get('support_count')!=expected: raise RuntimeError('END day/support count mismatch')
  proc.stdin.write('DUMP\n');proc.stdin.flush(); dumped=read_marker(proc,time.monotonic()+max(0.0,cap-(time.monotonic_ns()-launch_ns)/1_000_000_000),'DUMP')
  proc.stdin.close(); rc=proc.wait(timeout=15); stderr=proc.stderr.read()
  if rc: raise RuntimeError(f'IPC child exit {rc}: {stderr}')
  days=dumped.get('days');
  if not isinstance(days,list) or len(days)!=fresh_days or any(not isinstance(day,list) or len(day)!=expected for day in days): raise RuntimeError('DUMP day payload mismatch')
  day_digests=[hashlib.sha256(canonical(day).encode()).hexdigest() for day in days]
  digest=hashlib.sha256(canonical(days).encode()).hexdigest()
  if kind == 'timing':
   diagnostic=completed_result(cur,canonical({'cell':x,'kind':'diagnostic','batch':0}))
   if diagnostic is None or any(value != diagnostic['day_digests'][0] for value in day_digests): raise RuntimeError('timed day digest differs from diagnostic')
  charge=(time.monotonic_ns()-launch_ns)/1_000_000_000
  result={'key':key,'cell':x,'kind':kind,'batch':batch,'fresh_complete_days':fresh_days,'sample_wall_seconds':wall,'charged_elapsed_seconds':charge,'child_process_cpu_seconds':cpu,'cpu_clock_id':clock_id,'digest':digest,'day_digests':day_digests,'binary_sha256':sha(binary),'days':days}
  if charge > cap: raise RuntimeError('launch-through-evidence cap exceeded')
  cur['physical_seconds']+=charge;cur['completed'].append(key);cur.setdefault('results',[]).append(result);save(cur);print(json.dumps(result,sort_keys=True))
 except Exception as e:
  proc.kill(); proc.wait(); elapsed=(time.monotonic_ns()-launch_ns)/1_000_000_000;cur['physical_seconds']+=elapsed;cur['failed'].append({'key':key,'error':str(e),'charged_seconds':elapsed});save(cur);raise SystemExit(str(e))
def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['READY','RUN_FRESH_DAYS','END','DUMP']);p.add_argument('--cell');p.add_argument('--test-binary',type=Path);p.add_argument('--kind',choices=['diagnostic','timing'],default='diagnostic');p.add_argument('--batch',type=int,default=0);a=p.parse_args();cur=state()
 if a.command=='READY':
  if cur['phase'] not in ('NEW','READY'):raise SystemExit('READY only from NEW/READY')
  cur.update({'phase':'READY','frozen_inputs':frozen()});save(cur);print(json.dumps(cur,sort_keys=True))
 elif a.command=='RUN_FRESH_DAYS':
  if not a.cell or not a.test_binary:raise SystemExit('RUN_FRESH_DAYS requires --cell and --test-binary')
  run(cur,a.cell,a.test_binary,a.kind,a.batch)
 elif a.command=='END':
  if cur['phase']!='READY':raise SystemExit('END requires READY')
  cur['phase']='END';save(cur);print(json.dumps(cur,sort_keys=True))
 else: print(json.dumps({'state':cur,'frozen_inputs':frozen()},indent=2,sort_keys=True))
if __name__=='__main__':main()
