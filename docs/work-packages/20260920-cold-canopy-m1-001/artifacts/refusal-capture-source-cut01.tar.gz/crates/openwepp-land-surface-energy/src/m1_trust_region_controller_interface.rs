//! Private 21-coordinate operand boundary for the deferred Stage 2 controller.

pub(crate) const M1_TRUST_REGION_CONTROLLER_DIMENSION: usize = 21;
pub(crate) const M1_TRUST_REGION_CORE_ENTRY_CAP: u16 = 6_500;
pub(crate) const M1_GOVERNED_STEP_NORMS: usize = 4;

#[cfg(all(
    test,
    any(
        feature = "m1-trust-region-controller-stage",
        feature = "m1-trust-region-analytic-stage"
    )
))]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum M1TrustRegionWitnessPath {
    InstalledRoot,
    FullNoUpdate,
    FirstValidReplacement,
}

/// Test-only projection of analytic shared-controller runs.  It reports
/// controller-produced operands and refusal results; it is not a physical
/// adapter success claim.
#[cfg(all(
    test,
    any(
        feature = "m1-trust-region-controller-stage",
        feature = "m1-trust-region-analytic-stage"
    )
))]
#[derive(Clone, Debug)]
pub(crate) struct M1TrustRegionWitnessThresholds {
    pub(crate) base_raw_residuals: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) base_dynamic_normalizers: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) candidate_raw_residuals: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) candidate_dynamic_normalizers: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) governed_norms: [f64; M1_GOVERNED_STEP_NORMS],
    pub(crate) raw_refusal_messages: Vec<&'static str>,
    pub(crate) normalizer_refusal_messages: Vec<&'static str>,
    pub(crate) governed_refusal_messages: Vec<&'static str>,
    pub(crate) finite_boundary_admissions: u16,
    pub(crate) finite_boundary_refusals: u16,
    pub(crate) proposal_dispositions: Vec<M1TrustRegionProposalDisposition>,
    pub(crate) initial_coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) final_coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) materialized_coordinates: Option<[f64; M1_TRUST_REGION_CONTROLLER_DIMENSION]>,
    pub(crate) refusal_initial_coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) refusal_final_coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
}
#[cfg(all(
    test,
    any(
        feature = "m1-trust-region-controller-stage",
        feature = "m1-trust-region-analytic-stage"
    )
))]
#[derive(Clone, Debug)]
pub(crate) struct M1TrustRegionRadiusExhaustionObservation {
    pub(crate) kind: super::M1TrustRegionRefusalKind,
    pub(crate) radius_before: Vec<f64>,
    pub(crate) radius_after: Vec<f64>,
    pub(crate) final_coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) retained_coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) owner_sentinel_before: u64,
    pub(crate) owner_sentinel_after: u64,
}

/// Current-base hydraulics are deferred until the selected tangent and its
/// representable probe have completed. Candidate evaluations are complete.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub(crate) enum M1TrustRegionCurrentHydraulics {
    #[default]
    Pending,
    Complete([f64; 8]),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum M1TrustRegionProposalDisposition {
    AcceptedUpdate,
    MeritRejectedAndShrunk,
    NoPredictedReductionAndShrunk,
    RootAdmitted,
}

#[derive(Clone, Debug)]
pub(crate) struct M1TrustRegionControllerEvaluation<P> {
    pub(super) coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(super) raw_residual: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(super) dynamic_normalizers: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    // Complete governed-step operands are visible to the generic controller;
    // `payload` remains adapter-owned materialization state.
    pub(super) wet_temperature_k: [Option<f64>; 2],
    pub(super) current_hydraulics: M1TrustRegionCurrentHydraulics,
    pub(super) beta: [f64; 4],
    pub(super) ci_pa: [f64; 4],
    pub(super) payload: P,
}

/// Supplies inputs and owning failures; the controller alone selects transitions.
pub(crate) trait M1TrustRegionControllerEvaluator {
    type Error;
    type Payload: Clone;
    type Phase: Clone + PartialEq;
    fn initial_coordinates(&self) -> [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION];
    fn coordinate_scales(&self) -> [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION];
    fn coordinate_bounds(&self) -> [[f64; M1_TRUST_REGION_CONTROLLER_DIMENSION]; 2];
    fn evaluate(
        &mut self,
        coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    ) -> Result<M1TrustRegionControllerEvaluation<Self::Payload>, Self::Error>;
    fn pre_evaluator_trial_domain(
        &mut self,
        coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    ) -> Result<bool, Self::Error>;
    fn raw_jacobian(
        &mut self,
        current: &M1TrustRegionControllerEvaluation<Self::Payload>,
        selected_phase: Option<&Self::Phase>,
        predictor_direction: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    ) -> Result<
        [[f64; M1_TRUST_REGION_CONTROLLER_DIMENSION]; M1_TRUST_REGION_CONTROLLER_DIMENSION],
        Self::Error,
    >;
    /// Governs only root and witness admission.  Ordinary trust-region
    /// installation and radius updates deliberately retain their controller
    /// semantics; experiment profiles may replace these finite thresholds.
    fn governed_step_components_pass(
        &self,
        temperature_k: f64,
        humidity_kg_kg: f64,
        hydraulic_mm: f64,
        beta: f64,
        ci_pa: &[f64],
    ) -> bool {
        crate::solver::m1_governed_step_components_pass_for_trust_region(
            temperature_k,
            humidity_kg_kg,
            hydraulic_mm,
            beta,
            ci_pa,
        )
    }
    /// Representation adapters may carry a reconstructed physical humidity
    /// while the controller owns a fixed logical coordinate.
    fn governed_humidity_delta(
        &self,
        current: &M1TrustRegionControllerEvaluation<Self::Payload>,
        candidate: &M1TrustRegionControllerEvaluation<Self::Payload>,
    ) -> f64 {
        (candidate.coordinates[13] - current.coordinates[13]).abs()
    }
    #[cfg(test)]
    fn governed_step_thresholds(&self) -> [f64; 4] {
        crate::solver::m1_governed_step_thresholds_for_trust_region()
    }
    /// Optional test-only semantic ownership for BVLS-05.  Analytic
    /// evaluators retain the default-empty route.
    #[cfg(test)]
    fn bvls05_provenance(
        &self,
        _current: &M1TrustRegionControllerEvaluation<Self::Payload>,
    ) -> Option<crate::M1TrustRegionBvls05TestProvenance> {
        None
    }
    /// Completes only a pending current base after selected-tangent work and
    /// before prediction/trial admission. Analytic fixtures are already
    /// complete and leave this unchanged.
    fn complete_current_hydraulics(
        &mut self,
        current: &mut M1TrustRegionControllerEvaluation<Self::Payload>,
    ) -> Result<(), Self::Error>;
    /// Resets an installed non-root base only after post-update admission has
    /// declined it. The next selected tangent must then complete its base
    /// exactly once; complete candidates remain usable by post-update checks.
    fn reset_current_hydraulics_after_nonroot_post_update(
        &mut self,
        current: &mut M1TrustRegionControllerEvaluation<Self::Payload>,
    );
    fn select_phase(
        &mut self,
        current: &M1TrustRegionControllerEvaluation<Self::Payload>,
        physical_direction: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    ) -> Result<Self::Phase, Self::Error>;
    /// Constructs the adapter-owned failure for a disagreement between the
    /// selected predictor tangent and the final re-solved tangent.
    fn phase_active_set_inconsistent(
        &mut self,
        current: &M1TrustRegionControllerEvaluation<Self::Payload>,
        selected_phase: &Self::Phase,
        final_phase: &Self::Phase,
    ) -> Self::Error;
    fn selected_side_probe(
        &mut self,
        current: &M1TrustRegionControllerEvaluation<Self::Payload>,
        phase: &Self::Phase,
        direction: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    ) -> Result<(), Self::Error>;
    fn materialize(
        &mut self,
        current: &M1TrustRegionControllerEvaluation<Self::Payload>,
    ) -> Result<Self::Payload, Self::Error>;
    fn observe_controller_accounting(&mut self, _work: crate::M1TrustRegionWorkObservation) {}
    fn observe_controller_terminal_state(
        &mut self,
        _coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
        _materializations: u8,
    ) {
    }
    fn observe_selected_side_probe_attempt(&mut self, _final_probe: bool) {}
}

#[derive(Clone, Debug)]
pub(crate) struct M1TrustRegionControllerTransition {
    pub(super) scaled_step: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(super) lambda: f64,
    pub(super) predicted_reduction: f64,
    pub(super) actual_reduction: Option<f64>,
    pub(super) rho: Option<f64>,
    pub(super) installed: bool,
    pub(super) next_radius: f64,
    pub(super) weighted_jacobian:
        [[f64; M1_TRUST_REGION_CONTROLLER_DIMENSION]; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(super) disposition: M1TrustRegionProposalDisposition,
    pub(super) radius_before: f64,
    pub(super) base_before: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(super) stage1_observation: super::M1TrustRegionSubproblemObservation,
    pub(super) moving_merit: Option<f64>,
    pub(super) dynamic_max_normalized_residual: Option<f64>,
    pub(super) base_after: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(super) entered_materializations: u8,
    pub(super) governed_norms: Option<[f64; M1_GOVERNED_STEP_NORMS]>,
}

#[derive(Clone, Debug)]
pub(crate) struct M1TrustRegionControllerRun {
    pub(super) initial_radius: f64,
    pub(crate) proposals: u16,
    pub(super) entered_svd_factorizations: u16,
    pub(crate) refinement_scalar_operations: u64,
    pub(crate) refinement_guard_events: u64,
    pub(crate) refinement_attempted_entries: u16,
    pub(crate) refinement_denied_entries: u16,
    pub(crate) work: crate::M1TrustRegionWorkObservation,
    pub(crate) accepted_updates: u8,
    pub(crate) entered_materializations: u8,
    pub(crate) final_coordinates: [f64; M1_TRUST_REGION_CONTROLLER_DIMENSION],
    pub(crate) materialized_coordinates: Option<[f64; M1_TRUST_REGION_CONTROLLER_DIMENSION]>,
    pub(crate) proposal_trace: Vec<M1TrustRegionControllerTransition>,
    pub(crate) terminal_refusal: Option<super::M1TrustRegionRefusalKind>,
}

#[derive(Clone, Debug)]
pub(crate) struct M1TrustRegionSeededEntryGuard<E> {
    pub(super) incoming_core_entries: u16,
    pub(super) attempted_delta: u16,
    pub(super) entered_delta: u16,
    pub(super) refused_operation: super::M1TrustRegionControllerOperation,
    pub(super) numeric_refusal: Option<super::M1TrustRegionRefusalKind>,
    pub(super) entered_owner_error: Option<E>,
}
