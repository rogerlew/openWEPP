"""Path-aware emitted field table, with source hook routing and units. Offline only."""
import pathlib,json,re,hashlib
ROOT=pathlib.Path(__file__).resolve().parent;SRC=ROOT/'source'
cov=json.loads((ROOT/'schema-coverage-draft.json').read_text())
old=json.loads((ROOT/'prior-checks/prior-checks/schema-authority-draft.json').read_text())
texts={p:(SRC/p).read_text().splitlines() for p in cov['source_pins']}
rows=[];unmapped=[];unresolved_conditions=[]
condition_path=ROOT/'field-conditions.json'
condition_document=json.loads(condition_path.read_text()) if condition_path.exists() else {}
condition_authority=condition_document.get('fields',condition_document)
for row in cov['rows']:
 p=row['field'];k=row['key'];loc=row['serializer_locations'];fn=None
 if p.startswith('$.refinement_capture?.input.'):
  fn='refusal_capture_input_json'
 elif '.terminal_refusal?' in p and p!='$.refinement_capture?.refinement.terminal_refusal':fn='refusal_capture_terminal_json'
 elif '.work_ledger?' in p:fn='refusal_capture_work_json'
 elif '.completeness.' in p:fn='refusal_capture_completeness_json'
 elif '.field_status.' in p:fn='refinement_capture_field_status_json'
 elif p.startswith('$.adapter_observation.'):
  loc=[x for x in loc if x['path'].endswith('m1_coupled.rs')]
 elif p.startswith('$.mh_refusal_events') or p.startswith('$.request') or p.count('.')==1:fn='m1_refusal_capture_support0_ipc'
 if fn:loc=[x for x in loc if x['function']==fn]
 if p.startswith('$.refinement_capture') and not loc:
  loc=[x for x in row['serializer_locations'] if x['path'].endswith('m1_trust_region_stage1.rs')]
 if len(loc)>1:
  # The canonical request object is emitted before the outer payload object;
  # root support_id is the later identical literal in that same function.
  if p.startswith('$.request.'):loc=[min(loc,key=lambda x:x['line'])]
  elif p=='$.support_id':loc=[max(loc,key=lambda x:x['line'])]
  else:loc=list({(x['path'],x['line']):x for x in loc}.values())
 if not loc:unmapped.append(p)
 role='diagnostic metadata/identity or protocol envelope';units='unitless metadata';hook='post-return IPC serializer, no physical evaluation';condition='always emitted in the fixed support0 payload';absence='not optional unless explicit schema optional; missing required key is incomplete'
 if p.startswith('$.request'):role='canonical validated request';hook='m1_refusal_capture_request_witness validates exact four fields; IPC reconstructs canonical request'
 elif p.startswith('$.refinement_capture'):
  condition='refinement capture exists only if a subproblem was reached; nested field requirements follow typed correction_position × lambda × guard_stage'
  absence='An Option is null when its copy was absent. DRAFT LIMITATION: field-status and terminal predicates require independent verification of every actual branch, including interrupted prefixes and contradictory later evidence; null alone does not establish natural absence and this table grants no capture approval.'
  if '.input.' in p:
   role='actual subproblem input before refinement';hook='RefusalCaptureScope::begin_armed copies original input operands'
  elif '.ordered_norm_traces' in p:
   role='ordered actual norm operand trace for the named scaled-step stage';hook='bvls04_ordered_norm or lambda_norm copy each existing value/square/running sum and successful norm at original sites'
  elif '.terminal_refusal' in p:
   role='actual typed returned refusal, correction ordinal/stage/reason/masks';hook='refine_face_before_crossing outer return snapshots terminal_refusal'
  elif '.work_ledger' in p:
   role='actual completed/attempted/denied work ledger';units='counts or scalar operations, not elapsed time';hook='refine_face_before_crossing return copies observation_work'
  elif '.completeness' in p or '.field_status' in p:
   role='post-return observation validation result';hook='refinement_capture_terminal_complete and field-status/completeness serializers; expected historical terminal is separate'
  elif '.state_roles' in p:role='fixed semantic aliases of captured stage operands'
  else:
   role='retained last actual refinement-face operand';hook='RefinementObservationTrace copy sites in refinement preparation, factor application, first/second update and outer return'
  if k.endswith('_bits') or k in ('value_bits','square_bits','running_sum_bits'):
   units='dimensionless scaled-step/factor/weighted residual; squared dimensionless for norm2/squares/running sums'
   if '.input.' in p:
    units={'raw_residual_bits':old['raw_residual_and_normalizer_units'],'normalizer_bits':old['raw_residual_and_normalizer_units'],'raw_jacobian_bits':'raw row-unit divided by physical coordinate-unit; row roles as authority map','base_bits':'per-coordinate physical units from coordinate_layout','lower_bits':'per-coordinate physical units from coordinate_layout','upper_bits':'per-coordinate physical units from coordinate_layout','scale_bits':'physical coordinate-unit per dimensionless scaled step'}.get(k,units)
 elif p.startswith('$.mh_refusal_events'):
  role='actual reached MhConsistency emitter event, including handled refusals separately from exact terminal event';hook='vegetation record_m1_mh_refusal at actual constructor/temperature_jacobian/evap/residual rejection; caller scope inherits exact LSE role/map/FD/direction'
  condition='one row per observed rejection; event context required for every row by exact site allowlist; terminal id must join exactly one returned event'
  absence='Temperature is explicitly unavailable when emitter has not evaluated it; canonical phase undefined on constructor failure. FD/direction fields require caller applicability; missing required context fails completeness.'
  if k=='mass_bits':units='kg H2O m^-2 tile-ground'
  elif k=='enthalpy_bits':units='J m^-2 tile-ground'
  elif k=='temperature_bits':units='K; optional only if unavailable at actual emitter'
  elif k in ('trial_coordinate_bits','proposal_direction_bits'):units='per-coordinate physical units from coordinate_layout; direction is displacement'
 elif p.startswith('$.adapter_observation'):
  role='actual adapter observed values/counters';hook='M1PhysicalTrustRegionAdapter evaluate/select_phase/run return observation copies'
  if k.endswith('_bits'):units='physical coordinate/row units except dynamic normalizers share raw-row units'
  if '.phase_events' in p:condition='array statically empty in this IPC; separate face-pivot observer is never armed'
 elif k=='controller_result':
  role='complete actual Accepted or Refused outcome Debug';hook='Debug serialization after actual one-support controller returns';units='type-owned physical units for Accepted; enum identity for Refused'
 elif k=='seed_coordinate_bits':role='historical twice-mapped original support0 seed';units='per-coordinate physical units';hook='existing second reduced reconstruction before controller entry'
 # Exact field conditions must be supplied from actual hook/terminal semantics.
 if p.startswith('$.refinement_capture?.refinement.'):
  local=p.removeprefix('$.refinement_capture?.refinement.')
  root_field=local.split('.')[0].rstrip('[]?')
  authority=condition_authority.get(local) or condition_authority.get(root_field)
  if authority:
   condition=authority.get('conditions',authority.get('required_after','UNRESOLVED'));absence=authority.get('unavailable_unreached_semantics',authority.get('unavailable','UNRESOLVED'))
   if 'hook' in authority:hook=authority['hook']
  elif root_field in ('formulation','fixed_coordinate_reconstruction','logical_to_physical_map','state_roles','completeness'):
   condition='serializer-owned metadata/result emitted whenever refinement capture exists; formulation selected by fixed request, full coordinate IDs0..20, fixed semantic alias text'
   absence='Non-optional metadata when enclosing capture exists; enclosing null means no subproblem capture was installed'
  elif root_field in ('free_mask','held_mask'):
   condition='Some at refine_face_before_crossing entry before structural/eligibility checks, copied from state.free/state.held; required for every terminal from that entered call'
   absence='None only when no refinement-face entry was observed; this cannot satisfy entered-face completeness'
  elif root_field=='work_ledger':
   condition='Some after refine_face_before_crossing_inner returns Ok or Err; each member copies the corresponding actual state_work_observation counter'
   absence='None if refinement wrapper has not reached its return seam; no inferred counts from planned/reserved operations'
  elif root_field=='terminal_refusal':
   condition='Some exactly when refine_face_before_crossing_inner returns Err; each field is copied from that returned typed refusal, and nested refinement metadata is Some only when that refusal carries it'
   absence='Null outer refusal means refinement returned Ok or return seam not reached; nullable location/optimality fields preserve the actual typed constructor None without inventing operands'
  elif root_field=='field_status':
   named=local.partition('.')[2]
   aliases={'p0_full_norm':'p0_full_norm_bits','p0_free_norm':'p0_reduced_norm_bits','p1_full_norm':'p1_full_norm_bits','p1_free_norm':'p1_reduced_norm_bits','p2_full_norm':'p2_full_norm_bits','p2_free_norm':'p2_reduced_norm_bits','p0_mask':'lower_mask_p0','p1_mask':'lower_mask_p1','p2_mask':'lower_mask_p2'}
   target=aliases.get(named,named if named in condition_authority else named+'_bits')
   named_rule=condition_authority.get(target)
   if named_rule:
    condition='Status for '+target+': '+named_rule.get('conditions',named_rule.get('required_after','UNRESOLVED'))
    absence=named_rule.get('unavailable_unreached_semantics',named_rule.get('unavailable','UNRESOLVED'))
   elif not named:
    condition='post-return status object for observed fields; scientific validity requires the actual-terminal selector and field-specific rows'
   else:unresolved_conditions.append(p)
  elif local.startswith(('state_roles.','completeness.')):
   condition='fixed alias or actual post-return terminal validation result; emitted whenever refinement capture exists'
  else:unresolved_conditions.append(p)
 if '.partial_ordered_norms' in p:
  role='actual interrupted norm operation prefix, including reached failed operand; lengths show which operations executed'
  units='dimensionless scaled-step; squared dimensionless for squares and running sums'
 if '.factor_application_snapshots' in p:
  role='actual per-application factor operands, separately retained for ordinal first/second; no stale second-use inference'
  units='dimensionless scaled-step/factor/weighted residual'
 if k in ('source_mass_bits','source_enthalpy_bits'):
  role='actual beginning-input reservoir constructor operand; caller trial bits remain separate context'
  units='kg H2O m^-2 tile-ground' if k=='source_mass_bits' else 'J m^-2 tile-ground'
  condition='Some only at validate_with_q_guard_initial_reservoir and bit-identical to the event operand; None for trial-derived constructor sites'
  absence='Not the constructor source at other sites; actual operand is joined to indexed trial coordinates there'
 if p.startswith('$.mh_refusal_events') and k in ('representation','map_identity'):
  role='logical origin of the adapter call; independent of full physical trial vector storage'
  condition='full/full_logical_to_physical_identity or reduced/reduced_zero_sun_logical_to_physical_map only as permitted by exact caller site; inherited through mapped Jacobian, FD and phase-selection scopes'
  absence='Required on every event context. The representation labels logical origin, not the storage layout of trial_coordinate_bits.'
 if p.startswith('$.mh_refusal_events') and k=='trial_coordinate_bits':
  role='full 21-coordinate physical caller trial; reconstructed from reduced logical coordinates when applicable'
  condition='Some for every selected caller context; physical mass/enthalpy indices are occupancy 0:3,4 and occupancy 1:9,10'
  absence='At beginning-input validation this is caller context only, not constructor-source coordinates. No constructor-source coordinate vector exists there; source_mass_bits/source_enthalpy_bits are the separately captured constructor operands.'
 # Pin candidate assignment locations as additional audit pointers, never as a
 # substitute for the condition/role mapping above.
 trace_field=k.removesuffix('_bits');matches=[]
 if p.startswith('$.refinement_capture'):
  for file,lines in texts.items():
   if not file.endswith('m1_trust_region_stage1.rs'):continue
   for n,line in enumerate(lines,1):
    if re.search(r'\btrace\.'+re.escape(trace_field)+r'\s*=',line):matches.append({'path':file,'line':n,'source':line.strip()})
 rows.append({**row,'serializer_locations':loc,'role':role,'units':units,'hook':hook,'assignment_locations':matches,'conditions':condition,'unavailable_unreached_semantics':absence})
result={'status':'DRAFT_REQUIRES_CORRECTNESS_AND_QA','source_pins':cov['source_pins'],'field_count':len(rows),'unmapped_paths':unmapped,'unresolved_field_conditions':unresolved_conditions,'coordinate_layout':old['coordinate_layout'],'source_authority':old['authority'],'rows':rows,'limits':'Table maps every emitted nesting path, not only global names. Scientific completeness and actual-stage predicates remain separately reviewed. No capture approval.'}
(ROOT/'field-table-draft.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'fields':len(rows),'unmapped':unmapped,'unresolved_conditions':len(unresolved_conditions)}))
