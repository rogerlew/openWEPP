"""Independent offline arithmetic on captured IEEE754 operands; never invokes model."""
import fractions,json,math,pathlib,struct,sys
ROOT=pathlib.Path(__file__).resolve().parent
F=fractions.Fraction

def value(bits):return struct.unpack('>d',struct.pack('>Q',bits))[0]
def bits(x):return struct.unpack('>Q',struct.pack('>d',x))[0]
def exact(x):
 if not math.isfinite(x):return None
 f=F.from_float(x);return {'numerator':str(f.numerator),'denominator':str(f.denominator)}
def key(x):
 b=bits(x);return ~b & ((1<<64)-1) if b>>63 else b | (1<<63)
def pair(left,right,relation,units):
 difference=(F.from_float(left)-F.from_float(right)) if relation=='>' else (F.from_float(right)-F.from_float(left))
 return {'left_bits':bits(left),'right_bits':bits(right),'left':left,'right':right,'relation':relation,'holds':left>right if relation=='>' else left<right,'signed_violation':left-right if relation=='>' else right-left,'units':units,'ulp_distance':abs(key(left)-key(right)),'exact_left':exact(left),'exact_right':exact(right),'exact_signed_violation':{'numerator':str(difference.numerator),'denominator':str(difference.denominator)}}
def main(w):
 text=(ROOT/'captures'/f'{w}.stdout').read_text();marker='M1_REFUSAL_CAPTURE ';rows=[line.partition(marker)[2] for line in text.splitlines() if marker in line]
 if len(rows)!=1:raise ValueError('exactly one retained capture record required')
 payload=json.loads(rows[0]);r=(payload.get('refinement_capture') or {}).get('refinement');out={'evidence_class':'Ran: independent offline binary64/Fraction arithmetic on actual retained bits only','witness':w,'capture_complete':payload.get('capture_complete'),'controller_result':payload['controller_result'],'norms':[],'inequality':None}
 if r is None:
  out['status']='NO_REACHED_REFINEMENT_OPERANDS'
 else:
  out['terminal']=r.get('terminal_refusal');out['completeness']=r.get('completeness')
  for n in r['ordered_norm_traces']:
   total=0.;squares=[];sums=[];exact_sum=F(0)
   for b in n['value_bits']:
    v=value(b);s=v*v;total+=s;squares.append(bits(s));sums.append(bits(total))
    if math.isfinite(v):exact_sum+=F.from_float(v)**2
   norm=math.sqrt(total)
   out['norms'].append({'role':n['role'],'coordinate_ids':n['coordinate_ids'],'squares_match':squares==n['square_bits'],'running_sums_match':sums==n['running_sum_bits'],'norm2_matches':bits(total)==n['norm2_bits'],'sqrt_matches':bits(norm)==n['norm_bits'],'binary64_sum_bits':bits(total),'binary64_norm_bits':bits(norm),'exact_operand_square_sum':{'numerator':str(exact_sum.numerator),'denominator':str(exact_sum.denominator)}})
  terminal=r.get('terminal_refusal') or {};m=terminal.get('refinement') or {};stage=m.get('guard_stage');inp=payload['refinement_capture']['input']
  if stage in ('ScratchFullRadius','FinalFullRadius'):
   name='p1' if stage=='ScratchFullRadius' else 'p2';n=r.get(name+'_full_norm_bits')
   if n is not None:out['inequality']=pair(value(n),value(inp['initial_radius_bits']),'>','dimensionless scaled full-step norm')
  elif stage in ('ScratchReducedRadius','FinalReducedRadius'):
   name='p1' if stage=='ScratchReducedRadius' else 'p2';n=r.get(name+'_reduced_norm_bits')
   if n is not None:out['inequality']=pair(value(n),value(r['reduced_face_radius_bits']),'>','dimensionless scaled free-face norm')
  elif stage in ('FinalBoxLower','FinalBoxUpper','ScratchBoxLower','ScratchBoxUpper'):
   i=m.get('coordinate');name='p2' if stage.startswith('Final') else 'p1';vec=r.get(name+'_bits');lower=stage.endswith('Lower');bound=r.get('scaled_lower_bits' if lower else 'scaled_upper_bits')
   if i is not None and vec is not None and bound is not None:
    out['inequality']=pair(value(vec[i]),value(bound[i]),'<' if lower else '>','dimensionless scaled coordinate');out['inequality']['coordinate']=i
  out['status']='RECONSTRUCTED_REACHED_COMPARISON' if out['inequality'] is not None else 'ACTUAL_BRANCH_REQUIRES_SEPARATE_RECONSTRUCTION_NO_SUBSTITUTE'
 (ROOT/'captures'/f'{w}-independent-arithmetic.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({'witness':w,'status':out['status']}))
if __name__=='__main__':main(sys.argv[1])
