"""Offline serializer-key reconciliation; this does not prove scientific completeness."""
import pathlib,re,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=ROOT/'source'
files={'stage1':'crates/openwepp-land-surface-energy/src/m1_trust_region_stage1.rs','ipc':'crates/openwepp-land-surface-energy/src/m1_coupled_tests.rs','adapter':'crates/openwepp-land-surface-energy/src/solver_covered_evaluation/m1_coupled.rs'}
function_names={'stage1':['refusal_capture_work_json','add_capture_masks','refusal_capture_input_json','refusal_capture_terminal_json','add_refusal_capture_factor_fields','add_refusal_capture_first_norm_fields','add_refusal_capture_second_norm_fields','refusal_capture_completeness_json','refinement_capture_field_status_json','refusal_capture_json_for_test'],'ipc':['m1_refusal_capture_support0_ipc'],'adapter':['refusal_capture_json_for_test']}
seen={};pins={}
for kind,rel in files.items():
 text=(SOURCE/rel).read_text();pins[rel]=hashlib.sha256(text.encode()).hexdigest()
 for name in function_names[kind]:
  m=re.search(r'fn\s+'+name+r'\s*\(',text);assert m,name
  start=text.index('{',m.end());depth=1;end=start+1
  while depth:
   if text[end]=='{':depth+=1
   elif text[end]=='}':depth-=1
   end+=1
  body=text[start:end]
  patterns=[r'"([a-z][a-z0-9_]*)"\s*:',r'put!\(\s*"([a-z][a-z0-9_]*)"',r'\.insert\(\s*"([a-z][a-z0-9_]*)"',r'\(\s*"((?:free|held|lower|upper)_mask(?:_p[012]|_exit)?)"']
  for pattern in patterns:
   for match in re.finditer(pattern,body):seen.setdefault(match[1],[]).append({'path':rel,'function':name,'line':text[:start+match.start()].count('\n')+1})
schema=json.loads((ROOT/'schema-draft.json').read_text());names=set();rows=[]
def visit(node,path):
 k=node['kind']
 if k=='object':
  for key,value in node['fields'].items():
   names.add(key); p=path+'.'+key;rows.append({'field':p,'key':key,'type':value['kind'],'serializer_locations':seen.get(key,[])});visit(value,p)
 elif k in ('array','optional'):visit(node['item'] if k=='array' else node['value'],path+('[]' if k=='array' else '?'))
visit(schema['root'],'$')
result={'status':'DRAFT_SERIALIZER_KEY_COVERAGE_ONLY','source_pins':pins,'source_keys':sorted(seen),'schema_keys':sorted(names),'missing_schema_keys':sorted(set(seen)-names),'schema_keys_without_serializer_location':sorted(names-set(seen)),'rows':rows,'scientific_field_hook_units_stage_conditions':'must be supplied by source implementer and reviewed; key presence alone is not completeness'}
(ROOT/'schema-coverage-draft.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k in ['missing_schema_keys','schema_keys_without_serializer_location']}))
