"""Execute one already approved fixed support-0 witness; permanently reserve first."""
import datetime, fcntl, hashlib, json, os, pathlib, selectors, signal, subprocess, sys, time
if not __debug__:
    raise SystemExit('Optimized Python is prohibited; no capture launch')
ROOT = pathlib.Path(__file__).resolve().parent
ART = pathlib.Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
witness = sys.argv[1]
assert witness in ('W1', 'W2', 'W3')
receipt = json.loads((ART / 'refusal-finalization-approved.json').read_text())
assert receipt['correctness_approved'] is True and receipt['qa_approved'] is True
now = datetime.datetime.now(datetime.timezone.utc)
assert now + datetime.timedelta(seconds=30) <= datetime.datetime.fromisoformat(receipt['capture_deadline_utc'])
# Do not rebuild: exact immutable artifact and protocol only.
binary = pathlib.Path(receipt['binary_path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == receipt['binary_sha256']
for path, expected in receipt['required_capture_pins'].items():
    assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() == expected, path
ledger_path = ART / 'refusal-finalization-accounting.json'
ledger_lock = (ART / 'refusal-finalization-accounting.lock').open('a')
try:
    fcntl.flock(ledger_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    raise SystemExit('Concurrent reservation holds ledger lock; no launch')

def save_ledger(value):
    temporary = ledger_path.with_suffix('.json.tmp')
    with temporary.open('w') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, ledger_path)
    directory = os.open(str(ART), os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

ledger = json.loads(ledger_path.read_text())
slot = ledger['slots'][witness]
assert slot['reserved'] == slot['invocations'] == 0
for previous in ('W1', 'W2', 'W3')[:('W1', 'W2', 'W3').index(witness)]:
    assert ledger['slots'][previous]['invocations'] == 1
assert sum(s['elapsed_seconds'] for s in ledger['slots'].values()) < 90
slot.update(reserved=1, invocations=1, status='RESERVED_BEFORE_PROCESS_START', reserved_utc=now.isoformat())
ledger['physical_invocations'] = sum(s['invocations'] for s in ledger['slots'].values())
save_ledger(ledger)
command = receipt['commands'][witness]
assert command[0] == str(binary)
assert command[1:] == ['--exact', 'm1_coupled_tests::m1_refusal_capture_support0_ipc', '--ignored', '--nocapture', '--test-threads=1']
stdin = receipt['stdin'][witness].encode()
caps = {'stdout': receipt['stdout_transport_cap_bytes'], 'stderr': receipt['stderr_diagnostic_cap_bytes']}
logs = ROOT / 'captures'
logs.mkdir(exist_ok=True)
start = time.monotonic()
record = {'witness': witness, 'command': command, 'stdin': stdin.decode(), 'binary_sha256': receipt['binary_sha256'], 'start_utc': now.isoformat(), 'timeout_seconds': 30, 'process_cutoff_seconds': 29, 'cleanup_reserve_seconds': 1, 'output_cap_bytes': caps}
child = subprocess.Popen(command, cwd=receipt['cwd'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
child.stdin.write(stdin)
child.stdin.close()
sel = selectors.DefaultSelector()
streams = {}
for name, pipe in [('stdout', child.stdout), ('stderr', child.stderr)]:
    sel.register(pipe, selectors.EVENT_READ, name)
    streams[name] = (logs / (witness + '.' + name)).open('wb')
counts = {'stdout': 0, 'stderr': 0}
stop = None
while sel.get_map():
    remaining = 29 - (time.monotonic() - start)
    if remaining <= 0:
        stop = 'TIMEOUT'
        break
    for key, _ in sel.select(min(remaining, 0.1)):
        chunk = os.read(key.fd, 65536)
        if not chunk:
            sel.unregister(key.fileobj)
            continue
        streams[key.data].write(chunk)
        counts[key.data] += len(chunk)
        if counts[key.data] > caps[key.data]:
            stop = 'OUTPUT_CAP_EXCEEDED'
            break
    if stop:
        break
if stop:
    os.killpg(child.pid, signal.SIGKILL)
else:
    remaining = max(0.001, 29 - (time.monotonic() - start))
    try:
        child.wait(timeout=remaining)
    except subprocess.TimeoutExpired:
        stop = 'TIMEOUT'
        os.killpg(child.pid, signal.SIGKILL)
child.wait(timeout=1)
for stream in streams.values():
    stream.close()
record.update(exit=child.returncode, stop=stop, elapsed_seconds=time.monotonic()-start, output_bytes=counts)
stdout_text = (logs / (witness+'.stdout')).read_text(errors='replace')
record['selected_one_test'] = 'running 1 test\n' in stdout_text and 'running 0 tests' not in stdout_text
marker = 'M1_REFUSAL_CAPTURE '
records = [line.partition(marker)[2] for line in stdout_text.splitlines() if marker in line]
record['capture_records'] = len(records)
record['capture_complete'] = False
if len(records) == 1:
    try:
        payload = json.loads(records[0])
        record['capture_complete'] = payload.get('capture_complete') is True
    except (ValueError, TypeError):
        record['parse_error'] = True
record['execution_pass'] = child.returncode == 0 and stop is None and record['selected_one_test'] and record['capture_records'] == 1 and record['capture_complete']
for suffix in ('stdout', 'stderr'):
    record[suffix+'_sha256'] = hashlib.sha256((logs / (witness+'.'+suffix)).read_bytes()).hexdigest()
(logs / (witness+'.json')).write_text(json.dumps(record, indent=2)+'\n')
slot.update(status='FINISHED_NO_RETRY', elapsed_seconds=record['elapsed_seconds'], exit=record['exit'], stop=stop)
save_ledger(ledger)
print(json.dumps(record))
