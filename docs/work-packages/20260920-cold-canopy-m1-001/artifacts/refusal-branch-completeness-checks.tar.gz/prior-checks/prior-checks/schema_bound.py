"""Offline JSON byte bound from a reviewed, source-bound field schema; no solver calls."""
import json, pathlib, sys

def bound(node):
    kind = node['kind']
    if kind == 'uint64':
        return 20
    if kind == 'int64':
        return 20
    if kind == 'bool':
        return 5
    if kind == 'null':
        return 4
    if kind == 'literal':
        return len(json.dumps(node['value'], ensure_ascii=False, separators=(',', ':')).encode())
    if kind == 'string':
        # Worst case: each source byte is one ASCII control byte, encoded as \u00XX.
        return 2 + 6 * node['max_utf8_bytes']
    if kind == 'array':
        count = node['max_items']
        return 2 + max(0, count - 1) + count * bound(node['item'])
    if kind == 'tuple':
        return 2 + max(0, len(node['items']) - 1) + sum(map(bound, node['items']))
    if kind == 'object':
        fields = node['fields']
        return 2 + max(0, len(fields) - 1) + sum(len(json.dumps(key, ensure_ascii=False).encode()) + 1 + bound(value) for key, value in fields.items())
    if kind == 'optional':
        return max(4, bound(node['value']))
    if kind == 'union':
        return max(map(bound, node['variants']))
    raise ValueError(kind)

if __name__ == '__main__':
    schema = json.loads(pathlib.Path(sys.argv[1]).read_text())
    payload = bound(schema['root'])
    prefix = len(b'M1_REFUSAL_CAPTURE ')
    result = {'evidence_class': 'Ran: offline integer byte-bound arithmetic only; not a physical witness', 'payload_bound_bytes': payload, 'record_bound_bytes': prefix + payload + 1, 'payload_cap_bytes': schema['payload_cap_bytes'], 'fits_payload_cap': payload <= schema['payload_cap_bytes'], 'schema_status': schema['status'], 'method': 'Structural sum over every emitted key/value, commas, brackets/braces, maximum-width integers/bools, optional maximums, 6x UTF-8-byte string escaping, and bounded repeated sequences; prefix/newline separate.'}
    print(json.dumps(result, indent=2))
    assert result['fits_payload_cap']
