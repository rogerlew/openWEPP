"""Offline prospective upper bound for the retained full Debug outcome."""
import collections,hashlib,json,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parent
ART=pathlib.Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
original=ART/'original-input-reference.json'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='4b324b0a9c136f2203e8073ca260db5be9e7dd07722a37aec60f2cd528be2d54'
x=json.loads(original.read_text())['inputs']
c=collections.Counter();strings=[];arrays=[]
def walk(value,path):
 c[type(value).__name__]+=1
 if isinstance(value,dict):
  for k,v in value.items():strings.append(k);walk(v,path+'/'+k)
 elif isinstance(value,list):
  arrays.append((path,len(value)))
  for i,v in enumerate(value):walk(v,path+'/'+str(i))
 elif isinstance(value,str):strings.append(value)
walk(x,'column')
assert sum(c.values())==380 and max(len(s.encode()) for s in strings)<=64
assert len(x['occupancies'])==2
assert all(len(o['root_layers'])<=6 for o in x['occupancies'])
assert len(x['ground']['soil_nodes'])==6
# Each original JSON node budgets an extra Option/newtype/enum wrapper.
components={'column_data_nodes_and_wrapper_allowance':2*sum(c.values()),'M1_input_wrapper_support_topology_reservoirs':128,'evaluation_root':16,'residual_21_vector':22,'optional_21_by_21_jacobian':465,'two_occupancy_outputs_leaf_hydraulic_and_strings':256,'two_reservoir_outputs':48,'accepted_coordinates':22}
count=sum(components.values())
assert count<=4096
# Per node: <=128 bytes field name + <=128 bytes struct/variant name +
# <=642 bytes escaped source string (<=64 UTF8 bytes, Rust Debug <=10x),
# or <=330 bytes any binary64 display, plus <=64 punctuation/wrapper bytes.
# Parent and child punctuation double-counted deliberately; 962 <=1024.
result={'status':'PROSPECTIVE_DRAFT_REQUIRES_INDEPENDENT_TYPE_SHAPE_REVIEW','evidence_class':'Ran: offline fixture count and integer bound; no physical evaluation','source_nodes':dict(c),'source_arrays':arrays,'largest_input_key_or_string_utf8_bytes':max(len(s.encode()) for s in strings),'component_nodes':components,'component_node_sum':count,'conservative_node_allowance':4096,'bytes_per_node_allowance':1024,'raw_debug_string_max_utf8_bytes':4096*1024,'json_string_bound_bytes':2+6*4096*1024,'coverage':{'Accepted':'M1CoupledEvaluation: fixed unchanged accepted_input cloned from support0; 21 residuals, optional 21x21 Jacobian, 2 occupancy outputs, 2 reservoirs, 21 coordinates; materialize_m1_coupled_column_with_tolerances','Refused':'M1TrustRegionRefusalKind has unit variants, all names shorter than128 bytes'},'static_obligations':['Verify covered serde input has no uncounted variable-data defaults; absent transparent boundary adds at most one None node','Verify support0 loader changes only scalar values; support/topology IDs fixed and <=64 bytes','Verify hydraulic output vector lengths <=6 and gas branch names <=64 bytes','Verify each Debug-expanded type/field name <=128 bytes and no custom formatter emits unbounded data','Verify source-bound M1PhysicalTrustRegionAdapterOutcome stays exactly Accepted/Refused']}
(ROOT/'outcome-bound-draft.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps({'nodes':count,'debug_bound':result['raw_debug_string_max_utf8_bytes'],'json_bound':result['json_string_bound_bytes']}))
