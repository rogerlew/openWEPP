from pathlib import Path
import json,re,collections,hashlib,tarfile,shutil
base=Path(__file__).parent
run=base/'run-tools-c6-oracle'
art=Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
s=json.loads((run/'separate-accuracy-runner-state.json').read_text())
measure=json.loads((run/'separate-accuracy-measurement-draft.json').read_text())
def classify(v):
 f=' '.join(v.get('first_failures',[]))
 m=re.search(r'optimality_reason: Some\("([^"]+)"\)',f)
 return m.group(1) if m else ('VEG-E-142_MhConsistency' if 'VEG-E-142' in f else v.get('reason',v['status']))
rows=[]
for c in measure['cell_sequence']:
 v=next(v for v in s['operations'].values() if v['kind']=='diagnostic' and v['cell']==c)
 rows.append(dict(c,status=v['status'],failure_class=classify(v),completed_supports=v.get('completed_supports'),complete_days=v.get('fresh_complete_days',0),reused_reference=v.get('reused_reference'),partial_attempt_cpu_seconds=v.get('child_process_cpu_seconds'),partial_attempt_wall_seconds=v.get('sample_wall_seconds'),output=v.get('output')))
refs=[v for v in s['operations'].values() if v['kind'] in ('reference','stability')]
physical=[v for v in s['operations'].values() if v['kind'] in ('reference','stability','diagnostic') and v.get('charged_seconds',0)>0]
summary={'disposition':'FINITE_SCHEDULE_FINISHED_WITH_NEGATIVE_RESULTS','implementation_acceptance':'HOLD_NO_COMPLETED_DAY','source_tree':'e900961e8e7b902f1cc13e01344275769e4241d3f4f1cf4e6b0a399ab03760c3','binary_sha256':'c94275f4fe236ef35c5d6c80a42a0f73e59cdad1296afb419a5c817ff95725fb','control_status':'C1-C6_PASS_WITH_DISCLOSED_C5_AND_C6_CORRECTED_REPLAYS','C6_replay_charge_seconds':s['operations'][next(k for k,v in s['operations'].items() if v['cell'].get('control_id')=='C6_near_bound_rank_refusal')]['charged_seconds'],'physical_elapsed_seconds':s['physical_seconds'],'reference_elapsed_seconds':s['reference_seconds'],'historical_prior_control_elapsed_seconds':.053829565,'references_and_stability':refs,'cells':rows,'A_failure_counts':dict(collections.Counter(v['failure_class'] for v in rows if v['investigation']=='A')),'unique_physical_day_attempts':len(physical),'retained_completed_supports':sum(sum(v.get('completed_supports',[])) for v in physical),'completed_days':0,'timing_batches':0,'frontier':[],'frontier_status':'UNMEASURED_NO_COMPLETED_DAY_OR_CREDIBLE_REFERENCE','A_conclusion':'All24 fixed60second profiles/formulations failed; no valid reduction or tolerance accuracy/runtime ratios','B_conclusion':'All18 coarse cells unavailable because corresponding REDUCED60second baselines failed; no cadence comparison','accuracy_metrics':'UNRESOLVED: temperature/humidity/stores, occupancy fluxes/ET, transfers/releases, signed/gross integrals, cumulative residuals and event timing lack completed comparable days','target_gap':'Unmeasured completed OFEday and century costs; no functioning setting demonstrated','cpu_wall_limit':'Raw clocks below are partial failed attempts only, not completed-day costs or timing samples','partial_attempt_cpu_range_seconds':[min(v['child_process_cpu_seconds'] for v in physical),max(v['child_process_cpu_seconds'] for v in physical)],'partial_attempt_wall_range_seconds':[min(v['sample_wall_seconds'] for v in physical),max(v['sample_wall_seconds'] for v in physical)]}
(art/'c6-oracle-results.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copy2(run/'separate-accuracy-runner-state.json',art/'c6-oracle-terminal-state.json')
archive=art/'c6-oracle-run-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(run.iterdir()):
  if p.is_file():t.add(p,arcname='run-tools-c6-oracle/'+p.name)
 for n in ['dispatch-c6-oracle.py','summarize-c6-oracle.py']:t.add(base/n,arcname=n)
members={}
with tarfile.open(archive) as t:
 for p in t.getmembers():
  if p.isfile():members[p.name]=hashlib.sha256(t.extractfile(p).read()).hexdigest()
(art/'c6-oracle-run-evidence.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['A_failure_counts','unique_physical_day_attempts','retained_completed_supports','physical_elapsed_seconds','reference_elapsed_seconds','partial_attempt_cpu_range_seconds','partial_attempt_wall_range_seconds']}))
for formulation in ['FULL','REDUCED']:
 for profile in ['P0','P1','P2','P3']:
  vals=[v for v in rows if v['investigation']=='A' and v['formulation']==formulation and v['profile']==profile]
  print(formulation,profile,[(v['case'][0],v['failure_class'],v['completed_supports']) for v in vals])
