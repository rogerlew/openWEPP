---
contract_id: SC-LANDSURFACEENERGY-001
title: Land-Surface Energy-Balance Process Contract
status: approved
maturity: active
owner: openWEPP maintainers + land-surface-energy/hydrology reviewer
contract_version: 41
producer_scope:
  - Future snow-free land-surface energy control-volume evaluator
  - Future post-snow receiving-surface evaluator after an atomic handoff cutover
  - Persistent Stage 3 snow--soil lower-boundary evaluator
consumer_scope:
  - Future soil-heat/frost boundary, evaporation, infiltration/runoff, and surface-water ledgers
evidence_level: static+independent_oracle+contract_vectors
last_reviewed: 2026-09-29
supersedes: []
superseded_by: []
contract_format: directory-v1
binding_index: SC-LANDSURFACEENERGY-001/binding-index.md#binding-exposure-index
---

# LSE contract

Read the complete [shared interface](SC-LANDSURFACEENERGY-001/interface.md#interface) for every
task, then the applicable route and every conditional dependency. The entire normative
set remains binding. Sections include subsections to the next same/higher heading,
applicable marked definitions and their guard/test links; inspect each selected
chapter's Dependencies and introduction. Uncertainty expands reading.

## Document inventory
|Path|Kind|Purpose|Applicability|
|---|---|---|---|
|SC-LANDSURFACEENERGY-001/interface.md|normative|interface|selected|
|SC-LANDSURFACEENERGY-001/common-details.md|normative|common details|selected|
|SC-LANDSURFACEENERGY-001/audit-details.md|normative|audit details|selected|
|SC-LANDSURFACEENERGY-001/surface-energy.md|normative|surface energy|selected|
|SC-LANDSURFACEENERGY-001/soil-coupling.md|normative|soil coupling|selected|
|SC-LANDSURFACEENERGY-001/water-vapor.md|normative|water vapor|selected|
|SC-LANDSURFACEENERGY-001/solve-boundary.md|normative|solve boundary|selected|
|SC-LANDSURFACEENERGY-001/nonlinear-solve.md|normative|admission|selected|
|SC-LANDSURFACEENERGY-001/terminal-support.md|normative|terminal support|selected|
|SC-LANDSURFACEENERGY-001/litter-phase.md|normative|litter phase|selected|
|SC-LANDSURFACEENERGY-001/soil-custody.md|normative|soil custody|selected|
|SC-LANDSURFACEENERGY-001/surface-custody.md|normative|surface custody|selected|
|SC-LANDSURFACEENERGY-001/map-custody.md|normative|map custody|selected|
|SC-LANDSURFACEENERGY-001/dependency-replay.md|normative|dependency replay|selected|
|SC-LANDSURFACEENERGY-001/qualification.md|normative|physical capture|selected|
|SC-LANDSURFACEENERGY-001/binding-index.md|normative|binding index|audit|
|SC-LANDSURFACEENERGY-001/history.md|historical|history|audit|
|SC-LANDSURFACEENERGY-001/numerical-methods.md|normative|methods|selected|
|SC-LANDSURFACEENERGY-001/inactive-jacobian.md|normative|isolated v34 affine-column experiment|selected|
|SC-LANDSURFACEENERGY-001/replay-evidence.md|normative|replay|selected|

## Reading routes
|Task|Role/check|Initial material|Expansion trigger|
|---|---|---|---|
|Surface/soil rules|science review|[surface-energy](SC-LANDSURFACEENERGY-001/surface-energy.md#surface-energy)|Follow physical shared set and applicable mechanism dependencies.|
|Snow replay|correctness review|[dependency-replay](SC-LANDSURFACEENERGY-001/dependency-replay.md#dependency-replay)|All affected physics, errors/custody, support and frozen protocol.|
|Executable identity|identity verification|[qualification](SC-LANDSURFACEENERGY-001/replay-evidence.md#qualification)|Frozen capture protocol; scientific claims expand physics/closure.|
|Frozen-litter closure|closure review|[physical capture](SC-LANDSURFACEENERGY-001/qualification.md#qualification)|Physical operands, errors, support and receipt origin; implementation expands full evaluator/solver.|
|Other/uncertain|all|[binding index](SC-LANDSURFACEENERGY-001/binding-index.md#binding-exposure-index)|Expand full normative set and reconcile applicability.|

<a id="change-log"></a>
## Change Log
2026-09-30 v41: review-pending `COLD-CANOPY-M1-SEPARATE-ACCURACY-01`
detached full/reduced accuracy-cost authority.  It selects one complete
test-only TR/BVLS controller for both arms, defines exact coordinate pullback,
P0--P3 numerical profiles, and bounded support coarsening.  Production HOLD.
2026-09-29 v40: owner-adopted prospective `COLD-CANOPY-M1-TR-SVD-BVLS-05`
fully-wet structural-null-direction binding. It holds only role-proven exact
zero step directions after complete assembly, retains all 21 physical residuals
and existing BVLS guards, and requires renewed dual review/controls before body
release. Production HOLD.
2026-09-25 v39: accepted `COLD-CANOPY-M1-TR-SVD-BVLS-02` finite-precision active-face amendment after distinct independent correctness and QA review; it preserves `01` as historical evidence and defines a premeasurement, scale-aware all-coordinate approximate-KKT test for the detached diagnostic only. Production HOLD.
2026-09-21 v38: review-pending M1 selected-drainage affine-elimination binding; it preserves the primal capacity equation and selected branch, reduces/reconstructs the same normalized Newton system, and retains physical candidate admission and production HOLD.
2026-09-21 v37: review-pending M1 phase-join directional-linearization binding; it fixes only bounded Newton tangent selection and expected-red obligations, retaining primal phase/residual/receiver/transaction authority and production HOLD.
2026-09-20 v36: review-pending cold-canopy M1 component and typed liquid-receiver join; V35 bytes unchanged.
2026-09-20 v35: owner-adopted existing-domain liquid-canopy clarification; it distinguishes covered-component, shared-air, dry-stem, ground-snow, and transparent-passage temperature/release roles while retaining the liquid-only domain, existing guard seams, equations, acceptance, and production HOLD. No phase law, solver, runtime selector, or model-definition byte changed.

2026-09-19: non-versioned isolated B01 original-start grid40 experiment in
solve-boundary.md; prospective independent dual review, unchanged production
authority and no-update acceptance.

2026-09-08 v34: isolated owner-approved zero-input-area sun/shade affine-column
experiment with complete dependency proof, coordinate-aware assembly and
candidate-independent resolution routes. See inactive-jacobian.md. Production
HOLD; v33 stem policy/results remain historical and unchanged.

2026-09-08 v33: prospective experimental residual/Jacobian representation for
active dry-stem temperature columns, with derivative-through-normalization,
smooth-branch admission, independent multistep FD/Taylor authority, hybrid
assembly boundaries, and no production activation; scientific equations,
accepted-result construction, solver controller and custody are unchanged.

2026-09-07 v32: coherent directory presentation; scientific authority, production
HOLD and frozen identities unchanged. History: history.md.
