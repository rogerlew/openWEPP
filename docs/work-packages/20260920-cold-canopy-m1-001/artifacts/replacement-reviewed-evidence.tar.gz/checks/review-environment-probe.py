from pathlib import Path
import os,json,hashlib,shutil
r=Path('/home/roger/openwepp-experiments/cold-canopy-m1-recovered-terminal-20261004')
env=dict(os.environ,**json.loads((r/'build-env.json').read_text()))
recorded=json.loads((r/'tools.json').read_text());rows={}
for name,meta in recorded.items():
 p=Path(shutil.which(name,path=env['PATH'])).resolve(); actual=hashlib.sha256(p.read_bytes()).hexdigest(); assert actual==meta['sha256'],(name,str(p));rows[name]={'resolved':str(p),'sha256':actual}
keys=['OPENWEPP_NIX_TOOLCHAIN_ID','OPENWEPP_NIX_STAGED_INPUT','OPENWEPP_CACHE_ROOT','OPENWEPP_TASK_ID','CC','CXX','LD','RUSTC','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','NIX_CFLAGS_COMPILE','NIX_LDFLAGS']
out={'evidence_class':'Ran: entered current tools/dev/develop; authenticated effective recorded package tool resolution, no build or test','tools':rows,'environment':{k:env[k] for k in keys if k in env},'wrapper_inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('tools/dev/develop'),Path('tools/dev/heavy'),Path('tools/dev/openwepp-env'),Path('tools/dev/nix-toolchain/flake.nix'),Path('tools/dev/nix-toolchain/flake.lock')]}}
(r/'checks/review-environment-entry.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
