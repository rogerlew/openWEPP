"""Preserve and re-read bounded resumption evidence; source is separately archived."""
import hashlib, json, tarfile
from pathlib import Path
r=Path('/home/roger/openwepp-experiments/cold-canopy-m1-recovered-terminal-20261004')
a=Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
p=a/'replacement-reviewed-evidence.tar.gz'; receipt=a/'replacement-reviewed-evidence.json'
assert not p.exists() and not receipt.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={p.name:p for p in r.iterdir() if p.is_file() and not p.is_symlink() and p.suffix in ['.py','.json']}
for pth in (r/'checks').glob('review*'):
 for member in ([pth] if pth.is_file() else sorted(pth.rglob('*'))):
  if member.is_file() and not member.is_symlink() and '__pycache__' not in member.parts:
   files[str(member.relative_to(r))]=member
build=json.loads((r/'checks/review01-build-inputs.json').read_text());binary=Path(build['binary_path']);assert sha(binary)==build['binary_sha256'];files['binary/'+binary.name]=binary
members={key:{'sha256':sha(path),'bytes':path.stat().st_size,'mode':path.stat().st_mode & 0o777} for key,path in sorted(files.items())}
with tarfile.open(p,'w:gz') as out:
 for key,path in sorted(files.items()):out.add(path,arcname=key,recursive=False)
with tarfile.open(p) as saved:
 assert len(saved.getmembers())==len(members)
 for member in saved.getmembers():
  data=saved.extractfile(member).read(); row=members[member.name]
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and member.mode==row['mode']
for key,path in files.items():assert sha(path)==members[key]['sha256']
result={'evidence_class':'Ran: preserved and re-read every resumption raw/helper/proof/binary archive member; not scientific acceptance','source_sha256':build['source_sha256'] if 'source_sha256' in build else json.loads((a/'replacement-reviewed-source.json').read_text())['source_sha256'],'binary_sha256':build['binary_sha256'],'archive_sha256':sha(p),'archive_bytes':p.stat().st_size,'member_count':len(members),'members':members,'inherited_evidence':{name:sha(a/name) for name in ['replacement-final-source.tar.gz','replacement-final-source.json','replacement-final-evidence.tar.gz','replacement-final-evidence.json','replacement-final-validation.json']}}
receipt.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'}))
