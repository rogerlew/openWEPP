"""Charge the owner-reopened fixed window under the canonical ledger lock."""
from datetime import datetime, timezone
import fcntl, json, os
from pathlib import Path
art=Path('/workdir/openWEPP/docs/work-packages/20260920-cold-canopy-m1-001/artifacts')
p=art/'refusal-branch-completeness-accounting.json'
with (art/'refusal-branch-completeness-accounting.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 d=json.loads(p.read_text()); r=d['replacement_review_resumption_20261005']
 now=datetime.now(timezone.utc)
 charge=(now-datetime.fromisoformat(r['anchor_utc'])).total_seconds()
 cumulative=r['carry_seconds']+charge
 assert cumulative>=d['cumulative_charged_seconds']
 d.update(charged_through_utc=now.isoformat(), current_invocation_charge_seconds=charge, cumulative_charged_seconds=cumulative, remaining_seconds=d['ceiling_seconds']-cumulative, charge_method='Continuous concurrent wall once from21:54UTC Oct5, including all reading, work, waits, reviews, checks and preservation; inherited carry retained; no extension.')
 temp=p.with_suffix('.json.tmp')
 with temp.open('w') as f:
  json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(temp,p)
 fd=os.open(art,os.O_RDONLY);os.fsync(fd);os.close(fd)
 print(json.dumps({k:d[k] for k in ['charged_through_utc','cumulative_charged_seconds','remaining_seconds','work_cutoff_utc']}))
