"""Authenticate raw outputs for every exact-source check and inert control."""
from pathlib import Path
import hashlib,json
r=Path('/home/roger/openwepp-experiments/cold-canopy-m1-recovered-terminal-20261004')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((r/'checks/review01-no-run.json').read_text())['source_after']
labels=['p0','first_residual_h0','first_factor_scratch','second_residual_h1','second_factor_final']+[f'controls-{i}' for i in range(7)]
records=[]
for name in labels:
 p=r/f'checks/review01-{name}.json'
 for i,row in enumerate(json.loads(p.read_text())):
  assert row['exit']==0 and row['selected_one_test'] and row['source_before']==row['source_after']==source and row['physical_invocations']==0
  for suffix in ['stdout','stderr']:assert sha(p.with_name(p.stem+f'-{i}.{suffix}'))==row[suffix+'_sha256']
  records.append(row['command'][2])
assert len(records)==len(set(records))==32
for name in ['format','no-run','clippy-lse','clippy-vegetation']:
 p=r/f'checks/review01-{name}.json';row=json.loads(p.read_text());assert row['source_before']==row['source_after']==source and row['source_unchanged']
 assert row['exit']==(101 if name.startswith('clippy') else 0)
 for suffix in ['stdout','stderr']:assert sha(p.with_suffix('.'+suffix))==row[suffix+'_sha256']
result={'evidence_class':'Ran: independent raw-log hash authentication and exact-source receipt reconciliation','source_sha256':source,'inert_controls':len(records),'authenticated_control_raw_files':2*len(records),'authenticated_check_raw_files':8,'physical_invocations':0}
(r/'checks/review01-all-control-log-authentication.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
