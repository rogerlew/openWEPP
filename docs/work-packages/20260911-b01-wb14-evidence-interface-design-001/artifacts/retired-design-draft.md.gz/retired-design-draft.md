<!-- retired conflicting draft; replaced by the single specification below

The following technical draft is superseded in full by the consolidated
specification immediately before the execution ledger. It is retained only
until the rewrite is mechanically applied.

### Static source identity and resolved fixture provenance

Inspection was limited to the retained `reconciled-available145-r1` runtime
tree. Selected exact regular-file SHA-256 values are
`crates/openwepp-hillslope-orchestrator/src/lib.rs`
`489cb0bf3e6b271e4bb23908e56cf92f45782389b7234265f74e38bf31aca1f6`,
`direct_runtime/surface_liquid_ingress.rs`
`1826924b199e8a1ff7a42776ac99713b0b1bb01ab8207a1ea508cc1539096c29`,
`direct_runtime/surface_liquid_ingress_coordinator.rs`
`af0c281679e5b600e219eca487f3af93928f7eb2bdaaafdb1b47867115dec835`,
and runner `hillslope/05_runner_execution_and_outputs.rs`
`a1bcea3155c3724dea21678e4227af0be69fe1de6f272fdf820370b6c0ed6975`.
The runner test include surface is `hillslope/03_tests.rs`
`a4dbee9353a2905cbf069d9f3c7182b2654717c1114d5d528dd8a81a2d332b2e`;
the intended test file is `tests03/snow_accuracy_experiment.rs`
`ea5a1c412faab8f71e5def8099079a60c4d213d497e60205b1d74b2872520614`.
These match the predecessor actual-map scope; no full inventory was rerun.
The expanded spot-inspected set and its exact comparison to the predecessor
whole-source regular-file map are in
[`selected-source-identity.json`](artifacts/selected-source-identity.json).

The fixture is retained governing evidence, not a replacement runtime source:
`docs/work-packages/20260910-stage3-b01-snow-cycle-integration-001/artifacts/gradual-warm-tail7-cases.json`,
SHA-256 `c48cc560dff31102085ebcf852225b2063a1629ad96cfa9f7283364df44fbf3f`.
It defines seven authenticated forcing days, common constructor/no reset, and
the day-4--7 warm-tail continuation. Its bytes are required future test input.
The source-free formula at `surface_liquid_ingress_coordinator.rs:961-977`
computes the parent from authenticated `day_index * 48 + interval_index`:
`4 * 48 + 22 = 214`, so `[214*1800, 215*1800) = [385200,387000)` seconds.
The required prefix is `[385200,385920)` and transaction `255` must be observed
from the resulting parent receipt/clock, never injected by altering a clock,
ordinal, receipt, owner hash, or test fixture state.

Policy13 limits the zero-prefix assertion: native drainage preserves the full
WB14 continuation/interval/carry/markers and physical transaction markers, but
may update credited surface liquid, sensible-enthalpy high/carry, dependent
temperature, sealed owner digests, and a separately authenticated custody
history under the real parent/support/ordinal. Therefore the observation asserts
zero **WB14** calls, transitions, receipts, routing and WB14 cumulative-bit
deltas for the prefix; it must not assert every store or custody history is
unchanged. Source authority: `SC-SURFACELIQUID-001:2322-2385` and
`SC-SNOWENERGY-001:3908+`.

### Proposed feature-only facade (future write; not adopted)

Add `crates/openwepp-hillslope-orchestrator/src/restart_authority_evidence.rs`,
gated by `#[cfg(feature = "restart-authority-evidence")]`, and a matching
feature-gated `pub use` in `src/lib.rs` adjacent to the existing direct-runtime
exports (currently lines 196-205). The feature already exists with no default
activation in `Cargo.toml:10-13`; no manifest/default/CLI selector is proposed.
The facade is public because the runner is a separate crate; `pub(crate)`,
dependency `cfg(test)`, and `#[doc(hidden)]` do not make this cross-crate
boundary callable or safe.

```rust
pub struct Wb14EvidenceSession { /* private id + Drop cleanup */ }
pub struct Wb14EvidenceRequest {
    pub parent_transaction_id: TransactionId,
    pub day_index: usize,
    pub interval_index: usize,
    pub parent_support: (u128, u128),
    pub target_ofe: OfeId,
    pub target_lane_id: u32,
    pub phase: Wb14EvidencePhase, // BeforeAcceptedChildPublication
    pub child_ordinal: u32,
}
pub enum Wb14EvidencePhase { BeforeAcceptedChildPublication }
pub struct Wb14EvidenceSnapshot { /* immutable, fields below */ }
pub fn begin_wb14_evidence_session(request: Wb14EvidenceRequest)
  -> Result<Wb14EvidenceSession, Wb14EvidenceError>;
impl Wb14EvidenceSession {
  pub fn arm_one_shot_refusal(&mut self) -> Result<(), Wb14EvidenceError>;
  pub fn finish(self) -> Result<Wb14EvidenceSnapshot, Wb14EvidenceError>;
}
```

The concrete same-thread capability/cleanup design below supersedes this
summary. `begin` fails on any active session; `arm` is single-use; `finish`
consumes the handle, rejects unfired request and missing target, returns an
immutable clone, then clears state on unwind via `Drop`. Foreign session,
different parent/support/OFE/lane/ordinal, duplicate arm/fire, and stale state
are typed evidence errors. With no active session every hook is inert.

No physical owner, private constructor, proof type, mutable owner state, generic
callback, or arbitrary error constructor crosses this API. The only injected
error is an existing `Stage3V11FailureInjection` phase propagated through its
existing transaction unwind. This is diagnostic
control and immutable evidence, not another simulation path.

### Physical hooks, observation records, and refusal lifecycle

The total-call hook is immediately before the actual physical `advance_one_ofe`
call in `surface_liquid_ingress.rs:1203-1242`, replacing the test-only
`record_native_wb14_physics_entry_v1()` at line 1205 with a feature-only inert
observer call. Record every reached call before calculation, including a call
whose candidate later rejects: session id, parent transaction, day/interval,
parent and child support, OFE/lane, requested ordinal, candidate call sequence,
and beginning cumulative supply/infiltration bit patterns. Attribute only the
matching parent/session separately from other supports/lanes. Count accepted
child receipts independently only after receipt authentication and parent
advance; accepted receipt count is never a proxy for total physics calls.

The refusal hook is after all normal ingress/cadence/preflight validation and
after the real `advance_one_ofe`/routing candidate has made the selected child
observable, but before acceptance/publication of that child's receipt and before
the persistent parent final advance. Concrete wire location: immediately before
the `scalar_beginning` acceptance/receipt assembly beginning at
`surface_liquid_ingress.rs:1253`, with exact target matching against the coupled
binding constructed in `snow_stage3_v11_real_parent_execution.rs:181-202`.
The hook records `reached` first and, exactly once, emits the ordinary typed
candidate failure. Thus an earlier guard refusal, wrong target, skipped worker,
or zero-selected test cannot pass the negative case. Existing ingress errors
retain their ordered precedence; this proposal adds no passing guard or state
patch.

`Wb14EvidenceSnapshot` must contain: request identity; reached/fired booleans
and typed fired error code/phase; total call count by parent/OFE/lane and all
candidate records; accepted records with child ordinal/support, parent
transaction, OFE/lane/owner identities, authenticated receipt bytes and SHA-256;
prefix counters/transition/receipt/routing/cumulative-bit deltas; final-parent
advance count; and before/after immutable digests for the complete envelope
below. A successful nonzero control must observe at least one actual WB14 call
and accepted child; otherwise an unwired observer passes vacuously. A paired
hook-enabled/no-injection successful run must byte-compare scientific state,
receipts, accepted decisions, publication and output to the hook-disabled run.

### Exact two-layer future tests

Register the fresh-process runner test by retaining the existing include at
`crates/openwepp-runner/src/hillslope/03_tests.rs:49` and adding
`wb14_day4_interval22_transaction255_fresh_process_prefix_cadence_replay` in
`tests03/snow_accuracy_experiment.rs`, with
`#[ignore = "fresh process WB14 prefix/cadence authority"]`. It constructs the
seven-day case from the frozen JSON through the ordinary input/run constructors,
executes `execute_hillslope_run_with_runtime_policy` (existing direct calls at
`snow_accuracy_experiment.rs:155-162`), and self-spawns `current_exe()` when
`OPENWEPP_WB14_PREFIX_CADENCE_WORKER=1`. Parent requires child exit success and
exactly one named worker test; zero selected or skipped is failure. Use an
isolated run/output directory and target directory for each baseline-red and
candidate-green copy.

The private orchestrator layer adds feature-gated vectors at the existing
direct-runtime surfaces, principally
`surface_liquid_ingress_context_tests.rs` and
`surface_liquid_wb14_native_prefix_tests.rs`. It binds the same authenticated
fixture chronology and exact parent, observes: inert prefix `[385200,385920)`,
then 18 accepted suffix children per OFE with ordinals 0--17 in the declared
fixed-60-second complete-parent vector, and exactly one final persistent advance
to day 4 / interval 23. It must also contain (1) the nonzero control,
(2) hook/no-injection equality, (3) one-shot late refusal and foreign/wrong
target controls, (4) compound-poison ordered precedence, and (5) uninterrupted
versus split/restart replay. The fixed vector verifies the declared vector;
it must not force the authentic runner's adaptive controller to manufacture that
cadence. Both layers must be added and observed before any further cadence edit;
baseline red is retrospective failure evidence, and candidate green is later
matched evidence, not source adoption.

### Restart, rollback, independent operands, and complete future write envelope

Coordinator-only bytes are insufficient. The candidate parent is represented by
`DirectWb14ParentWorkingState` at
`surface_liquid_ingress_coordinator.rs:533-549`; its existing canonical
`restart_bytes`/`from_restart_bytes` boundary is lines 714-730 and includes
support, parameters, lanes, persistent/candidate surface owners, authorities and
finalizations. The outer snapshot must additionally preserve the complete
`V11ParentTransaction`, `DirectV10RealConsumerShadow`, `CoupledClockStateV1`,
Stage-3 attachment/runtime state, forcing/provider and GSI/event cursors,
accepted-history/archive and publication state, runner execution state, and
`HillslopeOutputTransaction` staged/private/final paths. The real parent tuple
is created and returned at `snow_stage3_v11_real_parent_execution.rs:6-29`; the
runner starts its output transaction at
`05_runner_execution_and_outputs.rs:2370-2408` and publishes outputs then
manifest at 2459-2505. Wire snapshot before execution of the selected candidate,
wire post-rejection comparison after transaction unwind and output rollback,
not merely a boolean diagnostic.

Before/after test comparisons require exact complete-owner and candidate bytes/
digests, parent candidates, coupled clock/provider/GSI/event cursor values,
accepted-history/publication state, and output transaction state. The refusal
case requires no final output, manifest, stage3 evidence, or staged evidence
file. Preserve and do not consume the existing historical cold checkpoint.

Independent closure records must retain operands from their actual immutable
owners: liquid mass and enthalpy from `DirectIngressAmount` and
`DirectOpenLiquidIngressParcel` (tile-ground basis, kg m^-2 and J kg^-1; source
definition `surface_liquid_ingress.rs:99-180`), area/topology/lane from
`DirectSurfaceLiquidConfiguration` bindings, accepted surface receipts and their
owner/source/destination identities, WB14 cumulative supply/infiltration from
the scalar authority, snow energy/material owner bytes, and coupled slab/parent
receipt digests. The independent test reconstructs water and energy with those
immutable inputs and authenticated transfer receipts on their stated area basis;
it does not reuse the production residual. Existing full-parent conservation
obligations remain required and unexecuted here.

The prospective implementation envelope is limited to the new facade module,
feature-gated `lib.rs` re-export, feature-gated observer/injection calls at the
two named ingress positions, execution-context propagation through the existing
Stage-3 worker path, the runner fresh-process test, and the private vectors.
It expressly excludes science-contract edits, solver/cadence math, manifests,
feature/default changes, CLI/runtime selectors, fixtures, substitution changes,
and production mutation APIs. Owner must adopt this envelope against the named
`reconciled-available145-r1` source before implementation.

### Prospective commands and static checks

All commands below are **NOT RUN**. Run only after owner adoption against paired
isolated `baseline-red` and `candidate-green` copies, with the frozen fixture
verified first:

```text
sha256sum docs/work-packages/20260910-stage3-b01-snow-cycle-integration-001/artifacts/gradual-warm-tail7-cases.json
nix develop /workdir/openWEPP --command env CARGO_TARGET_DIR=/tmp/openwepp-b01-wb14-interface/red RUST_MIN_STACK=67108864 cargo test --manifest-path /workdir/openwepp-experiments/b01-wb14-cadence/baseline-red/Cargo.toml -p openwepp-runner --lib --locked --release --features test-fixture-authority,openwepp-hillslope-orchestrator/persisted-restart-v1,openwepp-hillslope-orchestrator/restart-authority-evidence hillslope::tests::wb14_day4_interval22_transaction255_fresh_process_prefix_cadence_replay -- --ignored --exact --nocapture
nix develop /workdir/openWEPP --command env CARGO_TARGET_DIR=/tmp/openwepp-b01-wb14-interface/candidate RUST_MIN_STACK=67108864 cargo test --manifest-path /workdir/openwepp-experiments/b01-wb14-cadence/candidate-green/Cargo.toml -p openwepp-runner --lib --locked --release --features test-fixture-authority,openwepp-hillslope-orchestrator/persisted-restart-v1,openwepp-hillslope-orchestrator/restart-authority-evidence hillslope::tests::wb14_day4_interval22_transaction255_fresh_process_prefix_cadence_replay -- --ignored --exact --nocapture
```

The implementation package must add exact private-vector commands after concrete
test names exist, then run applicable feature compile/tests, required authority
anti-evasion guards, matched red/green observations, and the parent-selected
current validation lifecycle. These are future acceptance obligations, not this
design checkpoint's results.

### Design result and remaining acceptance

Static design result: **BLOCKED pending owner adoption and independent review**.
The cross-crate visibility, session lifecycle, total-call location, exact
fixture provenance, runner registration, rollback envelope and independent
operands now have concrete proposed surfaces. No Rust execution occurred. The
two historical test substitutions remain UNKNOWN and unchanged. Required before
this record can support implementation: independent correctness and QA/evidence
reviews of this design, owner decision on the explicitly limited envelope, and
future matched execution evidence. Source adoption, cadence repair, wider
modeling and release remain HOLD.

### Integration-corrected concrete design

Use the existing `pub(crate) Stage3V11FailureInjection` at
`snow_stage3_v11_attachment.rs:2811-2819`; do not create a
`DirectSurfaceLiquidError`. The exact three reusable late phases are
`OutcomeLedgerBuilt(usize)` (adaptive execution 2510-2517),
`SubslabAccepted(usize)` (2575-2584), and `FinalOwnerJoinCompleted` (the
existing stack-helper hook immediately before `parent.finalize_with_validated_handoff`,
not after finalization). The fixture refusal selects `OutcomeLedgerBuilt` with
its **one-based coupled accepted ordinal**. That ordinal is distinct from the
WB14 child ordinal: preserve both in the immutable record; never infer one from
the other. `OutcomeLedgerBuilt` is reached after the actual accepted receipt
exists and before owner-join commit; `SubslabAccepted` is a composed rollback
control after `owner_joins.extend`; `FinalOwnerJoinCompleted` is the enclosing
finalization-boundary control. All three reuse their existing typed
`DirectSnowStage3V11AttachmentError` unwind.

The existing ingress loop observer at `surface_liquid_ingress.rs:1203-1205` is
only a broad *entry attempt*: failures in lookup/route/validation before
`advance_one_ofe` at 1233 are not physical WB14 computation. Retain a separate
attempt counter there, and place the required physical-transition counter at
the successful lower-boundary transition inside `advance_one_ofe` (currently
the solver/boundary window block around line 2250), after input validation and
immediately before its first WB14 continuation advance. Record rejects after
that point too. Thus prefix proof requires zero attempts and zero transitions;
suffix control requires nonzero transitions; candidate rejection before physics
cannot be misreported as a physics call.

The facade's concrete private capability is
`struct SessionId(NonZeroU64);`, generated by a private process-local
`AtomicU64` monotonic sequence (reject zero); its constructor/value never cross
the facade. This is a nonconstructible capability, not a cryptographic token,
and needs no new dependency. The reached production call chain has no
`spawn`/rayon use in runner05, `snow_accuracy_experiment`, attachment runtime,
adaptive execution, stack helpers, or real-parent execution. Therefore use
thread-local `RefCell<Option<ActiveSession>>` *only after beginning the session
inside the fresh worker process/test thread*; private vector tests that use
`std::thread::Builder` move a nonconstructible guard into the spawned closure
and begin there. `Wb14EvidenceSession::Drop` clears its matching entry.
The runner call
is synchronous through `execute_selected_hillslope_days` at
`05_runner_execution_and_outputs.rs:2398-2408` and Stage-3 callback at 482-500.
Fresh-process test parent spawns only when `OPENWEPP_WB14_PREFIX_CADENCE_WORKER`
is absent/not `1`; the child (where it equals `1`) independently begins its
session before `execute_hillslope_run_with_runtime_policy` and returns a
create-new snapshot file. No thread-local or cross-process propagation claim is
made.

Fixture derivation is exact: future worker invokes the existing ignored
`hillslope::tests::stage3_snow_accuracy_case` machinery in
`snow_accuracy_experiment.rs:1-185`, with `OPENWEPP_ACCURACY_CASES` pointing to
the frozen JSON and case `gradual_warm_tail7`. It selects the case (28-30),
writes all seven authenticated rows to `p102.cli` (61-82), uses
`prepare_native_stage3_lane_d_scale_fixture` (53-56), then authenticates the
seed with `author_stage3_v11_owner_seed_fixture` (91-105). It must replay
days 1--3; it may not write a target clock or receipt. The historical cold
checkpoint remains unconsumed. The only supported split wire is
`native_custody_restart_experiment::Workflow::project` lines 80-137 and
`restore` 139-157, wired in runner 379-395 and 600-649; it serializes the
authentic prefix and restores through `DirectHydrologyNativeCustodyRestartV1`,
not a synthetic transaction-255 checkpoint.

Exact future test registration: add runner
`wb14_day4_interval22_transaction255_fresh_process_prefix_cadence_replay` to
`tests03/snow_accuracy_experiment.rs`, already included by `03_tests.rs:49`;
add private `direct_runtime/surface_liquid_wb14_evidence_tests.rs` with
`wb14_evidence_fixed_60s_prefix_zero_suffix_18_and_final_advance`,
`wb14_evidence_outcome_ledger_18_rolls_back_complete_outer_frame`, and
`wb14_evidence_hook_disabled_equals_armed_without_injection`, registered in the
direct-runtime test include surface. Required future preservation commands are
`cargo nextest run --test land_surface_energy_real_hydrology_shadow_contract -- precedence_tests:: --exact` and the same command with `raw_hash_tests::`;
both are NOT RUN and protect all 18 and four existing assertions.

The explicit prospective write list is new
`src/restart_authority_evidence.rs`; feature-gated module/re-export in
`src/lib.rs`; feature bridge around private enum in
`src/snow_stage3_v11_attachment.rs`; records only at existing phase hooks in
`src/snow_stage3_v11_adaptive_execution.rs` and physical transition in
`src/direct_runtime/surface_liquid_ingress.rs`; runner test and existing
`03_tests.rs`; plus the named private vector module/registration. Any runner
collection helper is limited to `05_runner_execution_and_outputs.rs`.
No manifest, feature declaration/default, CLI, fixture, science or solver write
is authorized.

The outer oracle runs only after the runner call has returned `Err` and the
output transaction has been dropped/unwound; it then checks final/staged output,
manifest and stage3-evidence paths are absent. It uses actual values, not only digests: the existing workflow
comparison enumerates `DirectRunFrame` fields `identity`, `lanes`, `phase_plan`,
`publication`, `lane_transfer_ledger`, `lane_transfer_downstream_operands`,
`lane_transfer_shadow_projection`, `groundwater`, `surface_liquid_shadow`,
`snow_stage3_v11_attachment`, `laned_active`, and `laned_active_summary`
(`native_custody_restart_experiment.rs:117-135`). Add output transaction
staged/final/evidence/manifest absence and bytes. Independent operands are
`DirectIngressAmount.mass_kg_m2_tile_ground`, `temperature_k`,
`specific_liquid_enthalpy_j_kg`; receipt mass/enthalpy on `kg m^-2
OFE-ground`/`J m^-2 OFE-ground`; topology area `m^2`; WB14 cumulative
supply/infiltration `m`; and sealed snow energy/material owner and transfer
receipt bytes. Reconstruct water and energy by OFE/support from those inputs,
not the production residual.

-->