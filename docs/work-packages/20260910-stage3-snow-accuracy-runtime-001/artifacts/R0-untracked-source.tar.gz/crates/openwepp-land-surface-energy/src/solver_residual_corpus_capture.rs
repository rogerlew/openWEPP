//! Bounded, test-support-only capture of authentic covered Jacobian bases.
//!
//! Capture clones the already-computed base. It never invokes the scientific
//! evaluator and is deliberately unavailable in ordinary production builds.
#![allow(clippy::missing_errors_doc)]

use crate::{
    CoveredColumnEvaluation, CoveredColumnInputs, CoveredFrozenBranches, CoveredWaterCaps,
    solver_mechanism_audit::LifecycleIdentity,
};
use serde::{Deserialize, Serialize};
use std::{cell::RefCell, marker::PhantomData, rc::Rc};

pub const SCHEMA: &str = "openwepp.covered-residual-corpus.v2";
const MAX_EDGE_RECORDS_PER_PASS: usize = 64;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Pass {
    Potential,
    FixedFinal,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum Family {
    Covered,
    GenericV3,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct V3Capture {
    pub context: crate::V3LitterResidualContext,
    pub evaluation: crate::V3PhaseFreeCoveredEvaluation,
    pub scaled_x_bits: Vec<u64>,
    pub coordinate_scale_bits: Vec<u64>,
    pub scaled_unit_bits: Vec<u64>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Snapshot {
    pub family: Family,
    pub v3: Option<V3Capture>,
    pub lifecycle: LifecycleIdentity,
    pub pass: Pass,
    pub inputs: CoveredColumnInputs,
    pub caps: Option<CoveredWaterCaps>,
    pub x_bits: Vec<u64>,
    pub frozen: CoveredFrozenBranches,
    pub base_evaluation: CoveredColumnEvaluation,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Corpus {
    pub schema: String,
    pub first: Vec<Snapshot>,
    pub last: Vec<Snapshot>,
    pub participation: Vec<Participation>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Counts {
    pub started: u64,
    pub completed: u64,
    pub failed: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Participation {
    pub family: Family,
    pub pass: Pass,
    /// solve, sweep, or a canonical component group (sun/shade/wet/stem/other).
    pub group: String,
    /// Positive/zero executed component area, or not_applicable for other coordinates.
    pub area: String,
    /// lifecycle, finite_difference, or identity_anchor.
    pub method: String,
    pub counts: Counts,
    pub expected_columns: u64,
    pub completed_sweep_columns: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
pub enum CaptureError {
    #[error("residual corpus capture already active on this thread")]
    AlreadyActive,
    #[error("residual corpus capture is not active")]
    NotActive,
    #[error("residual corpus capture has live observation scopes")]
    LiveScopes,
    #[error("residual corpus capture bound is outside 1..=64")]
    InvalidBound,
    #[error("residual corpus capture counter overflow")]
    Overflow,
    #[error("residual corpus snapshot is invalid: {0}")]
    InvalidSnapshot(&'static str),
    #[error("residual corpus wire encoding is malformed: {0}")]
    MalformedWire(String),
}

impl Corpus {
    pub fn to_wire_bytes(&self) -> Result<Vec<u8>, CaptureError> {
        self.validate()?;
        let mut value = serde_json::to_value(self)
            .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
        encode_float_bits(&mut value)?;
        serde_json::to_vec_pretty(&value)
            .map_err(|error| CaptureError::MalformedWire(error.to_string()))
    }

    pub fn from_wire_bytes(bytes: &[u8]) -> Result<Self, CaptureError> {
        let mut value: serde_json::Value = serde_json::from_slice(bytes)
            .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
        decode_float_bits(&mut value)?;
        let corpus: Self = serde_json::from_value(value)
            .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
        corpus.validate()?;
        Ok(corpus)
    }

    pub fn validate(&self) -> Result<(), CaptureError> {
        if self.schema != SCHEMA {
            return Err(CaptureError::InvalidSnapshot("schema version"));
        }
        if self.first.is_empty() && self.last.is_empty() {
            return Err(CaptureError::InvalidSnapshot("empty corpus"));
        }
        if self.first.len() > 4 * MAX_EDGE_RECORDS_PER_PASS
            || self.last.len() > 4 * MAX_EDGE_RECORDS_PER_PASS
        {
            return Err(CaptureError::InvalidSnapshot("snapshot bound"));
        }
        for snapshot in self.first.iter().chain(&self.last) {
            snapshot.validate()?;
            if !self.participation.iter().any(|row| {
                row.family == snapshot.family && row.pass == snapshot.pass && row.group == "sweep"
            }) {
                return Err(CaptureError::InvalidSnapshot(
                    "snapshot without participation",
                ));
            }
        }
        self.validate_participation()?;
        Ok(())
    }

    fn validate_participation(&self) -> Result<(), CaptureError> {
        // Two passes: Covered has 2 lifecycle + 9 area groups * 2 methods;
        // GenericV3 has 2 lifecycle + 9 area groups * 1 method.
        if self.participation.len() > 62 {
            return Err(CaptureError::InvalidSnapshot("participation bound"));
        }
        for (index, row) in self.participation.iter().enumerate() {
            let lifecycle = matches!(row.group.as_str(), "solve" | "sweep");
            let component = matches!(row.group.as_str(), "sun" | "shade" | "wet" | "stem");
            let valid = if lifecycle {
                row.area == "not_applicable" && row.method == "lifecycle"
            } else {
                ((component && matches!(row.area.as_str(), "positive" | "zero"))
                    || (row.group == "other" && row.area == "not_applicable"))
                    && (row.method == "finite_difference"
                        || (row.family == Family::Covered && row.method == "identity_anchor"))
            };
            if !valid
                || row.counts.started == 0
                || row.counts.completed.checked_add(row.counts.failed) != Some(row.counts.started)
                || (row.group != "sweep"
                    && (row.expected_columns != 0 || row.completed_sweep_columns != 0))
                || row.completed_sweep_columns > row.expected_columns
                || self.participation[..index].iter().any(|other| {
                    other.family == row.family
                        && other.pass == row.pass
                        && other.group == row.group
                        && other.area == row.area
                        && other.method == row.method
                })
            {
                return Err(CaptureError::InvalidSnapshot("participation bucket/counts"));
            }
        }
        for family in [Family::Covered, Family::GenericV3] {
            for pass in [Pass::Potential, Pass::FixedFinal] {
                let rows: Vec<_> = self
                    .participation
                    .iter()
                    .filter(|row| row.family == family && row.pass == pass)
                    .collect();
                let sum = |completed: bool| {
                    rows.iter()
                        .filter(|row| row.method != "lifecycle")
                        .try_fold(0_u64, |total, row| {
                            total.checked_add(if completed {
                                row.counts.completed
                            } else {
                                row.counts.started
                            })
                        })
                        .ok_or(CaptureError::Overflow)
                };
                let columns = sum(false)?;
                let completed = sum(true)?;
                let sweep = rows.iter().find(|row| row.group == "sweep");
                if let Some(sweep) = sweep {
                    if columns > sweep.expected_columns
                        || completed < sweep.completed_sweep_columns
                        || (sweep.counts.failed == 0
                            && (columns != sweep.expected_columns
                                || completed != columns
                                || sweep.completed_sweep_columns != sweep.expected_columns))
                        || !rows.iter().any(|row| row.group == "solve")
                    {
                        return Err(CaptureError::InvalidSnapshot(
                            "sweep dimension/column reconciliation",
                        ));
                    }
                } else if columns != 0 {
                    return Err(CaptureError::InvalidSnapshot("columns without sweeps"));
                }
            }
        }
        Ok(())
    }
}

fn encode_float_bits(value: &mut serde_json::Value) -> Result<(), CaptureError> {
    match value {
        serde_json::Value::Number(number) if number.is_f64() => {
            let float = number
                .as_f64()
                .ok_or_else(|| CaptureError::MalformedWire("invalid JSON float".to_owned()))?;
            if !float.is_finite() {
                return Err(CaptureError::InvalidSnapshot("nonfinite float"));
            }
            *value = serde_json::json!({"$f64_bits": format!("{:016x}", float.to_bits())});
        }
        serde_json::Value::Array(values) => {
            for value in values {
                encode_float_bits(value)?;
            }
        }
        serde_json::Value::Object(values) => {
            for value in values.values_mut() {
                encode_float_bits(value)?;
            }
        }
        _ => {}
    }
    Ok(())
}

fn decode_float_bits(value: &mut serde_json::Value) -> Result<(), CaptureError> {
    if let serde_json::Value::Object(values) = value {
        if values.len() == 1 && values.contains_key("$f64_bits") {
            let bits = values["$f64_bits"]
                .as_str()
                .filter(|text| {
                    text.len() == 16 && text.bytes().all(|byte| byte.is_ascii_hexdigit())
                })
                .ok_or_else(|| CaptureError::MalformedWire("invalid f64 bit word".to_owned()))?;
            let bits = u64::from_str_radix(bits, 16)
                .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
            let float = f64::from_bits(bits);
            if !float.is_finite() {
                return Err(CaptureError::InvalidSnapshot("nonfinite float"));
            }
            *value = serde_json::Value::Number(
                serde_json::Number::from_f64(float)
                    .ok_or(CaptureError::InvalidSnapshot("nonfinite float"))?,
            );
            return Ok(());
        }
    }
    match value {
        serde_json::Value::Array(values) => {
            for value in values {
                decode_float_bits(value)?;
            }
        }
        serde_json::Value::Object(values) => {
            for value in values.values_mut() {
                decode_float_bits(value)?;
            }
        }
        _ => {}
    }
    Ok(())
}

impl Snapshot {
    pub fn validate(&self) -> Result<(), CaptureError> {
        if (self.family == Family::GenericV3) != self.v3.is_some() {
            return Err(CaptureError::InvalidSnapshot("family/context mismatch"));
        }
        if let Some(v3) = &self.v3 {
            if (self.pass == Pass::FixedFinal) != v3.context.finalized_vapor.is_some()
                || v3.evaluation.predecessor != self.base_evaluation
            {
                return Err(CaptureError::InvalidSnapshot(
                    "V3 context/evaluation mismatch",
                ));
            }
        }
        if let Some(v3) = &self.v3 {
            if v3.scaled_x_bits.len() != self.x_bits.len()
                || v3.coordinate_scale_bits.len() != self.x_bits.len()
                || v3.scaled_unit_bits.len() != self.x_bits.len()
            {
                return Err(CaptureError::InvalidSnapshot("V3 coordinate cardinality"));
            }
            for index in 0..self.x_bits.len() {
                let scaled = f64::from_bits(v3.scaled_x_bits[index]);
                let scale = f64::from_bits(v3.coordinate_scale_bits[index]);
                let unit = f64::from_bits(v3.scaled_unit_bits[index]);
                if !scaled.is_finite()
                    || !scale.is_finite()
                    || scale <= 0.0
                    || !unit.is_finite()
                    || unit <= 0.0
                    || (scaled * scale).to_bits() != self.x_bits[index]
                {
                    return Err(CaptureError::InvalidSnapshot("V3 coordinate conversion"));
                }
            }
        }
        let occupancy_count = self.inputs.occupancies.len();
        let soil_count = self.inputs.ground.soil_nodes.len();
        let expected = occupancy_count
            .checked_mul(10)
            .and_then(|value| value.checked_add(3))
            .and_then(|value| value.checked_add(soil_count))
            .ok_or(CaptureError::InvalidSnapshot("D overflow"))?;
        if occupancy_count == 0 || soil_count == 0 || self.x_bits.len() != expected {
            return Err(CaptureError::InvalidSnapshot("D != 10N+3+S"));
        }
        if self
            .x_bits
            .iter()
            .any(|bits| !f64::from_bits(*bits).is_finite())
        {
            return Err(CaptureError::InvalidSnapshot("nonfinite trial coordinate"));
        }
        if self.base_evaluation.raw_residuals.len() != expected
            || self.base_evaluation.normalized_residuals.len() != expected
            || self.base_evaluation.tolerances.len() != expected
            || self.base_evaluation.occupancies.len() != occupancy_count
            || self.base_evaluation.soil_temperature_k.len() != soil_count
        {
            return Err(CaptureError::InvalidSnapshot("base evaluation cardinality"));
        }
        if (self.pass == Pass::FixedFinal) != self.caps.is_some() {
            return Err(CaptureError::InvalidSnapshot("pass/caps mismatch"));
        }
        if self.lifecycle.scope == 0
            || self.lifecycle.solve.is_none()
            || self.lifecycle.parent.is_none()
        {
            return Err(CaptureError::InvalidSnapshot("lifecycle join"));
        }
        if let Some(caps) = &self.caps {
            let expected_root_keys =
                self.inputs
                    .occupancies
                    .iter()
                    .flat_map(|occupancy| {
                        occupancy.root_layers.iter().map(move |layer| {
                            (occupancy.occupancy_id.clone(), layer.layer_id.clone())
                        })
                    })
                    .collect::<std::collections::BTreeSet<_>>();
            if caps
                .root
                .keys()
                .cloned()
                .collect::<std::collections::BTreeSet<_>>()
                != expected_root_keys
            {
                return Err(CaptureError::InvalidSnapshot("cap root keys"));
            }
        }
        Ok(())
    }

    /// Re-evaluate the captured family with its original complete frozen context.
    pub fn replay(&self) -> Result<(), CaptureError> {
        self.validate()?;
        let x: Vec<f64> = self
            .x_bits
            .iter()
            .map(|bits| f64::from_bits(*bits))
            .collect();
        let (actual, expected) = if let Some(v3) = &self.v3 {
            let actual = crate::evaluate_v3_phase_free_covered_column(
                &self.inputs,
                &x,
                self.caps.as_ref(),
                Some(&self.frozen),
                v3.context,
            )
            .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
            (
                serde_json::to_value(actual),
                serde_json::to_value(&v3.evaluation),
            )
        } else {
            let actual = crate::evaluate_covered_column(
                &self.inputs,
                &x,
                self.caps.as_ref(),
                Some(&self.frozen),
            )
            .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
            (
                serde_json::to_value(actual),
                serde_json::to_value(&self.base_evaluation),
            )
        };
        let mut actual = actual.map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
        let mut expected =
            expected.map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
        encode_float_bits(&mut actual)?;
        encode_float_bits(&mut expected)?;
        if actual != expected {
            return Err(CaptureError::InvalidSnapshot("base replay bits"));
        }
        Ok(())
    }
}

/// Bounded test-support evidence; the full-supply Covered FixedFinal vector is
/// constructed solely for observer equivalence, never authentic performance.
#[derive(Clone, Debug, Serialize)]
pub struct SolverObserverEvidence {
    pub family: Family,
    pub pass: Pass,
    pub fixture: String,
    pub success_counts: Vec<Participation>,
    pub failure_counts: Vec<Participation>,
}

#[derive(Debug, PartialEq)]
enum ObserverSolveResult {
    Covered(Result<crate::CoveredColumnSolveOutcome, crate::LandSurfaceEnergyError>),
    V3(
        Result<
            crate::NormalizedSolveOutcome<crate::V3PhaseFreeCoveredEvaluation>,
            crate::LandSurfaceEnergyError,
        >,
    ),
}

fn failure_value(failure: &crate::NumericalFailure) -> serde_json::Value {
    let crate::NumericalFailure {
        kind,
        iterations,
        normalized_residuals,
        ordered_residuals,
        failed_solution,
        occupancy_id,
        active_bounds,
        backtracking_count,
        step_norms,
        pivot_magnitude,
        matrix_norm,
    } = failure;
    serde_json::json!({"kind": format!("{kind:?}"), "iterations": iterations,
        "normalized_residuals": normalized_residuals, "ordered_residuals": ordered_residuals,
        "failed_solution": failed_solution, "occupancy_id": occupancy_id,
        "active_bounds": active_bounds, "backtracking_count": backtracking_count,
        "step_norms": step_norms, "pivot_magnitude": pivot_magnitude, "matrix_norm": matrix_norm})
}

impl ObserverSolveResult {
    fn accepted(&self) -> bool {
        matches!(
            self,
            Self::Covered(Ok(crate::CoveredColumnSolveOutcome::Accepted(_)))
                | Self::V3(Ok(crate::NormalizedSolveOutcome::Accepted { .. }))
        )
    }
    fn typed_error(&self) -> bool {
        matches!(self, Self::Covered(Err(_)) | Self::V3(Err(_)))
    }
    fn bits(&self) -> Result<Vec<u8>, CaptureError> {
        let mut value = match self {
            Self::Covered(Err(error)) | Self::V3(Err(error)) => {
                serde_json::json!({"error": error.to_string()})
            }
            Self::Covered(Ok(crate::CoveredColumnSolveOutcome::Rejected(failure)))
            | Self::V3(Ok(crate::NormalizedSolveOutcome::Rejected(failure))) => {
                failure_value(failure)
            }
            Self::Covered(Ok(crate::CoveredColumnSolveOutcome::Accepted(candidate))) => {
                let crate::CoveredColumnCandidate {
                    solution,
                    evaluation,
                    surface_enthalpy_j_m2_tile,
                    soil_temperature_k,
                    root_water,
                    ground_water,
                    iterations,
                    backtracking_count,
                    step_norms,
                } = candidate.as_ref();
                let crate::CoveredStepNorms {
                    hydraulic_mm,
                    beta,
                    temperature_k,
                    humidity_kg_kg,
                    ci_pa,
                } = step_norms;
                serde_json::json!({"solution": solution, "evaluation": evaluation,
                    "surface_enthalpy_j_m2_tile": surface_enthalpy_j_m2_tile,
                    "soil_temperature_k": soil_temperature_k, "root_water": root_water,
                    "ground_water": ground_water, "iterations": iterations,
                    "backtracking_count": backtracking_count,
                    "step_norms": [hydraulic_mm, beta, temperature_k, humidity_kg_kg, ci_pa]})
            }
            Self::V3(Ok(crate::NormalizedSolveOutcome::Accepted {
                solution,
                detail,
                iterations,
                residual_norm_history,
                backtracking_count,
                step_norm,
                pivot_magnitude,
                matrix_norm,
            })) => {
                serde_json::json!({"solution": solution, "detail": detail, "iterations": iterations,
                    "residual_norm_history": residual_norm_history, "backtracking_count": backtracking_count,
                    "step_norm": step_norm, "pivot_magnitude": pivot_magnitude, "matrix_norm": matrix_norm})
            }
        };
        encode_float_bits(&mut value)?;
        serde_json::to_vec(&value).map_err(|error| CaptureError::MalformedWire(error.to_string()))
    }
}

fn observer_solve(
    snapshot: &Snapshot,
    trial: &[f64],
    caps: Option<&CoveredWaterCaps>,
) -> ObserverSolveResult {
    if let Some(v3) = &snapshot.v3 {
        ObserverSolveResult::V3(crate::solve_v3_phase_free_covered_column(
            &snapshot.inputs,
            caps,
            trial,
            v3.context,
        ))
    } else {
        ObserverSolveResult::Covered(crate::solver::solve_covered_column(
            &snapshot.inputs,
            caps,
            trial.to_vec(),
        ))
    }
}

fn observer_input_bits(
    snapshot: &Snapshot,
    trial: &[f64],
    caps: Option<&CoveredWaterCaps>,
) -> Result<Vec<u8>, CaptureError> {
    let mut value = serde_json::json!({"inputs": &snapshot.inputs, "caps": caps,
        "trial_bits": trial.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
        "context": snapshot.v3.as_ref().map(|v3| v3.context)});
    encode_float_bits(&mut value)?;
    serde_json::to_vec(&value).map_err(|error| CaptureError::MalformedWire(error.to_string()))
}

fn observer_pair(
    snapshot: &Snapshot,
    trial: &[f64],
    caps: Option<&CoveredWaterCaps>,
    failing: bool,
) -> Result<Vec<Participation>, CaptureError> {
    let immutable = observer_input_bits(snapshot, trial, caps)?;
    let audit = crate::solver_mechanism_audit::begin_mechanism_audit(false, 0)
        .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
    let off = observer_solve(snapshot, trial, caps);
    audit
        .finish()
        .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
    if observer_input_bits(snapshot, trial, caps)? != immutable {
        return Err(CaptureError::InvalidSnapshot(
            "capture-off mutated solver inputs",
        ));
    }
    let audit = crate::solver_mechanism_audit::begin_mechanism_audit(false, 0)
        .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
    let capture = begin(1)?;
    let on = observer_solve(snapshot, trial, caps);
    let corpus = capture.finish()?;
    audit
        .finish()
        .map_err(|error| CaptureError::MalformedWire(error.to_string()))?;
    if observer_input_bits(snapshot, trial, caps)? != immutable
        || off != on
        || off.bits()? != on.bits()?
    {
        return Err(CaptureError::InvalidSnapshot(
            "solver observer outcome/input neutrality",
        ));
    }
    if failing != on.typed_error() || (!failing && !on.accepted()) {
        return Err(CaptureError::InvalidSnapshot(
            "solver observer fixture outcome",
        ));
    }
    let solves: Vec<_> = corpus
        .participation
        .iter()
        .filter(|row| row.group == "solve")
        .collect();
    if solves.len() != 1
        || solves[0].counts
            != (Counts {
                started: 1,
                completed: u64::from(!failing),
                failed: u64::from(failing),
            })
        || (failing && corpus.participation.iter().any(|row| row.group != "solve"))
    {
        return Err(CaptureError::InvalidSnapshot(
            "solver observer scope reconciliation",
        ));
    }
    Ok(corpus.participation)
}

/// Paired solver checks with the same optional mechanism-audit posture and only
/// residual capture toggled. No scientific selector or solver control is altered.
pub fn verify_solver_observer_neutrality(
    corpus: &Corpus,
) -> Result<Vec<SolverObserverEvidence>, CaptureError> {
    corpus.validate()?;
    let find = |family, pass| {
        corpus
            .first
            .iter()
            .chain(&corpus.last)
            .find(|snapshot| snapshot.family == family && snapshot.pass == pass)
            .ok_or(CaptureError::InvalidSnapshot(
                "observer fixture family/pass absent",
            ))
    };
    let covered = find(Family::Covered, Pass::Potential)?;
    let trial: Vec<_> = covered
        .x_bits
        .iter()
        .map(|bits| f64::from_bits(*bits))
        .collect();
    let ObserverSolveResult::Covered(Ok(crate::CoveredColumnSolveOutcome::Accepted(potential))) =
        observer_solve(covered, &trial, None)
    else {
        return Err(CaptureError::InvalidSnapshot(
            "full-supply test-vector potential solve",
        ));
    };
    let rate = |mass| mass / (covered.inputs.tile_fraction * covered.inputs.interval_s);
    let cap = |request| crate::SourceWaterCap {
        request_rate_kg_m2_tile_s: request,
        authorization_rate_kg_m2_tile_s: request,
    };
    let caps = CoveredWaterCaps {
        root: potential
            .root_water
            .iter()
            .map(|source| {
                (
                    (source.occupancy_id.clone(), source.layer_id.clone()),
                    cap(rate(source.request_kg_m2_stand_ground)),
                )
            })
            .collect(),
        ground: cap(rate(potential.ground_water.request_kg_m2_stand_ground)),
    };
    let mut evidence = Vec::new();
    for (snapshot, pass, caps, fixture) in [
        (covered, Pass::Potential, None, "authentic_sweep_restart"),
        (
            covered,
            Pass::FixedFinal,
            Some(&caps),
            "test_local_full_supply_caps_not_authentic_performance",
        ),
        (
            find(Family::GenericV3, Pass::Potential)?,
            Pass::Potential,
            None,
            "authentic_sweep_restart",
        ),
        (
            find(Family::GenericV3, Pass::FixedFinal)?,
            Pass::FixedFinal,
            find(Family::GenericV3, Pass::FixedFinal)?.caps.as_ref(),
            "authentic_sweep_restart",
        ),
    ] {
        let trial: Vec<_> = snapshot
            .x_bits
            .iter()
            .map(|bits| f64::from_bits(*bits))
            .collect();
        let success_counts = observer_pair(snapshot, &trial, caps, false)?;
        let mut invalid = trial;
        invalid[0] = f64::NAN; // Shape remains admitted; evaluator fails after solve entry.
        let failure_counts = observer_pair(snapshot, &invalid, caps, true)?;
        evidence.push(SolverObserverEvidence {
            family: snapshot.family,
            pass,
            fixture: fixture.into(),
            success_counts,
            failure_counts,
        });
    }
    Ok(evidence)
}

struct State {
    generation: Rc<()>,
    live: u64,
    edge: usize,
    first: [Vec<Snapshot>; 4],
    last: [Vec<Snapshot>; 4],
    seen: [u64; 4],
    participation: Vec<Participation>,
    current: Option<(Family, Pass, Vec<[f64; 4]>, usize)>,
    overflow: bool,
}

thread_local! { static ACTIVE: RefCell<Option<State>> = const { RefCell::new(None) }; }

pub struct Session {
    generation: Rc<()>,
    _thread: PhantomData<Rc<()>>,
}

pub fn begin(edge_records_per_pass: usize) -> Result<Session, CaptureError> {
    if !(1..=MAX_EDGE_RECORDS_PER_PASS).contains(&edge_records_per_pass) {
        return Err(CaptureError::InvalidBound);
    }
    ACTIVE.with(|active| {
        let mut active = active.borrow_mut();
        if active.is_some() {
            return Err(CaptureError::AlreadyActive);
        }
        let generation = Rc::new(());
        *active = Some(State {
            generation: Rc::clone(&generation),
            live: 0,
            edge: edge_records_per_pass,
            first: std::array::from_fn(|_| Vec::new()),
            last: std::array::from_fn(|_| Vec::new()),
            seen: [0; 4],
            participation: Vec::new(),
            current: None,
            overflow: false,
        });
        Ok(Session {
            generation,
            _thread: PhantomData,
        })
    })
}

pub(crate) fn record(snapshot: Snapshot) {
    ACTIVE.with(|active| {
        let mut active = active.borrow_mut();
        let Some(state) = active.as_mut() else { return };
        let index = usize::from(snapshot.pass == Pass::FixedFinal)
            + 2 * usize::from(snapshot.family == Family::GenericV3);
        state.current = Some((
            snapshot.family,
            snapshot.pass,
            snapshot
                .base_evaluation
                .occupancies
                .iter()
                .map(|o| o.component_areas_m2_m2_tile)
                .collect(),
            snapshot.x_bits.len(),
        ));
        let Some(seen) = state.seen[index].checked_add(1) else {
            state.overflow = true;
            return;
        };
        state.seen[index] = seen;
        if state.first[index].len() < state.edge {
            state.first[index].push(snapshot);
        } else {
            if state.last[index].len() == state.edge {
                state.last[index].remove(0);
            }
            state.last[index].push(snapshot);
        }
    });
}

pub(crate) fn is_active() -> bool {
    ACTIVE.with(|active| active.borrow().is_some())
}

/// Drop records an incomplete/error lifecycle; success is explicit at the real boundary.
pub(crate) struct Observation {
    index: Option<usize>,
    clear_sweep: bool,
    generation: Option<Rc<()>>,
    dimension: u64,
}

fn increment(value: &mut u64, overflow: &mut bool) {
    if let Some(next) = value.checked_add(1) {
        *value = next;
    } else {
        *overflow = true;
    }
}

fn start(family: Family, pass: Pass, group: &str, area: &str, method: &str) -> Observation {
    let mut generation = None;
    let mut dimension = 0;
    let index = ACTIVE.with(|active| {
        let mut active = active.borrow_mut();
        let state = active.as_mut()?;
        let index = state
            .participation
            .iter()
            .position(|row| {
                row.family == family
                    && row.pass == pass
                    && row.group == group
                    && row.area == area
                    && row.method == method
            })
            .unwrap_or_else(|| {
                state.participation.push(Participation {
                    family,
                    pass,
                    group: group.into(),
                    area: area.into(),
                    method: method.into(),
                    counts: Counts::default(),
                    expected_columns: 0,
                    completed_sweep_columns: 0,
                });
                state.participation.len() - 1
            });
        increment(
            &mut state.participation[index].counts.started,
            &mut state.overflow,
        );
        increment(&mut state.live, &mut state.overflow);
        generation = Some(Rc::clone(&state.generation));
        if group == "sweep" {
            dimension = state
                .current
                .as_ref()
                .map_or(0, |(_, _, _, dimension)| *dimension as u64);
            if let Some(total) = state.participation[index]
                .expected_columns
                .checked_add(dimension)
            {
                state.participation[index].expected_columns = total;
            } else {
                state.overflow = true;
            }
        }
        Some(index)
    });
    Observation {
        index,
        clear_sweep: group == "sweep",
        generation,
        dimension,
    }
}

pub(crate) fn solve(family: Family, fixed: bool) -> Observation {
    start(
        family,
        if fixed {
            Pass::FixedFinal
        } else {
            Pass::Potential
        },
        "solve",
        "not_applicable",
        "lifecycle",
    )
}

pub(crate) fn sweep() -> Observation {
    let identity = ACTIVE.with(|active| {
        active.borrow().as_ref().and_then(|state| {
            state
                .current
                .as_ref()
                .map(|(family, pass, _, _)| (*family, *pass))
        })
    });
    identity.map_or(
        Observation {
            index: None,
            clear_sweep: false,
            generation: None,
            dimension: 0,
        },
        |(family, pass)| start(family, pass, "sweep", "not_applicable", "lifecycle"),
    )
}

pub(crate) fn column(index: usize, identity_anchor: bool) -> Observation {
    let metadata = ACTIVE.with(|active| {
        let active = active.borrow();
        let (family, pass, areas, _) = active.as_ref()?.current.as_ref()?;
        let component = (index < 10 * areas.len() && index % 10 >= 6).then(|| index % 10 - 6);
        let (group, area) = component.map_or(("other", "not_applicable"), |component| {
            (
                ["sun", "shade", "wet", "stem"][component],
                if areas[index / 10][component] > 0.0 {
                    "positive"
                } else {
                    "zero"
                },
            )
        });
        Some((*family, *pass, group, area))
    });
    metadata.map_or(
        Observation {
            index: None,
            clear_sweep: false,
            generation: None,
            dimension: 0,
        },
        |(family, pass, group, area)| {
            start(
                family,
                pass,
                group,
                area,
                if identity_anchor {
                    "identity_anchor"
                } else {
                    "finite_difference"
                },
            )
        },
    )
}

impl Observation {
    pub(crate) fn finish(mut self, success: bool) {
        self.end(success);
    }
    fn end(&mut self, success: bool) {
        let Some(index) = self.index.take() else {
            return;
        };
        ACTIVE.with(|active| {
            if let Some(state) = active.borrow_mut().as_mut() {
                if !self
                    .generation
                    .as_ref()
                    .is_some_and(|generation| Rc::ptr_eq(generation, &state.generation))
                {
                    return;
                }
                state.live -= 1;
                let counts = &mut state.participation[index].counts;
                increment(
                    if success {
                        &mut counts.completed
                    } else {
                        &mut counts.failed
                    },
                    &mut state.overflow,
                );
                if self.clear_sweep {
                    if success {
                        if let Some(total) = state.participation[index]
                            .completed_sweep_columns
                            .checked_add(self.dimension)
                        {
                            state.participation[index].completed_sweep_columns = total;
                        } else {
                            state.overflow = true;
                        }
                    }
                    state.current = None;
                }
            }
        });
    }
}
impl Drop for Observation {
    fn drop(&mut self) {
        self.end(false);
    }
}

impl Session {
    pub fn finish(self) -> Result<Corpus, CaptureError> {
        ACTIVE.with(|active| {
            let state = active.borrow_mut().take().ok_or(CaptureError::NotActive)?;
            if state.live != 0 {
                return Err(CaptureError::LiveScopes);
            }
            if state.overflow {
                return Err(CaptureError::Overflow);
            }
            let corpus = Corpus {
                schema: SCHEMA.to_owned(),
                first: state.first.into_iter().flatten().collect(),
                last: state.last.into_iter().flatten().collect(),
                participation: state.participation,
            };
            corpus.validate_participation()?;
            if !(corpus.first.is_empty() && corpus.last.is_empty()) {
                corpus.validate()?;
            }
            Ok(corpus)
        })
    }
}

impl Drop for Session {
    fn drop(&mut self) {
        ACTIVE.with(|active| {
            let mut active = active.borrow_mut();
            if active
                .as_ref()
                .is_some_and(|state| Rc::ptr_eq(&state.generation, &self.generation))
            {
                active.take();
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn live_finish_and_stale_drops_cannot_poison_a_new_session() {
        let session = begin(1).expect("old session");
        let stale = solve(Family::Covered, false);
        assert_eq!(session.finish(), Err(CaptureError::LiveScopes));
        let session = begin(1).expect("new session");
        drop(stale);
        let current = solve(Family::GenericV3, true);
        current.finish(true);
        let corpus = session.finish().expect("unpoisoned new session");
        assert_eq!(corpus.participation.len(), 1);
        assert_eq!(
            corpus.participation[0].counts,
            Counts {
                started: 1,
                completed: 1,
                failed: 0
            }
        );

        let abandoned = begin(1).expect("abandoned session");
        let stale = solve(Family::Covered, false);
        drop(abandoned);
        let replacement = begin(1).expect("replacement");
        stale.finish(true);
        assert!(
            replacement
                .finish()
                .expect("no stale writes")
                .participation
                .is_empty()
        );
    }

    #[test]
    fn participation_rejects_bad_buckets_counts_and_missing_columns() {
        let session = begin(1).expect("session");
        let solve = solve(Family::GenericV3, false);
        ACTIVE.with(|active| {
            active.borrow_mut().as_mut().expect("active").current =
                Some((Family::GenericV3, Pass::Potential, vec![[1.0; 4]; 2], 25))
        });
        let sweep = sweep();
        for index in 0..25 {
            column(index, false).finish(true);
        }
        sweep.finish(true);
        solve.finish(true);
        let corpus = session.finish().expect("dimension-complete capture");
        corpus.validate_participation().expect("valid");
        let mut corrupt = corpus.clone();
        corrupt.participation.push(corrupt.participation[0].clone());
        assert!(corrupt.validate_participation().is_err());
        for (field, value) in [
            ("group", "arbitrary"),
            ("area", "negative"),
            ("method", "identity_anchor"),
        ] {
            let mut corrupt = corpus.clone();
            let row = corrupt
                .participation
                .iter_mut()
                .find(|row| row.group == "sun")
                .expect("sun");
            match field {
                "group" => row.group = value.into(),
                "area" => row.area = value.into(),
                _ => row.method = value.into(),
            }
            assert!(corrupt.validate_participation().is_err());
        }
        let mut corrupt = corpus.clone();
        corrupt.participation[0].counts.completed = u64::MAX;
        corrupt.participation[0].counts.failed = 1;
        assert!(corrupt.validate_participation().is_err());
        let mut corrupt = corpus;
        let row = corrupt
            .participation
            .iter_mut()
            .find(|row| row.group == "sun")
            .expect("sun");
        row.counts.started -= 1;
        row.counts.completed -= 1;
        assert!(
            corrupt.validate_participation().is_err(),
            "balanced but missing column fails dimension reconciliation"
        );
    }

    #[test]
    fn observer_counter_overflow_fails_closed() {
        let session = begin(1).expect("session");
        ACTIVE.with(|active| active.borrow_mut().as_mut().expect("active").overflow = true);
        assert_eq!(session.finish(), Err(CaptureError::Overflow));
        begin(1)
            .expect("replacement")
            .finish()
            .expect("new generation is clean");
    }

    #[test]
    fn actual_column_participation_is_bounded_and_reconciles_failures() {
        let session = begin(1).expect("begin");
        let solve = solve(Family::Covered, true);
        ACTIVE.with(|active| {
            active.borrow_mut().as_mut().expect("active").current = Some((
                Family::Covered,
                Pass::FixedFinal,
                vec![[1.0, 0.0, 2.0, 0.0]; 30],
                305,
            ))
        });
        let sweep = sweep();
        for _ in 0..10 {
            column(6, false).finish(true);
            column(17, false).finish(true);
            column(29, true).finish(true);
            column(32, false).finish(true);
        }
        drop(column(8, false));
        drop(sweep);
        solve.finish(false);
        let corpus = session.finish().expect("finish");
        assert_eq!(
            corpus.participation.len(),
            7,
            "bounded by families, not visits/topology"
        );
        for row in &corpus.participation {
            assert_eq!(row.counts.started, row.counts.completed + row.counts.failed);
        }
        let sun = corpus
            .participation
            .iter()
            .find(|row| row.group == "sun")
            .expect("sun");
        assert_eq!(
            (sun.area.as_str(), sun.method.as_str(), sun.counts.completed),
            ("positive", "finite_difference", 10)
        );
        let shade = corpus
            .participation
            .iter()
            .find(|row| row.group == "shade")
            .expect("shade");
        assert_eq!(
            (shade.area.as_str(), shade.method.as_str()),
            ("zero", "finite_difference")
        );
        let wet = corpus
            .participation
            .iter()
            .find(|row| row.group == "wet")
            .expect("wet");
        assert_eq!(wet.counts.failed, 1);
    }

    #[test]
    fn bounds_and_session_ownership_fail_closed() {
        assert!(matches!(begin(0), Err(CaptureError::InvalidBound)));
        let session = begin(2).expect("begin bounded capture");
        assert!(matches!(begin(2), Err(CaptureError::AlreadyActive)));
        let corpus = session.finish().expect("finish empty capture");
        assert_eq!(corpus.schema, SCHEMA);
        assert!(corpus.first.is_empty() && corpus.last.is_empty());
    }

    #[test]
    fn float_wire_words_are_bit_exact_and_deterministic() {
        let mut value = serde_json::json!({
            "negative_zero": -0.0,
            "ordinary": 1.25,
            "integer": 7,
        });
        encode_float_bits(&mut value).expect("encode finite floats");
        assert_eq!(value["negative_zero"]["$f64_bits"], "8000000000000000");
        assert_eq!(value["ordinary"]["$f64_bits"], "3ff4000000000000");
        assert_eq!(value["integer"], 7);
        let first = serde_json::to_vec(&value).expect("wire JSON");
        let second = serde_json::to_vec(&value).expect("repeat wire JSON");
        assert_eq!(first, second);
        decode_float_bits(&mut value).expect("decode finite floats");
        assert_eq!(
            value["negative_zero"].as_f64().expect("f64").to_bits(),
            (-0.0_f64).to_bits()
        );
        assert_eq!(
            value["ordinary"].as_f64().expect("f64").to_bits(),
            1.25_f64.to_bits()
        );
    }

    #[test]
    fn malformed_and_nonfinite_float_words_fail_closed() {
        for malformed in [
            serde_json::json!({"$f64_bits": "xyz"}),
            serde_json::json!({"$f64_bits": 1}),
            serde_json::json!({"$f64_bits": "7ff8000000000000"}),
            serde_json::json!({"$f64_bits": "7ff0000000000000"}),
        ] {
            let mut malformed = malformed;
            assert!(decode_float_bits(&mut malformed).is_err());
        }
    }

    #[test]
    fn corpus_wire_rejects_malformed_schema_and_empty_payload() {
        assert!(Corpus::from_wire_bytes(b"not-json").is_err());
        let empty = br#"{"schema":"openwepp.covered-residual-corpus.v0","first":[],"last":[]}"#;
        assert!(Corpus::from_wire_bytes(empty).is_err());
    }
}
