//! Baseline-only independent oracle for the prospective v33 dry-stem block.
//!
//! This module deliberately knows nothing about a candidate Jacobian. It
//! reconstructs every probe through the canonical primal evaluator.
#![allow(
    clippy::cast_possible_truncation,
    clippy::cast_possible_wrap,
    clippy::float_cmp,
    clippy::too_many_lines
)]

use crate::{
    CoveredColumnEvaluation, LandSurfaceEnergyError, evaluate_covered_column,
    solver_residual_corpus_capture::{Corpus, Snapshot},
};

const EPSILON: f64 = f64::EPSILON;

#[derive(Clone, Copy, Debug)]
struct OracleEntry {
    derivative: f64,
    uncertainty: f64,
}

fn centered_difference(minus: f64, plus: f64, h: f64) -> f64 {
    (plus - minus) / (2.0 * h)
}

fn select_basin(d: &[f64; 9], base_residual: f64, h0: f64) -> Option<OracleEntry> {
    let mut selected: Option<(u64, i32, i32, usize)> = None;
    for coarse in 2..9 {
        let fine = coarse - 2;
        let d_f = (d[fine] - d[fine + 1]).abs();
        let d_c = (d[fine + 1] - d[coarse]).abs();
        if !(d_f.is_finite() && d_c.is_finite() && d_f > 0.0) {
            continue;
        }
        let ratio = d_c / d_f;
        if !(2.5..=5.5).contains(&ratio) {
            continue;
        }
        let q = fine as i32 - 4;
        let key = (d_f.to_bits(), q.abs(), q, fine);
        if selected.is_none_or(|current| key < current) {
            selected = Some(key);
        }
    }
    let (d_f_bits, _, q, fine) = selected?;
    let d_f = f64::from_bits(d_f_bits);
    let h_q = h0 * 2.0_f64.powi(q);
    let derivative = (4.0 * d[fine] - d[fine + 1]) / 3.0;
    let uncertainty = (d_f / 3.0)
        .max(64.0 * EPSILON * base_residual.abs().max(1.0) / h_q)
        .max(2.0e-9);
    Some(OracleEntry {
        derivative,
        uncertainty,
    })
}

fn candidate_bound(candidate: f64, oracle: OracleEntry) -> f64 {
    8.0 * oracle.uncertainty + 2.0e-7 + 5.0e-5 * candidate.abs().max(oracle.derivative.abs())
}

fn same_sign(left: f64, right: f64) -> bool {
    left.is_sign_negative() == right.is_sign_negative()
        && (left.to_bits() == 0.0_f64.to_bits()) == (right.to_bits() == 0.0_f64.to_bits())
}

fn same_floor_region(left: f64, right: f64) -> bool {
    left != 1.0 && right != 1.0 && (left < 1.0) == (right < 1.0)
}

fn shared_heat_scale(evaluation: &CoveredColumnEvaluation) -> f64 {
    evaluation.canopy_sensible_w_m2.abs()
        + evaluation.ground_sensible_to_canopy_air_w_m2.abs()
        + evaluation.sensible_to_reference_air_w_m2.abs()
}

fn smooth_mask_same(base: &CoveredColumnEvaluation, probe: &CoveredColumnEvaluation) -> bool {
    same_floor_region(shared_heat_scale(base), shared_heat_scale(probe))
        && base.ground_water.branch == probe.ground_water.branch
        && base
            .occupancies
            .iter()
            .zip(&probe.occupancies)
            .all(|(left, right)| {
                left.wet_branch == right.wet_branch
                    && left.gas_branches == right.gas_branches
                    && left
                        .source_water
                        .iter()
                        .zip(&right.source_water)
                        .all(|(l, r)| l.branch == r.branch)
                    && left
                        .net_longwave_w_m2
                        .iter()
                        .zip(right.net_longwave_w_m2)
                        .all(|(l, r)| same_sign(*l, r))
                    && left
                        .sensible_to_canopy_air_w_m2
                        .iter()
                        .zip(right.sensible_to_canopy_air_w_m2)
                        .all(|(l, r)| same_sign(*l, r))
            })
        && same_sign(
            base.whole_column_longwave.ground_net_w_m2,
            probe.whole_column_longwave.ground_net_w_m2,
        )
        && same_sign(base.canopy_sensible_w_m2, probe.canopy_sensible_w_m2)
        && same_sign(
            base.ground_sensible_to_canopy_air_w_m2,
            probe.ground_sensible_to_canopy_air_w_m2,
        )
        && same_sign(
            base.sensible_to_reference_air_w_m2,
            probe.sensible_to_reference_air_w_m2,
        )
}

fn expected_affected(snapshot: &Snapshot, target: usize) -> Vec<bool> {
    let n = snapshot.inputs.occupancies.len();
    let mut affected = vec![false; snapshot.x_bits.len()];
    for receiver in 0..n {
        if receiver == target {
            continue;
        }
        for component in 0..4 {
            if snapshot.base_evaluation.occupancies[receiver].component_areas_m2_m2_tile[component]
                .to_bits()
                != 0.0_f64.to_bits()
            {
                affected[10 * receiver + 6 + component] = true;
            }
        }
    }
    affected[10 * target + 9] = true;
    affected[10 * n] = true;
    if snapshot.inputs.stage3_lower_boundary.is_none() {
        affected[10 * n + 2] = true;
    }
    affected
}

fn evaluate_probe(
    snapshot: &Snapshot,
    trial: &[f64],
) -> Result<CoveredColumnEvaluation, LandSurfaceEnergyError> {
    evaluate_covered_column(
        &snapshot.inputs,
        trial,
        snapshot.caps.as_ref(),
        Some(&snapshot.frozen),
    )
}

fn audit_snapshot(snapshot: &Snapshot) -> (usize, usize) {
    let base_trial: Vec<f64> = snapshot
        .x_bits
        .iter()
        .map(|bits| f64::from_bits(*bits))
        .collect();
    let n = snapshot.inputs.occupancies.len();
    assert_eq!(
        evaluate_probe(snapshot, &base_trial).expect("replay corpus base"),
        snapshot.base_evaluation,
        "corpus base must replay exactly"
    );

    let mut candidates = 0;
    let mut supported = 0;
    for target in 0..n {
        let column = 10 * target + 9;
        let dry_stem = snapshot.base_evaluation.occupancies[target].component_areas_m2_m2_tile[3];
        if dry_stem.to_bits() == 0.0_f64.to_bits() {
            continue;
        }
        candidates += 1;
        assert!(dry_stem.is_finite() && dry_stem > 0.0);
        let temperature = base_trial[column];
        assert!((200.0..350.0).contains(&temperature));
        let h0 = EPSILON.sqrt() * temperature.abs().max(1.0);
        let mut differences = vec![[0.0; 9]; base_trial.len()];
        let mut exact_zero = vec![true; base_trial.len()];
        let mut stem_sensible_d = [0.0; 9];
        let mut stem_longwave_d = [0.0; 9];
        let mut ground_longwave_d = [0.0; 9];
        for sample in 0..9 {
            let k = sample as i32 - 4;
            let h = h0 * 2.0_f64.powi(k);
            let mut minus_trial = base_trial.clone();
            let mut plus_trial = base_trial.clone();
            minus_trial[column] -= h;
            plus_trial[column] += h;
            let minus = evaluate_probe(snapshot, &minus_trial).expect("canonical minus probe");
            let plus = evaluate_probe(snapshot, &plus_trial).expect("canonical plus probe");
            assert!(smooth_mask_same(&snapshot.base_evaluation, &minus));
            assert!(smooth_mask_same(&snapshot.base_evaluation, &plus));
            for row in 0..base_trial.len() {
                differences[row][sample] = centered_difference(
                    minus.normalized_residuals[row],
                    plus.normalized_residuals[row],
                    h,
                );
                exact_zero[row] &= minus.normalized_residuals[row].to_bits()
                    == snapshot.base_evaluation.normalized_residuals[row].to_bits()
                    && plus.normalized_residuals[row].to_bits()
                        == snapshot.base_evaluation.normalized_residuals[row].to_bits();
            }
            stem_sensible_d[sample] = centered_difference(
                minus.occupancies[target].sensible_to_canopy_air_w_m2[3],
                plus.occupancies[target].sensible_to_canopy_air_w_m2[3],
                h,
            );
            stem_longwave_d[sample] = centered_difference(
                minus.occupancies[target].net_longwave_w_m2[3],
                plus.occupancies[target].net_longwave_w_m2[3],
                h,
            );
            ground_longwave_d[sample] = centered_difference(
                minus.whole_column_longwave.ground_net_w_m2,
                plus.whole_column_longwave.ground_net_w_m2,
                h,
            );
        }

        let expected = expected_affected(snapshot, target);
        let mut missing_rows = Vec::new();
        for row in 0..base_trial.len() {
            if expected[row] {
                let oracle = select_basin(
                    &differences[row],
                    snapshot.base_evaluation.normalized_residuals[row],
                    h0,
                );
                if oracle.is_none() {
                    missing_rows.push(row);
                }
                assert!(
                    !exact_zero[row],
                    "affected row {row}, column {column} stayed exact zero"
                );
            } else {
                assert!(
                    exact_zero[row],
                    "undeclared affected row {row}, column {column}"
                );
            }
        }
        if missing_rows.is_empty() {
            supported += 1;
        } else {
            eprintln!(
                "v33 unsupported lifecycle={:?} column={column} missing_rows={missing_rows:?}",
                snapshot.lifecycle
            );
        }

        // The elementary signs are independent of basin selection. Use the
        // coarsest declared centered probe, which has the strongest signal.
        assert!(stem_sensible_d[8].is_finite() && stem_sensible_d[8] > 0.0);
        assert!(stem_longwave_d[8].is_finite() && stem_longwave_d[8] < 0.0);
        assert!(ground_longwave_d[8].is_finite() && ground_longwave_d[8] > 0.0);
    }
    (candidates, supported)
}

#[derive(Clone, Copy, Debug)]
pub(super) struct AuditReport {
    pub candidates: usize,
    pub supported: usize,
}

pub(super) fn audit_corpus(corpus: &Corpus) -> AuditReport {
    corpus.validate().expect("valid exact corpus");
    let snapshots: Vec<_> = corpus.first.iter().chain(&corpus.last).collect();
    assert!(snapshots.iter().any(|snapshot| {
        snapshot
            .base_evaluation
            .occupancies
            .iter()
            .any(|occupancy| occupancy.component_areas_m2_m2_tile[3] > 0.0)
    }));
    assert!(snapshots.iter().any(|snapshot| snapshot.caps.is_none()));
    assert!(snapshots.iter().any(|snapshot| snapshot.caps.is_some()));
    let mut report = AuditReport {
        candidates: 0,
        supported: 0,
    };
    for snapshot in snapshots {
        let (candidates, supported) = audit_snapshot(snapshot);
        report.candidates += candidates;
        report.supported += supported;
    }
    assert!(report.candidates > 0);
    report
}

#[test]
fn v33_oracle_selector_self_tests_precede_candidate_code() {
    let x = 1.25_f64;
    let h0 = 1.0e-3;
    let cubic = std::array::from_fn(|sample| {
        let h = h0 * 2.0_f64.powi(sample as i32 - 4);
        centered_difference((x - h).powi(3), (x + h).powi(3), h)
    });
    let oracle = select_basin(&cubic, x.powi(3), h0).expect("cubic basin");
    assert!((oracle.derivative - 3.0 * x * x).abs() <= 8.0 * oracle.uncertainty);

    let constant = [0.0; 9];
    assert!(select_basin(&constant, 7.0, h0).is_none());

    let kink = std::array::from_fn(|sample| {
        let h = h0 * 2.0_f64.powi(sample as i32 - 4);
        centered_difference((-h).abs(), h.abs(), h)
    });
    assert!(select_basin(&kink, 0.0, h0).is_none());
    assert!(!same_sign(-h0, h0), "abs-zero branch crossing must reject");
    assert!(
        !same_floor_region(0.5, 1.5),
        "max-floor crossing must reject"
    );
    assert!(!same_floor_region(1.0, 1.0), "exact max tie must reject");

    let wrong = oracle.derivative + 0.1;
    assert!((wrong - oracle.derivative).abs() > candidate_bound(wrong, oracle));
}
