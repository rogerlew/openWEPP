use super::terminal_event::TerminalFluxIntegral;
#[allow(clippy::wildcard_imports)]
use super::*;

impl Wb11HydrologyKernel {
    /// Shared validation and canonical arithmetic for both typed interfaces.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn terminal_carrier_flux(
        phase_class: HillslopeKernelPhaseClass,
        tag: Stage3EvaluationTag,
        inputs: &DirectActiveSnowPartitionInputs,
        hourly: DirectSnowHourlyForcing,
        support_seconds: f64,
        request: &CoveredTerminalFeedForwardRequestV1,
        receipt: &CoveredTerminalTrialTransitionV1,
    ) -> Result<TerminalFluxIntegral, DirectSnowStage3EvaluationError> {
        let duration_seconds = f64::from_bits(request.support.duration_s_bits());
        if receipt.boundary.support != request.support
            || receipt.beginning_joint != request.beginning_joint
            || receipt.probe_child_identity.trial_support != request.support
            || receipt.probe_child_identity.role != request.role
            || receipt.probe_child_identity.attempt_ordinal != request.attempt_ordinal
            || receipt.probe_child_identity.beginning_joint_sha256
                != request.beginning_joint.receipt_sha256()
        {
            return Err(Wb11HydrologyKernel::stage3_domain_error(
                phase_class,
                "snow.terminal_trial_boundary_support_join",
                duration_seconds,
                Some(duration_seconds),
                Some(duration_seconds),
            )
            .into());
        }
        let carrier = Self::stage3_hourly_surface_energy(
            phase_class,
            inputs,
            hourly,
            Stage3SurfaceInterval {
                surface_temperature_c: request.surface_temperature_c,
                snow_depth_m: request.snow_depth_m,
                snow_density_kg_m3: request.snow_density_kg_m3,
                duration_seconds,
                forcing_duration_seconds: duration_seconds,
                boundary: Some(receipt.boundary.clone()),
            },
            Some(tag.operator),
            DirectSnowDiagnosticCapture::Verbose,
        )?;
        let surface = carrier.diagnostics.ok_or_else(|| {
            Wb11HydrologyKernelGuardError::MissingRequiredStateSymbol {
                phase_class,
                symbol: BoundarySymbol::from("snow.terminal_enthalpy_diagnostics"),
            }
        })?;
        let flux = TerminalFluxIntegral {
            complete_energy_j_m2: surface.shadow_complete_energy_j_m2,
            vapor_mass_exchange_kg_m2: surface.shadow_vapor_mass_exchange_kg_m2,
            shortwave_energy_j_m2: carrier.shortwave_j_m2,
            longwave_energy_j_m2: carrier.longwave_j_m2,
            sensible_energy_j_m2: surface.shadow_sensible_flux_w_m2 * duration_seconds,
            latent_energy_j_m2: surface.shadow_latent_flux_w_m2 * duration_seconds,
            advected_energy_j_m2: surface.shadow_advected_flux_w_m2 * duration_seconds,
            snow_soil_heat_energy_j_m2: carrier.reconciliation.as_ref().map_or(0.0, |value| {
                value.snow_soil_heat_flux_w_m2 * duration_seconds
            }),
            external_liquid_kg_m2: hourly.rain_m * STAGE3_RHO_WATER_KG_M3 * duration_seconds
                / support_seconds,
        };

        Ok(flux)
    }

    /// One local invocation. The selected interface is fixed before physics;
    /// only feedback-capable providers enter the original convergence loop.
    #[allow(clippy::too_many_arguments, clippy::too_many_lines)]
    pub(super) fn evaluate_terminal_carrier_invocation<
        M: TerminalEvidenceMode<Option<CoveredTerminalJointTrialStateV1>>,
    >(
        phase_class: HillslopeKernelPhaseClass,
        tag: Stage3EvaluationTag,
        inputs: &DirectActiveSnowPartitionInputs,
        hourly: DirectSnowHourlyForcing,
        support_seconds: f64,
        trial_state: TerminalState,
        physical_request: &CoveredTerminalFeedForwardRequestV1,
        provider: &mut CoveredTerminalProviderV1<'_, '_>,
        coupling_evidence: &mut M::CouplingState,
    ) -> Result<
        (TerminalFluxIntegral, CoveredTerminalTrialTransitionV1),
        DirectSnowStage3EvaluationError,
    > {
        #[cfg(not(test))]
        let _ = coupling_evidence;
        match provider {
            CoveredTerminalProviderV1::FeedForward(provider) => {
                let receipt = (**provider)(physical_request.clone())?;
                let flux = Self::terminal_carrier_flux(
                    phase_class,
                    tag,
                    inputs,
                    hourly,
                    support_seconds,
                    physical_request,
                    &receipt,
                )?;
                Self::terminal_transition(trial_state, flux)?;
                Ok((flux, receipt))
            }
            #[cfg(test)]
            CoveredTerminalProviderV1::Feedback(provider) => {
                Self::evaluate_feedback_carrier_invocation::<M>(
                    phase_class,
                    tag,
                    inputs,
                    hourly,
                    support_seconds,
                    trial_state,
                    physical_request,
                    *provider,
                    coupling_evidence,
                )
            }
        }
    }

    #[cfg(test)]
    #[allow(clippy::too_many_arguments, clippy::too_many_lines)]
    fn evaluate_feedback_carrier_invocation<
        M: TerminalEvidenceMode<Option<CoveredTerminalJointTrialStateV1>>,
    >(
        phase_class: HillslopeKernelPhaseClass,
        tag: Stage3EvaluationTag,
        inputs: &DirectActiveSnowPartitionInputs,
        hourly: DirectSnowHourlyForcing,
        support_seconds: f64,
        trial_state: TerminalState,
        physical_request: &CoveredTerminalFeedForwardRequestV1,
        provider: &mut CoveredTerminalTrialProviderV1<'_>,
        coupling_evidence: &mut M::CouplingState,
    ) -> Result<
        (TerminalFluxIntegral, CoveredTerminalTrialTransitionV1),
        DirectSnowStage3EvaluationError,
    > {
        let mut hint = None;
        let mut accepted = None;
        for coupling_iteration in 0..32_u32 {
            let request = physical_request
                .clone()
                .into_feedback_request(hint, coupling_iteration);
            let evidence_request = M::ENABLED.then(|| request.clone());
            let receipt = (provider)(request)?;
            let flux = Self::terminal_carrier_flux(
                phase_class,
                tag,
                inputs,
                hourly,
                support_seconds,
                physical_request,
                &receipt,
            )?;
            let preview = Self::terminal_transition(trial_state, flux)?.state;
            let next_hint = CoveredTerminalEndingSnowHintV1 {
                ice_kg_m2: preview.ice_kg_m2,
                liquid_kg_m2: preview.liquid_kg_m2,
                cold_content_j_m2: preview.cold_content_j_m2,
                surface_temperature_c: Self::stage3_temperature_from_cold_content_values(
                    preview.ice_kg_m2 / STAGE3_RHO_WATER_KG_M3,
                    preview.cold_content_j_m2,
                ),
            };
            let converged = hint.is_some_and(|previous| {
                terminal_coupling_four_component_converged(previous, next_hint)
            });
            let comparisons = evidence_request.as_ref().and_then(|_| {
                hint.map(|previous| terminal_coupling_comparisons(previous, next_hint))
            });
            if let Some(request) = evidence_request.as_ref() {
                M::coupling_iteration(
                    coupling_evidence,
                    TerminalCouplingIterationHook {
                        request: request.clone(),
                        outgoing: next_hint,
                        comparisons,
                        converged,
                    },
                );
            }
            accepted = Some((receipt, flux, evidence_request, converged));
            if converged {
                break;
            }
            hint = Some(next_hint);
        }
        let (receipt, flux, selected_request, selected_live_converged) =
            accepted.ok_or(DirectSnowStage3EvaluationError::TerminalCustody(
                "covered terminal coupled trial missing result",
            ))?;
        let preview = Self::terminal_transition(trial_state, flux)?.state;
        let converged = hint.is_some_and(|previous| {
            terminal_coupling_post_loop_three_component_converged(
                previous,
                CoveredTerminalEndingSnowHintV1 {
                    ice_kg_m2: preview.ice_kg_m2,
                    liquid_kg_m2: preview.liquid_kg_m2,
                    cold_content_j_m2: preview.cold_content_j_m2,
                    surface_temperature_c: previous.surface_temperature_c,
                },
            )
        });
        if let Some(selected_request) = selected_request {
            M::coupling_selection(
                coupling_evidence,
                TerminalCouplingSelectionHook {
                    request: selected_request,
                    reason: if selected_live_converged {
                        TerminalCouplingSelectionReason::FourComponentConvergenceBreak
                    } else {
                        TerminalCouplingSelectionReason::IterationLoopExhausted
                    },
                    post_loop_three_component_check: converged,
                },
            );
        }
        require_terminal_coupling_live_convergence(selected_live_converged)?;

        Ok((flux, receipt))
    }
    #[cfg(test)]
    pub(crate) fn feed_forward_reference_hint(
        inputs: &DirectActiveSnowPartitionInputs,
        forcing: DirectSnowStage3SupportInput,
        request: &CoveredTerminalFeedForwardRequestV1,
        receipt: &CoveredTerminalTrialTransitionV1,
    ) -> Result<CoveredTerminalEndingSnowHintV1, DirectSnowStage3EvaluationError> {
        let flux = Self::terminal_carrier_flux(
            HillslopeKernelPhaseClass::HydrologyRunoffReconciliation,
            Stage3EvaluationTag::new(SnowStage3EvaluationOperator::PersistentAccumulationShadowV1),
            inputs,
            forcing.forcing,
            forcing.duration_seconds,
            request,
            receipt,
        )?;
        let preview = Self::terminal_transition(
            TerminalState {
                ice_kg_m2: request.ice_kg_m2,
                liquid_kg_m2: request.liquid_kg_m2,
                cold_content_j_m2: request.cold_content_j_m2,
            },
            flux,
        )?
        .state;
        Ok(CoveredTerminalEndingSnowHintV1 {
            ice_kg_m2: preview.ice_kg_m2,
            liquid_kg_m2: preview.liquid_kg_m2,
            cold_content_j_m2: preview.cold_content_j_m2,
            surface_temperature_c: Self::stage3_temperature_from_cold_content_values(
                preview.ice_kg_m2 / STAGE3_RHO_WATER_KG_M3,
                preview.cold_content_j_m2,
            ),
        })
    }
}
