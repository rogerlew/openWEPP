//! Contract-derived EXP-STAGE3-20260906-F guards. Real-carrier parity is a separate gate.
use super::*;

fn inputs() -> DirectActiveSnowPartitionInputs {
    let mut layer = DirectSnowLayerState::new(0.01, 0.02, 450.0, 12.0);
    layer.temperature_c = 0.0;
    layer.cold_content_j_m2 = 0.0;
    DirectActiveSnowPartitionInputs {
        hyetograph_rainfall_m: 0.0,
        rst_c: 0.0,
        newsnw_kg_m3: 100.0,
        ssd_kg_m3: 522.0,
        runtime_swe_m: 0.01,
        runtime_depth_m: 0.02,
        runtime_density_kg_m3: 450.0,
        runtime_settle_day_count: 12.0,
        liquid_water_retained_m: 0.0,
        tmax_c: -3.0,
        tmin_c: -7.0,
        canopy_cover_fraction: 0.45,
        wind_m_s: 3.0,
        dewpoint_c: -15.0,
        snow_melt_model: SnowMeltModel::AdaptiveCompositionalStage3V1,
        snow_density_model: SnowDensityModel::PhysicsBulkDensityCompactionV1,
        stage3_liquid_routing_model: SnowStage3LiquidRoutingModel::LayeredThermalLiquidV1,
        surface_energy_options: DirectSnowSurfaceEnergyOptions {
            longwave_model: SnowSurfaceLongwaveModel::DilleyUnsworthSubcanopyV1,
            sublimation_model: SnowSurfaceSublimationModel::NeutralBulkStage3V1,
            daily_solar_radiation_mj_m2: 5.0,
            daily_extraterrestrial_radiation_mj_m2: 10.0,
            daylight: true,
            atmospheric_pressure_pa: 101_324.6,
            turbulent_geometry: DirectSnowTurbulentGeometry::CLIGEN_V1,
            complete_carrier_shadow: false,
        },
        sturm_climate_class: None,
        sturm_day_of_year: None,
        coe_boundary_depth_m: 0.40,
        coe_boundary_density_kg_m3: 450.0,
        coe_boundary_settle_day_count: 12.0,
        snow_albedo_model: None,
        snow_albedo_state: None,
        snow_layers: vec![layer],
        underlying_surface_albedo: 0.2,
        hourly: [DirectSnowHourlyForcing {
            radiation_mj_m2: 0.0,
            air_temperature_c: -5.0,
            ..DirectSnowHourlyForcing::zero()
        }; 24],
    }
}

fn support() -> TimeSupport {
    TimeSupport::new(ModelTimeNs::new(0), ModelTimeNs::new(1_800_000_000_000)).unwrap()
}

fn joint() -> CoveredTerminalJointTrialStateV1 {
    CoveredTerminalJointTrialStateV1::try_new(
        JointTrialAuthorityV1 {
            source_owner_set_sha256: Digest32::from_bytes([8; 32]),
            lane_id: 31,
            source_snow_owner_sha256: Digest32::from_bytes([9; 32]),
            interval_index: 0,
            state_support: support(),
            accepted_predecessors: Vec::new(),
        },
        BTreeMap::from([
            ("vegetation".to_owned(), vec![1]),
            ("snow".to_owned(), vec![2]),
            ("land_surface_energy".to_owned(), vec![3]),
            ("hydrology".to_owned(), vec![4]),
            ("bgc".to_owned(), vec![5]),
            ("soil_thermal".to_owned(), vec![6]),
            ("surface_liquid".to_owned(), vec![7]),
        ]),
    )
    .unwrap()
}

// No `..`: adding either forbidden feedback field makes this exhaustive pattern
// fail compilation, even if callers would otherwise leave that field unused.
fn assert_structurally_feed_forward(request: &CoveredTerminalFeedForwardRequestV1) {
    let CoveredTerminalFeedForwardRequestV1 {
        lane_id: _,
        support: _,
        role: _,
        attempt_ordinal: _,
        ice_kg_m2: _,
        liquid_kg_m2: _,
        cold_content_j_m2: _,
        surface_temperature_c: _,
        snow_depth_m: _,
        snow_density_kg_m3: _,
        beginning_stage3_state: _,
        beginning_joint: _,
    } = request;
}

#[test]
fn feed_forward_equal_payload_invocations_and_exact_path_each_call_provider() {
    let inputs = inputs();
    let state = Wb11HydrologyKernel::initialize_stage3_persistent_state_with_terminal_event(
        31,
        inputs.snow_layers.clone(),
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .unwrap();
    let before = state.clone();
    let beginning_joint = joint();
    let joint_before = beginning_joint.clone();
    let mut calls = Vec::new();
    for mode in [
        CoveredTerminalExecutionMode::DiscoveryProbe,
        CoveredTerminalExecutionMode::DiscoveryProbe,
        CoveredTerminalExecutionMode::ExactEndpoint {
            expected_tick: support().end_ns(),
        },
    ] {
        let mut evidence = <CaptureEvidence as TerminalEvidenceMode<
            Option<CoveredTerminalJointTrialStateV1>,
        >>::new_state();
        let mut provider = |request: CoveredTerminalFeedForwardRequestV1| {
            calls.push((
                request.lane_id,
                request.support,
                request.role,
                request.attempt_ordinal,
                request.beginning_joint.receipt_sha256(),
            ));
            assert_structurally_feed_forward(&request);
            Err(DirectSnowStage3EvaluationError::TerminalCustody(
                "sole-provider-poison",
            ))
        };
        let result = Wb11HydrologyKernel::evaluate_stage3_terminal_support_with_feed_forward_provider_and_evidence_v1::<CaptureEvidence>(
            &inputs, &state, 31, 0,
            DirectSnowStage3SupportInput { forcing: inputs.hourly[0], duration_seconds: 1_800.0 },
            support(), mode, beginning_joint.clone(), &mut provider, &mut evidence,
        );
        assert!(matches!(
            result,
            Err(DirectSnowStage3EvaluationError::TerminalCustody(
                "sole-provider-poison"
            ))
        ));
        assert!(evidence.selected_trials.is_empty());
        assert_eq!(state, before);
        assert_eq!(beginning_joint, joint_before);
    }
    assert_eq!(calls.len(), 3);
    assert_eq!(
        calls[0], calls[1],
        "equal requests still execute independently"
    );
    assert_eq!(calls[1], calls[2], "exact path must not reuse discovery");
}

#[test]
fn feed_forward_outer_guards_precede_provider_poison_and_preserve_state() {
    let inputs = inputs();
    let state = Wb11HydrologyKernel::initialize_stage3_persistent_state_with_terminal_event(
        31,
        inputs.snow_layers.clone(),
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .unwrap();
    let before = state.clone();
    for (lane, interval, duration, mode) in [
        (32, 0, 1_800.0, CoveredTerminalExecutionMode::DiscoveryProbe),
        (31, 1, 1_800.0, CoveredTerminalExecutionMode::DiscoveryProbe),
        (31, 0, 60.0, CoveredTerminalExecutionMode::DiscoveryProbe),
        (
            31,
            0,
            1_800.0,
            CoveredTerminalExecutionMode::PersistentReject,
        ),
    ] {
        let mut calls = 0;
        let mut evidence = <CaptureEvidence as TerminalEvidenceMode<
            Option<CoveredTerminalJointTrialStateV1>,
        >>::new_state();
        let mut provider = |_request: CoveredTerminalFeedForwardRequestV1| {
            calls += 1;
            Err(DirectSnowStage3EvaluationError::TerminalCustody(
                "unreachable-provider-poison",
            ))
        };
        let result = Wb11HydrologyKernel::evaluate_stage3_terminal_support_with_feed_forward_provider_and_evidence_v1::<CaptureEvidence>(
            &inputs, &state, lane, interval,
            DirectSnowStage3SupportInput { forcing: inputs.hourly[0], duration_seconds: duration },
            support(), mode, joint(), &mut provider, &mut evidence,
        );
        assert!(
            matches!(result, Err(DirectSnowStage3EvaluationError::Kernel(_))),
            "{result:?}"
        );
        assert_eq!(calls, 0);
        assert!(evidence.selected_trials.is_empty());
        assert_eq!(state, before);
    }
}

fn request(role: CoveredTerminalTrialRoleV1) -> CoveredTerminalFeedForwardRequestV1 {
    let inputs = inputs();
    CoveredTerminalFeedForwardRequestV1 {
        lane_id: 31,
        support: support(),
        role,
        attempt_ordinal: 7,
        ice_kg_m2: 10.0,
        liquid_kg_m2: 0.0,
        cold_content_j_m2: 0.0,
        surface_temperature_c: 0.0,
        snow_depth_m: 0.02,
        snow_density_kg_m3: 450.0,
        beginning_stage3_state: Box::new(
            Wb11HydrologyKernel::initialize_stage3_persistent_state_with_terminal_event(
                31,
                inputs.snow_layers,
                DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
            )
            .unwrap(),
        ),
        beginning_joint: joint(),
    }
}

// Boundary fixture, not a replacement for the real LSE/vegetation carrier oracle.
fn transition(request: &CoveredTerminalFeedForwardRequestV1) -> CoveredTerminalTrialTransitionV1 {
    use crate::snow_stage3_terminal_handoff::{
        Stage3BoundaryIdentity, Stage3SnowSurfaceBoundaryReceiptInputs,
    };
    CoveredTerminalTrialTransitionV1 {
        boundary: Stage3SnowSurfaceBoundaryReceiptV1::try_new(
            Stage3SnowSurfaceBoundaryReceiptInputs {
                support: request.support,
                sensible_energy_j_m2: 2.0,
                vapor_mass_kg_m2: 0.0,
                latent_energy_j_m2: 0.0,
                shortwave_energy_j_m2: 10.0,
                net_longwave_energy_j_m2: -1.0,
                precipitation_advection_j_m2: 0.0,
                snow_soil_heat_j_m2: 0.0,
                latent_heat_j_kg: 2_834_000.0,
                beginning_stage3_state_sha256: Digest32::from_bytes([31; 32]),
                identity: Stage3BoundaryIdentity::Provisional {
                    carrier_receipt_sha256: Digest32::from_bytes([41; 32]),
                },
            },
        )
        .unwrap(),
        beginning_joint: request.beginning_joint.clone(),
        ending_joint: request.beginning_joint.clone(),
        probe_child_identity: CoveredProbeChildIdentityV1::try_new(ProbeChildAuthorityV1 {
            parent_transaction_sha256: Digest32::from_bytes([1; 32]),
            enclosing_parent_support: support(),
            trial_support: request.support,
            physical_child_ordinal: 2,
            role: request.role,
            attempt_ordinal: request.attempt_ordinal,
            beginning_joint_sha256: request.beginning_joint.receipt_sha256(),
            beginning_owner_set_sha256: request.beginning_joint.authority().source_owner_set_sha256,
            complete_forcing_sha256: Digest32::from_bytes([4; 32]),
            topology_sha256: Digest32::from_bytes([5; 32]),
        })
        .unwrap(),
        trial_snow_soil_receipt: None,
    }
}

fn invoke(
    request: &CoveredTerminalFeedForwardRequestV1,
    provider: &mut CoveredTerminalProviderV1<'_, '_>,
) -> Result<
    (
        terminal_event::TerminalFluxIntegral,
        CoveredTerminalTrialTransitionV1,
    ),
    DirectSnowStage3EvaluationError,
> {
    let inputs = inputs();
    Wb11HydrologyKernel::evaluate_terminal_carrier_invocation::<NoEvidence>(
        HillslopeKernelPhaseClass::HydrologyRunoffReconciliation,
        Stage3EvaluationTag::new(SnowStage3EvaluationOperator::PersistentAccumulationShadowV1),
        &inputs,
        inputs.hourly[0],
        1_800.0,
        TerminalState {
            ice_kg_m2: request.ice_kg_m2,
            liquid_kg_m2: request.liquid_kg_m2,
            cold_content_j_m2: request.cold_content_j_m2,
        },
        request,
        provider,
        &mut (),
    )
}

fn flux_bits(flux: terminal_event::TerminalFluxIntegral) -> [u64; 9] {
    [
        flux.complete_energy_j_m2,
        flux.vapor_mass_exchange_kg_m2,
        flux.shortwave_energy_j_m2,
        flux.longwave_energy_j_m2,
        flux.sensible_energy_j_m2,
        flux.latent_energy_j_m2,
        flux.advected_energy_j_m2,
        flux.snow_soil_heat_energy_j_m2,
        flux.external_liquid_kg_m2,
    ]
    .map(f64::to_bits)
}

fn boundary_bits(boundary: &Stage3SnowSurfaceBoundaryReceiptV1) -> [u64; 8] {
    [
        boundary.sensible_energy_j_m2,
        boundary.vapor_mass_kg_m2,
        boundary.latent_energy_j_m2,
        boundary.shortwave_energy_j_m2,
        boundary.net_longwave_energy_j_m2,
        boundary.precipitation_advection_j_m2,
        boundary.snow_soil_heat_j_m2,
        boundary.latent_heat_j_kg,
    ]
    .map(f64::to_bits)
}

#[test]
fn feed_forward_one_call_matches_both_feedback_results_for_every_role() {
    for role in [
        CoveredTerminalTrialRoleV1::Full,
        CoveredTerminalTrialRoleV1::Retry,
        CoveredTerminalTrialRoleV1::Half1,
        CoveredTerminalTrialRoleV1::Half2,
        CoveredTerminalTrialRoleV1::Root,
    ] {
        let request = request(role);
        let mut forward_calls = Vec::new();
        let mut forward = |request: CoveredTerminalFeedForwardRequestV1| {
            let result = transition(&request);
            forward_calls.push(result.clone());
            Ok(result)
        };
        let one = invoke(
            &request,
            &mut CoveredTerminalProviderV1::FeedForward(&mut forward),
        )
        .unwrap();
        let mut feedback_calls = Vec::new();
        let mut feedback = |request: CoveredTerminalTrialRequestV1| {
            assert_eq!(request.coupling_iteration as usize, feedback_calls.len());
            assert_eq!(
                request.ending_snow_hint.is_some(),
                !feedback_calls.is_empty()
            );
            let result = transition(&CoveredTerminalFeedForwardRequestV1::from(request));
            feedback_calls.push(result.clone());
            Ok(result)
        };
        let two = invoke(
            &request,
            &mut CoveredTerminalProviderV1::Feedback(&mut feedback),
        )
        .unwrap();
        assert_eq!(forward_calls.len(), 1);
        assert_eq!(
            feedback_calls.len(),
            2,
            "feedback convergence still needs its second evaluation"
        );
        for reference in &feedback_calls {
            assert_eq!(one.1.boundary, reference.boundary);
            assert_eq!(
                boundary_bits(&one.1.boundary),
                boundary_bits(&reference.boundary)
            );
            assert_eq!(one.1.beginning_joint, reference.beginning_joint);
            assert_eq!(one.1.ending_joint, reference.ending_joint);
            assert_eq!(one.1.probe_child_identity, reference.probe_child_identity);
            assert_eq!(
                one.1.trial_snow_soil_receipt,
                reference.trial_snow_soil_receipt
            );
        }
        assert_eq!(flux_bits(one.0), flux_bits(two.0));
        let initial = TerminalState {
            ice_kg_m2: 10.0,
            liquid_kg_m2: 0.0,
            cold_content_j_m2: 0.0,
        };
        let one_preview = Wb11HydrologyKernel::terminal_transition(initial, one.0).unwrap();
        let two_preview = Wb11HydrologyKernel::terminal_transition(initial, two.0).unwrap();
        assert_eq!(one_preview.state, two_preview.state);
    }
}

#[test]
fn feed_forward_stale_support_role_attempt_and_beginning_fail_before_surface_math() {
    for poison in 0..5 {
        let request = request(CoveredTerminalTrialRoleV1::Full);
        let mut calls = 0;
        let mut provider = |request: CoveredTerminalFeedForwardRequestV1| {
            calls += 1;
            let mut receipt = transition(&request);
            // A second poison would fail downstream boundary/energy validation;
            // the invocation join must retain precedence over that failure.
            receipt.boundary.shortwave_energy_j_m2 = f64::NAN;
            match poison {
                0 => {
                    receipt.boundary.support =
                        TimeSupport::new(ModelTimeNs::new(0), ModelTimeNs::new(60_000_000_000))
                            .unwrap();
                }
                1 => receipt.probe_child_identity.role = CoveredTerminalTrialRoleV1::Retry,
                2 => receipt.probe_child_identity.attempt_ordinal += 1,
                3 => {
                    receipt.probe_child_identity.beginning_joint_sha256 =
                        Digest32::from_bytes([77; 32]);
                }
                _ => {
                    receipt.probe_child_identity.trial_support =
                        TimeSupport::new(ModelTimeNs::new(0), ModelTimeNs::new(60_000_000_000))
                            .unwrap();
                }
            }
            Ok(receipt)
        };
        let error = invoke(
            &request,
            &mut CoveredTerminalProviderV1::FeedForward(&mut provider),
        )
        .err()
        .unwrap();
        assert!(matches!(error, DirectSnowStage3EvaluationError::Kernel(_)));
        assert!(format!("{error:?}").contains("snow.terminal_trial_boundary_support_join"));
        assert_eq!(calls, 1);
    }
}
