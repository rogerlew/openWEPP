// Test-only full physical/custody reference oracle for EXP-STAGE3-20260906-F.
std::thread_local! {
    static FEED_FORWARD_REFERENCE_RECORDS: std::cell::RefCell<Option<Vec<(CoveredTerminalExecutionMode, crate::hydrology::CoveredTerminalTrialRoleV1, TimeSupport, u32)>>> = const { std::cell::RefCell::new(None) };
}

pub(crate) fn begin_feed_forward_reference_oracle() {
    FEED_FORWARD_REFERENCE_RECORDS.with(|records| *records.borrow_mut() = Some(Vec::new()));
}

pub(crate) fn take_feed_forward_reference_oracle() -> Vec<(
    CoveredTerminalExecutionMode,
    crate::hydrology::CoveredTerminalTrialRoleV1,
    TimeSupport,
    u32,
)> {
    FEED_FORWARD_REFERENCE_RECORDS.with(|records| {
        records
            .borrow_mut()
            .take()
            .expect("reference oracle enabled")
    })
}

fn assert_complete_feed_forward_reference(
    actual: &crate::v9_real_consumer_shadow::CoveredCarrierPhaseResultV1,
    reference: &crate::v9_real_consumer_shadow::CoveredCarrierPhaseResultV1,
) {
    // Debug's shortest round-trip float representation distinguishes every
    // admitted finite value, including signed zero. Compare all result fields;
    // no digest-only substitute for physical and custody payload equality.
    macro_rules! exact_field {
        ($($field:ident),+ $(,)?) => {$(
            assert_eq!(actual.$field, reference.$field, stringify!($field));
            assert_eq!(format!("{:?}", actual.$field), format!("{:?}", reference.$field), stringify!($field));
        )+};
    }
    exact_field!(
        beginning_stage3_by_lane,
        precipitation_sets,
        carrier_envelope,
        complete_lower_boundaries,
        carrier_source_receipts,
        open_snow_candidates,
        covered_lse_states,
        soil_candidate,
        soil_top_boundary_credit,
        batch_boundaries_by_lane,
        batch_terminal_snow_soil_trial_receipts_by_lane,
        batch_soil_top_boundary_credits_by_lane,
        wb14_child_receipt_set_sha256,
        wb14_parent_receipt_set_sha256,
        wb14_child_replay_bytes,
        wb14_parent_replay_bytes
    );
    assert_eq!(actual.transition.boundary, reference.transition.boundary);
    assert_eq!(
        actual.transition.beginning_joint,
        reference.transition.beginning_joint
    );
    assert_eq!(
        actual.transition.ending_joint,
        reference.transition.ending_joint
    );
    assert_eq!(
        actual.transition.probe_child_identity,
        reference.transition.probe_child_identity
    );
    assert_eq!(
        actual.transition.trial_snow_soil_receipt,
        reference.transition.trial_snow_soil_receipt
    );
    assert_eq!(
        format!("{:?}", actual.transition),
        format!("{:?}", reference.transition)
    );
    for (actual, reference) in [
        (
            &actual.beginning_candidates,
            &reference.beginning_candidates,
        ),
        (&actual.ending_candidates, &reference.ending_candidates),
    ] {
        actual.assert_exact_feed_forward_reference(reference);
        assert_eq!(actual.joint(), reference.joint());
        assert_eq!(actual.shadow(), reference.shadow());
        assert_eq!(
            actual
                .shadow()
                .canonical_owner_state_bytes()
                .expect("candidate owners"),
            reference
                .shadow()
                .canonical_owner_state_bytes()
                .expect("reference owners")
        );
        assert_eq!(
            format!("{:?}", actual.stage3_by_lane()),
            format!("{:?}", reference.stage3_by_lane())
        );
        assert_eq!(
            actual.terminal_snow_soil_trial_receipt(),
            reference.terminal_snow_soil_trial_receipt()
        );
        assert_eq!(
            format!("{:?}", actual.soil_continuation()),
            format!("{:?}", reference.soil_continuation())
        );
    }
}

#[allow(clippy::too_many_arguments)]
fn check_feed_forward_actual_carrier_reference(
    mode: CoveredTerminalExecutionMode,
    stack: &DirectV11SnowCoveredRealConsumerStack<'_>,
    beginning: &crate::v9_real_consumer_shadow::CoveredCarrierEphemeralCandidatesV1,
    request: &crate::hydrology::CoveredTerminalFeedForwardRequestV1,
    child: &CoveredProbeChildIdentityV1,
    actual: &crate::v9_real_consumer_shadow::CoveredCarrierPhaseResultV1,
    inputs: &crate::hydrology::DirectActiveSnowPartitionInputs,
    forcing: crate::hydrology::DirectSnowStage3SupportInput,
) {
    if !FEED_FORWARD_REFERENCE_RECORDS.with(|records| records.borrow().is_some()) {
        return;
    }
    let rollback_owners = beginning
        .shadow()
        .canonical_owner_state_bytes()
        .expect("beginning owners");
    let mut reference_request = request.observation_request();
    let first = stack
        .execute_covered_carrier_phase_v1(beginning, &reference_request, child.clone())
        .expect("first forced reference");
    assert_complete_feed_forward_reference(actual, &first);
    reference_request.ending_snow_hint = Some(
        Wb11HydrologyKernel::feed_forward_reference_hint(
            inputs,
            forcing,
            request,
            &first.transition,
        )
        .expect("canonical reference preview"),
    );
    reference_request.coupling_iteration = 1;
    let second = stack
        .execute_covered_carrier_phase_v1(beginning, &reference_request, child.clone())
        .expect("second forced reference");
    assert_complete_feed_forward_reference(actual, &second);
    let second_hint = Wb11HydrologyKernel::feed_forward_reference_hint(
        inputs,
        forcing,
        request,
        &second.transition,
    )
    .expect("second canonical reference preview");
    assert_eq!(
        format!("{:?}", reference_request.ending_snow_hint),
        format!("{:?}", Some(second_hint)),
        "exact-zero feedback delta"
    );
    assert_eq!(
        beginning
            .shadow()
            .canonical_owner_state_bytes()
            .expect("unchanged beginning"),
        rollback_owners
    );
    FEED_FORWARD_REFERENCE_RECORDS.with(|records| {
        records
            .borrow_mut()
            .as_mut()
            .expect("reference enabled")
            .push((mode, request.role, request.support, request.attempt_ordinal))
    });
}
