#[allow(clippy::wildcard_imports)]
use super::*;

/// Physical input for one independent carrier invocation (INV-SNOWENERGY-088).
/// Feedback coordinates are structurally absent from this interface.
#[derive(Clone, Debug)]
pub(crate) struct CoveredTerminalFeedForwardRequestV1 {
    pub lane_id: u32,
    pub support: TimeSupport,
    pub role: CoveredTerminalTrialRoleV1,
    pub attempt_ordinal: u32,
    pub ice_kg_m2: f64,
    pub liquid_kg_m2: f64,
    pub cold_content_j_m2: f64,
    pub surface_temperature_c: f64,
    pub snow_depth_m: f64,
    pub snow_density_kg_m3: f64,
    pub beginning_stage3_state: Box<DirectSnowStage3PersistentState>,
    pub beginning_joint: CoveredTerminalJointTrialStateV1,
}

impl From<CoveredTerminalTrialRequestV1> for CoveredTerminalFeedForwardRequestV1 {
    fn from(request: CoveredTerminalTrialRequestV1) -> Self {
        Self {
            lane_id: request.lane_id,
            support: request.support,
            role: request.role,
            attempt_ordinal: request.attempt_ordinal,
            ice_kg_m2: request.ice_kg_m2,
            liquid_kg_m2: request.liquid_kg_m2,
            cold_content_j_m2: request.cold_content_j_m2,
            surface_temperature_c: request.surface_temperature_c,
            snow_depth_m: request.snow_depth_m,
            snow_density_kg_m3: request.snow_density_kg_m3,
            beginning_stage3_state: request.beginning_stage3_state,
            beginning_joint: request.beginning_joint,
        }
    }
}

impl CoveredTerminalFeedForwardRequestV1 {
    /// Observation projection only: retained audit schemas describe the physical
    /// first call. Only the test-only forced reference may execute this shape.
    pub(crate) fn observation_request(&self) -> CoveredTerminalTrialRequestV1 {
        self.clone().into_feedback_request(None, 0)
    }

    pub(super) fn into_feedback_request(
        self,
        ending_snow_hint: Option<CoveredTerminalEndingSnowHintV1>,
        coupling_iteration: u32,
    ) -> CoveredTerminalTrialRequestV1 {
        CoveredTerminalTrialRequestV1 {
            lane_id: self.lane_id,
            support: self.support,
            role: self.role,
            attempt_ordinal: self.attempt_ordinal,
            coupling_iteration,
            ice_kg_m2: self.ice_kg_m2,
            liquid_kg_m2: self.liquid_kg_m2,
            cold_content_j_m2: self.cold_content_j_m2,
            surface_temperature_c: self.surface_temperature_c,
            snow_depth_m: self.snow_depth_m,
            snow_density_kg_m3: self.snow_density_kg_m3,
            beginning_stage3_state: self.beginning_stage3_state,
            ending_snow_hint,
            beginning_joint: self.beginning_joint,
        }
    }
}

pub(crate) type CoveredTerminalFeedForwardProviderV1<'a> = dyn FnMut(
        CoveredTerminalFeedForwardRequestV1,
    ) -> Result<CoveredTerminalTrialTransitionV1, DirectSnowStage3EvaluationError>
    + 'a;

/// Selected before evaluation; failures never select the other interface.
pub(crate) enum CoveredTerminalProviderV1<'a, 'b> {
    #[cfg(test)]
    Feedback(&'a mut CoveredTerminalTrialProviderV1<'b>),
    FeedForward(&'a mut CoveredTerminalFeedForwardProviderV1<'b>),
}

impl CoveredTerminalProviderV1<'_, '_> {
    /// The independently required resolved-domain call remains a single call.
    pub(super) fn evaluate_resolved(
        &mut self,
        request: CoveredTerminalTrialRequestV1,
    ) -> Result<CoveredTerminalTrialTransitionV1, DirectSnowStage3EvaluationError> {
        match self {
            #[cfg(test)]
            Self::Feedback(provider) => (**provider)(request),
            Self::FeedForward(provider) => (**provider)(request.into()),
        }
    }
}
