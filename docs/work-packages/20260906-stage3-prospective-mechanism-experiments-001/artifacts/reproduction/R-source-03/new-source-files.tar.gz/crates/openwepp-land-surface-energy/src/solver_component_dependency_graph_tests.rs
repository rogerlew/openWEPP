//! Independent INV164/C020 graph oracle: enumerate all pairs, then apply the
//! normative direct-read predicates. Never infer a direct edge from closure.
use super::*;

#[derive(Clone, Debug)]
struct OracleNode {
    id: String,
    family: &'static str,
    rank: usize,
    component: &'static str,
}

fn oracle_nodes(n: usize, s: usize) -> Vec<OracleNode> {
    let mut nodes = Vec::new();
    let mut add = |family, rank, component, id| {
        nodes.push(OracleNode {
            id,
            family,
            rank,
            component,
        });
    };
    for rank in 0..n {
        for component in ["sun", "shade", "wet", "stem"] {
            for family in ["probe", "occ.sensible", "occ.energy", "occ.tolerance"] {
                add(
                    family,
                    rank,
                    component,
                    format!("{family}[{rank},{component}]"),
                );
            }
        }
        for component in ["sun", "shade"] {
            for family in ["occ.leaf.current", "occ.leaf.maximum", "occ.vapor"] {
                add(
                    family,
                    rank,
                    component,
                    format!("{family}[{rank},{component}]"),
                );
            }
        }
        for family in [
            "route.prepare",
            "route.wet",
            "route.finalize",
            "longwave.layer",
            "occ.wet",
            "occ.hydraulic",
            "occ.liquid",
            "occ.route_match",
            "occ.output",
        ] {
            add(family, rank, "", format!("{family}[{rank}]"));
        }
    }
    for rank in 0..=n {
        for family in ["route.incident", "route.stemflow"] {
            add(family, rank, "", format!("{family}[{rank}]"));
        }
    }
    for rank in 0..10 * n + 3 + s {
        for family in ["residual.raw", "residual.tolerance", "residual.normalized"] {
            add(family, rank, "", format!("{family}[{rank}]"));
        }
    }
    for family in [
        "longwave.column",
        "lower.ground_output",
        "shared.heat",
        "shared.vapor",
        "shared.tolerance",
        "result.ground_release",
        "result.ground_stemflow",
        "result.output",
    ] {
        add(family, 0, "", family.to_string());
    }
    nodes.sort_by(|a, b| a.id.cmp(&b.id));
    nodes
}

fn required_direct(a: &OracleNode, b: &OracleNode, n: usize) -> bool {
    let same = a.rank == b.rank;
    let matching = same && a.component == b.component;
    let f = b.family;
    let component_row = ["occ.sensible", "occ.energy", "occ.tolerance"].contains(&f);
    let energy = ["occ.energy", "occ.tolerance"].contains(&f);
    let raw_tol = ["residual.raw", "residual.tolerance"].contains(&f);
    let shared = ["shared.heat", "shared.vapor", "shared.tolerance"].contains(&f);
    let output = f == "result.output";
    match a.family {
        "probe" => {
            same && (f == "longwave.layer"
                || f == "occ.output"
                || (matching && component_row)
                || (["sun", "shade"].contains(&a.component)
                    && (f == "occ.hydraulic"
                        || (matching
                            && ["occ.leaf.current", "occ.leaf.maximum", "occ.vapor"]
                                .contains(&f))))
                || (a.component == "wet"
                    && ["route.wet", "route.finalize", "occ.wet", "occ.liquid"].contains(&f)))
        }
        "route.incident" => {
            (same && a.rank < n && f == "route.prepare")
                || (a.rank == n && f == "result.ground_release")
        }
        "route.stemflow" => {
            (a.rank < n && b.rank == a.rank + 1 && f == "route.stemflow")
                || (a.rank == n && f == "result.ground_stemflow")
        }
        "route.prepare" => {
            same && ([
                "route.wet",
                "route.finalize",
                "longwave.layer",
                "occ.wet",
                "occ.vapor",
                "occ.hydraulic",
                "occ.sensible",
                "occ.energy",
                "occ.tolerance",
                "occ.liquid",
                "occ.output",
            ]
            .contains(&f))
        }
        "route.wet" => same && f == "route.finalize",
        "route.finalize" => {
            (b.rank == a.rank + 1 && ["route.incident", "route.stemflow"].contains(&f))
                || (same && f == "occ.route_match")
                || (a.rank + 1 == n
                    && ["result.ground_release", "result.ground_stemflow"].contains(&f))
        }
        "longwave.layer" => f == "longwave.column",
        "longwave.column" => energy || f == "occ.output" || f == "lower.ground_output" || output,
        "occ.leaf.current" => {
            same && (f == "occ.hydraulic"
                || f == "occ.output"
                || (matching && (energy || ["occ.leaf.maximum", "occ.vapor"].contains(&f))))
        }
        "occ.leaf.maximum" => {
            same && (f == "occ.hydraulic" || f == "occ.output" || (matching && f == "occ.vapor"))
        }
        "occ.vapor" => {
            f == "shared.vapor"
                || (same && (f == "occ.hydraulic" || f == "occ.output" || (matching && energy)))
        }
        "occ.wet" => {
            f == "shared.vapor"
                || (same
                    && (["occ.hydraulic", "occ.liquid", "occ.output"].contains(&f)
                        || (b.component == "wet" && energy)))
        }
        "occ.sensible" => {
            f == "shared.heat" || (same && (f == "occ.output" || (matching && energy)))
        }
        "occ.hydraulic" | "occ.energy" | "occ.tolerance" => same && f == "occ.output",
        "occ.liquid" => same && ["occ.output", "occ.route_match"].contains(&f),
        "occ.route_match" => same && f == "occ.output",
        "occ.output" => shared || output || (raw_tol && b.rank / 10 == a.rank),
        "lower.ground_output" => shared || output || (raw_tol && b.rank >= 10 * n + 2),
        "shared.heat" => f == "shared.tolerance" || output || (raw_tol && b.rank == 10 * n),
        "shared.vapor" => f == "shared.tolerance" || output || (raw_tol && b.rank == 10 * n + 1),
        "shared.tolerance" => {
            output
                || (["residual.tolerance", "residual.normalized"].contains(&f)
                    && [10 * n, 10 * n + 1].contains(&b.rank))
        }
        "result.ground_release" | "result.ground_stemflow" | "residual.normalized" => output,
        "residual.raw" | "residual.tolerance" => output || (same && f == "residual.normalized"),
        _ => false,
    }
}

fn oracle(n: usize, s: usize) -> (Vec<String>, Vec<(String, String)>) {
    let nodes = oracle_nodes(n, s);
    let edges = nodes
        .iter()
        .flat_map(|a| {
            nodes
                .iter()
                .filter_map(move |b| required_direct(a, b, n).then(|| (a.id.clone(), b.id.clone())))
        })
        .collect();
    (nodes.into_iter().map(|node| node.id).collect(), edges)
}

fn independent_hash(n: usize, s: usize, nodes: &[String], edges: &[(String, String)]) -> [u8; 32] {
    let mut fields = vec![
        "covered-component-temperature-dependency-v1".to_owned(),
        n.to_string(),
        s.to_string(),
        nodes.len().to_string(),
    ];
    fields.extend_from_slice(nodes);
    fields.push(edges.len().to_string());
    for (a, b) in edges {
        fields.extend([a.clone(), b.clone()]);
    }
    let bytes: Vec<u8> = fields
        .into_iter()
        .flat_map(|field| {
            (field.len() as u64)
                .to_be_bytes()
                .into_iter()
                .chain(field.into_bytes())
        })
        .collect();
    Sha256::digest(bytes).into()
}

#[test]
fn golden_schema_and_topology_hashes() {
    // Frozen from a separate Python hashlib/struct implementation of the
    // normative all-pairs oracle, before Rust compilation or graph execution.
    for (n, s, count, edge_count, golden) in [
        (
            1,
            1,
            85,
            254,
            "5119d5d7274807d5d871987d96a8ff1a75a8b9a2db790cf3fb83d1caa9ccf15f",
        ),
        (
            2,
            6,
            163,
            494,
            "cfd9d3c7f82c5871f8c6c953843f1d600f4929a7d9ba47c27f2494458e5a7b3b",
        ),
    ] {
        let (nodes, edges) = oracle(n, s);
        assert_eq!((nodes.len(), edges.len()), (count, edge_count));
        let expected = independent_hash(n, s, &nodes, &edges);
        let hex: String = expected.iter().map(|byte| format!("{byte:02x}")).collect();
        assert_eq!(hex, golden);
        let graph = CoveredComponentTemperatureDependencyGraph::new(n, s);
        assert_eq!(graph.schema_hash, expected);
    }
}

#[test]
fn unknown_read_never_proves_independence() {
    let (nodes, mut edges) = oracle(2, 6);
    edges.push(("probe[0,sun]".into(), "unrecognized.evaluator.read".into()));
    let graph =
        CoveredComponentTemperatureDependencyGraph::from_records(2, &nodes, &edges, [0; 32]);
    for coordinate in [6, 7, 8, 9, 16, 17, 18, 19] {
        assert!(!graph.coordinate_eligible(coordinate));
        assert!(graph.route_reachable(coordinate, 0));
        assert!(graph.leaf_current_reachable(coordinate, 1, true));
        assert!(graph.leaf_maximum_reachable(coordinate, 0, false));
    }
}

#[test]
fn exact_normative_direct_edges_and_every_single_edge_mutation() {
    for (n, s) in [(1, 1), (2, 6), (3, 2)] {
        let expected = oracle(n, s);
        let actual = graph_records(n, s);
        assert_eq!(actual, expected);
        let expected_hash = independent_hash(n, s, &expected.0, &expected.1);
        assert_eq!(graph_hash(n, s, &actual.0, &actual.1), expected_hash);
        for index in 0..actual.1.len() {
            let mut missing = actual.1.clone();
            missing.remove(index);
            assert_ne!(missing, expected.1, "missing edge {index}");
            assert_ne!(independent_hash(n, s, &actual.0, &missing), expected_hash);
            let mut changed = actual.1.clone();
            changed[index].1.push_str(".unknown");
            changed.sort();
            assert_ne!(changed, expected.1, "changed edge {index}");
            assert_ne!(independent_hash(n, s, &actual.0, &changed), expected_hash);
        }
    }
}

#[test]
fn compact_selectors_retain_all_lower_routes_and_exact_leaf_independence() {
    for (n, s) in [(1, 1), (2, 6), (4, 3)] {
        let graph = CoveredComponentTemperatureDependencyGraph::new(n, s);
        for changed in 0..n {
            for k in 0..4 {
                let coordinate = 10 * changed + 6 + k;
                assert!(graph.coordinate_eligible(coordinate));
                for rank in 0..n {
                    assert_eq!(
                        graph.route_reachable(coordinate, rank),
                        k == 2 && rank >= changed
                    );
                    for sun in [true, false] {
                        let expected = rank == changed && k == usize::from(!sun);
                        assert_eq!(
                            graph.leaf_current_reachable(coordinate, rank, sun),
                            expected
                        );
                        assert_eq!(
                            graph.leaf_maximum_reachable(coordinate, rank, sun),
                            expected
                        );
                    }
                }
            }
        }
        for coordinate in [0, 5, 10 * n, usize::MAX] {
            assert!(!graph.coordinate_eligible(coordinate));
            assert!(graph.route_reachable(coordinate, 0));
            assert!(graph.leaf_current_reachable(coordinate, 0, true));
        }
        assert!(graph.route_reachable(6, n));
        assert!(graph.leaf_maximum_reachable(6, n, false));
    }
}
