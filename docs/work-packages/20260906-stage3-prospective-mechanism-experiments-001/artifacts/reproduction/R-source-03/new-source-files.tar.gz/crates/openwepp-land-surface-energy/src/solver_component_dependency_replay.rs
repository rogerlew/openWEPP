// Private, same-sweep reuse of successful canonical evaluator nodes.
#[derive(Default, Debug, PartialEq)]
struct CoveredReplayCapture {
    preparations: Vec<CoveredLiquidPreparation>,
    ledgers: Vec<crate::CoveredOccupancyLiquidLedger>,
    leaves: Vec<[LeafTrialState; 4]>,
}

#[derive(Clone, Copy)]
struct CoveredReplayReuse<'a> {
    capture: &'a CoveredReplayCapture,
    graph: &'a CoveredComponentTemperatureDependencyGraph,
    coordinate: usize,
}

impl CoveredReplayReuse<'_> {
    fn leaves(&self, occupancy: usize) -> [Option<LeafTrialState>; 4] {
        let states = self.capture.leaves[occupancy];
        [
            (!self
                .graph
                .leaf_current_reachable(self.coordinate, occupancy, true))
            .then_some(states[0]),
            (!self
                .graph
                .leaf_current_reachable(self.coordinate, occupancy, false))
            .then_some(states[1]),
            (!self
                .graph
                .leaf_maximum_reachable(self.coordinate, occupancy, true))
            .then_some(states[2]),
            (!self
                .graph
                .leaf_maximum_reachable(self.coordinate, occupancy, false))
            .then_some(states[3]),
        ]
    }
}

fn covered_leaf_node(
    cached: Option<LeafTrialState>,
    evaluate: impl FnOnce() -> Result<LeafTrialState, LandSurfaceEnergyError>,
) -> Result<LeafTrialState, LandSurfaceEnergyError> {
    match cached {
        Some(value) => Ok(value),
        None => evaluate(),
    }
}

#[allow(clippy::too_many_arguments)]
fn covered_liquid_route_nodes(
    column: &CoveredColumnInputs,
    occupancy: &CoveredOccupancyInputs,
    incident_rain: f64,
    wet_temperature: f64,
    canopy_temperature: f64,
    canopy_q: f64,
    caps: Option<&CoveredWaterCaps>,
    frozen: Option<&CoveredFrozenBranches>,
) -> Result<
    (
        CoveredLiquidPreparation,
        crate::CoveredOccupancyLiquidLedger,
    ),
    LandSurfaceEnergyError,
> {
    let preparation = prepare_covered_liquid(occupancy, incident_rain)?;
    let (wet_flux, _) = covered_wet_flux(
        column,
        occupancy,
        preparation,
        wet_temperature,
        canopy_temperature,
        canopy_q,
        frozen,
    )?;
    let liquid = finalize_covered_liquid(
        preparation,
        wet_flux * column.interval_s,
        wet_temperature,
        if caps.is_some() {
            CoveredLiquidPass::FixedAuthorizationFinal
        } else {
            CoveredLiquidPass::Potential
        },
    )?;
    Ok((preparation, liquid))
}

#[cfg(any(test, feature = "test-support"))]
fn evaluate_covered_column_with_replay_capture(
    validated: &ValidatedCoveredEvaluationInputs<'_>,
    trial: &[f64],
    frozen: Option<&CoveredFrozenBranches>,
    replay: Option<(&CoveredReplayCapture, usize)>,
) -> Result<(CoveredColumnEvaluation, CoveredReplayCapture), LandSurfaceEnergyError> {
    let reuse = replay
        .map(|(capture, coordinate)| {
            validated
                .component_graph
                .as_ref()
                .map(|graph| CoveredReplayReuse {
                    capture,
                    graph,
                    coordinate,
                })
                .ok_or_else(component_replay_integrity)
        })
        .transpose()?;
    let mut capture = CoveredReplayCapture::default();
    let evaluation = evaluate_covered_column_observed(
        validated,
        trial,
        frozen,
        None,
        Some(&mut capture),
        reuse,
    )?;
    Ok((evaluation, capture))
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum CoveredProbeSign {
    Minus,
    Plus,
}

/// Generic non-Clone proof of canonical signed construction. This authorizes
/// no replay: regime/coordinate/graph selection precedes replay-capability minting.
struct ValidatedCoveredSignedProbe<'s, 'v> {
    base: &'s ValidatedCoveredJacobianBase<'v>,
    probe: Vec<f64>,
    coordinate: usize,
    sign: CoveredProbeSign,
    perturbation: f64,
    stencil: CoveredFiniteDifferenceStencil,
    graph_hash: Option<[u8; 32]>,
    lifecycle: Option<crate::solver_mechanism_audit::LifecycleContext>,
}

/// Minted only after represented-snow component graph eligibility is proven.
/// Its signed proof and successful base are consumed by one replay invocation.
struct ValidatedCoveredComponentProbeReplay<'s, 'v> {
    signed: ValidatedCoveredSignedProbe<'s, 'v>,
}

struct CoveredCanonicalProbePair<'s, 'v> {
    minus: Option<ValidatedCoveredSignedProbe<'s, 'v>>,
    plus: Option<ValidatedCoveredSignedProbe<'s, 'v>>,
    minus_value: f64,
    plus_value: f64,
    stencil: CoveredFiniteDifferenceStencil,
}

impl ValidatedCoveredSignedProbe<'_, '_> {
    fn evaluate_for(
        self,
        expected_base: &ValidatedCoveredJacobianBase<'_>,
        coordinate: usize,
        sign: CoveredProbeSign,
        perturbation: f64,
        stencil: CoveredFiniteDifferenceStencil,
    ) -> Result<Vec<f64>, LandSurfaceEnergyError> {
        if !std::ptr::eq(self.base, expected_base)
            || self.coordinate != coordinate
            || self.sign != sign
            || self.perturbation.to_bits() != perturbation.to_bits()
            || self.stencil != stencil
            || self.graph_hash
                != expected_base
                    .validated
                    .component_graph
                    .as_ref()
                    .map(|graph| graph.schema_hash)
            || self.lifecycle != expected_base.lifecycle
        {
            return Err(component_replay_integrity());
        }
        let expected = match sign {
            CoveredProbeSign::Minus => self.base.trial[coordinate] - perturbation,
            CoveredProbeSign::Plus => self.base.trial[coordinate] + perturbation,
        };
        if self.probe[coordinate].to_bits() != expected.to_bits() {
            return Err(component_replay_integrity());
        }
        if !force_complete_covered_jacobian_probes()
            && covered_component_replay_is_proved(expected_base, coordinate)
        {
            return covered_component_temperature_probe_residuals(
                expected_base,
                ValidatedCoveredComponentProbeReplay { signed: self },
            );
        }
        let mut observation =
            crate::solver_mechanism_audit::Scope::new(crate::solver_mechanism_audit::Kind::Probe);
        let result = covered_jacobian_probe_residuals_observed(
            expected_base,
            &self.probe,
            coordinate,
            &mut observation,
            true,
        );
        observation.finish(result)
    }
}

impl<'s, 'v> CoveredCanonicalProbePair<'s, 'v> {
    fn new(
        base: &'s ValidatedCoveredJacobianBase<'v>,
        coordinate: usize,
        perturbation: f64,
    ) -> Result<Self, LandSurfaceEnergyError> {
        let current = base
            .trial
            .get(coordinate)
            .ok_or_else(component_replay_integrity)?;
        let n = base.validated.column.occupancies.len();
        let unit = if coordinate < 10 * n {
            if coordinate % 10 < 4 { 1000.0 } else { 1.0 }
        } else if coordinate == 10 * n + 1 {
            0.001
        } else {
            1.0
        };
        if perturbation.to_bits() != (f64::EPSILON.sqrt() * current.abs().max(unit)).to_bits() {
            return Err(component_replay_integrity());
        }
        let mut minus = base.trial.clone();
        let mut plus = base.trial.clone();
        minus[coordinate] -= perturbation;
        plus[coordinate] += perturbation;
        let liquid_ground = covered_ground_uses_liquid_vapor_phase_domain(base.validated.column);
        let stencil =
            covered_finite_difference_stencil(&base.trial, &minus, &plus, n, liquid_ground)?;
        let minus_value = minus[coordinate];
        let plus_value = plus[coordinate];
        let graph_hash = base
            .validated
            .component_graph
            .as_ref()
            .map(|graph| graph.schema_hash);
        let lifecycle = base.lifecycle;
        let minus = covered_trial_is_valid(&minus, n, liquid_ground).then_some(
            ValidatedCoveredSignedProbe {
                base,
                probe: minus,
                coordinate,
                sign: CoveredProbeSign::Minus,
                perturbation,
                stencil,
                graph_hash,
                lifecycle,
            },
        );
        let plus = covered_trial_is_valid(&plus, n, liquid_ground).then_some(
            ValidatedCoveredSignedProbe {
                base,
                probe: plus,
                coordinate,
                sign: CoveredProbeSign::Plus,
                perturbation,
                stencil,
                graph_hash,
                lifecycle,
            },
        );
        Ok(Self {
            minus,
            plus,
            minus_value,
            plus_value,
            stencil,
        })
    }
}

fn covered_component_replay_is_proved(
    base: &ValidatedCoveredJacobianBase<'_>,
    coordinate: usize,
) -> bool {
    if !base
        .validated
        .component_graph
        .as_ref()
        .is_some_and(|graph| graph.coordinate_eligible(coordinate))
    {
        return false;
    }
    // EXP-STAGE3-20260906-R-PC1: affected maximum is exactly the
    // successful probe-current state only at bit-identical beta one.
    // Wet/stem temperatures change no canonical leaf-call operand.
    match coordinate % 10 {
        6 | 7 => base.trial[coordinate - 2].to_bits() == 1.0_f64.to_bits(),
        8 | 9 => true,
        _ => false,
    }
}

fn component_replay_integrity() -> LandSurfaceEnergyError {
    LandSurfaceEnergyError::ConstitutiveDomain("covered_component_dependency_replay_integrity")
}

fn covered_component_temperature_probe_residuals(
    base: &ValidatedCoveredJacobianBase<'_>,
    capability: ValidatedCoveredComponentProbeReplay<'_, '_>,
) -> Result<Vec<f64>, LandSurfaceEnergyError> {
    let capability = capability.signed;
    if !std::ptr::eq(base, capability.base)
        || capability.graph_hash
            != base
                .validated
                .component_graph
                .as_ref()
                .map(|graph| graph.schema_hash)
        || capability.lifecycle != base.lifecycle
    {
        return Err(component_replay_integrity());
    }
    let mut observation =
        crate::solver_mechanism_audit::Scope::new(crate::solver_mechanism_audit::Kind::Probe);
    let result = covered_jacobian_probe_residuals_observed(
        base,
        &capability.probe,
        capability.coordinate,
        &mut observation,
        true,
    );
    observation.finish(result)
}

/// Run the unchanged complete probe oracle in this thread, restoring its
/// previous posture on return or unwind. Experimental test support only.
#[cfg(any(test, feature = "test-support"))]
pub fn with_forced_complete_covered_probes<T>(evaluate: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            FORCE_COMPLETE_COVERED_JACOBIAN_PROBES.with(|force| force.set(self.0));
        }
    }
    let restore = Restore(FORCE_COMPLETE_COVERED_JACOBIAN_PROBES.with(|force| force.replace(true)));
    let result = evaluate();
    drop(restore);
    result
}

/// Check all captured fields on the first authentic N=2/S=6 potential and
/// fixed-final bases. This is a separate correctness run, never a timing mode.
#[cfg(any(test, feature = "test-support"))]
pub fn with_component_replay_runtime_oracle<T>(evaluate: impl FnOnce() -> T) -> T {
    component_replay_oracle::begin_runtime_replay_oracle();
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            if self.0 {
                let _ = component_replay_oracle::take_runtime_replay_oracle();
            }
        }
    }
    let mut restore = Restore(true);
    let result = evaluate();
    let seen = component_replay_oracle::take_runtime_replay_oracle();
    restore.0 = false;
    assert_eq!(
        seen,
        (true, true),
        "both authentic N2/S6 cap postures must complete the node oracle"
    );
    result
}

#[cfg(test)]
#[derive(Debug, PartialEq, Eq)]
enum CoveredSolveTrace {
    Matrix {
        jacobian: Vec<Vec<u64>>,
        rhs: Vec<u64>,
    },
    Linear {
        delta: Vec<u64>,
        pivot: u64,
        matrix_norm: u64,
    },
    Trial {
        iteration: u32,
        values: Vec<u64>,
        residuals: Vec<u64>,
    },
}

#[cfg(test)]
thread_local! {
    static COVERED_SOLVE_TRACE: std::cell::RefCell<Option<Vec<CoveredSolveTrace>>> = const { std::cell::RefCell::new(None) };
}

#[cfg(test)]
fn begin_covered_solve_trace() {
    COVERED_SOLVE_TRACE.with(|trace| *trace.borrow_mut() = Some(Vec::new()));
}

#[cfg(test)]
fn take_covered_solve_trace() -> Vec<CoveredSolveTrace> {
    COVERED_SOLVE_TRACE.with(|trace| trace.borrow_mut().take().unwrap_or_default())
}

#[cfg(test)]
fn record_covered_solve_trace(make: impl FnOnce() -> CoveredSolveTrace) {
    COVERED_SOLVE_TRACE.with(|trace| {
        if let Some(trace) = trace.borrow_mut().as_mut() {
            trace.push(make());
        }
    });
}

#[cfg(test)]
fn record_covered_trial_trace(iteration: u32, trial: &[f64], detail: &CoveredColumnEvaluation) {
    record_covered_solve_trace(|| CoveredSolveTrace::Trial {
        iteration,
        values: trial.iter().map(|value| value.to_bits()).collect(),
        residuals: detail
            .normalized_residuals
            .iter()
            .map(|value| value.to_bits())
            .collect(),
    });
}
