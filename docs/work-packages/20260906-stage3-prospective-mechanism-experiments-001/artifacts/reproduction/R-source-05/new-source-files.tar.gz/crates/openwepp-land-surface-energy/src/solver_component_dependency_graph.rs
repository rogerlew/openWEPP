//! EXP-STAGE3-20260906-R / INV164 topology descriptor, built outside sweeps.
//! The complete direct graph is reduced to the only cached node groups. The
//! canonical evaluator reexecutes the rest of its tail without reordering.
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};

const SCHEMA: &str = "covered-component-temperature-dependency-v1";
const COMPONENTS: [&str; 4] = ["sun", "shade", "wet", "stem"];

#[derive(Debug)]
pub(super) struct CoveredComponentTemperatureDependencyGraph {
    // Four component probes per occupancy; five groups per target occupancy:
    // routing trio, sun current, shade current, sun maximum, shade maximum.
    masks: Vec<Vec<[bool; 5]>>,
    complete: bool,
    pub(super) schema_hash: [u8; 32],
}

impl CoveredComponentTemperatureDependencyGraph {
    pub(super) fn new(occupancies: usize, soil: usize) -> Self {
        let (nodes, edges) = graph_records(occupancies, soil);
        let schema_hash = graph_hash(occupancies, soil, &nodes, &edges);
        Self::from_records(occupancies, &nodes, &edges, schema_hash)
    }

    fn from_records(
        n: usize,
        nodes: &[String],
        edges: &[(String, String)],
        schema_hash: [u8; 32],
    ) -> Self {
        let indices: BTreeMap<&str, usize> = nodes
            .iter()
            .enumerate()
            .map(|(index, node)| (node.as_str(), index))
            .collect();
        let mut adjacency = vec![Vec::new(); nodes.len()];
        let mut complete = n > 0;
        for (from, to) in edges {
            match (indices.get(from.as_str()), indices.get(to.as_str())) {
                (Some(&a), Some(&b)) => adjacency[a].push(b),
                _ => complete = false, // Unknown edges never establish independence.
            }
        }
        let mut masks = Vec::with_capacity(4 * n);
        for rank in 0..n {
            for component in COMPONENTS {
                let mut reached = vec![false; nodes.len()];
                if let Some(&start) = indices.get(node("probe", rank, component).as_str()) {
                    let mut pending = vec![start];
                    while let Some(index) = pending.pop() {
                        if !reached[index] {
                            reached[index] = true;
                            // Reversed push visits lexical adjacency in forward order.
                            pending.extend(adjacency[index].iter().rev().copied());
                        }
                    }
                } else {
                    complete = false;
                }
                let mut targets = Vec::with_capacity(n);
                for target in 0..n {
                    let mut reachable = |name: String| {
                        if let Some(&index) = indices.get(name.as_str()) {
                            reached[index]
                        } else {
                            complete = false;
                            true
                        }
                    };
                    let route = ["route.prepare", "route.wet", "route.finalize"]
                        .into_iter()
                        .map(|family| reachable(node(family, target, "")))
                        .fold(false, |a, b| a | b);
                    targets.push([
                        route,
                        reachable(node("occ.leaf.current", target, "sun")),
                        reachable(node("occ.leaf.current", target, "shade")),
                        reachable(node("occ.leaf.maximum", target, "sun")),
                        reachable(node("occ.leaf.maximum", target, "shade")),
                    ]);
                }
                masks.push(targets);
            }
        }
        Self {
            masks,
            complete,
            schema_hash,
        }
    }

    fn probe_index(&self, coordinate: usize) -> Option<usize> {
        if !self.complete || coordinate % 10 < 6 {
            return None;
        }
        let index = coordinate / 10 * 4 + coordinate % 10 - 6;
        (index < self.masks.len()).then_some(index)
    }

    pub(super) fn coordinate_eligible(&self, coordinate: usize) -> bool {
        self.probe_index(coordinate).is_some()
    }

    fn reachable(&self, coordinate: usize, occupancy: usize, group: usize) -> bool {
        self.probe_index(coordinate)
            .and_then(|index| self.masks.get(index))
            .and_then(|targets| targets.get(occupancy))
            .is_none_or(|mask| mask[group])
    }

    pub(super) fn route_reachable(&self, coordinate: usize, occupancy: usize) -> bool {
        self.reachable(coordinate, occupancy, 0)
    }

    pub(super) fn leaf_current_reachable(
        &self,
        coordinate: usize,
        occupancy: usize,
        sun: bool,
    ) -> bool {
        self.reachable(coordinate, occupancy, if sun { 1 } else { 2 })
    }

    pub(super) fn leaf_maximum_reachable(
        &self,
        coordinate: usize,
        occupancy: usize,
        sun: bool,
    ) -> bool {
        self.reachable(coordinate, occupancy, if sun { 3 } else { 4 })
    }
}

fn node(family: &str, rank: usize, component: &str) -> String {
    if component.is_empty() {
        format!("{family}[{rank}]")
    } else {
        format!("{family}[{rank},{component}]")
    }
}

fn graph_records(n: usize, s: usize) -> (Vec<String>, Vec<(String, String)>) {
    let mut nodes = BTreeSet::new();
    let mut edges = BTreeSet::new();
    for global in [
        "longwave.column",
        "lower.ground_output",
        "shared.heat",
        "shared.vapor",
        "shared.tolerance",
        "result.ground_release",
        "result.ground_stemflow",
        "result.output",
    ] {
        nodes.insert(global.to_owned());
    }
    for rank in 0..=n {
        nodes.insert(node("route.incident", rank, ""));
        nodes.insert(node("route.stemflow", rank, ""));
    }
    for row in 0..10 * n + 3 + s {
        for family in ["residual.raw", "residual.tolerance", "residual.normalized"] {
            nodes.insert(node(family, row, ""));
        }
    }
    for rank in 0..n {
        for family in [
            "route.prepare",
            "route.wet",
            "route.finalize",
            "longwave.layer",
            "occ.wet",
            "occ.hydraulic",
            "occ.liquid",
            "occ.route_match",
            "occ.output",
        ] {
            nodes.insert(node(family, rank, ""));
        }
        for component in COMPONENTS {
            for family in ["probe", "occ.sensible", "occ.energy", "occ.tolerance"] {
                nodes.insert(node(family, rank, component));
            }
        }
        for component in ["sun", "shade"] {
            for family in ["occ.leaf.current", "occ.leaf.maximum", "occ.vapor"] {
                nodes.insert(node(family, rank, component));
            }
        }
    }
    let mut edge = |a: String, b: String| {
        edges.insert((a, b));
    };
    for o in 0..n {
        for k in COMPONENTS {
            let probe = node("probe", o, k);
            edge(probe.clone(), node("longwave.layer", o, ""));
            edge(probe.clone(), node("occ.output", o, ""));
            for family in ["occ.sensible", "occ.energy", "occ.tolerance"] {
                edge(probe.clone(), node(family, o, k));
            }
            if k == "sun" || k == "shade" {
                edge(probe.clone(), node("occ.hydraulic", o, ""));
                for family in ["occ.leaf.current", "occ.leaf.maximum", "occ.vapor"] {
                    edge(probe.clone(), node(family, o, k));
                }
            } else if k == "wet" {
                for family in ["route.wet", "route.finalize", "occ.wet", "occ.liquid"] {
                    edge(probe.clone(), node(family, o, ""));
                }
            }
            for family in ["occ.energy", "occ.tolerance"] {
                edge("longwave.column".into(), node(family, o, k));
                edge(node("occ.sensible", o, k), node(family, o, k));
                edge(node(family, o, k), node("occ.output", o, ""));
            }
            edge(node("occ.sensible", o, k), node("occ.output", o, ""));
            edge(node("occ.sensible", o, k), "shared.heat".into());
        }
        edge(node("route.incident", o, ""), node("route.prepare", o, ""));
        edge(
            node("route.stemflow", o, ""),
            node("route.stemflow", o + 1, ""),
        );
        edge(node("route.wet", o, ""), node("route.finalize", o, ""));
        for family in ["route.incident", "route.stemflow"] {
            edge(node("route.finalize", o, ""), node(family, o + 1, ""));
        }
        edge(
            node("route.finalize", o, ""),
            node("occ.route_match", o, ""),
        );
        if o + 1 == n {
            edge(
                node("route.finalize", o, ""),
                "result.ground_release".into(),
            );
            edge(
                node("route.finalize", o, ""),
                "result.ground_stemflow".into(),
            );
        }
        for family in [
            "route.wet",
            "route.finalize",
            "longwave.layer",
            "occ.wet",
            "occ.hydraulic",
            "occ.liquid",
            "occ.output",
        ] {
            edge(node("route.prepare", o, ""), node(family, o, ""));
        }
        for k in COMPONENTS {
            for family in ["occ.sensible", "occ.energy", "occ.tolerance"] {
                edge(node("route.prepare", o, ""), node(family, o, k));
            }
        }
        for k in ["sun", "shade"] {
            edge(node("route.prepare", o, ""), node("occ.vapor", o, k));
            edge(
                node("occ.leaf.current", o, k),
                node("occ.leaf.maximum", o, k),
            );
            for family in ["occ.leaf.current", "occ.leaf.maximum"] {
                edge(node(family, o, k), node("occ.vapor", o, k));
            }
            for family in ["occ.leaf.current", "occ.leaf.maximum", "occ.vapor"] {
                edge(node(family, o, k), node("occ.hydraulic", o, ""));
                edge(node(family, o, k), node("occ.output", o, ""));
            }
            for family in ["occ.leaf.current", "occ.vapor"] {
                for target in ["occ.energy", "occ.tolerance"] {
                    edge(node(family, o, k), node(target, o, k));
                }
            }
            edge(node("occ.vapor", o, k), "shared.vapor".into());
        }
        edge(node("longwave.layer", o, ""), "longwave.column".into());
        edge("longwave.column".into(), node("occ.output", o, ""));
        for family in ["occ.hydraulic", "occ.liquid", "occ.output"] {
            edge(node("occ.wet", o, ""), node(family, o, ""));
        }
        for family in ["occ.energy", "occ.tolerance"] {
            edge(node("occ.wet", o, ""), node(family, o, "wet"));
        }
        edge(node("occ.wet", o, ""), "shared.vapor".into());
        for family in ["occ.hydraulic", "occ.liquid", "occ.route_match"] {
            edge(node(family, o, ""), node("occ.output", o, ""));
        }
        edge(node("occ.liquid", o, ""), node("occ.route_match", o, ""));
        for target in [
            "shared.heat",
            "shared.vapor",
            "shared.tolerance",
            "result.output",
        ] {
            edge(node("occ.output", o, ""), target.into());
        }
        for row in 10 * o..10 * (o + 1) {
            for family in ["residual.raw", "residual.tolerance"] {
                edge(node("occ.output", o, ""), node(family, row, ""));
            }
        }
    }
    edge(
        node("route.incident", n, ""),
        "result.ground_release".into(),
    );
    edge(
        node("route.stemflow", n, ""),
        "result.ground_stemflow".into(),
    );
    edge("longwave.column".into(), "lower.ground_output".into());
    edge("longwave.column".into(), "result.output".into());
    for target in [
        "shared.heat",
        "shared.vapor",
        "shared.tolerance",
        "result.output",
    ] {
        edge("lower.ground_output".into(), target.into());
    }
    for row in 10 * n + 2..10 * n + 3 + s {
        for family in ["residual.raw", "residual.tolerance"] {
            edge("lower.ground_output".into(), node(family, row, ""));
        }
    }
    for (offset, shared) in ["shared.heat", "shared.vapor"].into_iter().enumerate() {
        edge(shared.into(), "shared.tolerance".into());
        edge(shared.into(), "result.output".into());
        for family in ["residual.raw", "residual.tolerance"] {
            edge(shared.into(), node(family, 10 * n + offset, ""));
        }
        for family in ["residual.tolerance", "residual.normalized"] {
            edge("shared.tolerance".into(), node(family, 10 * n + offset, ""));
        }
    }
    for source in [
        "shared.tolerance",
        "result.ground_release",
        "result.ground_stemflow",
    ] {
        edge(source.into(), "result.output".into());
    }
    for row in 0..10 * n + 3 + s {
        for family in ["residual.raw", "residual.tolerance", "residual.normalized"] {
            edge(node(family, row, ""), "result.output".into());
            if family != "residual.normalized" {
                edge(node(family, row, ""), node("residual.normalized", row, ""));
            }
        }
    }
    (nodes.into_iter().collect(), edges.into_iter().collect())
}

fn graph_hash(n: usize, s: usize, nodes: &[String], edges: &[(String, String)]) -> [u8; 32] {
    let mut hash = Sha256::new();
    let mut field = |value: &str| {
        hash.update((value.len() as u64).to_be_bytes());
        hash.update(value.as_bytes());
    };
    for value in [
        SCHEMA.to_owned(),
        n.to_string(),
        s.to_string(),
        nodes.len().to_string(),
    ] {
        field(&value);
    }
    for value in nodes {
        field(value);
    }
    field(&edges.len().to_string());
    for (from, to) in edges {
        field(from);
        field(to);
    }
    hash.finalize().into()
}

#[cfg(test)]
#[path = "solver_component_dependency_graph_tests.rs"]
mod tests;
