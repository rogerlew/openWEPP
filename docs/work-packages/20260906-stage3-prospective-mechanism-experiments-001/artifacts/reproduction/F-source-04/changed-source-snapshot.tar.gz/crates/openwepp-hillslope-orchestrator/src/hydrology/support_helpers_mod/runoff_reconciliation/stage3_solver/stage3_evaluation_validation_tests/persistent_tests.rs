use super::*;

#[test]
fn persistent_operator_requires_stateful_api() {
    let inputs = reconciliation_inputs();
    assert!(
        Wb11HydrologyKernel::compute_direct_snow_liquid_partition_with_evaluation(
            &inputs,
            SnowStage3EvaluationOperator::PersistentAccumulationShadowV1,
        )
        .is_err()
    );
}

#[test]
fn persistent_shadow_accumulates_snow_and_censors_external_liquid() {
    let mut inputs = reconciliation_inputs();
    inputs.snow_layers.clear();
    inputs.runtime_swe_m = 0.0;
    inputs.runtime_depth_m = 0.0;
    inputs.runtime_density_kg_m3 = 0.0;
    inputs.hourly = [DirectSnowHourlyForcing {
        air_temperature_c: -5.0,
        ..DirectSnowHourlyForcing::zero()
    }; 24];
    inputs.hourly[0].snowfall_m = 0.02;
    inputs.hourly[0].hydrometeor_temperature_c = Some(-5.0);
    inputs.hourly[1].rain_m = 0.003;
    inputs.hourly[1].hydrometeor_temperature_c = Some(-5.0);
    let state = Wb11HydrologyKernel::initialize_stage3_persistent_state(7, Vec::new())
        .expect("valid empty carry");
    let mut dormant_inputs = inputs.clone();
    dormant_inputs.hourly[0].snowfall_m = 0.0;
    dormant_inputs.hourly[1].rain_m = 0.0;
    let dormant =
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&dormant_inputs, &state, 7, 0)
            .expect("dormant day");
    assert_eq!(dormant.lifecycle, "dormant");
    let day = Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &dormant.state, 7, 1)
        .expect("persistent day");
    assert_eq!(day.lifecycle, "reappeared");
    assert_eq!(day.snowfall_kg_m2.to_bits(), 2.0_f64.to_bits());
    assert_eq!(day.external_liquid_kg_m2.to_bits(), 3.0_f64.to_bits());
    assert!(
        (day.external_liquid_kg_m2 + day.melt_kg_m2 + day.start_retained_liquid_kg_m2
            - day.refrozen_kg_m2
            - day.end_retained_liquid_kg_m2
            - day.unresolved_liquid_kg_m2)
            .abs()
            <= 1.0e-12
    );
    assert!(day.end_ice_kg_m2 > 0.0);
    assert!(day.ice_mass_closure_residual_kg_m2.abs() <= 1.0e-9);
    assert_eq!(day.state.next_interval_index, 2);
}

#[test]
fn persistent_shadow_restore_is_exact_and_order_is_fail_closed() {
    let inputs = reconciliation_inputs();
    let mut nonfinite_layer = inputs.snow_layers[0];
    nonfinite_layer.settle_day_count = f64::NAN;
    assert!(
        Wb11HydrologyKernel::initialize_stage3_persistent_state(3, vec![nonfinite_layer],).is_err()
    );
    let initial =
        Wb11HydrologyKernel::initialize_stage3_persistent_state(3, inputs.snow_layers.clone())
            .expect("valid initial carry");
    let first = Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &initial, 3, 0)
        .expect("first day");
    let snapshot = Wb11HydrologyKernel::serialize_stage3_persistent_state(&first.state)
        .expect("serialize valid snapshot");
    let restored = Wb11HydrologyKernel::restore_stage3_persistent_state_json(&snapshot, 3, 1)
        .expect("valid fingerprint-bound restore");
    let uninterrupted =
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &first.state, 3, 1)
            .expect("uninterrupted second day");
    let resumed = Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &restored, 3, 1)
        .expect("restored second day");
    assert_eq!(uninterrupted, resumed);
    assert!(
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &restored, 4, 1,).is_err()
    );
    assert!(
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &restored, 3, 0,).is_err()
    );
    let mut corrupted = restored.clone();
    corrupted.cumulative_snowfall_kg_m2 += 1.0;
    assert!(Wb11HydrologyKernel::restore_stage3_persistent_state(corrupted, 3, 1,).is_err());
    assert_eq!(first.state, restored);
    let mut unknown = snapshot.clone();
    unknown.pop();
    unknown.extend_from_slice(b",\"unknown\":1}");
    assert!(Wb11HydrologyKernel::restore_stage3_persistent_state_json(&unknown, 3, 1,).is_err());
}

#[test]
fn persistent_shadow_disappears_dorms_and_reappears() {
    let mut inputs = reconciliation_inputs();
    inputs.snow_layers[0].mass_swe_m = 0.001_1;
    inputs.snow_layers[0].thickness_m = 0.002_2;
    inputs.snow_layers[0].cold_content_j_m2 = 0.0;
    inputs.hourly = [DirectSnowHourlyForcing {
        radiation_mj_m2: 1_000.0,
        air_temperature_c: 0.0,
        ..DirectSnowHourlyForcing::zero()
    }; 24];
    inputs.surface_energy_options.daily_solar_radiation_mj_m2 = 48.0;
    let initial =
        Wb11HydrologyKernel::initialize_stage3_persistent_state(9, inputs.snow_layers.clone())
            .unwrap();
    let disappeared =
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &initial, 9, 0).unwrap();
    assert_eq!(disappeared.lifecycle, "disappeared");

    let mut dormant_inputs = inputs.clone();
    dormant_inputs.hourly = [DirectSnowHourlyForcing::zero(); 24];
    let dormant = Wb11HydrologyKernel::evaluate_stage3_persistent_day(
        &dormant_inputs,
        &disappeared.state,
        9,
        1,
    )
    .unwrap();
    assert_eq!(dormant.lifecycle, "dormant");

    dormant_inputs.hourly[0] = DirectSnowHourlyForcing {
        snowfall_m: 0.02,
        air_temperature_c: -5.0,
        hydrometeor_temperature_c: Some(-5.0),
        ..DirectSnowHourlyForcing::zero()
    };
    let reappeared =
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&dormant_inputs, &dormant.state, 9, 2)
            .unwrap();
    assert_eq!(reappeared.lifecycle, "reappeared");
}

#[test]
fn terminal_event_request_is_state_bound_and_censors_remaining_time() {
    let mut inputs = reconciliation_inputs();
    inputs.snow_layers.truncate(1);
    inputs.snow_layers[0].mass_swe_m = 0.000_6;
    inputs.snow_layers[0].thickness_m = 0.001_2;
    inputs.snow_layers[0].cold_content_j_m2 = 0.0;
    inputs.snow_layers[0].temperature_c = 0.0;
    inputs.hourly = [DirectSnowHourlyForcing {
        radiation_mj_m2: 1_000.0,
        air_temperature_c: 0.0,
        ..DirectSnowHourlyForcing::zero()
    }; 24];
    inputs.surface_energy_options.daily_solar_radiation_mj_m2 = 48.0;
    let ordinary =
        Wb11HydrologyKernel::initialize_stage3_persistent_state(12, inputs.snow_layers.clone())
            .unwrap();
    assert_eq!(ordinary.schema_version, 2);
    assert_eq!(
        ordinary.terminal_event_model,
        Some(DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1.model)
    );
    let terminal = Wb11HydrologyKernel::initialize_stage3_persistent_state_with_terminal_event(
        12,
        inputs.snow_layers.clone(),
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .unwrap();
    assert_eq!(ordinary, terminal);
    let implicit =
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &terminal, 12, 0).unwrap();
    let day = Wb11HydrologyKernel::evaluate_stage3_persistent_day_with_terminal_event(
        &inputs,
        &terminal,
        12,
        0,
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .unwrap();
    assert_eq!(implicit, day);
    let event = day.terminal_event.expect("localized exhaustion event");
    assert!(event.event_occurred);
    assert!(event.evaluated_seconds > 0.0);
    assert!(event.unevaluated_seconds > 0.0);
    assert!(day.end_ice_kg_m2.abs() <= f64::EPSILON);
    assert!(day.state.layers.is_empty());
    assert!(event.solid_mass_closure_residual_kg_m2.abs() <= 1.0e-9);
    assert!(event.liquid_mass_closure_residual_kg_m2.abs() <= 1.0e-9);
    assert!(event.energy_closure_residual_j_m2.abs() <= 1.0e-6);
}

#[test]
fn persistent_support_evaluator_runs_one_admitted_parent_support() {
    let mut inputs = reconciliation_inputs();
    inputs.snow_layers[0].mass_swe_m = 0.000_6;
    inputs.snow_layers[0].thickness_m = 0.001_2;
    inputs.snow_layers[0].cold_content_j_m2 = 0.0;
    inputs.snow_layers[0].temperature_c = 0.0;
    inputs.hourly = [DirectSnowHourlyForcing {
        radiation_mj_m2: 1_000.0,
        air_temperature_c: 0.0,
        ..DirectSnowHourlyForcing::zero()
    }; 24];
    inputs.surface_energy_options.daily_solar_radiation_mj_m2 = 48.0;
    let state = Wb11HydrologyKernel::initialize_stage3_persistent_state_with_terminal_event(
        21,
        inputs.snow_layers.clone(),
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .expect("valid support state");
    let support = DirectSnowStage3SupportInput {
        forcing: inputs.hourly[0],
        duration_seconds: 1_800.0,
    };
    let result = Wb11HydrologyKernel::evaluate_stage3_persistent_support(
        &inputs,
        &state,
        21,
        0,
        support,
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .expect("one parent support must use the actual terminal solver");
    let event = result.terminal_event.expect("terminal result is retained");
    assert!(event.event_occurred);
    assert_eq!(result.evaluation.requested_seconds, 1_800.0);
    assert_eq!(event.requested_seconds, 1_800.0);
    assert!(event.evaluated_seconds > 0.0);
    assert!(event.unevaluated_seconds > 0.0);
    assert_eq!(result.state.next_interval_index, 1);
}

#[test]
fn resolved_terminal_model_calls_covered_provider_before_any_raw_carrier() {
    let mut inputs = reconciliation_inputs();
    inputs.snow_layers[0].mass_swe_m = 0.01;
    inputs.snow_layers[0].thickness_m = 0.02;
    inputs.snow_layers[0].cold_content_j_m2 = 0.0;
    inputs.snow_layers[0].temperature_c = 0.0;
    let state = Wb11HydrologyKernel::initialize_stage3_persistent_state_with_terminal_event(
        31,
        inputs.snow_layers.clone(),
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .expect("resolved terminal-model state");
    let support = DirectSnowStage3SupportInput {
        forcing: inputs.hourly[0],
        duration_seconds: 1_800.0,
    };
    let time_support = TimeSupport::new(ModelTimeNs::new(0), ModelTimeNs::new(1_800_000_000_000))
        .expect("exact support");
    let joint = CoveredTerminalJointTrialStateV1::try_new(
        JointTrialAuthorityV1 {
            source_owner_set_sha256: Digest32::from_bytes([8; 32]),
            lane_id: 1,
            source_snow_owner_sha256: Digest32::from_bytes([9; 32]),
            interval_index: 0,
            state_support: TimeSupport::new(
                ModelTimeNs::new(0),
                ModelTimeNs::new(3_600_000_000_000),
            )
            .unwrap(),
            accepted_predecessors: Vec::new(),
        },
        BTreeMap::from([
            ("vegetation".to_owned(), vec![1]),
            ("snow".to_owned(), vec![2]),
            ("land_surface_energy".to_owned(), vec![3]),
            ("hydrology".to_owned(), vec![4]),
            ("bgc".to_owned(), vec![5]),
            ("soil_thermal".to_owned(), vec![6]),
            ("surface_liquid".to_owned(), vec![7]),
        ]),
    )
    .expect("complete ephemeral owner set");
    let mut calls = 0_u32;
    let mut provider = |request: CoveredTerminalTrialRequestV1| {
        calls += 1;
        assert_eq!(request.lane_id, 31);
        assert_eq!(request.support.start_ns(), time_support.start_ns());
        Err(DirectSnowStage3EvaluationError::TerminalCustody(
            "resolved-covered-provider-called",
        ))
    };
    let result = Wb11HydrologyKernel::evaluate_stage3_terminal_support_with_trial_provider_v1(
        &inputs,
        &state,
        31,
        0,
        support,
        time_support,
        CoveredTerminalExecutionMode::DiscoveryProbe,
        joint,
        &mut provider,
    );
    assert_eq!(calls, 1, "{result:?}");
    assert!(matches!(
        result,
        Err(DirectSnowStage3EvaluationError::TerminalCustody(
            "resolved-covered-provider-called"
        ))
    ));
}

#[test]
fn covered_resolved_source_routes_provider_boundary_into_carrier() {
    let source = include_str!("../evaluation.rs");
    let resolved = source
        .split("let covered_substep_boundary")
        .nth(1)
        .expect("covered resolved seam");
    let before_next_function = resolved
        .split("fn ")
        .next()
        .expect("resolved evaluator body");
    assert_eq!(
        before_next_function
            .matches("provider.evaluate_resolved(CoveredTerminalTrialRequestV1")
            .count(),
        1,
        "resolved support retains its independent one-call provider seam"
    );
    assert!(before_next_function.contains("snow.resolved_terminal_trial_boundary_join"));
    assert!(before_next_function.contains("Some(transition.boundary)"));
    assert!(before_next_function.contains("boundary: covered_substep_boundary"));

    let provider_source = include_str!("../../terminal_carrier_provider.rs");
    let dispatch = provider_source
        .split("fn evaluate_resolved(")
        .nth(1)
        .expect("independent resolved dispatcher")
        .split("fn ")
        .next()
        .expect("resolved dispatcher body");
    for arm in [
        "Self::FeedForward(provider) => (**provider)(request.into())",
        "Self::Feedback(provider) => (**provider)(request)",
    ] {
        assert_eq!(dispatch.matches(arm).count(), 1, "direct callback {arm}");
    }
    assert_eq!(dispatch.matches("(**provider)(").count(), 2);
    assert!(!dispatch.contains("evaluate_terminal_carrier_invocation"));
    assert!(!dispatch.contains("evaluate_feedback_carrier_invocation"));
}

#[test]
fn terminal_no_event_refreeze_closes_persistent_day() {
    let mut inputs = reconciliation_inputs();
    inputs.snow_layers.truncate(1);
    inputs.snow_layers[0].mass_swe_m = 0.000_6;
    inputs.snow_layers[0].thickness_m = 0.001_2;
    inputs.snow_layers[0].liquid_water_m = 0.000_1;
    inputs.snow_layers[0].cold_content_j_m2 = 50_000.0;
    inputs.snow_layers[0].temperature_c = -5.0;
    inputs.hourly = [DirectSnowHourlyForcing {
        air_temperature_c: -10.0,
        ..DirectSnowHourlyForcing::zero()
    }; 24];
    let initial = Wb11HydrologyKernel::initialize_stage3_persistent_state_with_terminal_event(
        14,
        inputs.snow_layers.clone(),
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .unwrap();
    let day = Wb11HydrologyKernel::evaluate_stage3_persistent_day_with_terminal_event(
        &inputs,
        &initial,
        14,
        0,
        DirectSnowTerminalEventRequest::ENTHALPY_EVENT_V1,
    )
    .unwrap();
    assert!(day.refrozen_kg_m2 > 0.0);
    assert!(day.ice_mass_closure_residual_kg_m2.abs() <= 1.0e-12);
    assert!(day.total_water_closure_residual_kg_m2.abs() <= 1.0e-12);
    assert!(!day.terminal_intervals.is_empty());
    assert!(!day.terminal_intervals.last().unwrap().event_occurred);
}

#[test]
fn persistent_cold_rain_on_snow_refreezes_and_closes_linked_ledgers() {
    let mut inputs = reconciliation_inputs();
    inputs.snow_layers.truncate(1);
    inputs.snow_layers[0].mass_swe_m = 0.05;
    inputs.snow_layers[0].thickness_m = 0.10;
    inputs.snow_layers[0].cold_content_j_m2 = 1_000_000.0;
    inputs.snow_layers[0].temperature_c = -10.0;
    inputs.hourly = [DirectSnowHourlyForcing {
        air_temperature_c: -10.0,
        ..DirectSnowHourlyForcing::zero()
    }; 24];
    inputs.hourly[0].rain_m = 0.001;
    inputs.hourly[0].hydrometeor_temperature_c = Some(-5.0);
    let initial =
        Wb11HydrologyKernel::initialize_stage3_persistent_state(31, inputs.snow_layers.clone())
            .expect("valid cold persistent snow");

    let day = Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &initial, 31, 0)
        .expect("cold rain-on-snow must use the persistent liquid disposition");

    assert_eq!(day.external_liquid_kg_m2.to_bits(), 1.0_f64.to_bits());
    assert!(day.refrozen_kg_m2 > 0.0, "{day:?}");
    assert!(day.end_ice_kg_m2 > day.start_ice_kg_m2);
    assert!(day.ice_mass_closure_residual_kg_m2.abs() <= 1.0e-9);
    assert!(day.total_water_closure_residual_kg_m2.abs() <= 1.0e-9);
}

#[test]
fn persistent_warm_rain_on_isothermal_snow_does_not_refreeze() {
    let mut layers = vec![DirectSnowLayerState {
        mass_swe_m: 0.05,
        thickness_m: 0.10,
        density_kg_m3: 500.0,
        settle_day_count: 1.0,
        temperature_c: 0.0,
        liquid_water_m: 0.0,
        cold_content_j_m2: 0.0,
        refrozen_liquid_m: 0.0,
    }];
    let mut cold_content = vec![0.0];
    let beginning_ice_kg_m2 = layers[0].mass_swe_m * STAGE3_RHO_WATER_KG_M3;
    let (routed, retained, refrozen) =
        Wb11HydrologyKernel::route_stage3_persistent_liquid_through_layers(
            HillslopeKernelPhaseClass::HydrologyRunoffReconciliation,
            1.0,
            &mut layers,
            &mut cold_content,
        )
        .expect("isothermal snow must disposition warm rain without refreezing");

    assert_eq!(refrozen.to_bits(), 0.0_f64.to_bits());
    assert_eq!(
        (layers[0].mass_swe_m * STAGE3_RHO_WATER_KG_M3).to_bits(),
        beginning_ice_kg_m2.to_bits()
    );
    assert!((1.0 - routed - retained).abs() <= 1.0e-12);
}

#[test]
fn persistent_refreeze_capacity_roundoff_canonicalizes_zero_and_closes_ledgers() {
    let beginning_cold_content_j_m2 = 10.9;
    let refreeze_capacity_kg_m2 = beginning_cold_content_j_m2 / STAGE3_LATENT_HEAT_FUSION_J_KG;
    let refreeze_energy_j_m2 = refreeze_capacity_kg_m2 * STAGE3_LATENT_HEAT_FUSION_J_KG;
    let raw_energy_remainder_j_m2 = beginning_cold_content_j_m2 - refreeze_energy_j_m2;
    assert!(raw_energy_remainder_j_m2 < 0.0);
    assert!(raw_energy_remainder_j_m2.abs() <= STAGE3_REFREEZE_COLD_CONTENT_ROUNDOFF_J_M2);

    let mut layers = vec![DirectSnowLayerState {
        mass_swe_m: 0.05,
        thickness_m: 0.10,
        density_kg_m3: 500.0,
        settle_day_count: 1.0,
        temperature_c: -1.0,
        liquid_water_m: 0.0,
        cold_content_j_m2: beginning_cold_content_j_m2,
        refrozen_liquid_m: 0.0,
    }];
    let beginning_ice_kg_m2 = layers[0].mass_swe_m * STAGE3_RHO_WATER_KG_M3;
    let mut cold_content = vec![beginning_cold_content_j_m2];
    let (routed, retained, refrozen) =
        Wb11HydrologyKernel::route_stage3_persistent_liquid_through_layers(
            HillslopeKernelPhaseClass::HydrologyRunoffReconciliation,
            refreeze_capacity_kg_m2,
            &mut layers,
            &mut cold_content,
        )
        .expect("capacity-limited refreeze roundoff must canonicalize at its generating seam");

    assert_eq!(routed.to_bits(), 0.0_f64.to_bits());
    assert_eq!(retained.to_bits(), 0.0_f64.to_bits());
    assert_eq!(refrozen.to_bits(), refreeze_capacity_kg_m2.to_bits());
    assert_eq!(cold_content[0].to_bits(), 0.0_f64.to_bits());
    assert_eq!(layers[0].cold_content_j_m2.to_bits(), 0.0_f64.to_bits());
    assert!(
        (refreeze_capacity_kg_m2 - routed - retained - refrozen).abs()
            <= SNOW_STAGE3_LIQUID_CLOSURE_TOLERANCE_M * STAGE3_RHO_WATER_KG_M3
    );
    assert!(
        (layers[0].mass_swe_m * STAGE3_RHO_WATER_KG_M3 - beginning_ice_kg_m2 - refrozen).abs()
            <= 1.0e-12
    );
    assert!(raw_energy_remainder_j_m2.abs() <= STAGE3_ENERGY_CLOSURE_TOLERANCE_J_M2);
}

#[test]
fn persistent_refreeze_roundoff_poison_rejects_material_or_wrong_branch_negative() {
    let phase_class = HillslopeKernelPhaseClass::HydrologyRunoffReconciliation;
    assert!(
        Wb11HydrologyKernel::canonical_stage3_refreeze_cold_content_remainder(
            phase_class,
            10.9,
            10.9 + 2.0 * STAGE3_REFREEZE_COLD_CONTENT_ROUNDOFF_J_M2,
            true,
        )
        .is_err()
    );
    assert!(
        Wb11HydrologyKernel::canonical_stage3_refreeze_cold_content_remainder(
            phase_class,
            10.9,
            10.9 + 0.5 * STAGE3_REFREEZE_COLD_CONTENT_ROUNDOFF_J_M2,
            false,
        )
        .is_err()
    );
}

#[test]
fn persistent_rain_disposition_failure_preserves_beginning_owner() {
    let mut inputs = reconciliation_inputs();
    inputs.hourly[0].rain_m = f64::NAN;
    let beginning =
        Wb11HydrologyKernel::initialize_stage3_persistent_state(33, inputs.snow_layers.clone())
            .expect("valid beginning owner");
    let immutable_snapshot = beginning.clone();

    assert!(
        Wb11HydrologyKernel::evaluate_stage3_persistent_day(&inputs, &beginning, 33, 0).is_err()
    );
    assert_eq!(beginning, immutable_snapshot);
}
