#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct CoveredStepNorms {
    pub hydraulic_mm: f64,
    pub beta: f64,
    pub temperature_k: f64,
    pub humidity_kg_kg: f64,
    pub ci_pa: f64,
}

impl CoveredStepNorms {
    fn accepted(self) -> bool {
        self.hydraulic_mm <= 1.0e-7
            && self.beta <= 1.0e-10
            && self.temperature_k
                <= crate::snow_accuracy_policy::Policy::current().temperature_step()
            && self.humidity_kg_kg <= 1.0e-12
    }

    pub(crate) fn diagnostics(self) -> StepNorms {
        StepNorms {
            temperature_k: Some(self.temperature_k),
            humidity_kg_kg: Some(self.humidity_kg_kg),
            ci_pa: Some(self.ci_pa),
            hydraulic_mm: Some(self.hydraulic_mm),
            beta: Some(self.beta),
        }
    }

    fn governed_threshold_exceeded(self) -> bool {
        [
            self.hydraulic_mm,
            self.beta,
            self.temperature_k,
            self.humidity_kg_kg,
        ]
        .iter()
        .all(|step| step.is_finite())
            && (self.hydraulic_mm > 1.0e-7
                || self.beta > 1.0e-10
                || self.temperature_k
                    > crate::snow_accuracy_policy::Policy::current().temperature_step()
                || self.humidity_kg_kg > 1.0e-12)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum CoveredFullTrialNoUpdateRefusal {
    DomainInvalid,
    GovernedStepThresholdExceeded,
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum CoveredHalvedTrialProbe {
    DomainInvalid,
    EvaluationIncomplete,
    Complete(CoveredStepNorms),
}

/// Test-only selection for the adopted fixed-grid diagnostic experiment.
///
/// Normal crate execution always retains the canonical `0..=20` grid.  The
/// treatment value can only be installed by the private ignored libtest entry.
#[cfg(test)]
#[derive(Clone, Copy, Debug, Eq, PartialEq, serde::Serialize)]
pub(crate) enum Grid40StrictDecreaseGrid {
    Baseline,
    Treatment,
}

#[cfg(test)]
std::thread_local! {
    static GRID40_STRICT_GRID: std::cell::Cell<Grid40StrictDecreaseGrid> =
        const { std::cell::Cell::new(Grid40StrictDecreaseGrid::Baseline) };
}

#[cfg(test)]
pub(crate) struct Grid40StrictDecreaseGridGuard {
    previous: Grid40StrictDecreaseGrid,
}

#[cfg(test)]
pub(crate) fn grid40_install_strict_decrease_grid(
    grid: Grid40StrictDecreaseGrid,
) -> Grid40StrictDecreaseGridGuard {
    let previous = GRID40_STRICT_GRID.with(|active| {
        let previous = active.get();
        active.set(grid);
        previous
    });
    Grid40StrictDecreaseGridGuard { previous }
}

#[cfg(test)]
impl Drop for Grid40StrictDecreaseGridGuard {
    fn drop(&mut self) {
        GRID40_STRICT_GRID.with(|active| active.set(self.previous));
    }
}

/// Test-only accounting for the fixed experiment.  It is inert unless the
/// private ignored replay installs a session, so ordinary tests and production
/// selection cannot observe it.
#[cfg(test)]
#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize)]
pub(crate) struct Grid40CallCounts {
    pub numerical_identity: &'static str,
    pub base: u32,
    pub jacobian_assembly: u32,
    pub updates: u32,
    pub witness: u32,
    pub strict: u32,
    pub signed_probe: u32,
    /// Actual leaf-Ci bracket-loop iterations (labels 3 through 64 only).
    /// It excludes endpoint setup/repeats, dark bracketing, and final carbon
    /// evaluations; it is inventory only, never a residual admission or budget.
    pub ci_bracket_loop_iterations: u32,
    pub domain_predicate: u32,
    pub ordinary: u32,
    pub complete: u32,
    pub errors: u32,
    pub inflight: u32,
    pub denied: u32,
    pub next_operation_id: u64,
    pub inflight_operation_ids: Vec<u64>,
    pub budget_stop: Option<&'static str>,
    /// Exponents of installed strict-decrease trials, in solver order.  This
    /// is private experiment evidence and never enters the ordinary trace.
    pub accepted_strict_exponents: Vec<u32>,
    /// Every real strict-search candidate, recorded before its existing
    /// domain guard. This distinguishes an attempted invalid candidate from
    /// a complete evaluator call.
    pub strict_attempted_exponents: Vec<u32>,
    pub strict_attempted_trial_bits: Vec<Vec<u64>>,
    /// Ordered private accounting events for independent replay-side recount.
    /// These never enter the established ordinary diagnostic trace.
    pub events: Vec<Grid40OperationEvent>,
}

#[cfg(test)]
#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize)]
pub(crate) struct Grid40OperationEvent {
    pub operation_id: u64,
    pub strict_exponent: Option<u32>,
    /// The signed Jacobian probe that caused this complete evaluator call.
    /// Counter classes retain their own operation IDs; this is the only
    /// private parent/child join and never enters the ordinary trace.
    pub related_operation_id: Option<u64>,
    pub operation: &'static str,
    pub counter_class: &'static str,
    pub admitted: bool,
    pub phase: &'static str,
    pub typed_error: Option<String>,
}

/// Private unwind payload for the ignored original-start replay only.  This is
/// deliberately not a `LandSurfaceEnergyError`: canonical/public solver error
/// behavior must remain unchanged when no test session is installed.
#[cfg(test)]
#[derive(Debug)]
pub(crate) struct Grid40BudgetStop {
    pub operation: &'static str,
}

/// Private evidence-channel failure.  This never represents numerical
/// nonconvergence or a resource budget disposition.
#[cfg(test)]
#[derive(Debug)]
pub(crate) struct Grid40EvidenceFailure {
    pub channel: &'static str,
    pub detail: String,
}

#[cfg(test)]
std::thread_local! {
    static GRID40_COUNTS: std::cell::RefCell<Option<Grid40CallCounts>> = const { std::cell::RefCell::new(None) };
    static GRID40_EVENT_PATH_FOR_TEST: std::cell::RefCell<Option<std::path::PathBuf>> = const { std::cell::RefCell::new(None) };
    static GRID40_STRICT_FAULT_EXPONENT: std::cell::Cell<Option<u32>> = const { std::cell::Cell::new(None) };
    static GRID40_REPLAY_ACTIVE: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
    static GRID40_ACTIVE_STRICT_EXPONENT: std::cell::Cell<Option<u32>> = const { std::cell::Cell::new(None) };
}

#[cfg(test)]
pub(crate) fn grid40_set_event_path_for_test(path: Option<std::path::PathBuf>) {
    GRID40_EVENT_PATH_FOR_TEST.with(|value| *value.borrow_mut() = path);
}

#[cfg(test)]
pub(crate) struct Grid40StrictFaultGuard(Option<u32>);

#[cfg(test)]
struct Grid40ActiveStrictExponentGuard(Option<u32>);

#[cfg(test)]
impl Grid40ActiveStrictExponentGuard {
    fn install(exponent: u32) -> Self {
        Self(GRID40_ACTIVE_STRICT_EXPONENT.with(|active| {
            let previous = active.get();
            active.set(Some(exponent));
            previous
        }))
    }
}

#[cfg(test)]
impl Drop for Grid40ActiveStrictExponentGuard {
    fn drop(&mut self) {
        GRID40_ACTIVE_STRICT_EXPONENT.with(|active| active.set(self.0));
    }
}

#[cfg(test)]
pub(crate) struct Grid40ReplayGuard;

#[cfg(test)]
pub(crate) fn grid40_begin_replay_for_test() -> Grid40ReplayGuard {
    GRID40_REPLAY_ACTIVE.with(|replay| {
        assert!(!replay.get(), "grid40 replay already active");
        assert!(
            GRID40_STRICT_FAULT_EXPONENT.with(|fault| fault.get().is_none()),
            "grid40 replay and strict fault are mutually exclusive"
        );
        replay.set(true);
    });
    Grid40ReplayGuard
}

#[cfg(test)]
impl Drop for Grid40ReplayGuard {
    fn drop(&mut self) {
        GRID40_REPLAY_ACTIVE.with(|replay| replay.set(false));
    }
}

#[cfg(test)]
pub(crate) fn grid40_force_strict_evaluator_error_for_test(
    exponent: u32,
) -> Grid40StrictFaultGuard {
    let previous = GRID40_STRICT_FAULT_EXPONENT.with(|value| {
        assert!(
            !GRID40_REPLAY_ACTIVE.with(std::cell::Cell::get),
            "grid40 replay and strict fault are mutually exclusive"
        );
        assert!(
            GRID40_COUNTS.with(|counts| counts.borrow().is_some()),
            "grid40 strict fault requires an active counter session"
        );
        let previous = value.get();
        value.set(Some(exponent));
        previous
    });
    Grid40StrictFaultGuard(previous)
}

#[cfg(test)]
impl Drop for Grid40StrictFaultGuard {
    fn drop(&mut self) {
        GRID40_STRICT_FAULT_EXPONENT.with(|value| value.set(self.0));
    }
}

#[cfg(test)]
pub(crate) struct Grid40CallCountSession;

#[cfg(test)]
pub(crate) fn grid40_begin_call_counts(grid: Grid40StrictDecreaseGrid) -> Grid40CallCountSession {
    GRID40_COUNTS.with(|counts| {
        assert!(
            counts.borrow().is_none(),
            "grid40 counter session already active"
        );
        assert_eq!(
            GRID40_STRICT_GRID.with(std::cell::Cell::get),
            grid,
            "grid40 session policy must be installed before counter admission"
        );
        let session = Grid40CallCounts {
            numerical_identity: match grid {
            Grid40StrictDecreaseGrid::Baseline => {
                "EXP-B01-LSE-GRID40-20260919;strict=0..20;witness=0..20;updates=50"
            }
            Grid40StrictDecreaseGrid::Treatment => {
                "EXP-B01-LSE-GRID40-20260919;strict=0..40;witness=0..20;updates=50"
            }
            },
            ..Grid40CallCounts::default()
        };
        *counts.borrow_mut() = Some(session);
    });
    Grid40CallCountSession
}

#[cfg(test)]
impl Grid40CallCountSession {
    pub(crate) fn finish(self) -> Grid40CallCounts {
        let _ = self;
        GRID40_COUNTS.with(|counts| counts.borrow_mut().take().expect("active grid40 counters"))
    }
}

#[cfg(test)]
fn grid40_increment(
    operation: &'static str,
    select: impl FnOnce(&mut Grid40CallCounts) -> &mut u32,
    ceiling: u32,
) {
    GRID40_COUNTS.with(|counts| {
        let denied = if let Some(counts) = counts.borrow_mut().as_mut() {
            let operation_id = grid40_next_operation_id(counts);
            let value = select(counts);
            if *value >= ceiling {
                counts.denied += 1;
                counts.budget_stop = Some(operation);
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    operation,
                    false,
                    "denied",
                    None,
                    None,
                );
                true
            } else {
                *value += 1;
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    operation,
                    true,
                    "started",
                    None,
                    None,
                );
                false
            }
        } else {
            false
        };
        if denied {
            std::panic::panic_any(Grid40BudgetStop { operation });
        }
    })
}

#[cfg(test)]
fn grid40_event(
    counts: &mut Grid40CallCounts,
    operation_id: u64,
    operation: &'static str,
    counter_class: &'static str,
    admitted: bool,
    phase: &'static str,
    typed_error: Option<String>,
    related_operation_id: Option<u64>,
) {
    let event = Grid40OperationEvent {
        operation_id,
        strict_exponent: GRID40_ACTIVE_STRICT_EXPONENT.with(std::cell::Cell::get),
        related_operation_id,
        operation,
        counter_class,
        admitted,
        phase,
        typed_error,
    };
    let path = GRID40_EVENT_PATH_FOR_TEST
        .with(|value| value.borrow().clone())
        .or_else(|| std::env::var_os("OPENWEPP_GRID40_EVENTS").map(Into::into));
    if let Some(path) = path {
        let line = match serde_json::to_vec(&event) {
            Ok(mut line) => {
                line.push(b'\n');
                line
            }
            Err(error) => std::panic::panic_any(Grid40EvidenceFailure {
                channel: "event_journal_serialize",
                detail: error.to_string(),
            }),
        };
        let write = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(path)
            .and_then(|mut file| std::io::Write::write_all(&mut file, &line));
        if let Err(error) = write {
            std::panic::panic_any(Grid40EvidenceFailure {
                channel: "event_journal_write",
                detail: error.to_string(),
            });
        }
    }
    counts.events.push(event);
}

#[cfg(test)]
fn grid40_next_operation_id(counts: &mut Grid40CallCounts) -> u64 {
    counts.next_operation_id = counts
        .next_operation_id
        .checked_add(1)
        .expect("grid40 operation id overflow");
    counts.next_operation_id
}

#[derive(Clone, Copy)]
enum Grid40EvaluationClass {
    Base,
    Witness,
    #[cfg(test)]
    Strict,
    Other,
}

impl Grid40EvaluationClass {
    #[cfg(test)]
    const fn name(self) -> &'static str {
        match self {
            Self::Base => "base",
            Self::Witness => "witness",
            #[cfg(test)]
            Self::Strict => "strict",
            Self::Other => "jacobian",
        }
    }
}

#[cfg(test)]
fn grid40_admit_evaluation(
    operation: &'static str,
    class: Grid40EvaluationClass,
    ordinary: bool,
    ordinary_ceiling: u32,
    complete_ceiling: u32,
    signed_parent_id: Option<u64>,
) -> Option<u64> {
    GRID40_COUNTS.with(|counts| {
        let denied = if let Some(counts) = counts.borrow_mut().as_mut() {
            let operation_id = grid40_next_operation_id(counts);
            // Both category limits are checked before either start is
            // committed: a complete-cap denial must not leave an ordinary
            // evaluator attempt that never entered the canonical evaluator.
            let class_at_cap = match class {
                Grid40EvaluationClass::Base => counts.base >= 51,
                Grid40EvaluationClass::Witness => counts.witness >= 100,
                Grid40EvaluationClass::Strict => {
                    let limit = if matches!(
                        GRID40_STRICT_GRID.with(std::cell::Cell::get),
                        Grid40StrictDecreaseGrid::Baseline
                    ) {
                        1_050
                    } else {
                        2_050
                    };
                    counts.strict >= limit
                }
                Grid40EvaluationClass::Other => false,
            };
            if class_at_cap
                || (ordinary && counts.ordinary >= ordinary_ceiling)
                || counts.complete >= complete_ceiling
            {
                counts.denied += 1;
                counts.budget_stop = Some(operation);
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    class.name(),
                    false,
                    "denied",
                    None,
                    signed_parent_id,
                );
                if let Some(parent_id) = signed_parent_id {
                    grid40_finish_signed_probe(
                        counts,
                        parent_id,
                        "child_complete_evaluation_denied",
                        Some(format!("child_operation_id={operation_id}")),
                    );
                }
                true
            } else {
                match class {
                    Grid40EvaluationClass::Base => counts.base += 1,
                    Grid40EvaluationClass::Witness => counts.witness += 1,
                    Grid40EvaluationClass::Strict => counts.strict += 1,
                    Grid40EvaluationClass::Other => {}
                }
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    class.name(),
                    true,
                    "started",
                    None,
                    signed_parent_id,
                );
                if ordinary {
                    counts.ordinary += 1;
                    grid40_event(
                        counts,
                        operation_id,
                        operation,
                        "ordinary",
                        true,
                        "started",
                        None,
                        signed_parent_id,
                    );
                }
                counts.complete += 1;
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    "complete",
                    true,
                    "started",
                    None,
                    signed_parent_id,
                );
                counts.inflight += 1;
                counts.inflight_operation_ids.push(operation_id);
                if let Some(parent_id) = signed_parent_id {
                    grid40_event(
                        counts,
                        parent_id,
                        "signed_jacobian_probe",
                        "signed_jacobian_probe",
                        true,
                        "child_complete_evaluation_started",
                        Some(format!("child_operation_id={operation_id}")),
                        Some(operation_id),
                    );
                }
                return Some(operation_id);
            }
        } else {
            false
        };
        if denied {
            std::panic::panic_any(Grid40BudgetStop { operation });
        }
        None
    })
}

#[cfg(test)]
fn grid40_evaluate_with_parent<T>(
    operation: &'static str,
    class: Grid40EvaluationClass,
    ordinary: bool,
    signed_parent_id: Option<u64>,
    call: impl FnOnce() -> Result<T, LandSurfaceEnergyError>,
) -> Result<T, LandSurfaceEnergyError> {
    let grid = GRID40_STRICT_GRID.with(std::cell::Cell::get);
    let ordinary_ceiling = match grid {
        Grid40StrictDecreaseGrid::Baseline => 1_201,
        Grid40StrictDecreaseGrid::Treatment => 2_201,
    };
    let complete_ceiling = match grid {
        Grid40StrictDecreaseGrid::Baseline => 4_101,
        Grid40StrictDecreaseGrid::Treatment => 5_101,
    };
    let operation_id = grid40_admit_evaluation(
        operation,
        class,
        ordinary,
        ordinary_ceiling,
        complete_ceiling,
        signed_parent_id,
    );
    let result = call();
    GRID40_COUNTS.with(|counts| {
        if let Some(counts) = counts.borrow_mut().as_mut() {
            let operation_id = operation_id.expect("admitted grid40 evaluator has id");
            counts.inflight -= 1;
            counts
                .inflight_operation_ids
                .retain(|id| *id != operation_id);
            if result.is_err() {
                counts.errors += 1;
                let detail = result.as_ref().err().map(|error| format!("{error:?}"));
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    class.name(),
                    true,
                    "error",
                    detail.clone(),
                    signed_parent_id,
                );
                if ordinary {
                    grid40_event(
                        counts,
                        operation_id,
                        operation,
                        "ordinary",
                        true,
                        "error",
                        detail.clone(),
                        signed_parent_id,
                    );
                }
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    "complete",
                    true,
                    "error",
                    detail,
                    signed_parent_id,
                );
            } else {
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    class.name(),
                    true,
                    "completed",
                    None,
                    signed_parent_id,
                );
                if ordinary {
                    grid40_event(
                        counts,
                        operation_id,
                        operation,
                        "ordinary",
                        true,
                        "completed",
                        None,
                        signed_parent_id,
                    );
                }
                grid40_event(
                    counts,
                    operation_id,
                    operation,
                    "complete",
                    true,
                    "completed",
                    None,
                    signed_parent_id,
                );
            }
        }
    });
    result
}

#[cfg(test)]
fn grid40_evaluate<T>(
    operation: &'static str,
    class: Grid40EvaluationClass,
    ordinary: bool,
    call: impl FnOnce() -> Result<T, LandSurfaceEnergyError>,
) -> Result<T, LandSurfaceEnergyError> {
    grid40_evaluate_with_parent(operation, class, ordinary, None, call)
}

#[cfg(test)]
fn grid40_evaluate_strict<T>(
    exponent: u32,
    call: impl FnOnce() -> Result<T, LandSurfaceEnergyError>,
) -> Result<T, LandSurfaceEnergyError> {
    let _exponent = Grid40ActiveStrictExponentGuard::install(exponent);
    let result = grid40_evaluate(
        "strict_evaluation",
        Grid40EvaluationClass::Strict,
        true,
        || {
            let result = call();
            let inject = result.is_ok()
                && GRID40_STRICT_FAULT_EXPONENT.with(|fault| {
                    if fault.get() == Some(exponent) {
                        fault.set(None);
                        true
                    } else {
                        false
                    }
                });
            if inject {
                Err(LandSurfaceEnergyError::NumericalAcceptedResidual)
            } else {
                result
            }
        },
    );
    result
}

#[cfg(test)]
pub(crate) fn grid40_record_strict_fault_for_test(exponent: u32) -> (bool, bool) {
    let _fault = grid40_force_strict_evaluator_error_for_test(exponent);
    let first = grid40_evaluate_strict(exponent, || Ok(())).is_err();
    let second = grid40_evaluate_strict(exponent, || Ok(())).is_ok();
    (first, second)
}

#[cfg(not(test))]
fn grid40_evaluate_strict<T>(
    _: u32,
    call: impl FnOnce() -> Result<T, LandSurfaceEnergyError>,
) -> Result<T, LandSurfaceEnergyError> {
    call()
}

#[cfg(not(test))]
fn grid40_evaluate_with_parent<T>(
    _: &'static str,
    _: Grid40EvaluationClass,
    _: bool,
    _: Option<u64>,
    call: impl FnOnce() -> Result<T, LandSurfaceEnergyError>,
) -> Result<T, LandSurfaceEnergyError> {
    call()
}

#[cfg(not(test))]
fn grid40_evaluate<T>(
    _: &'static str,
    _: Grid40EvaluationClass,
    _: bool,
    call: impl FnOnce() -> Result<T, LandSurfaceEnergyError>,
) -> Result<T, LandSurfaceEnergyError> {
    call()
}

#[cfg(test)]
pub(crate) fn grid40_count_domain_predicate() {
    grid40_increment(
        "domain_predicate",
        |counts| &mut counts.domain_predicate,
        20_000,
    );
}
#[cfg(not(test))]
pub(crate) fn grid40_count_domain_predicate() {}

#[cfg(test)]
pub(crate) fn grid40_count_ci_bracket_loop_iteration() {
    GRID40_COUNTS.with(|counts| {
        if let Some(counts) = counts.borrow_mut().as_mut() {
            counts.ci_bracket_loop_iterations = counts
                .ci_bracket_loop_iterations
                .checked_add(1)
                .expect("grid40 Ci bracket-loop iteration counter overflow");
        }
    });
}
#[cfg(not(test))]
pub(crate) fn grid40_count_ci_bracket_loop_iteration() {}

#[cfg(test)]
struct Grid40SignedProbe {
    operation_id: Option<u64>,
}

#[cfg(test)]
fn grid40_finish_signed_probe(
    counts: &mut Grid40CallCounts,
    operation_id: u64,
    phase: &'static str,
    typed_error: Option<String>,
) {
    if let Some(index) = counts
        .inflight_operation_ids
        .iter()
        .position(|id| *id == operation_id)
    {
        counts.inflight_operation_ids.remove(index);
        counts.inflight -= 1;
        grid40_event(
            counts,
            operation_id,
            "signed_jacobian_probe",
            "signed_jacobian_probe",
            true,
            phase,
            typed_error,
            None,
        );
    }
}

#[cfg(test)]
impl Grid40SignedProbe {
    fn begin() -> Self {
        let operation_id = GRID40_COUNTS.with(|counts| {
            let denied = if let Some(counts) = counts.borrow_mut().as_mut() {
                let operation_id = grid40_next_operation_id(counts);
                if counts.signed_probe >= 2_900 {
                    counts.denied += 1;
                    counts.budget_stop = Some("signed_jacobian_probe");
                    grid40_event(
                        counts,
                        operation_id,
                        "signed_jacobian_probe",
                        "signed_jacobian_probe",
                        false,
                        "denied",
                        None,
                        None,
                    );
                    true
                } else {
                    counts.signed_probe += 1;
                    counts.inflight += 1;
                    counts.inflight_operation_ids.push(operation_id);
                    grid40_event(
                        counts,
                        operation_id,
                        "signed_jacobian_probe",
                        "signed_jacobian_probe",
                        true,
                        "started",
                        None,
                        None,
                    );
                    return Some(operation_id);
                }
            } else {
                false
            };
            if denied {
                std::panic::panic_any(Grid40BudgetStop {
                    operation: "signed_jacobian_probe",
                });
            }
            None
        });
        Self { operation_id }
    }

    fn operation_id(&self) -> Option<u64> {
        self.operation_id
    }

    fn finish(&mut self, phase: &'static str, typed_error: Option<String>) {
        if let Some(operation_id) = self.operation_id.take() {
            GRID40_COUNTS.with(|counts| {
                if let Some(counts) = counts.borrow_mut().as_mut() {
                    grid40_finish_signed_probe(counts, operation_id, phase, typed_error);
                }
            });
        }
    }
}

#[cfg(test)]
impl Drop for Grid40SignedProbe {
    fn drop(&mut self) {
        // An unwind can interrupt a real probe after its signed helper began.
        // Retain it as inflight.  Do not write an interrupted row while an
        // outer panic is active: a failed journal write there would become a
        // second panic and obscure the typed primary failure.
        if let Some(operation_id) = self.operation_id.take() {
            if std::thread::panicking() {
                return;
            }
            GRID40_COUNTS.with(|counts| {
                if let Some(counts) = counts.borrow_mut().as_mut() {
                    if counts.inflight_operation_ids.contains(&operation_id) {
                        grid40_event(
                            counts,
                            operation_id,
                            "signed_jacobian_probe",
                            "signed_jacobian_probe",
                            true,
                            "interrupted",
                            None,
                            None,
                        );
                    }
                }
            });
        }
    }
}

#[cfg(test)]
fn grid40_begin_signed_probe() -> Grid40SignedProbe {
    Grid40SignedProbe::begin()
}
#[cfg(not(test))]
struct Grid40SignedProbe;

#[cfg(not(test))]
impl Grid40SignedProbe {
    const fn operation_id(&self) -> Option<u64> {
        let _ = core::mem::size_of_val(self);
        None
    }
    fn finish(&mut self, _: &'static str, _: Option<String>) {
        let _ = core::mem::size_of_val(self);
    }
}

#[cfg(not(test))]
fn grid40_begin_signed_probe() -> Grid40SignedProbe {
    Grid40SignedProbe
}
#[cfg(test)]
fn grid40_count_jacobian_assembly() {
    grid40_increment(
        "jacobian_assembly",
        |counts| &mut counts.jacobian_assembly,
        50,
    );
}
#[cfg(not(test))]
fn grid40_count_jacobian_assembly() {}
#[cfg(test)]
fn grid40_count_update() {
    grid40_increment("newton_update", |counts| &mut counts.updates, 50);
}
#[cfg(not(test))]
fn grid40_count_update() {}

#[cfg(test)]
fn grid40_note_installed_strict_exponent(exponent: u32) {
    GRID40_COUNTS.with(|counts| {
        if let Some(counts) = counts.borrow_mut().as_mut() {
            counts.accepted_strict_exponents.push(exponent);
        }
    });
}

#[cfg(not(test))]
fn grid40_note_installed_strict_exponent(_: u32) {}

#[cfg(test)]
fn grid40_note_strict_attempt(exponent: u32, trial: &[f64]) {
    GRID40_COUNTS.with(|counts| {
        if let Some(counts) = counts.borrow_mut().as_mut() {
            counts.strict_attempted_exponents.push(exponent);
            counts
                .strict_attempted_trial_bits
                .push(trial.iter().map(|value| value.to_bits()).collect());
        }
    });
}

#[cfg(not(test))]
fn grid40_note_strict_attempt(_: u32, _: &[f64]) {}

#[cfg(test)]
pub(crate) fn grid40_force_denial_for_test() {
    grid40_increment("synthetic_denial", |counts| &mut counts.base, 0);
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
pub(crate) enum Grid40BudgetClassForTest {
    Base,
    Witness,
    Strict,
    Ordinary,
    Complete,
    Domain,
    Probe,
}

#[cfg(test)]
pub(crate) fn grid40_force_class_denial_for_test(class: Grid40BudgetClassForTest) {
    match class {
        Grid40BudgetClassForTest::Base
        | Grid40BudgetClassForTest::Witness
        | Grid40BudgetClassForTest::Strict => {
            unreachable!("evaluator classes use atomic admission")
        }
        Grid40BudgetClassForTest::Ordinary => {
            grid40_increment("ordinary_evaluator", |counts| &mut counts.ordinary, 0);
        }
        Grid40BudgetClassForTest::Complete => {
            grid40_increment(
                "complete_residual_evaluator",
                |counts| &mut counts.complete,
                0,
            );
        }
        Grid40BudgetClassForTest::Domain => {
            grid40_increment("domain_predicate", |counts| &mut counts.domain_predicate, 0);
        }
        Grid40BudgetClassForTest::Probe => {
            grid40_increment(
                "signed_jacobian_probe",
                |counts| &mut counts.signed_probe,
                0,
            );
        }
    }
}

#[cfg(test)]
pub(crate) fn grid40_force_complete_cap_denial_before_ordinary_start_for_test() {
    GRID40_COUNTS.with(|counts| {
        counts
            .borrow_mut()
            .as_mut()
            .expect("active grid40 counters")
            .complete = 4_101;
    });
    grid40_admit_evaluation(
        "atomic_complete_denial",
        Grid40EvaluationClass::Base,
        true,
        1_201,
        4_101,
        None,
    );
}

#[cfg(test)]
pub(crate) fn grid40_force_ordinary_cap_denial_before_complete_start_for_test() {
    GRID40_COUNTS.with(|counts| {
        counts
            .borrow_mut()
            .as_mut()
            .expect("active grid40 counters")
            .ordinary = 1_201;
    });
    grid40_admit_evaluation(
        "atomic_ordinary_denial",
        Grid40EvaluationClass::Base,
        true,
        1_201,
        4_101,
        None,
    );
}

#[cfg(test)]
pub(crate) fn grid40_force_evaluation_class_denial_for_test(class: Grid40BudgetClassForTest) {
    GRID40_COUNTS.with(|counts| {
        let mut counts = counts.borrow_mut();
        let counts = counts.as_mut().expect("active grid40 counters");
        match class {
            Grid40BudgetClassForTest::Base => counts.base = 51,
            Grid40BudgetClassForTest::Witness => counts.witness = 100,
            Grid40BudgetClassForTest::Strict => counts.strict = 1_050,
            _ => unreachable!("only evaluator classes"),
        }
    });
    let class = match class {
        Grid40BudgetClassForTest::Base => Grid40EvaluationClass::Base,
        Grid40BudgetClassForTest::Witness => Grid40EvaluationClass::Witness,
        Grid40BudgetClassForTest::Strict => Grid40EvaluationClass::Strict,
        _ => unreachable!(),
    };
    grid40_admit_evaluation("class_cap_denial", class, true, 1_201, 4_101, None);
}

#[cfg(test)]
pub(crate) fn grid40_begin_interrupted_evaluation_for_test() {
    let _ = grid40_admit_evaluation(
        "interrupted_evaluator",
        Grid40EvaluationClass::Base,
        true,
        1_201,
        4_101,
        None,
    );
}

#[cfg(test)]
pub(crate) fn grid40_record_evaluator_lifecycle_for_test(error: bool) {
    let result = grid40_evaluate(
        "synthetic_evaluator",
        Grid40EvaluationClass::Other,
        true,
        || {
            if error {
                Err(LandSurfaceEnergyError::NumericalAcceptedResidual)
            } else {
                Ok(())
            }
        },
    );
    assert_eq!(result.is_err(), error);
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
pub(crate) enum Grid40SignedProbeOutcomeForTest {
    Identity,
    Full,
    Error,
    Interrupted,
}

#[cfg(test)]
pub(crate) fn grid40_record_signed_probe_lifecycle_for_test(
    outcome: Grid40SignedProbeOutcomeForTest,
) {
    let mut signed_probe = grid40_begin_signed_probe();
    match outcome {
        Grid40SignedProbeOutcomeForTest::Identity => {
            signed_probe.finish("identity_anchor_complete", None);
        }
        Grid40SignedProbeOutcomeForTest::Full | Grid40SignedProbeOutcomeForTest::Error => {
            let result = grid40_evaluate_with_parent(
                "jacobian_full_residual",
                Grid40EvaluationClass::Other,
                false,
                signed_probe.operation_id(),
                || {
                    if matches!(outcome, Grid40SignedProbeOutcomeForTest::Error) {
                        Err(LandSurfaceEnergyError::NumericalAcceptedResidual)
                    } else {
                        Ok(())
                    }
                },
            );
            let error = result.as_ref().err().map(|value| format!("{value:?}"));
            signed_probe.finish(
                if error.is_some() {
                    "full_evaluation_error"
                } else {
                    "full_evaluation_complete"
                },
                error,
            );
        }
        Grid40SignedProbeOutcomeForTest::Interrupted => {
            // Drop records an interrupted terminal phase but intentionally
            // preserves the pending signed operation in the partial ledger.
        }
    }
}

#[cfg(test)]
pub(crate) fn grid40_interrupt_signed_probe_during_unwind_for_test(event_path: std::path::PathBuf) {
    let _signed_probe = grid40_begin_signed_probe();
    grid40_set_event_path_for_test(Some(event_path));
    std::panic::panic_any("grid40 primary interruption");
}

#[cfg(test)]
pub(crate) fn grid40_strict_decrease_exponents(
    grid: Grid40StrictDecreaseGrid,
) -> std::ops::RangeInclusive<u32> {
    match grid {
        Grid40StrictDecreaseGrid::Baseline => 0..=MAX_BACKTRACKING_HALVINGS,
        Grid40StrictDecreaseGrid::Treatment => 0..=40,
    }
}

#[cfg(test)]
pub(crate) const fn grid40_backtracking_failure_increment(grid: Grid40StrictDecreaseGrid) -> u32 {
    match grid {
        Grid40StrictDecreaseGrid::Baseline => MAX_BACKTRACKING_HALVINGS,
        Grid40StrictDecreaseGrid::Treatment => 40,
    }
}

fn covered_strict_decrease_exponents() -> std::ops::RangeInclusive<u32> {
    #[cfg(test)]
    {
        #[allow(clippy::needless_return)]
        return GRID40_STRICT_GRID.with(|grid| grid40_strict_decrease_exponents(grid.get()));
    }
    #[cfg(not(test))]
    {
        0..=MAX_BACKTRACKING_HALVINGS
    }
}

fn covered_strict_decrease_failure_increment() -> u32 {
    #[cfg(test)]
    {
        #[allow(clippy::needless_return)]
        return GRID40_STRICT_GRID.with(|grid| grid40_backtracking_failure_increment(grid.get()));
    }
    #[cfg(not(test))]
    {
        MAX_BACKTRACKING_HALVINGS
    }
}

fn covered_complete_residuals_pass(residuals: &[f64]) -> bool {
    !residuals.is_empty()
        && residuals
            .iter()
            .all(|residual| residual.is_finite() && residual.abs() <= 1.0)
}

fn covered_halved_no_update_witness(
    current_residuals: &[f64],
    full_trial_refusal: Option<CoveredFullTrialNoUpdateRefusal>,
    is_first_domain_valid_halved_trial: bool,
    prospective_steps: CoveredStepNorms,
) -> bool {
    covered_complete_residuals_pass(current_residuals)
        && full_trial_refusal.is_some()
        && is_first_domain_valid_halved_trial
        && prospective_steps.accepted()
}

fn covered_first_domain_valid_halved_no_update_witness<F>(
    current_residuals: &[f64],
    full_trial_refusal: Option<CoveredFullTrialNoUpdateRefusal>,
    mut probe: F,
) -> Option<(u32, CoveredStepNorms)>
where
    F: FnMut(u32) -> CoveredHalvedTrialProbe,
{
    if !covered_complete_residuals_pass(current_residuals) || full_trial_refusal.is_none() {
        return None;
    }
    for exponent in 1..=MAX_BACKTRACKING_HALVINGS {
        match probe(exponent) {
            CoveredHalvedTrialProbe::DomainInvalid => {}
            CoveredHalvedTrialProbe::EvaluationIncomplete => return None,
            CoveredHalvedTrialProbe::Complete(steps) => {
                return covered_halved_no_update_witness(
                    current_residuals,
                    full_trial_refusal,
                    true,
                    steps,
                )
                .then_some((exponent, steps));
            }
        }
    }
    None
}

fn empty_step_norms() -> StepNorms {
    StepNorms {
        temperature_k: None,
        humidity_kg_kg: None,
        ci_pa: None,
        hydraulic_mm: None,
        beta: None,
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct CoveredColumnCandidate {
    pub solution: Vec<f64>,
    pub evaluation: CoveredColumnEvaluation,
    pub surface_enthalpy_j_m2_tile: f64,
    pub soil_temperature_k: Vec<f64>,
    pub root_water: Vec<SourceWaterFlux>,
    pub ground_water: GroundWaterFlux,
    pub iterations: u32,
    pub backtracking_count: u32,
    pub step_norms: CoveredStepNorms,
}

#[derive(Clone, Debug, PartialEq)]
pub enum CoveredColumnSolveOutcome {
    Accepted(Box<CoveredColumnCandidate>),
    Rejected(NumericalFailure),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum CoveredFiniteDifferenceStencil {
    Centered,
    InwardFromUpperBound,
    InwardFromLowerBound,
}

fn covered_finite_difference_stencil(
    current: &[f64],
    minus: &[f64],
    plus: &[f64],
    occupancy_count: usize,
    ground_uses_liquid_vapor_phase_domain: bool,
) -> Result<CoveredFiniteDifferenceStencil, LandSurfaceEnergyError> {
    if !covered_trial_is_valid(
        current,
        occupancy_count,
        ground_uses_liquid_vapor_phase_domain,
    ) {
        return Err(LandSurfaceEnergyError::ConstitutiveDomain(
            "covered_jacobian_bound",
        ));
    }
    match (
        covered_trial_is_valid(
            minus,
            occupancy_count,
            ground_uses_liquid_vapor_phase_domain,
        ),
        covered_trial_is_valid(plus, occupancy_count, ground_uses_liquid_vapor_phase_domain),
    ) {
        (true, true) => Ok(CoveredFiniteDifferenceStencil::Centered),
        (true, false) => Ok(CoveredFiniteDifferenceStencil::InwardFromUpperBound),
        (false, true) => Ok(CoveredFiniteDifferenceStencil::InwardFromLowerBound),
        (false, false) => Err(LandSurfaceEnergyError::ConstitutiveDomain(
            "covered_jacobian_bound",
        )),
    }
}

fn covered_finite_difference_value(
    stencil: CoveredFiniteDifferenceStencil,
    current: f64,
    minus: Option<f64>,
    plus: Option<f64>,
    perturbation: f64,
) -> Result<f64, LandSurfaceEnergyError> {
    let missing_probe = || LandSurfaceEnergyError::ConstitutiveDomain("covered_jacobian_bound");
    match stencil {
        CoveredFiniteDifferenceStencil::Centered => Ok((plus.ok_or_else(missing_probe)?
            - minus.ok_or_else(missing_probe)?)
            / (2.0 * perturbation)),
        CoveredFiniteDifferenceStencil::InwardFromUpperBound => {
            Ok((current - minus.ok_or_else(missing_probe)?) / perturbation)
        }
        CoveredFiniteDifferenceStencil::InwardFromLowerBound => {
            Ok((plus.ok_or_else(missing_probe)? - current) / perturbation)
        }
    }
}

#[cfg(test)]
std::thread_local! {
    static COVERED_JACOBIAN_FULL_PROBE_AUDIT: std::cell::Cell<Option<u32>> = const { std::cell::Cell::new(None) };
    static FORCE_COMPLETE_COVERED_JACOBIAN_PROBES: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

#[cfg(test)]
fn begin_covered_jacobian_full_probe_audit() {
    FORCE_COMPLETE_COVERED_JACOBIAN_PROBES.with(|force| force.set(false));
    COVERED_JACOBIAN_FULL_PROBE_AUDIT.with(|audit| audit.set(Some(0)));
}

#[cfg(test)]
fn begin_forced_complete_covered_jacobian_probe_audit() {
    FORCE_COMPLETE_COVERED_JACOBIAN_PROBES.with(|force| force.set(true));
    COVERED_JACOBIAN_FULL_PROBE_AUDIT.with(|audit| audit.set(Some(0)));
}

#[cfg(test)]
fn take_covered_jacobian_full_probe_audit() -> u32 {
    FORCE_COMPLETE_COVERED_JACOBIAN_PROBES.with(|force| force.set(false));
    COVERED_JACOBIAN_FULL_PROBE_AUDIT.with(|audit| audit.take().unwrap_or_default())
}

#[cfg(test)]
fn force_complete_covered_jacobian_probes() -> bool {
    FORCE_COMPLETE_COVERED_JACOBIAN_PROBES.with(std::cell::Cell::get)
}

#[cfg(not(test))]
const fn force_complete_covered_jacobian_probes() -> bool {
    false
}

struct ValidatedCoveredIterationMap<'a> {
    validated: &'a ValidatedCoveredEvaluationInputs<'a>,
    evaluation: CoveredColumnEvaluation,
}

impl<'a> ValidatedCoveredIterationMap<'a> {
    fn evaluate(
        validated: &'a ValidatedCoveredEvaluationInputs<'a>,
        trial: &[f64],
    ) -> Result<Self, LandSurfaceEnergyError> {
        Ok(Self {
            validated,
            evaluation: grid40_evaluate(
                "base_evaluation",
                Grid40EvaluationClass::Base,
                true,
                || evaluate_covered_column_validated(validated, trial, None, None),
            )?,
        })
    }

    fn into_jacobian_base(self, trial: &[f64]) -> ValidatedCoveredJacobianBase<'a> {
        let frozen = freeze_covered_branches(&self.evaluation);
        ValidatedCoveredJacobianBase {
            validated: self.validated,
            trial: trial.to_vec(),
            evaluation: self.evaluation,
            frozen,
        }
    }
}

struct ValidatedCoveredJacobianBase<'a> {
    validated: &'a ValidatedCoveredEvaluationInputs<'a>,
    trial: Vec<f64>,
    evaluation: CoveredColumnEvaluation,
    frozen: CoveredFrozenBranches,
}

#[cfg(test)]
impl<'a> ValidatedCoveredJacobianBase<'a> {
    fn evaluate(
        validated: &'a ValidatedCoveredEvaluationInputs<'a>,
        trial: &[f64],
    ) -> Result<Self, LandSurfaceEnergyError> {
        Ok(ValidatedCoveredIterationMap::evaluate(validated, trial)?.into_jacobian_base(trial))
    }
}

#[cfg(test)]
fn record_covered_jacobian_full_probe_audit() {
    COVERED_JACOBIAN_FULL_PROBE_AUDIT.with(|audit| {
        if let Some(count) = audit.get() {
            audit.set(Some(count.saturating_add(1)));
        }
    });
}

#[cfg(not(test))]
fn record_covered_jacobian_full_probe_audit() {}

/// Returns the ordered normalized residuals for one admitted Jacobian probe.
///
/// Under represented snow, ground and soil temperatures are exact identity
/// anchors and cannot affect any other residual.  Reuse is therefore confined
/// to those columns and to this validated solve; every other probe executes the
/// complete evaluator.
fn covered_jacobian_probe_residuals(
    base: &ValidatedCoveredJacobianBase<'_>,
    probe: &[f64],
    column_index: usize,
) -> Result<Vec<f64>, LandSurfaceEnergyError> {
    let mut signed_probe = grid40_begin_signed_probe();
    let _cost = if !force_complete_covered_jacobian_probes()
        && base
            .validated
            .stage3_identity_anchor_k(column_index)
            .is_some()
    {
        crate::solver_mechanism_audit::compact_cost::scope(
            crate::solver_mechanism_audit::compact_cost::Bucket::Assembly,
        )
    } else {
        crate::solver_mechanism_audit::compact_cost::probe(column_index)
    };
    let mut observation =
        crate::solver_mechanism_audit::Scope::new(crate::solver_mechanism_audit::Kind::Probe);
    let result = covered_jacobian_probe_residuals_observed(
        base,
        probe,
        column_index,
        &mut observation,
        &mut signed_probe,
    );
    observation.finish(result)
}

fn covered_jacobian_probe_residuals_observed(
    base: &ValidatedCoveredJacobianBase<'_>,
    probe: &[f64],
    column_index: usize,
    observation: &mut crate::solver_mechanism_audit::Scope,
    signed_probe: &mut Grid40SignedProbe,
) -> Result<Vec<f64>, LandSurfaceEnergyError> {
    let validated = base.validated;
    let current = &base.evaluation;
    let frozen = Some(&base.frozen);
    if probe.len() != base.trial.len() || column_index >= probe.len() {
        observation.probe(
            column_index,
            probe.get(column_index).map(|v| v.to_bits()),
            crate::solver_mechanism_audit::ProbeClass::Complete,
        );
        record_covered_jacobian_full_probe_audit();
        let evaluation = grid40_evaluate_with_parent(
            "jacobian_full_residual",
            Grid40EvaluationClass::Other,
            false,
            signed_probe.operation_id(),
            || evaluate_covered_column_validated(validated, probe, frozen, None),
        );
        let error = evaluation.as_ref().err().map(|value| format!("{value:?}"));
        signed_probe.finish(
            if error.is_some() {
                "full_evaluation_error"
            } else {
                "full_evaluation_complete"
            },
            error,
        );
        return Ok(evaluation?.normalized_residuals);
    }
    if probe.iter().enumerate().any(|(index, value)| {
        index != column_index && value.to_bits() != base.trial[index].to_bits()
    }) {
        observation.probe(
            column_index,
            Some(probe[column_index].to_bits()),
            crate::solver_mechanism_audit::ProbeClass::Complete,
        );
        record_covered_jacobian_full_probe_audit();
        let evaluation = grid40_evaluate_with_parent(
            "jacobian_full_residual",
            Grid40EvaluationClass::Other,
            false,
            signed_probe.operation_id(),
            || evaluate_covered_column_validated(validated, probe, frozen, None),
        );
        let error = evaluation.as_ref().err().map(|value| format!("{value:?}"));
        signed_probe.finish(
            if error.is_some() {
                "full_evaluation_error"
            } else {
                "full_evaluation_complete"
            },
            error,
        );
        return Ok(evaluation?.normalized_residuals);
    }
    if !force_complete_covered_jacobian_probes() {
        if let Some(anchor_k) = validated.stage3_identity_anchor_k(column_index) {
            observation.probe(
                column_index,
                Some(probe[column_index].to_bits()),
                crate::solver_mechanism_audit::ProbeClass::IdentityAnchor,
            );
            let mut residuals = current.normalized_residuals.clone();
            let raw_residual = probe[column_index] - anchor_k;
            residuals[column_index] = raw_residual / STAGE3_COVERED_IDENTITY_TOLERANCE_K;
            signed_probe.finish("identity_anchor_complete", None);
            return Ok(residuals);
        }
    }
    observation.probe(
        column_index,
        Some(probe[column_index].to_bits()),
        crate::solver_mechanism_audit::ProbeClass::Complete,
    );
    record_covered_jacobian_full_probe_audit();
    let evaluation = grid40_evaluate_with_parent(
        "jacobian_full_residual",
        Grid40EvaluationClass::Other,
        false,
        signed_probe.operation_id(),
        || evaluate_covered_column_validated(validated, probe, frozen, None),
    );
    let error = evaluation.as_ref().err().map(|value| format!("{value:?}"));
    signed_probe.finish(
        if error.is_some() {
            "full_evaluation_error"
        } else {
            "full_evaluation_complete"
        },
        error,
    );
    Ok(evaluation?.normalized_residuals)
}

pub(crate) fn covered_failure_residuals(
    beginning: &CoveredColumnInputs,
    detail: &CoveredColumnEvaluation,
) -> Vec<NormalizedResidual> {
    const OCCUPANCY_IDENTITIES: [&str; 10] = [
        "sun_gas_minus_q1",
        "shade_gas_minus_q1",
        "sun_gas_minus_vulnerability_demand",
        "shade_gas_minus_vulnerability_demand",
        "q1_sum_minus_q2",
        "q2_minus_root_source_sum",
        "sun_leaf_energy",
        "shade_leaf_energy",
        "wet_surface_energy",
        "dry_stem_energy",
    ];
    let occupancy_count = beginning.occupancies.len();
    detail
        .raw_residuals
        .iter()
        .zip(&detail.tolerances)
        .zip(&detail.normalized_residuals)
        .enumerate()
        .map(|(index, ((raw, tolerance), normalized))| {
            let (identity, unit) = if index < 10 * occupancy_count {
                let occupancy = index / 10;
                let local = index % 10;
                let prefix = if occupancy_count == 1 {
                    String::new()
                } else {
                    format!("{}:", beginning.occupancies[occupancy].occupancy_id)
                };
                (
                    format!("{prefix}{}", OCCUPANCY_IDENTITIES[local]),
                    if local < 6 {
                        ResidualUnit::KilogramsPerSquareMeterSecond
                    } else {
                        ResidualUnit::WattsPerSquareMeter
                    },
                )
            } else {
                let shared = index - 10 * occupancy_count;
                match shared {
                    0 => (
                        "shared_canopy_air_heat".into(),
                        ResidualUnit::WattsPerSquareMeter,
                    ),
                    1 => (
                        "shared_canopy_air_vapor".into(),
                        ResidualUnit::KilogramsPerSquareMeterSecond,
                    ),
                    2 => (
                        "ground_surface_energy".into(),
                        ResidualUnit::WattsPerSquareMeter,
                    ),
                    soil => (
                        format!(
                            "soil_thermal:{}",
                            beginning.ground.soil_nodes[soil - 3].layer_id
                        ),
                        ResidualUnit::WattsPerSquareMeter,
                    ),
                }
            };
            diagnostic_residual(identity, *raw, *tolerance, *normalized, unit)
        })
        .collect()
}

fn freeze_covered_branches(detail: &CoveredColumnEvaluation) -> CoveredFrozenBranches {
    let mut frozen = CoveredFrozenBranches {
        ground: Some(detail.ground_water.branch),
        ..Default::default()
    };
    for occupancy in &detail.occupancies {
        if let Some(identity) = occupancy
            .source_water
            .first()
            .map(|value| value.occupancy_id.clone())
        {
            frozen.wet.insert(identity, occupancy.wet_branch);
        }
        for source in &occupancy.source_water {
            frozen.root.insert(
                (source.occupancy_id.clone(), source.layer_id.clone()),
                source.branch,
            );
        }
    }
    frozen
}

fn covered_step_norms(
    applied: &[f64],
    occupancy_count: usize,
    before: &CoveredColumnEvaluation,
    after: &CoveredColumnEvaluation,
) -> CoveredStepNorms {
    let mut result = CoveredStepNorms::default();
    for index in 0..occupancy_count {
        let offset = 10 * index;
        result.hydraulic_mm = result.hydraulic_mm.max(
            applied[offset..offset + 4]
                .iter()
                .map(|value| value.abs())
                .fold(0.0, f64::max),
        );
        result.beta = result.beta.max(
            applied[offset + 4..offset + 6]
                .iter()
                .map(|value| value.abs())
                .fold(0.0, f64::max),
        );
        result.temperature_k = result.temperature_k.max(
            applied[offset + 6..offset + 10]
                .iter()
                .map(|value| value.abs())
                .fold(0.0, f64::max),
        );
        result.ci_pa = result
            .ci_pa
            .max((after.occupancies[index].ci_pa[0] - before.occupancies[index].ci_pa[0]).abs())
            .max((after.occupancies[index].ci_pa[1] - before.occupancies[index].ci_pa[1]).abs());
    }
    let common = 10 * occupancy_count;
    result.temperature_k = result.temperature_k.max(applied[common].abs()).max(
        applied[common + 2..]
            .iter()
            .map(|value| value.abs())
            .fold(0.0, f64::max),
    );
    result.humidity_kg_kg = applied[common + 1].abs();
    result
}

pub(crate) fn solve_covered_column(
    beginning: &CoveredColumnInputs,
    caps: Option<&CoveredWaterCaps>,
    initial_trial: Vec<f64>,
) -> Result<CoveredColumnSolveOutcome, LandSurfaceEnergyError> {
    #[cfg(any(test, feature = "test-support"))]
    crate::lse_first_trial_diagnosis::begin_if_requested();
    #[cfg(any(test, feature = "test-support"))]
    crate::lse_first_trial_diagnosis::record("solver_input", || {
        serde_json::json!({
                "inputs": beginning,
                "caps": caps,
                "initial_trial": initial_trial,
                "allow_v10_initial_final_acceptance": false,
                "snow_accuracy_policy": format!("{:?}", crate::snow_accuracy_policy::Policy::current()),
        })
    });
    let outcome = solve_covered_column_impl(beginning, caps, initial_trial, false);
    // Keep the established ordinary trace schema and record count byte-for-byte
    // comparable.  GRID40 terminal/candidate metadata belongs only in its
    // separate sidecar after the ignored replay boundary.
    #[cfg(any(test, feature = "test-support"))]
    crate::lse_first_trial_diagnosis::finish();
    outcome
}

pub(crate) fn solve_v10_full_supply_final(
    beginning: &CoveredColumnInputs,
    caps: &CoveredWaterCaps,
    initial_trial: Vec<f64>,
) -> Result<CoveredColumnSolveOutcome, LandSurfaceEnergyError> {
    solve_covered_column_impl(beginning, Some(caps), initial_trial, true)
}

fn solve_covered_column_impl(
    beginning: &CoveredColumnInputs,
    caps: Option<&CoveredWaterCaps>,
    initial_trial: Vec<f64>,
    allow_v10_initial_final_acceptance: bool,
) -> Result<CoveredColumnSolveOutcome, LandSurfaceEnergyError> {
    let observation =
        crate::solver_mechanism_audit::Scope::new(crate::solver_mechanism_audit::Kind::Solve);
    #[cfg(any(test, feature = "test-support"))]
    let capture = crate::solver_residual_corpus_capture::solve(
        crate::solver_residual_corpus_capture::Family::Covered,
        caps.is_some(),
    );
    let result = solve_covered_column_observed(
        beginning,
        caps,
        initial_trial,
        allow_v10_initial_final_acceptance,
    );
    #[cfg(any(test, feature = "test-support"))]
    capture.finish(matches!(
        &result,
        Ok(CoveredColumnSolveOutcome::Accepted(..))
    ));
    observation.finish(result)
}

fn solve_covered_column_observed(
    beginning: &CoveredColumnInputs,
    caps: Option<&CoveredWaterCaps>,
    initial_trial: Vec<f64>,
    allow_v10_initial_final_acceptance: bool,
) -> Result<CoveredColumnSolveOutcome, LandSurfaceEnergyError> {
    let _cost_solve = crate::solver_mechanism_audit::compact_cost::solve(
        if caps.is_some() {
            crate::solver_mechanism_audit::compact_cost::Family::CoveredFixedFinal
        } else {
            crate::solver_mechanism_audit::compact_cost::Family::CoveredPotential
        },
        initial_trial.len(),
        beginning,
    );
    validate_covered_caps(beginning, caps)?;
    let ground_uses_liquid_vapor_phase_domain =
        covered_ground_uses_liquid_vapor_phase_domain(beginning);
    if !covered_trial_is_valid(
        &initial_trial,
        beginning.occupancies.len(),
        ground_uses_liquid_vapor_phase_domain,
    ) {
        return Err(LandSurfaceEnergyError::ConstitutiveDomain(
            "covered_initial_trial",
        ));
    }
    let validated_evaluation_inputs =
        ValidatedCoveredEvaluationInputs::try_new_after_caps_validated(beginning, caps)?;
    let inactive_hydraulic_anchors = initial_trial.clone();
    let mut x = initial_trial;
    let mut last_steps = None;
    let mut backtracking_count = 0;
    let mut pivot = None;
    let mut matrix_norm = None;
    let _cost_remaining = crate::solver_mechanism_audit::compact_cost::scope(
        crate::solver_mechanism_audit::compact_cost::Bucket::SolverRemaining,
    );
    for iteration in 0..=MAX_NEWTON_ITERATIONS {
        crate::solver_mechanism_audit::iteration(iteration);
        let iteration_map = {
            let _cost = crate::solver_mechanism_audit::compact_cost::scope(
                crate::solver_mechanism_audit::compact_cost::Bucket::PreparationBase,
            );
            ValidatedCoveredIterationMap::evaluate(&validated_evaluation_inputs, &x)?
        };
        let detail = &iteration_map.evaluation;
        let norm = normalized_infinity_norm(&detail.normalized_residuals);
        #[cfg(any(test, feature = "test-support"))]
        crate::lse_first_trial_diagnosis::record("accepted_base", || {
            serde_json::json!({
                "iteration": iteration, "coordinates": &x, "raw_residuals": &detail.raw_residuals,
                "applied_normalizers": &detail.tolerances, "normalized_residuals": &detail.normalized_residuals,
                "infinity_norm": norm, "evaluation": detail,
            })
        });
        let v10_nonpositive_assimilation = beginning.authority.admits_nonpositive_assimilation()
            && v10_nonpositive_assimilation_active(detail);
        let v10_initial_final_acceptance = allow_v10_initial_final_acceptance
            && iteration == 0
            && caps.is_some()
            && v10_nonpositive_assimilation
            && v10_initial_final_residuals_pass(&detail.normalized_residuals);
        if norm <= 1.0
            && (last_steps.is_some_and(CoveredStepNorms::accepted) || v10_initial_final_acceptance)
        {
            return accept_covered_candidate(
                beginning,
                x,
                iteration_map.evaluation,
                iteration,
                backtracking_count,
                last_steps.unwrap_or_default(),
            );
        }
        if iteration == MAX_NEWTON_ITERATIONS {
            let (occupancy_id, active_bounds) = covered_failure_metadata(beginning, detail, &x);
            return Ok(CoveredColumnSolveOutcome::Rejected(NumericalFailure {
                kind: NumericalFailureKind::IterationLimit,
                iterations: iteration,
                ordered_residuals: covered_failure_residuals(beginning, detail),
                normalized_residuals: detail.normalized_residuals.clone(),
                occupancy_id,
                active_bounds,
                failed_solution: x,
                backtracking_count,
                step_norms: last_steps.map_or_else(empty_step_norms, CoveredStepNorms::diagnostics),
                pivot_magnitude: pivot,
                matrix_norm,
            }));
        }
        let jacobian_base = iteration_map.into_jacobian_base(&x);
        grid40_count_jacobian_assembly();
        crate::solver_mechanism_audit::compact_cost::sweep();
        let cost_assembly = crate::solver_mechanism_audit::compact_cost::scope(
            crate::solver_mechanism_audit::compact_cost::Bucket::Assembly,
        );
        let mut sweep_observation =
            crate::solver_mechanism_audit::Scope::new(crate::solver_mechanism_audit::Kind::Sweep);
        #[cfg(any(test, feature = "test-support"))]
        if let Some(lifecycle) = sweep_observation.lifecycle_identity() {
            crate::solver_residual_corpus_capture::record(
                crate::solver_residual_corpus_capture::Snapshot {
                    family: crate::solver_residual_corpus_capture::Family::Covered,
                    v3: None,
                    lifecycle,
                    pass: if jacobian_base.validated.caps.is_some() {
                        crate::solver_residual_corpus_capture::Pass::FixedFinal
                    } else {
                        crate::solver_residual_corpus_capture::Pass::Potential
                    },
                    inputs: jacobian_base.validated.column.clone(),
                    caps: jacobian_base.validated.caps.cloned(),
                    x_bits: jacobian_base
                        .trial
                        .iter()
                        .map(|value| value.to_bits())
                        .collect(),
                    frozen: jacobian_base.frozen.clone(),
                    base_evaluation: jacobian_base.evaluation.clone(),
                },
            );
        }
        #[cfg(any(test, feature = "test-support"))]
        let capture_sweep = crate::solver_residual_corpus_capture::sweep();
        let detail = &jacobian_base.evaluation;
        let units: Vec<f64> = (0..beginning.occupancies.len())
            .flat_map(|_| [1000.0, 1000.0, 1000.0, 1000.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0])
            .chain([1.0, 0.001, 1.0])
            .chain(std::iter::repeat_n(1.0, beginning.ground.soil_nodes.len()))
            .collect();
        let perturbations: Vec<f64> = x
            .iter()
            .zip(units.iter())
            .map(|(value, unit)| f64::EPSILON.sqrt() * value.abs().max(*unit))
            .collect();
        let mut jacobian = vec![vec![0.0; x.len()]; x.len()];
        sweep_observation.sweep_base(
            &x,
            beginning.occupancies.len(),
            beginning.ground.soil_nodes.len(),
            validated_evaluation_inputs.stage3_boundary.is_some(),
            ground_uses_liquid_vapor_phase_domain,
        );
        for column_index in 0..x.len() {
            crate::solver_mechanism_audit::compact_cost::column(
                column_index,
                !force_complete_covered_jacobian_probes()
                    && validated_evaluation_inputs
                        .stage3_identity_anchor_k(column_index)
                        .is_some(),
            );
            #[cfg(any(test, feature = "test-support"))]
            let capture_column = crate::solver_residual_corpus_capture::column(
                column_index,
                !force_complete_covered_jacobian_probes()
                    && validated_evaluation_inputs
                        .stage3_identity_anchor_k(column_index)
                        .is_some(),
            );
            let mut minus = x.clone();
            let mut plus = x.clone();
            minus[column_index] -= perturbations[column_index];
            plus[column_index] += perturbations[column_index];
            let stencil = covered_finite_difference_stencil(
                &x,
                &minus,
                &plus,
                beginning.occupancies.len(),
                ground_uses_liquid_vapor_phase_domain,
            )?;
            if sweep_observation.detailed() {
                sweep_observation.stencil(
                    column_index,
                    minus[column_index],
                    plus[column_index],
                    covered_trial_is_valid(
                        &minus,
                        beginning.occupancies.len(),
                        ground_uses_liquid_vapor_phase_domain,
                    ),
                    covered_trial_is_valid(
                        &plus,
                        beginning.occupancies.len(),
                        ground_uses_liquid_vapor_phase_domain,
                    ),
                    validated_evaluation_inputs.stage3_identity_anchor_k(column_index),
                );
            }
            // Preserve the canonical minus-then-plus evaluation order while
            // never evaluating a constitutively inadmissible boundary probe.
            let minus_residuals = covered_trial_is_valid(
                &minus,
                beginning.occupancies.len(),
                ground_uses_liquid_vapor_phase_domain,
            )
            .then(|| covered_jacobian_probe_residuals(&jacobian_base, &minus, column_index))
            .transpose()?;
            let plus_residuals = covered_trial_is_valid(
                &plus,
                beginning.occupancies.len(),
                ground_uses_liquid_vapor_phase_domain,
            )
            .then(|| covered_jacobian_probe_residuals(&jacobian_base, &plus, column_index))
            .transpose()?;
            for row in 0..x.len() {
                jacobian[row][column_index] = covered_finite_difference_value(
                    stencil,
                    detail.normalized_residuals[row],
                    minus_residuals.as_ref().map(|value| value[row]),
                    plus_residuals.as_ref().map(|value| value[row]),
                    perturbations[column_index],
                )?;
            }
            #[cfg(any(test, feature = "test-support"))]
            capture_column.finish(true);
        }
        #[cfg(any(test, feature = "test-support"))]
        capture_sweep.finish(true);
        sweep_observation.complete();
        drop(sweep_observation);
        let mut rhs: Vec<f64> = detail
            .normalized_residuals
            .iter()
            .map(|value| -value)
            .collect();
        for (occupancy_index, occupancy) in beginning.occupancies.iter().enumerate() {
            let completely_inactive = beginning.authority.admits_nonpositive_assimilation()
                && occupancy.sun.leaf_area_m2_m2_tile.to_bits() == 0.0_f64.to_bits()
                && occupancy.shade.leaf_area_m2_m2_tile.to_bits() == 0.0_f64.to_bits()
                && occupancy.stem_area_m2_m2_tile.to_bits() == 0.0_f64.to_bits()
                && occupancy.lai.to_bits() == 0.0_f64.to_bits()
                && occupancy.sai.to_bits() == 0.0_f64.to_bits();
            if !completely_inactive {
                continue;
            }
            let block_start = 10 * occupancy_index;
            for local_index in 0..6 {
                let row_index = block_start + local_index;
                let column_index = block_start + local_index;
                jacobian[row_index].fill(0.0);
                jacobian[row_index][column_index] = 1.0 / units[column_index];
                let target = if local_index < 4 {
                    inactive_hydraulic_anchors[column_index]
                } else {
                    1.0
                };
                rhs[row_index] = (target - x[column_index]) / units[column_index];
            }
        }
        let canopy_air_temperature_index = 10 * beginning.occupancies.len();
        for (occupancy_index, occupancy) in detail.occupancies.iter().enumerate() {
            for (component_index, area) in occupancy
                .component_areas_m2_m2_tile
                .iter()
                .copied()
                .enumerate()
            {
                if area.to_bits() != 0.0_f64.to_bits() {
                    continue;
                }
                let row_index = 10 * occupancy_index + 6 + component_index;
                jacobian[row_index].fill(0.0);
                jacobian[row_index][row_index] = 1.0 / units[row_index];
                let target = beginning
                    .inactive_component_anchor_k(component_index, x[canopy_air_temperature_index]);
                rhs[row_index] = (target - x[row_index]) / units[row_index];
            }
        }
        let v10_scaled_potential = caps.is_none() && v10_nonpositive_assimilation;
        if v10_scaled_potential {
            for row in &mut jacobian {
                for (coefficient, unit) in row.iter_mut().zip(&units) {
                    *coefficient *= unit;
                }
            }
        }
        drop(cost_assembly);
        let linear_result = {
            let _cost = crate::solver_mechanism_audit::compact_cost::scope(
                crate::solver_mechanism_audit::compact_cost::Bucket::Linear,
            );
            solve_linear(&jacobian, &rhs)
        };
        let (mut delta, current_pivot, current_matrix_norm) = match linear_result {
            Ok(value) => value,
            Err(evidence) => {
                let (occupancy_id, active_bounds) = covered_failure_metadata(beginning, detail, &x);
                return Ok(CoveredColumnSolveOutcome::Rejected(NumericalFailure {
                    kind: NumericalFailureKind::SingularPivot,
                    iterations: iteration,
                    ordered_residuals: covered_failure_residuals(beginning, detail),
                    normalized_residuals: detail.normalized_residuals.clone(),
                    occupancy_id,
                    active_bounds,
                    failed_solution: x,
                    backtracking_count,
                    step_norms: last_steps
                        .map_or_else(empty_step_norms, CoveredStepNorms::diagnostics),
                    pivot_magnitude: Some(evidence.pivot),
                    matrix_norm: Some(evidence.matrix_norm),
                }));
            }
        };
        if v10_scaled_potential {
            for (change, unit) in delta.iter_mut().zip(&units) {
                *change *= unit;
            }
        }
        pivot = Some(current_pivot);
        matrix_norm = Some(current_matrix_norm);
        #[cfg(any(test, feature = "test-support"))]
        crate::lse_first_trial_diagnosis::record("linear_system", || {
            serde_json::json!({
                "iteration": iteration, "jacobian": &jacobian, "rhs": &rhs, "direction": &delta,
                "pivot_magnitude": current_pivot, "matrix_infinity_norm": current_matrix_norm,
                "v10_scaled_potential": v10_scaled_potential,
            })
        });
        let _cost_trial = crate::solver_mechanism_audit::compact_cost::scope(
            crate::solver_mechanism_audit::compact_cost::Bucket::Trial,
        );
        let prospective: Vec<f64> = x
            .iter()
            .zip(delta.iter())
            .map(|(value, change)| value + change)
            .collect();
        let full_trial_is_valid = covered_trial_is_valid(
            &prospective,
            beginning.occupancies.len(),
            ground_uses_liquid_vapor_phase_domain,
        );
        let complete_current_residuals_pass =
            covered_complete_residuals_pass(&detail.normalized_residuals);
        let mut full_trial_refusal =
            (!full_trial_is_valid).then_some(CoveredFullTrialNoUpdateRefusal::DomainInvalid);
        #[cfg(any(test, feature = "test-support"))]
        crate::lse_first_trial_diagnosis::record("full_trial", || {
            serde_json::json!({
                "iteration": iteration, "factor": 1.0, "domain_valid": full_trial_is_valid,
                "current_residuals_pass": complete_current_residuals_pass,
                "coordinates": &prospective,
            })
        });
        if complete_current_residuals_pass && full_trial_is_valid {
            let prospective_detail = grid40_evaluate(
                "witness_evaluation",
                Grid40EvaluationClass::Witness,
                true,
                || {
                    evaluate_covered_column_validated(
                        &validated_evaluation_inputs,
                        &prospective,
                        None,
                        None,
                    )
                },
            )?;
            let prospective_steps = covered_step_norms(
                &delta,
                beginning.occupancies.len(),
                detail,
                &prospective_detail,
            );
            if prospective_steps.accepted() {
                return accept_covered_candidate(
                    beginning,
                    x,
                    jacobian_base.evaluation,
                    iteration,
                    backtracking_count,
                    prospective_steps,
                );
            }
            if prospective_steps.governed_threshold_exceeded() {
                full_trial_refusal =
                    Some(CoveredFullTrialNoUpdateRefusal::GovernedStepThresholdExceeded);
            }
        }
        if let Some((exponent, steps)) = covered_first_domain_valid_halved_no_update_witness(
            &detail.normalized_residuals,
            full_trial_refusal,
            |exponent| {
                let factor = 0.5_f64.powf(f64::from(exponent));
                let trial: Vec<f64> = x
                    .iter()
                    .zip(delta.iter())
                    .map(|(value, change)| value + factor * change)
                    .collect();
                if !covered_trial_is_valid(
                    &trial,
                    beginning.occupancies.len(),
                    ground_uses_liquid_vapor_phase_domain,
                ) {
                    return CoveredHalvedTrialProbe::DomainInvalid;
                }
                let Ok(trial_detail) = grid40_evaluate(
                    "witness_evaluation",
                    Grid40EvaluationClass::Witness,
                    true,
                    || {
                        evaluate_covered_column_validated(
                            &validated_evaluation_inputs,
                            &trial,
                            None,
                            None,
                        )
                    },
                ) else {
                    return CoveredHalvedTrialProbe::EvaluationIncomplete;
                };
                let applied: Vec<f64> = delta.iter().map(|value| factor * value).collect();
                let steps = covered_step_norms(
                    &applied,
                    beginning.occupancies.len(),
                    detail,
                    &trial_detail,
                );
                CoveredHalvedTrialProbe::Complete(steps)
            },
        ) {
            return accept_covered_candidate(
                beginning,
                x,
                jacobian_base.evaluation,
                iteration,
                backtracking_count + exponent,
                steps,
            );
        }
        let mut accepted = None;
        let mut rejected_step_norms = None;
        for exponent in covered_strict_decrease_exponents() {
            let factor = 0.5_f64.powf(f64::from(exponent));
            let trial: Vec<f64> = x
                .iter()
                .zip(delta.iter())
                .map(|(value, change)| value + factor * change)
                .collect();
            grid40_note_strict_attempt(exponent, &trial);
            if !covered_trial_is_valid(
                &trial,
                beginning.occupancies.len(),
                ground_uses_liquid_vapor_phase_domain,
            ) {
                #[cfg(any(test, feature = "test-support"))]
                crate::lse_first_trial_diagnosis::record("line_search_attempt", || {
                    serde_json::json!({
                        "iteration": iteration, "exponent": exponent, "factor": factor,
                        "coordinates": &trial, "domain_valid": false,
                        "acceptance_predicate": "domain_valid && normalized_infinity_norm(trial) < normalized_infinity_norm(base)",
                        "accepted": false,
                    })
                });
                continue;
            }
            let Ok(trial_detail) = grid40_evaluate_strict(exponent, || {
                evaluate_covered_column_validated(&validated_evaluation_inputs, &trial, None, None)
            }) else {
                #[cfg(any(test, feature = "test-support"))]
                crate::lse_first_trial_diagnosis::record("line_search_attempt", || {
                    serde_json::json!({
                        "iteration": iteration, "exponent": exponent, "factor": factor,
                        "coordinates": &trial, "domain_valid": true, "evaluation_complete": false,
                        "acceptance_predicate": "domain_valid && normalized_infinity_norm(trial) < normalized_infinity_norm(base)",
                        "accepted": false,
                    })
                });
                continue;
            };
            let applied: Vec<f64> = delta.iter().map(|value| factor * value).collect();
            let steps =
                covered_step_norms(&applied, beginning.occupancies.len(), detail, &trial_detail);
            rejected_step_norms = Some(steps);
            let strict_decrease =
                is_strict_residual_decrease(norm, &trial_detail.normalized_residuals);
            #[cfg(any(test, feature = "test-support"))]
            crate::lse_first_trial_diagnosis::record("line_search_attempt", || {
                serde_json::json!({
                    "iteration": iteration, "exponent": exponent, "factor": factor,
                    "coordinates": &trial, "domain_valid": true, "evaluation_complete": true,
                    "raw_residuals": &trial_detail.raw_residuals,
                    "applied_normalizers": &trial_detail.tolerances,
                    "normalized_residuals": &trial_detail.normalized_residuals,
                    "infinity_norm": normalized_infinity_norm(&trial_detail.normalized_residuals),
                    "step_norms": steps.diagnostics(),
                    "acceptance_predicate": "domain_valid && normalized_infinity_norm(trial) < normalized_infinity_norm(base)",
                    "strict_decrease": strict_decrease, "accepted": strict_decrease,
                })
            });
            if strict_decrease {
                accepted = Some((trial, steps, exponent));
                break;
            }
        }
        if let Some((trial, steps, exponent)) = accepted {
            grid40_count_update();
            grid40_note_installed_strict_exponent(exponent);
            x = trial;
            last_steps = Some(steps);
            backtracking_count += exponent;
        } else {
            let (occupancy_id, active_bounds) = covered_failure_metadata(beginning, detail, &x);
            let failure = NumericalFailure {
                kind: NumericalFailureKind::BacktrackingLimit,
                iterations: iteration,
                ordered_residuals: covered_failure_residuals(beginning, detail),
                normalized_residuals: detail.normalized_residuals.clone(),
                occupancy_id,
                active_bounds,
                failed_solution: x,
                backtracking_count: backtracking_count
                    + covered_strict_decrease_failure_increment(),
                step_norms: rejected_step_norms
                    .or(last_steps)
                    .map_or_else(empty_step_norms, CoveredStepNorms::diagnostics),
                pivot_magnitude: pivot,
                matrix_norm,
            };
            #[cfg(any(test, feature = "test-support"))]
            {
                // GRID40 deliberately performs no diagnostic post-refusal
                // evaluations.  The retained terminal trace below is enough
                // to classify the first obstruction without spending outside
                // the frozen ordinary-evaluator envelope.
                crate::lse_first_trial_diagnosis::record("terminal_failure", || {
                    serde_json::json!({
                        "failure": {
                            "kind": format!("{:?}", failure.kind), "iterations": failure.iterations,
                            "normalized_residuals": &failure.normalized_residuals,
                            "ordered_residuals": &failure.ordered_residuals,
                            "failed_solution": &failure.failed_solution,
                            "occupancy_id": &failure.occupancy_id, "active_bounds": &failure.active_bounds,
                            "backtracking_count": failure.backtracking_count, "step_norms": failure.step_norms,
                            "pivot_magnitude": failure.pivot_magnitude, "matrix_norm": failure.matrix_norm,
                        },
                        "terminal_residual_state": "current_accepted_base",
                        "terminal_step_state": "last_domain-valid_rejected_trial_or_previous_accepted_step",
                    })
                });
            }
            return Ok(CoveredColumnSolveOutcome::Rejected(failure));
        }
    }
    Err(LandSurfaceEnergyError::NumericalAcceptedResidual)
}

fn accept_covered_candidate(
    beginning: &CoveredColumnInputs,
    solution: Vec<f64>,
    detail: CoveredColumnEvaluation,
    iterations: u32,
    backtracking_count: u32,
    step_norms: CoveredStepNorms,
) -> Result<CoveredColumnSolveOutcome, LandSurfaceEnergyError> {
    for (input, evaluated) in beginning.occupancies.iter().zip(&detail.occupancies) {
        if exact_inactive_hydraulic_occupancy(beginning.authority, input)
            && evaluated
                .source_water
                .iter()
                .any(|source| !exact_inactive_source_water(source))
        {
            return Err(LandSurfaceEnergyError::UnsupportedDomain(
                "inactive_hydraulic_source",
            ));
        }
    }
    if beginning.authority.admits_nonpositive_assimilation()
        && detail
            .occupancies
            .iter()
            .flat_map(|occupancy| &occupancy.source_water)
            .any(|source| source.law_kg_m2_tile_s < 0.0 || source.final_kg_m2_tile_s < 0.0)
    {
        return Err(LandSurfaceEnergyError::UnsupportedDomain(
            "hydraulic_redistribution",
        ));
    }
    let root_water = detail
        .occupancies
        .iter()
        .flat_map(|value| value.source_water.clone())
        .collect();
    Ok(CoveredColumnSolveOutcome::Accepted(Box::new(
        CoveredColumnCandidate {
            solution,
            surface_enthalpy_j_m2_tile: detail.ending_surface_enthalpy_j_m2_tile,
            soil_temperature_k: detail.soil_temperature_k.clone(),
            root_water,
            ground_water: detail.ground_water,
            iterations,
            backtracking_count,
            step_norms,
            evaluation: detail,
        },
    )))
}

#[derive(Clone, Debug, PartialEq)]
pub struct CoveredPotentialFinalTransaction {
    pub potential: Box<CoveredColumnCandidate>,
    pub final_pass: Box<CoveredColumnCandidate>,
}

/// Execute the owner-uncapped pass and the fixed-cap pass from the same
/// immutable beginning problem. The supplied cap batch must preserve every
/// potential request identity and amount exactly.
#[cfg(test)]
pub(crate) fn execute_covered_potential_final(
    beginning: &CoveredColumnInputs,
    potential_initial_trial: Vec<f64>,
    caps: &CoveredWaterCaps,
    final_initial_trial: Vec<f64>,
) -> Result<CoveredPotentialFinalTransaction, LandSurfaceEnergyError> {
    let potential = match solve_covered_column(beginning, None, potential_initial_trial)? {
        CoveredColumnSolveOutcome::Accepted(value) => value,
        CoveredColumnSolveOutcome::Rejected(_) => {
            return Err(LandSurfaceEnergyError::NumericalAcceptedResidual);
        }
    };
    for source in &potential.root_water {
        let cap = caps
            .root
            .get(&(source.occupancy_id.clone(), source.layer_id.clone()))
            .ok_or(LandSurfaceEnergyError::water_cardinality(
                "missing_potential_root_request_identity",
            ))?;
        let potential_rate =
            source.request_kg_m2_stand_ground / (beginning.tile_fraction * beginning.interval_s);
        if cap.request_rate_kg_m2_tile_s != potential_rate {
            return Err(LandSurfaceEnergyError::water_identity(
                "changed_potential_root_request",
            ));
        }
    }
    let ground_potential_rate = potential.ground_water.request_kg_m2_stand_ground
        / (beginning.tile_fraction * beginning.interval_s);
    if caps.ground.request_rate_kg_m2_tile_s != ground_potential_rate {
        return Err(LandSurfaceEnergyError::water_identity(
            "changed_potential_ground_request",
        ));
    }
    // `beginning`, rather than `potential`, is deliberately passed here.
    let final_pass = match solve_covered_column(beginning, Some(caps), final_initial_trial)? {
        CoveredColumnSolveOutcome::Accepted(value) => value,
        CoveredColumnSolveOutcome::Rejected(_) => {
            return Err(LandSurfaceEnergyError::NumericalAcceptedResidual);
        }
    };
    for source in &final_pass.root_water {
        let authorization = source.authorization_kg_m2_stand_ground.ok_or(
            LandSurfaceEnergyError::water_cardinality("missing_final_root_authorization"),
        )?;
        if source.finalized_use_kg_m2_stand_ground > authorization
            || authorization > source.request_kg_m2_stand_ground
        {
            return Err(LandSurfaceEnergyError::water_bound("root_D/A/F"));
        }
    }
    let ground_authorization = final_pass
        .ground_water
        .authorization_kg_m2_stand_ground
        .ok_or(LandSurfaceEnergyError::water_cardinality(
            "missing_final_ground_authorization",
        ))?;
    if final_pass.ground_water.finalized_use_kg_m2_stand_ground > ground_authorization
        || ground_authorization > final_pass.ground_water.request_kg_m2_stand_ground
    {
        return Err(LandSurfaceEnergyError::water_bound("ground_D/A/F"));
    }
    Ok(CoveredPotentialFinalTransaction {
        potential,
        final_pass,
    })
}

#[cfg(test)]
mod inactive_hydraulic_source_tests {
    use super::*;

    fn exact_inactive_source() -> SourceWaterFlux {
        SourceWaterFlux {
            occupancy_id: "inactive-occupancy".into(),
            layer_id: "soil-1".into(),
            law_kg_m2_tile_s: 0.0,
            final_kg_m2_tile_s: 0.0,
            request_kg_m2_stand_ground: 0.0,
            authorization_kg_m2_stand_ground: Some(0.0),
            finalized_use_kg_m2_stand_ground: 0.0,
            branch: WaterBranch::ConstitutiveLaw,
        }
    }

    #[test]
    fn inactive_source_requires_exact_zero_flow_demand_and_inactive_branch() {
        let source = exact_inactive_source();
        assert!(exact_inactive_source_water(&source));

        let mut negative_law = source.clone();
        negative_law.law_kg_m2_tile_s = -f64::from_bits(1);
        assert!(!exact_inactive_source_water(&negative_law));

        for poison in [
            |source: &mut SourceWaterFlux| source.final_kg_m2_tile_s = f64::from_bits(1),
            |source: &mut SourceWaterFlux| {
                source.request_kg_m2_stand_ground = f64::from_bits(1);
            },
            |source: &mut SourceWaterFlux| {
                source.authorization_kg_m2_stand_ground = Some(f64::from_bits(1));
            },
            |source: &mut SourceWaterFlux| {
                source.finalized_use_kg_m2_stand_ground = f64::from_bits(1);
            },
        ] {
            let mut poisoned = source.clone();
            poison(&mut poisoned);
            assert!(!exact_inactive_source_water(&poisoned));
        }

        let mut active_branch = source;
        active_branch.branch = WaterBranch::AuthorizationActiveOrTie;
        assert!(!exact_inactive_source_water(&active_branch));
    }
}

#[cfg(test)]
mod covered_halved_no_update_witness_tests {
    use super::*;

    fn passing_steps() -> CoveredStepNorms {
        CoveredStepNorms {
            hydraulic_mm: 1.0e-7,
            beta: 1.0e-10,
            temperature_k: 1.0e-8,
            humidity_kg_kg: 1.0e-12,
            ci_pa: f64::MAX,
        }
    }

    #[test]
    fn each_full_witness_refusal_and_first_domain_valid_halving_admit_no_update() {
        for refusal in [
            CoveredFullTrialNoUpdateRefusal::DomainInvalid,
            CoveredFullTrialNoUpdateRefusal::GovernedStepThresholdExceeded,
        ] {
            assert!(covered_halved_no_update_witness(
                &[1.0, -1.0, 0.0],
                Some(refusal),
                true,
                passing_steps(),
            ));
        }
    }

    #[test]
    fn enclosing_preflight_skips_domain_invalid_trials_and_returns_first_complete_witness() {
        let mut examined = Vec::new();
        let witness = covered_first_domain_valid_halved_no_update_witness(
            &[0.0, 1.0],
            Some(CoveredFullTrialNoUpdateRefusal::DomainInvalid),
            |exponent| {
                examined.push(exponent);
                if exponent < 3 {
                    CoveredHalvedTrialProbe::DomainInvalid
                } else {
                    CoveredHalvedTrialProbe::Complete(passing_steps())
                }
            },
        );
        assert_eq!(witness, Some((3, passing_steps())));
        assert_eq!(examined, [1, 2, 3]);
    }

    #[test]
    fn enclosing_preflight_does_not_skip_incomplete_or_failed_first_domain_valid_trial() {
        let mut failed_steps = passing_steps();
        failed_steps.hydraulic_mm = 1.0e-7 + f64::EPSILON;
        for first_domain_valid in [
            CoveredHalvedTrialProbe::EvaluationIncomplete,
            CoveredHalvedTrialProbe::Complete(failed_steps),
        ] {
            let mut examined = Vec::new();
            let witness = covered_first_domain_valid_halved_no_update_witness(
                &[0.0, 1.0],
                Some(CoveredFullTrialNoUpdateRefusal::GovernedStepThresholdExceeded),
                |exponent| {
                    examined.push(exponent);
                    if exponent == 1 {
                        first_domain_valid
                    } else {
                        CoveredHalvedTrialProbe::Complete(passing_steps())
                    }
                },
            );
            assert_eq!(witness, None);
            assert_eq!(examined, [1]);
        }

        let mut examined_without_trigger = false;
        assert_eq!(
            covered_first_domain_valid_halved_no_update_witness(&[0.0, 1.0], None, |_| {
                examined_without_trigger = true;
                CoveredHalvedTrialProbe::Complete(passing_steps())
            },),
            None
        );
        assert!(!examined_without_trigger);
    }

    #[test]
    fn complete_residual_passing_full_and_later_domain_valid_poisons_refuse_the_witness() {
        for residual_poison in [1.0 + f64::EPSILON, f64::INFINITY, f64::NAN] {
            assert!(!covered_halved_no_update_witness(
                &[0.0, residual_poison, 0.5],
                Some(CoveredFullTrialNoUpdateRefusal::DomainInvalid),
                true,
                passing_steps(),
            ));
        }
        assert!(!covered_halved_no_update_witness(
            &[0.0, 1.0],
            None,
            true,
            passing_steps(),
        ));
        assert!(!covered_halved_no_update_witness(
            &[0.0, 1.0],
            Some(CoveredFullTrialNoUpdateRefusal::DomainInvalid),
            false,
            passing_steps(),
        ));
    }

    #[test]
    fn each_governed_prospective_step_coordinate_poison_refuses_the_witness() {
        let mut hydraulic = passing_steps();
        hydraulic.hydraulic_mm = 1.0e-7 + f64::EPSILON;
        let mut beta = passing_steps();
        beta.beta = 1.0e-10 + f64::EPSILON;
        let mut temperature = passing_steps();
        temperature.temperature_k = 1.0e-8 + f64::EPSILON;
        let mut humidity = passing_steps();
        humidity.humidity_kg_kg = 1.0e-12 + f64::EPSILON;
        let mut nonfinite = passing_steps();
        nonfinite.beta = f64::NAN;
        for poison in [hydraulic, beta, temperature, humidity, nonfinite] {
            assert!(!covered_halved_no_update_witness(
                &[0.0, 1.0],
                Some(CoveredFullTrialNoUpdateRefusal::GovernedStepThresholdExceeded),
                true,
                poison,
            ));
        }
    }

    #[test]
    fn full_trial_threshold_excess_classification_requires_every_governed_step_finite() {
        for poison in [
            |steps: &mut CoveredStepNorms, value| steps.hydraulic_mm = value,
            |steps: &mut CoveredStepNorms, value| steps.beta = value,
            |steps: &mut CoveredStepNorms, value| steps.temperature_k = value,
            |steps: &mut CoveredStepNorms, value| steps.humidity_kg_kg = value,
        ] {
            for nonfinite in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
                let mut steps = passing_steps();
                poison(&mut steps, nonfinite);
                assert!(!steps.governed_threshold_exceeded());
            }
        }

        for poison in [
            |steps: &mut CoveredStepNorms| steps.hydraulic_mm = 1.0e-7 + f64::EPSILON,
            |steps: &mut CoveredStepNorms| steps.beta = 1.0e-10 + f64::EPSILON,
            |steps: &mut CoveredStepNorms| steps.temperature_k = 1.0e-8 + f64::EPSILON,
            |steps: &mut CoveredStepNorms| steps.humidity_kg_kg = 1.0e-12 + f64::EPSILON,
        ] {
            let mut steps = passing_steps();
            poison(&mut steps);
            assert!(steps.governed_threshold_exceeded());
        }
    }
}

#[cfg(test)]
mod covered_finite_difference_stencil_tests {
    use super::*;

    const OCCUPANCY_COUNT: usize = 1;

    fn admitted_trial() -> Vec<f64> {
        vec![
            -5_000.0,
            -5_000.0,
            -5_000.0,
            -5_000.0,
            0.5,
            0.5,
            LIQUID_VAPOR_PHASE_MINIMUM_K,
            LIQUID_VAPOR_PHASE_MINIMUM_K,
            LIQUID_VAPOR_PHASE_MINIMUM_K,
            273.15,
            273.15,
            0.01,
            273.15,
            273.15,
        ]
    }

    fn canonical_probes(current: &[f64], column: usize, unit_scale: f64) -> (Vec<f64>, Vec<f64>) {
        let h = f64::EPSILON.sqrt() * current[column].abs().max(unit_scale);
        let mut minus = current.to_vec();
        let mut plus = current.to_vec();
        minus[column] -= h;
        plus[column] += h;
        (minus, plus)
    }

    #[test]
    fn beta_zero_and_one_select_only_the_unique_inward_probe() {
        let mut lower = admitted_trial();
        lower[4] = 0.0;
        let (minus, plus) = canonical_probes(&lower, 4, 1.0);
        assert_eq!(
            covered_finite_difference_stencil(&lower, &minus, &plus, OCCUPANCY_COUNT, false)
                .expect("beta=0 is an admitted closed bound"),
            CoveredFiniteDifferenceStencil::InwardFromLowerBound
        );

        let mut upper = admitted_trial();
        upper[5] = 1.0;
        let (minus, plus) = canonical_probes(&upper, 5, 1.0);
        assert_eq!(
            covered_finite_difference_stencil(&upper, &minus, &plus, OCCUPANCY_COUNT, false)
                .expect("beta=1 is an admitted closed bound"),
            CoveredFiniteDifferenceStencil::InwardFromUpperBound
        );
    }

    #[test]
    fn exact_phase_minimum_uses_inward_probe_for_active_or_zero_area_coordinates() {
        let current = admitted_trial();
        for column in [6, 7, 8] {
            let (minus, plus) = canonical_probes(&current, column, 1.0);
            let stencil =
                covered_finite_difference_stencil(&current, &minus, &plus, OCCUPANCY_COUNT, false)
                    .expect("exact liquid-vapor phase minimum is admitted");
            assert_eq!(
                stencil,
                CoveredFiniteDifferenceStencil::InwardFromLowerBound,
                "the trial domain is identical for active and zero-area coordinate {column}"
            );
        }

        let ground_temperature_column = 10 * OCCUPANCY_COUNT + 2;
        let (minus, plus) = canonical_probes(&current, ground_temperature_column, 1.0);
        assert_eq!(
            covered_finite_difference_stencil(&current, &minus, &plus, OCCUPANCY_COUNT, true,)
                .expect("exact liquid-bearing ground phase minimum is admitted"),
            CoveredFiniteDifferenceStencil::InwardFromLowerBound
        );
    }

    #[test]
    fn interior_coordinate_retains_exact_centered_stencil() {
        let current = admitted_trial();
        let (minus, plus) = canonical_probes(&current, 4, 1.0);
        assert_eq!(
            covered_finite_difference_stencil(&current, &minus, &plus, OCCUPANCY_COUNT, false)
                .expect("interior probes"),
            CoveredFiniteDifferenceStencil::Centered
        );
    }

    #[test]
    fn centered_and_inward_formulas_are_exact_and_missing_probes_reject() {
        assert_eq!(
            covered_finite_difference_value(
                CoveredFiniteDifferenceStencil::Centered,
                10.0,
                Some(7.0),
                Some(15.0),
                2.0,
            )
            .expect("centered formula")
            .to_bits(),
            2.0_f64.to_bits()
        );
        assert_eq!(
            covered_finite_difference_value(
                CoveredFiniteDifferenceStencil::InwardFromUpperBound,
                10.0,
                Some(7.0),
                None,
                2.0,
            )
            .expect("upper-bound inward formula")
            .to_bits(),
            1.5_f64.to_bits()
        );
        assert_eq!(
            covered_finite_difference_value(
                CoveredFiniteDifferenceStencil::InwardFromLowerBound,
                10.0,
                None,
                Some(15.0),
                2.0,
            )
            .expect("lower-bound inward formula")
            .to_bits(),
            2.5_f64.to_bits()
        );
        assert!(matches!(
            covered_finite_difference_value(
                CoveredFiniteDifferenceStencil::Centered,
                10.0,
                None,
                Some(15.0),
                2.0,
            ),
            Err(LandSurfaceEnergyError::ConstitutiveDomain(
                "covered_jacobian_bound"
            ))
        ));
    }

    #[test]
    fn outside_current_and_two_inadmissible_probes_fail_closed() {
        let mut outside = admitted_trial();
        outside[4] = -f64::EPSILON;
        let (minus, plus) = canonical_probes(&outside, 4, 1.0);
        assert!(matches!(
            covered_finite_difference_stencil(&outside, &minus, &plus, OCCUPANCY_COUNT, false,),
            Err(LandSurfaceEnergyError::ConstitutiveDomain(
                "covered_jacobian_bound"
            ))
        ));

        let current = admitted_trial();
        let mut inadmissible_minus = current.clone();
        inadmissible_minus[4] = -f64::EPSILON;
        let mut inadmissible_plus = current.clone();
        inadmissible_plus[11] = 0.1 + f64::EPSILON;
        assert!(matches!(
            covered_finite_difference_stencil(
                &current,
                &inadmissible_minus,
                &inadmissible_plus,
                OCCUPANCY_COUNT,
                false,
            ),
            Err(LandSurfaceEnergyError::ConstitutiveDomain(
                "covered_jacobian_bound"
            ))
        ));
    }

    #[test]
    fn exact_phase_bound_outward_newton_direction_has_no_admitted_backtracking_factor() {
        let current = admitted_trial();
        let ground_temperature_column = 10 * OCCUPANCY_COUNT + 2;
        let outward_change_k = -4.198_172_269_516_074;
        for exponent in 0..=MAX_BACKTRACKING_HALVINGS {
            let factor = 0.5_f64.powf(f64::from(exponent));
            let mut trial = current.clone();
            trial[ground_temperature_column] += factor * outward_change_k;
            assert!(
                !covered_trial_is_valid(&trial, OCCUPANCY_COUNT, true),
                "outward phase-bound step unexpectedly admitted at 2^-{exponent}"
            );
        }
    }
}

#[cfg(test)]
#[test]
#[ignore = "isolated P policy requires a fresh process"]
fn snow_accuracy_covered_policy_boundary_and_residual_poison() {
    use crate::snow_accuracy_policy::Policy;
    let name = std::env::var("OPENWEPP_ACCURACY_POLICY").expect("explicit P policy");
    let policy = Policy::parse(&name).expect("known policy");
    policy.install().expect("first policy install");
    assert!(
        policy.install().is_err(),
        "startup policy cannot be replaced"
    );
    let threshold = policy.temperature_step();
    let at = CoveredStepNorms {
        temperature_k: threshold,
        ..CoveredStepNorms::default()
    };
    assert!(at.accepted());
    assert!(!at.governed_threshold_exceeded());
    let above = CoveredStepNorms {
        temperature_k: threshold * (1.0 + 1e-12),
        ..at
    };
    assert!(!above.accepted());
    assert!(above.governed_threshold_exceeded());
    assert!(!covered_complete_residuals_pass(&[f64::NAN]));
    assert!(!covered_complete_residuals_pass(&[1.0001]));
    assert!(!covered_complete_residuals_pass(&[]));
    assert!(covered_halved_no_update_witness(
        &[0.5],
        Some(CoveredFullTrialNoUpdateRefusal::DomainInvalid),
        true,
        at
    ));
    assert!(!covered_halved_no_update_witness(
        &[2.0],
        Some(CoveredFullTrialNoUpdateRefusal::DomainInvalid),
        true,
        at
    ));
    assert!(!covered_halved_no_update_witness(
        &[0.5],
        Some(CoveredFullTrialNoUpdateRefusal::DomainInvalid),
        false,
        at
    ));
    assert!(!covered_halved_no_update_witness(
        &[0.5],
        Some(CoveredFullTrialNoUpdateRefusal::DomainInvalid),
        true,
        above
    ));
}
