//! Contract-derived controls for EXP-B01-LSE-GRID40-20260919.
//!
//! These controls intentionally contain no captured original-start evaluation.

use crate::solver::{
    CoveredColumnInputs, CoveredColumnSolveOutcome, Grid40BudgetClassForTest,
    Grid40SignedProbeOutcomeForTest, Grid40StrictDecreaseGrid, covered_trial_is_valid,
    grid40_begin_call_counts, grid40_begin_interrupted_evaluation_for_test,
    grid40_begin_replay_for_test, grid40_force_class_denial_for_test,
    grid40_force_complete_cap_denial_before_ordinary_start_for_test, grid40_force_denial_for_test,
    grid40_force_evaluation_class_denial_for_test,
    grid40_force_ordinary_cap_denial_before_complete_start_for_test,
    grid40_install_strict_decrease_grid, grid40_interrupt_signed_probe_during_unwind_for_test,
    grid40_record_evaluator_lifecycle_for_test, grid40_record_signed_probe_lifecycle_for_test,
    grid40_record_strict_fault_for_test, grid40_set_event_path_for_test,
    grid40_strict_decrease_exponents, solve_covered_column,
};
use sha2::Digest;

const GRID40_ORIGINAL_TRACE_SHA256: &str =
    "527208c3e5ad07f1744f1bd92c9e4ac17cf7efd9469968a97d7964c5db482dfd";

fn grid40_admit_original_trace_bytes(bytes: Vec<u8>) -> Result<Vec<u8>, &'static str> {
    if format!("{:x}", sha2::Sha256::digest(&bytes)) != GRID40_ORIGINAL_TRACE_SHA256 {
        return Err("grid40 original trace sha256");
    }
    Ok(bytes)
}

fn grid40_read_admitted_original_trace(path: &std::path::Path) -> Result<Vec<u8>, &'static str> {
    let bytes = std::fs::read(path).map_err(|_| "grid40 original trace read")?;
    grid40_admit_original_trace_bytes(bytes)
}

fn grid40_arm_grid(arm: &str) -> Option<Grid40StrictDecreaseGrid> {
    match arm {
        "baseline" => Some(Grid40StrictDecreaseGrid::Baseline),
        "treatment" => Some(Grid40StrictDecreaseGrid::Treatment),
        _ => None,
    }
}

fn grid40_write_sidecar(
    sidecar: &std::path::Path,
    value: &serde_json::Value,
) -> Result<(), crate::solver::Grid40EvidenceFailure> {
    let bytes =
        serde_json::to_vec_pretty(value).map_err(|error| crate::solver::Grid40EvidenceFailure {
            channel: "sidecar_serialize",
            detail: error.to_string(),
        })?;
    std::fs::write(sidecar, bytes).map_err(|error| crate::solver::Grid40EvidenceFailure {
        channel: "sidecar_write",
        detail: error.to_string(),
    })
}

fn grid40_write_invalid_measurement_sidecar(
    arm: &str,
    sidecar: &std::path::Path,
    counters: &crate::solver::Grid40CallCounts,
    failure: &crate::solver::Grid40EvidenceFailure,
) -> Result<(), crate::solver::Grid40EvidenceFailure> {
    grid40_write_sidecar(
        sidecar,
        &serde_json::json!({
            "schema": "openwepp.grid40.sidecar.v1",
            "arm": arm,
            "terminal": {"kind": "EvidenceFailure", "channel": failure.channel,
                "detail": failure.detail, "incomplete": true},
            "counts": counters,
            "measurement_valid": false,
        }),
    )
}

fn grid40_abort_invalid_measurement(
    arm: &str,
    sidecar: &std::path::Path,
    counters: &crate::solver::Grid40CallCounts,
    failure: &crate::solver::Grid40EvidenceFailure,
) -> ! {
    if let Err(report_failure) =
        grid40_write_invalid_measurement_sidecar(arm, sidecar, counters, failure)
    {
        panic!("grid40 evidence failure and invalid sidecar write: {report_failure:?}");
    }
    panic!("grid40 evidence failure invalidates this measurement");
}

fn grid40_trace_write_failure() -> Option<crate::solver::Grid40EvidenceFailure> {
    crate::lse_first_trial_diagnosis::take_write_failure().map(|detail| {
        crate::solver::Grid40EvidenceFailure {
            channel: "trace_write",
            detail,
        }
    })
}

#[test]
fn grid40_private_replay_rejects_every_non_arm_before_trace_or_evaluator_access() {
    assert_eq!(
        grid40_arm_grid("baseline"),
        Some(Grid40StrictDecreaseGrid::Baseline)
    );
    assert_eq!(
        grid40_arm_grid("treatment"),
        Some(Grid40StrictDecreaseGrid::Treatment)
    );
    for wrong in ["", "original", "full-case", "treatment ", "BASELINE"] {
        assert_eq!(
            grid40_arm_grid(wrong),
            None,
            "wrong private replay arm {wrong:?}"
        );
    }
}

#[test]
fn grid40_wrong_trace_bytes_refuse_before_deserialization_or_evaluation() {
    let rejected = grid40_admit_original_trace_bytes(b"wrong trace bytes".to_vec());
    assert_eq!(rejected, Err("grid40 original trace sha256"));
}

#[test]
fn grid40_preserves_the_original_strict_grid_and_extends_only_the_private_grid() {
    assert_eq!(
        grid40_strict_decrease_exponents(Grid40StrictDecreaseGrid::Baseline),
        0..=20
    );
    assert_eq!(
        grid40_strict_decrease_exponents(Grid40StrictDecreaseGrid::Treatment),
        0..=40
    );
}

#[test]
fn grid40_failure_count_uses_the_actual_last_strict_exponent() {
    assert_eq!(
        crate::solver::grid40_backtracking_failure_increment(Grid40StrictDecreaseGrid::Baseline),
        20
    );
    assert_eq!(
        crate::solver::grid40_backtracking_failure_increment(Grid40StrictDecreaseGrid::Treatment),
        40
    );
}

#[test]
fn grid40_treatment_selection_is_scoped_and_cannot_change_other_tests() {
    assert_eq!(
        grid40_strict_decrease_exponents(Grid40StrictDecreaseGrid::Baseline),
        0..=20
    );
    {
        let _grid = grid40_install_strict_decrease_grid(Grid40StrictDecreaseGrid::Treatment);
        assert_eq!(
            grid40_strict_decrease_exponents(Grid40StrictDecreaseGrid::Treatment),
            0..=40
        );
    }
    assert_eq!(
        grid40_strict_decrease_exponents(Grid40StrictDecreaseGrid::Baseline),
        0..=20
    );
}

#[test]
fn grid40_beyond20_is_a_treatment_only_strict_choice_and_exhaustion_is_fixed() {
    let first_lawful =
        |grid| grid40_strict_decrease_exponents(grid).find(|exponent| *exponent == 21);
    assert_eq!(first_lawful(Grid40StrictDecreaseGrid::Baseline), None);
    assert_eq!(first_lawful(Grid40StrictDecreaseGrid::Treatment), Some(21));
    for grid in [
        Grid40StrictDecreaseGrid::Baseline,
        Grid40StrictDecreaseGrid::Treatment,
    ] {
        assert_eq!(
            grid40_strict_decrease_exponents(grid).find(|_| false),
            None,
            "a fixed grid must preserve backtracking refusal when no trial strictly decreases"
        );
    }
}

#[test]
fn grid40_domain_counter_is_charged_at_the_actual_predicate_entry() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    assert!(!covered_trial_is_valid(&[], 0, false));
    let counts = session.finish();
    assert_eq!(counts.domain_predicate, 1);
    assert_eq!(counts.base, 0);
    assert_eq!(counts.witness, 0);
    assert_eq!(counts.strict, 0);
    assert_eq!(counts.signed_probe, 0);
    assert_eq!(counts.denied, 0);
}

#[test]
fn grid40_budget_denies_before_the_operation_and_preserves_the_partial_counts() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    let stop = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        grid40_force_denial_for_test();
    }))
    .expect_err("a denied operation must stop before execution");
    let stop = stop
        .downcast::<crate::solver::Grid40BudgetStop>()
        .expect("only the private typed budget payload is admitted here");
    assert_eq!(stop.operation, "synthetic_denial");
    let counts = session.finish();
    assert_eq!(counts.base, 0, "denied operation was not incremented");
    assert_eq!(counts.denied, 1);
    assert_eq!(counts.budget_stop, Some("synthetic_denial"));
    assert_eq!(counts.inflight, 0);
    assert_eq!(counts.events.len(), 1);
    assert!(!counts.events[0].admitted);
    assert_eq!(counts.events[0].operation, "synthetic_denial");
}

#[test]
fn grid40_every_budget_class_denies_before_incrementing_its_real_counter() {
    for (class, operation) in [
        (Grid40BudgetClassForTest::Ordinary, "ordinary_evaluator"),
        (
            Grid40BudgetClassForTest::Complete,
            "complete_residual_evaluator",
        ),
        (Grid40BudgetClassForTest::Domain, "domain_predicate"),
        (Grid40BudgetClassForTest::Probe, "signed_jacobian_probe"),
    ] {
        let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
        let payload = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            grid40_force_class_denial_for_test(class);
        }))
        .expect_err("each budget class must reject its denied operation");
        assert_eq!(
            payload
                .downcast::<crate::solver::Grid40BudgetStop>()
                .expect("only the typed private stop is admissible")
                .operation,
            operation
        );
        let counts = session.finish();
        assert_eq!(counts.denied, 1);
        assert_eq!(counts.ordinary, 0);
        assert_eq!(counts.complete, 0);
        assert_eq!(counts.domain_predicate, 0);
        assert_eq!(counts.signed_probe, 0);
        assert_eq!(counts.inflight, 0);
        assert_eq!(counts.events.len(), 1);
        assert!(!counts.events[0].admitted);
    }
}

#[test]
fn grid40_complete_cap_denial_cannot_leave_an_ordinary_start() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    let payload = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        grid40_force_complete_cap_denial_before_ordinary_start_for_test();
    }))
    .expect_err("complete-cap denial must occur before ordinary admission");
    assert_eq!(
        payload
            .downcast::<crate::solver::Grid40BudgetStop>()
            .expect("typed private stop")
            .operation,
        "atomic_complete_denial"
    );
    let counts = session.finish();
    assert_eq!(counts.ordinary, 0);
    assert_eq!(counts.complete, 4_101);
    assert_eq!(counts.denied, 1);
}

#[test]
fn grid40_ordinary_cap_denial_cannot_leave_a_complete_start() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    let payload = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        grid40_force_ordinary_cap_denial_before_complete_start_for_test();
    }))
    .expect_err("ordinary-cap denial must occur before complete admission");
    assert_eq!(
        payload
            .downcast::<crate::solver::Grid40BudgetStop>()
            .expect("typed private stop")
            .operation,
        "atomic_ordinary_denial"
    );
    let counts = session.finish();
    assert_eq!(counts.ordinary, 1_201);
    assert_eq!(counts.complete, 0);
    assert_eq!(counts.denied, 1);
}

#[test]
fn grid40_strict_fault_is_one_shot_and_records_the_typed_error() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    assert_eq!(grid40_record_strict_fault_for_test(7), (true, true));
    let counts = session.finish();
    assert_eq!(counts.strict, 2);
    assert_eq!(counts.errors, 1);
    assert!(counts.events.iter().any(|event| {
        event.counter_class == "strict"
            && event.phase == "error"
            && event.strict_exponent == Some(7)
            && event
                .typed_error
                .as_deref()
                .is_some_and(|error| error.contains("NumericalAcceptedResidual"))
    }));
}

#[test]
fn grid40_replay_and_strict_fault_are_mutually_exclusive_in_both_directions() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    {
        let _replay = grid40_begin_replay_for_test();
        assert!(
            std::panic::catch_unwind(|| {
                let _fault = crate::solver::grid40_force_strict_evaluator_error_for_test(0);
            })
            .is_err()
        );
    }
    {
        let fault = crate::solver::grid40_force_strict_evaluator_error_for_test(0);
        assert!(
            std::panic::catch_unwind(|| {
                let _replay = grid40_begin_replay_for_test();
            })
            .is_err()
        );
        drop(fault);
    }
    let counts = session.finish();
    assert_eq!(counts.strict, 0);
}

#[test]
fn grid40_class_cap_denials_leave_every_other_evaluator_counter_unchanged() {
    for class in [
        Grid40BudgetClassForTest::Base,
        Grid40BudgetClassForTest::Witness,
        Grid40BudgetClassForTest::Strict,
    ] {
        let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
        let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            grid40_force_evaluation_class_denial_for_test(class);
        }));
        let counts = session.finish();
        assert_eq!(counts.ordinary, 0);
        assert_eq!(counts.complete, 0);
        assert_eq!(counts.inflight, 0);
        assert_eq!(counts.denied, 1);
    }
}

#[test]
fn grid40_interrupted_evaluator_retains_a_single_identifiable_inflight_operation() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    grid40_begin_interrupted_evaluation_for_test();
    let counts = session.finish();
    assert_eq!(counts.inflight, 1);
    assert_eq!(counts.inflight_operation_ids, vec![1]);
    assert!(counts.events.iter().all(|event| event.phase == "started"));
    assert!(counts.events.iter().all(|event| event.operation_id == 1));
}

#[test]
fn grid40_session_refuses_a_grid_that_was_not_installed() {
    let _treatment = grid40_install_strict_decrease_grid(Grid40StrictDecreaseGrid::Treatment);
    let mismatch = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let _ = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    }));
    assert!(mismatch.is_err());
}

#[test]
fn grid40_event_journal_open_failure_is_distinct_evidence_failure() {
    let missing = std::env::temp_dir().join(format!(
        "openwepp-grid40-missing-journal-{}/events.jsonl",
        std::process::id()
    ));
    grid40_set_event_path_for_test(Some(missing));
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    let payload = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let _ = covered_trial_is_valid(&[], 0, false);
    }))
    .expect_err("journal open failure must invalidate evidence");
    grid40_set_event_path_for_test(None);
    let failure = payload
        .downcast::<crate::solver::Grid40EvidenceFailure>()
        .expect("journal failure must not be a Grid40BudgetStop");
    assert_eq!(failure.channel, "event_journal_write");
    let counts = session.finish();
    assert_eq!(counts.domain_predicate, 1);
    assert_eq!(counts.denied, 0);
    assert_eq!(counts.inflight, 0);
}

#[test]
fn grid40_invalid_measurement_reporting_preserves_the_prior_journal_prefix() {
    let root = std::env::temp_dir().join(format!(
        "openwepp-grid40-invalid-report-{}",
        std::process::id()
    ));
    std::fs::create_dir_all(&root).expect("synthetic report root");
    let journal = root.join("events.jsonl");
    std::fs::write(&journal, b"prior-prefix\n").expect("synthetic journal prefix");
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    let counts = session.finish();
    let failure = crate::solver::Grid40EvidenceFailure {
        channel: "event_journal_write",
        detail: "synthetic closure failure".into(),
    };
    let sidecar = root.join("missing/sidecar.json");
    let report_failure =
        grid40_write_invalid_measurement_sidecar("baseline", &sidecar, &counts, &failure)
            .expect_err("an unwritable invalid sidecar remains externally invalid");
    assert_eq!(report_failure.channel, "sidecar_write");
    assert_eq!(
        std::fs::read(&journal).expect("prior journal remains readable"),
        b"prior-prefix\n"
    );
    assert!(!sidecar.exists());
    std::fs::remove_dir_all(root).expect("synthetic report cleanup");
}

#[test]
fn grid40_evaluator_lifecycle_counts_complete_and_error_outcomes_without_inflight_leaks() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    grid40_record_evaluator_lifecycle_for_test(false);
    grid40_record_evaluator_lifecycle_for_test(true);
    let counts = session.finish();
    assert_eq!(counts.ordinary, 2);
    assert_eq!(counts.complete, 2);
    assert_eq!(counts.errors, 1);
    assert_eq!(counts.inflight, 0);
    assert_eq!(counts.denied, 0);
    assert_eq!(
        counts.events.iter().filter(|event| event.admitted).count(),
        12,
        "each evaluator operation records class, ordinary, complete start and matching terminal phases"
    );
    for id in [1_u64, 2] {
        let rows = counts
            .events
            .iter()
            .filter(|event| event.operation_id == id)
            .collect::<Vec<_>>();
        assert_eq!(rows.len(), 6);
        assert!(rows.iter().any(|event| event.counter_class == "complete"));
        assert!(rows.iter().any(|event| event.phase == "started"));
    }
    assert!(counts.events.iter().any(|event| {
        event.operation_id == 2 && event.phase == "error" && event.typed_error.is_some()
    }));
}

#[test]
fn grid40_signed_probe_lifecycle_links_the_actual_parent_and_child_operations() {
    for (outcome, parent_terminal, child_terminal) in [
        (
            Grid40SignedProbeOutcomeForTest::Full,
            "full_evaluation_complete",
            "completed",
        ),
        (
            Grid40SignedProbeOutcomeForTest::Error,
            "full_evaluation_error",
            "error",
        ),
    ] {
        let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
        grid40_record_signed_probe_lifecycle_for_test(outcome);
        let counts = session.finish();
        assert_eq!(counts.signed_probe, 1);
        assert_eq!(counts.complete, 1);
        assert_eq!(counts.inflight, 0);
        assert_eq!(
            counts.errors,
            u32::from(matches!(outcome, Grid40SignedProbeOutcomeForTest::Error))
        );
        let parent = counts
            .events
            .iter()
            .filter(|event| event.operation_id == 1)
            .collect::<Vec<_>>();
        assert!(parent.iter().any(|event| event.phase == parent_terminal));
        assert!(parent.iter().any(|event| {
            event.phase == "child_complete_evaluation_started"
                && event.related_operation_id == Some(2)
        }));
        assert!(counts.events.iter().any(|event| {
            event.operation_id == 2
                && event.related_operation_id == Some(1)
                && event.phase == child_terminal
        }));

        let starts = counts
            .events
            .iter()
            .filter(|event| event.phase == "started")
            .count();
        let terminals = counts
            .events
            .iter()
            .filter(|event| {
                matches!(
                    event.phase,
                    "completed" | "error" | "full_evaluation_complete" | "full_evaluation_error"
                )
            })
            .count();
        assert_eq!(starts, terminals, "raw started/terminal recount must close");
    }
}

#[test]
fn grid40_signed_probe_identity_and_interruption_preserve_their_own_ids() {
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    grid40_record_signed_probe_lifecycle_for_test(Grid40SignedProbeOutcomeForTest::Identity);
    let counts = session.finish();
    assert_eq!(counts.signed_probe, 1);
    assert_eq!(counts.complete, 0);
    assert_eq!(counts.inflight, 0);
    assert!(
        counts
            .events
            .iter()
            .any(|event| { event.operation_id == 1 && event.phase == "identity_anchor_complete" })
    );

    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    grid40_record_signed_probe_lifecycle_for_test(Grid40SignedProbeOutcomeForTest::Interrupted);
    let counts = session.finish();
    assert_eq!(counts.signed_probe, 1);
    assert_eq!(counts.complete, 0);
    assert_eq!(counts.inflight, 1);
    assert_eq!(counts.inflight_operation_ids, vec![1]);
    assert!(
        counts
            .events
            .iter()
            .any(|event| { event.operation_id == 1 && event.phase == "interrupted" })
    );
}

#[test]
fn grid40_signed_probe_unwind_never_replaces_the_primary_panic_with_a_journal_failure() {
    let missing = std::env::temp_dir().join(format!(
        "openwepp-grid40-unwind-journal-{}/events.jsonl",
        std::process::id()
    ));
    let session = grid40_begin_call_counts(Grid40StrictDecreaseGrid::Baseline);
    let payload = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        // The start remains in the in-memory prefix. Installing an invalid
        // journal only for Drop proves the unwind guard cannot double-panic.
        grid40_interrupt_signed_probe_during_unwind_for_test(missing.clone());
    }))
    .expect_err("the synthetic primary interruption must propagate");
    grid40_set_event_path_for_test(None);
    assert_eq!(
        *payload
            .downcast::<&str>()
            .expect("primary panic must survive"),
        "grid40 primary interruption"
    );
    let counts = session.finish();
    assert_eq!(counts.signed_probe, 1);
    assert_eq!(counts.inflight_operation_ids, vec![1]);
    assert_eq!(counts.events.len(), 1, "no fake terminal event was emitted");
    assert_eq!(counts.events[0].phase, "started");
}

fn grid40_read_original_input() -> (CoveredColumnInputs, Vec<f64>) {
    let trace_path =
        std::env::var("OPENWEPP_GRID40_TRACE").expect("explicit immutable trace path is required");
    let trace_bytes = grid40_read_admitted_original_trace(std::path::Path::new(&trace_path))
        .expect("exact original trace bytes before deserialize");
    let trace: serde_json::Value = serde_json::from_slice(&trace_bytes).expect("trace JSON");
    let capture = &trace["records"][0]["value"];
    let inputs: CoveredColumnInputs =
        serde_json::from_value(capture["inputs"].clone()).expect("captured covered inputs");
    let initial_trial: Vec<f64> =
        serde_json::from_value(capture["initial_trial"].clone()).expect("captured initial trial");
    assert_eq!(initial_trial.len(), 29);
    (inputs, initial_trial)
}

#[test]
#[ignore = "the immutable original-start capture may run only as the explicit baseline or treatment arm"]
fn grid40_original_start_replay_is_explicit_and_single_arm_only() {
    let arm = std::env::var("OPENWEPP_GRID40_ARM")
        .expect("explicit baseline or treatment arm is required");
    let grid =
        grid40_arm_grid(&arm).expect("only the one baseline or one treatment arm is admitted");
    let _replay = grid40_begin_replay_for_test();
    let (inputs, initial_trial) = grid40_read_original_input();
    let sidecar = std::env::var("OPENWEPP_GRID40_SIDECAR")
        .expect("explicit external sidecar path is required");
    let _grid = grid40_install_strict_decrease_grid(grid);
    let counters = grid40_begin_call_counts(grid);
    let outcome = match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        solve_covered_column(&inputs, None, initial_trial)
    })) {
        Ok(outcome) => outcome,
        Err(payload) => match payload.downcast::<crate::solver::Grid40BudgetStop>() {
            Ok(stop) => {
                let counters = counters.finish();
                if let Some(failure) = grid40_trace_write_failure() {
                    grid40_abort_invalid_measurement(
                        &arm,
                        std::path::Path::new(&sidecar),
                        &counters,
                        &failure,
                    );
                }
                let terminal = serde_json::json!({
                    "kind": "BudgetStop", "operation": stop.operation,
                });
                std::fs::write(
                    &sidecar,
                    serde_json::to_vec_pretty(&serde_json::json!({
                        "schema": "openwepp.grid40.sidecar.v1", "arm": arm,
                        "terminal": terminal, "counts": counters,
                    }))
                    .expect("sidecar serialization"),
                )
                .expect("sidecar write");
                return;
            }
            Err(payload) => match payload.downcast::<crate::solver::Grid40EvidenceFailure>() {
                Ok(failure) => {
                    let counters = counters.finish();
                    grid40_abort_invalid_measurement(
                        &arm,
                        std::path::Path::new(&sidecar),
                        &counters,
                        &failure,
                    );
                }
                Err(other) => std::panic::resume_unwind(other),
            },
        },
    };
    let counters = counters.finish();
    if let Some(failure) = grid40_trace_write_failure() {
        grid40_abort_invalid_measurement(&arm, std::path::Path::new(&sidecar), &counters, &failure);
    }
    let terminal = match &outcome {
        Ok(CoveredColumnSolveOutcome::Accepted(candidate)) => serde_json::json!({
            "kind": "Accepted", "iterations": candidate.iterations,
            "backtracking_count": candidate.backtracking_count,
            "candidate_identity": "covered_column_candidate",
            "coordinates": &candidate.solution,
            "raw_residuals": &candidate.evaluation.raw_residuals,
            "normalizers": &candidate.evaluation.tolerances,
            "normalized_residuals": &candidate.evaluation.normalized_residuals,
            "step_norms": candidate.step_norms.diagnostics(),
            "step_origin": "last_accepted_strict_or_no_update_witness",
        }),
        Ok(CoveredColumnSolveOutcome::Rejected(failure)) => serde_json::json!({
            "kind": "Rejected", "failure_kind": format!("{:?}", failure.kind),
            "iterations": failure.iterations, "backtracking_count": failure.backtracking_count,
            "current_base_coordinates": &failure.failed_solution,
            "ordered_residuals": &failure.ordered_residuals,
            "normalized_residuals": &failure.normalized_residuals,
            "step_norms": &failure.step_norms,
            "step_origin": "last_domain_valid_rejected_trial_or_previous_accepted_step",
            "pivot_magnitude": failure.pivot_magnitude, "matrix_norm": failure.matrix_norm,
        }),
        Err(error) => serde_json::json!({"kind": "Error", "error": format!("{error:?}")}),
    };
    std::fs::write(
        sidecar,
        serde_json::to_vec_pretty(&serde_json::json!({
            "schema": "openwepp.grid40.sidecar.v1",
            "arm": arm,
            "terminal": terminal,
            "counts": counters,
        }))
        .expect("sidecar serialization"),
    )
    .expect("sidecar write");
}
