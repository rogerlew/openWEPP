//! Opt-in, test-support-only operand recording for one bounded LSE diagnosis.
//!
//! The recorder is observational: the solver never reads its state and this
//! module only allocates/serializes after the caller sets its private path.

use std::{cell::RefCell, fs, path::PathBuf};

#[derive(serde::Serialize)]
struct Trace {
    schema: &'static str,
    records: Vec<serde_json::Value>,
}

thread_local! {
    static ACTIVE: RefCell<Option<(PathBuf, Trace)>> = const { RefCell::new(None) };
    static LAST_WRITE_FAILURE: RefCell<Option<String>> = const { RefCell::new(None) };
}

pub(crate) fn begin_if_requested() {
    LAST_WRITE_FAILURE.with(|failure| *failure.borrow_mut() = None);
    ACTIVE.with(|active| {
        if active.borrow().is_none() {
            if let Some(path) = std::env::var_os("OPENWEPP_LSE_FIRST_TRIAL_TRACE") {
                *active.borrow_mut() = Some((
                    PathBuf::from(path),
                    Trace {
                        schema: "openwepp.lse-first-trial-diagnosis.v1",
                        records: Vec::new(),
                    },
                ));
            }
        }
    });
}

pub(crate) fn record(kind: &'static str, build: impl FnOnce() -> serde_json::Value) {
    ACTIVE.with(|active| {
        if let Some((path, trace)) = active.borrow_mut().as_mut() {
            trace
                .records
                .push(serde_json::json!({"kind": kind, "value": build()}));
            // A resource stop can prevent `finish`; leave the complete prefix
            // recoverable without changing solver control flow or record shape.
            match serde_json::to_vec_pretty(trace)
                .map_err(|error| error.to_string())
                .and_then(|bytes| {
                    let partial = path.with_extension("partial");
                    let next = path.with_extension("partial.next");
                    fs::write(&next, bytes)
                        .and_then(|()| fs::rename(&next, partial))
                        .map_err(|error| error.to_string())
                }) {
                Ok(()) => {}
                Err(error) => {
                    LAST_WRITE_FAILURE.with(|failure| *failure.borrow_mut() = Some(error));
                }
            }
        }
    });
}

pub(crate) fn finish() {
    ACTIVE.with(|active| {
        let Some((path, trace)) = active.borrow_mut().take() else {
            return;
        };
        if let Ok(bytes) = serde_json::to_vec_pretty(&trace) {
            let temporary = path.with_extension("partial.next");
            if fs::write(&temporary, bytes).is_ok() {
                if let Err(error) = fs::rename(&temporary, path) {
                    LAST_WRITE_FAILURE
                        .with(|failure| *failure.borrow_mut() = Some(error.to_string()));
                }
            } else {
                LAST_WRITE_FAILURE.with(|failure| {
                    *failure.borrow_mut() = Some("final trace replacement write failed".into());
                });
            }
        } else {
            LAST_WRITE_FAILURE.with(|failure| {
                *failure.borrow_mut() = Some("final trace serialization failed".into());
            });
        }
    });
}

#[cfg(test)]
pub(crate) fn take_write_failure() -> Option<String> {
    LAST_WRITE_FAILURE.with(|failure| failure.borrow_mut().take())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn recorder_write_failure_is_retained_and_cannot_be_silently_cleared() {
        let missing_parent = std::env::temp_dir().join(format!(
            "openwepp-grid40-recorder-missing-{}",
            std::process::id()
        ));
        let path = missing_parent.join("trace.json");
        ACTIVE.with(|active| {
            *active.borrow_mut() = Some((
                path,
                Trace {
                    schema: "openwepp.lse-first-trial-diagnosis.v1",
                    records: Vec::new(),
                },
            ));
        });
        record("io_failure_control", || serde_json::json!({"fixed": true}));
        assert!(take_write_failure().is_some());
        ACTIVE.with(|active| {
            active.borrow_mut().take();
        });
    }

    #[test]
    fn failed_partial_replacement_preserves_the_last_complete_prefix() {
        let root = std::env::temp_dir().join(format!(
            "openwepp-grid40-recorder-prefix-{}",
            std::process::id()
        ));
        fs::create_dir_all(&root).expect("synthetic recorder root");
        let path = root.join("trace.json");
        let partial = path.with_extension("partial");
        fs::write(&partial, b"{\"complete\":true}").expect("prior complete prefix");
        fs::create_dir(path.with_extension("partial.next")).expect("replacement blocker");
        ACTIVE.with(|active| {
            *active.borrow_mut() = Some((
                path,
                Trace {
                    schema: "openwepp.lse-first-trial-diagnosis.v1",
                    records: Vec::new(),
                },
            ));
        });
        record("replacement_failure", || serde_json::json!({"fixed": true}));
        assert!(take_write_failure().is_some());
        assert_eq!(
            fs::read(&partial).expect("retained prefix"),
            b"{\"complete\":true}"
        );
        ACTIVE.with(|active| {
            active.borrow_mut().take();
        });
        fs::remove_dir_all(root).expect("synthetic recorder cleanup");
    }
}
